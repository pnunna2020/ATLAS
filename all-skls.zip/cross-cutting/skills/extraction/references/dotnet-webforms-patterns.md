# .NET WebForms Business Rule Extraction Patterns

## Purpose

Reference for the Extraction skill when performing 3-pass business rule extraction
from .NET WebForms applications. WebForms buries business logic in event-driven
code-behind files, server control behaviors, and implicit framework conventions.
This guide maps every hiding place.

## Event Handler Extraction

Event handlers are the primary entry points for business rules in WebForms.
Every event handler signature follows the pattern:
```csharp
protected void ControlName_EventName(object sender, EventArgs e)
```

### Page Lifecycle Events

Each page lifecycle event can contain business rules. Extract in lifecycle order:

```csharp
// Page_PreInit — dynamic control creation, master page assignment
protected void Page_PreInit(object sender, EventArgs e)
{
    // RULE: Admin users see a different layout
    if (User.IsInRole("Admin"))
        MasterPageFile = "~/Admin.master";
}

// Page_Init — control initialization before ViewState loads
protected void Page_Init(object sender, EventArgs e)
{
    // RULE: Dynamic controls must be re-created on every request
    CreateDynamicFilterControls();
}

// Page_Load — primary initialization and data loading
protected void Page_Load(object sender, EventArgs e)
{
    if (!IsPostBack)
    {
        // RULE: First load populates dropdowns from reference data
        LoadAirportList();
        LoadAirlineList();

        // RULE: Default date range is today + 7 days
        txtStartDate.Text = DateTime.Today.ToString("MM/dd/yyyy");
        txtEndDate.Text = DateTime.Today.AddDays(7).ToString("MM/dd/yyyy");
    }
}

// Page_PreRender — final adjustments before rendering
protected void Page_PreRender(object sender, EventArgs e)
{
    // RULE: Hide export button if no results
    btnExport.Visible = gvResults.Rows.Count > 0;

    // RULE: Show warning banner if in maintenance window
    pnlWarning.Visible = MaintenanceSchedule.IsInWindow(DateTime.Now);
}
```

**Extraction checklist for lifecycle events:**
- `Page_PreInit`: Dynamic master page logic, dynamic control creation
- `Page_Init`: Control tree construction, initial property assignment
- `Page_Load (!IsPostBack)`: First-load defaults, dropdown population, query string parsing
- `Page_Load (always)`: Per-request validation, authorization checks
- `Page_PreRender`: Conditional visibility, final data formatting, UI state rules

### Button Click Events

Button clicks are the most common business rule trigger:

```csharp
protected void btnSubmitApplication_Click(object sender, EventArgs e)
{
    // RULE: Validate all required fields before submission
    if (!Page.IsValid) return;

    // RULE: Application number is auto-generated: prefix + date + sequence
    string appNumber = GenerateApplicationNumber();

    // RULE: Applications submitted after 5 PM ET go to next business day queue
    DateTime effectiveDate = DateTime.Now.Hour >= 17
        ? GetNextBusinessDay(DateTime.Today)
        : DateTime.Today;

    // RULE: Tier 1 applications require supervisor pre-approval
    bool requiresPreApproval = ddlTier.SelectedValue == "1";

    var app = new Application
    {
        Number = appNumber,
        EffectiveDate = effectiveDate,
        RequiresPreApproval = requiresPreApproval,
        SubmittedBy = User.Identity.Name,
        Status = requiresPreApproval ? "PendingApproval" : "Submitted"
    };

    ApplicationService.Submit(app);
}
```

**Key extraction points:**
- Auto-generation rules (IDs, numbers, codes)
- Time-based rules (cutoff times, business day calculations)
- Conditional workflow branching (approval routing)
- Status transitions (what status is set and when)

### GridView Events

GridView events contain per-row business logic:

```csharp
// Row data binding — conditional formatting rules
protected void gvFlights_RowDataBound(object sender, GridViewRowEventArgs e)
{
    if (e.Row.RowType == DataControlRowType.DataRow)
    {
        var flight = (Flight)e.Row.DataItem;

        // RULE: Delayed flights shown in red
        if (flight.Status == "Delayed")
            e.Row.CssClass = "delayed-row";

        // RULE: Flights departing within 30 minutes cannot be edited
        var btnEdit = (Button)e.Row.FindControl("btnEdit");
        btnEdit.Enabled = flight.DepartureTime > DateTime.Now.AddMinutes(30);

        // RULE: Only supervisors can see the cost column
        e.Row.Cells[5].Visible = User.IsInRole("Supervisor");
    }
}

// Row command — action rules
protected void gvFlights_RowCommand(object sender, GridViewCommandEventArgs e)
{
    int flightId = Convert.ToInt32(e.CommandArgument);

    switch (e.CommandName)
    {
        case "Cancel":
            // RULE: Flights can only be cancelled 2+ hours before departure
            var flight = FlightService.GetById(flightId);
            if (flight.DepartureTime < DateTime.Now.AddHours(2))
                throw new BusinessException("Cannot cancel within 2 hours");
            FlightService.Cancel(flightId, User.Identity.Name);
            break;

        case "Reassign":
            // RULE: Reassignment requires dispatcher role
            if (!User.IsInRole("Dispatcher"))
                throw new UnauthorizedAccessException();
            break;
    }
}

// Sorting and paging — may contain custom sort logic
protected void gvFlights_Sorting(object sender, GridViewSortEventArgs e)
{
    // RULE: Default sort is departure time ascending, then priority descending
}

// Row editing — field-level edit rules
protected void gvFlights_RowUpdating(object sender, GridViewUpdateEventArgs e)
{
    // RULE: Gate assignment can only be changed by operations staff
    // RULE: Estimated departure time cannot be set to past
}
```

### DropDownList Events

Selection changes often trigger cascading rules:

```csharp
protected void ddlAirport_SelectedIndexChanged(object sender, EventArgs e)
{
    // RULE: Terminal list depends on selected airport
    LoadTerminals(ddlAirport.SelectedValue);

    // RULE: Gate list depends on selected terminal
    ddlGate.Items.Clear();
    ddlGate.Items.Add(new ListItem("-- Select Terminal First --", ""));
}

protected void ddlCategory_SelectedIndexChanged(object sender, EventArgs e)
{
    // RULE: Category "Hazardous" enables additional required fields
    pnlHazmatDetails.Visible = ddlCategory.SelectedValue == "HAZ";
    rfvHazmatClass.Enabled = ddlCategory.SelectedValue == "HAZ";

    // RULE: Category "Diplomatic" requires special authorization code
    pnlDiplomaticAuth.Visible = ddlCategory.SelectedValue == "DIP";
}
```

### Timer Events

Periodic refresh logic contains temporal rules:

```csharp
protected void Timer1_Tick(object sender, EventArgs e)
{
    // RULE: Flight board refreshes every 30 seconds
    // RULE: Flights that landed more than 2 hours ago drop off the board
    var activeFlights = FlightService.GetActive()
        .Where(f => f.LandingTime == null ||
                     f.LandingTime > DateTime.Now.AddHours(-2));
    gvFlightBoard.DataSource = activeFlights;
    gvFlightBoard.DataBind();
}
```

### Wizard Control Events

Multi-step form logic contains step-transition rules:

```csharp
protected void Wizard1_ActiveStepChanged(object sender, EventArgs e)
{
    // RULE: Step 3 requires completion of background check in Step 2
}

protected void Wizard1_NextButtonClick(object sender, WizardNavigationEventArgs e)
{
    // RULE: Cannot proceed past Step 2 without uploading required documents
    if (Wizard1.ActiveStepIndex == 1 && !HasRequiredDocuments())
    {
        e.Cancel = true;
        lblError.Text = "Please upload all required documents.";
    }
}

protected void Wizard1_FinishButtonClick(object sender, WizardNavigationEventArgs e)
{
    // RULE: Final submission creates the application record and triggers workflow
}
```

## Validation Extraction

### Declarative Validators (aspx Markup)

Validators in markup encode business rules as field-level constraints:

```aspx
<!-- RULE: Flight number is required -->
<asp:RequiredFieldValidator ID="rfvFlightNum" runat="server"
    ControlToValidate="txtFlightNumber"
    ErrorMessage="Flight number is required"
    ValidationGroup="FlightEntry" />

<!-- RULE: Flight number must match pattern: 2 letters + 1-4 digits -->
<asp:RegularExpressionValidator ID="revFlightNum" runat="server"
    ControlToValidate="txtFlightNumber"
    ValidationExpression="^[A-Z]{2}\d{1,4}$"
    ErrorMessage="Format: AA1234" />

<!-- RULE: Arrival time must be after departure time -->
<asp:CompareValidator ID="cvTimes" runat="server"
    ControlToValidate="txtArrivalTime"
    ControlToCompare="txtDepartureTime"
    Operator="GreaterThan" Type="Date"
    ErrorMessage="Arrival must be after departure" />

<!-- RULE: Passenger count must be between 1 and 853 -->
<asp:RangeValidator ID="rvPassengers" runat="server"
    ControlToValidate="txtPassengers"
    MinimumValue="1" MaximumValue="853" Type="Integer"
    ErrorMessage="Passengers must be 1-853" />

<!-- RULE: Custom validation — departure airport cannot equal arrival airport -->
<asp:CustomValidator ID="cvAirports" runat="server"
    ControlToValidate="ddlArrival"
    OnServerValidate="cvAirports_ServerValidate"
    ClientValidationFunction="validateAirports"
    ErrorMessage="Departure and arrival airports must differ" />
```

### Server-Side Custom Validation

```csharp
protected void cvAirports_ServerValidate(object source,
    ServerValidateEventArgs args)
{
    // RULE: Origin and destination airports must be different
    args.IsValid = ddlDeparture.SelectedValue != ddlArrival.SelectedValue;
}

protected void cvDateRange_ServerValidate(object source,
    ServerValidateEventArgs args)
{
    // RULE: Search date range cannot exceed 90 days
    DateTime start = DateTime.Parse(txtStartDate.Text);
    DateTime end = DateTime.Parse(txtEndDate.Text);
    args.IsValid = (end - start).TotalDays <= 90;
}
```

**Extraction approach:**
1. Scan all `.aspx` files for validator controls — each is a business rule
2. Map `ValidationGroup` attributes to understand which validators fire together
3. Extract `CustomValidator` server-side methods — they contain complex rules
4. Check for client-side validation functions that may duplicate or extend server rules

### Programmatic Validation in Code-Behind

```csharp
protected void btnSave_Click(object sender, EventArgs e)
{
    // RULE: Manual validation beyond declarative validators
    var errors = new List<string>();

    // RULE: If international flight, passport number is required
    if (ddlFlightType.SelectedValue == "International"
        && string.IsNullOrEmpty(txtPassport.Text))
    {
        errors.Add("Passport number required for international flights");
    }

    // RULE: Total weight cannot exceed aircraft maximum
    decimal totalWeight = CalculateTotalWeight();
    decimal maxWeight = GetAircraftMaxWeight(ddlAircraft.SelectedValue);
    if (totalWeight > maxWeight)
    {
        errors.Add($"Total weight {totalWeight} exceeds max {maxWeight}");
    }

    if (errors.Any())
    {
        rptErrors.DataSource = errors;
        rptErrors.DataBind();
        pnlErrors.Visible = true;
        return;
    }

    // Proceed with save...
}
```

### ModelState Validation (WebForms 4.5+ Model Binding)

```csharp
public void SaveFlight(Flight flight)
{
    if (ModelState.IsValid)
    {
        // Model binding validation passed
        FlightService.Save(flight);
    }
    else
    {
        // Validation errors in ModelState
    }
}
```

## Entity Framework / LINQ Extraction

### LINQ Queries as Business Rules

LINQ queries encode filtering, ordering, and transformation logic that constitutes
business rules:

```csharp
// RULE: Active flights are those not cancelled and departing within 24 hours
var activeFlights = context.Flights
    .Where(f => f.Status != "Cancelled"
             && f.DepartureTime >= DateTime.Now
             && f.DepartureTime <= DateTime.Now.AddHours(24))
    .OrderBy(f => f.DepartureTime)
    .Select(f => new FlightSummary
    {
        FlightNumber = f.FlightNumber,
        // RULE: Display name is airline code + flight number
        DisplayName = f.Airline.Code + " " + f.FlightNumber,
        // RULE: Delayed if actual departure is 15+ minutes after scheduled
        IsDelayed = f.ActualDeparture.HasValue &&
            (f.ActualDeparture.Value - f.ScheduledDeparture).TotalMinutes > 15
    });

// RULE: Monthly report includes only completed flights with valid metrics
var monthlyReport = context.Flights
    .Where(f => f.CompletedDate.HasValue
             && f.CompletedDate.Value.Month == reportMonth
             && f.CompletedDate.Value.Year == reportYear)
    .GroupBy(f => f.AirlineId)
    .Select(g => new AirlineMetrics
    {
        AirlineId = g.Key,
        TotalFlights = g.Count(),
        // RULE: On-time percentage excludes cancelled and diverted flights
        OnTimePercentage = g.Count(f => !f.IsDelayed && f.Status == "Completed")
            * 100.0 / g.Count(f => f.Status == "Completed"),
        // RULE: Average delay is only calculated for delayed flights
        AvgDelayMinutes = g.Where(f => f.IsDelayed)
            .Average(f => (f.ActualDeparture.Value - f.ScheduledDeparture).TotalMinutes)
    });
```

### EF Migrations as Schema Evolution

```csharp
// Migrations encode business rule changes over time
public partial class AddFlightPriorityLevel : DbMigration
{
    public override void Up()
    {
        // RULE: Priority levels added in v2.3 — 1=Emergency, 2=High, 3=Normal
        AddColumn("dbo.Flights", "PriorityLevel",
            c => c.Int(nullable: false, defaultValue: 3));

        // RULE: Historical flights default to Normal priority
        Sql("UPDATE Flights SET PriorityLevel = 3 WHERE PriorityLevel IS NULL");
    }
}
```

### DbContext Configuration as Business Constraints

```csharp
protected override void OnModelCreating(DbModelBuilder modelBuilder)
{
    // RULE: Flight number is unique per airline per date
    modelBuilder.Entity<Flight>()
        .HasIndex(f => new { f.AirlineId, f.FlightNumber, f.FlightDate })
        .IsUnique();

    // RULE: Soft delete — flights are never physically deleted
    modelBuilder.Entity<Flight>()
        .HasQueryFilter(f => !f.IsDeleted);

    // RULE: Cascade delete from Flight to Segments but not to Passengers
    modelBuilder.Entity<Flight>()
        .HasMany(f => f.Segments)
        .WithRequired(s => s.Flight)
        .WillCascadeOnDelete(true);

    modelBuilder.Entity<Flight>()
        .HasMany(f => f.Passengers)
        .WithRequired(p => p.Flight)
        .WillCascadeOnDelete(false);
}
```

## Stored Procedure Business Logic

### Naming Convention Analysis
Common FAA / government .NET stored procedure conventions:
```
sp_GetFlightsByRoute        ← read operation
sp_InsertFlightRecord       ← create operation
sp_UpdateFlightStatus       ← update operation
sp_DeleteFlightSegment      ← delete (or soft-delete) operation
sp_CalculateDelayMetrics    ← business calculation
sp_ValidateFlightPlan       ← business rule validation
sp_ProcessDailyBatch        ← batch processing logic
usp_*                       ← "user stored procedure" prefix variant
fn_CalculateFuelCost        ← scalar function (business rule)
fn_GetNextBusinessDay       ← scalar function (utility rule)
vw_ActiveFlights            ← view (encapsulated query rule)
```

### Extracting Rules from Stored Procedures

```sql
-- RULE: Flight status transition validation
CREATE PROCEDURE sp_UpdateFlightStatus
    @FlightId INT,
    @NewStatus VARCHAR(20),
    @UpdatedBy VARCHAR(50)
AS
BEGIN
    DECLARE @CurrentStatus VARCHAR(20)
    SELECT @CurrentStatus = Status FROM Flights WHERE FlightId = @FlightId

    -- RULE: Valid status transitions
    -- Scheduled → Boarding → Departed → Airborne → Landed → Completed
    -- Any status → Cancelled (except Completed)
    -- Any status → Diverted (only from Airborne)
    IF @NewStatus = 'Cancelled' AND @CurrentStatus = 'Completed'
    BEGIN
        RAISERROR('Cannot cancel a completed flight', 16, 1)
        RETURN
    END

    IF @NewStatus = 'Diverted' AND @CurrentStatus != 'Airborne'
    BEGIN
        RAISERROR('Only airborne flights can be diverted', 16, 1)
        RETURN
    END

    -- RULE: Status change creates audit trail
    INSERT INTO FlightStatusHistory (FlightId, OldStatus, NewStatus,
        ChangedBy, ChangedDate)
    VALUES (@FlightId, @CurrentStatus, @NewStatus, @UpdatedBy, GETDATE())

    UPDATE Flights SET Status = @NewStatus, LastUpdated = GETDATE()
    WHERE FlightId = @FlightId
END
```

### Dynamic SQL in Stored Procedures

```sql
-- Dynamic SQL hides conditional business logic
CREATE PROCEDURE sp_SearchFlights
    @Origin VARCHAR(3) = NULL,
    @Dest VARCHAR(3) = NULL,
    @DateFrom DATE = NULL,
    @DateTo DATE = NULL,
    @Status VARCHAR(20) = NULL,
    @AirlineId INT = NULL
AS
BEGIN
    DECLARE @sql NVARCHAR(MAX) = N'SELECT * FROM Flights WHERE 1=1'

    -- RULE: Each parameter is an optional filter
    IF @Origin IS NOT NULL
        SET @sql += N' AND OriginAirport = @Origin'
    IF @Dest IS NOT NULL
        SET @sql += N' AND DestAirport = @Dest'

    -- RULE: Date range defaults to today if not specified
    IF @DateFrom IS NULL SET @DateFrom = CAST(GETDATE() AS DATE)
    IF @DateTo IS NULL SET @DateTo = DATEADD(DAY, 7, @DateFrom)

    SET @sql += N' AND FlightDate BETWEEN @DateFrom AND @DateTo'

    EXEC sp_executesql @sql,
        N'@Origin VARCHAR(3), @Dest VARCHAR(3),
          @DateFrom DATE, @DateTo DATE',
        @Origin, @Dest, @DateFrom, @DateTo
END
```

**Extraction note**: Dynamic SQL requires careful reading to extract the full
set of filtering and defaulting rules. Reconstruct the complete query for each
combination of non-null parameters.

## web.config Business Rules

### appSettings as Business Configuration

```xml
<appSettings>
    <!-- RULE: Maximum search results per page -->
    <add key="MaxSearchResults" value="100" />

    <!-- RULE: Session timeout for inactive users (minutes) -->
    <add key="SessionTimeoutMinutes" value="20" />

    <!-- RULE: File upload size limit (bytes) -->
    <add key="MaxUploadSize" value="10485760" />

    <!-- RULE: Days before certificate expiration to send warning -->
    <add key="CertExpirationWarningDays" value="30" />

    <!-- RULE: Allowed file extensions for document upload -->
    <add key="AllowedFileExtensions" value=".pdf,.doc,.docx,.xls,.xlsx" />

    <!-- RULE: Feature toggle for new flight plan validation -->
    <add key="EnableNewFlightPlanValidation" value="false" />

    <!-- RULE: Email distribution list for critical alerts -->
    <add key="CriticalAlertRecipients"
         value="ops@faa.gov;supervisor@faa.gov" />
</appSettings>
```

**Extraction approach**: Every `appSettings` value is a potential business rule.
Extract each one with its key name, current value, and the code that reads it:
```csharp
int maxResults = int.Parse(ConfigurationManager.AppSettings["MaxSearchResults"]);
```

### Custom Configuration Sections

```csharp
// FlightRulesSection.cs
public class FlightRulesSection : ConfigurationSection
{
    [ConfigurationProperty("minimumCrewSize", DefaultValue = 2)]
    public int MinimumCrewSize => (int)this["minimumCrewSize"];

    [ConfigurationProperty("maxFlightHours", DefaultValue = 16.0)]
    public double MaxFlightHours => (double)this["maxFlightHours"];

    [ConfigurationProperty("requiredRestHours", DefaultValue = 10.0)]
    public double RequiredRestHours => (double)this["requiredRestHours"];
}
```

```xml
<flightRules minimumCrewSize="3" maxFlightHours="14" requiredRestHours="10" />
```

Custom config sections are business rules by definition. Extract every property,
its default value, its current configured value, and where it is consumed in code.

## VB.NET vs C# Idiom Differences

Many FAA WebForms apps are written in VB.NET. Key extraction differences:

### With Blocks
```vb
' VB.NET — With block groups property assignments
With flight
    .Number = txtFlightNumber.Text
    .Origin = ddlOrigin.SelectedValue
    .Destination = ddlDestination.SelectedValue
    .DepartureDate = Calendar1.SelectedDate
    .Status = "Scheduled"
End With
```
Each property assignment inside a `With` block is a field-mapping rule.

### Optional Parameters and Default Values
```vb
' VB.NET — optional parameters with defaults
Public Function SearchFlights(
    origin As String,
    destination As String,
    Optional departDate As Date = Nothing,
    Optional maxResults As Integer = 50,
    Optional includeCodeshares As Boolean = True) As List(Of Flight)
```
Default parameter values ARE business rules (default search limit, default
inclusion behavior).

### Late Binding
```vb
' VB.NET — late-bound COM object interaction
Dim excelApp As Object = CreateObject("Excel.Application")
excelApp.Workbooks.Open("C:\Reports\FlightData.xlsx")
```
Late binding hides the actual API being called. If `Option Strict Off` is set
(common in older VB.NET apps), any object can be called with any method name
without compile-time checking.

### My Namespace
```vb
' VB.NET — My namespace provides application-level shortcuts
My.Settings.MaxSearchResults         ' reads from app.config
My.Computer.FileSystem.ReadAllText() ' file I/O
My.Application.Log.WriteEntry()      ' application logging
My.User.Name                         ' current Windows user
```
`My.Settings` entries map to `appSettings` or `Properties/Settings.settings`
file — extract them as business configuration.

### Nothing vs Null Handling
```vb
' VB.NET treats Nothing differently for value types vs reference types
Dim x As Integer = Nothing    ' x = 0 (value type default)
Dim s As String = Nothing     ' s = null reference
If x = Nothing Then           ' True (0 = 0)
If s Is Nothing Then          ' True (null check)
```
This implicit behavior differs from C#'s stricter null semantics. Document
any code that relies on VB.NET's `Nothing` coercion as an implicit business rule.

## Implicit Behaviors

WebForms has many implicit behaviors that function as business rules even though
they are not explicitly coded. Extract and document each one found.

### ViewState Roundtrip
```csharp
// Control values automatically survive postback via ViewState
// This means: if a user fills a form and clicks a button, all field values
// are preserved without explicit re-loading from the database.
// In the target stack, this must be handled explicitly (form state, Redux,
// Blazor state, etc.)
```

**Rule**: Any page that relies on ViewState for multi-step data entry has an
implicit state persistence rule that must be made explicit in the target.

### Postback Lifecycle Ordering
```csharp
// Page_Load fires BEFORE button click events
// This means: if Page_Load modifies a control, the button handler sees
// the modified value, not the original postback value.
protected void Page_Load(object sender, EventArgs e)
{
    // This runs first on postback
    if (IsPostBack)
    {
        // IMPLICIT RULE: Recalculate totals before handling any button click
        RecalculateTotals();
    }
}

protected void btnSubmit_Click(object sender, EventArgs e)
{
    // This runs second — sees the recalculated totals
    decimal total = decimal.Parse(lblTotal.Text);
}
```

### Control Initialization Order
Controls are initialized in declaration order within the `.aspx` markup. If
control A's initialization depends on control B's value, the markup order
matters. This creates an implicit dependency that must be made explicit.

### Page Directive Inheritance
```aspx
<%@ Page Language="C#" MasterPageFile="~/Site.master"
    AutoEventWireup="true" CodeBehind="Flight.aspx.cs"
    Inherits="MyApp.Flight" %>
```

- `AutoEventWireup="true"` — events are wired by naming convention (e.g.,
  `Page_Load` is automatically called). If `false`, events must be explicitly
  wired in `OnInit`.
- `MasterPageFile` — determines layout inheritance and available ContentPlaceHolders
- `Inherits` — the code-behind class, which may itself inherit from a custom
  base page class

### Base Page Classes
```csharp
// BasePage.cs — shared logic inherited by all pages
public class BasePage : System.Web.UI.Page
{
    protected override void OnInit(EventArgs e)
    {
        // IMPLICIT RULE: Every page checks session validity
        if (Session["UserId"] == null)
            Response.Redirect("~/Login.aspx");

        // IMPLICIT RULE: Every page logs access
        AuditLogger.LogPageAccess(Request.Url.ToString(), User.Identity.Name);

        base.OnInit(e);
    }

    protected override void OnError(EventArgs e)
    {
        // IMPLICIT RULE: Every page error is logged and redirected
        Exception ex = Server.GetLastError();
        ErrorLogger.Log(ex);
        Server.ClearError();
        Response.Redirect("~/Error.aspx");
    }
}
```

**Extraction**: Check every page's `Inherits` attribute and trace the inheritance
chain. Base page classes contain cross-cutting business rules that apply to every
page but are invisible when reading individual page code.

## Error Handling Patterns

### Page-Level Error Handling
```csharp
protected void Page_Error(object sender, EventArgs e)
{
    Exception ex = Server.GetLastError();

    // RULE: Specific exception types get specific handling
    if (ex is UnauthorizedAccessException)
        Response.Redirect("~/AccessDenied.aspx");
    else if (ex is FlightNotFoundException)
        Response.Redirect("~/FlightNotFound.aspx?msg=" +
            Server.UrlEncode(ex.Message));
}
```

### Application-Level Error Handling
```csharp
// Global.asax.cs
protected void Application_Error(object sender, EventArgs e)
{
    Exception ex = Server.GetLastError();

    // RULE: Log all unhandled exceptions with request context
    ErrorLogger.Log(ex, new
    {
        Url = Request.Url.ToString(),
        User = User?.Identity?.Name,
        SessionId = Session?.SessionID
    });

    // RULE: Different error pages based on HTTP status code
    var httpEx = ex as HttpException;
    if (httpEx != null)
    {
        switch (httpEx.GetHttpCode())
        {
            case 404: Response.Redirect("~/404.aspx"); break;
            case 403: Response.Redirect("~/403.aspx"); break;
            default: Response.Redirect("~/Error.aspx"); break;
        }
    }
}
```

### Custom Error Pages in web.config
```xml
<customErrors mode="On" defaultRedirect="~/Error.aspx">
  <error statusCode="404" redirect="~/404.aspx" />
  <error statusCode="403" redirect="~/403.aspx" />
  <error statusCode="500" redirect="~/Error.aspx" />
</customErrors>
```

### Health Monitoring
```xml
<healthMonitoring enabled="true">
  <rules>
    <add name="All Errors" eventName="All Errors"
         provider="EventLogProvider" />
    <add name="Failure Audits" eventName="Failure Audits"
         provider="SqlWebEventProvider" />
  </rules>
</healthMonitoring>
```

Health monitoring rules define what errors are captured and where they are sent.
These are operational business rules that must be preserved in the target system's
logging and monitoring configuration.

## Workflow Patterns

### Wizard Control State Machine

```csharp
// Multi-step application process
// Step 0: Personal Information
// Step 1: Document Upload
// Step 2: Payment
// Step 3: Review & Submit
// Step 4: Confirmation

protected void Wizard1_NextButtonClick(object sender,
    WizardNavigationEventArgs e)
{
    switch (e.CurrentStepIndex)
    {
        case 0:
            // RULE: SSN must be validated against external system before proceeding
            if (!SsnValidator.Validate(txtSSN.Text))
            {
                e.Cancel = true;
                lblError.Text = "SSN validation failed.";
            }
            break;

        case 1:
            // RULE: At least 2 documents required: photo ID + proof of citizenship
            if (fuDocuments.PostedFile == null || GetUploadedDocCount() < 2)
            {
                e.Cancel = true;
                lblError.Text = "Upload required documents.";
            }
            break;

        case 2:
            // RULE: Payment must be processed before review step
            var result = PaymentService.Process(GetPaymentInfo());
            if (!result.Success)
            {
                e.Cancel = true;
                lblError.Text = "Payment failed: " + result.Message;
            }
            Session["PaymentConfirmation"] = result.ConfirmationNumber;
            break;
    }
}
```

**Extraction checklist for wizard workflows:**
- Document every step and its purpose
- Extract step transition rules (what must be true to advance)
- Extract back-navigation rules (can the user go back? what happens to data?)
- Extract cancel rules (what cleanup happens on abandonment?)
- Extract the final submission logic (what happens at completion)

### Session-Based Multi-Page Workflows

When workflow spans multiple pages without a Wizard control:

```csharp
// Step1.aspx.cs
protected void btnNext_Click(object sender, EventArgs e)
{
    // RULE: Store step 1 data in session for later assembly
    Session["Step1_Name"] = txtName.Text;
    Session["Step1_DOB"] = txtDOB.Text;
    Session["Step1_Complete"] = true;
    Response.Redirect("Step2.aspx");
}

// Step2.aspx.cs
protected void Page_Load(object sender, EventArgs e)
{
    // RULE: Step 2 requires step 1 completion
    if (Session["Step1_Complete"] == null || !(bool)Session["Step1_Complete"])
        Response.Redirect("Step1.aspx");
}

// Step3.aspx.cs (final)
protected void btnSubmit_Click(object sender, EventArgs e)
{
    // RULE: Assemble complete application from session state
    var app = new Application
    {
        Name = Session["Step1_Name"].ToString(),
        DOB = DateTime.Parse(Session["Step1_DOB"].ToString()),
        Address = Session["Step2_Address"].ToString(),
        // ... more fields from session
    };

    ApplicationService.Submit(app);

    // RULE: Clear session after successful submission
    Session.Remove("Step1_Name");
    Session.Remove("Step1_DOB");
    Session.Remove("Step1_Complete");
    // ...
}
```

**Extraction approach:**
1. Map all session keys used across the workflow pages
2. Document the required completion order (which pages must be visited first)
3. Extract the final assembly logic that combines all session data
4. Document cleanup rules (when session data is cleared)
5. Document timeout behavior (what happens when session expires mid-workflow)

## Extraction Checklist Summary

For each WebForms application, extract in this order:

1. **Page inventory**: List every `.aspx` page with its code-behind class and
   base class, noting master page assignments
2. **Event handler catalog**: For each page, list every event handler method and
   classify it (initialization, action, validation, navigation)
3. **Validation rules**: Extract all declarative validators from markup AND all
   programmatic validation from code-behind
4. **Data access rules**: Extract LINQ queries, stored procedure calls, and
   inline SQL — each query's WHERE clause is a business rule
5. **State management rules**: Map all session variables and ViewState-dependent
   behaviors
6. **Configuration rules**: Extract all `appSettings`, custom config sections,
   and connection strings as business configuration
7. **Workflow rules**: Document multi-step processes (Wizard controls,
   session-based workflows, cross-page postbacks)
8. **Error handling rules**: Extract exception handling, error pages, and
   health monitoring configuration
9. **Authorization rules**: Extract role checks, location-based authorization,
   and custom auth module logic
10. **Implicit behaviors**: Document lifecycle dependencies, base page logic,
    auto-wired events, and ViewState reliance
