# NATURAL/ADABAS Business Rule Extraction Patterns

Reference for the Extraction skill when extracting business rules, validations,
calculations, and workflows from Software AG NATURAL 4GL applications backed by
ADABAS databases.

## Extraction Strategy Overview

NATURAL business rules hide in different constructs than typical 3GL languages.
The 4GL nature means much behavior is implicit (automatic loops, implicit commits,
edit masks) rather than explicit. Extraction must surface these implicit behaviors
as explicit rules in the target specification.

**3-pass extraction is mandatory for NATURAL:**
- **Pass 1 (Rules)**: Extract all decision logic, calculations, data access,
  and validation from NATURAL source
- **Pass 2 (Tests)**: Derive test cases from extracted rules, including edge
  cases around NATURAL implicit behaviors
- **Pass 3 (Cross-Validation)**: Reconcile rules across CALLNAT boundaries,
  copycode inclusions, and GDA-shared state

## DECIDE ON / DECIDE FOR Extraction

### Pattern: DECIDE ON (Value-Based Dispatch)
```natural
DECIDE ON FIRST VALUE OF DISPOSITION-CODE
  VALUE 'RET'
    PERFORM PROCESS-RETIRE
    MOVE 'Retired from service' TO DISP-DESC
  VALUE 'REF'
    PERFORM PROCESS-REFACTOR
    MOVE 'Scheduled for refactoring' TO DISP-DESC
  VALUE 'REP'
    PERFORM PROCESS-REPLACE
    MOVE 'Replacement system identified' TO DISP-DESC
  VALUE 'CON'
    PERFORM PROCESS-CONSOLIDATE
    MOVE 'Merged into target system' TO DISP-DESC
  NONE VALUE
    MOVE 'ERR-INVALID-DISP' TO ERROR-CODE
    PERFORM ERROR-HANDLER
END-DECIDE
```

**Extract as decision table:**

| DISPOSITION-CODE | Action | Description | Error |
|-----------------|--------|-------------|-------|
| RET | PROCESS-RETIRE | "Retired from service" | |
| REF | PROCESS-REFACTOR | "Scheduled for refactoring" | |
| REP | PROCESS-REPLACE | "Replacement system identified" | |
| CON | PROCESS-CONSOLIDATE | "Merged into target system" | |
| (any other) | ERROR-HANDLER | | ERR-INVALID-DISP |

**Extraction checklist:**
- [ ] Document every VALUE clause with its action
- [ ] Document the NONE VALUE clause (default/error path)
- [ ] Note whether it is FIRST VALUE (stop at first match) or EVERY VALUE (all matches)
- [ ] Trace PERFORM targets to extract delegated logic
- [ ] Check if DECIDE ON variable is from user input, database, or derived

### Pattern: DECIDE FOR (Condition-Based Dispatch)
```natural
DECIDE FOR FIRST CONDITION
  WHEN AIRCRAFT-WEIGHT > 12500 AND ENGINE-COUNT >= 2
    MOVE 'TRANSPORT' TO CATEGORY
    MOVE 3 TO INSPECTION-FREQUENCY
  WHEN AIRCRAFT-WEIGHT > 12500
    MOVE 'LARGE' TO CATEGORY
    MOVE 2 TO INSPECTION-FREQUENCY
  WHEN ENGINE-COUNT > 1
    MOVE 'MULTI-ENGINE' TO CATEGORY
    MOVE 2 TO INSPECTION-FREQUENCY
  WHEN AIRCRAFT-WEIGHT <= 12500
    MOVE 'SMALL' TO CATEGORY
    MOVE 1 TO INSPECTION-FREQUENCY
  WHEN NONE
    MOVE 'UNCLASSIFIED' TO CATEGORY
    MOVE 0 TO INSPECTION-FREQUENCY
END-DECIDE
```

**Extract as ordered rule set (order matters for FIRST CONDITION):**

| Priority | Condition | Category | Inspection Frequency |
|----------|-----------|----------|---------------------|
| 1 | weight > 12500 AND engines >= 2 | TRANSPORT | 3 |
| 2 | weight > 12500 | LARGE | 2 |
| 3 | engines > 1 | MULTI-ENGINE | 2 |
| 4 | weight <= 12500 | SMALL | 1 |
| 5 | (none match) | UNCLASSIFIED | 0 |

**Critical: FIRST vs EVERY**
- `DECIDE FOR FIRST CONDITION` stops at first match. Rule order is business logic.
- `DECIDE FOR EVERY CONDITION` executes ALL matching branches. Later branches may
  overwrite values set by earlier branches. Extract as accumulative rule set.

## COMPUTE / MOVE Extraction

### Calculation Rules with Operand Tracing
```natural
COMPUTE ANNUAL-FEE =
    BASE-REGISTRATION-FEE
  + (ENGINE-COUNT * PER-ENGINE-SURCHARGE)
  + (IF AIRCRAFT-WEIGHT > 12500 THEN HEAVY-AIRCRAFT-FEE ELSE 0)
  - EARLY-RENEWAL-DISCOUNT
```

**Extract as formula specification:**
```
Rule: ANNUAL-FEE-CALCULATION
  Formula: BASE-REGISTRATION-FEE
           + (ENGINE-COUNT * PER-ENGINE-SURCHARGE)
           + conditional(AIRCRAFT-WEIGHT > 12500, HEAVY-AIRCRAFT-FEE, 0)
           - EARLY-RENEWAL-DISCOUNT
  Operands:
    BASE-REGISTRATION-FEE     source: RATE-TABLE file, field RT-BASE-FEE
    ENGINE-COUNT               source: AIRCRAFT file, field AC-ENGINES
    PER-ENGINE-SURCHARGE       source: RATE-TABLE file, field RT-PER-ENGINE
    AIRCRAFT-WEIGHT            source: AIRCRAFT file, field AC-WEIGHT
    HEAVY-AIRCRAFT-FEE         source: RATE-TABLE file, field RT-HEAVY-FEE
    EARLY-RENEWAL-DISCOUNT     source: calculated, see DISCOUNT-CALC rule
  Result Type: N9.2 (9 digits, 2 decimal places)
  Overflow: Raises NAT1305 if result exceeds N9.2 range
```

**Operand tracing checklist:**
- [ ] For each operand, trace to its source (database field, calculation, input, constant)
- [ ] Document field types and sizes (truncation and overflow implications)
- [ ] Document edit masks used for display (they are NOT part of the calculation)
- [ ] Check for ROUNDED keyword (NATURAL supports explicit rounding in COMPUTE)
- [ ] Check for integer vs decimal arithmetic (NATURAL uses fixed-point, not floating)

### MOVE Statement Patterns
```natural
/* Simple assignment */
MOVE #INPUT-DATE TO #CERT-EFFECTIVE-DATE

/* Edited move (format conversion) */
MOVE EDITED #NUMERIC-STRING (EM=9999) TO #NUMBER

/* MOVE BY NAME (copies matching field names between groups) */
MOVE BY NAME INPUT-RECORD TO DATABASE-RECORD

/* MOVE ALL (fill with repeated character) */
MOVE ALL '*' TO #MASKED-SSN
```

**MOVE BY NAME is high-risk**: It copies fields with matching names between two
group structures. If a field exists in the source but not the target (or vice versa),
it is silently skipped. Document every MOVE BY NAME with explicit field-by-field
mapping showing which fields actually transfer.

## AT BREAK Extraction

### Report Aggregation Rules
```natural
READ CERT-FILE BY CERT-TYPE
  AT BREAK OF CERT-TYPE
    WRITE '--- Subtotal for' OLD(CERT-TYPE) '---'
    WRITE 'Active:'   CNT(CERT-STATUS = 'ACTIVE')
    WRITE 'Expired:'  CNT(CERT-STATUS = 'EXPIRED')
    WRITE 'Suspended:' CNT(CERT-STATUS = 'SUSPENDED')
    WRITE 'Total:'    COUNT(*)
  END-BREAK
  AT END OF DATA
    WRITE '=== Grand Total ==='
    WRITE 'Total records:' COUNT(*)
    WRITE 'Average score:' AVER(EXAM-SCORE)
  END-ENDDATA
END-READ
```

**Extract as aggregation specification:**
```
Report: CERT-STATUS-SUMMARY
  Group By: CERT-TYPE
  Aggregations Per Group:
    - CNT where CERT-STATUS = 'ACTIVE'   -> active_count
    - CNT where CERT-STATUS = 'EXPIRED'  -> expired_count
    - CNT where CERT-STATUS = 'SUSPENDED' -> suspended_count
    - COUNT(*)                             -> group_total
  Grand Total Aggregations:
    - COUNT(*)     -> grand_total
    - AVER(EXAM-SCORE) -> average_score
  SQL Equivalent:
    SELECT cert_type,
           COUNT(*) FILTER (WHERE cert_status = 'ACTIVE') AS active_count,
           COUNT(*) FILTER (WHERE cert_status = 'EXPIRED') AS expired_count,
           COUNT(*) FILTER (WHERE cert_status = 'SUSPENDED') AS suspended_count,
           COUNT(*) AS group_total
    FROM cert_file
    GROUP BY cert_type;
```

**AT BREAK implicit behaviors to extract:**
- [ ] `OLD(field)` returns the value BEFORE the break occurred
- [ ] `COUNT(field)` counts non-blank/non-zero values since last break
- [ ] `SUM(field)` sums values since last break
- [ ] `AVER(field)` averages values since last break
- [ ] `MIN(field)` / `MAX(field)` track extremes since last break
- [ ] `NMIN(field)` / `NMAX(field)` track non-zero extremes
- [ ] Nested AT BREAK (break within break) resets inner counters at each outer break
- [ ] AT END OF DATA aggregates are grand totals across ALL breaks

## IF Chain Extraction

### Nesting Depth Analysis
```natural
IF APPLICATION-TYPE = 'NEW'
  IF APPLICANT-AGE >= 16
    IF EXAM-SCORE >= 70
      IF MEDICAL-CLASS <= 3
        IF FLIGHT-HOURS >= 40
          MOVE 'APPROVED' TO APP-STATUS
          PERFORM ISSUE-CERTIFICATE
        ELSE
          MOVE 'HOURS-DEFICIENT' TO APP-STATUS
          COMPUTE HOURS-NEEDED = 40 - FLIGHT-HOURS
        END-IF
      ELSE
        MOVE 'MEDICAL-INELIGIBLE' TO APP-STATUS
      END-IF
    ELSE
      MOVE 'EXAM-FAILED' TO APP-STATUS
      COMPUTE RETAKE-AFTER-DATE = *DATX + 14
    END-IF
  ELSE
    MOVE 'AGE-INELIGIBLE' TO APP-STATUS
  END-IF
ELSE
  IF APPLICATION-TYPE = 'RENEWAL'
    /* ... renewal logic ... */
  END-IF
END-IF
```

**Extract as decision tree:**
```
Rule: NEW-APPLICATION-ELIGIBILITY
  Condition Path: APPLICATION-TYPE = 'NEW'
    Condition: APPLICANT-AGE >= 16
      Condition: EXAM-SCORE >= 70
        Condition: MEDICAL-CLASS <= 3
          Condition: FLIGHT-HOURS >= 40
            Result: APP-STATUS = 'APPROVED', issue certificate
          Else:
            Result: APP-STATUS = 'HOURS-DEFICIENT'
            Derived: HOURS-NEEDED = 40 - FLIGHT-HOURS
        Else:
          Result: APP-STATUS = 'MEDICAL-INELIGIBLE'
      Else:
        Result: APP-STATUS = 'EXAM-FAILED'
        Derived: RETAKE-AFTER-DATE = current_date + 14 days
    Else:
      Result: APP-STATUS = 'AGE-INELIGIBLE'
```

**If chain extraction checklist:**
- [ ] Convert deeply nested IF chains to decision trees (easier to verify)
- [ ] Document all possible leaf outcomes (every MOVE to status fields)
- [ ] Check for "fall-through" — IF without ELSE means the field retains its prior value
- [ ] Note which conditions use database fields vs calculated fields vs constants
- [ ] Check nesting depth: > 5 levels typically indicates multiple business rules
  packed into one block that should be decomposed

## CALLNAT Parameter Extraction

### Service Interface Contract
```natural
/* Caller: */
RESET #RETURN-CODE #ERROR-MSG
CALLNAT 'VALIDATE-CERT-RENEWAL'
    #AIRMAN-ID
    #CERT-TYPE
    #CURRENT-MEDICAL-CLASS
    #RENEWAL-APPROVED     /* output */
    #DENIAL-REASON        /* output */
    #RETURN-CODE          /* output */
    #ERROR-MSG            /* output */
```

```natural
/* Subprogram VALIDATE-CERT-RENEWAL: */
DEFINE DATA PARAMETER
  1 #AIRMAN-ID            (A9)     BY VALUE    /* input, not modifiable */
  1 #CERT-TYPE            (A10)    BY VALUE
  1 #MEDICAL-CLASS        (I2)     BY VALUE
  1 #RENEWAL-APPROVED     (L)      BY VALUE RESULT  /* output */
  1 #DENIAL-REASON        (A80)    BY VALUE RESULT
  1 #RETURN-CODE          (I4)     BY VALUE RESULT
  1 #ERROR-MSG            (A80)    BY VALUE RESULT
END-DEFINE
```

**Extract as service contract:**
```
Service: VALIDATE-CERT-RENEWAL
  Input Parameters:
    - AIRMAN-ID: alpha(9), required, by-value
    - CERT-TYPE: alpha(10), required, by-value
    - MEDICAL-CLASS: integer(2), required, by-value
  Output Parameters:
    - RENEWAL-APPROVED: boolean, indicates approval
    - DENIAL-REASON: alpha(80), populated when not approved
    - RETURN-CODE: integer(4), 0=success, non-zero=error
    - ERROR-MSG: alpha(80), populated on error
  Behavior:
    - Validates airman exists and cert type is renewable
    - Checks medical class meets cert-type requirements
    - Checks no outstanding enforcement actions
    - Returns approval or denial with reason
```

**Parameter extraction checklist:**
- [ ] Document direction: BY VALUE (input), BY VALUE RESULT (output), BY REFERENCE (in/out)
- [ ] Document exact types and lengths (mismatch = runtime error)
- [ ] Document array dimensions if parameters include arrays
- [ ] Note if parameter uses PDA (`.NSA` file) vs inline PARAMETER definition
- [ ] Trace all CALLNAT invocations to build caller-callee map

## Map Validation Extraction

### Screen-Level Validation Rules
```natural
INPUT USING MAP 'AIRMAN-UPDATE'
/* Map processing rules fire before control returns here */

/* Program-level validation after map processing */
IF #SSN = ' '
  REINPUT 'Social Security Number is required' MARK *#SSN
END-IF

IF NOT (#SSN = MASK(NNN'-'NN'-'NNNN))
  REINPUT 'SSN must be in format NNN-NN-NNNN' MARK *#SSN
END-IF

IF #CERT-EXPIRY-DATE < *DATX
  REINPUT 'Expiry date cannot be in the past' MARK *#CERT-EXPIRY-DATE
END-IF
```

**Extract as validation rules:**
```
Screen: AIRMAN-UPDATE
  Field: SSN
    Rule 1: Required (not blank)
    Rule 2: Format mask NNN-NN-NNNN
  Field: CERT-EXPIRY-DATE
    Rule 1: Must be >= current date (future date)
  Validation Order: SSN rules first, then date rules
  Error Display: REINPUT re-shows screen with message, cursor on error field
```

### Map-Embedded Processing Rules
Processing rules defined within the `.NSM` map file itself:
```
Map Field: #AIRMAN-ID
  Rule: IF #AIRMAN-ID = MASK('AAA999999') THEN OK ELSE REINPUT 'Invalid ID format'
  Trigger: On field exit (tab/enter from field)
  
Map Field: #STATE-CODE
  Rule: Must be in array of valid state codes
  Trigger: On field exit
  Type: Table lookup validation
```

**Map validation extraction checklist:**
- [ ] Examine `.NSM` source for embedded processing rules (often missed)
- [ ] Extract REINPUT messages as validation error messages
- [ ] Document MARK targets (which field gets cursor focus on error)
- [ ] Check for cross-field validation (field A depends on field B value)
- [ ] Note AT conditions (e.g., `IF *PF-KEY = 'PF5'` — validation only on save)
- [ ] Check for automatic help invocation (PF1 -> helproutine)
- [ ] Map `PROCESS PAGE` rules for array/table validation

## Database Operation Extraction

### CRUD Patterns Per ADABAS File
```natural
/* CREATE (STORE) */
RESET AIRMEN-FILE-VIEW          /* Clear all fields */
MOVE #INPUT-NAME TO AIRMAN-NAME
MOVE #INPUT-SSN TO AIRMAN-SSN
MOVE *DATX TO CREATE-DATE
STORE AIRMEN-FILE-VIEW
END TRANSACTION

/* READ (FIND/READ/GET) */
FIND AIRMEN-FILE-VIEW WITH AIRMAN-ID = #SEARCH-ID
  IF NO RECORDS FOUND
    MOVE 'NOT-FOUND' TO #STATUS
  END-NOREC
  /* Process found record */
END-FIND

/* UPDATE */
GET AIRMEN-FILE-VIEW #ISN-VALUE
  MOVE #NEW-NAME TO AIRMAN-NAME
  MOVE *DATX TO LAST-MODIFIED-DATE
  UPDATE
  END TRANSACTION

/* DELETE */
GET AIRMEN-FILE-VIEW #ISN-VALUE
  DELETE
  END TRANSACTION
```

**Extract as CRUD matrix per file:**

| File | Operation | Conditions | Fields Modified | Transaction |
|------|-----------|------------|-----------------|-------------|
| AIRMEN-FILE | STORE | New airman registration | NAME, SSN, CREATE-DATE | ET after store |
| AIRMEN-FILE | FIND | By AIRMAN-ID | (read only) | None |
| AIRMEN-FILE | UPDATE | After GET by ISN | NAME, LAST-MODIFIED-DATE | ET after update |
| AIRMEN-FILE | DELETE | After GET by ISN | (all removed) | ET after delete |

**Database operation extraction checklist:**
- [ ] Map every ADABAS access verb to CRUD (READ/FIND=R, STORE=C, UPDATE=U, DELETE=D)
- [ ] Document search criteria for FIND operations (become WHERE clauses)
- [ ] Document descriptor usage for READ operations (become ORDER BY + index hints)
- [ ] Note transaction boundaries (END TRANSACTION placement)
- [ ] Check for multi-file transactions (one ET commits across files)
- [ ] Document IF NO RECORDS FOUND handling (error path)
- [ ] Note FIND COUPLED patterns (cross-file joins)

## Batch Job Extraction

### Work File I/O Patterns
```natural
/* Batch program reading input file, processing, writing output */
DEFINE DATA LOCAL
  1 #INPUT-REC   (A200)
  1 #OUTPUT-REC  (A300)
  1 #REC-COUNT   (I8)
  1 #ERR-COUNT   (I8)
END-DEFINE

READ WORK FILE 1 #INPUT-REC
  ADD 1 TO #REC-COUNT
  PERFORM PARSE-INPUT
  IF #PARSE-OK
    PERFORM VALIDATE-RECORD
    IF #VALID
      PERFORM TRANSFORM-RECORD
      WRITE WORK FILE 2 #OUTPUT-REC
    ELSE
      ADD 1 TO #ERR-COUNT
      WRITE WORK FILE 3 #INPUT-REC  /* Error/reject file */
    END-IF
  END-IF
END-WORK

/* Summary report */
WRITE (PRINTER) 'Batch Processing Summary'
WRITE (PRINTER) 'Records Read:    ' #REC-COUNT
WRITE (PRINTER) 'Records Written: ' (#REC-COUNT - #ERR-COUNT)
WRITE (PRINTER) 'Errors:          ' #ERR-COUNT
```

**Extract as batch job specification:**
```
Job: BATCH-CERT-RENEWAL
  Schedule: Daily at 02:00 (see JCL/scheduler)
  Input:
    - WORK FILE 1 (CMWKF01): Renewal-eligible airman records
      Format: Fixed-length 200 bytes
      Source: Upstream extract job
  Processing:
    1. Parse input record into fields
    2. Validate against business rules
    3. Transform to output format
    4. Write valid records to output
    5. Write invalid records to reject file
  Output:
    - WORK FILE 2 (CMWKF02): Processed renewal records
    - WORK FILE 3 (CMWKF03): Rejected records for review
    - PRINTER (CMPRT01): Processing summary report
  Error Handling:
    - Invalid records written to reject file (not abend)
    - Summary counts printed at end
  Dependencies:
    - Requires upstream extract job to complete first
    - Output feeds downstream update job
```

### JCL Job Card Extraction
```jcl
//RENEW    JOB (ACCT),'CERT RENEWAL BATCH',
//         CLASS=A,MSGCLASS=X,NOTIFY=&SYSUID
//STEP010  EXEC PGM=NATBATCH,REGION=0M
//STEPLIB  DD DSN=NAT.LOAD,DISP=SHR
//         DD DSN=ADABAS.LOAD,DISP=SHR
//CMSYNIN  DD *
  LOGON RMSLIB
  BATCH-RENEWAL
  FIN
/*
//CMWKF01  DD DSN=DAILY.RENEWAL.INPUT,DISP=SHR
//CMWKF02  DD DSN=DAILY.RENEWAL.OUTPUT,DISP=(NEW,CATLG,DELETE),
//         SPACE=(CYL,(10,5),RLSE)
//CMWKF03  DD DSN=DAILY.RENEWAL.REJECT,DISP=(NEW,CATLG,DELETE),
//         SPACE=(CYL,(1,1),RLSE)
//CMPRT01  DD SYSOUT=A
```

**JCL extraction checklist:**
- [ ] Extract JOB card: job name, class, scheduling info
- [ ] Extract CMSYNIN: library and program to execute
- [ ] Map CMWKF01-32 to WORK FILE 1-32 in NATURAL program
- [ ] Map CMPRT01-32 to PRINTER 1-32 in NATURAL program
- [ ] Document dataset names for input/output files
- [ ] Note DISP parameters: SHR=input, NEW=output, MOD=append
- [ ] Check for multi-step JCL (multiple NATURAL programs in sequence)
- [ ] Check for COND parameters (conditional step execution)
- [ ] Extract SPACE allocations as data volume indicators

## Error Handling Extraction

### ON ERROR Block Analysis
```natural
ON ERROR
  DECIDE ON FIRST VALUE OF *ERROR-NR
    VALUE 3009
      /* End of file — normal condition, not a real error */
      IGNORE
    VALUE 3113
      /* Record held by another user */
      WRITE 'Record is locked. Please try again.'
      BACKOUT TRANSACTION
      ESCAPE ROUTINE
    VALUE 3145, 3148
      /* ADABAS timeout */
      WRITE 'Database timeout. Transaction rolled back.'
      BACKOUT TRANSACTION
      CALLNAT 'ERROR-LOGGER' *PROGRAM *ERROR-NR *ERROR-LINE 'TIMEOUT'
      ESCAPE MODULE
    VALUE 1305
      /* Numeric overflow */
      WRITE 'Calculation error in' *PROGRAM 'line' *ERROR-LINE
      CALLNAT 'ERROR-LOGGER' *PROGRAM *ERROR-NR *ERROR-LINE 'OVERFLOW'
      ESCAPE MODULE
    NONE VALUE
      /* Unexpected error */
      WRITE 'Unexpected error' *ERROR-NR 'in' *PROGRAM 'line' *ERROR-LINE
      BACKOUT TRANSACTION
      CALLNAT 'ERROR-LOGGER' *PROGRAM *ERROR-NR *ERROR-LINE 'UNEXPECTED'
      STOP
  END-DECIDE
END-ERROR
```

**Extract as error handling specification:**

| Error Code | Category | Description | Handling | Severity |
|-----------|----------|-------------|----------|----------|
| 3009 | Data Access | End of file | Ignore (normal) | Info |
| 3113 | Concurrency | Record lock contention | Backout, notify user | Warning |
| 3145 | Timeout | ADABAS timeout | Backout, log, exit module | Error |
| 3148 | Timeout | Transaction timeout | Backout, log, exit module | Error |
| 1305 | Arithmetic | Numeric overflow | Log, exit module | Error |
| (other) | Unknown | Unexpected error | Backout, log, STOP | Critical |

**Error handling extraction checklist:**
- [ ] Extract every `ON ERROR` block in every program
- [ ] Map error codes to categories (ADABAS response codes vs NATURAL errors)
- [ ] Document error recovery action (IGNORE, BACKOUT, ESCAPE, STOP)
- [ ] Note which errors call error logging subprograms
- [ ] Identify error codes that represent normal conditions (e.g., 3009)
- [ ] Check for missing ON ERROR blocks (unhandled errors terminate program)

## Transaction Boundary Extraction

### END TRANSACTION / BACKOUT TRANSACTION Patterns
```natural
/* Pattern 1: Commit after each record (safe but slow) */
FIND AIRMEN-FILE WITH CERT-STATUS = 'PENDING'
  GET AIRMEN-FILE *ISN(AIRMEN-FILE)
    MOVE 'ACTIVE' TO CERT-STATUS
    UPDATE
    END TRANSACTION
END-FIND

/* Pattern 2: Commit after batch of N records (performance) */
FIND AIRMEN-FILE WITH CERT-STATUS = 'PENDING'
  ADD 1 TO #UPDATE-COUNT
  GET AIRMEN-FILE *ISN(AIRMEN-FILE)
    MOVE 'ACTIVE' TO CERT-STATUS
    UPDATE
  IF #UPDATE-COUNT >= 100
    END TRANSACTION
    RESET #UPDATE-COUNT
  END-IF
END-FIND
END TRANSACTION    /* Final commit for remaining records */

/* Pattern 3: All-or-nothing (single transaction) */
FIND AIRMEN-FILE WITH BATCH-ID = #CURRENT-BATCH
  GET AIRMEN-FILE *ISN(AIRMEN-FILE)
    MOVE 'PROCESSED' TO BATCH-STATUS
    UPDATE
END-FIND
/* Single ET at end commits everything or nothing */
END TRANSACTION
```

**Extract as transaction specification:**
```
Transaction Pattern: BATCH-UPDATE-CERT-STATUS
  Type: Batched commits (every 100 records)
  Files Modified: AIRMEN-FILE
  Commit Frequency: Every 100 updates
  Rollback Scope: Last 100 records on failure
  Restart Strategy: Must track last committed batch for restart
  Target Equivalent: PostgreSQL batch with SAVEPOINT every 100 rows
```

**Transaction extraction checklist:**
- [ ] Identify every END TRANSACTION and BACKOUT TRANSACTION
- [ ] Document commit frequency (per-record, batched, end-of-program)
- [ ] Identify multi-file transactions (one ET covering multiple ADABAS files)
- [ ] Note implicit commits (program normal termination)
- [ ] Note implicit rollbacks (program abnormal termination)
- [ ] Document restart/recovery strategy (how does the batch resume after failure?)
- [ ] Map to target transaction model (PostgreSQL COMMIT/SAVEPOINT/ROLLBACK)

## System Variable Usage Extraction

### Implicit Behavior Dependencies
```natural
/* Date-dependent logic */
IF CERT-EXPIRY-DATE < *DATX
  MOVE 'EXPIRED' TO CERT-STATUS
END-IF

/* User-dependent logic */
IF *USER = 'BATCHUSR' OR *INIT-USER = 'SCHEDLR'
  /* Batch mode: skip interactive prompts */
  PERFORM BATCH-PROCESS
ELSE
  /* Online mode: display screens */
  INPUT USING MAP 'MAIN-MENU'
END-IF

/* Environment-dependent logic */
IF *LIBRARY = 'TESTLIB'
  MOVE 'TEST-DB' TO #DATABASE-NAME
ELSE
  MOVE 'PROD-DB' TO #DATABASE-NAME
END-IF
```

**Extract as environment dependency specification:**

| System Variable | Usage | Business Meaning | Target Equivalent |
|----------------|-------|------------------|-------------------|
| `*DATX` | Date comparison | Current date for expiry checks | `CURRENT_DATE` or `LocalDate.now()` |
| `*TIMX` | Time comparison | Current time for scheduling | `CURRENT_TIME` or `LocalTime.now()` |
| `*USER` | Authorization | Runtime user for access control | Auth context / JWT claims |
| `*INIT-USER` | Batch detection | Original login user for batch/online branching | Process identity |
| `*LIBRARY` | Env detection | Library name for environment branching | Environment variable |
| `*PROGRAM` | Logging | Current program name for error logging | Class/module name |
| `*DEVICE` | Mode detection | Terminal type or BATCH | Runtime mode flag |
| `*ERROR-NR` | Error handling | Last error code | Exception type |
| `*ISN(file)` | Record tracking | Last accessed record ISN | Primary key / cursor position |
| `*COUNTER` | Loop tracking | Current loop iteration | Loop index variable |
| `*NUMBER` | Result count | Records found by last FIND | SQL `COUNT(*)` result |

## NATURAL 4GL Implicit Behaviors as Explicit Rules

These behaviors are automatic in NATURAL but must become explicit code in the target:

### 1. Automatic Loop Termination
```natural
READ AIRMEN-FILE BY LAST-NAME
  /* Loop body */
END-READ
/* NATURAL automatically stops when file is exhausted */
```
**Target rule**: Loop must check for end-of-resultset explicitly.

### 2. Automatic Record Locking
```natural
GET AIRMEN-FILE #ISN    /* Automatically places hold lock */
  UPDATE                /* Relies on implicit lock from GET */
```
**Target rule**: Must acquire explicit row lock (`SELECT ... FOR UPDATE`).

### 3. Automatic Transaction at Program End
If a NATURAL program terminates normally without an explicit `END TRANSACTION`,
all pending changes are automatically committed.
**Target rule**: Must add explicit COMMIT at logical end of processing.

### 4. Automatic Rollback on Abnormal Termination
If a NATURAL program abends, all pending changes are automatically rolled back.
**Target rule**: Must add explicit ROLLBACK in exception handler.

### 5. Automatic Field Initialization
All NATURAL variables are initialized to their natural zero (0 for numeric,
blanks for alpha, zero-date for date). No explicit initialization needed.
**Target rule**: Must explicitly initialize all variables or handle null.

### 6. Automatic Format Conversion
```natural
MOVE '12345' TO #NUMERIC-FIELD (N5)    /* String to number: automatic */
MOVE #NUMERIC-FIELD TO #ALPHA-FIELD    /* Number to string: automatic */
```
**Target rule**: Must add explicit type conversion / parsing.

### 7. Automatic Array Bounds Checking
NATURAL raises an error if you access an array element beyond its declared bounds.
**Target rule**: May need explicit bounds checking in target language.

### 8. ESCAPE BOTTOM Numbered Exits
```natural
READ FILE-A
  READ FILE-B
    IF CONDITION
      ESCAPE BOTTOM (2)    /* Exits BOTH loops */
    END-IF
  END-READ
END-READ
```
**Target rule**: Requires labeled breaks or flag variables in most languages.
