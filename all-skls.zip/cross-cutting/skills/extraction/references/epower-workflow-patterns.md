# ePower → Camunda 8 BPMN/DMN Extraction

## Purpose
Extract business semantics from ePower workflow-engine definitions (FAA Phase 2
DIWS) and re-express them as Camunda 8 BPMN + DMN.

## Where Definitions Live
- Files: `*.proc`, `*.process`, `*.epw`, `workflow.xml` under `workflows/` or `epower/`.
- Backing DB (SQL Server / Oracle): `EP_PROCESS_DEF`, `EP_STEP`, `EP_TRANSITION`,
  `EP_WORK_ITEM`, `EP_ACTOR_ROLE`, `EP_FORM_FIELD`.
- Host config: `epower.config`, `<epower>` in `web.config` / `application.xml`.

## Constructs → Camunda 8 Target
| ePower construct | Camunda 8 target |
|---|---|
| State / activity | `UserTask`, `ServiceTask`, `ScriptTask` |
| Transition + guard | Sequence flow, FEEL `conditionExpression` |
| Actor / role | `assignee` / `candidateGroups` |
| Signal / event | Message or Signal event |
| Timer / SLA / escalation | Boundary timer or escalation event |
| Form-field binding | `zeebe:formKey` + variable mapping |
| Data-entity binding | Process variables + ServiceTask |
| Decision table | DMN on `BusinessRuleTask` |

## Anti-Pattern: Opaque Workflow
Do NOT treat ePower steps as black boxes. Every step, guard, form, timer, and
decision table contains business rules. Emit each to `business_rules_catalog`
with citation `epower:<process>:<step-id>` (or `:<transition-id>` for guards).

## Detection Heuristics
- Files: `*.proc`, `*.process`, `*.epw`, or XML with `<epower>` root.
- DB: tables prefixed `EP_`; columns `STEP_ID`, `TRANSITION_ID`, `GUARD_EXPR`,
  `ACTOR_ROLE`, `WORK_ITEM_STATE`.
- Config: `epower.engine.url`, `EPowerWorkflowModule`, `EPowerServlet`.

## Extraction Priority
1. Enumerate definitions; emit one BPMN skeleton per process.
2. Extract steps with actor/role and form bindings.
3. Extract transitions; preserve guard, translate to FEEL.
4. Extract timers, escalations, signals with payload.
5. Extract decision tables to DMN; retain hit policy and I/O typing.
6. Cite every rule as `epower:<process>:<step|transition>`.
