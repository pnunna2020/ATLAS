# SQL Server T-SQL Business Rule Extraction Patterns

## Purpose

Reference for the Extraction skill when performing business rule extraction from
SQL Server T-SQL stored procedures, functions, triggers, and views. SQL Server
applications commonly embed significant business logic in the database tier. This
guide covers every pattern an agent needs to recognize and extract.

## Stored Procedure Business Logic Extraction

### Parameter Analysis

Stored procedure parameters encode the interface contract:

```sql
-- Common parameter patterns in business-rule-heavy procedures
CREATE PROCEDURE dbo.usp_ProcessInvoice
    @InvoiceId      INT,
    @ApprovedBy     NVARCHAR(50),
    @OverrideAmount DECIMAL(18,2) = NULL,    -- optional override
    @ForceApproval  BIT = 0,                 -- flag for exception handling
    @ResultCode     INT OUTPUT,              -- return status
    @ResultMessage  NVARCHAR(500) OUTPUT     -- return description
AS
```

**Extraction points**:
- Default parameter values encode business defaults
- Optional parameters (with defaults) indicate conditional behavior paths
- Flag parameters (BIT type) indicate branching business rules
- OUTPUT parameters define the result contract

### Control Flow Patterns

**IF/ELSE chains** — the most common business rule encoding:
```sql
-- RULE: Approval routing based on invoice amount and type
IF @InvoiceAmount > 100000
BEGIN
    -- RULE: Over $100K requires CFO approval
    SET @ApprovalLevel = 'CFO'
    SET @RequiresBoard = 1
END
ELSE IF @InvoiceAmount > 25000
BEGIN
    -- RULE: Over $25K requires VP approval
    SET @ApprovalLevel = 'VP'
    SET @RequiresBoard = 0
END
ELSE IF @InvoiceType = 'CAPITAL'
BEGIN
    -- RULE: Capital expenditures always require Director approval
    SET @ApprovalLevel = 'DIRECTOR'
    SET @RequiresBoard = 0
END
ELSE
BEGIN
    -- RULE: All others require Manager approval
    SET @ApprovalLevel = 'MANAGER'
    SET @RequiresBoard = 0
END
```

**WHILE loops** — iterative business processing:
```sql
-- RULE: Process payment batches with running balance check
DECLARE @RunningBalance DECIMAL(18,2) = @AvailableFunds

WHILE EXISTS (SELECT 1 FROM @PaymentQueue WHERE Processed = 0)
BEGIN
    SELECT TOP 1
        @CurrentPaymentId = PaymentId,
        @CurrentAmount = Amount
    FROM @PaymentQueue
    WHERE Processed = 0
    ORDER BY Priority, DueDate  -- RULE: Priority-then-date ordering

    -- RULE: Stop processing if insufficient funds
    IF @CurrentAmount > @RunningBalance
        BREAK

    -- Process payment...
    SET @RunningBalance = @RunningBalance - @CurrentAmount

    UPDATE @PaymentQueue
    SET Processed = 1
    WHERE PaymentId = @CurrentPaymentId
END
```

### Dynamic SQL Detection

Dynamic SQL hides business logic inside string construction:

```sql
-- PATTERN 1: EXEC with string concatenation (SQL injection risk)
DECLARE @sql NVARCHAR(MAX)
SET @sql = 'SELECT * FROM Orders WHERE Status = ''' + @Status + ''''
EXEC(@sql)

-- PATTERN 2: sp_executesql with parameters (safer)
DECLARE @sql NVARCHAR(MAX)
SET @sql = N'SELECT * FROM Orders WHERE OrderDate >= @StartDate'

-- RULE: Dynamic filter construction based on user-selected criteria
IF @VendorId IS NOT NULL
    SET @sql = @sql + N' AND VendorId = @VendorId'
IF @MinAmount IS NOT NULL
    SET @sql = @sql + N' AND TotalAmount >= @MinAmount'
IF @Department IS NOT NULL
    SET @sql = @sql + N' AND DepartmentCode = @Department'

EXEC sp_executesql @sql,
    N'@StartDate DATE, @VendorId INT, @MinAmount DECIMAL(18,2),
      @Department VARCHAR(10)',
    @StartDate, @VendorId, @MinAmount, @Department
```

**Extraction rule**: Every `EXEC(@sql)` and `sp_executesql` call must be traced.
The dynamic SQL construction encodes search/filter business rules that are
invisible to static analysis of the final SQL.

### Cursor Patterns

Cursors indicate row-by-row business processing:

```sql
-- RULE: Apply tiered discount based on customer lifetime value
DECLARE customer_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT CustomerId, LifetimeValue, CurrentDiscount
    FROM Customers
    WHERE IsActive = 1 AND Region = @Region

OPEN customer_cursor
FETCH NEXT FROM customer_cursor INTO @CustId, @LTV, @CurrentDiscount

WHILE @@FETCH_STATUS = 0
BEGIN
    -- RULE: Discount tiers based on lifetime value
    SET @NewDiscount = CASE
        WHEN @LTV >= 1000000 THEN 0.15   -- Platinum: 15%
        WHEN @LTV >= 500000  THEN 0.10   -- Gold: 10%
        WHEN @LTV >= 100000  THEN 0.05   -- Silver: 5%
        ELSE 0.02                         -- Standard: 2%
    END

    -- RULE: Never decrease an existing discount
    IF @NewDiscount > @CurrentDiscount
    BEGIN
        UPDATE Customers
        SET CurrentDiscount = @NewDiscount,
            DiscountEffectiveDate = GETDATE(),
            LastReviewDate = GETDATE()
        WHERE CustomerId = @CustId
    END

    FETCH NEXT FROM customer_cursor INTO @CustId, @LTV, @CurrentDiscount
END

CLOSE customer_cursor
DEALLOCATE customer_cursor
```

## Function Extraction

### Scalar Functions (Business Calculations)

```sql
-- RULE: Calculate late fee based on days overdue and contract terms
CREATE FUNCTION dbo.fn_CalculateLateFee(
    @InvoiceAmount  DECIMAL(18,2),
    @DueDate        DATE,
    @PaymentDate    DATE,
    @ContractType   VARCHAR(20)
) RETURNS DECIMAL(18,2)
AS
BEGIN
    DECLARE @DaysLate INT = DATEDIFF(DAY, @DueDate, @PaymentDate)

    IF @DaysLate <= 0
        RETURN 0.00

    -- RULE: Government contracts use statutory rate (Prompt Payment Act)
    IF @ContractType = 'GOVERNMENT'
        RETURN @InvoiceAmount * 0.0001 * @DaysLate  -- ~3.65% annual

    -- RULE: Commercial contracts use tiered penalty
    RETURN CASE
        WHEN @DaysLate <= 30  THEN @InvoiceAmount * 0.015  -- 1.5%
        WHEN @DaysLate <= 60  THEN @InvoiceAmount * 0.030  -- 3%
        WHEN @DaysLate <= 90  THEN @InvoiceAmount * 0.050  -- 5%
        ELSE @InvoiceAmount * 0.100                         -- 10% cap
    END
END
```

### Table-Valued Functions (Parameterized Views)

```sql
-- RULE: Return eligible approvers based on amount and department
CREATE FUNCTION dbo.fn_GetEligibleApprovers(
    @Amount      DECIMAL(18,2),
    @Department  VARCHAR(10)
) RETURNS TABLE
AS
RETURN
(
    SELECT
        e.EmployeeId,
        e.FullName,
        e.Title,
        a.ApprovalLimit,
        a.DelegateEmployeeId,
        -- RULE: Delegate can approve if within delegate limit and primary is OOO
        CASE
            WHEN d.OutOfOfficeEnd >= GETDATE()
                AND a.DelegateLimit >= @Amount
            THEN 1
            ELSE 0
        END AS DelegateActive
    FROM Employees e
    INNER JOIN ApprovalAuthority a ON e.EmployeeId = a.EmployeeId
    LEFT JOIN DelegationSchedule d ON e.EmployeeId = d.PrimaryEmployeeId
    WHERE a.ApprovalLimit >= @Amount
      AND a.DepartmentCode = @Department
      AND e.IsActive = 1
      AND a.EffectiveDate <= GETDATE()
      AND (a.ExpirationDate IS NULL OR a.ExpirationDate > GETDATE())
)
```

### CLR Functions

CLR (Common Language Runtime) functions execute .NET code inside SQL Server:

```sql
-- Detection: Check for CLR assemblies
SELECT
    a.name AS assembly_name,
    a.permission_set_desc,
    am.assembly_class,
    am.assembly_method,
    o.name AS sql_object_name,
    o.type_desc
FROM sys.assemblies a
JOIN sys.assembly_modules am ON a.assembly_id = am.assembly_id
JOIN sys.objects o ON am.object_id = o.object_id
WHERE a.is_user_defined = 1;
```

**Migration impact**: CLR functions contain .NET business logic that is invisible
to T-SQL analysis. The source assembly DLL must be decompiled or the original
source code obtained to extract the business rules.

## Trigger Business Rules

### AFTER Triggers

```sql
-- RULE: Audit trail with business-rule-driven severity
CREATE TRIGGER tr_Orders_AuditUpdate
    ON dbo.Orders
    AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON

    -- RULE: Log all status changes with severity classification
    INSERT INTO AuditLog (
        TableName, RecordId, FieldName,
        OldValue, NewValue, Severity, ChangedBy, ChangedDate
    )
    SELECT
        'Orders',
        i.OrderId,
        'Status',
        d.Status,
        i.Status,
        -- RULE: Severity based on status transition
        CASE
            WHEN d.Status = 'Approved' AND i.Status = 'Cancelled'
                THEN 'HIGH'       -- Cancelling approved order is high-severity
            WHEN d.Status = 'Shipped' AND i.Status <> 'Delivered'
                THEN 'HIGH'       -- Reversing shipment is high-severity
            WHEN i.Status = 'OnHold'
                THEN 'MEDIUM'     -- Holding any order is medium
            ELSE 'LOW'
        END,
        SYSTEM_USER,
        GETDATE()
    FROM inserted i
    INNER JOIN deleted d ON i.OrderId = d.OrderId
    WHERE i.Status <> d.Status

    -- RULE: Auto-notify manager on high-value order changes
    IF EXISTS (
        SELECT 1 FROM inserted i
        INNER JOIN deleted d ON i.OrderId = d.OrderId
        WHERE i.TotalAmount <> d.TotalAmount
          AND i.TotalAmount > 50000
    )
    BEGIN
        EXEC dbo.usp_SendNotification
            @Type = 'HIGH_VALUE_ORDER_CHANGE',
            @Details = 'Order amount changed for high-value order'
    END
END
```

### INSTEAD OF Triggers

```sql
-- RULE: Custom insert logic for views (common in legacy apps)
CREATE TRIGGER tr_vw_EmployeeInfo_Insert
    ON dbo.vw_EmployeeInfo
    INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON

    -- RULE: Auto-generate employee number
    DECLARE @NextEmpNum VARCHAR(10)
    SELECT @NextEmpNum = 'EMP' +
        RIGHT('000000' + CAST(NEXT VALUE FOR seq_EmployeeNumber AS VARCHAR), 6)

    -- RULE: Insert into multiple base tables from single view insert
    INSERT INTO Employees (EmployeeNumber, FirstName, LastName, HireDate)
    SELECT @NextEmpNum, i.FirstName, i.LastName, GETDATE()
    FROM inserted i

    INSERT INTO EmployeeDetails (EmployeeNumber, Department, Title, Salary)
    SELECT @NextEmpNum, i.Department, i.Title, i.Salary
    FROM inserted i

    -- RULE: Auto-create default benefit enrollment
    INSERT INTO BenefitEnrollments (EmployeeNumber, PlanCode, EnrollmentDate)
    SELECT @NextEmpNum, 'BASIC', GETDATE()
    FROM inserted i
END
```

### Cross-Table Cascade Logic

```sql
-- RULE: Cascade status change through order hierarchy
CREATE TRIGGER tr_Orders_CascadeCancel
    ON dbo.Orders
    AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON

    -- RULE: Cancelling a parent order cancels all child orders
    IF UPDATE(Status)
    BEGIN
        UPDATE ol
        SET ol.Status = 'Cancelled',
            ol.CancelledDate = GETDATE(),
            ol.CancelReason = 'Parent order cancelled'
        FROM OrderLines ol
        INNER JOIN inserted i ON ol.OrderId = i.OrderId
        INNER JOIN deleted d ON i.OrderId = d.OrderId
        WHERE i.Status = 'Cancelled'
          AND d.Status <> 'Cancelled'
          AND ol.Status NOT IN ('Shipped', 'Delivered')

        -- RULE: Release reserved inventory for cancelled lines
        UPDATE inv
        SET inv.ReservedQty = inv.ReservedQty - ol.Quantity
        FROM Inventory inv
        INNER JOIN OrderLines ol ON inv.ProductId = ol.ProductId
        INNER JOIN inserted i ON ol.OrderId = i.OrderId
        INNER JOIN deleted d ON i.OrderId = d.OrderId
        WHERE i.Status = 'Cancelled'
          AND d.Status <> 'Cancelled'
          AND ol.Status NOT IN ('Shipped', 'Delivered')
    END
END
```

## View Business Logic

### Computed Columns in Views

```sql
-- RULE: Business status derived from multiple conditions
CREATE VIEW dbo.vw_OrderStatus AS
SELECT
    o.OrderId,
    o.CustomerName,
    o.OrderDate,
    o.TotalAmount,
    -- RULE: Derived status based on business conditions
    CASE
        WHEN o.CancelledDate IS NOT NULL THEN 'Cancelled'
        WHEN o.ShipDate IS NOT NULL AND o.DeliveryDate IS NOT NULL THEN 'Delivered'
        WHEN o.ShipDate IS NOT NULL THEN 'In Transit'
        WHEN o.ApprovalDate IS NOT NULL AND p.PaymentDate IS NOT NULL THEN 'Paid'
        WHEN o.ApprovalDate IS NOT NULL THEN 'Approved'
        WHEN DATEDIFF(DAY, o.OrderDate, GETDATE()) > 30 THEN 'Stale'
        ELSE 'Pending'
    END AS DerivedStatus,
    -- RULE: Risk score based on customer history and amount
    CASE
        WHEN c.CreditRating < 3 AND o.TotalAmount > 10000 THEN 'HIGH'
        WHEN c.CreditRating < 5 OR o.TotalAmount > 50000 THEN 'MEDIUM'
        ELSE 'LOW'
    END AS RiskLevel,
    -- RULE: Aging bucket calculation
    DATEDIFF(DAY, o.OrderDate, GETDATE()) AS DaysOpen,
    CASE
        WHEN DATEDIFF(DAY, o.DueDate, GETDATE()) <= 0 THEN 'Current'
        WHEN DATEDIFF(DAY, o.DueDate, GETDATE()) <= 30 THEN '1-30 Past Due'
        WHEN DATEDIFF(DAY, o.DueDate, GETDATE()) <= 60 THEN '31-60 Past Due'
        WHEN DATEDIFF(DAY, o.DueDate, GETDATE()) <= 90 THEN '61-90 Past Due'
        ELSE '90+ Past Due'
    END AS AgingBucket
FROM Orders o
LEFT JOIN Payments p ON o.OrderId = p.OrderId
LEFT JOIN Customers c ON o.CustomerId = c.CustomerId
```

### Complex JOINs Encoding Business Relationships

```sql
-- RULE: Active employee with current assignment
-- (encodes the business concept of "effective-dated" records)
CREATE VIEW dbo.vw_CurrentEmployees AS
SELECT
    e.EmployeeId,
    e.FullName,
    a.DepartmentCode,
    a.PositionTitle,
    a.Salary
FROM Employees e
INNER JOIN Assignments a ON e.EmployeeId = a.EmployeeId
    AND GETDATE() BETWEEN a.EffectiveStartDate
                       AND ISNULL(a.EffectiveEndDate, '9999-12-31')
    AND a.AssignmentType = 'PRIMARY'           -- RULE: Only primary assignment
WHERE e.TerminationDate IS NULL                -- RULE: Not terminated
  AND e.HireDate <= GETDATE()                  -- RULE: Already started
```

## Cross-Database and Linked Server Patterns

### Three-Part Naming (Cross-Database)

```sql
-- RULE: Validation against reference data in separate database
SELECT o.OrderId, o.VendorId
FROM OrderDB.dbo.Orders o
INNER JOIN MasterDB.dbo.Vendors v ON o.VendorId = v.VendorId
WHERE v.IsActive = 1
  AND v.CertificationDate > DATEADD(YEAR, -1, GETDATE())  -- cert within 1 year
```

**Extraction impact**: Three-part naming creates cross-database dependencies
that must be resolved during migration. Document every cross-database reference.

### Four-Part Naming (Linked Servers)

```sql
-- RULE: Sync data from remote HR system
INSERT INTO LocalDB.dbo.EmployeeCache
SELECT
    EmployeeId, FirstName, LastName, Department
FROM [HRSERVER].[HRDatabase].[dbo].[Employees]
WHERE LastModifiedDate > @LastSyncDate
```

### OPENQUERY / OPENROWSET

```sql
-- Remote query execution (often used for non-SQL Server sources)
SELECT * FROM OPENQUERY(
    [ORACLE_LINK],
    'SELECT employee_id, employee_name FROM hr.employees WHERE status = ''A'''
)

-- Ad hoc remote data access
SELECT * FROM OPENROWSET(
    'SQLNCLI',
    'Server=RemoteServer;Database=RemoteDB;Trusted_Connection=yes;',
    'SELECT * FROM dbo.SharedConfig'
)
```

## Transaction Patterns

### Explicit Transaction Management

```sql
-- RULE: Multi-table update with all-or-nothing semantics
BEGIN TRY
    BEGIN TRANSACTION

    -- RULE: Update order status
    UPDATE Orders
    SET Status = 'Shipped', ShipDate = GETDATE()
    WHERE OrderId = @OrderId

    -- RULE: Deduct inventory
    UPDATE Inventory
    SET QuantityOnHand = QuantityOnHand - @Quantity
    WHERE ProductId = @ProductId

    -- RULE: Prevent negative inventory
    IF EXISTS (SELECT 1 FROM Inventory
               WHERE ProductId = @ProductId AND QuantityOnHand < 0)
    BEGIN
        RAISERROR('Insufficient inventory for product %d', 16, 1, @ProductId)
        -- This jumps to CATCH, which rolls back
    END

    -- RULE: Create shipment record
    INSERT INTO Shipments (OrderId, ShipDate, Carrier, TrackingNumber)
    VALUES (@OrderId, GETDATE(), @Carrier, @TrackingNumber)

    COMMIT TRANSACTION
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION

    -- RULE: Log error details for troubleshooting
    INSERT INTO ErrorLog (
        ErrorNumber, ErrorSeverity, ErrorState,
        ErrorProcedure, ErrorLine, ErrorMessage, ErrorDate
    )
    VALUES (
        ERROR_NUMBER(), ERROR_SEVERITY(), ERROR_STATE(),
        ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), GETDATE()
    )

    -- Re-raise to caller
    THROW
END CATCH
```

### Savepoint Patterns

```sql
-- RULE: Partial rollback for non-critical failures
BEGIN TRANSACTION

-- Critical: Must succeed
UPDATE Accounts SET Balance = Balance - @Amount WHERE AccountId = @FromAccount
UPDATE Accounts SET Balance = Balance + @Amount WHERE AccountId = @ToAccount

SAVE TRANSACTION NotificationPoint

-- Non-critical: Failure should not roll back the transfer
BEGIN TRY
    EXEC dbo.usp_SendTransferNotification @FromAccount, @ToAccount, @Amount
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION NotificationPoint
    -- Log but continue — notification failure is not fatal
    INSERT INTO NotificationFailures (TransactionDate, Details)
    VALUES (GETDATE(), ERROR_MESSAGE())
END CATCH

COMMIT TRANSACTION
```

### Isolation Level Patterns

```sql
-- RULE: Read committed snapshot for high-concurrency reads
SET TRANSACTION ISOLATION LEVEL READ COMMITTED
-- (database must have READ_COMMITTED_SNAPSHOT ON)

-- RULE: Serializable for financial calculations (prevent phantom reads)
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
BEGIN TRANSACTION
    SELECT @Balance = Balance FROM Accounts WHERE AccountId = @AccountId
    -- No other transaction can modify this row until we commit
    UPDATE Accounts SET Balance = @Balance - @Amount WHERE AccountId = @AccountId
COMMIT TRANSACTION

-- RULE: NOLOCK hint (dirty reads) for reporting queries
-- WARNING: This is a common pattern but can return inconsistent data
SELECT OrderId, Status, TotalAmount
FROM Orders WITH (NOLOCK)
WHERE OrderDate >= @StartDate
```

## Error Handling

### TRY/CATCH with Severity Levels

```sql
-- Error severity determines behavior:
-- 0-10: Informational (no error)
-- 11-16: User errors (application logic)
-- 17-19: Resource errors (disk, memory)
-- 20-25: Fatal errors (connection terminated)

-- RULE: Custom error handling with severity-based routing
BEGIN TRY
    EXEC dbo.usp_ProcessBatch @BatchId
END TRY
BEGIN CATCH
    DECLARE @Severity INT = ERROR_SEVERITY()

    IF @Severity >= 17
    BEGIN
        -- RULE: Resource errors trigger admin alert
        EXEC msdb.dbo.sp_send_dbmail
            @profile_name = 'DBA_Alerts',
            @recipients = 'dba-team@company.com',
            @subject = 'Critical Database Error',
            @body = ERROR_MESSAGE()
    END

    IF @Severity BETWEEN 11 AND 16
    BEGIN
        -- RULE: Application errors logged for review
        INSERT INTO ProcessingErrors (BatchId, ErrorMessage, ErrorDate)
        VALUES (@BatchId, ERROR_MESSAGE(), GETDATE())
    END

    -- RULE: XACT_ABORT behavior — if ON, any error auto-rolls back
    -- Check: SET XACT_ABORT ON at the top of the procedure
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION
END CATCH
```

### RAISERROR vs THROW

```sql
-- Legacy pattern: RAISERROR with format string
RAISERROR('Invoice %d has invalid amount: %s', 16, 1,
    @InvoiceId, @AmountStr)

-- Modern pattern: THROW (SQL Server 2012+)
-- Re-raises the current error in CATCH blocks
THROW

-- THROW with custom error
THROW 50001, 'Custom business rule violation', 1
```

## SQL Server Specific Syntax Reference

For migration to PostgreSQL, these SQL Server patterns need translation:

| SQL Server Pattern | PostgreSQL Equivalent | Notes |
|--------------------|----------------------|-------|
| `SELECT TOP N` | `SELECT ... LIMIT N` | PostgreSQL LIMIT goes at end |
| `IDENTITY(1,1)` | `SERIAL` / `GENERATED ALWAYS AS IDENTITY` | PG has both options |
| `OUTPUT inserted.*` | `RETURNING *` | On INSERT/UPDATE/DELETE |
| `MERGE ... WHEN MATCHED` | `INSERT ... ON CONFLICT DO UPDATE` | PG upsert syntax |
| `CROSS APPLY` | `LATERAL JOIN` | Correlated subquery in FROM |
| `OUTER APPLY` | `LEFT JOIN LATERAL ... ON TRUE` | Nullable lateral join |
| `GETDATE()` | `NOW()` or `CURRENT_TIMESTAMP` | Current datetime |
| `GETUTCDATE()` | `NOW() AT TIME ZONE 'UTC'` | UTC datetime |
| `ISNULL(a, b)` | `COALESCE(a, b)` | Null replacement |
| `NEWID()` | `gen_random_uuid()` | UUID generation |
| `LEN(str)` | `LENGTH(str)` | String length |
| `CHARINDEX(sub, str)` | `POSITION(sub IN str)` | Substring search |
| `DATEADD(unit, n, date)` | `date + INTERVAL 'n unit'` | Date arithmetic |
| `DATEDIFF(unit, d1, d2)` | `DATE_PART('unit', d2 - d1)` or `EXTRACT` | Date difference |
| `CONVERT(type, val, style)` | `CAST(val AS type)` or `TO_CHAR` | Type conversion |
| `STRING_AGG(col, ',')` | `STRING_AGG(col, ',')` | Same in PG 9.0+ |
| `FORMAT(date, 'yyyy-MM-dd')` | `TO_CHAR(date, 'YYYY-MM-DD')` | Date formatting |
| `TRY_CAST(val AS INT)` | Custom function or EXCEPTION block | No direct PG equivalent |
| `IIF(cond, true, false)` | `CASE WHEN cond THEN true ELSE false END` | Ternary expression |

## Temporal Tables

```sql
-- System-versioned temporal tables (SQL Server 2016+)
-- Detect by checking for PERIOD FOR SYSTEM_TIME
SELECT
    t.name AS table_name,
    t.temporal_type_desc,
    h.name AS history_table_name,
    c1.name AS period_start_column,
    c2.name AS period_end_column
FROM sys.tables t
LEFT JOIN sys.tables h ON t.history_table_id = h.object_id
LEFT JOIN sys.periods p ON t.object_id = p.object_id
LEFT JOIN sys.columns c1 ON p.object_id = c1.object_id
    AND p.start_column_id = c1.column_id
LEFT JOIN sys.columns c2 ON p.object_id = c2.object_id
    AND p.end_column_id = c2.column_id
WHERE t.temporal_type <> 0;

-- Query historical data:
-- RULE: Show employee salary as of a specific date
SELECT * FROM Employees
FOR SYSTEM_TIME AS OF '2025-01-01'
WHERE EmployeeId = @EmpId
```

**Migration impact**: Temporal tables must be redesigned as custom history tables
in PostgreSQL (no native temporal table support, though PG 17+ has proposals).

## JSON and XML Handling

### JSON Patterns (SQL Server 2016+)

```sql
-- RULE: Parse JSON configuration stored in NVARCHAR column
SELECT
    JSON_VALUE(ConfigData, '$.maxRetries') AS MaxRetries,
    JSON_VALUE(ConfigData, '$.timeout') AS Timeout,
    JSON_QUERY(ConfigData, '$.endpoints') AS Endpoints
FROM SystemConfig
WHERE ConfigKey = 'API_SETTINGS'

-- FOR JSON output
SELECT OrderId, CustomerName, TotalAmount
FROM Orders
WHERE Status = 'Active'
FOR JSON PATH, ROOT('orders')

-- OPENJSON for JSON arrays
SELECT j.*
FROM Orders o
CROSS APPLY OPENJSON(o.LineItemsJson)
WITH (
    ProductId INT '$.productId',
    Quantity INT '$.qty',
    UnitPrice DECIMAL(18,2) '$.price'
) j
```

### XML Patterns

```sql
-- FOR XML output (common in older integrations)
SELECT OrderId, CustomerName
FROM Orders
FOR XML PATH('order'), ROOT('orders'), ELEMENTS

-- XML parsing with nodes()
SELECT
    t.c.value('@id', 'INT') AS ItemId,
    t.c.value('name[1]', 'VARCHAR(100)') AS ItemName,
    t.c.value('price[1]', 'DECIMAL(18,2)') AS Price
FROM @XmlData.nodes('/items/item') AS t(c)
```

## Extraction Priority Checklist

1. **Stored procedures** — primary business rule containers (check `sys.procedures`)
2. **Functions** — scalar and table-valued calculations (check `sys.objects WHERE type IN ('FN','IF','TF')`)
3. **Triggers** — enforcement rules and cascade logic (check `sys.triggers`)
4. **Views with CASE expressions** — derived status/classification rules
5. **Dynamic SQL** — trace EXEC and sp_executesql for hidden logic
6. **Cross-database references** — dependency mapping (3-part and 4-part naming)
7. **CLR assemblies** — .NET code embedded in database (check `sys.assemblies`)
8. **Temporal table queries** — historical data access patterns
9. **JSON/XML handling** — data transformation rules
10. **Transaction isolation** — concurrency rules and consistency requirements
