# Oracle EBS Business Rule Extraction Patterns

## Purpose

Reference for the Extraction skill when performing business rule extraction from
Oracle EBS customizations. EBS business rules hide in PL/SQL packages, workflow
definitions, flexfield validations, concurrent program logic, forms personalizations,
and interface processing routines. This guide maps every extraction point.

## Custom PL/SQL Package Extraction

### Package Structure Analysis

Custom EBS packages (XX_*_PKG) typically follow this structure:

```sql
-- Package specification (public interface)
CREATE OR REPLACE PACKAGE xx_po_validation_pkg AS
    -- Constants encoding business rules
    c_max_po_amount     CONSTANT NUMBER := 1000000;
    c_approval_threshold CONSTANT NUMBER := 50000;

    -- Record types for structured data
    TYPE t_validation_result IS RECORD (
        is_valid    BOOLEAN,
        error_code  VARCHAR2(30),
        error_msg   VARCHAR2(2000)
    );

    -- Public procedures (entry points for business rules)
    PROCEDURE validate_po_header(
        p_po_header_id  IN  NUMBER,
        p_org_id        IN  NUMBER,
        x_result        OUT t_validation_result
    );

    PROCEDURE validate_po_line(
        p_po_line_id    IN  NUMBER,
        x_result        OUT t_validation_result
    );

    -- Table-type for bulk validation
    TYPE t_validation_results IS TABLE OF t_validation_result;
END xx_po_validation_pkg;
```

### Business Rule Extraction from Package Bodies

Look for these patterns in package body code:

**Threshold-based rules**:
```sql
-- RULE: POs over $50K require director approval
IF l_po_total > c_approval_threshold THEN
    l_approver_level := 'DIRECTOR';
ELSIF l_po_total > 10000 THEN
    l_approver_level := 'MANAGER';
ELSE
    l_approver_level := 'SUPERVISOR';
END IF;
```

**Date-based rules**:
```sql
-- RULE: Fiscal year cutoff — POs after Sept 15 go to next FY
IF l_po_date > TO_DATE(TO_CHAR(l_po_date, 'YYYY') || '0915', 'YYYYMMDD') THEN
    l_fiscal_year := TO_NUMBER(TO_CHAR(l_po_date, 'YYYY')) + 1;
ELSE
    l_fiscal_year := TO_NUMBER(TO_CHAR(l_po_date, 'YYYY'));
END IF;
```

**Profile-driven rules**:
```sql
-- RULE: Behavior varies by profile option
l_auto_approve := NVL(fnd_profile.value('XX_AUTO_APPROVE_ENABLED'), 'N');
IF l_auto_approve = 'Y' AND l_po_total <= l_auto_approve_limit THEN
    auto_approve_po(p_po_header_id);
END IF;
```

**Organization-dependent rules**:
```sql
-- RULE: Different validation rules per operating unit
l_org_id := fnd_global.org_id;
IF l_org_id = 101 THEN  -- Headquarters
    validate_hq_rules(p_po_header_id, x_result);
ELSIF l_org_id IN (201, 202, 203) THEN  -- Regional offices
    validate_regional_rules(p_po_header_id, x_result);
ELSE
    validate_default_rules(p_po_header_id, x_result);
END IF;
```

### Trigger Logic Extraction

Custom triggers on EBS base tables contain enforcement rules:

```sql
-- Before-insert trigger with business rules
CREATE OR REPLACE TRIGGER xx_po_headers_bri
    BEFORE INSERT ON po_headers_all
    FOR EACH ROW
WHEN (NEW.attribute_category = 'XX_CUSTOM')
DECLARE
    l_valid BOOLEAN;
BEGIN
    -- RULE: Custom PO type requires project code in DFF
    IF :NEW.attribute_category = 'XX_CUSTOM' AND :NEW.attribute1 IS NULL THEN
        fnd_message.set_name('XXCUST', 'XX_PROJECT_CODE_REQUIRED');
        app_exception.raise_exception;
    END IF;

    -- RULE: Auto-populate audit columns
    :NEW.attribute15 := fnd_global.user_name;
    :NEW.attribute14 := TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS');

    -- RULE: Enforce naming convention for custom PO types
    IF :NEW.type_lookup_code = 'XX_EMERGENCY' THEN
        :NEW.segment1 := 'EM-' || xx_po_seq.NEXTVAL;
    END IF;
END;
```

### Concurrent Program Logic Extraction

Concurrent programs contain batch processing rules:

```sql
-- Typical concurrent program structure
PROCEDURE xx_invoice_import(
    errbuf    OUT VARCHAR2,
    retcode   OUT VARCHAR2,
    p_org_id  IN  NUMBER,
    p_batch_name IN VARCHAR2
) IS
    -- RULE: Processing cursor defines scope of work
    CURSOR c_invoices IS
        SELECT *
        FROM xx_invoice_staging
        WHERE org_id = p_org_id
          AND batch_name = p_batch_name
          AND process_flag = 'N'   -- unprocessed only
          AND error_flag = 'N'     -- no prior errors
        ORDER BY invoice_date, vendor_id;

    l_success_count NUMBER := 0;
    l_error_count   NUMBER := 0;
BEGIN
    fnd_file.put_line(fnd_file.log, 'Starting invoice import...');

    FOR r_inv IN c_invoices LOOP
        BEGIN
            -- RULE: Validate vendor is active
            IF NOT is_vendor_active(r_inv.vendor_id) THEN
                mark_error(r_inv.rowid, 'INACTIVE_VENDOR');
                l_error_count := l_error_count + 1;
                CONTINUE;
            END IF;

            -- RULE: Validate amount within tolerance
            IF ABS(r_inv.invoice_amount - r_inv.po_amount) >
               r_inv.po_amount * 0.10 THEN
                mark_error(r_inv.rowid, 'AMOUNT_TOLERANCE_EXCEEDED');
                l_error_count := l_error_count + 1;
                CONTINUE;
            END IF;

            -- RULE: Create invoice via standard API (not direct DML)
            ap_invoices_pkg.insert_row(
                x_invoice_id      => l_invoice_id,
                p_vendor_id       => r_inv.vendor_id,
                p_invoice_amount  => r_inv.invoice_amount,
                p_invoice_date    => r_inv.invoice_date,
                p_org_id          => p_org_id
            );

            -- RULE: Mark staging record as processed
            UPDATE xx_invoice_staging
            SET process_flag = 'Y',
                process_date = SYSDATE,
                invoice_id = l_invoice_id
            WHERE ROWID = r_inv.rowid;

            l_success_count := l_success_count + 1;

            -- RULE: Commit every 500 records for large batches
            IF MOD(l_success_count, 500) = 0 THEN
                COMMIT;
            END IF;

        EXCEPTION
            WHEN OTHERS THEN
                mark_error(r_inv.rowid, SQLERRM);
                l_error_count := l_error_count + 1;
        END;
    END LOOP;

    COMMIT;

    -- RULE: Return status based on error count
    IF l_error_count = 0 THEN
        retcode := '0';  -- Success
    ELSIF l_success_count > 0 THEN
        retcode := '1';  -- Warning (partial success)
    ELSE
        retcode := '2';  -- Error (complete failure)
    END IF;

    errbuf := 'Processed: ' || l_success_count ||
              ', Errors: ' || l_error_count;
END;
```

**Extraction checklist for concurrent programs**:
- Cursor WHERE clauses define the processing scope (eligibility rules)
- Validation blocks before API calls define data quality rules
- Error handling blocks define failure modes and retry logic
- Commit frequency defines batch processing characteristics
- Return code logic defines success/failure criteria
- FND_FILE.PUT_LINE calls document expected outputs

## Workflow Business Rules

### Approval Hierarchy Extraction

EBS approval workflows encode authorization rules:

```sql
-- Workflow function implementing approval routing
PROCEDURE get_next_approver(
    itemtype  IN  VARCHAR2,
    itemkey   IN  VARCHAR2,
    actid     IN  NUMBER,
    funcmode  IN  VARCHAR2,
    resultout OUT VARCHAR2
) IS
    l_amount NUMBER;
    l_current_approver NUMBER;
    l_supervisor_id NUMBER;
    l_approval_limit NUMBER;
BEGIN
    IF funcmode = 'RUN' THEN
        l_amount := wf_engine.GetItemAttrNumber(itemtype, itemkey, 'TOTAL_AMOUNT');
        l_current_approver := wf_engine.GetItemAttrNumber(itemtype, itemkey,
            'CURRENT_APPROVER_ID');

        -- RULE: Find supervisor with sufficient authority
        SELECT supervisor_id, approval_limit
        INTO l_supervisor_id, l_approval_limit
        FROM xx_approval_hierarchy
        WHERE employee_id = l_current_approver
          AND SYSDATE BETWEEN effective_start_date AND effective_end_date;

        IF l_approval_limit >= l_amount THEN
            -- RULE: Supervisor has authority — route for approval
            wf_engine.SetItemAttrNumber(itemtype, itemkey,
                'APPROVER_ID', l_supervisor_id);
            resultout := 'COMPLETE:APPROVED';
        ELSE
            -- RULE: Supervisor lacks authority — escalate up
            wf_engine.SetItemAttrNumber(itemtype, itemkey,
                'CURRENT_APPROVER_ID', l_supervisor_id);
            resultout := 'COMPLETE:ESCALATE';
        END IF;
    END IF;
END;
```

### Routing Logic Extraction

```sql
-- Workflow routing function with business rules
PROCEDURE determine_route(
    itemtype IN VARCHAR2, itemkey IN VARCHAR2,
    actid IN NUMBER, funcmode IN VARCHAR2,
    resultout OUT VARCHAR2
) IS
    l_po_type    VARCHAR2(30);
    l_urgency    VARCHAR2(30);
    l_org_id     NUMBER;
BEGIN
    IF funcmode = 'RUN' THEN
        l_po_type := wf_engine.GetItemAttrText(itemtype, itemkey, 'PO_TYPE');
        l_urgency := wf_engine.GetItemAttrText(itemtype, itemkey, 'URGENCY');
        l_org_id  := wf_engine.GetItemAttrNumber(itemtype, itemkey, 'ORG_ID');

        -- RULE: Emergency POs skip standard approval chain
        IF l_po_type = 'EMERGENCY' THEN
            resultout := 'COMPLETE:EMERGENCY_ROUTE';

        -- RULE: HQ contracts go through legal review
        ELSIF l_po_type = 'CONTRACT' AND l_org_id = 101 THEN
            resultout := 'COMPLETE:LEGAL_REVIEW';

        -- RULE: High-urgency items use expedited routing
        ELSIF l_urgency = 'HIGH' THEN
            resultout := 'COMPLETE:EXPEDITED';

        ELSE
            resultout := 'COMPLETE:STANDARD';
        END IF;
    END IF;
END;
```

### Notification Template Extraction

Workflow notifications contain message templates with token substitution:

```sql
-- Notification message attributes define the content template
-- Extract from WF_MESSAGES and WF_MESSAGE_ATTRIBUTES

SELECT
    wm.type AS item_type,
    wm.name AS message_name,
    wm.display_name,
    wm.subject,
    wm.body,
    wm.html_body,
    wma.name AS attribute_name,
    wma.display_name AS attribute_display_name,
    wma.type AS attribute_type
FROM wf_messages wm
LEFT JOIN wf_message_attributes wma
    ON wm.type = wma.message_type
    AND wm.name = wma.message_name
WHERE wm.type LIKE 'XX%'
ORDER BY wm.type, wm.name;

-- Token format in notification body:
-- &ATTRIBUTE_NAME references workflow item attributes
-- Example body: "PO &PO_NUMBER for &VENDOR_NAME requires your approval.
--                Amount: &TOTAL_AMOUNT. Due date: &NEED_BY_DATE."
```

## Flexfield Validation Rule Extraction

### Value Set Validation Rules

```sql
-- Independent value set values (static lookup)
SELECT
    fvs.flex_value_set_name,
    fv.flex_value,
    fvt.flex_value_meaning,
    fvt.description,
    fv.enabled_flag,
    fv.start_date_active,
    fv.end_date_active,
    fv.summary_flag
FROM fnd_flex_values fv
JOIN fnd_flex_value_sets fvs ON fv.flex_value_set_id = fvs.flex_value_set_id
JOIN fnd_flex_values_tl fvt ON fv.flex_value_id = fvt.flex_value_id
    AND fvt.language = 'US'
WHERE fvs.flex_value_set_name LIKE 'XX%'
AND fv.enabled_flag = 'Y'
ORDER BY fvs.flex_value_set_name, fv.flex_value;
```

### Table-Validated Value Set Business Rules

Table-validated value sets contain SQL WHERE clauses that encode business rules:

```sql
-- RULE embedded in table-validated value set
-- Value set: XX_ACTIVE_VENDORS
-- Table: PO_VENDORS
-- WHERE clause:
--   end_date_active IS NULL
--   AND vendor_type_lookup_code IN ('APPROVED', 'PREFERRED')
--   AND NVL(hold_flag, 'N') = 'N'
--   AND enabled_flag = 'Y'

-- This encodes the business rule: "Only show vendors that are active,
-- approved or preferred, not on hold, and enabled."
```

### Cross-Validation Rules

Cross-validation rules restrict valid combinations of flexfield segments:

```sql
-- Extract cross-validation rules as business rules
-- Example: "Cost center 4100 can only be combined with account 6000-6999"
--
-- RULE: Only R&D expense accounts (6000-6999) can be charged to
--       the Research cost center (4100)
-- Implementation: GL cross-validation rule
-- Include: Company=01, CostCenter=4100, Account=6000-6999
-- Exclude: Company=01, CostCenter=4100, Account=*  (all others)
```

### Segment Qualifier Rules

```sql
-- Segment qualifiers define segment-level behavior
SELECT
    fifs.id_flex_structure_name,
    fifsg.segment_name,
    fifsg.application_column_name,
    fifsq.segment_attribute_type,
    fifsq.value_attribute_type
FROM fnd_id_flex_segments fifsg
JOIN fnd_id_flex_structures_vl fifs
    ON fifsg.application_id = fifs.application_id
    AND fifsg.id_flex_code = fifs.id_flex_code
    AND fifsg.id_flex_num = fifs.id_flex_num
JOIN fnd_segment_attribute_values fifsq
    ON fifsg.application_id = fifsq.application_id
    AND fifsg.id_flex_code = fifsq.id_flex_code
    AND fifsg.id_flex_num = fifsq.id_flex_num
    AND fifsg.application_column_name = fifsq.application_column_name
WHERE fifs.id_flex_code = 'GL#'
AND fifsq.attribute_value = 'Y'
ORDER BY fifsg.segment_num;
```

## Interface Business Rule Extraction

### Mapping Logic

Interface programs contain field-level mapping rules:

```sql
-- RULE: Map external vendor codes to EBS vendor_id
FUNCTION get_ebs_vendor_id(
    p_external_code IN VARCHAR2
) RETURN NUMBER IS
    l_vendor_id NUMBER;
BEGIN
    -- RULE: First try direct lookup in cross-reference table
    SELECT vendor_id INTO l_vendor_id
    FROM xx_vendor_xref
    WHERE external_vendor_code = p_external_code
      AND NVL(end_date, SYSDATE + 1) > SYSDATE;

    RETURN l_vendor_id;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        -- RULE: Fall back to matching on tax ID (EIN)
        SELECT vendor_id INTO l_vendor_id
        FROM ap_suppliers
        WHERE num_1099 = p_external_code
          AND enabled_flag = 'Y'
          AND ROWNUM = 1;

        RETURN l_vendor_id;
    WHEN OTHERS THEN
        RETURN NULL;  -- RULE: Unmapped vendors flagged for manual review
END;
```

### Transformation Rules

```sql
-- RULE: Transform external date formats to EBS dates
FUNCTION parse_external_date(
    p_date_string IN VARCHAR2,
    p_source_format IN VARCHAR2 DEFAULT 'MM/DD/YYYY'
) RETURN DATE IS
BEGIN
    RETURN TO_DATE(p_date_string, p_source_format);
EXCEPTION
    WHEN OTHERS THEN
        -- RULE: Invalid dates default to current date with error flag
        log_error('Invalid date: ' || p_date_string);
        RETURN SYSDATE;
END;

-- RULE: Transform amounts from external currency to functional currency
FUNCTION convert_to_functional(
    p_amount        IN NUMBER,
    p_from_currency IN VARCHAR2,
    p_conversion_date IN DATE
) RETURN NUMBER IS
    l_rate NUMBER;
BEGIN
    -- RULE: Use EBS standard rate table (GL_DAILY_RATES)
    SELECT conversion_rate INTO l_rate
    FROM gl_daily_rates
    WHERE from_currency = p_from_currency
      AND to_currency = fnd_profile.value('GL_SET_OF_BKS_ID_CURRENCY')
      AND conversion_date = TRUNC(p_conversion_date)
      AND conversion_type = fnd_profile.value('XX_DEFAULT_CONV_TYPE');

    RETURN p_amount * l_rate;
END;
```

### Error Handling and Retry Logic

```sql
-- Interface error handling rules
PROCEDURE process_interface_errors(
    p_batch_id IN NUMBER
) IS
    CURSOR c_errors IS
        SELECT *
        FROM xx_interface_errors
        WHERE batch_id = p_batch_id
          AND process_flag = 'E';
BEGIN
    FOR r IN c_errors LOOP
        -- RULE: Auto-retry transient errors up to 3 times
        IF r.error_code IN ('TIMEOUT', 'LOCK_WAIT', 'DEADLOCK')
           AND r.retry_count < 3 THEN
            UPDATE xx_interface_staging
            SET process_flag = 'N',  -- requeue for processing
                retry_count = retry_count + 1
            WHERE interface_id = r.interface_id;

        -- RULE: Validation errors require manual correction
        ELSIF r.error_code IN ('INVALID_VENDOR', 'INVALID_ACCOUNT',
                                'AMOUNT_MISMATCH') THEN
            send_notification(
                p_user       => r.created_by,
                p_subject    => 'Interface Error Requires Correction',
                p_body       => r.error_message,
                p_error_code => r.error_code
            );

        -- RULE: Fatal errors stop the batch
        ELSIF r.error_code IN ('INVALID_BATCH', 'DUPLICATE_BATCH') THEN
            UPDATE xx_interface_batches
            SET status = 'FAILED'
            WHERE batch_id = p_batch_id;
            RETURN;
        END IF;
    END LOOP;
END;
```

## Concurrent Program Scheduling Rules

### Dependency Extraction

```sql
-- Concurrent program incompatibilities (cannot run simultaneously)
SELECT
    fcp1.concurrent_program_name AS program_name,
    fcp2.concurrent_program_name AS incompatible_with,
    fci.to_run_type,
    DECODE(fci.to_run_type,
        'D', 'Domain (same parameters)',
        'G', 'Global (any parameters)',
        fci.to_run_type
    ) AS incompatibility_type
FROM fnd_concurrent_program_serial fci
JOIN fnd_concurrent_programs fcp1
    ON fci.running_application_id = fcp1.application_id
    AND fci.running_concurrent_program_id = fcp1.concurrent_program_id
JOIN fnd_concurrent_programs fcp2
    ON fci.to_run_application_id = fcp2.application_id
    AND fci.to_run_concurrent_program_id = fcp2.concurrent_program_id
WHERE fcp1.concurrent_program_name LIKE 'XX%'
   OR fcp2.concurrent_program_name LIKE 'XX%'
ORDER BY fcp1.concurrent_program_name;
```

### Schedule Pattern Extraction

```sql
-- Request sets (grouped program execution)
SELECT
    frs.request_set_name,
    frst.user_request_set_name,
    frss.stage_name,
    frss.display_sequence,
    frssp.concurrent_program_name,
    frss.critical,
    frss.incompatibilities_allowed
FROM fnd_request_sets frs
JOIN fnd_request_sets_tl frst
    ON frs.request_set_id = frst.request_set_id
    AND frst.language = 'US'
JOIN fnd_request_set_stages frss
    ON frs.request_set_id = frss.set_application_id
JOIN fnd_request_set_programs frssp
    ON frss.request_set_id = frssp.request_set_id
    AND frss.set_application_id = frssp.set_application_id
    AND frss.request_set_stage_id = frssp.request_set_stage_id
WHERE frs.request_set_name LIKE 'XX%'
ORDER BY frs.request_set_name, frss.display_sequence;
```

### Parameter Default Rules

```sql
-- Concurrent program parameters with defaults
SELECT
    fcp.concurrent_program_name,
    fdp.column_seq_num,
    fdp.end_user_column_name AS parameter_name,
    fdp.required,
    fdp.default_type,
    DECODE(fdp.default_type,
        'C', 'Constant: ' || fdp.default_value,
        'S', 'SQL: ' || fdp.default_value,
        'P', 'Profile: ' || fdp.default_value,
        'E', 'Environment: ' || fdp.default_value,
        fdp.default_value
    ) AS default_description,
    fvs.flex_value_set_name,
    fvs.validation_type
FROM fnd_concurrent_programs fcp
JOIN fnd_descr_flex_column_usages fdp
    ON fcp.concurrent_program_name = fdp.descriptive_flexfield_name
LEFT JOIN fnd_flex_value_sets fvs
    ON fdp.flex_value_set_id = fvs.flex_value_set_id
WHERE fcp.concurrent_program_name LIKE 'XX%'
ORDER BY fcp.concurrent_program_name, fdp.column_seq_num;
```

## Report Business Rule Extraction

### Selection Criteria Rules

```sql
-- Report queries often encode business rules in WHERE clauses:

-- RULE: Only show invoices eligible for payment
-- (encodes payment eligibility logic)
SELECT i.invoice_num, i.invoice_amount, i.invoice_date
FROM ap_invoices_all i
WHERE i.org_id = :p_org_id
  AND i.payment_status_flag = 'N'           -- not yet paid
  AND i.approval_status = 'APPROVED'         -- approved
  AND i.cancelled_flag = 'N'                 -- not cancelled
  AND NVL(i.hold_all_payments_flag, 'N') = 'N'  -- not on hold
  AND i.invoice_date <= :p_cutoff_date       -- within payment period
  AND EXISTS (                                -- has at least one valid line
      SELECT 1 FROM ap_invoice_lines_all il
      WHERE il.invoice_id = i.invoice_id
        AND il.line_type_lookup_code <> 'AWT'  -- exclude auto-withholding
        AND il.discarded_flag = 'N'
  );
```

### Calculation Logic

```sql
-- RULE: Calculate aging buckets (common in AP/AR reports)
FUNCTION get_aging_bucket(
    p_invoice_date IN DATE,
    p_as_of_date   IN DATE DEFAULT SYSDATE
) RETURN VARCHAR2 IS
    l_days NUMBER;
BEGIN
    l_days := TRUNC(p_as_of_date) - TRUNC(p_invoice_date);

    RETURN CASE
        WHEN l_days <= 30  THEN 'Current'
        WHEN l_days <= 60  THEN '31-60 Days'
        WHEN l_days <= 90  THEN '61-90 Days'
        WHEN l_days <= 120 THEN '91-120 Days'
        ELSE 'Over 120 Days'
    END;
END;
```

## Forms Personalization Rule Extraction

### Conditional Display Rules

```
-- FND_FORM_CUSTOM_RULES entry:
-- Form: POXPOEPO (Purchase Orders)
-- Trigger: WHEN-NEW-RECORD-INSTANCE
-- Block: PO_HEADERS
-- Condition: :PO_HEADERS.TYPE_LOOKUP_CODE = 'XX_EMERGENCY'
-- Action: Set Property PO_HEADERS.ATTRIBUTE1 REQUIRED = TRUE
-- Action: Set Property PO_HEADERS.ATTRIBUTE1 PROMPT_TEXT = 'Emergency Justification'

-- RULE: Emergency POs require a justification in DFF Attribute1
```

### Value Default Rules

```
-- FND_FORM_CUSTOM_RULES entry:
-- Form: APXINWKB (Invoices)
-- Trigger: WHEN-NEW-RECORD-INSTANCE
-- Block: INV_SUM_FOLDER
-- Condition: :parameter.ORG_ID = '101'
-- Action: Set Property INV_SUM_FOLDER.PAYMENT_METHOD_CODE VALUE = 'EFT'

-- RULE: HQ invoices default to EFT payment method
```

### Field Validation Rules

```
-- FND_FORM_CUSTOM_RULES entry:
-- Form: POXPOEPO (Purchase Orders)
-- Trigger: WHEN-VALIDATE-ITEM
-- Block: PO_HEADERS
-- Item: ATTRIBUTE2 (Custom Project Code)
-- Condition: :PO_HEADERS.ATTRIBUTE2 IS NOT NULL
-- Action: Execute PL/SQL:
--   BEGIN
--     IF NOT xx_project_utils.is_valid_project(:PO_HEADERS.ATTRIBUTE2) THEN
--       fnd_message.set_name('XXCUST', 'XX_INVALID_PROJECT');
--       fnd_message.error;
--     END IF;
--   END;

-- RULE: Project code in DFF must exist in custom project table
```

### Restriction Rules

```
-- FND_FORM_CUSTOM_RULES entry:
-- Form: POXPOEPO (Purchase Orders)
-- Trigger: WHEN-NEW-FORM-INSTANCE
-- Condition: FND_PROFILE.VALUE('XX_READONLY_MODE') = 'Y'
-- Action: Set Property PO_HEADERS.* UPDATEABLE = FALSE

-- RULE: When read-only profile is enabled, entire form is non-editable
```

## Extraction Strategy Summary

### Priority Order for Business Rule Extraction

1. **Custom PL/SQL packages** (XX_*_PKG) — the richest source of explicit business rules
2. **Concurrent program logic** — batch processing rules, scheduling constraints
3. **Workflow functions** — approval hierarchies, routing logic
4. **Interface programs** — mapping rules, transformation rules, validation rules
5. **Form personalizations** — UI-level business rules (conditional display, validation)
6. **Trigger logic** — enforcement rules on base tables
7. **Value set definitions** — lookup values, table validation WHERE clauses
8. **Cross-validation rules** — valid flexfield segment combinations
9. **Report queries** — selection criteria encoding business eligibility rules
10. **Profile options** — configuration-driven behavior switches

### Rule Classification Template

For each extracted rule, classify:
- **Rule ID**: Unique identifier (e.g., XX-PO-VAL-001)
- **Source**: Package/program/form/workflow name and location
- **Category**: Validation, Calculation, Routing, Authorization, Default, Mapping
- **Criticality**: High (data integrity), Medium (business process), Low (UI/display)
- **Dependencies**: Other rules, profile options, org context
- **Data elements**: Tables/columns referenced
- **Migration complexity**: Simple (direct translation), Medium (logic redesign), Complex (requires new approach)
