# Legacy Business Rules Discovery

> Provenance: Ported from the deprecated `legacy-business-rule-extractor` and
> `sdr-area-logic` skills during A17-P0-18 consolidation. Both skills overlapped
> with `extraction`; their unique discovery-phase content lives here.

This reference captures the Discovery-phase patterns for unearthing business
rules, validation logic, workflows, state transitions, and implicit behaviors
from legacy application code. Apply it in combination with the 3-pass extraction
methodology defined in the parent `SKILL.md`.

## Scope

Extract every business rule, validation, calculation, workflow, and edge case
from legacy code — including the implicit, undocumented behaviors that are
operationally significant. Neither the application layer nor the database layer
is secondary; both are first-class extraction targets.

## Rule Taxonomy

**Explicit rules** (directly visible in code):
- Conditional branches (if/else, switch/case, ternary operators)
- Validation logic (input checks, range validation, format validation)
- Calculations (formulas, aggregations, derived values)
- State transitions (status field updates with guard conditions)
- Authorization checks (role/permission gates in business logic)
- Error handling with business meaning (not just technical catch blocks)

**Implicit rules** (derived from convention or configuration):
- ORM validation annotations (`@NotNull`, `@Size`, `@Pattern`, `validates_presence_of`)
- Database constraints (`NOT NULL`, `CHECK`, `UNIQUE`, `FOREIGN KEY`)
- Framework conventions (Rails `strong_params`, Spring `@Valid`, ColdFusion `cfparam`)
- Stored procedure logic (PL/SQL, T-SQL business rules in the database)
- Trigger-based rules (BEFORE INSERT/UPDATE triggers enforcing business logic)
- Configuration-driven rules (feature flags, environment-based behavior)
- Magic numbers, hardcoded thresholds, and undocumented defaults

## Per-Rule Capture Schema

For every rule discovered, record:

- `id` (BR-NNN, sequential, never reused)
- `category` (validation | calculation | workflow | authorization | business-decision | data-transformation | scheduling | state-transition)
- `description`
- `source_file`, `source_line`, `source_function`
- `logic` (pseudocode)
- `inputs` / `outputs` with type and origin
- `conditions` and `exceptions`
- `implicit` (true if derived from framework convention or DB constraint)
- `confidence` (high | medium | low)
- `active` (false if dead code, feature-flagged off, or unreachable)
- `related_rules` and `endpoint_refs`
- `test_scenarios` (>= 1 per rule, Given/When/Then with concrete values)

See `assets/business-rules-catalog-template.yaml` for the full schema.

## Methodology Notes Beyond the 3 Passes

1. Analyze conditional branches for validation and business rules.
2. Trace state transitions and workflow paths end-to-end.
3. Extract calculation and transformation logic from every layer.
4. Identify rules embedded in switch statements and guard clauses.
5. Flag implicit behaviors: magic numbers, hardcoded thresholds, type coercion.
6. Analyze SQL for business logic in stored procedures, triggers, functions.
7. Document exception handling paths and edge cases alongside happy-path rules.
8. Cross-reference with available business documentation; flag discrepancies.

## Anomaly Classification

Apply `assets/anomaly-resolution-rules.yaml` during Pass 3 cross-validation to
categorize discovered issues: security violations, dead code, duplicate logic,
naming inconsistencies, redundant validation, implicit behaviors, performance
antipatterns, accessibility violations, error-handling gaps, and data-integrity
risks. Each anomaly type has a prescribed SRS treatment (FIX, OMIT, CONSOLIDATE,
RENAME, MAKE_EXPLICIT, OPTIMIZE).

## Cross-Validation Expectations

- **No contradictions**: Two rules must not prescribe opposite outcomes for the
  same input. If found, flag as CONTRADICTION with both rule IDs.
- **No gaps**: Every endpoint in the interface inventory must trace to at least
  one business rule. Endpoints without rules are either pure CRUD (document as
  such) or have undiscovered logic.
- **Complete traceability**: Every rule has `{file}:{line}` that resolves to
  actual code. Verify a sample (minimum 20%) by reading the referenced source.
- **Coverage metric**: Calculate rules-per-endpoint and rules-per-source-file
  to identify under-analyzed areas.

## Gotchas Unique to Legacy Discovery

- **Business logic in stored procedures is often missed**: Some FAA applications
  keep 60%+ of their logic in PL/SQL or T-SQL. Treat stored procs as primary
  scanning targets, not optional ones.
- **ColdFusion implicit type coercion IS business logic**: CF silently converts
  strings to numbers, dates to strings, and nulls to empty strings. These
  coercions change behavior and must be documented as implicit rules.
- **Validation in JavaScript duplicates server-side validation**: Extract both.
  Document which validations exist only client-side (risk) vs. both sides
  (redundant but safe) vs. only server-side (expected pattern).
- **Batch jobs contain scheduling rules**: The schedule itself (run at 2am,
  run every 15 minutes, run after job X completes) is a business rule.
- **Dead code still appears as business logic**: Unreachable branches, commented
  code, and feature-flagged-off code must be identified and classified as
  `dead_code` in the anomaly log, not included as active rules.
- **Framework magic hides logic**: Spring AOP, Rails callbacks, ColdFusion
  `onRequestStart` — these execute business logic invisibly. Trace them.
- **Flag uncertain rules for SME confirmation**: Mark rules where intent is
  ambiguous. Don't guess — escalate to domain experts.

## Quality Checklist

- [ ] Every rule has a unique BR-NNN ID and a `{file}:{line}` source reference.
- [ ] Every rule has at least one Given/When/Then test scenario (>= 95% coverage).
- [ ] Implicit behaviors (coercion, magic numbers, framework conventions) are
      documented as explicit rules.
- [ ] Database-resident logic (stored procedures, triggers, functions) is in
      scope — not deferred.
- [ ] Contradictions are flagged and resolved with a documented decision.
- [ ] Dead code is classified in the anomaly log, not cataloged as active.
- [ ] Uncertain rules carry an "SME confirmation needed" marker.
