# Oracle PL/SQL Advanced Extraction Patterns (Oracle to PostgreSQL)

## Purpose

Reference for the Extraction skill when performing advanced PL/SQL business rule
extraction for Oracle-to-PostgreSQL migration. Covers Oracle-specific constructs
that have no direct PostgreSQL equivalent and require architectural decisions
during migration. Every pattern includes the Oracle source, the PostgreSQL target,
and migration notes.

## Autonomous Transactions

### Oracle Pattern
```sql
-- PRAGMA AUTONOMOUS_TRANSACTION creates an independent transaction
-- that can commit/rollback without affecting the calling transaction.
-- Common use: audit logging that persists even if the main transaction rolls back.

CREATE OR REPLACE PROCEDURE log_audit_event(
    p_table_name  IN VARCHAR2,
    p_action      IN VARCHAR2,
    p_details     IN VARCHAR2
) AS
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    INSERT INTO audit_log (table_name, action, details, log_date, log_user)
    VALUES (p_table_name, p_action, p_details, SYSDATE, SYS_CONTEXT('USERENV', 'SESSION_USER'));
    COMMIT;  -- commits only the audit insert, not the caller's transaction
END;
```

### PostgreSQL Equivalent
```sql
-- PostgreSQL has no PRAGMA AUTONOMOUS_TRANSACTION.
-- Option 1: dblink self-connection (most common workaround)
CREATE OR REPLACE FUNCTION log_audit_event(
    p_table_name TEXT,
    p_action     TEXT,
    p_details    TEXT
) RETURNS VOID AS $$
BEGIN
    PERFORM dblink_exec(
        'dbname=' || current_database(),
        format(
            'INSERT INTO audit_log (table_name, action, details, log_date, log_user)
             VALUES (%L, %L, %L, NOW(), CURRENT_USER)',
            p_table_name, p_action, p_details
        )
    );
END;
$$ LANGUAGE plpgsql;

-- Option 2: Use a separate connection via application layer
-- Option 3: Use pg_background extension (third-party)
```

**Migration notes**: The dblink approach has performance overhead from establishing
a new connection. For high-frequency audit logging, consider an application-layer
approach using a separate database connection.

## Pipelined Functions

### Oracle Pattern
```sql
-- Pipelined functions return rows one at a time, enabling streaming.
CREATE OR REPLACE FUNCTION get_active_employees
RETURN employee_tab PIPELINED AS
BEGIN
    FOR r IN (SELECT * FROM employees WHERE status = 'ACTIVE') LOOP
        -- Apply business transformation
        r.salary := r.salary * 1.03;  -- 3% raise for display
        PIPE ROW(r);
    END LOOP;
    RETURN;
END;

-- Usage: SELECT * FROM TABLE(get_active_employees);
```

### PostgreSQL Equivalent
```sql
-- PostgreSQL uses RETURNS TABLE or RETURNS SETOF with RETURN NEXT
CREATE OR REPLACE FUNCTION get_active_employees()
RETURNS TABLE (
    employee_id   INTEGER,
    employee_name TEXT,
    salary        NUMERIC
) AS $$
BEGIN
    FOR employee_id, employee_name, salary IN
        SELECT e.employee_id, e.employee_name, e.salary * 1.03
        FROM employees e
        WHERE e.status = 'ACTIVE'
    LOOP
        RETURN NEXT;  -- equivalent to PIPE ROW
    END LOOP;
    RETURN;
END;
$$ LANGUAGE plpgsql;
```

## REF CURSORs

### Oracle Pattern
```sql
-- SYS_REFCURSOR used to return result sets from procedures
CREATE OR REPLACE PROCEDURE get_orders_by_status(
    p_status   IN  VARCHAR2,
    p_cursor   OUT SYS_REFCURSOR
) AS
BEGIN
    OPEN p_cursor FOR
        SELECT order_id, customer_name, total_amount
        FROM orders
        WHERE status = p_status
        ORDER BY order_date DESC;
END;

-- Called from application code:
-- var cursor = call get_orders_by_status('PENDING', :cursor)
-- fetch from cursor until exhausted
```

### PostgreSQL Equivalent
```sql
-- Option 1: REFCURSOR (closest to Oracle)
CREATE OR REPLACE FUNCTION get_orders_by_status(p_status TEXT)
RETURNS REFCURSOR AS $$
DECLARE
    ref REFCURSOR := 'orders_cursor';
BEGIN
    OPEN ref FOR
        SELECT order_id, customer_name, total_amount
        FROM orders
        WHERE status = p_status
        ORDER BY order_date DESC;
    RETURN ref;
END;
$$ LANGUAGE plpgsql;

-- Option 2: RETURNS TABLE (preferred for new code)
CREATE OR REPLACE FUNCTION get_orders_by_status(p_status TEXT)
RETURNS TABLE (
    order_id      INTEGER,
    customer_name TEXT,
    total_amount  NUMERIC
) AS $$
BEGIN
    RETURN QUERY
        SELECT o.order_id, o.customer_name, o.total_amount
        FROM orders o
        WHERE o.status = p_status
        ORDER BY o.order_date DESC;
END;
$$ LANGUAGE plpgsql;
```

**Migration notes**: RETURNS TABLE is strongly preferred over REFCURSOR in
PostgreSQL. REFCURSOR requires the caller to manage cursor lifecycle within
the same transaction. Convert to RETURNS TABLE unless the application layer
specifically manages cursors.

## BULK COLLECT / FORALL

### Oracle Pattern
```sql
-- BULK COLLECT reads entire result set into a PL/SQL collection
-- FORALL performs bulk DML with a single context switch
DECLARE
    TYPE t_emp_ids IS TABLE OF employees.employee_id%TYPE;
    TYPE t_salaries IS TABLE OF employees.salary%TYPE;
    l_emp_ids  t_emp_ids;
    l_salaries t_salaries;
BEGIN
    SELECT employee_id, salary
    BULK COLLECT INTO l_emp_ids, l_salaries
    FROM employees
    WHERE department_id = 10;

    -- RULE: Apply 5% raise to all department 10 employees
    FORALL i IN l_emp_ids.FIRST .. l_emp_ids.LAST
        UPDATE employees
        SET salary = l_salaries(i) * 1.05,
            last_raise_date = SYSDATE
        WHERE employee_id = l_emp_ids(i);

    COMMIT;
END;
```

### PostgreSQL Equivalent
```sql
-- PostgreSQL handles bulk operations natively with set-based SQL
-- No collection-and-iterate pattern needed
UPDATE employees
SET salary = salary * 1.05,
    last_raise_date = NOW()
WHERE department_id = 10;

-- If row-by-row logic is truly needed, use FOREACH with arrays:
DO $$
DECLARE
    emp_ids INTEGER[];
    emp_id INTEGER;
BEGIN
    SELECT ARRAY_AGG(employee_id) INTO emp_ids
    FROM employees
    WHERE department_id = 10;

    FOREACH emp_id IN ARRAY emp_ids LOOP
        -- Per-row business logic here
        UPDATE employees
        SET salary = salary * 1.05,
            last_raise_date = NOW()
        WHERE employee_id = emp_id;
    END LOOP;
END $$;
```

**Migration notes**: Most BULK COLLECT/FORALL patterns exist for Oracle performance
optimization (reducing PL/SQL-to-SQL context switches). In PostgreSQL, set-based
SQL is already efficient. Convert to a single UPDATE/INSERT/DELETE statement
wherever possible.

## Oracle-Specific SQL Mapping

### CONNECT BY to Recursive CTE

```sql
-- Oracle hierarchical query
SELECT employee_id, employee_name, manager_id, LEVEL
FROM employees
START WITH manager_id IS NULL
CONNECT BY PRIOR employee_id = manager_id
ORDER SIBLINGS BY employee_name;

-- PostgreSQL recursive CTE
WITH RECURSIVE emp_hierarchy AS (
    -- Anchor: root employees (no manager)
    SELECT employee_id, employee_name, manager_id, 1 AS level
    FROM employees
    WHERE manager_id IS NULL

    UNION ALL

    -- Recursive: employees under the current level
    SELECT e.employee_id, e.employee_name, e.manager_id, h.level + 1
    FROM employees e
    INNER JOIN emp_hierarchy h ON e.manager_id = h.employee_id
)
SELECT * FROM emp_hierarchy
ORDER BY level, employee_name;
```

### CONNECT BY Path (SYS_CONNECT_BY_PATH)

```sql
-- Oracle: build path string
SELECT SYS_CONNECT_BY_PATH(department_name, ' > ') AS dept_path
FROM departments
START WITH parent_dept_id IS NULL
CONNECT BY PRIOR department_id = parent_dept_id;

-- PostgreSQL: accumulate path in recursive CTE
WITH RECURSIVE dept_path AS (
    SELECT department_id, department_name,
           department_name::TEXT AS dept_path
    FROM departments
    WHERE parent_dept_id IS NULL

    UNION ALL

    SELECT d.department_id, d.department_name,
           dp.dept_path || ' > ' || d.department_name
    FROM departments d
    INNER JOIN dept_path dp ON d.parent_dept_id = dp.department_id
)
SELECT dept_path FROM dept_path;
```

### MODEL Clause to Window Functions

```sql
-- Oracle MODEL clause (spreadsheet-style calculations)
SELECT product, year, sales
FROM yearly_sales
MODEL
    PARTITION BY (product)
    DIMENSION BY (year)
    MEASURES (sales)
    RULES (
        sales[2026] = sales[2025] * 1.10,  -- 10% growth forecast
        sales[2027] = sales[2026] * 1.08   -- 8% growth forecast
    );

-- PostgreSQL: Use GENERATE_SERIES + LAG/LEAD or application logic
-- No direct equivalent — requires decomposing the calculation rules
```

### PIVOT / UNPIVOT

```sql
-- Oracle PIVOT
SELECT *
FROM (SELECT department, quarter, revenue FROM quarterly_results)
PIVOT (SUM(revenue) FOR quarter IN ('Q1', 'Q2', 'Q3', 'Q4'));

-- PostgreSQL: crosstab from tablefunc extension
SELECT * FROM crosstab(
    'SELECT department, quarter, revenue FROM quarterly_results
     ORDER BY 1, 2',
    $$VALUES ('Q1'), ('Q2'), ('Q3'), ('Q4')$$
) AS ct(department TEXT, q1 NUMERIC, q2 NUMERIC, q3 NUMERIC, q4 NUMERIC);

-- Or: conditional aggregation (no extension needed)
SELECT
    department,
    SUM(CASE WHEN quarter = 'Q1' THEN revenue END) AS q1,
    SUM(CASE WHEN quarter = 'Q2' THEN revenue END) AS q2,
    SUM(CASE WHEN quarter = 'Q3' THEN revenue END) AS q3,
    SUM(CASE WHEN quarter = 'Q4' THEN revenue END) AS q4
FROM quarterly_results
GROUP BY department;
```

### ROWNUM vs ROW_NUMBER / LIMIT

```sql
-- Oracle: ROWNUM for pagination
SELECT * FROM (
    SELECT t.*, ROWNUM AS rn
    FROM (SELECT * FROM orders ORDER BY order_date DESC) t
    WHERE ROWNUM <= 20  -- top 20
)
WHERE rn > 10;  -- skip first 10 (page 2)

-- PostgreSQL: LIMIT/OFFSET
SELECT * FROM orders
ORDER BY order_date DESC
LIMIT 10 OFFSET 10;

-- Or: ROW_NUMBER for more complex pagination
SELECT * FROM (
    SELECT *, ROW_NUMBER() OVER (ORDER BY order_date DESC) AS rn
    FROM orders
) sub
WHERE rn BETWEEN 11 AND 20;
```

### DECODE vs CASE

```sql
-- Oracle DECODE
SELECT DECODE(status, 'A', 'Active', 'I', 'Inactive', 'P', 'Pending', 'Unknown')
FROM accounts;

-- PostgreSQL CASE (DECODE has no equivalent)
SELECT CASE status
    WHEN 'A' THEN 'Active'
    WHEN 'I' THEN 'Inactive'
    WHEN 'P' THEN 'Pending'
    ELSE 'Unknown'
END
FROM accounts;
```

### NVL / NVL2 / COALESCE

```sql
-- Oracle NVL (two arguments)
SELECT NVL(commission_pct, 0) FROM employees;
-- PostgreSQL: COALESCE(commission_pct, 0)

-- Oracle NVL2 (three arguments: value, if-not-null, if-null)
SELECT NVL2(commission_pct, salary + commission_pct, salary) FROM employees;
-- PostgreSQL:
SELECT CASE WHEN commission_pct IS NOT NULL
    THEN salary + commission_pct
    ELSE salary
END FROM employees;

-- CRITICAL: Oracle treats empty string ('') as NULL
-- PostgreSQL does NOT: '' IS NOT NULL in PostgreSQL
-- This is the single most common migration breakage point.
```

## Package Global Variables

### Oracle Pattern
```sql
-- Package-level variables maintain state for the session
CREATE OR REPLACE PACKAGE session_context AS
    g_user_id      NUMBER;
    g_org_id       NUMBER;
    g_role_name    VARCHAR2(100);
    g_debug_mode   BOOLEAN := FALSE;

    PROCEDURE initialize(p_user_id NUMBER, p_org_id NUMBER);
    FUNCTION get_user_id RETURN NUMBER;
    FUNCTION get_org_id RETURN NUMBER;
END;

CREATE OR REPLACE PACKAGE BODY session_context AS
    PROCEDURE initialize(p_user_id NUMBER, p_org_id NUMBER) AS
    BEGIN
        g_user_id := p_user_id;
        g_org_id := p_org_id;
        SELECT role_name INTO g_role_name
        FROM user_roles WHERE user_id = p_user_id;
    END;

    FUNCTION get_user_id RETURN NUMBER AS
    BEGIN RETURN g_user_id; END;

    FUNCTION get_org_id RETURN NUMBER AS
    BEGIN RETURN g_org_id; END;
END;
```

### PostgreSQL Equivalents
```sql
-- Option 1: Temporary tables (session-scoped)
CREATE TEMP TABLE IF NOT EXISTS session_context (
    user_id    INTEGER,
    org_id     INTEGER,
    role_name  TEXT
) ON COMMIT PRESERVE ROWS;

-- Option 2: SET/SHOW custom GUC variables
SET myapp.user_id = '42';
SET myapp.org_id = '101';
SELECT current_setting('myapp.user_id')::INTEGER;

-- Option 3: Application-layer configuration
-- Store context in the application (e.g., request-scoped container)
```

## Collection Types

### Oracle Pattern
```sql
-- VARRAY (fixed-size ordered collection)
CREATE OR REPLACE TYPE color_list AS VARRAY(10) OF VARCHAR2(30);

-- Nested table (variable-size, can be stored in tables)
CREATE OR REPLACE TYPE phone_list AS TABLE OF VARCHAR2(20);

-- Associative array (PL/SQL only, not storable)
TYPE employee_map IS TABLE OF employees%ROWTYPE INDEX BY PLS_INTEGER;
```

### PostgreSQL Equivalents
```sql
-- VARRAY / Nested table → PostgreSQL ARRAY
CREATE TABLE products (
    product_id SERIAL PRIMARY KEY,
    colors     TEXT[],       -- replaces VARRAY/nested table of VARCHAR2
    sizes      INTEGER[]     -- replaces VARRAY/nested table of NUMBER
);

-- Insert
INSERT INTO products (colors, sizes)
VALUES (ARRAY['Red', 'Blue', 'Green'], ARRAY[8, 10, 12]);

-- Query array elements
SELECT * FROM products WHERE 'Red' = ANY(colors);
SELECT * FROM products WHERE colors @> ARRAY['Red', 'Blue'];

-- Associative array → temporary table or JSONB
CREATE TEMP TABLE employee_map (
    key   INTEGER PRIMARY KEY,
    value JSONB
);
```

## DBMS Package Equivalents

### DBMS_SCHEDULER to pg_cron

```sql
-- Oracle DBMS_SCHEDULER
BEGIN
    DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'NIGHTLY_CLEANUP',
        job_type        => 'PLSQL_BLOCK',
        job_action      => 'BEGIN cleanup_old_records(90); END;',
        start_date      => SYSTIMESTAMP,
        repeat_interval => 'FREQ=DAILY; BYHOUR=2; BYMINUTE=0',
        enabled         => TRUE
    );
END;

-- PostgreSQL pg_cron
SELECT cron.schedule(
    'nightly-cleanup',
    '0 2 * * *',
    $$CALL cleanup_old_records(90)$$
);
```

### DBMS_OUTPUT to RAISE NOTICE

```sql
-- Oracle
DBMS_OUTPUT.PUT_LINE('Processing record: ' || l_record_id);

-- PostgreSQL
RAISE NOTICE 'Processing record: %', l_record_id;
-- Severity levels: DEBUG, LOG, INFO, NOTICE, WARNING, EXCEPTION
```

### UTL_FILE to PostgreSQL File Operations

```sql
-- Oracle UTL_FILE (server-side file I/O)
DECLARE
    l_file UTL_FILE.FILE_TYPE;
BEGIN
    l_file := UTL_FILE.FOPEN('EXPORT_DIR', 'output.csv', 'W');
    UTL_FILE.PUT_LINE(l_file, 'id,name,amount');
    FOR r IN (SELECT * FROM orders) LOOP
        UTL_FILE.PUT_LINE(l_file, r.id || ',' || r.name || ',' || r.amount);
    END LOOP;
    UTL_FILE.FCLOSE(l_file);
END;

-- PostgreSQL: COPY command (much simpler)
COPY (SELECT id, name, amount FROM orders)
TO '/tmp/output.csv' WITH (FORMAT CSV, HEADER);

-- Or: pg_write_file (superuser only, requires admin_pack)
SELECT pg_write_file('/tmp/output.txt', 'content here');
```

### UTL_HTTP to PostgreSQL HTTP

```sql
-- Oracle UTL_HTTP
DECLARE
    l_response UTL_HTTP.RESP;
    l_body     VARCHAR2(32767);
BEGIN
    l_response := UTL_HTTP.BEGIN_REQUEST('https://api.example.com/data');
    UTL_HTTP.READ_TEXT(l_response, l_body, 32767);
    UTL_HTTP.END_RESPONSE(l_response);
END;

-- PostgreSQL: http extension (pgsql-http)
SELECT content::json FROM http_get('https://api.example.com/data');

-- Or: application-layer HTTP calls (preferred for production)
```

### DBMS_LOB to PostgreSQL Large Objects

```sql
-- Oracle DBMS_LOB
DECLARE
    l_clob CLOB;
BEGIN
    DBMS_LOB.CREATETEMPORARY(l_clob, TRUE);
    DBMS_LOB.WRITEAPPEND(l_clob, LENGTH(l_text), l_text);
    INSERT INTO documents (doc_content) VALUES (l_clob);
    DBMS_LOB.FREETEMPORARY(l_clob);
END;

-- PostgreSQL: TEXT or BYTEA (no LOB management needed)
INSERT INTO documents (doc_content) VALUES (p_text);
-- TEXT columns in PostgreSQL handle large strings natively via TOAST
-- No explicit create/free operations required
```

## Dynamic SQL

### Oracle Pattern
```sql
-- EXECUTE IMMEDIATE (simple dynamic SQL)
EXECUTE IMMEDIATE 'ALTER TABLE ' || l_table_name || ' ADD (new_col VARCHAR2(100))';

-- EXECUTE IMMEDIATE with bind variables
EXECUTE IMMEDIATE
    'SELECT COUNT(*) FROM ' || l_table_name || ' WHERE status = :1'
    INTO l_count
    USING p_status;

-- DBMS_SQL (complex dynamic SQL with describe)
l_cursor := DBMS_SQL.OPEN_CURSOR;
DBMS_SQL.PARSE(l_cursor, l_sql, DBMS_SQL.NATIVE);
DBMS_SQL.BIND_VARIABLE(l_cursor, ':status', p_status);
l_rows := DBMS_SQL.EXECUTE(l_cursor);
DBMS_SQL.CLOSE_CURSOR(l_cursor);
```

### PostgreSQL Equivalent
```sql
-- EXECUTE with format() (safe dynamic SQL)
EXECUTE format('ALTER TABLE %I ADD COLUMN new_col VARCHAR(100)', l_table_name);

-- EXECUTE with parameters (bind variables)
EXECUTE format('SELECT COUNT(*) FROM %I WHERE status = $1', l_table_name)
    INTO l_count
    USING p_status;

-- %I = identifier quoting (safe from SQL injection)
-- %L = literal quoting (safe from SQL injection)
-- %s = simple string substitution (NOT safe — avoid for user input)
```

## Materialized Views

```sql
-- Oracle: auto-refresh on commit
CREATE MATERIALIZED VIEW mv_order_summary
REFRESH FAST ON COMMIT
ENABLE QUERY REWRITE
AS
SELECT customer_id, COUNT(*) AS order_count, SUM(total) AS total_spent
FROM orders
GROUP BY customer_id;

-- PostgreSQL: manual refresh (no ON COMMIT refresh)
CREATE MATERIALIZED VIEW mv_order_summary AS
SELECT customer_id, COUNT(*) AS order_count, SUM(total) AS total_spent
FROM orders
GROUP BY customer_id;

-- Refresh (blocks reads during refresh without CONCURRENTLY)
REFRESH MATERIALIZED VIEW mv_order_summary;

-- Concurrent refresh (requires unique index, does not block reads)
CREATE UNIQUE INDEX idx_mv_order_summary ON mv_order_summary(customer_id);
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_order_summary;

-- Schedule via pg_cron
SELECT cron.schedule(
    'refresh-order-summary',
    '*/15 * * * *',  -- every 15 minutes
    $$REFRESH MATERIALIZED VIEW CONCURRENTLY mv_order_summary$$
);
```

**Migration notes**: Oracle's `REFRESH FAST ON COMMIT` has no PostgreSQL equivalent.
Use `pg_cron` for periodic refresh. Oracle's `QUERY REWRITE` (automatic MV
substitution) also has no PostgreSQL equivalent — queries must explicitly reference
the materialized view.

## Database Links to postgres_fdw

```sql
-- Oracle database link
CREATE DATABASE LINK remote_hr
CONNECT TO hr_user IDENTIFIED BY "password"
USING 'remote_host:1521/HRDB';

SELECT * FROM employees@remote_hr WHERE department = 'IT';

-- PostgreSQL: Foreign Data Wrapper
CREATE EXTENSION IF NOT EXISTS postgres_fdw;

CREATE SERVER remote_hr
    FOREIGN DATA WRAPPER postgres_fdw
    OPTIONS (host 'remote_host', port '5432', dbname 'hrdb');

CREATE USER MAPPING FOR CURRENT_USER
    SERVER remote_hr
    OPTIONS (user 'hr_user', password 'password');

CREATE FOREIGN TABLE remote_employees (
    employee_id INTEGER,
    employee_name TEXT,
    department TEXT
) SERVER remote_hr
  OPTIONS (schema_name 'public', table_name 'employees');

-- Query the foreign table directly
SELECT * FROM remote_employees WHERE department = 'IT';
```

## Empty String = NULL (Critical Breaking Change)

```sql
-- Oracle: '' IS NULL evaluates to TRUE
SELECT CASE WHEN '' IS NULL THEN 'YES' ELSE 'NO' END FROM dual;
-- Result: 'YES'

-- PostgreSQL: '' IS NULL evaluates to FALSE
SELECT CASE WHEN '' IS NULL THEN 'YES' ELSE 'NO' END;
-- Result: 'NO'

-- Oracle: LENGTH('') returns NULL
SELECT LENGTH('') FROM dual;
-- Result: NULL

-- PostgreSQL: LENGTH('') returns 0
SELECT LENGTH('');
-- Result: 0
```

**Impact on WHERE clauses**:
```sql
-- Oracle code that works:
WHERE name IS NOT NULL  -- excludes both NULL and empty string

-- Same code in PostgreSQL:
WHERE name IS NOT NULL  -- excludes NULL but INCLUDES empty string
-- Must add: AND name <> '' to match Oracle behavior
-- Or: WHERE NULLIF(name, '') IS NOT NULL
```

**Impact on NVL/COALESCE**:
```sql
-- Oracle: NVL('', 'default') returns 'default' ('' is NULL)
-- PostgreSQL: COALESCE('', 'default') returns '' ('' is NOT NULL)
-- Fix: COALESCE(NULLIF(value, ''), 'default')
```

## Implicit Date Conversion (NLS_DATE_FORMAT)

```sql
-- Oracle: implicit conversion uses NLS_DATE_FORMAT session parameter
-- Default NLS_DATE_FORMAT is 'DD-MON-RR' or 'DD-MON-YYYY'
ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

-- This works in Oracle (implicit VARCHAR2 → DATE conversion):
SELECT * FROM orders WHERE order_date > '2026-01-01';

-- PostgreSQL: requires explicit casting
SELECT * FROM orders WHERE order_date > '2026-01-01'::DATE;
-- Or: WHERE order_date > DATE '2026-01-01';
-- Or: WHERE order_date > TO_DATE('2026-01-01', 'YYYY-MM-DD');
```

**Migration rule**: Every implicit date comparison in Oracle code must be reviewed.
PostgreSQL requires explicit casting or standard date literal syntax.

## Extraction Priority for Oracle-to-PostgreSQL

1. **Empty string / NULL handling** — audit all NULL checks, NVL calls, and string comparisons
2. **CONNECT BY hierarchical queries** — convert to recursive CTEs
3. **Package global state** — redesign as temp tables or GUC variables
4. **Autonomous transactions** — redesign as dblink or application-layer
5. **Bulk operations** — simplify to set-based SQL
6. **DECODE / NVL / NVL2** — convert to CASE / COALESCE
7. **Oracle-specific functions** — map to PostgreSQL equivalents (see function mapping reference)
8. **REF CURSORs** — convert to RETURNS TABLE functions
9. **Dynamic SQL** — convert EXECUTE IMMEDIATE to EXECUTE + format()
10. **Implicit date conversion** — add explicit casts
11. **DB links** — convert to postgres_fdw
12. **DBMS_* packages** — map to PostgreSQL equivalents or application-layer
13. **Materialized views** — convert to manual refresh with pg_cron
14. **Collection types** — convert to arrays or temp tables
