---
name: extraction
description: >
  Perform 3-pass business rule extraction from legacy code: rules pass, tests pass, cross-validation synthesis. Use during P4.1 for specification extraction. Triggers on extraction, business rule extraction, spec extraction, @extract-specifications, or P4.1 mentions.
agent: opus
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Extraction

## Purpose
Extract every business rule, validation, calculation, and workflow from legacy code with archetype-aware strategies (web/batch/API).

## Gotchas
- **3 passes are non-negotiable**: Pass 1 (rules), Pass 2 (tests), Pass 3
  (cross-validation). Skipping Pass 3 gives you specs that look complete
  but have internal contradictions. Claude will try to do it in one pass.
- **Oracle PL/SQL contains business logic**: Don't just extract from application
  code. Check stored procedures, triggers, and functions in the database.
- **ColdFusion implicit behaviors**: CF does type coercion, scope chaining,
  and null handling differently than modern languages. Document these behaviors
  explicitly — they ARE business rules even if unintentional.
- **Batch job extraction is different from web app extraction**: Load the
  batch-extraction skill for job-specific patterns.

## Tech-Stack Dispatch
Before extraction, detect the source technology and load the appropriate reference:
- ColdFusion → load the `legacy-architecture-mapper` skill's ColdFusion patterns
- Java EE → load the `legacy-architecture-mapper` skill's Java EE patterns
- .NET/WebForms → `references/dotnet-webforms-patterns.md`
- NATURAL → `references/natural-adabas-patterns.md`
- Oracle EBS → `references/oracle-ebs-patterns.md`
- PHP → `references/php-patterns.md`
- SQL Server → `references/sqlserver-tsql-patterns.md`
- ePower workflow engine detected (.proc files, process-definition tables, ePower hosting-app config markers) → `references/epower-workflow-patterns.md` → key patterns: states/transitions, guards, timers, form bindings, decision tables; target: Camunda 8 BPMN + DMN

## Discovery-Phase Legacy Rules Reference
For Discovery Pass 2 (business-logic extraction) and anomaly classification
carried over from the deprecated `legacy-business-rule-extractor` and
`sdr-area-logic` skills, see `references/legacy-business-rules-discovery.md`.
The consolidated templates live at `assets/business-rules-catalog-template.yaml`
and `assets/anomaly-resolution-rules.yaml`.

## DDL Extraction Tool (B.4 + MP10)
For Oracle PL/SQL and SQL Server T-SQL sources, use the `extract_ddl` tool to
produce a structured `data-dictionary.json` artifact before Pass 1. The tool
parses `.sql`/`.pks`/`.pkb` files and returns tables, columns, primary keys,
views, procedures, functions, triggers, Oracle packages, and a foreign-key
graph. Dialect is auto-detected; override via the `dialect` argument when
needed.

**Invocation (agent tool_use):**

```json
{
  "name": "extract_ddl",
  "input": {
    "source_dir": "/path/to/db/ddl",
    "dialect": "oracle"
  }
}
```

**Module:** `olympus.tools.ddl_extraction` — public functions `extract_ddl()`,
`detect_dialect()`, and the tool adapter `get_ddl_tools()` / `handle_ddl_tool()`.

**Output artifact:** `data-dictionary.json` with keys `tables`, `views`,
`procedures`, `functions`, `triggers`, `packages` (Oracle-only), `foreign_keys`,
`fk_graph`, plus a `warnings[]` list when DDL is malformed.

Feed the resulting FK graph into Pass 3 cross-validation so rules referencing
database-resident logic line up with actual schema relationships.

## Quality Rules
- [ ] Pass 1 (Rules): Every extracted business rule has a unique ID and a source citation in `{file}:{line}` format
- [ ] Pass 1 (Rules): Rules are classified by type (validation, calculation, conditional, workflow) — no unclassified rules
- [ ] Pass 2 (Tests): Every extracted rule from Pass 1 has at least one corresponding test specification with expected input/output
- [ ] Pass 2 (Tests): Edge cases and boundary conditions are documented for each calculation and validation rule
- [ ] Pass 3 (Cross-Validation): Pass 1 rules and Pass 2 tests are reconciled — no orphaned tests and no untested rules
- [ ] Pass 3 (Cross-Validation): Internal contradictions between passes are identified and resolved with a documented decision
- [ ] All implicit behaviors (type coercion, null handling, scope chaining) are documented as explicit rules
- [ ] Database-resident logic (stored procedures, triggers, functions) is included in the extraction — not just application code
- [ ] Archetype (web/batch/API) is identified and extraction strategy matches the archetype

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Single-pass extraction | Specs look complete but have internal contradictions; downstream generation fails on edge cases | Enforce all 3 passes sequentially — never skip Pass 3 cross-validation |
| Missed database logic | Modernized app missing business rules that lived in stored procedures or triggers | Always include PL/SQL, T-SQL, and trigger analysis in Pass 1 scope |
| ColdFusion implicit behavior ignored | Modernized app behaves differently on null inputs or type boundaries | Document CF-specific implicit behaviors (scope chaining, type coercion) as explicit rules |
| Wrong archetype strategy | Batch job rules extracted with web-app patterns; scheduling and error recovery logic missed | Detect archetype before extraction; load `batch-extraction` skill for batch jobs |
| Contradictions not resolved | Pass 3 flags contradictions but they ship unresolved; generation produces inconsistent code | Require explicit resolution (keep/discard/merge) for every contradiction before handoff |

## Handoff Summary
When this skill completes, verify:
1. All three passes are complete and the cross-validation synthesis is clean (zero unresolved contradictions)
2. Every rule has a unique ID, source citation, type classification, and at least one test specification
3. Database-resident logic is included in the extraction output
Then proceed to: `module-design` (P4.2) for service boundary design, and gate `G-04a` for extraction completeness review

## Technology Dispatch
Detection-driven dispatch to language- and framework-specific pattern references. Apply in addition to the Tech-Stack Dispatch above for .NET stacks:

| Trigger | Reference | Key patterns |
|---|---|---|
| primary_language in {csharp, vbnet} and webforms_detected | `../extraction/references/dotnet-webforms-patterns.md` | ASPX code-behind, ViewState, Page lifecycle, Master Pages, Global.asax, Web.config handlers, HttpModules |
| primary_language in {csharp} and aspnetcore_detected | (inline: same patterns file, sections for DI, middleware) | Program.cs, Startup.cs, middleware pipeline, IConfiguration |
