-- SQL Server Inventory Script
-- Generates a comprehensive inventory of database objects, jobs, and dependencies.
-- Run against each target database. Requires VIEW DEFINITION and VIEW SERVER STATE.
--
-- Usage: sqlcmd -S ServerName -d DatabaseName -i inventory_sqlserver.sql -o output.txt
--
-- Sections:
--   1. Stored procedures with dependency count
--   2. SSIS packages from SSISDB catalog
--   3. SQL Agent jobs with schedules and step details
--   4. Cross-database references
--   5. Linked server usage
--   6. Trigger inventory
--   7. View dependency chains
--   8. Function inventory
--   9. Table sizing summary

SET NOCOUNT ON;

PRINT '========================================================'
PRINT '  SQL Server Inventory: ' + DB_NAME()
PRINT '  Server: ' + @@SERVERNAME
PRINT '  Generated: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT '  Version: ' + @@VERSION
PRINT '========================================================'
PRINT ''

-- ============================================================
-- 1. Stored Procedures with Dependency Graph
-- Purpose: Identify all stored procedures and what they reference.
-- ============================================================
PRINT '=== 1. Stored Procedures with Dependencies ==='
PRINT ''

SELECT
    SCHEMA_NAME(p.schema_id) AS [Schema],
    p.name AS ProcedureName,
    sm.uses_ansi_nulls AS AnsiNulls,
    sm.uses_quoted_identifier AS QuotedIdentifier,
    sm.is_encrypted AS IsEncrypted,
    LEN(sm.definition) AS DefinitionLength,
    -- Count of objects this procedure depends on
    (SELECT COUNT(DISTINCT referenced_entity_name)
     FROM sys.sql_expression_dependencies d
     WHERE d.referencing_id = p.object_id) AS DependencyCount,
    -- Count of objects that depend on this procedure
    (SELECT COUNT(*)
     FROM sys.sql_expression_dependencies d
     WHERE d.referenced_id = p.object_id) AS ReferencedByCount,
    p.create_date AS Created,
    p.modify_date AS LastModified
FROM sys.procedures p
JOIN sys.sql_modules sm ON p.object_id = sm.object_id
WHERE p.is_ms_shipped = 0
ORDER BY DependencyCount DESC, p.name;

-- Detailed dependencies per procedure
PRINT ''
PRINT '=== 1b. Procedure Dependency Details ==='
PRINT ''

SELECT
    SCHEMA_NAME(o.schema_id) AS SourceSchema,
    o.name AS SourceProcedure,
    d.referenced_schema_name AS TargetSchema,
    d.referenced_entity_name AS TargetObject,
    CASE
        WHEN d.referenced_database_name IS NOT NULL THEN 'Cross-DB: ' + d.referenced_database_name
        WHEN d.referenced_server_name IS NOT NULL THEN 'Linked: ' + d.referenced_server_name
        ELSE 'Local'
    END AS ReferenceScope,
    ISNULL(o2.type_desc, 'UNKNOWN') AS TargetType
FROM sys.sql_expression_dependencies d
JOIN sys.objects o ON d.referencing_id = o.object_id
LEFT JOIN sys.objects o2 ON d.referenced_id = o2.object_id
WHERE o.type = 'P'  -- procedures only
  AND o.is_ms_shipped = 0
ORDER BY o.name, d.referenced_entity_name;

-- ============================================================
-- 2. SSIS Packages from SSISDB Catalog
-- Purpose: Inventory all deployed SSIS packages.
-- Note: Requires SSISDB database to exist (SSIS 2012+ catalog).
-- ============================================================
PRINT ''
PRINT '=== 2. SSIS Packages (SSISDB Catalog) ==='
PRINT ''

IF EXISTS (SELECT 1 FROM sys.databases WHERE name = 'SSISDB')
BEGIN
    EXEC('
    SELECT
        f.name AS FolderName,
        prj.name AS ProjectName,
        pkg.name AS PackageName,
        pkg.package_format_version AS FormatVersion,
        prj.deployed_by_name AS DeployedBy,
        prj.last_deployed_time AS LastDeployed,
        prj.description AS ProjectDescription
    FROM SSISDB.catalog.packages pkg
    JOIN SSISDB.catalog.projects prj ON pkg.project_id = prj.project_id
    JOIN SSISDB.catalog.folders f ON prj.folder_id = f.folder_id
    ORDER BY f.name, prj.name, pkg.name;
    ')

    -- SSIS execution history (last 30 days)
    PRINT ''
    PRINT '=== 2b. SSIS Execution History (Last 30 Days) ==='
    PRINT ''

    EXEC('
    SELECT
        f.name AS FolderName,
        prj.name AS ProjectName,
        pkg.name AS PackageName,
        e.status AS ExecutionStatus,
        CASE e.status
            WHEN 1 THEN ''Created''
            WHEN 2 THEN ''Running''
            WHEN 3 THEN ''Cancelled''
            WHEN 4 THEN ''Failed''
            WHEN 5 THEN ''Pending''
            WHEN 6 THEN ''Ended Unexpectedly''
            WHEN 7 THEN ''Succeeded''
            WHEN 8 THEN ''Stopping''
            WHEN 9 THEN ''Completed''
        END AS StatusDescription,
        COUNT(*) AS ExecutionCount,
        AVG(DATEDIFF(SECOND, e.start_time, e.end_time)) AS AvgDurationSec,
        MAX(DATEDIFF(SECOND, e.start_time, e.end_time)) AS MaxDurationSec,
        SUM(CASE WHEN e.status = 4 THEN 1 ELSE 0 END) AS FailureCount
    FROM SSISDB.catalog.executions e
    JOIN SSISDB.catalog.packages pkg ON e.package_name = pkg.name
    JOIN SSISDB.catalog.projects prj ON pkg.project_id = prj.project_id
    JOIN SSISDB.catalog.folders f ON prj.folder_id = f.folder_id
    WHERE e.start_time >= DATEADD(DAY, -30, GETDATE())
    GROUP BY f.name, prj.name, pkg.name, e.status
    ORDER BY f.name, prj.name, pkg.name;
    ')
END
ELSE
BEGIN
    PRINT '  SSISDB catalog database not found on this instance.'
    PRINT '  SSIS packages may be stored in msdb or on the file system.'
END

-- Check for legacy SSIS packages in msdb
PRINT ''
PRINT '=== 2c. Legacy SSIS Packages (msdb) ==='
PRINT ''

IF EXISTS (SELECT 1 FROM msdb.sys.tables WHERE name = 'sysssispackages')
BEGIN
    EXEC('
    SELECT
        f.foldername AS FolderName,
        p.name AS PackageName,
        p.description,
        SUSER_SNAME(p.ownersid) AS Owner,
        p.createdate AS Created,
        p.packageformat AS PackageFormat
    FROM msdb.dbo.sysssispackages p
    LEFT JOIN msdb.dbo.sysssispackagefolders f ON p.folderid = f.folderid
    ORDER BY f.foldername, p.name;
    ')
END
ELSE
    PRINT '  No legacy SSIS packages found in msdb.'

-- ============================================================
-- 3. SQL Agent Jobs with Schedules and Step Details
-- Purpose: Full job inventory for batch processing analysis.
-- ============================================================
PRINT ''
PRINT '=== 3. SQL Agent Jobs ==='
PRINT ''

SELECT
    j.name AS JobName,
    j.description,
    j.enabled,
    SUSER_SNAME(j.owner_sid) AS JobOwner,
    c.name AS Category,
    j.date_created AS Created,
    j.date_modified AS Modified,
    -- Step count
    (SELECT COUNT(*) FROM msdb.dbo.sysjobsteps js
     WHERE js.job_id = j.job_id) AS StepCount,
    -- Schedule summary
    (SELECT TOP 1
        CASE s.freq_type
            WHEN 1  THEN 'Once'
            WHEN 4  THEN 'Daily'
            WHEN 8  THEN 'Weekly'
            WHEN 16 THEN 'Monthly'
            WHEN 32 THEN 'Monthly Relative'
            WHEN 64 THEN 'Agent Start'
            WHEN 128 THEN 'Idle'
        END
     FROM msdb.dbo.sysjobschedules jsc
     JOIN msdb.dbo.sysschedules s ON jsc.schedule_id = s.schedule_id
     WHERE jsc.job_id = j.job_id) AS PrimarySchedule,
    -- Last run status
    (SELECT TOP 1
        CASE jh.run_status
            WHEN 0 THEN 'Failed'
            WHEN 1 THEN 'Succeeded'
            WHEN 2 THEN 'Retry'
            WHEN 3 THEN 'Cancelled'
        END
     FROM msdb.dbo.sysjobhistory jh
     WHERE jh.job_id = j.job_id AND jh.step_id = 0
     ORDER BY jh.run_date DESC, jh.run_time DESC) AS LastRunStatus
FROM msdb.dbo.sysjobs j
LEFT JOIN msdb.dbo.syscategories c ON j.category_id = c.category_id
ORDER BY j.name;

-- Job step details
PRINT ''
PRINT '=== 3b. Job Step Details ==='
PRINT ''

SELECT
    j.name AS JobName,
    js.step_id AS StepId,
    js.step_name AS StepName,
    js.subsystem AS StepType,
    js.database_name AS TargetDatabase,
    CASE js.on_success_action
        WHEN 1 THEN 'Quit Success'
        WHEN 2 THEN 'Quit Failure'
        WHEN 3 THEN 'Next Step'
        WHEN 4 THEN 'Step ' + CAST(js.on_success_step_id AS VARCHAR)
    END AS OnSuccess,
    CASE js.on_fail_action
        WHEN 1 THEN 'Quit Success'
        WHEN 2 THEN 'Quit Failure'
        WHEN 3 THEN 'Next Step'
        WHEN 4 THEN 'Step ' + CAST(js.on_fail_step_id AS VARCHAR)
    END AS OnFailure,
    js.retry_attempts AS Retries,
    js.retry_interval AS RetryIntervalMin,
    LEN(js.command) AS CommandLength,
    LEFT(REPLACE(REPLACE(js.command, CHAR(13), ' '), CHAR(10), ' '), 200)
        AS CommandPreview
FROM msdb.dbo.sysjobs j
JOIN msdb.dbo.sysjobsteps js ON j.job_id = js.job_id
ORDER BY j.name, js.step_id;

-- ============================================================
-- 4. Cross-Database References
-- Purpose: Map dependencies between databases on this instance.
-- ============================================================
PRINT ''
PRINT '=== 4. Cross-Database References ==='
PRINT ''

SELECT
    DB_NAME() AS SourceDatabase,
    SCHEMA_NAME(o.schema_id) AS SourceSchema,
    o.name AS SourceObject,
    o.type_desc AS SourceType,
    d.referenced_database_name AS TargetDatabase,
    d.referenced_schema_name AS TargetSchema,
    d.referenced_entity_name AS TargetObject
FROM sys.sql_expression_dependencies d
JOIN sys.objects o ON d.referencing_id = o.object_id
WHERE d.referenced_database_name IS NOT NULL
  AND d.referenced_database_name <> DB_NAME()
ORDER BY d.referenced_database_name, d.referenced_entity_name;

-- ============================================================
-- 5. Linked Server Usage
-- Purpose: Identify all remote server connections and their usage.
-- ============================================================
PRINT ''
PRINT '=== 5. Linked Servers ==='
PRINT ''

SELECT
    s.name AS LinkedServerName,
    s.product,
    s.provider,
    s.data_source,
    s.catalog AS DefaultCatalog,
    s.is_data_access_enabled AS DataAccessEnabled,
    s.is_rpc_out_enabled AS RPCEnabled,
    -- Count of objects referencing this linked server
    (SELECT COUNT(*)
     FROM sys.sql_expression_dependencies d
     WHERE d.referenced_server_name = s.name) AS UsageCount
FROM sys.servers s
WHERE s.is_linked = 1
ORDER BY s.name;

-- Objects using linked servers
PRINT ''
PRINT '=== 5b. Objects Using Linked Servers ==='
PRINT ''

SELECT
    SCHEMA_NAME(o.schema_id) AS SourceSchema,
    o.name AS SourceObject,
    o.type_desc AS SourceType,
    d.referenced_server_name AS LinkedServer,
    d.referenced_database_name AS RemoteDatabase,
    d.referenced_entity_name AS RemoteObject
FROM sys.sql_expression_dependencies d
JOIN sys.objects o ON d.referencing_id = o.object_id
WHERE d.referenced_server_name IS NOT NULL
ORDER BY d.referenced_server_name, o.name;

-- ============================================================
-- 6. Trigger Inventory
-- Purpose: Identify all triggers and their target tables.
-- ============================================================
PRINT ''
PRINT '=== 6. Triggers ==='
PRINT ''

SELECT
    SCHEMA_NAME(t.schema_id) AS TableSchema,
    OBJECT_NAME(tr.parent_id) AS TableName,
    tr.name AS TriggerName,
    tr.type_desc AS TriggerType,
    CASE tr.is_instead_of_trigger
        WHEN 1 THEN 'INSTEAD OF'
        ELSE 'AFTER'
    END AS TimingType,
    OBJECTPROPERTY(tr.object_id, 'ExecIsInsertTrigger') AS OnInsert,
    OBJECTPROPERTY(tr.object_id, 'ExecIsUpdateTrigger') AS OnUpdate,
    OBJECTPROPERTY(tr.object_id, 'ExecIsDeleteTrigger') AS OnDelete,
    tr.is_disabled AS IsDisabled,
    LEN(sm.definition) AS DefinitionLength,
    tr.create_date AS Created,
    tr.modify_date AS Modified
FROM sys.triggers tr
JOIN sys.tables t ON tr.parent_id = t.object_id
JOIN sys.sql_modules sm ON tr.object_id = sm.object_id
WHERE tr.is_ms_shipped = 0
ORDER BY OBJECT_NAME(tr.parent_id), tr.name;

-- ============================================================
-- 7. View Dependency Chains
-- Purpose: Identify views and what they depend on (potential
--          business logic in computed columns and JOINs).
-- ============================================================
PRINT ''
PRINT '=== 7. Views with Dependencies ==='
PRINT ''

SELECT
    SCHEMA_NAME(v.schema_id) AS ViewSchema,
    v.name AS ViewName,
    sm.is_schema_bound AS IsSchemaBound,
    LEN(sm.definition) AS DefinitionLength,
    -- Count referenced tables/views
    (SELECT COUNT(DISTINCT referenced_entity_name)
     FROM sys.sql_expression_dependencies d
     WHERE d.referencing_id = v.object_id) AS ReferencedObjectCount,
    -- Count objects that use this view
    (SELECT COUNT(*)
     FROM sys.sql_expression_dependencies d
     WHERE d.referenced_id = v.object_id) AS UsedByCount,
    v.create_date AS Created,
    v.modify_date AS Modified
FROM sys.views v
JOIN sys.sql_modules sm ON v.object_id = sm.object_id
WHERE v.is_ms_shipped = 0
ORDER BY ReferencedObjectCount DESC, v.name;

-- ============================================================
-- 8. Function Inventory
-- Purpose: Identify scalar, table-valued, and CLR functions.
-- ============================================================
PRINT ''
PRINT '=== 8. Functions ==='
PRINT ''

SELECT
    SCHEMA_NAME(o.schema_id) AS FunctionSchema,
    o.name AS FunctionName,
    CASE o.type
        WHEN 'FN' THEN 'Scalar'
        WHEN 'IF' THEN 'Inline Table-Valued'
        WHEN 'TF' THEN 'Multi-Statement Table-Valued'
        WHEN 'FS' THEN 'CLR Scalar'
        WHEN 'FT' THEN 'CLR Table-Valued'
    END AS FunctionType,
    ISNULL(LEN(sm.definition), 0) AS DefinitionLength,
    -- For CLR functions, show assembly info
    am.assembly_class AS CLRClass,
    am.assembly_method AS CLRMethod,
    o.create_date AS Created,
    o.modify_date AS Modified
FROM sys.objects o
LEFT JOIN sys.sql_modules sm ON o.object_id = sm.object_id
LEFT JOIN sys.assembly_modules am ON o.object_id = am.object_id
WHERE o.type IN ('FN', 'IF', 'TF', 'FS', 'FT')
  AND o.is_ms_shipped = 0
ORDER BY o.type, o.name;

-- ============================================================
-- 9. Table Sizing Summary
-- Purpose: Identify the largest tables for migration planning.
-- ============================================================
PRINT ''
PRINT '=== 9. Table Sizes (Top 50) ==='
PRINT ''

SELECT TOP 50
    SCHEMA_NAME(t.schema_id) AS TableSchema,
    t.name AS TableName,
    p.rows AS RowCount,
    CAST(SUM(a.total_pages) * 8.0 / 1024 AS DECIMAL(18,2)) AS TotalSizeMB,
    CAST(SUM(a.used_pages) * 8.0 / 1024 AS DECIMAL(18,2)) AS UsedSizeMB,
    (SELECT COUNT(*) FROM sys.columns c
     WHERE c.object_id = t.object_id) AS ColumnCount,
    (SELECT COUNT(*) FROM sys.indexes i
     WHERE i.object_id = t.object_id) AS IndexCount,
    (SELECT COUNT(*) FROM sys.triggers tr
     WHERE tr.parent_id = t.object_id) AS TriggerCount,
    CASE WHEN EXISTS (
        SELECT 1 FROM sys.partitions pp
        WHERE pp.object_id = t.object_id AND pp.partition_number > 1
    ) THEN 'Yes' ELSE 'No' END AS IsPartitioned
FROM sys.tables t
JOIN sys.partitions p ON t.object_id = p.object_id AND p.index_id IN (0, 1)
JOIN sys.allocation_units a ON p.partition_id = a.container_id
WHERE t.is_ms_shipped = 0
GROUP BY t.schema_id, t.name, t.object_id, p.rows
ORDER BY SUM(a.total_pages) DESC;

PRINT ''
PRINT '========================================================'
PRINT '  Inventory Complete'
PRINT '========================================================'

SET NOCOUNT OFF;
