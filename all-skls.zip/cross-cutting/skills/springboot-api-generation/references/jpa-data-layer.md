# JPA Data Layer Generation

Generate the data layer first (other layers depend on it). For each bounded
context, produce entities, repositories, and Flyway migration scripts.

## Entity classes (`@Entity`)
- One entity class per table from the Step 2 ER diagram
- Package: `{root}.{context}.domain.entity`
- Class-level annotations: `@Entity`, `@Table(name = "...")`, `@EntityListeners(AuditingEntityListener.class)`
- Field annotations: `@Column(name = "...", nullable = ..., length = ...)` with constraints matching DDL
- Relationship annotations: `@ManyToOne(fetch = FetchType.LAZY)`, `@OneToMany(mappedBy = "...", cascade = CascadeType.ALL)`
- Use `FetchType.LAZY` by default for all relationships — eager fetching causes N+1 queries
- Audit fields: `@CreatedDate`, `@LastModifiedDate`, `@CreatedBy`, `@LastModifiedBy`
- Implement `equals()` and `hashCode()` using business key (not database ID)
- Use `@NaturalId` where applicable for business identifiers
- Soft delete: `@SQLDelete` and `@Where` annotations if specified in architecture design

## JPA Repositories (`JpaRepository`)
- Package: `{root}.{context}.domain.repository`
- Extend `JpaRepository<Entity, ID>` with appropriate ID type
- Custom query methods using Spring Data naming conventions where possible
- `@Query` with JPQL for complex queries derived from legacy SQL in extraction artifacts
- Cite extraction rule IDs in Javadoc: `/** Implements rule: {rule-id} */`
- Specification-based queries (`JpaSpecificationExecutor`) for dynamic filtering
- Pagination support via `Pageable` parameter on all list methods

## Flyway migration scripts
- Location: `src/main/resources/db/migration/`
- Naming: `V{NNN}__{description}.sql` (e.g., `V001__create_flight_schedule.sql`)
- One migration per bounded context's initial schema
- Separate migration for indexes
- Separate migration for seed/reference data
- Include rollback comments (Flyway does not auto-rollback, but document the reversal SQL)
