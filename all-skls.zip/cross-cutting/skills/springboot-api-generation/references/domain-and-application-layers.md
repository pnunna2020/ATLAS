# Domain and Application Layer Generation

## Step 3: Domain Layer

For each bounded context, generate domain services, events, and value objects.

### Domain services (`@Service`)
- Package: `{root}.{context}.domain.service`
- One service class per aggregate root
- Business logic extracted from legacy procedures/functions, citing extraction rule IDs
- `@Transactional` on methods that modify state (read-only = true for queries)
- Input validation beyond DTO constraints (business rule validation)
- Domain event publishing via `ApplicationEventPublisher` for cross-context notifications
- `@Cacheable` / `@CacheEvict` annotations where the architecture design identifies hot data

### Domain events
- Package: `{root}.{context}.domain.event`
- One event record per state change that other contexts need to react to
- Immutable records with timestamp, actor, and payload fields
- Event naming: past tense (`OrderCreated`, `FlightScheduleUpdated`)

### Value objects
- Package: `{root}.{context}.domain.model`
- Immutable Java records for composite domain concepts
- Validation in constructor (fail-fast on invalid state)
- Override `toString()` for logging readability

## Step 4: Application Layer

For each bounded context, generate use case handlers.

### Application services
- Package: `{root}.{context}.application`
- One application service per use case group (e.g., `FlightScheduleManagement`)
- Orchestrate domain services and repositories
- No business logic here — delegate to domain layer
- Transaction boundaries at application service level
- Command/Query separation where appropriate (write methods return void or ID, read methods return DTOs)
