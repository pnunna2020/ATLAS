# REST Controllers, DTOs, and Mappers

## Step 5: REST Controllers

For each bounded context with API endpoints, generate controllers from OpenAPI specs.

### REST controllers (`@RestController`)
- Package: `{root}.{context}.api.controller`
- Class-level: `@RestController`, `@RequestMapping("/api/v1/{context}")`
- Method-level: `@GetMapping`, `@PostMapping`, `@PutMapping`, `@DeleteMapping`, `@PatchMapping`
- Path variables: `@PathVariable` with type matching OpenAPI parameter schema
- Query parameters: `@RequestParam(required = false, defaultValue = "...")` for optional params
- Request bodies: `@Valid @RequestBody` with DTO type
- Return type: `ResponseEntity<DTO>` with explicit HTTP status codes
- Pagination: Accept `Pageable` parameter for list endpoints; return `Page<DTO>`
- Swagger/OpenAPI annotations: `@Operation(summary = "...")`, `@ApiResponse`, `@Parameter`

### Exception handling (`@RestControllerAdvice`)
- Package: `{root}.shared.api.exception`
- Global exception handler mapping domain exceptions to HTTP status codes
- RFC 7807 Problem Details response format
- Exception types: `EntityNotFoundException` (404), `BusinessRuleViolationException` (422),
  `ConflictException` (409), `AccessDeniedException` (403)
- Log exception context at appropriate level (WARN for 4xx, ERROR for 5xx)

## Step 6: DTOs and Mappers

For each API endpoint, generate request/response types.

### DTOs (Java records)
- Package: `{root}.{context}.api.dto`
- Request DTOs: `Create{Entity}Request`, `Update{Entity}Request`
- Response DTOs: `{Entity}Response`, `{Entity}ListResponse`
- Bean Validation annotations: `@NotNull`, `@NotBlank`, `@Size`, `@Email`, `@Pattern`, etc.
- Validation groups: `OnCreate.class`, `OnUpdate.class` for conditional validation
- Use Java records for immutability (or classes with Lombok `@Value` if pre-Java 16 compatibility needed)

### MapStruct mappers
- Package: `{root}.{context}.api.mapper`
- Interface with `@Mapper(componentModel = "spring")`
- Entity-to-DTO and DTO-to-Entity mappings
- Custom mapping methods for complex transformations
- Null-safe mappings with `nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE`
