# Configuration, Build, and Deployment

## Step 7: Configuration

Produce Spring Boot configuration files.

### `application.yml` with profiles
- `application.yml` — shared configuration (logging format, actuator, Jackson settings)
- `application-dev.yml` — local development (H2 in-memory DB, debug logging, CORS permissive)
- `application-staging.yml` — staging environment (Aurora connection, info logging)
- `application-prod.yml` — production environment (Aurora connection, warn logging, strict CORS)
- All secrets as environment variable references: `${DB_PASSWORD}`, `${OKTA_CLIENT_SECRET}`

### Security configuration (`@EnableWebSecurity`)
- Package: `{root}.shared.config`
- OAuth2 Resource Server configuration with OKTA JWT validation
- CORS configuration matching client profile allowed origins
- CSRF disabled for stateless API (with comment explaining why)
- Endpoint-level authorization rules from architecture security spec
- Actuator endpoints secured (health public, others require admin role)

### Actuator configuration
- Health endpoint: `/actuator/health` (public, includes DB and custom health indicators)
- Info endpoint: `/actuator/info` (includes build info, git commit)
- Metrics endpoint: `/actuator/metrics` (secured, Datadog-compatible)
- Prometheus endpoint: `/actuator/prometheus` (if Datadog agent scrapes Prometheus format)

## Step 8: Build and Deployment Files

### `pom.xml` (Maven) or `build.gradle` (Gradle)
- Parent: `spring-boot-starter-parent:3.x` (version from client profile)
- Dependencies: spring-boot-starter-web, spring-boot-starter-data-jpa,
  spring-boot-starter-validation, spring-boot-starter-security,
  spring-boot-starter-oauth2-resource-server, spring-boot-starter-actuator,
  flyway-core, mapstruct, springdoc-openapi
- Test dependencies: spring-boot-starter-test, h2 (test scope), testcontainers
- Compiler plugins: maven-compiler-plugin (Java 21), mapstruct-processor

### Dockerfile
- Multi-stage build: build stage (Maven/Gradle) + runtime stage (Eclipse Temurin JRE 21)
- Non-root user for runtime
- Health check instruction using actuator endpoint
- Environment variable declarations for all config placeholders
- `.dockerignore` to exclude unnecessary files

### README.md (build/run instructions only)
- Prerequisites (Java 21, Maven/Gradle, Docker)
- Build command (`mvn clean package` or `./gradlew build`)
- Run locally command (with environment variable examples)
- Run with Docker command
- API documentation URL (Swagger UI path)
