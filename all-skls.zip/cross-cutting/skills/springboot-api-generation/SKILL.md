---
name: springboot-api-generation
description: >
  Generate production-ready Java Spring Boot REST APIs, service layers, JPA repositories,
  and infrastructure configuration from extraction artifacts and abstract scaffolds.
  Use during P4.3 Generate step for applications targeting Spring Boot 3.x archetype.
  Triggers on Spring Boot generation, Java API generation, JPA generation, Spring REST,
  or Java 21 code generation mentions.
agent: sonnet
allowed-tools:
  - Read
  - Write
  - Bash
  - Grep
---

# Spring Boot API Generation

## Purpose
Generate production-ready Java 21 / Spring Boot 3.x code from extraction artifacts
and the abstract scaffold produced by `code-generation-abstract`. This skill produces
compilable, convention-following Spring Boot applications with REST controllers,
service layers, JPA data access, DTOs, configuration, and Dockerized deployment —
ready for the Ralph Loop (tdd-generation) to validate through test-driven iteration.

This skill is invoked after `code-generation-abstract` has produced the project
scaffold and implementation plan. It replaces TODO stubs with real Spring Boot
implementation code, following the generation order specified in the implementation
plan (data layer -> domain layer -> application layer -> API layer).

## Inputs
- `code-generation-abstract` output (project scaffold, implementation plan, traceability index)
- Extraction artifact from Step 1 (business rules YAML, test scenarios, module inventory)
- Target architecture blueprint from Step 2 (must specify Spring Boot archetype)
- OpenAPI 3.x specifications from `api-specification` skill
- Data models and DDL from `data-modeling` skill
- Risk tier (T1, T2, T3) from Rationalization

## Outputs
- Complete Maven or Gradle project structure with all Java source files
- REST controllers with full endpoint implementations
- Service layer with business logic from extracted rules
- JPA entities, repositories, and custom queries
- Request/Response DTOs with Bean Validation annotations
- MapStruct mapper interfaces
- `application.yml` with profiles (dev, staging, prod)
- Spring Security configuration (OKTA OAuth2 integration)
- Flyway migration SQL files
- `pom.xml` or `build.gradle` with all dependencies
- Dockerfile for the Spring Boot application
- Integration test stubs for every endpoint
- README with build/run instructions

## Methodology

### Step 1: Validate Scaffold and Load Inputs
Read the abstract scaffold from `code-generation-abstract`. Validate that:
1. The scaffold specifies Spring Boot as the target framework
2. Maven/Gradle project structure exists with proper directory layout
3. The implementation plan lists modules in dependency-respecting order
4. OpenAPI specs are available for all bounded contexts with API endpoints

Load the extraction artifact and map business rules to bounded contexts using
the traceability index from the scaffold.

### Step 2: Generate JPA Data Layer
Generate JPA entities, repositories, and Flyway migrations per bounded context,
with lazy fetch defaults, business-key `equals/hashCode`, and audit fields.

See `references/jpa-data-layer.md` for entity annotations, repository patterns,
and Flyway naming conventions.

### Steps 3-4: Generate Domain and Application Layers
Generate domain services (per aggregate root, with `@Transactional` on writes),
domain events (immutable records, past-tense names), value objects, and
application services (orchestration only, no business logic).

See `references/domain-and-application-layers.md` for layering rules, event
shape, and transaction-boundary guidance.

### Steps 5-6: Generate REST Controllers, DTOs, and Mappers
Generate controllers from OpenAPI specs (with pagination, validation, and
OpenAPI annotations), a global `@RestControllerAdvice` exception handler
producing RFC 7807 responses, Bean-Validated DTOs, and MapStruct mappers.

See `references/rest-controllers-and-dtos.md` for controller, exception
handler, DTO, and MapStruct conventions.

### Steps 7-8: Generate Configuration, Build, and Deployment Files
Produce profile-based `application.yml`, Spring Security (OKTA OAuth2)
configuration, secured Actuator endpoints, a multi-stage Dockerfile, and
build files (Maven or Gradle) with the approved dependency set.

See `references/configuration-and-deployment.md` for profile layout, security
config, actuator exposure, Dockerfile, and build-file contents.

## Tech-Stack Dispatch
This skill targets a single technology stack. Before generating, validate that
the target architecture specifies one of these Spring Boot configurations:

| Configuration | Java Version | Spring Boot | Build Tool | Notes |
|--------------|:------------:|:-----------:|:----------:|-------|
| Standard | Java 21 | 3.2+ | Maven | Default for most applications |
| Reactive | Java 21 | 3.2+ | Maven | WebFlux for high-throughput async APIs |
| Gradle | Java 21 | 3.2+ | Gradle | When client profile specifies Gradle |

If the architecture blueprint specifies a non-Spring Boot target (FastAPI, .NET, Node.js),
this skill should NOT be invoked. Check the tech stack before proceeding.

## Disposition Context
This skill applies to applications dispositioned as:
- **Refactor**: Legacy Java EE (Struts, JSF, EJB) modernized to Spring Boot 3.x
- **Rearchitect**: Non-Java legacy (ColdFusion, Classic ASP, PHP) rewritten in Spring Boot

For Refactor dispositions, preserve existing Java naming conventions and package
structure where possible. For Rearchitect dispositions, use clean-slate Spring Boot
conventions with no legacy naming carryover.

## Gotchas
- **Constructor injection only**: Never use `@Autowired` on fields. All dependencies
  must be injected via constructor. Use `@RequiredArgsConstructor` (Lombok) or
  explicit constructors. Field injection makes testing harder and hides dependencies.
- **Lazy fetch by default**: All JPA relationships must use `FetchType.LAZY`. Eager
  fetching causes N+1 query problems that only surface under load. Use `@EntityGraph`
  or join fetch in specific queries when eager loading is needed.
- **equals/hashCode on business key**: Never use `@Id` (database-generated) for
  equals/hashCode. Use natural business identifiers. This prevents Hibernate proxy
  issues and collection behavior bugs.
- **Transactions at application service level**: Domain services should not declare
  `@Transactional`. Transaction boundaries belong on application service methods
  that orchestrate multiple domain operations.
- **No business logic in controllers**: Controllers validate input, call application
  services, and map responses. Business rules live in domain services. If a controller
  method exceeds 15 lines, logic is leaking into the wrong layer.
- **Flyway naming is strict**: Migration files must follow `V{NNN}__{description}.sql`
  exactly. Wrong naming causes Flyway to skip migrations silently.
- **MapStruct over manual mapping**: Never write manual entity-to-DTO mapping code.
  MapStruct generates type-safe mappers at compile time with better performance
  and fewer bugs than manual mapping.
- **Secrets are never in application.yml**: Database passwords, OKTA client secrets,
  API keys must be environment variable references (`${...}`). CyberArk integration
  provides secrets at runtime. Hardcoded secrets fail security scan at G-04c.

## Quality Rules
- [ ] Generated code compiles with `mvn compile` (or `./gradlew compileJava`) without errors — syntactically valid Java 21
- [ ] All endpoints have corresponding integration test stubs using `@SpringBootTest` and `MockMvc`
- [ ] JPA entities implement `equals()` and `hashCode()` using business key, not database ID
- [ ] No field injection — all dependencies use constructor injection (`@RequiredArgsConstructor` or explicit constructor)
- [ ] All JPA relationships use `FetchType.LAZY` by default
- [ ] Code follows Google Java Style Guide conventions (4-space indent, braces on same line, etc.)
- [ ] Every service method has Javadoc citing the extraction rule ID(s) it implements
- [ ] `application.yml` profiles exist for dev, staging, and prod — no hardcoded secrets
- [ ] Flyway migration files follow `V{NNN}__{description}.sql` naming convention
- [ ] DTOs use Bean Validation annotations matching OpenAPI spec constraints
- [ ] MapStruct mappers exist for all entity-to-DTO conversions — no manual mapping
- [ ] Dockerfile uses multi-stage build with non-root runtime user
- [ ] Global exception handler produces RFC 7807 Problem Details responses
- [ ] OKTA OAuth2 Resource Server configuration is present in security config
- [ ] Actuator health/info/metrics endpoints are configured and secured appropriately
- [ ] No controller method exceeds 15 lines of logic — business rules are in domain services

## Common Failure Modes
| Failure Mode | Symptom | Prevention |
|-------------|---------|------------|
| Field injection | `@Autowired` on fields; tests require Spring context for every unit test; hidden dependencies | Search-and-reject `@Autowired` on fields; require constructor injection |
| Eager fetch N+1 | API response times degrade exponentially with data volume; database query count explodes | Default all relationships to `FetchType.LAZY`; use `@EntityGraph` for specific queries |
| Business logic in controllers | Controller methods exceed 15 lines; same logic duplicated across endpoints | Enforce layer boundaries; controllers only validate, delegate, and map |
| Wrong equals/hashCode | Entities misbehave in Sets and Maps; duplicate entries in collections; Hibernate merge issues | Implement equals/hashCode on natural business key; never use database ID |
| Hardcoded secrets | Security scan at G-04c flags credentials in source; deployment requires code change for each environment | Use `${ENV_VAR}` placeholders exclusively; run secret scan before handoff |
| Flyway migration naming | Migrations silently skipped; database schema out of sync with entities; runtime errors | Validate migration file naming matches `V{NNN}__{description}.sql` exactly |
| Manual DTO mapping | Entity fields added but mapper not updated; NPE in production on new fields | Use MapStruct for all entity-DTO conversions; compile-time safety catches missing fields |
| Missing transaction boundary | Partial writes committed when domain service throws; data corruption | Declare `@Transactional` on application service methods, not domain services |

## Handoff Summary
When this skill completes, verify:
1. `mvn compile` (or `./gradlew compileJava`) passes with zero errors
2. All REST endpoints match the Step 2 OpenAPI specification (paths, methods, status codes)
3. JPA entities match the Step 2 ER diagram (tables, columns, relationships)
4. Every service method cites extraction rule IDs in Javadoc
5. Integration test stubs exist for every endpoint
6. Security configuration uses OKTA OAuth2 Resource Server
7. Flyway migrations create the target schema
8. Dockerfile builds and runs the application
Then proceed to: `tdd-generation` (P4.3) for Ralph Loop test-driven validation, `security-scan-review` for static analysis, and gate `G-04c` for generation quality review
