# 13 — The Generation Engine: Extract → Design → Generate factory + the Ralph Loop

**Atomic regeneration spec.** Behavioral parity is the bar. Everything below is derived from live code at `/Users/pnunna/Documents/GitHub/olympus`. Cite `path:line`. The canonical files:

- `temporal/olympus_workflows/workflows/generate_bc.py` (324 LOC) — the Ralph Loop child workflow (`GenerateBCWorkflow`).
- `temporal/olympus_workflows/workflows/modernization.py` (2813 LOC) — brownfield line; §`_execute_generate` at :1703, `_parse_bounded_contexts` at :2095, `parse_bc_names_from_yaml` at :2771.
- `temporal/olympus_workflows/workflows/build.py` (759 LOC) — greenfield (net-new) line `BuildWorkflow`; Spec → Design → Generate.
- `temporal/olympus_workflows/activities/line_transitions/modernization.py` (450 LOC) — `persist_modernization_side_effects` (G-04a/b/c DB projection).
- `temporal/olympus_workflows/activities/line_transitions/governance.py` (600 LOC) — pattern-extraction projection (flywheel side-effects).
- `olympus-agent-runtime/src/services/agent_executor.py` (2601 LOC) — the actual code-generation engine: `execute_skill` (:1721), `build_system_prompt` (:218), validation + repair continuations.
- `temporal/olympus_workflows/types.py` — constants + dataclasses.
- `temporal/olympus_workflows/composition/registered.py` / `evaluator.py` — code-generation skill variant selection.

---

## 0. Constants (exact values — reproduce verbatim)

From `types.py`:
- `MAX_BC_CHILDREN_PER_APP = 12` (:135)
- `MAX_RALPH_ITERATIONS = 10` (:136)
- `MAX_CONCURRENT_WAVES = 4`, `MAX_APPS_PER_WAVE = 10`, `MAX_VALIDATION_STREAMS = 4` (:133–137)

From `build.py`:
- `MAX_REWORK_ITERATIONS = 3` (:63)
- `MAX_BC_CHILDREN_PER_APP = 12` (:65) — a **local re-declaration** in build.py, same value.
- `_FRONTEND_BC_NAMES = {"frontend", "ui", "web-app", "spa"}` (:67)

From `modernization.py`:
- `MAX_REWORK_ITERATIONS = 3` (:201)
- Inside `_execute_generate`, local `_FRONTEND_BC_NAMES = {"frontend", "ui", "web-app", "spa"}` (:1774), `_DEFAULT_BACKEND_FRAMEWORK = "express"` (:1775), `_DEFAULT_FRONTEND = "react"` (:1776). **GOTCHA:** these frontend/default constants are redefined *inside the while-loop body*, not module-level — they re-materialise every rework iteration but the values are constant.

From `agent_timeouts.py`: `AGENT_START_TO_CLOSE = timedelta(hours=3)` (:67).

From `retry_policies.py`:
- `AGENT_FAILURE_RETRY_POLICY`: `initial_interval=5s`, `backoff_coefficient=2.0`, `maximum_interval=60s`, `maximum_attempts=3` (:38–43).
- `TRANSIENT_RETRY_POLICY = HTTP_RETRY_POLICY` (3 retries, exp backoff 1–15s) (:34).
- `RETRY_POLICIES["agent_failure"]`, `["transient"]`, `["validation_failure"]` (max_attempts=1), `["timeout"]` (max 2) (:110–114).

---

## 1. The factory shape — two lines, one shared Generate

There are **two** production lines that end in a Generate phase driven by the same `GenerateBCWorkflow` child:

| Line | Workflow | Trigger | Phases (gates) |
|---|---|---|---|
| **Modernization** (brownfield) | `ModernizationWorkflow` | any of 7 legacy dispositions | Extract (G-04a) → Design (G-04b) → Generate (G-04c) |
| **Build** (greenfield/net-new) | `BuildWorkflow` | `Build` disposition | Spec-from-Requirements (G-NEW-1) → Design (G-NEW-2) → Generate (G-NEW-3) |

Build is a **dedicated sibling `LineWorkflowBase` subclass, NOT a generalization** of Modernization (`build.py:21–29` design note). The reuse that matters happens at the **skill layer and the `GenerateBCWorkflow` child layer** — both lines fan out the *same* Ralph Loop child; only the surrounding gate scaffolding, artifact paths, and phase-1 differ. Modernization phase-1 = legacy Extract (business rules trace to extracted code); Build phase-1 = Spec-from-Requirements (business rules trace to `FR-xxx` requirement items, no legacy source; `build.py:8–19`).

### 1.1 Generate step, Modernization (`modernization.py:_execute_generate` :1703)

`_execute_generate(input, app_id, repo, source_repo, run_suffix, workspace_key) -> str`. `branch = f"olympus/modernization/generate/{app_id}/{run_suffix}"` (:1713). Returns `"approved" | "cancelled" | "failed"`.

Structured pseudocode — preserve every branch:

```
generate_base = sum of STEP_WEIGHTS for
    extract, cross-validation, extract-commit, extract-gate,
    design, design-commit, design-gate            # :1714
# One-time DevSecOps profile resolution (before the loop; reused across reworks):
if not self._devsecops_params:                     # :1729
    ds = execute_activity(resolve_devsecops_profile,
                          ResolveDevSecOpsProfileInput(profile_id=input.portfolio_id or ""),
                          timeout=30s, retry=transient)
    self._devsecops_params = {sast_tool, sbom_required, container_base,
                              license, target_cloud, primary_ecosystem, iac, cicd}  # :1739

while True:                                        # G-04c rework loop  :1750
    set_step("generate", generate_base)
    bc_names = await _parse_bounded_contexts(repo, app_id)   # :1758 (see §3)

    # -- Fan-out: one GenerateBCWorkflow child per BC, capped at 12 --
    bc_tasks = []
    for bc_name in bc_names[:MAX_BC_CHILDREN_PER_APP]:        # :1779
        bc_name_lower = bc_name.lower()
        if bc_name_lower in {"frontend","ui","web-app","spa"}:  # :1781
            bc_framework = None
            bc_frontend  = input.target_frontend or "react"     # :1783
        else:
            bc_framework = input.target_framework or "express"  # :1785
            bc_frontend  = None
        bc_input = GenerateBCInput(app_id, bc_name, wave_id, portfolio_id,
                                   artifact_repo=repo, source_repo=source_repo,
                                   design_artifacts=self._collect_design_artifacts(),
                                   target_framework=bc_framework,
                                   target_frontend=bc_frontend,
                                   primary_language=input.primary_language)   # :1788
        bc_tasks.append(execute_child_workflow(
            "GenerateBCWorkflow", bc_input,
            id=f"generate-bc-{app_id}-{bc_name}-{run_suffix}",
            task_queue=info().task_queue))                       # :1800
    raw_results = await asyncio.gather(*bc_tasks)                # :1809  ALL children in parallel
    bc_results  = [GenerateBCResult(**r) if isinstance(r,dict) else r for r in raw_results]  # :1811
    self._generate_results = list(bc_results)

    # -- Post-fan-out chain (all direct _dispatch_agent, sequential) --
    synthesis = _dispatch_agent(app_id, "synthesis", skill_id="code-synthesis",
                 input_artifacts=[a for r in bc_results for a in r.output_artifacts],
                 source_repo, workspace_key)                     # :1822
    _dispatch_agent(app_id, "adversarial-review", skill_id="adversarial-review",
                 input_artifacts=synthesis.output_artifacts, ...) # :1840
    _dispatch_agent(app_id, "security-posture-review",
                 skill_id="security-posture-review",
                 input_artifacts=synthesis.output_artifacts, ...) # :1854  (reasons about design intent)
    try:                                                          # :1870  best-effort
        _dispatch_agent(app_id, "security-scan-review",
                 skill_id="security-scan-review",
                 input_artifacts=synthesis.output_artifacts, ...) # :1871  (triages SAST/SCA output)
    except Exception: log warning (non-fatal)                     # :1879
    _dispatch_agent(app_id, "iac-scaffolding", skill_id="iac-scaffolding-generator",
                 input_artifacts=synthesis.output_artifacts, ...) # :1896
    _dispatch_agent(app_id, "gate-review-package",
                 skill_id="gate-review-package",
                 input_artifacts=synthesis.output_artifacts, ...) # :1906

    artifact_paths = await _commit_generate_artifacts(repo, branch, app_id, bc_results)  # :1923

    # -- Deterministic DevSecOps baseline validator (gates G-04c) --
    baseline = execute_activity(validate_devsecops_baseline,
                 ValidateDevSecOpsBaselineInput(app_id,
                     committed_files=list(self._committed_baseline_files),
                     sast_tool=self._devsecops_params.get("sast_tool","codeql")),
                 timeout=60s, retry=transient)                    # :1935
    if not baseline.passed:                                       # :1948
        reset g04c EA + security stakeholder flags
        _bump_rework("G-04c")
        if _rework_count("G-04c") > 3:                            # :1961
            status=FAILED; update_app_status(app_id,"modernization_failed",
                "generate-baseline-incomplete","Modernization"); return "failed"
        continue                                                  # :1972 restart Generate

    # -- PR + gate G-04c --
    pr_result   = _create_generate_pr(repo, branch, app_id, bc_results)  # :1975
    gate_record = create_gate_record(gate_type="G-04c", ..., evidence_package_url=pr_result.pr_url)  # :1979
    _submit_gate_evidence(gate_record.gate_id, G_04C, app_id, artifact_paths, pr_url, "Modernization", "generate")  # :1992
    if workflow.patched("modernization-gate-pre-review-v1"):      # :2002
        _run_gate_pre_review(gate_id, "G-04c", artifact_paths, artifact_repo=repo, artifact_ref=branch)
    else:
        _mark_ready_for_review(gate_id)
    update_app_status(app_id,"gate_review","generate-gate-review","Modernization")
    decision = await _wait_for_gate_decision(G_04C)               # :2028 blocks on signal

    if decision == "cancelled": return "cancelled"                # :2030
    if decision == "approved":                                    # :2033
        if self._risk_tier == 1:                                  # :2041 Tier-1 triple-signal
            await wait_condition(lambda:
                (self._g04c_stakeholder_ea_approved and
                 self._g04c_stakeholder_security_approved) or self.cancelled)
            if self.cancelled: status=CANCELLED; return "cancelled"
        package_content = _find_output_file_content("gate-review-package")  # :2059
        await _persist_side_effects(app_id, "generate",
                 gate_review_package_json=package_content)         # :2062 (see §5)
        await _reconcile_and_merge_with_retry_loop(repo, pr_result.pr_number, gate_record.gate_id)  # :2069
        return "approved"

    # decision == "rejected" -> rework                            # :2076
    reset g04c EA + security stakeholder flags                    # :2079
    _bump_rework("G-04c")
    if _rework_count("G-04c") > 3:                                # :2083
        status=FAILED; update_app_status(app_id,"modernization_failed",
            "generate-max-rework-exceeded","Modernization"); return "failed"
    # loop again
```

**Two distinct G-04c rework exits** (both cap at `> MAX_REWORK_ITERATIONS = 3`, i.e. 4 attempts): baseline-incomplete (:1961, step `generate-baseline-incomplete`) and gate-rejected (:2083, step `generate-max-rework-exceeded`). Both flip app status to `modernization_failed` and return `"failed"`.

**GOTCHA (:2002):** the gate-pre-review call is guarded by `workflow.patched("modernization-gate-pre-review-v1")`. Old (unpatched) histories take the `_mark_ready_for_review` path. This is a Temporal versioning branch — any replay of a pre-patch workflow MUST take the else-branch, so both branches must exist forever.

**GOTCHA (:1809):** `asyncio.gather(*bc_tasks)` runs all ≤12 children concurrently; if any child *raises* (as opposed to returning an escalated/abandoned result), `gather` propagates it and the whole Generate step fails/retries. Children never raise on Ralph exhaustion — they return a `GenerateBCResult` with `status="escalated"|"abandoned"|"cancelled"` (see §2).

### 1.2 Generate step, Build (`build.py:_execute_generate` :445)

`branch = f"olympus/build/generate/{app_id}/{run_suffix}"` (:454). Structurally similar to Modernization but simpler post-fan-out chain and one critical extra step — **it commits the children's generated source files to the repo before synthesis**:

```
while True:                                                       # G-NEW-3 rework loop  :455
    set_step("generate", 70.0)
    bc_names = await _parse_bounded_contexts(repo, app_id)        # :457 (Build variant, §3)
    design_artifacts = _collect_design_artifacts()                # :458
    for bc_name in bc_names[:12]:                                 # :461
        is_frontend = bc_name.lower() in _FRONTEND_BC_NAMES
        bc_input = GenerateBCInput(app_id, bc_name, wave_id, portfolio_id,
                     artifact_repo=repo, source_repo="",          # :469 greenfield: NO legacy tree
                     design_artifacts=design_artifacts,
                     target_framework=(None if is_frontend else input.target_framework),  # :471
                     target_frontend=(input.target_frontend if is_frontend else None),
                     primary_language=input.primary_language)
        bc_tasks.append(execute_child_workflow("GenerateBCWorkflow", bc_input,
                     id=f"generate-bc-{app_id}-{bc_name}-{run_suffix}",
                     task_queue=info().task_queue))               # :480
    raw = await asyncio.gather(*bc_tasks)                         # :488
    self._generate_results = [GenerateBCResult(**r) if dict else r for r in raw]

    # -- Persist the children's OUTPUT FILES to the repo BEFORE synthesis --  :507
    bc_code_files=[]; bc_code_paths=[]
    for r in self._generate_results:
        for f in (r.output_files or []):
            if not f.path: continue
            repo_path = f"build/{app_id}/generate/code/{r.bc_name}/{f.path}"  # :513
            bc_code_files.append((repo_path, f.content)); bc_code_paths.append(repo_path)
    if bc_code_files:                                             # :518
        execute_activity(write_artifacts_batch, WriteArtifactsBatchInput(
             repo, branch, files=bc_code_files,
             commit_message=f"build({app_id}): generated source ({N} files)",
             execution_context=...), timeout=180s, retry=transient,
             activity_id=f"commit-generate-code-{run_suffix}")    # :519

    synthesis = _dispatch_agent(app_id,"synthesis", bc_code_paths,   # :539 note: paths, not free-text
                 workspace_key, artifact_repo=repo, artifact_ref=branch)
    _commit_step_artifacts(repo,branch,app_id,"synthesis",synthesis, "build/{app_id}/generate/synthesis.json")
    committed = list(self._step_committed_paths.get("synthesis",[synth_path]))
    synth_inputs = list(committed)                                # :560

    adversarial = _dispatch_agent(app_id,"adversarial-review", synth_inputs,
                    ..., artifact_ref=branch)                     # :563
    _commit_step_artifacts(...,"adversarial-review",...)
    committed.extend(...)
    try:                                                          # :577 best-effort
        sec = _dispatch_agent(app_id,"security-scan-review", synth_inputs, ..., artifact_ref=branch)  # :579
        _commit_step_artifacts(...); committed.extend(...)
    except Exception: log warning (non-fatal)                     # :593

    decision, pr_number, gate_id = await _run_one_gate(input, repo, branch,
        gate_type=G_NEW_3, gate_key="G-NEW-3", step="synthesis",
        artifact_paths=committed, pr_title=..., pr_body=...)      # :598 (see §1.3)
    if decision == "cancelled": status=CANCELLED; return "cancelled"
    if decision == "approved":
        if self._risk_tier == 1:                                  # :614 EA + security double-signal
            await wait_condition(lambda:
              (self._g_new_3_ea_approved and self._g_new_3_security_approved) or self.cancelled)
            if self.cancelled: status=CANCELLED; return "cancelled"
        await _reconcile_and_merge_with_retry_loop(repo, pr_number, gate_id, merge_method="merge")
        return "approved"
    reset g_new_3 EA + security flags                             # :632
    _bump_rework("G-NEW-3")
    if _rework_count("G-NEW-3") > 3: return await _fail_max_rework(app_id,"generate")  # :635
```

**GOTCHA (:494–517, Build):** the Ralph-Loop children ran in **ephemeral workspaces** (Build's child dispatches carry no shared `workspace_key`), so their generated files survive ONLY as `GenerateBCResult.output_files` (path+content pairs in *workflow memory*) — they are NOT in the repo and NOT in synthesis' workspace. `output_artifacts` is the code-gen agent's **free-text summary**, NOT file paths. Feeding `output_artifacts` as synthesis `input_artifacts` makes the runtime's `_fetch_input_artifacts` try to fetch prose as a repo path and hard-fail. The fix is to commit the real files first, then hand synthesis the committed **repo paths** with `artifact_ref=branch` (the paths are on the build branch, not merged to default). Modernization avoids this because its children share the source_repo and its `_commit_generate_artifacts` handles persistence; **any reimplementation of Build MUST commit child output_files before synthesis.**

### 1.3 `_run_one_gate` (Build, :642) — one step→PR→gate cycle

Returns `(decision, pr_number, gate_id)`. Steps (all sequential):
1. `_create_gate_pr(repo, branch, app_id, gate_type.value, pr_title, pr_body)` → `pr_result` (:663).
2. `create_gate_record(CreateGateRecordInput(gate_type, app_id, portfolio_id, workflow_id, evidence_package_url=pr_result.pr_url))`, timeout 30s, transient retry (:667).
3. `_submit_gate_evidence(gate_id, gate_type, app_id, artifact_paths, pr_url, "Build", step)` (:680).
4. `_run_gate_pre_review(gate_id, gate_type.value, artifact_paths, artifact_repo=repo, artifact_ref=branch)` (:689). **No `workflow.patched` guard here** (Build is new; no legacy histories).
5. `_update_app_status(app_id, "gate_review", f"{gate_key.lower()}-review", "Build")` (:696).
6. `decision = await _wait_for_gate_decision(gate_type)` (:699) — blocks on the gate signal.

### 1.4 Build phase-1 / phase-2 (context for the factory)

- **Spec (G-NEW-1, `_execute_spec` :292):** reads three CROSS-LINE priors from the **portfolio** repo (`self._artifact_repo`, NOT the target `repo`): `build/{app_id}/requirements/requirements-capability.json`, `architecture/{app_id}/architecture-blueprint.json`, `data/{app_id}/data-architecture.json` (:298–302). Dispatches `spec-from-requirements`, commits to `build/{app_id}/specs/spec-from-requirements.json`, runs gate. Tier-1 requires a single SME `stakeholder_approved(scope="g-new-1-stakeholder")` signal (:353). Rework cap 3.
- **Design (G-NEW-2, `_execute_design` :378):** iterates the four **source-agnostic** design sub-steps in order `_DESIGN_STEPS = ["module-design","api-specification","data-modeling","traceability-audit"]` (:125), each committed to `build/{app_id}/design/{step}.json`, one shared gate. Rework cap 3.

**Repo-routing rule (:236–256, Build; mirrors Modernization :682):** ALL of the line's own deliverables (spec/design/code/tests/devsecops) AND its gate PRs live in the per-target application repo (`repo = input.target_repo_url or input.artifact_repo`). The portfolio `artifact_repo` is the READ repo for the three cross-line priors ONLY. `_dispatch_agent(artifact_repo=...)` selects what the agent READS; `_commit_step_artifacts(repo=...)` selects where output LANDS.

**GOTCHA (defensive-output handling, all phases):** downstream steps read the **committed file paths** (`self._step_committed_paths.get(step, [default])`), never `result.output_artifacts` (the agent's free-text prose summary). Feeding prose as `input_artifacts` hard-fails `_fetch_input_artifacts`. See `build.py:327–333`, `:405–413`, `:552–560`.

---

## 2. The Ralph Loop — `GenerateBCWorkflow` (`generate_bc.py`)

A `@workflow.defn` extending `HILSignalsMixin` (:54–55). One instance per bounded context, spawned as a child by both lines. Input `GenerateBCInput`, output `GenerateBCResult`.

### 2.1 Instance state (`__init__` :63) — lives on the workflow instance (durable in Temporal history)

```
_bc_name="", _app_id="", _status=WorkflowStatus.PENDING, _current_step="",
_iteration=0, _started_at="", _updated_at="",
# Escalation state:
_escalation_id="", _escalation_resolved=False,
_escalation_resolution="", _escalation_resolution_type=None
```

`GenerateBCInput` fields (`types.py:2801`): `app_id, bc_name, wave_id, portfolio_id, artifact_repo="", source_repo="", module_map="", design_artifacts=[], target_framework=None, target_frontend=None, primary_language=None`.

`GenerateBCResult` fields (`types.py:2831`): `bc_name, status="completed", test_results=[], iteration_count=0, escalation_id="", output_artifacts=[], output_files=[]`. `status` domain observed in code: `completed | escalated | abandoned | cancelled` (and doc `failed`).

### 2.2 `run(input)` — the loop (`generate_bc.py:79`)

Exact pseudocode — every step, branch, early-return preserved:

```
run(input) -> GenerateBCResult:                                  # :79
    _status = RUNNING; _started_at = now_iso(); _updated_at = _started_at
    _bc_name = input.bc_name; _app_id = input.app_id; _iteration = 0
    all_output_artifacts=[]; all_output_files=[]; test_results=[]  # accumulate ACROSS iterations  :96

    while _iteration < MAX_RALPH_ITERATIONS:                      # 10  :100
        _iteration += 1
        _current_step = f"ralph-loop-{_iteration}"; _updated_at = now_iso()

        # -- STEP 1: write tests from specifications --           :106
        tdd_result = execute_activity(dispatch_agent_task,
            AgentTaskInput(task_type=f"generate-tdd-{bc_name}", app_id, skill_id="tdd-generation",
                           input_artifacts=input.design_artifacts, source_repo=input.source_repo),
            start_to_close_timeout=AGENT_START_TO_CLOSE(3h),
            retry_policy=RETRY_POLICIES["agent_failure"],
            activity_id=f"tdd-{bc_name}-iter{_iteration}")

        # -- STEP 2: generate code to pass the tests --           :120
        # Resolve code-generation skill variant at dispatch time:
        code_generation_skill_id = select_skill(
            CODE_GENERATION_COMPOSITION,
            code_generation_selector_inputs(input.target_framework,
                                            input.target_frontend,
                                            input.primary_language)
        ) or "code-generation"                                   # :131  fallback to generic
        code_result = execute_activity(dispatch_agent_task,
            AgentTaskInput(task_type=f"generate-code-{bc_name}", app_id,
                           skill_id=code_generation_skill_id,
                           input_artifacts=tdd_result.output_artifacts,   # tests feed code step
                           source_repo=input.source_repo),
            start_to_close_timeout=AGENT_START_TO_CLOSE(3h),
            retry_policy=RETRY_POLICIES["agent_failure"],
            activity_id=f"codegen-{bc_name}-iter{_iteration}")

        # -- STEP 3: run the tests --                             :156
        test_result = execute_activity(dispatch_agent_task,
            AgentTaskInput(task_type=f"test-validation-{bc_name}", app_id,
                           skill_id="test-validation",
                           input_artifacts=code_result.output_artifacts,  # code feeds test step
                           source_repo=input.source_repo),
            start_to_close_timeout=timedelta(minutes=15),        # :166  NOT 3h — tighter
            retry_policy=RETRY_POLICIES["agent_failure"],
            activity_id=f"test-{bc_name}-iter{_iteration}")

        test_results.extend(test_result.output_artifacts)        # :171 accumulate
        all_output_artifacts.extend(code_result.output_artifacts)
        all_output_files.extend(code_result.output_files)

        # -- STEP 4: did all tests pass? --                       :175
        raw_status = test_result.status
        if isinstance(raw_status, list): raw_status = "".join(raw_status)   # :179 GOTCHA
        tests_passed = (str(raw_status) == TaskStatus.COMPLETED.value    # "completed"
                        and not test_result.error)                # :181
        if tests_passed:                                          # :185
            _status=COMPLETED; _current_step="completed"; _updated_at=now_iso()
            return GenerateBCResult(bc_name, status="completed",
                test_results=test_results, iteration_count=_iteration,
                output_artifacts=all_output_artifacts, output_files=all_output_files)
        # else: tests failed -> continue the while loop (next iteration)  :198

    # -- Loop exhausted (MAX_RALPH_ITERATIONS reached) --         :200
    return await _handle_escalation(input, test_results, all_output_artifacts)
```

**Stop conditions (exactly three):**
1. **Success:** step-3 `test-validation` returns `status=="completed"` AND `error` is falsy → return immediately with `status="completed"`, `iteration_count = current iteration` (:185).
2. **Exhaustion:** loop runs full `MAX_RALPH_ITERATIONS = 10` iterations without a pass → falls through to escalation (:200).
3. **Cancellation:** only observable while *waiting* in escalation (`self.cancelled`), not mid-loop.

**State carried between iterations:** `test_results`, `all_output_artifacts`, `all_output_files` accumulate across ALL iterations (extend, never reset). `_iteration` monotonically increases. There is **NO feedback of the failing test output into the next TDD/codegen dispatch** at the workflow level — each iteration re-runs `tdd-generation` from `input.design_artifacts` and `code-generation` from that iteration's fresh `tdd_result.output_artifacts`. The per-attempt schema self-correction happens one layer down, inside `execute_skill` (§4). **GOTCHA:** because step-1 always re-derives tests from the same `design_artifacts`, and the failing test artifacts are NOT threaded back in, a deterministically-failing BC will burn all 10 iterations producing largely-similar attempts before escalating.

**GOTCHA (:179, :259):** Temporal deserializes `str`-enum fields as a **list of characters** in some paths. Both the test-status check (:179) and the resolution-type check (:259) defensively `"".join(...)` a list before comparing. Any reimplementation on a serializer that round-trips enums as lists MUST normalise the same way or the success/abandon detection silently mis-fires.

**Timeouts differ by step:** TDD and codegen use `AGENT_START_TO_CLOSE` (3h); test-validation uses a hard `timedelta(minutes=15)` (:166). All three use `agent_failure` retry (3 attempts, 5→60s exp backoff).

### 2.3 `_handle_escalation` (`generate_bc.py:203`)

```
_handle_escalation(input, test_results, output_artifacts) -> GenerateBCResult:
    wf_id = workflow.info().workflow_id
    _escalation_id = f"esc-{wf_id[-8:]}"                          # :211 last 8 chars of workflow id
    _current_step="escalation-pending"; _status=WAITING_FOR_SIGNAL; _updated_at=now_iso()

    # Dispatch the escalation-handler agent to RECOMMEND a path (advisory):
    execute_activity(dispatch_agent_task,
        AgentTaskInput(task_type=f"escalation-{bc_name}", app_id,
                       skill_id="escalation-handler",
                       input_artifacts=test_results, source_repo=input.source_repo),
        start_to_close_timeout=timedelta(minutes=10),            # :226
        retry_policy=RETRY_POLICIES["agent_failure"],
        activity_id=f"escalation-{bc_name}")

    # BLOCK until a human resolves, or the workflow is cancelled:
    await workflow.wait_condition(lambda: self._escalation_resolved or self.cancelled)  # :232

    if self.cancelled:                                           # :236
        _status=CANCELLED; _updated_at=now_iso()
        return GenerateBCResult(bc_name, status="cancelled",
            test_results=test_results, iteration_count=_iteration,
            escalation_id=_escalation_id, output_artifacts=output_artifacts)

    _status=COMPLETED; _current_step="escalation-resolved"; _updated_at=now_iso()

    # Distinguish terminal Abandon from resolvable outcomes:
    result_status = "escalated"                                  # :257 default
    resolution_type = self._escalation_resolution_type
    if isinstance(resolution_type, list): resolution_type = "".join(resolution_type)  # :259 GOTCHA
    if isinstance(resolution_type, str):
        if resolution_type == ResolutionType.ABANDON.value:      # "Abandon"  :263
            result_status = "abandoned"
    elif resolution_type == ResolutionType.ABANDON:              # :265 enum object path
        result_status = "abandoned"

    return GenerateBCResult(bc_name, status=result_status,
        test_results=test_results, iteration_count=_iteration,
        escalation_id=_escalation_id, output_artifacts=output_artifacts)
```

**GOTCHA:** on resolution `_status` is set to `COMPLETED` (:248) *even for Abandon* — the "abandoned" signal is carried in `GenerateBCResult.status`, NOT the `WorkflowStatus`. The parent inspects the result status to decide the app's lifecycle (see §5). Escalation result never carries `output_files` (only `output_artifacts`) — the abandon/escalate paths do not persist generated files.

### 2.4 Escape outcomes — `ResolutionType` (`types.py:86`, doc `generate_bc.py:14`)

Four formal Ralph-Loop escape outcomes (W19 Modernization contract):
- `RE_EXTRACT = "Re-Extract"` — spec input was wrong; parent restarts Modernization from Extract.
- `MANUAL_AUGMENT = "Manual Augment"` — human commits patches; child re-enters Ralph Loop from test-validation.
- `RE_DISPOSITION = "Re-Disposition"` — target not viable at chosen disposition; parent cancels remaining BCs, signals Rationalization.
- `ABANDON = "Abandon"` — terminal failure for this BC. Parent Modernization run FAILS (no partial ship); escalation record stays open. This is the ONLY resolution that maps `GenerateBCResult.status` to `"abandoned"`.

The escalation-handler agent only *recommends*; the human's `EscalationResolvedSignal` decides. The child workflow itself does NOT implement Re-Extract / Re-Disposition; it returns `escalated`/`abandoned` and the **parent** acts on it (§5).

### 2.5 Signals + query (`generate_bc.py:281`)

- `@workflow.signal escalation_resolved(EscalationResolvedSignal)` (:281): sets `_escalation_resolved=True`, records `_escalation_resolution=signal.resolution`, `_escalation_resolution_type=signal.resolution_type`, bumps `_updated_at`. This is what unblocks `wait_condition`.
- `@workflow.signal gate_approved(GateApprovedSignal)` (:288), `gate_rejected` (:292), `wave_patterns_ready` (:296) — each ONLY bumps `_updated_at` (no-ops behaviorally; present for interface uniformity across HIL workflows).
- `@workflow.query get_status() -> WorkflowStatusResponse` (:304): returns workflow_id, `_status`, `current_step = f"{_bc_name}: {_current_step} (iteration {_iteration})"`, `progress_pct = (_iteration / MAX_RALPH_ITERATIONS)*100 if _iteration>0 else 0.0` (:313), `_started_at`, `_updated_at`.

`EscalationResolvedSignal` (`types.py:157`): `escalation_id, resolved_by, resolution_type: ResolutionType, resolution: str`.

`_now_iso()` = `workflow.now().isoformat()` (:323) — deterministic Temporal time, NOT `datetime.now()`.

---

## 3. Bounded-context discovery — `_parse_bounded_contexts` + `parse_bc_names_from_yaml`

### 3.1 Modernization (`modernization.py:2095`)

```
_parse_bounded_contexts(repo, app_id) -> list[str]:
    module_map_artifacts = self._design_results.get("module-design", [])   # :2113
    if not module_map_artifacts: return ["default"]                        # :2114 fallback
    module_map_path = f"modernization/{app_id}/design/files/module-design/module-map.yaml"  # :2120
    # (top-level module-map.yaml is a JSON metadata envelope, NOT parseable YAML — read the files/ one)
    try:
        read_result = execute_activity(read_artifact,
            ReadArtifactInput(repo, branch="main", path=module_map_path,   # :2129 reads MAIN (G-04b merged)
                              execution_context=...), timeout=60s, retry=transient,
            activity_id=f"read-module-map-{app_id}")
        content = read_result.content
    except Exception:
        log warning; return ["default"]                                    # :2142 fallback
    bc_names = parse_bc_names_from_yaml(content)                           # :2149
    if not bc_names: return ["default"]                                    # :2150 fallback
    if len(bc_names) > MAX_BC_CHILDREN_PER_APP: log truncation warning     # :2153 (does NOT truncate here)
    return bc_names
```

### 3.2 Build (`build.py:715`)

Reads `build/{app_id}/design/module-design.json` from `branch="main"` (:726–731), calls `parse_bc_names_from_yaml(result.content)` (:736), returns `names or ["default"]`, and on any exception returns `["default"]` (:738). **Note:** Build reads `.json` but still uses the YAML parser (YAML is a JSON superset, so `safe_load` handles both).

### 3.3 `parse_bc_names_from_yaml` (`modernization.py:2771`) — pure helper

```
parse_bc_names_from_yaml(content) -> list[str]:
    if not content or not content.strip(): return []
    try: data = yaml.safe_load(content)          # NEVER yaml.load  :2791
    except yaml.YAMLError: return []
    if not isinstance(data, dict): return []
    contexts = data.get("bounded_contexts") or data.get("contexts") or data.get("modules")  # :2798 first-non-empty
    if not isinstance(contexts, list) or not contexts: return []
    names=[]
    for ctx in contexts:
        if not isinstance(ctx, dict): continue           # :2808 skips string entries here
        name = ctx.get("name") or ctx.get("id")          # :2810
        if isinstance(name, str) and name.strip(): names.append(name.strip())
    return names
```

**GOTCHA:** truncation to 12 happens at the **call site** via slicing `bc_names[:MAX_BC_CHILDREN_PER_APP]`, NOT in the parser (:2783 docstring, applied at `modernization.py:1779` / `build.py:461`). **GOTCHA:** `parse_bc_names_from_yaml` only accepts dict entries with `name`/`id`; the `persist_modernization_side_effects` extractors (§5) additionally accept bare-string module entries and `bc_name` keys — the two parsers have subtly different accept-sets.

---

## 4. The actual code-generation engine — `execute_skill` (`agent_executor.py:1721`)

Every Ralph-Loop step (`tdd-generation`, `code-generation-*`, `test-validation`, `escalation-handler`) and every direct Generate dispatch (synthesis, reviews) ultimately runs here (via `dispatch_agent_task` → A2A → agent runtime). This is where generated code is written, validated, and accepted/rejected in-process.

### 4.1 Signature + defaults (:1721)

```
execute_skill(skill, task_message, model_id, app_id="", source_repo="",
    workspace_key="", workspace_dir="/workspace", permission_mode="acceptEdits",
    task_type="", input_artifacts=None, optional_input_artifacts=None,
    artifact_repo="", artifact_ref="", mission_context=None,
    timeout_seconds=None, idle_timeout_seconds=None, max_turns=None,
    max_budget_usd=None, memory_backend=None, extras=None, profile_id="",
    work_log_gate=True) -> A2ATaskResponse
```

- If SDK unavailable → `RuntimeError` (:1772). SDK import is guarded (`_SDK_AVAILABLE`, :78–99) — `claude_agent_sdk.query`, `ClaudeAgentOptions`, message types.
- `permission_mode` defaults to `"acceptEdits"` — agents write files without prompting.

### 4.2 Workspace setup (via `memory_backend.setup_workspace` → `_setup_workspace` :784)

- Returns `(workspace_path, source_dir, artifacts_dir)`. When `workspace_key` given, workspace **persists** across dispatches (shared source clone, prior artifacts visible); when empty, an **ephemeral** tempdir is created and cleaned up after (`_cleanup_workspace` :1391 rmtree only when no key).
- `task_type` scopes artifacts to `artifacts/{task_type}/` to prevent parallel-pass cross-contamination (:830).
- Path-injection guard: both `workspace_key` and `task_type` matched against `_SAFE_PATH_SEGMENT = ^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$` (:61); unsafe key → fresh tempdir, unsafe task_type → unscoped artifacts dir; neither raises. Defense-in-depth `realpath`+`commonpath` boundary check raises on escape (:841).
- **GOTCHA (:860):** the task-scoped artifacts subdir is `rmtree`'d at dispatch start so a **retry in a persistent workspace does not leak the prior failed attempt's files** (they'd be snapshotted as `pre_existing` and filtered out of the delta, landing `output_files` empty). Only the scoped subdir is cleaned, never the parent `artifacts/`.
- Source clone: tries S3 cache restore (`_restore_source_from_cache`), else `git clone --depth 1 --single-branch`, then uploads to cache (:876). Cache is a no-op unless `AGENT_WORKSPACE_S3_BUCKET` set. Clone timeout `GIT_CLONE_TIMEOUT_SECONDS` default 1800s (:1129). Token injected into clone URL only when target host == configured enterprise base host (:1227).
- CWD = `source_dir` if cloned, else `workspace_path` (:1813).

### 4.3 Input artifacts (`_fetch_input_artifacts` :631)

Fetches prior-line artifacts from GitHub via **Trees + Blobs API** (≤2 tree calls + 8-worker parallel blob fetch, :767). Resolves each path preferring `artifact_ref` tree, falling back to default-branch (`HEAD`) tree. `required=True` → missing path raises `FileNotFoundError` (:746); `required=False` (optional inputs) → logged and skipped (:752). **GOTCHA:** a truncated tree (repo >100k entries) raises `RuntimeError` (:581) — no paginated fallback.

### 4.4 Prompt assembly — `build_system_prompt` (:218)

Concatenated **in this exact order** (each block only when its input is non-empty), joined with `"\n"`:

1. **Mission/program context** (:243): `f"# {mission_context.heading}\n\n{mission_context.body.rstrip()}\n\n---"`. Intentionally FIRST — the strategic framing every skill operates under (e.g. FAA Statement of Objectives). Falls back to `load_mission_context()` when caller passes none (:1931).
2. **Skill body** (:250): `skill.system_prompt` (the markdown below SKILL.md frontmatter).
3. **Reference docs** (:254): for each `ref_name, ref_content` in `skill.references`: `f"\n\n--- Reference: {ref_name} ---\n{ref_content}"`.
4. **Output templates** (:258): for each in `skill.assets`: `f"\n\n--- Output Template: {asset_name} ---\n{asset_content}"`.
5. **Output Contract** (:267) — the load-bearing block for generation. If `skill.output_schemas`, prepend header `"--- Output Contract (STRICT — your output MUST conform) ---"` + a sentence that the runtime validates output against these schemas after finish and any violation is a hard failure. Then for each `{path, schema}` entry: `load_schema(schema_ref)`; if loadable, emit `f"\n### {path}\nSchema source: {schema_ref}\n```json\n{json.dumps(schema,indent=2)}\n```"` (:300); if not loadable, emit a fallback note telling the agent to emit valid JSON per stated structure (:286).
6. **Context** (:309): lines for `Application ID: {app_id}`, `Input Artifacts Directory: {dir}` (+ an instruction to read `_dispatch-context.json` FIRST and copy ids VERBATIM, never invent ids, :313), `Output Directory: {dir}` (+ "All output files MUST be written to this directory"). Wrapped as `"--- Context ---\n" + "\n".join(...)`.
7. **Platform Capability: Parallel Sub-Agents** (:341) — always appended. Tells the model it has the `Agent` tool; decompose into parallel sub-agents; include batching guidance in each sub-agent prompt.
8. **Platform Capability: Parallel Tool Calls** (:373) — always appended. Emit independent Read/Grep/Glob/Bash/Write in a single turn; the runtime runs tool_use blocks in one turn concurrently.
9. **Previous-attempt schema-failure feedback** (:406) — LAST block, only when `previous_failure_feedback` non-empty. Header `"--- IMPORTANT: PREVIOUS ATTEMPT FAILED SCHEMA VALIDATION ---"` + the violation text + instruction to emit ONLY valid JSON, no prose in `.json` paths, and re-emit a fresh schema-valid set (not a partial patch). Read from the workspace failure marker (§4.8).

**`normalize_system_prompt(raw, provider)` (:424):** for `provider in ("", "bedrock-claude", "anthropic")` return `raw` verbatim; for any OTHER provider, EXCISE the "Parallel Sub-Agents" block (the `Agent` tool is Claude-SDK-only) while preserving everything after it (finds next `"\n\n--- "` boundary, :455). The Output Contract block is provider-agnostic and always preserved.

**GOTCHA (:1983):** if the assembled prompt exceeds `_SYSTEM_PROMPT_FILE_THRESHOLD = 64*1024` bytes, it is spilled to `workspace_path/system-prompt.txt` and passed as `{"type":"file","path":...}` (→ CLI `--system-prompt-file`) to avoid `ARG_MAX` (`[Errno 7] Argument list too long`, observed ~150KB). Below threshold it goes inline.

### 4.5 SDK options (`ClaudeAgentOptions` :2014)

```
allowed_tools = skill.allowed_tools or ["Read","Glob","Grep","Write","Bash"]; +"Agent" if absent  # :1954
options = ClaudeAgentOptions(
    allowed_tools=tools, system_prompt=system_prompt_param,
    permission_mode=permission_mode, model=model_id, cwd=cwd,
    add_dirs=[workspace_path] if workspace_path else [],   # :2020 ONLY this dir (read-isolation)
    include_partial_messages=True)                          # :2028 token heartbeat for idle-timeout
if max_turns is not None: options.max_turns = max_turns
if max_budget_usd is not None: options.max_budget_usd = max_budget_usd
options.stderr = _log_cli_stderr                            # :2048 surface CLI stderr
if skill.mcp_servers: options.mcp_servers = skill.mcp_servers
```

**GOTCHA (:2001–2020):** `add_dirs` is deliberately ONLY `workspace_path` (not the parent `workspace_dir`) so a Read/Glob/Bash can't escape upward into a sibling app's artifacts on a shared replica — the fix for the 2026-06-12 cross-app-bleed incident.

### 4.6 The generation stream loop (:2182) — idle-timeout model

```
_idle = idle_timeout_seconds if >0 else None
_absolute = timeout_seconds if >0 else None
_absolute_deadline = loop.time()+_absolute if _absolute else None
async with asyncio.timeout(None) as cm:
    cm.reschedule(_next_deadline())                          # min(now+idle, absolute)  :2184
    async for message in query(prompt=task_message, options=options):   # :2186
        _last_event_at = monotonic(); cm.reschedule(_next_deadline())   # EVERY event pushes deadline
        if ResultMessage:  flush_phase("llm"); result_text=msg.result; total_cost=..; tokens=..;
                            log num_turns/stop_reason; continue          # :2194
        if AssistantMessage: count tool_use blocks; sample first 20;
                            flush_phase("tool" if has_tool_use else "llm"); continue   # :2230
        if UserMessage w/ ToolResultBlock: flush_phase("llm"); continue  # :2278
```

- **Idle model (:2140–2180):** the deadline fires only after `_idle` seconds of TRUE silence; `include_partial_messages` gives a token heartbeat so a long synthesis turn keeps resetting the deadline. `_absolute` is a runaway backstop. On expiry → `TimeoutError` caught (:2290): distinguish idle-stall vs absolute-ceiling, cleanup workspace, return `A2ATaskResponse(status="timeout", ...)`. **GOTCHA:** the OLD single-`asyncio.timeout(N)` model killed actively-working agents mid-synthesis; the new per-event reschedule is required for behavioral parity.
- **GOTCHA (:2336–2347):** if the SDK raises AFTER a valid `ResultMessage` was captured (non-zero CLI exit but success content), it's treated as SUCCESS and falls through to collection. Only a raise with `result_text is None` returns `status="failed"`.
- Phase timing split into `llm_ms`/`tool_ms` buckets via `_flush_phase` (:2128) for telemetry (Task #94).

### 4.7 How generated code is validated / accepted / rejected (:2362 onward)

After the stream, in order:

1. **Collect delta artifacts** (`_collect_artifacts` :1331) — walk `artifacts_dir` with **in-place dir pruning** of `_ARTIFACT_IGNORE_DIRS` (`.git`, `node_modules`, `.venv`, `__pycache__`, `dist`, `build`, `target`, `coverage`, `vendor`, `Pods`, `.terraform`, … full set :121). Collect only files NOT in the pre-execution snapshot `_pre_existing_files` (:2064). **GOTCHA:** collecting dependency trees inline overflows Temporal's 4 MB gRPC activity-result limit — a single greenfield BC's `npm install` produced 9608 files / 216 MB (ResourceExhausted), wedging the Ralph Loop in a doomed retry (:112–120). Binary extensions (`_BINARY_EXTENSIONS` :102) → base64.

2. **Write-before-finish guard** (`_missing_declared_outputs` :1403, continuation :1435): if the skill declares `output_schemas` but a declared path is missing OR present-but-empty, and `result_text is not None`, issue ONE bounded continuation (`_reprompt_write_missing_outputs`) telling the agent to Write the named files from content it already produced (do NOT redo analysis), capped at `min(_absolute or 1800, 1800)` s. Re-collect afterward (:2408). Match is by exact relpath OR basename (:1421).

3. **Schema-validity guard** (:2442): probe `collect_output_violations` WITHOUT raising; filter to `agent_actionable` violations (empty required array, wrong type, prose-in-json — NOT missing-schema-file/jsonschema-not-installed); `coalesce_violations`; if any, issue ONE bounded continuation (`_reprompt_fix_schema_violations` :1486) handing the agent the EXACT schema errors, instruct it to re-Write COMPLETE content (targets the "skeleton then narrate" failure — a valid metadata skeleton with empty required arrays). Re-collect (:2474).

4. **Strict terminal validation** (`validate_output_files` :2510): raises `OutputValidationError` on the first violation. On violation: `_write_failure_marker(workspace_path, exc)` (:2514) → persist the failure detail to the workspace for the NEXT retry attempt to fold into its prompt (§4.8), cleanup, return `A2ATaskResponse(status="failed", output_files=..., error=...)`. On clean pass: `_clear_failure_marker` (:2529) so stale feedback never bleeds forward.

5. **Maker/verifier work-log gate** (`_finalize_and_gate_worklog` :1656, gate :2566): the VERIFIER role (never the maker) authors the review verdict; `verify_disposition` reads the on-disk log and returns the AUTHORITATIVE block/allow verdict. If `work_log_gate and _wl_verdict.blocked` → return `status="failed"` (`REQ-WL-007`). A MISSING or non-verifier-authored log **blocks** (fail-closed). The maker pre-write (`_begin_maker_worklog` :1598, BEFORE the side-effecting query) and checklist ticking are best-effort. This is the runtime enforcement of "the agent that writes code is never the one that grades it."

6. **Success** (:2586): `A2ATaskResponse(status="completed", output_artifacts=[result_text], output_files=..., token_usage=TokenUsage(input, output, llm_ms, tool_ms, tool_call_count), cost_estimate_usd=total_cost, duration_ms=...)`.

**GOTCHA:** `output_artifacts` = `[result_text]` = the agent's **final narrative/summary text**, NOT file paths. `output_files` = the actual `OutputFile(path, content, encoding)` list. Callers that need real files MUST use `output_files`; feeding `output_artifacts` as downstream `input_artifacts` is the recurrent hard-fail the workflows guard against (§1.2, §1.3).

### 4.8 Retry-with-feedback marker (:144)

`_FAILURE_MARKER_FILENAME = ".previous-validation-failure.json"`. On schema-validation failure, `_write_failure_marker` writes `{feedback, path, schema_path, violations}` to the persistent workspace BEFORE returning failure. Temporal's `agent_failure` retry (3 attempts) re-dispatches against the SAME `workspace_key`; the next `execute_skill` reads the marker (`_read_failure_marker` :147) and folds it into the system prompt (block 9, §4.4), giving the agent exactly ONE prompt-level self-correction chance per retry. On any clean run the marker is cleared. **GOTCHA:** the marker only rides across retries when `workspace_key` is supplied (persistent workspace). Ephemeral dispatches (Build's `GenerateBCWorkflow` children carry no shared key) get no cross-retry feedback marker — the in-process continuations (steps 2–3) are their only self-correction.

---

## 5. Failure / regression handling & DB projection

### 5.1 Ralph exhaustion → escalation (child), abandon → parent failure

- Child exhausts 10 iterations → escalation-handler recommends → human `EscalationResolvedSignal`. `Abandon` → `GenerateBCResult.status="abandoned"`; anything else → `"escalated"`. Cancellation while waiting → `"cancelled"`. (§2.3)
- The parent's `asyncio.gather` collects all children; a child never raises on exhaustion (returns a result), so one abandoned BC does NOT crash the fan-out — the parent projects it (below).

### 5.2 `persist_modernization_side_effects` (`activities/line_transitions/modernization.py:258`)

Called three times per target run — once after each gate. `gate_phase in {"extract","design","generate"}` (`_GATE_PHASES` :53); invalid phase → `NonRetryableError` (:306). Best-effort outside the txn: unparseable artifacts log + return empty result (never raise).

**Generate phase (`_extract_generate_side_effects` :179)** — reads the `gate-review-package.json` `bounded_contexts` array. Returns `(application_projections, bounded_context_updates)`:

```
for each bc in package["bounded_contexts"]:                   # :216
    name = bc["bc_name"] or bc["name"]; skip if not str
    status = bc["status"]
    if status not in {"design-complete","generate-active","generate-complete",
                      "escalated","abandoned"}:                # _BOUNDED_CONTEXT_STATUSES :47
        status = "generate-complete"                          # default when unambiguously green  :225
    if status in {"escalated","abandoned"}: escalated_count += 1   # :229
    carry ralph_iterations (int), escalations (list), generated_path (str)   # :231
    if generated_path: paths.append(path)
if paths: app_out["generated_module_refs"] = paths            # :244

# Lifecycle status roll-up:                                   # :248
if bc_updates:
    if escalated_count == 0:                app_out["modernization_current_status"]="modernization_complete"
    elif escalated_count < len(bc_updates): app_out["modernization_current_status"]="modernization_partial"
    else:                                   app_out["modernization_current_status"]="modernization_failed"
```

So: ALL BCs green → `modernization_complete`; SOME escalated/abandoned → `modernization_partial`; ALL escalated/abandoned → `modernization_failed`. **GOTCHA:** this is a SEPARATE decision from the workflow-level `return "failed"` on rework-cap; a G-04c that a PM approves with some abandoned BCs still merges but records `modernization_partial`. The Abandon-terminal semantics from the child are honored here via the escalated_count roll-up.

**DB writes (single txn, :362):**
- UPDATE `application` row with `projections` via `_build_update_sql` (:365).
- INSERT `bounded_context` rows at G-04b (`ON CONFLICT (target_app_id, bc_name) DO NOTHING` — idempotent rework, :377).
- UPDATE `bounded_context` rows at G-04c (dynamic SET of `status`, `updated_at`, optional `ralph_iterations`, `escalations` (json.dumps), `generated_path`; :388). Rows were provisioned at G-04b at status `design-complete`; G-04c updates in-place.

**Whitelisting GOTCHAs:** `modernization_pattern` is whitelisted against `_MODERNIZATION_PATTERNS = {"monolith-lift","microservices-decompose","bc-per-service","hybrid"}` (:42) so a skill typo can't poison the column (:125). Non-ISO `decided_at` logs a warning and drops the timestamp (:74).

### 5.3 Governance flywheel (`activities/line_transitions/governance.py`)

`persist_governance_sweep_side_effects` projects `pattern-extraction.json` → `pattern` table rows (`_extract_pattern_side_effects` :109) and `drift-detection.json` → `drift_alert` rows (`_extract_drift_alert_side_effects` :54, whitelisting `_DRIFT_TYPES`/`_DRIFT_SEVERITIES`, :41–48). `wave_patterns_ready` acks flatten into `pattern_reuse_count` updates (`_apply_pattern_reuse_count_updates` :297). Model tiers whitelisted against `_MODEL_TIERS = {"Tier-1","Tier-2","Tier-3"}` (:51). This closes the compound-growth loop: patterns extracted from completed waves feed reuse counts back into governance — the `WavePatternsReadySignal` that `GenerateBCWorkflow` accepts (as a no-op) is the child-side ack of that flywheel.

### 5.4 Dispatch-level failure propagation (`agent_dispatch.py:756`)

`dispatch_agent_task` spawns a 30s heartbeat loop (`_heartbeat_loop`, cancelled on every exit, :779). In `_dispatch_agent_task_inner`: resolves agent via `OlympusAgentRegistry.find_agent_for_skill` (:837); dispatches via A2A (or `dispatch_via_mock` when `AGENT_RUNTIME_MODE=mock`, :846 — tests only; prod refuses mock at worker startup). **GOTCHA (:871):** both `TaskStatus.FAILED` and `TaskStatus.TIMED_OUT` are propagated as `RetryableError` — a timed-out run returns empty `output_files`, and if surfaced as COMPLETED the workflow would see empty output and (for steps with a non-retryable empty-output guard) fail the whole wave on what should be a fresh retry. Ralph-Loop dispatches use `agent_failure` retry → 3 attempts before the activity fails, which then propagates into the workflow's own rework/escalation loop.

---

## 6. Consolidated GOTCHA index

1. `MAX_RALPH_ITERATIONS=10` (`types.py:136`) is a WHILE bound; success returns early at any iteration. Exhaustion (all 10 fail) → escalation, NOT failure. (`generate_bc.py:100`, `:200`)
2. Enum-as-list-of-chars deserialization: normalise with `"".join()` before comparing test status (`generate_bc.py:179`) and resolution type (`:259`).
3. Escalation sets `WorkflowStatus.COMPLETED` even for Abandon; the abandon signal lives in `GenerateBCResult.status`, not the workflow status. (`generate_bc.py:248`, `:257`)
4. Escalation `_escalation_id = f"esc-{wf_id[-8:]}"` — last 8 chars of the workflow id. (`generate_bc.py:211`)
5. Ralph Loop does NOT thread failing test output back into the next iteration; each iteration re-derives tests from the same `design_artifacts`. Self-correction is one layer down in `execute_skill`. (`generate_bc.py:106`)
6. test-validation timeout is 15 min, NOT the 3h `AGENT_START_TO_CLOSE` used by TDD/codegen. (`generate_bc.py:166`)
7. Build MUST commit child `output_files` to the repo before synthesis (children ran ephemeral; `output_artifacts` is prose). (`build.py:494–517`)
8. Everywhere: feed **committed file paths** downstream, never `result.output_artifacts` (free-text). Prose-as-path hard-fails `_fetch_input_artifacts`. (`build.py:327`, `agent_executor.py:2586`)
9. Modernization gate-pre-review is behind `workflow.patched("modernization-gate-pre-review-v1")` — both branches must survive forever for replay. (`modernization.py:2002`)
10. Two distinct G-04c rework exits (baseline-incomplete :1961; gate-rejected :2083), both cap at `>3`. Build's single G-NEW-3 cap `>3` (`build.py:635`).
11. BC-count truncation to 12 happens at the call-site slice, not in `parse_bc_names_from_yaml`. (`modernization.py:1779`, `build.py:461`, `:2783`)
12. `_ARTIFACT_IGNORE_DIRS` pruning is mandatory — inline `node_modules` overflows Temporal's 4 MB limit and wedges the loop. (`agent_executor.py:121`)
13. Retry-feedback marker only survives across retries with a persistent `workspace_key`; ephemeral BC children get only in-process continuations. (`agent_executor.py:144`, `:1935`)
14. Idle-timeout must reschedule on EVERY stream event (needs `include_partial_messages=True`); a blunt wall-clock timeout kills working agents. (`agent_executor.py:2028`, `:2182`)
15. `add_dirs=[workspace_path]` only (not parent) — cross-app read isolation. (`agent_executor.py:2020`)
16. SDK raise AFTER a valid ResultMessage = success. (`agent_executor.py:2343`)
17. Mission context is the FIRST prompt block; previous-failure feedback is the LAST. Non-Claude providers get the sub-agent block stripped. (`agent_executor.py:243`, `:406`, `:424`)
18. System prompt >64KB spills to a file (`--system-prompt-file`) to dodge ARG_MAX. (`agent_executor.py:1983`)
19. Work-log gate is fail-closed: missing/non-verifier log BLOCKS the disposition (opposite of best-effort telemetry). (`agent_executor.py:1703`, `:2566`)
20. `modernization_current_status` roll-up (`complete`/`partial`/`failed`) is separate from the workflow's `return "failed"`; a PM-approved gate with abandoned BCs still merges as `partial`. (`line_transitions/modernization.py:248`)
21. `modernization_pattern` is whitelisted (typo protection) against 4 values. (`line_transitions/modernization.py:42`, `:125`)
22. `TIMED_OUT` dispatch status propagates as retryable (not COMPLETED) so empty-output guards don't fail the wave on a stall. (`agent_dispatch.py:871`)
