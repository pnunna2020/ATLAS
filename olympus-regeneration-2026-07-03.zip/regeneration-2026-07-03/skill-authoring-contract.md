# Skill Authoring Contract (Olympus)

**Regeneration atomic spec — 2026-07-03.** Standalone. This document is written so a
skill-builder can author a *conformant* Olympus skill **without** reading any runtime
code. It reproduces the exact contract a `SKILL.md` (plus its sibling files and its
registry entry) must satisfy so the platform loads it, dispatches it, feeds it inputs,
validates its output, and retries it on failure — with **behavioral parity**.

Everything below is derived from live code. Non-trivial claims cite `path:line`. When a
file is named at the top of a section, bare `(:NN)` refers to that file.

---

## 0. What a skill physically is

A skill is a directory under `cross-cutting/skills/<skill-id>/` (or, as a profile overlay,
`profiles/<profile_id>/skills/<skill-id>/`). Its authoritative artifact is `SKILL.md`:
YAML frontmatter + a markdown body. The **body is loaded verbatim into the LLM as the
system prompt** at dispatch time (`cross-cutting/skills/CONVENTIONS.md:11`). A skill is a
prompt template, NOT workflow logic — fan-out/sequencing/merge live in Temporal workflows
(`CONVENTIONS.md:13`).

The directory MAY additionally contain these sibling resources, all optional:

| Sibling | Purpose | Staged as |
|---|---|---|
| `references/` | domain-knowledge docs the body cites by path | folded into system prompt AND staged to disk under `references/` |
| `assets/` | output templates | folded into system prompt AND staged under `assets/` |
| `scripts/` | executable helpers the body says to run | staged under `scripts/`, marked executable |
| `schemas/`, `templates/`, `fixtures/` | resolved by path from bundled scripts/bodies | staged back under the skill root as `schemas/…` etc. |
| `config.json` | per-deployment overlay values | staged as `config.json` at the skill root |

Enrichment level (registry metadata, and a DB badge) is derived from which of these exist:
`full` = has `references/` AND (`assets/` OR `config.json` OR `scripts/`); `partial` = any
one of them; `minimal` = SKILL.md only
(`olympus-api/src/services/skill_bootstrap.py:186`; `CONVENTIONS.md:113`).

There are **192** skill directories under `cross-cutting/skills/` in this tree (plus
`CONVENTIONS.md`, `README.md`, `PR-DESCRIPTION.md`, and `registry.yaml`, which are NOT
skills — they lack a `SKILL.md`).

---

## 1. `SKILL.md` frontmatter schema

Frontmatter is the block between the first two `---` fences. **Two independent parsers read
it**, and they do NOT agree on every field — this is load-bearing and a common footgun:

- **Runtime loader** (`olympus-agent-runtime/src/services/skill_loader.py`): parses with
  `yaml.safe_load` over the whole frontmatter block (`:362`). It reads `name`,
  `description`, `agent`, `allowed-tools`, `output_schemas`, and `provider`.
- **API bootstrap parser** (`olympus-api/src/services/skill_bootstrap.py:64` `_parse_frontmatter`):
  a hand-rolled line scanner, NOT a YAML parser. It reads ONLY `name`, `description`,
  `agent`, and `allowed-tools` (`:88`–`:93`, `:82`). It does **not** read
  `output_schemas`, `provider`, `disable-model-invocation`, or any other field.
- **`output_schemas` for the API dispatch response** is loaded SEPARATELY, straight off
  disk, by a third YAML parser
  (`olympus-api/src/services/return_payload_validator.py:166` `load_output_schemas_for_skill`
  → `_parse_frontmatter` at `:125` uses `yaml.safe_load`).

> **GOTCHA:** because the API bootstrap parser is line-based, frontmatter that is valid YAML
> but relies on YAML features the scanner doesn't implement (e.g. flow-style lists,
> anchors, multi-key inline maps) may parse differently in the API DB record vs. the
> runtime. Keep frontmatter to the simple block forms shown here. Lists MUST be block
> style (`- item` on its own line), because `_parse_frontmatter` recognizes a list item
> only when the stripped line starts with `- ` and a key is currently open
> (`skill_bootstrap.py:99`).

### 1.1 Required fields

| Field | Type | Meaning | Read by |
|---|---|---|---|
| `name` | string | Skill id. **MUST equal the directory name exactly** (`CONVENTIONS.md:105`). If a body-parse yields `name == skill_id` the API re-renders it as a title case display name (`skill_bootstrap.py:301`), so setting it to the dir name is safe. | runtime `:115`, API `:88` |
| `description` | string (one paragraph) | Summary surfaced by the registry and used by model auto-selection. Authored as a YAML block scalar (`>`), see below. | runtime `:116`, API `:90` |
| `agent` | enum `opus`\|`sonnet`\|`haiku` | Model TIER hint. Maps to a canonical tier. | runtime `:117`, API `:270` |

`agent` → tier mapping (runtime `_AGENT_TIER_MAP`, `skill_loader.py:22`):
`opus`→`tier-1`, `sonnet`→`tier-2`, `haiku`→`tier-3` (the `tier-N` forms are also accepted
verbatim). **Any unrecognized value silently defaults to `tier-2`** (`:118`). Choose per
`CONVENTIONS.md:107`: `opus`=reasoning-heavy, `sonnet`=standard, `haiku`=fast.

`description` is conventionally a folded block scalar so it can wrap across lines:

```yaml
description: >
  One paragraph. What this skill produces, when it's invoked, and its trigger
  phrases. Keep it tight — the registry surfaces this as the summary.
```

The runtime `.strip()`s the description (`:137`). The description SHOULD end with trigger
phrases (observed convention: "Triggers on X, Y, or @skill-name.") so model auto-selection
can match it — see the real examples in `analyze-portfolio-redundancy` and
`classify-application`.

### 1.2 Optional frontmatter fields

| Field | Type | Meaning | Read by |
|---|---|---|---|
| `allowed-tools` | block list of strings | Tool allow-list handed to the Claude Agent SDK. When omitted/empty the runtime defaults to `["Read","Glob","Grep","Write","Bash"]` (`agent_executor.py:1954`). **`Agent` is always appended** whether or not you list it (`:1955`). | runtime `:119`, API `:82` |
| `output_schemas` | block list of `{path, schema}` maps | Output contract (see §2). | runtime `:120`, RPV `:191` |
| `provider` | string | Per-skill provider override (`bedrock-claude`\|`openai`\|`gemini-vertex`). Empty ⇒ inherit profile/global default. **`config.json`'s `provider` wins over this** (`skill_loader.py:130`). No skill in this tree currently sets it. | runtime `:130`,`:593` |
| `disable-model-invocation` | bool | `true` ⇒ skill is dispatched by orchestration only, never model auto-selection (`CONVENTIONS.md:109`). Advisory metadata; not enforced by the loader. Example: `analyze-portfolio-redundancy/SKILL.md`. | (documentation only) |

**Frontmatter fields that are NOT consumed by any loader** (they live in frontmatter on
some skills but the runtime/API ignore them — they are documentation, or are read from the
`registry.yaml` copy, not from `SKILL.md`): `required_outputs`, `validation_commands`,
`supported_stacks`, `failure_classes`, `benchmark_tags`, `depends_on`. The
authoritative home for those is the **registry entry** (§5). Declaring them in frontmatter
too is harmless (the runtime `yaml.safe_load` just drops unread keys) but has no runtime
effect there.

### 1.3 Canonical frontmatter template

```yaml
---
name: <skill-id>                 # MUST equal directory name
description: >
  One paragraph describing what this skill produces and when it fires.
  Triggers on <phrase>, <phrase>, or @<skill-id>.
agent: sonnet                    # opus | sonnet | haiku
allowed-tools:                   # optional; block list only
  - Read
  - Write
  - Grep
  - Bash
output_schemas:                  # optional; see §2
  - path: <output-filename>.json
    schema: schemas/<line>/<name>.schema.json
disable-model-invocation: true   # optional; orchestration-only skills
---
```

### 1.4 Body structure (convention, not loader-enforced)

`CONVENTIONS.md:56` mandates these sections in order for authoring review (CI checklist
`:285`), though the loader does not parse them: `# <Title>`, then `## Purpose`,
`## Inputs`, `## Outputs`, `## Methodology`, `## Constraints`. Optional: `## Quality
Criteria`, `## Validation`, `## References`, `## Variants`, `## Gotchas` /
`## Anti-Patterns`, `## Artifact Output`, `## Currency`.

> **This document does not include prompt bodies** — only the contract they must satisfy.
> The body is free-form markdown; whatever you write is loaded verbatim as the system
> prompt (§3), so it must actually instruct the agent to (a) read the staged inputs, (b)
> produce every declared output file at its declared path, and (c) emit valid JSON for any
> `.json` output that has a schema.

---

## 2. `output_schemas`: the output contract

### 2.1 Declaration form

`output_schemas` is a block list of mappings, each with exactly two string keys:

```yaml
output_schemas:
  - path: portfolio-redundancy-matrix.json
    schema: schemas/rationalization/rationalization-clustering-plan.schema.json
```

Real examples: `analyze-portfolio-redundancy/SKILL.md` (path preserved from a legacy name;
schema is a different shape), `classify-application/SKILL.md`
(`path: classification.json`, `schema: schemas/rationalization/classification.schema.json`),
`cato-compliance/SKILL.md` (`path: security-arch.json`,
`schema: schemas/architecture/security-arch.schema.json`).

### 2.2 Normalization / coercion rules (identical on both sides)

Runtime `_coerce_output_schemas` (`skill_loader.py:187`) and API `_coerce_output_schemas`
(`return_payload_validator.py:145`) are deliberately kept in lockstep:

- Missing or non-list ⇒ `[]` (validation disabled; runtime logs a `debug` line, `:204`).
- Each entry must be a mapping with **both** `path` (str) and `schema` (str); any entry
  missing either, or not a dict, is **silently skipped** (`skill_loader.py:212`–`:224`).
- Result is a list of `{"path": ..., "schema": ...}` dicts, order preserved.

> **GOTCHA:** a malformed `output_schemas` block does NOT raise — it degrades to "no
> contract," so the skill runs but its output is never validated. If you intend validation,
> the block MUST be a clean block list of two-key maps.

### 2.3 `schema` path resolution

The `schema` value is a **repo-relative path** (or absolute). It is resolved against the
repo root, located by walking up from the validator file to find a `schemas/` sibling, or
via env `OLYMPUS_SCHEMA_ROOT` (runtime `output_validator.py:84`–`:101`,`:115`–`:125`; API
`return_payload_validator.py:105`). So `schema: schemas/rationalization/classification.schema.json`
must exist at `<repo>/schemas/rationalization/classification.schema.json`.

- If the schema file cannot be loaded, the runtime folds a *warning stanza* into the prompt
  telling the agent the contract is in flux (`agent_executor.py:286`–`:294`) and, at
  validation time, produces a NON-agent-actionable failure
  (`output_validator.py:222`–`:231`) — i.e. it will not be fixed by re-prompting; it is a
  deployment bug.

The schemas are **JSON Schema, Draft 2020-12** — validated with
`jsonschema.Draft202012Validator` (`output_validator.py:169`,`:234`). There are 113
`*.schema.json` files under `schemas/`, organized by assembly line:
`architecture/ build/ common/ compliance/ cross-cutting/ data/ design/ discovery/
dispositions/ drift/ evidence/ gates/ ingestion/ modernization/ oscal/ profiles/
rationalization/ samples/ validate.sh`. Each schema declares
`"$schema": "https://json-schema.org/draft/2020-12/schema"` and a `"$id"`
(e.g. `schemas/rationalization/classification.schema.json:1`).

### 2.4 Which schema(s) a skill "of each type" must satisfy

There is no skill "type" system. The contract is **per declared output file**:

- A skill that declares NO `output_schemas` has NO enforced output contract. Its outputs
  are collected but never schema-validated (`output_validator.py:300` returns the files
  unchanged when `schemas` is empty). Downstream workflow guards may still reject empty
  output.
- A skill that declares `output_schemas` MUST, for **every** declared `path`, produce a
  file whose content is JSON that validates against the named schema. A declared output
  that is absent or empty is treated as a hard failure (§4). A `.json` file containing
  prose fails `json.loads` and surfaces as a parse-error violation (`output_validator.py:207`).

The correct schema for a given output is whichever schema in `schemas/<line>/` describes
that artifact; pick the one whose `title`/`description` matches your output (schemas are
self-describing — see `classification.schema.json`'s `description` at `:5`). If none
exists yet, author a Draft-2020-12 schema and place it under the appropriate line dir.

### 2.5 Path-matching at validation time

The validator matches a declared `path` against a produced `output_file.path` **either**
as a full repo-relative path **or** by basename (`output_validator.py:185`,
`_missing_declared_outputs` at `agent_executor.py:1421`). So
`path: classification.json` matches an output written to
`artifacts/<task-type>/classification.json`. Both the bare-filename and full-path styles
appear across skills (`output_validator.py:292`). Only `encoding == "utf-8"` files are
validated; base64 outputs are skipped (`output_validator.py:190`).

---

## 3. The runtime input / context / priors envelope (author's view)

This is exactly what your skill will "see" at runtime. It is assembled in two places: the
**system prompt** (`build_system_prompt`, `agent_executor.py:218`) and the **staged
workspace files**. Author your body to consume both.

### 3.1 The system prompt, in assembly order

`build_system_prompt` concatenates these parts with `"\n".join` (`agent_executor.py:238`–`:421`):

1. **Mission / program context** (if a client profile provides one) — prepended FIRST,
   before your body, as `# <heading>\n\n<body>\n\n---` (`:243`–`:247`). This is the
   program's strategic framing (e.g. the FAA Statement of Objectives). You do not author
   it; it comes from the active profile. Write your body to operate *within* it.
2. **Your SKILL.md body** verbatim (`:250`–`:251`).
3. **Reference documents**: each `references/<name>` file as
   `\n\n--- Reference: <name> ---\n<content>` (`:254`–`:255`).
4. **Output templates**: each `assets/<name>` file as
   `\n\n--- Output Template: <name> ---\n<content>` (`:258`–`:259`).
5. **Output Contract** (only if `output_schemas` is set): a "STRICT — your output MUST
   conform" header (`:268`–`:274`) followed, per declared entry, by the schema reproduced
   verbatim as pretty-printed JSON in a fenced block, headed by `### <path>` and
   `Schema source: <schema-ref>` (`:296`–`:306`). **This means the agent sees your full
   JSON Schema up front** — you do not need to paste it into your body.
6. **Context** block (`:310`–`:334`): `Application ID: <app_id>` when set; an
   `Input Artifacts Directory: <dir>` note telling the agent prior-line artifacts are
   staged there and to READ `_dispatch-context.json` FIRST and copy ids VERBATIM
   (`:314`–`:326`); an `Output Directory: <dir>` note requiring all outputs be written
   there (`:327`–`:332`).
7. **Platform Capability: Parallel Sub-Agents** — always appended (`:341`–`:362`); tells
   the agent it has the `Agent` tool and should decompose into parallel sub-agents.
8. **Platform Capability: Parallel Tool Calls** — always appended (`:373`–`:396`); tells
   the agent to batch independent tool calls in one turn.
9. **Previous-attempt validation feedback** — appended LAST when a retry marker exists
   (§4.2, `:406`–`:419`).

> **GOTCHA (non-Claude providers):** if the resolved provider is not
> `""`/`bedrock-claude`/`anthropic`, `normalize_system_prompt` (`:424`) STRIPS the
> Parallel Sub-Agents block (the `Agent` tool doesn't exist there) but PRESERVES the
> Output Contract. Do not write body text that assumes the `Agent` tool exists if your
> skill sets a non-Claude `provider`.

> **GOTCHA (prompt size):** if the assembled prompt exceeds **64 KiB** it is spilled to
> `system-prompt.txt` and passed as a file to avoid `ARG_MAX` (`agent_executor.py:1984`).
> No behavior change for the author, but keep references lean.

### 3.2 Files staged into the workspace (read them by path)

Your agent runs with `cwd` = the cloned source repo (if `source_repo` was provided and
cloned) else the workspace root (`agent_executor.py:1813`). The only readable/writable
directory is this dispatch's `workspace_path` (`add_dirs=[workspace_path]`, `:2020`) — you
cannot read sibling dispatches' files. Under it:

- **`input-artifacts/`** — prior-line artifacts fetched from the artifact git repo. Every
  `context.input_artifacts[]` path is fetched here (REQUIRED — a missing one fails the
  dispatch, `agent_executor.py:744`); every `context.optional_input_artifacts[]` is
  best-effort (a 404 is skipped, `:752`). Fetch preserves repo-relative subpaths
  (`:774`). Author your `## Inputs` to Read these.
- **`input-artifacts/_dispatch-context.json`** — pretty-printed JSON of the workflow's
  structured `extras` (only list/dict values with content are written, `:1889`–`:1901`).
  This carries REAL database ids (e.g. capability inventories with real UUIDs). **The
  prompt explicitly orders the agent to read this first and copy ids verbatim**
  (`:318`–`:326`); a fabricated id silently fails to bind downstream. Author your body to
  honor that.
- **`artifacts/<task_type>/`** — the OUTPUT directory (`output_dir` in the prompt). Write
  every declared output file here. It is cleaned at dispatch start so retries don't leak
  stale files (`:860`). Only NEW files (delta vs. a pre-run snapshot) are collected as
  outputs (`:2064`–`:2072`,`:2366`).
- **`source/`** — the cloned source repo, when `source_repo` was supplied.
- **Bundled resources** — your `scripts/`, `references/`, `assets/`, and
  `schemas/`/`templates/`/`fixtures/` are staged as real files under `cwd` so
  `scripts/foo.py` and `references/bar.md` resolve by the paths your body names
  (`_stage_skill_resources`, `:1246`; scripts are chmod +x, `:1305`). `config.json` is
  staged at `cwd/config.json` (`:1278`).

### 3.3 The natural-language task message

Separately from the system prompt, the agent receives a **task message** as the user turn
(`query(prompt=task_message, …)`, `:2186`). The workflow builds it
(`olympus-worker/src/agent_client.py:72` `_build_task_message`):

```
Execute skill '<skill_id>' for application '<app_id>'. Task type: <task_type>.
Context: <k=v, k=v, ... sorted by key>.
```

The `Context:` clause is a flattened `k=v` render of the workflow's free-form context dict
(`agent_client.py:84`). Scalars ride here fine; **structured lists/dicts are unreadable
inline** and are instead materialized as `_dispatch-context.json` (see §3.2). Do not rely
on parsing the inline `Context:` string for anything structured.

### 3.4 The A2A context envelope (fields your workflow passes)

The dispatch carries an `A2AContext` (`olympus-agent-runtime/src/models/a2a.py:10`), whose
fields drive everything above. As an author you don't build this, but you must know which
fields exist so your `## Inputs` matches reality:

| Field | Type | Effect on your skill |
|---|---|---|
| `app_id` | str | injected as `Application ID:` in prompt (`:311`) |
| `skill_id` | str | which skill is dispatched |
| `task_type` | str | scopes the output subdir `artifacts/<task_type>/` (`:830`); used in the task message |
| `input_artifacts` | list[str] | REQUIRED prior-line artifact repo paths staged to `input-artifacts/` |
| `optional_input_artifacts` | list[str] | best-effort inputs (404 tolerated) (`a2a.py:22`) |
| `source_repo` | str | cloned to `source/`; becomes `cwd` |
| `artifact_repo`, `artifact_ref` | str | repo + branch the inputs are fetched from |
| `model_preference` | str | tier/model routing |
| `workspace_key` | str | persistent-workspace id; enables retry-feedback + work-log (§4) |
| `extras` | dict[JSON] | scalars → inline `Context:`; lists/dicts → `_dispatch-context.json` |

---

## 4. Output validation contract + retry-feedback format

### 4.1 Validation pipeline (what your output must survive)

After the agent's stream ends, the runtime (`execute_skill`) does, in order:

1. **Collect delta artifacts** from `artifacts/<task_type>/` (`:2365`). Dependency/build
   dirs (`node_modules`, `.venv`, `dist`, `.git`, …) are pruned and never collected
   (`_ARTIFACT_IGNORE_DIRS`, `:121`). Text files are utf-8; binaries base64.
2. **Write-before-finish net** (`:2387`): if any declared `output_schemas[].path` is
   missing OR present-but-empty (`_missing_declared_outputs`, `:1403`), issue exactly
   **one** bounded continuation telling the agent to `Write` the named file(s) from the
   content it already produced (`_reprompt_write_missing_outputs`, `:1435`), then re-collect.
3. **Schema-validity net** (`:2442`): probe (without raising) for schema violations
   (`collect_output_violations`, `:152`); for **agent-actionable** violations only
   (`agent_actionable == True`), issue one more bounded continuation handing the agent the
   exact errors and telling it to re-Write complete, schema-valid content
   (`_reprompt_fix_schema_violations`, `:1486`), then re-collect.
4. **Terminal strict validation** (`validate_output_files`, `:2510` → `output_validator.py:277`):
   for every declared entry, match the produced file by full path or basename, require
   `encoding=="utf-8"`, require non-empty content, require `json.loads` to succeed, load the
   schema, and run `Draft202012Validator`. ALL files are checked; failures are coalesced
   into one `OutputValidationError` (`coalesce_violations`, `:250`). On any violation the
   dispatch returns `status="failed"` (`:2518`).
5. **Work-log gate** (only meaningful with a `workspace_key`): a maker/verifier work-log
   is finalized and an AUTHORITATIVE block/allow verdict is read from the on-disk artifact
   (`_finalize_and_gate_worklog`, `:2541`; `verify_disposition`). If blocked, dispatch
   returns `failed` with `work-log verification failed … (REQ-WL-007)` (`:2571`). A missing
   log fails CLOSED. `work_log_gate=False` disables only the blocking decision. This is
   platform machinery; as an author you don't produce the work-log, but be aware a
   successful skill can still be blocked here.

**Per-violation message format** (`_format_violations`, `output_validator.py:141`): one line
per JSON Schema error as `"<json_path>: <message>"` (json_path is `<root>` when empty),
capped at 10 with a `"... and N more"` tail. Empty file ⇒ violation
`"empty file (expected JSON conforming to schema)"` (`:201`). Parse failure ⇒
`"JSON parse failed: <exc>. First chars: '<first 120 chars>'"` (`:209`).

### 4.2 Retry-feedback envelope (what a *retry* attempt sees)

This only engages when the dispatch has a persistent `workspace_key` (so the workspace
survives Temporal activity retries). Mechanism:

1. On terminal validation failure, BEFORE workspace cleanup, the runtime writes a marker
   file `.previous-validation-failure.json` at the workspace root
   (`_write_failure_marker`, `agent_executor.py:167`; `:2514`). Its shape:

```json
{
  "feedback": "Path: <exc.path>\nSchema: <exc.schema_path>\nViolations:\n  - <v1>\n  - <v2>",
  "path": "<;-joined failing paths>",
  "schema_path": "<;-joined schema paths>",
  "violations": ["<path>: <violation>", ...]
}
```

2. Temporal retries the activity against the SAME `workspace_key`. The next `execute_skill`
   reads the marker (`_read_failure_marker`, `:147`; `:1939`) and folds the `feedback`
   string into the system prompt as the LAST section (`:406`–`:419`), headed
   `--- IMPORTANT: PREVIOUS ATTEMPT FAILED SCHEMA VALIDATION ---`, instructing the agent to
   emit ONLY valid JSON to `.json` paths (prose belongs in `.md` sidecars) and to re-emit
   every output file fresh (not partially patch).
3. On a clean run the success path clears the marker (`_clear_failure_marker`, `:202`;
   `:2529`) so stale feedback never bleeds into the next dispatch.

> The agent gets exactly **one** feedback-driven retry beyond the two in-process
> continuations; if it still fails, the dispatch fails and the workflow's normal retry
> policy decides next steps (`output_validator.py:11`–`:14`).

**Authoring implications:** (a) put narrative in a `.md` sidecar and machine data in the
`.json`; (b) always call `Write` to persist declared outputs (do not only produce them
inline); (c) populate required arrays fully (a valid-metadata / empty-arrays "skeleton"
passes the presence net but fails schema and burns a retry — the exact failure mode these
nets exist for, `:2433`).

---

## 5. Profile overlays, `depends_on`, and the registry entry

### 5.1 Profile overlays (three mechanisms, increasing precedence)

The cross-cutting skill is the abstract base; a client profile
(`profiles/<client>/`) may override it (`skill_loader.py:445`–`:461`;
`CONVENTIONS.md:127`). Precedence (least → most authoritative):

1. **Cross-cutting SKILL.md body** (base).
2. **Config variables** — `profiles/<client>/config/<skill-id>.yaml` (per-skill) merged over
   `profiles/<client>/config/common.yaml` (`_load_profile_variables`, `:485`; per-skill
   wins). At load time `{{name}}` tokens in the body are substituted from these variables
   (`_resolve_variables`, `:468`). **Unknown tokens are left literal on purpose** so a
   missing variable is visibly wrong in the rendered prompt (`:471`). *Author cross-cutting
   bodies with `{{token}}` placeholders for anything client-specific — never hardcode a
   client term* (`CONVENTIONS.md:150`). Real example: `cato-compliance/SKILL.md` cites
   `{{compliance_framework}}` / `{{control_baseline}}`.
3. **Reference additions** — `profiles/<client>/skills/<skill-id>/references/*.md` merged
   ON TOP of base references; profile keys win on filename collision
   (`_merge_profile_references`, `:521`).
4. **Full SKILL.md overlay** — `profiles/<client>/skills/<skill-id>/SKILL.md` REPLACES the
   body entirely (`_load_profile_overlay`, `:510`; applied `:572`). Frontmatter merge: the
   overlay wins where it specifies `description`, `agent`, `allowed-tools`, `provider`;
   otherwise base values are kept (`:576`–`:594`). `output_schemas` is NOT overridden by an
   overlay — the base's schemas are carried through (`:618`).

> **GOTCHA:** an overlay `SKILL.md` that omits a field inherits the base's — but if it
> declares `allowed-tools` as a non-list it is ignored and the base list is kept
> (`:586`–`:588`). The overlay body is still `{{token}}`-substituted after selection
> (`:602`–`:604`).

On the **API side**, profile skills are collected too: a profile dir WITH its own SKILL.md
is a standalone skill sourced `{profile_id}-profile` (overriding core), and a profile dir
WITHOUT a SKILL.md but with overlay content (references/assets/scripts/config) merges onto
the matching core skill (`skill_bootstrap.py:453`–`:486`,`:321`). The active profile is
resolved via the activation singleton → `OLYMPUS_PROFILE` env → default `faa`
(`:385`–`:412`).

### 5.2 `depends_on`

`depends_on` lives in the **registry entry** (`registry.yaml`), NOT in `SKILL.md`
frontmatter (no loader reads a frontmatter `depends_on`). It is a REQUIRED registry field —
declare `[]` when the skill has no upstream skill inputs (`CONVENTIONS.md:154`–`:169`).
Rules: list only DIRECT upstream skills whose artifact this skill reads at dispatch time;
do NOT list orchestration ordering (that lives in the workflow); when an upstream skill's
artifact schema changes, bump this skill's `version` (`CONVENTIONS.md:169`). CI enforces
that every registry entry has `depends_on` present (`CONVENTIONS.md:273`).

`depends_on` is documentation of data-flow — it does not by itself cause artifacts to be
staged. Actual staging is driven by the workflow's `input_artifacts` (§3.4). Keep the two
consistent: if you `depends_on` skill X, your workflow dispatch must list X's artifact in
`input_artifacts` for it to appear in `input-artifacts/`.

### 5.3 Registry entry (required companion to every SKILL.md)

Every skill needs one entry in `cross-cutting/skills/registry.yaml`
(`CONVENTIONS.md:173`). Required v1 fields (`CONVENTIONS.md:177`–`:189`), example matching
`classify-application`:

```yaml
- id: classify-application            # required; == directory name
  version: 1.0.0                      # required; semver
  category: Business Process & Automation   # required
  enrichment: partial                 # required; Minimal|Partial|Full
  line: Rationalization               # required; primary consuming line
  step: Step 8 — Classification & Risk Tiering  # optional
  is_orchestration: false             # required; false for real skills
  variants: []                        # optional
  profile_overrides:                  # optional; profiles with overlays
    - faa
  depends_on: []                      # required (may be empty)
  delegatable: false                  # optional; defaults false
```

Optional registry blocks (all ignored by the loader unless declared, unknown nested keys
tolerated — `CONVENTIONS.md:252`,`:336`): `currency` (`recency_window_days`,
`minimum_recent_executions`, `revalidation_interval_days`, `lapsed_action` ∈
`benchmark_required`\|`human_review_required`\|`quarantine`), and benchmark metadata
(`validation_commands`, `supported_stacks`, `failure_classes`, `benchmark_tags`).

CI (`CONVENTIONS.md:265`–`:275`) blocks the PR if: a workflow dispatches a name with no
SKILL.md on disk; a line README references a missing skill; the skill is double-registered;
the directory name violates the naming convention (noun phrase; `plan-*`/`step-*`/`execute-*`
prefixes are reserved for orchestration and flagged); or a registry entry omits
`depends_on`.

---

## 6. Minimal conformant skill — end-to-end checklist

To author a skill that the platform will load, dispatch, feed, validate, and retry
correctly:

1. Create `cross-cutting/skills/<skill-id>/SKILL.md` with frontmatter §1.3
   (`name`==dir, `description`, `agent`; `allowed-tools` if you need non-defaults;
   `output_schemas` if you emit structured artifacts).
2. Body (§1.4): `## Inputs` must instruct the agent to Read `input-artifacts/` and
   `input-artifacts/_dispatch-context.json` first and copy ids verbatim; `## Outputs` must
   name each declared output path and require it be written (via `Write`) into the output
   directory; require JSON-only content for `.json` outputs, narrative in `.md` sidecars.
3. If structured: add each output to `output_schemas` with a `schema:` pointing at an
   existing (or newly authored) Draft-2020-12 schema under `schemas/<line>/`.
4. Add sibling `references/`, `assets/`, `scripts/`, `config.json` as needed (staged to
   disk; enrichment level derives from these).
5. For client-specific content: use `{{token}}` placeholders and add
   `profiles/<client>/config/<skill-id>.yaml`; reserve a full profile overlay only when the
   methodology fundamentally differs.
6. Add the `registry.yaml` entry (§5.3) with `depends_on` (`[]` if none) and all required
   v1 fields; list variants/profile_overrides; consider a `currency` block for T1/T2 skills.
7. Ensure at least one workflow dispatches the skill by its registry id, listing the
   upstream artifacts your skill reads in `input_artifacts` (so `depends_on` and the actual
   staged inputs agree).

---

## Source index (primary tree only; stale trees excluded)

- `olympus-agent-runtime/src/services/skill_loader.py` — frontmatter schema, tier map,
  `output_schemas` coercion, provider/config precedence, profile overlays.
- `olympus-agent-runtime/src/services/agent_executor.py` — system-prompt assembly, workspace
  staging, input fetch, `_dispatch-context.json`, validation nets, retry marker.
- `olympus-agent-runtime/src/services/output_validator.py` — Draft-2020-12 validation,
  violation formatting, coalescing, schema resolution.
- `olympus-agent-runtime/src/models/a2a.py` — `A2AContext` / `A2ATaskResponse` /
  `OutputFile` envelope.
- `olympus-api/src/services/skill_bootstrap.py` — API-side frontmatter parser, enrichment
  level, DB upsert, profile scan.
- `olympus-api/src/services/return_payload_validator.py` — API `output_schemas` loader.
- `olympus-worker/src/agent_client.py` — task-message + context construction.
- `cross-cutting/skills/CONVENTIONS.md` — authoring conventions, registry schema, currency.
- `cross-cutting/skills/<skill>/SKILL.md`, `config.json`, `schemas/**/*.schema.json` —
  real examples.
