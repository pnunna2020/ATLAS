# 01 — olympus-api Service Layer — Part 2 (supporting modules + sub-packages)

Continuation of `01-api-services.md`. Each module: responsibility + key entry points (path:line for the
public functions). All follow the conventions in Part 1 (async `text()` SQL, `OlympusHTTPException`, structlog).

---

## Agent / attribution / telemetry

### `agent_attribution.py` (172 LOC) — attribution stamping (P10-W2, REQ-AA-004/005/006)
Stamps every agent/human-with-agent mutation onto the existing `audit_log`. Entry points:
`record_agent_action(db, acting_user, session_id, intent_id, resource_type, resource_id, action, details)`
— writes an audit row with `actor_kind="human_with_agent"` + session/intent ids (used by `nl_engine._run_action`);
`record_human_action(...)` — the plain-human counterpart.

### `agent_client.py` (249 LOC) — provider-agnostic A2A dispatch client
Sends a skill task to an agent runtime over A2A and normalizes the result. Entry point:
`dispatch_via_a2a(agent_url, task_input) -> AgentTaskResult` — the canonical single-skill dispatch path
(reused by `capabilities/service.py` and `skills/{id}/dispatch`). Helpers `_keepalive_transport`,
`_build_task_message`, `_build_context`, `_extract_result`.

### `agent_roles.py` (385 LOC) — agent-role analytics (P5-AUDIT-011, Cluster D)
`get_agent_roles(db, ...)` — aggregates per-skill/per-role activity + model tier. Helpers
`load_agent_roles_config`, `_worker_config_dir`, `_safe_execute`, `_aggregate_per_skill`, `_combine_per_role`,
`_resolve_model_tier`.

### `agent_runs.py` (92 LOC) — cross-app agent error queries
`list_recent_errors(db, ...)` — recent failed agent runs across apps.

### `agents.py` (179 LOC) — telemetry ingestion (P5-S26, slimmed)
`record_task_start(...)`, `record_task_complete(...)` — write agent-task telemetry rows.

### `audit_log.py` (293 LOC) — centralized RBAC audit aggregation (P6-S6.6)
`query_audit_events(db, ...)` — filtered/paginated audit query. Helpers `_iso`, `_aware`.

### `model_usage.py` (235 LOC) — model usage analytics (P5-S26)
`get_model_usage(db, ...)` — per-model call counts + cost estimate. Helpers `_classify`, `_safe_execute`.

### `viewer_analytics.py` (159 LOC) — viewer analytics (P5-S30.11)
`record_events(db, events)`, `summarize(db, ...)`. `_missing_relation`, `_safe_execute` swallow a missing table.

---

## Gate support / RBAC

### `gate_rbac.py` (227 LOC) — gate-type → reviewer-role resolution (P6-S6.3/6.4)
`resolve_gate_review_policy(gate_type, profile) -> GateReviewPolicy` (minimum_approvals, oversight_role,
allowed reviewer roles); `evaluate_approver(policy, user, ...) -> ApproverDecision`. Helpers
`_profile_extension_roles`, `_platform_default`. Feeds `gate.record_gate_approval`.

### `delegation.py` (441 LOC) — scoped revocable on-behalf-of delegation (P10-W10, REQ-NS-005..011)
`DelegationError`; `compute_scope_hash(...)`; `grantor_rights_admit(...)`; `authorize_delegated_action(...)` —
the enforcement gate for a delegated call; `issue_grant / get_grant / list_active_grants / revoke_grant`;
`record_delegated_action / record_delegated_refusal`. `_utcnow`, `_row_to_grant`.

---

## Portfolio / profiles / identity / users

### `portfolio.py` (147 LOC) — `get_portfolio_summary`, `get_portfolio_manifest`.

### `portfolio_membership.py` (228 LOC) — `portfolio_membership` R/W. `PortfolioMembership` model; `is_member`,
`get_membership`, `list_user_portfolio_ids` (drives the non-admin allowlist injected across services),
`list_portfolio_members`, `add_member`, `remove_member`. `_coerce_role`.

### `profile_loader.py` (728 LOC) — Client Profile Loader (P4-S4)
Parses `profiles/<id>/*.yaml` into a `Profile` (frozen dataclasses `ProfileMetadata`, `Compliance`, `RiskTier`,
`RiskClassification`, `GateOverride`, `Gates`, `ScoringDimension`, `Scoring`, `Technology`). `ProfileLoadError`.
`load_profile(root)` / `discover_profile_root()`; `_validate_declared_cardinality` enforces declared counts
(lines/gates/dispositions/tiers). Per-section loaders `_load_metadata/_load_compliance/...`.

### `profile_activation.py` (126 LOC) — profile activation (P4-S4.3/4.4)
Process-wide active profile. `active_profile() -> Profile|None`, `activate_profile(id)`, `deactivate_profile()`.
`ProfileActivationError`.

### `identity_config.py` (90 LOC) — active-profile identity config loader (P4-S1.11)
`get_identity_config()` / `refresh_identity_config()` / `set_identity_config_for_test()`;
`_discover_identity_path` reads `profiles/<client>/config/identity.yaml`.

### `compliance_pack.py` (110 LOC) — profile-driven compliance pack (P7-S16.2)
`ControlSpec`, `CompliancePack`; `compliance_pack_from_profile(profile)`, `active_compliance_pack()`;
`_coerce_controls`.

### `user.py` (436 LOC) — user/credential service (P4-S1.11)
`list_users`, `get_user`, `get_user_by_login`, `get_user_by_external_identity`, `create_user`, `update_user`,
`set_password`, `deactivate_user`, `record_login`, `upsert_oidc_user`. `_row_to_profile`.

### `password.py` (70 LOC) — password hashing (P4-S1.11)
`hash_password`, `verify_password`, `PasswordError`. `_cost`, `_encode` (bcrypt-family cost params).

---

## Assembly lines / systems / lineage / insights

### `lines.py` (484 LOC) — Assembly Lines service (P4-S1.2)
`list_lines`, `get_line`, `get_line_status`, `get_line_throughput`, `line_dependencies`, `line_mandatory_gates`,
`resolve_startable_line` / `resolve_startable_line_workflow`, `line_id_prefix`, `_derive_workflow_name`.
`LineInfo`; `_canonical_line_name`.

### `system.py` (857 LOC) — system / capability / business-domain reads (Phase 5 PR#2)
`list_systems`, `get_system`, `list_capabilities_for_system`, `get_capability`, `get_capability_lineage`,
`list_business_domains_for_system`, `get_system_lineage`, `get_lineage_row`, `list_wave_capability_lineage`;
governed ratification: `ratify_capability_lineage_row`, `reject_capability_lineage_row`;
compliance rollup: `get_portfolio_compliance_rollup`, `_classify_compliance_status`, `_is_cato_certified`.
`_get_lineage_row_or_404`, `_row_view`.

### `lineage.py` (123 LOC) — `get_application_lineage(db, app_id)` (application lineage read).

### `rationale.py` (229 LOC) — retrospective traceability for target apps.
`get_application_rationale(db, app_id, ...)`; `_load_rationalization_gates`, `_artifact_refs_for_source`.

### `target_state_rollup.py` (462 LOC) — Portfolio Target-State Rollup (P5-S12/W11)
`get_target_state_rollup(db, portfolio_id)` — aggregates per-wave synthesis / disposition-recommendation
artifacts; `_derive_synthesis_from_dispositions` fallback; `_synthesis_path`, `_disposition_recommendation_path`,
`_list_portfolio_waves`, `_read_synthesis`, `_read_disposition_recommendation`, `_aggregate`.

### `insights.py` (724 LOC) — Application Detail insights + decisions timeline.
`get_insights(db, app_id)` and `get_decisions_timeline(db, app_id)`; reads score history, structural-analysis
artifact, architecture, tech stack, line progress. `_normalize_score_to_fraction`, `_components_from_artifact`,
`_read_structural_analysis_artifact`, `_fetch_*` helpers.

### `disposition_output.py` (156 LOC) — read per-disposition output bundles from the artifact repo.
`get_disposition_output(db, app_id, ...)`; `_artifact_path`, `_load_app_portfolio`.

### `design_review.py` (291 LOC) — design-review surface (Phase 6 W9).
`list_design_artifacts(db, app_id, ...)`, `submit_design_feedback(...)`. `_type_for_path`, `_canonical_line`,
`_stem`, `_load_app`.

---

## Traceability / knowledge graph / memory

### `traceability.py` (612 LOC) — citation parsing, indexing, trace queries, validation
`parse_citations(text)` (`{artifact}:{section}:{finding}` / `{repo}:{file}:{line}`), `index_citations(...)`,
`forward_trace`, `backward_trace`, `detect_staleness`, `compute_coverage`, `cross_validate`,
`validate_gate_traceability`, `normalize_input_origin`, `record_input_provenance` (W1's `{path,origin,attestation}`
stamp reused by `scoped_execution.propose_inputs`), `get_input_provenance`, `get_output_attributions`.

### `graph_projection.py` (679 LOC) — typed lifecycle graph over `traceability_link`
`build_graph_view`, `classify_graph_node`, `provenance_for`, `assert_required_upstream`, `apply_artifact_change`,
`view_fingerprint`, `rebuild_if_diverged`, `minimal_subgraph`, `fetch_links_for_profile`,
`resolve_agent_graph_context`. `ProfileBoundaryViolation`; `GraphContextResolver`.

### `connected_memory.py` (336 LOC) — typed projection over `traceability_link`
`build_connected_memory_view`, `query_memory`, `classify_node`, `fetch_links`, `resolve_connected_memory`.
`DbContextResolver`.

---

## Skills

### `skill_registry.py` (362 LOC) — skill registry loader (parses `cross-cutting/skills/registry.yaml`)
`SkillVariant`, `SkillEntry`, `DispatchAlias`, `Registry` (`find`, `skills`, `variants`); `load_registry`,
`get_registry` (cached), `reset_cache`; builds `LINE_MAP`, `DISPATCH_TO_DIR`, `DIR_TO_DISPATCH`, fallback
description/agent. `__getattr__` re-exports legacy names. Single source of truth for capability→skill validation.

### `skill.py` (578 LOC) — skill lifecycle CRUD + per-line metrics
`list_skills`, `get_skill`, `create_skill`, `update_skill`, `delete_skill`, `get_skill_by_dispatch_id`,
`list_line_skill_metrics`. `_row_to_detail`, `_line_ids_for`, `_task_type_to_line`, `_accumulate_counters`.

### `skill_metrics.py` (117 LOC) — projection keyed by `skill_id`
`recompute_skill_metrics(db, skill_id)`, `get_skill_metrics(db, skill_id)`.

---

## Intake / interview / source

### `intake.py` (729 LOC) — intent-intake service (P8 intent-intake)
Structured mission-intent front door. `IntakeService` (guided prompts, coverage), `derive_requirements(...)`,
`classify_material(...)`, `acknowledged_material_criteria`, `_next_guided_prompt`, `_decision_covered`,
`_find_requirement`. `IntakeError`.

### `interview.py` (718 LOC) — requirements-interview session (P6-S5.12)
`start_interview`, `submit_turn`, `get_session`, `complete_interview`, `expire_due_sessions`. Validates the
`requirements-capability` schema (`validate_requirements_capability`); phase-driven questions (`_phase_question`),
preview build, artifact finalize (`_finalize_artifact`), live signal emit. `_load_app`, `_active_session_row`,
`_state_from_row`, `_accumulate`.

### `source_intake.py` (619 LOC) — non-Git application source intake (P5-S14/W13)
Providers for Zip / S3 / Confluence / SharePoint / GDrive / GCS (each a `SourceProvider`). `build_provider(...)`,
`destination_for(...)`. Security: `_is_unsafe_zip_entry` (zip-slip guard), `_LimitedReader` (size cap),
`_strip_common_prefix`, `_parse_s3_uri`. `SourceIntakeError`, `SourceIntakeNotImplemented`. Produces a
`SourceIntakeResult(local_path=...)` consumed by `application.create_application`.

---

## Human-paired / bundle contract / delegation-bundle helpers

### `human_paired_agent.py` (556 LOC) — human-paired-agent task surface (Phase 5)
`list_my_tasks(db, user)`, `return_task(...)` (with strict `_validate_return_payload`), session-artifact
persistence, `render_task_audit_narrative`. `_row_to_my_task_summary`, `_jsonb_param`.

### `bundle_contract.py` (522 LOC) — bundle contract resolver (Phase 5 W20)
`resolve(db, scope_kind, target_id, application_id, wave_id) -> BundleContract` — resolves the input/output
artifact contract for a step/gate scope (consumed by `bundle.dispatch_from_kickoff`). `known_gate_targets`,
`known_step_targets`, `_outputs_for`, `_default_inputs_for_app/_wave`, `_resolve_app/_wave_metadata`.

---

## Evidence / compliance / OSCAL

### `evidence_emit.py` (413 LOC) — automatic evidence-emission backbone (P8 evidence-layer-delta)
`EvidenceEmitService(db)` — `emit(evidence: EvidenceRecordInput, envelope: CtEnvelope, mappings, subject_kind,
subject_id, commit) -> EmissionResult|None`. Content-addresses per `(portfolio_id, control)`; enqueues an
`evidence.created` outbox event with `idempotency_key=content_hash`; suppression table returns None.
`EvidenceWriteError` (durability → callers fail-closed), `EmissionResult(record, ...)`. Reused by capability
provenance + autonomy escalation.

### `evidence_ledger.py` (540 LOC) — immutable content-addressed evidence ledger (P7-S16.16)
`EvidenceLedgerService` — append + verify. `canonical_payload`, `compute_content_hash`, `verify_record`,
`verify_chain` (hash-chain integrity). `EvidenceLedgerError`, `_record_from_row`, `_jsonable`.

### `evidence_export.py` (317 LOC) — compliance evidence export bundles (P6-S8.10)
`build_evidence_zip(...)`, `build_integrity_manifest(...)`, `build_pdf_summary(...)`. `AppEvidence`, `_slug`,
`_escape_pdf_text`, `_readme`.

### `evidence_oscal.py` (166 LOC) — run-scoped OSCAL assessment-results assembler (P8, REQ-EV-007)
`assemble_assessment_results(...)` → OSCAL JSON; `content_digest(...)`; `_det_uuid` (deterministic uuid),
`_status_to_oscal`.

### `control_mapping.py` (158 LOC) — control-mapping read + governed-ratification store (P8)
`ControlMappingService` — read mappings; governed ratification of a mapping.

---

## Evals / decomposition support

### `eval_harness.py` (319 LOC) — AI-reviewer quality measurement (P7-S16.8)
`record_eval_result(...)`, `get_model_eval_summary(...)`, `compute_variance_report(...)`. Statistics:
`cohens_kappa`, `kappa_strength`, `_summarize_rows`.

### `evals_run.py` (521 LOC) — eval-harness EXECUTION + gating (P8 evals-harness-delta)
`validate_case(case)` — rejects self-grading / criterion-less `EvalCase` (REQ-EH-006; reused by capability
`verification.py`); `run_eval_case(...)`, `summarize_run_variance`, `compute_run_variance`,
`evaluate_regression`, `evaluate_stability`, `routing_justification`, `get_dispatcher`. `_is_mock_mode`,
`_mock_dispatch`, `_insert_run`.

### `return_payload_validator.py` (521 LOC) — strict output-spec validator for `POST /agent-tasks/{id}/return`
`validate_return_output_payload(skill_id, output_payload, payload_path) -> (violations, debug)` — JSON-Schema
validation against a skill's declared `output_schemas` (reused by capability `service`/`verification`).
`load_output_schemas_for_skill(skill_id)`, `resolve_output_producer`, `build_output_attributions`,
`record_output_attributions`, `reset_cache`. `_detect_missing_capability_id`, `_select_schema_entry`,
`_format_violation`.

---

## Events / signals / outbox / scheduling

### `event_outbox.py` (337 LOC) — transactional event-outbox (P7-S16.10 / P8)
`enqueue_event(db, event_type, payload, aggregate_type, aggregate_id, profile_id, owner_scope,
idempotency_key) -> outbox_id` — writes an outbox row on the caller's session (not committed here).
`drain_outbox(...)` — delivers pending rows, deduping via `_key_already_delivered(idempotency_key)`
(REQ-EO-006; this is where capability-run idempotency is honored). `backoff_seconds`, `_next_retry_iso`,
`_coalesce_status`, `_to_event`. GOTCHA: idempotency is enforced at the DRAIN, keyed on `idempotency_key`.

### `signal_inbox.py` (112 LOC) — DB-backed workflow signal inbox
`enqueue_signal(...)`, `mark_queued(...)`, `list_pending(...)` — durable retry buffer for Temporal signals.

### `governance_schedule.py` (124 LOC) — governance sweep Temporal Schedule management (P6-S8.6)
`create_governance_schedule(...)`, `delete_governance_schedule(...)`, `set_governance_schedule_paused(...)`,
`schedule_id_for(...)`.

---

## Catalog / reusable parts / performance / workflow health

### `catalog_facets.py` (632 LOC) — asset-catalog facets (P8): tenancy scope, consumers, notifications, regression
`scope_permits(...)`, `consume_part(...)`, `notify_version_delta(...)`, `detect_regression(...)`,
`run_regression_watch(...)`, `staleness_days_for_profile(...)`. `_entry_classification_rank`,
`_target_clearance_rank`, `_entry_from_row`, `_consumer_from_row`, `_consumers_for_part`.

### `reusable_parts.py` (637 LOC) — reusable-parts catalog + publication-gate (P7-S16.11)
`register_part(...)`, `list_catalog(...)`, `get_entry(...)`, `record_review(...)`, `publish_part(...)`.
`resolve_eval_status`, `_contract_review`, `_latest_publication_decision`, `_entry_row`, `_review_from_row`.

### `performance_report.py` (452 LOC) — wave performance report aggregator (task #94)
`get_wave_performance_report(db, wave_id)` — per-step durations + bottleneck detection.
`_percentile`, `_detect_bottlenecks`, `_as_float`.

### `workflow_health.py` (531 LOC) — cross-workflow health surface
`list_workflows(...)`, `get_workflow_detail(...)`, `restart_workflow(...)`, `fail_workflow(...)`.
`_extract_app_id_from_workflow_id`, `_app_names`, `_summarize`, `_latest_failure_event`,
`_build_aged_out_workflow_detail`, `_elapsed`, `_temporal_ui_url`.

### `wave_assignment.py` (161 LOC) — `assign_waves(apps, ...)` — groups unassigned apps into waves. `_sort_key`.

### `wave_target_provisioning.py` (513 LOC) — lineage seeding from disposition-recommendation artifacts (task #86)
`seed_targets_from_artifacts(...)` — reads disposition-recommendation artifacts and seeds target repos +
lineage. `load_wave_apps`, `_read_disposition_artifact`, `_synthesize_target_repo`, `_extract_target_config`,
`_lineage_relationship_for`, `_parse_agent_json`. `SeededTarget`, `ArtifactSeedResult`.

### `mcp_client.py` (64 LOC) — thin async client for the Olympus MCP server.
`read_mcp_resource(uri, ...)`; `_get_base_url` (env-configured).

### `nl_agent.py` (560 LOC) — agentic tool-use loop for the NL Action Console (P10-W6, REQ-NL-016/017)
`run_agent_loop(...)` — Bedrock native tool-use loop wiring the `nl_tools` catalog (read/nav in-loop) +
`nl_engine` write actions. `build_tool_defs()`, `agent_system_prompt(...)` (shares `nl_engine._grounding_preamble`,
adds tool-use rules — NO JSON contract, GOTCHA), `_run_one_tool`, `_result_block`, `_parse_block_result`.
`AgentEvent`, `TurnResult`.

---

## Sub-package: `decomp/` — feature/blueprint decomposition (P8 decomposition-agent-delta)

- **`gate.py` (185 LOC)** — the CRITICAL-NODE review gate (the load-bearing guarantee).
  `load_criticality_review_floor(profile)` (from `profiles/`), `node_requires_review(node, floor)`,
  `evaluate_work_order_gate(...)` → `GateDecision`. `_is_reviewed`, `_resolve_profiles_root`. A work order
  cannot be generated over an unreviewed critical node.
- **`linking.py` (270 LOC)** — IntentRecord → requirement hierarchy + bidirectional impact.
  `expand_intent_to_hierarchy(...)`, `hierarchy_from_payload(...)`, `propagate_impact(...)`. `_trace_ref`,
  `_children_of`, `_descendants`, `_ancestors`, `_node_from_schema_dict`. `DecompositionError`.
- **`impact.py` (85 LOC)** — `DecompImpactService` — bidirectional impact propagation on node revision (REQ-DA-004).
- **`persistence.py` (474 LOC)** — `DecompPersistService` — persist hierarchy + review + GATED work-order
  generation. Errors `DecompPersistError`, `HierarchyNotFoundError`, `UnreviewedCriticalNodeError`.
  `_content_digest`, `_roll_up_gate_status`.

## Sub-package: `drift/` — drift detection (P8 drift-detection-delta)

- **`obligations.py` (169 LOC)** — obligation DERIVATION from registered specs (REQ-DR-001/007).
  `derive_obligations(...)` from Python signatures (`_derive_from_python`) or JSON Schema
  (`_derive_from_json_schema`). `_signature`. `SpecObligationError`.
- **`persistence.py` (416 LOC)** — `DriftPersistService` — persist a directional + severity-scored
  `DriftReport`. `DriftPersistResult`, `_classified_to_persisted`, `_content_digest`.
- **`reconcile.py` (85 LOC)** — no-cross-boundary-auto-edit guard (REQ-DR-008).
  `guard_no_cross_boundary_write(...)` (raises `CrossBoundaryWriteError`), `build_proposed_diff(...)`.
- **`thresholds.py` (113 LOC)** — profile-configured severity thresholds (REQ-DR-010).
  `load_drift_thresholds(profile)`, `evidence_controls_for_profile(profile)`. `_coerce_config`,
  `_resolve_profiles_root`.

## Sub-package: `drift_control/` — drift-as-control (P8 drift-as-control-delta)

- **`models.py` (124 LOC)** — `DriftControlVerdictModel`, `RiskAcceptanceRequest`, `RiskAcceptanceResult`,
  `DriftControlBlockRow`, `DriftControlStatusPage`.
- **`evaluation.py` (199 LOC)** — `DriftControlEvaluator` — verdict resolution (REQ-DC-001/002/003).
  `load_drift_control_config(profile)`, `evidence_controls(...)`. `_resolve_profiles_root`.
- **`risk_acceptance.py` (223 LOC)** — `DriftControlRiskAcceptanceService` — human risk-acceptance of a
  failing drift-control. `DriftControlRiskAcceptanceError`.
- **`status.py` (80 LOC)** — `DriftControlStatusService` — status read surface (REQ-DC-007). `_row_to_model`.

## Sub-package: `feedback/` — feedback → work-order loop (P8 feedback-loop-delta)

- **`loop.py` (848 LOC)** — the feedback → work-order loop. `FeedbackConfig`, `load_feedback_config(profile)`;
  `classify(...)`, `ingest_sources(...)` (with cursor tracking `_get_cursor`/`_bump_cursor`/`_source_already_captured`),
  `escalate_recurrence(...)`, `generate_work_order(...)`, `complete_work_order(...)`,
  `propose_distillation(...)` → `DistillationProposal`. Audit via `_write_audit`; `_open_item_for_signature`,
  `_latest_closed_item_for_signature`, `_insert_pending_item`. `_resolve_profiles_root`.

---

## Module inventory verification

Top-level (69, incl. `__init__.py`): agent_attribution, agent_client, agent_roles, agent_runs, agents,
application, audit_log, bundle, bundle_contract, catalog_facets, compliance_pack, connected_memory,
control_mapping, delegation, design_review, disposition_output, eval_harness, evals_run, event_outbox,
evidence_emit, evidence_export, evidence_ledger, evidence_oscal, gate, gate_rbac, git_service,
governance_schedule, graph_projection, human_paired_agent, identity_config, insights, intake, interview,
layer_resolution, lineage, lines, mcp_client, model_usage, nl_agent, nl_engine, oidc, password,
performance_report, portfolio, portfolio_membership, profile_activation, profile_loader, rationale,
return_payload_validator, reusable_parts, scoped_execution, scoring, signal_inbox, skill, skill_bootstrap,
skill_metrics, skill_registry, source_intake, step_mapping, system, target_state_rollup, traceability, user,
viewer_analytics, wave, wave_assignment, wave_target_provisioning, workflow_control, workflow_health.

Sub-packages (7): `autonomy/` (7 files: __init__, escalation, incidents, models, policy, status, store);
`capabilities/` (9: __init__, allowlist, defaults, models, provenance, run_event, service, store, verification);
`decomp/` (5: __init__, gate, impact, linking, persistence); `drift/` (5: __init__, obligations, persistence,
reconcile, thresholds); `drift_control/` (5: __init__, evaluation, models, risk_acceptance, status);
`feedback/` (2: __init__, loop); `nl_tools/` (3: __init__, catalog, executor).
