# 00 — Olympus System Overview & Map

> ATOMIC regeneration spec. Premise: the codebase is deleted; this document set is the only surviving artifact. All facts below are derived from LIVE code at `/Users/pnunna/Documents/GitHub/olympus` on 2026-07-03 (branch `main`, HEAD `6c99bb6b214d65cc6a5ed65dddbc7a399404decb`). Every non-trivial claim cites `path:line`. This regeneration set SUPERSEDES the 2026-07-02 set (commit 22976138), which was ~184 commits stale — every count here was re-verified against live code.

---

## 1. What Olympus Is

Olympus is a **domain-customizable framework and platform for modernizing enterprise application portfolios using AI-native processes** — it defines named, composable "assembly lines" where humans and AI agents co-produce enterprise software through structured quality gates and continuous improvement (`README.md:1-14`). It operates at **AI Maturity Level 3-4**: agents execute autonomously within defined lines, humans review completed work and approve at gates; the human role is oversight, not step-by-step approval (`README.md:16`). It is API-first: every capability is an endpoint the dashboard consumes, orchestration flows through Temporal OSS, Git is the source of truth for artifacts, and PostgreSQL is a derived/disposable query layer (`CLAUDE.md` Core Principles).

---

## 2. The Four Pillars (live directory counts)

| Pillar | Dir | Live count | Members |
|---|---|---|---|
| **Assembly Lines** | `assembly-lines/` | **12 dirs** | architecture, build, data, deployment, discovery, disposition, governance, modernization, rationalization, **reverse-engineering**, sustainment, validation |
| **Cross-Cutting Concerns** | `cross-cutting/` | **12 dirs** | agents, compliance, extensibility, gates, hcd, human-agent-collaboration, orchestration, risk-classification, security, skills, templates, traceability |
| **Client Profiles** | `profiles/` | **4 dirs** | baseline, faa, test-generic, vba |
| **Platform Specifications** | `specifications/` | (spec corpus) | phased plans + contracts + decisions |

Verified via `ls -d assembly-lines/*/ cross-cutting/*/ profiles/*/`.

> **GOTCHA (count drift — assembly lines):** The parent task expected **11** assembly-line dirs, and the 2026-07-02 spec recorded 11. Live filesystem now holds **12** — `reverse-engineering/` was added since the prior spec. `CLAUDE.md` prose narrates "10 assembly lines" and enumerates the reverse-engineering skill line separately; the live dir count is 12. `assembly-lines/overview.md` is a FILE, not one of the 12 dirs.

> **GOTCHA (count drift — cross-cutting):** `CLAUDE.md` narrates "11 cross-cutting concerns / capabilities" but the live filesystem holds **12** cross-cutting dirs — `cross-cutting/templates/` is the 12th and is not one of the "11 capabilities" the prose enumerates.

Each assembly line follows the convention `README.md` (single source of truth) + `artifacts.md`. Profiles are YAML bundles — **7 bundles** per profile validated by `make validate-profile` (`Makefile:206-207`).

---

## 3. Service Inventory / Runtime Topology

### 3.1 Top-level service packages

Each package is independently testable with its own `pyproject.toml` / `package.json`.

| Package | Language / framework | Distribution / module | Purpose |
|---|---|---|---|
| `olympus-api/` | Python, **FastAPI** + pydantic-settings + SQLAlchemy(async/asyncpg) + Temporal client | `olympus-api`, module `src` | REST/WS backend. API-first: every capability is an endpoint. Activates a client profile against the 6 registries at startup (`src/main.py` `activate_profile()`). Serves `/health`, `/health/ready` on `:8000`. Config in `olympus-api/src/config.py:108`. |
| `olympus-worker/` | Python, **Temporal SDK** worker | `olympus-worker`, module `src` | Registers all workflows + activities and polls the shared `olympus-main` task queue. Entrypoint `python -m src.worker` (`olympus-worker/src/worker.py:8`). Derives a unique-per-replica Temporal identity from hostname+pid (`worker.py:35-54`). |
| `olympus-agent-runtime/` | Python, FastAPI + **Claude Agent SDK on Bedrock** | `olympus-agent-runtime`, module `src` | Agent dispatch service. `AGENT_NAME` selects the registered identity served; one general-purpose image per DECISION-019. Config `olympus-agent-runtime/src/config.py:12`. Serves `/health` on `:8100`. |
| `mcp-server/` | Python, **MCP protocol server** (asyncpg to Postgres) | `olympus-mcp`, module `olympus_mcp` | Exposes Olympus resources/tools over MCP. Entrypoint `python -m olympus_mcp.server [--host --port]` (`mcp-server/olympus_mcp/server.py:12`). Serves on `:3001`. |
| `olympus-cli/` | Python | `olympus-cli`, module `olympus_cli` | Collaboration CLI — fetch/accept/return human-paired-agent tasks from a local dev machine. |
| `olympus-contracts/` | Python (shared types + JSON schemas + assembly-line YAMLs) | `olympus-contracts`, module `olympus_contracts` (`olympus-contracts/pyproject.toml:6`) | Generated/shared contract types, enums (incl. `RiskTier`), and the canonical assembly-line contract YAMLs. Editable-installed into other packages. |
| `dashboard/` | **React + USWDS** (Vite, Vitest, Playwright) | npm package | Frontend that consumes the API. Dev server `:3000`. |
| `temporal/olympus_workflows/` | Python, **Temporal workflow + activity definitions + registries** | `olympus_workflows` | The workflow/activity library imported by the worker (`ALL_WORKFLOWS`, `ALL_ACTIVITIES` from `temporal/olympus_workflows/worker.py:191,258`). Holds the 6 extension registries. **26** `@workflow.defn` definitions across `workflows/`. |

### 3.2 Dependency graph (service-to-service)

```
                       ┌──────────────┐
  browser ───:3000────▶│  dashboard   │───:8000 (VITE_API_BASE_URL)──▶ olympus-api
                       └──────────────┘                                   │
                                                                          │ SQLAlchemy/asyncpg :5432
                              ┌───────────────────────────────────────────┤ Temporal client :7233
                              │                                            │ Redis :6379
                              ▼                                            ▼
                        ┌──────────┐                               ┌───────────────┐
                        │ postgres │◀── asyncpg :5432 ──── mcp-server (:3001)      │
                        │  :5432   │                               │ olympus-api   │
                        └────┬─────┘                               └───────────────┘
                             │  (also DB backend for Temporal: temporal + temporal_visibility DBs)
                             ▼
                     ┌────────────────┐   gRPC :7233   ┌───────────────────────┐
                     │ temporal-server│◀───────────────│ olympus-temporal-worker│
                     │    :7233       │  polls olympus-main task queue          │
                     └────────────────┘                └───────────┬───────────┘
                             ▲                                      │ A2A dispatch
                             │ :8080 (temporal-ui)                  ▼ http://olympus-agent:8100
                       ┌──────────┐                        ┌──────────────────┐   least_conn
                       │temporal-ui│                       │ olympus-agent (LB)│───────────▶ olympus-agent-runtime × N
                       └──────────┘                        │  HAProxy :8100    │            (Bedrock/Claude Agent SDK)
                                                           └──────────────────┘
```

- `olympus-api` depends on `db-migrate` (completed), `postgres` (healthy), `temporal-server` (healthy), `redis` (healthy) (`docker-compose.yml:212-220`).
- `olympus-temporal-worker` depends on `db-migrate`, `temporal-server`, `postgres`; dispatches agent work to the HAProxy LB at `http://olympus-agent:8100` (`docker-compose.yml:261,290-296`).
- `olympus-agent` (HAProxy LB) depends on `olympus-agent-runtime` (healthy); fans out with `least_conn` (`docker-compose.yml:495-497`, `infra/haproxy/agent-lb.cfg`).
- `olympus-mcp-server` depends on `db-migrate`, `postgres` (`docker-compose.yml:520-524`).
- `dashboard` depends on `olympus-api` (healthy) (`docker-compose.yml:339-341`).
- `temporal-server` and `temporal-namespace-init`/`temporal-ui` depend on `postgres`/`temporal-server` (`docker-compose.yml:84-92,102-125`).

### 3.3 docker-compose runtime topology — 13 services

Full config in **`00b-environment.md`**. Ports summary:

| # | Compose service | Image / build | Host port(s) | Role |
|---|---|---|---|---|
| 1 | `postgres` | `postgres:16` | 5432 | App DB (`olympus`) + Temporal DBs (`temporal`, `temporal_visibility`) |
| 2 | `redis` | `redis:7` | 6379 | Cache / rate-limit backing |
| 3 | `localstack` | `localstack/localstack:latest` | 4566 | Local S3 + Secrets Manager emulation |
| 4 | `db-migrate` | build `db/Dockerfile` | — | One-shot `alembic upgrade head`; `restart: "no"` |
| 5 | `temporal-server` | `temporalio/auto-setup:latest` | 7233 | Temporal cluster (Postgres-backed) |
| 6 | `temporal-namespace-init` | `temporalio/auto-setup:latest` | — | One-shot: sets `default` namespace retention → 2160h (90d); `restart: "no"` |
| 7 | `temporal-ui` | `temporalio/ui:latest` | 8080 | Temporal web UI |
| 8 | `olympus-api` | build `olympus-api/Dockerfile` | 8000 | FastAPI backend |
| 9 | `olympus-temporal-worker` | build `olympus-worker/Dockerfile` | — (scale-safe, no host port) | Temporal worker pool |
| 10 | `olympus-dashboard` | build `dashboard/Dockerfile` | 3000 | React/USWDS UI |
| 11 | `olympus-agent-runtime` | build `olympus-agent-runtime/Dockerfile` | — (`deploy.replicas: 3` default; scale to 8 via Makefile) | Agent runtime replicas |
| 12 | `olympus-agent` | `haproxy:2.9-alpine` | 8100 | HAProxy LB in front of the runtime pool (`least_conn`) |
| 13 | `olympus-mcp-server` | build `mcp-server/Dockerfile` | 3001 | MCP protocol server |

Named volumes: `postgres-data`, `redis-data`, `localstack-data`, `agent-workspace` (`docker-compose.yml:532-536`).

---

## 4. Document-set Index

| Doc | Purpose (one line) |
|---|---|
| `00-overview.md` | (this doc) system map: pillars, service inventory, runtime topology, doc index, coverage floors, drift-register seed |
| `00b-environment.md` | Everything to STAND UP the system: all 13 compose services (full config), every env var, Temporal worker config, volumes, seed scripts, all 35 Makefile targets, local-vs-deployed, from-zero runbook |
| `01-api*.md` | FastAPI backend: routers, endpoints, request/response models, auth/RBAC, config, DB session, startup profile activation |
| `02-worker/agent-runtime/mcp/cli.md` | Temporal worker bootstrap, agent-runtime dispatch/inference providers, MCP server resources/tools, CLI commands |
| `03-workflows/` | Every `@workflow.defn` (26 workflows): signals, queries, child-workflow fan-out, retry policies, gate staging |
| `03b-activities/` | Every `@activity.defn` / `@foundry_activity`: inputs, outputs, side-effects, retry, timeouts |
| `04-data-layer.md` | PostgreSQL schema, SQLAlchemy models, Alembic migration chain, JSONB query layer, seed data shapes |
| `05-dashboard*.md` | React pages + components, USWDS usage, API client, WebSocket wiring, routing |
| `06-contracts.md` | `olympus-contracts` shared types, enums (`RiskTier` IntEnum), JSON schemas, assembly-line contract YAMLs |
| `07-framework.md` | Pillar spec content: assembly-line READMEs, gates, dispositions, risk tiers, cross-cutting concerns |
| `08-build-ci.md` | Dockerfiles, CI workflow matrix, coverage gates, lint, drift checks, branch protection |
| `09-regeneration-order.md` | The order to rebuild components so dependencies resolve |
| `11-skill-registry.md` | Skill catalog / `registry.yaml` structure and wiring |
| `13-generation-engine.md` | Modernization Extract→Design→Generate factory + Ralph Loop |
| `skill-authoring-contract.md` | `SKILL.md` schema + pydantic contract + fixtures convention |
| `DRIFT-REGISTER.md` | Running table of code-vs-spec / code-vs-docs discrepancies |

---

## 5. Coverage Floors (verified from each package's `pyproject.toml` addopts + CI)

CI runs `pytest` with each package's own `addopts` (which carry `--cov-fail-under`); the matrix in `.github/workflows/ci.yml:893-914` sets only `cov_source`, so the fail-under floor comes from `pyproject.toml`.

| Package | Cov source | Floor | Source |
|---|---|---|---|
| `olympus-api` | `src` | **87** (`--ignore=tests/integration`) | `olympus-api/pyproject.toml:89` |
| `olympus-worker` | `src` | **90** | `olympus-worker/pyproject.toml:56` |
| `olympus-agent-runtime` | `src` | **90** | `olympus-agent-runtime/pyproject.toml:69` |
| `mcp-server` | `olympus_mcp` | **90** | `mcp-server/pyproject.toml:41` |
| `temporal` | `olympus_workflows` | **80** | `temporal/pyproject.toml:123` |
| `dashboard` (vitest) | — | **lines 81 / branches 70 / functions 76 / statements 78** | `dashboard/vitest.config.ts:67-71` |

> **GOTCHA (coverage-floor drift vs CLAUDE.md):** `CLAUDE.md` states the `temporal` floor is **87** and the dashboard statements floor is **79**. Live code: `temporal` floor is **80** (`temporal/pyproject.toml:123`) and dashboard statements floor is **78** (`dashboard/vitest.config.ts:71`, with an in-file comment noting P5-S26 dropped 79→78 to match main-branch drift). CLAUDE.md's stated `dashboard` floors "81/70/76/79" are 81/70/76/**78** live.

CLAUDE.md rule: "Coverage floors only move up, never down." — the temporal 87→80 and dashboard 79→78 entries are the exception the code actually reflects.

---

## 6. Drift Register (seed — extend in `DRIFT-REGISTER.md`)

| # | Discrepancy | Evidence |
|---|---|---|
| D1 | `RiskTier` is an **`enum.IntEnum`** (tiers compare/order as ints), not a str enum | `olympus-contracts/olympus_contracts/enums.py:44` |
| D2 | Assembly-line contract YAMLs are **canonical** at `olympus-contracts/olympus_contracts/data/assembly-lines/` with a **duplicate stale copy** at `olympus-contracts/build/lib/olympus_contracts/data/assembly-lines/` (the `build/lib/` tree is a packaging artifact — do not treat as source) | both dirs list `architecture.yaml`, `build.yaml`, `data.yaml`, … |
| D3 | `RiskTier` is defined in TWO places: the canonical IntEnum in contracts AND a plain (non-Enum) `class RiskTier` in `olympus-api/src/services/profile_loader.py:150` | `grep "class RiskTier"` |
| D4 | `@foundry_activity` is a **wrapper around `@activity.defn`** (adds two standard behaviors), not a bare Temporal decorator | `temporal/olympus_workflows/temporal_base/activities.py:79-100` |
| D5 | **"7th extension registry" is a trap:** `loop_pattern.py` LOOKS like a 7th extension point but is explicitly NOT one — DECISION-010 caps extension registries at **6**; loop_pattern is a read-only *catalog* built on the shared `Registry` engine (like analysis_pass) | `temporal/olympus_workflows/registries/loop_pattern.py:9-25` |
| D6 | The **6 canonical extension registries**: `assembly_line`, `disposition`, `analysis_pass`, `scoring_dimension`, `gate_provider`, `skill_composition` (module-level singletons `*_REGISTRY`) | `registries/*.py:186,490,170,222,406,194` |
| D7 | Assembly-line dir count is **12** live (adds `reverse-engineering/`), but `CLAUDE.md` narrates 10 and the 2026-07-02 spec recorded 11 | `ls -d assembly-lines/*/` |
| D8 | Cross-cutting dir count is **12** live (`templates/` is the extra), CLAUDE.md narrates 11 | `ls -d cross-cutting/*/` |
| D9 | Temporal coverage floor is **80**, not 87 as CLAUDE.md states | `temporal/pyproject.toml:123` |
| D10 | Dashboard statements floor is **78**, not 79 as CLAUDE.md states | `dashboard/vitest.config.ts:71` |
| D11 | The agent LB is **HAProxy** (`haproxy:2.9-alpine`), though some compose comments still reference "nginx LB" from an earlier task | `docker-compose.yml:487`, comment at `:261` says "nginx LB" |
| D12 | `olympus2` API host port is **18000**, not the naive +1000 (9000) — a host-level Ztunnel occupies 9000 | `docker-compose.olympus2.yml:36-38,77-78` |
| D13 | `temporal-server` dynamicconfig overrides `blobSize.error` 2 MiB → 4 MiB as a band-aid for oversized gate-evidence payloads (durable fix pending) | `docker-compose.yml:78-83`, `infra/temporal/dynamicconfig.yaml` |
