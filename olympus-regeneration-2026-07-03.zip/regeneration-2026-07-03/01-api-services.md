# 01 — olympus-api Service Layer (`olympus-api/src/services/`)

**Scope:** the entire service layer — 69 top-level modules + 7 sub-packages
(`autonomy/`, `capabilities/`, `decomp/`, `drift/`, `drift_control/`, `feedback/`,
`nl_tools/`). This is the business-logic tier that FastAPI routers call. Services
own SQL (raw `text()` against a derived Postgres query layer), Temporal client
interaction, Git operations, profile/registry resolution, and cross-cutting
enforcement (RBAC quorum, provenance, autonomy caps, drift-as-control, evidence).

**Conventions used throughout (verified across modules):**
- Async SQLAlchemy `AsyncSession` passed per-call; services are stateless w.r.t. the DB.
- SQL is raw `text()` with bind params; results consumed via `.mappings().all()/.first()`,
  `.scalar()`, or `.first()`. Writes end in `await db.commit()` unless the caller commits.
- HTTP errors raised as `src.middleware.error_handler.OlympusHTTPException(status, CODE, message)`
  or (in a few older modules — `bundle.py`) `fastapi.HTTPException(status_code, detail={code,message})`.
- Structured logging via `structlog.get_logger()`.
- Time: `datetime.now(timezone.utc)` (aware); **`bundle.py` is the exception** — it stores
  *naive* UTC (`_naive_utc_now`, `:76`) because `delegated_bundle` timestamp columns are
  `TIMESTAMP WITHOUT TIME ZONE` and asyncpg rejects aware datetimes bound to them. GOTCHA.
- Verified module inventory (`ls *.py` + sub-packages): the 69 top-level modules and
  sub-package files enumerated below are the complete set.

This file is split. **Part 2** (`01-api-services-part2.md`) covers the "rest" modules
(the ~55 supporting services) with responsibility + entry points. This Part 1 reproduces
the non-trivial logic of the headline modules as pseudocode.

> NOTE on "endpoints": the routing/HTTP surface (methods, paths, scopes, request/response
> models, mount order) lives in the **routers** document, not here — this scope is the
> service layer. Where an endpoint's behavior is load-bearing, the target endpoint is named
> on the service function (e.g. capability `run` maps to `POST /a2a/tasks`).

---

## `nl_engine.py` (1500 LOC) — NL Action Console engine (P10-W6, `nl-action-engine`)

**Responsibility.** Turns the advisory chat surface into an **action-taking**
conversational engine. Plans a sequence of actions, each mapped to an *existing*
W2-hardened endpoint, and executes them **under the user's own token** so RBAC/gates are
inherited for free. Adds **no new action endpoint**. Tiered-confirmation policy is
profile-configurable DATA (`profiles/<profile>/nl-action-policy.yaml`), never a code
constant. Gate decisions are **staged and explained, never made** by the agent.
Attribution is W2's (`agent_attribution.record_agent_action`).

### Core data (`:65`–`:283`)
- `ActionTier = Literal["reversible","high_stakes","gate_decision"]`; constants `REVERSIBLE`,
  `HIGH_STAKES`, `GATE_DECISION` (`:65`–`:69`).
- `ActionSpec` (frozen dataclass, `:78`): `action_id, label, endpoint, method, resource_type,
  required_roles: tuple[RBACRole,...]|None, gate_staged=False, description, example,
  param_hints: tuple, required_params: tuple`. `required_roles=None` = the endpoint enforces
  a *portfolio-scoped* role at call time (engine never widens).
- Role groups (`:124`): `_MANAGER_ROLES=(PORTFOLIO_MANAGER, PORTFOLIO_ADMIN)`,
  `_ADMIN_ROLES=(PORTFOLIO_ADMIN,)`, `_REVIEWER_ROLES=(TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD,
  OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN)`.
- **`ACTION_SPECS` catalog** (`:142`–`:283`) — every entry maps to an EXISTING endpoint:
  | action_id | endpoint | method | resource_type | required_roles | required_params | gate_staged |
  |---|---|---|---|---|---|---|
  | `onboard_application` | POST /api/v1/applications | POST | application | MANAGER | name, repository_url | |
  | `create_portfolio` | POST /api/v1/portfolio | POST | portfolio | ADMIN | — | |
  | `start_line` | POST /api/v1/applications/{app_id}/workflow/start | POST | line_run | MANAGER | app_id, line | |
  | `start_discovery` | POST /api/v1/applications/{app_id}/discovery/start | POST | line_run | MANAGER | app_id | |
  | `rerun_step` | POST …/steps/{step}/rerun | POST | step_execution | MANAGER | app_id, step | |
  | `retry_step` | POST …/steps/{step}/retry | POST | step_execution | MANAGER | app_id, step | |
  | `reset_step` | POST …/steps/{step}/reset | POST | step_execution | MANAGER | app_id, step | |
  | `cancel_step` | POST …/steps/{step}/cancel | POST | step_execution | MANAGER | app_id, step | |
  | `dispatch_skill` | POST /api/v1/skills/{skill_id}/dispatch | POST | agent_task | None (scoped) | skill_id, app_id | |
  | `gate_decision` | POST /api/v1/gates/{gate_id}/decision | POST | gate | REVIEWER | gate_id | **True** |

  GOTCHA: `start_line` deliberately targets the lightweight per-app workflow-start endpoint,
  NOT `/lines/{line}/start` (which needs wave_id/artifact_repo/etc. and would 422 every
  conversational start).

### Profile policy (DATA) — `ActionPolicy` (`:291`–`:415`)
- `ActionPolicy(profile, default_tier, reversible: frozenset, high_stakes: frozenset,
  gate_agent_may_approve: bool)`. `tier_for(action_id)` (`:305`):
  ```
  if ACTION_SPECS[action_id].gate_staged: return GATE_DECISION   # gate always staged, ignores lists
  if action_id in reversible:  return REVERSIBLE
  if action_id in high_stakes: return HIGH_STAKES
  return default_tier                                             # fail-safe: default is high_stakes
  ```
- `_profiles_root()` (`:324`): honor `OLYMPUS_PROFILES_DIR`, else walk parents for a `profiles/`
  dir, else `parents[3]/profiles`.
- `_active_profile_id()` (`:345`): try `profile_activation.active_profile().metadata.id`;
  fallback `OLYMPUS_PROFILE` env, then `"test-generic"`.
- `load_policy(profile=None)` (`:367`, `@lru_cache(maxsize=8)`): for `(profile_id, "test-generic")`
  try `root/<p>/nl-action-policy.yaml`; first existing → `_parse_policy`. If none: WARN and return
  fail-safe `ActionPolicy(default_tier=HIGH_STAKES, empty sets, gate_agent_may_approve=False)`.
  `clear_policy_cache()` clears (tests mutate the file on disk).
- `_parse_policy(path, profile_id)` (`:400`): read YAML → `nl_action_policy` block; `default_tier`
  clamped to reversible|high_stakes (else high_stakes); build frozensets from `tiers.reversible/high_stakes`.

### Plan models (`:428`–`:495`)
- `PlannedAction(action_id, label, tier, params, seq, status="planned", result=None,
  explanation=None, confirmation_id=None)` with `to_dict()`. `status` ∈ {planned, executed,
  awaiting_confirmation, staged, denied, needs_input, failed}.
- `ActionPlan(session_id, intent_id, intent_text, actions=[])` with `to_dict()`.
- `ActionExecutor = Callable[[ActionSpec, dict, CurrentUser], Awaitable[tuple[int, dict]]]`
  — injected; returns `(status_code, result_dict)`; RBAC denials come back as 401/403 status.

### Deterministic intent parsing (`:506`–`:585`)
- `_INTENT_CUES` (`:506`) — ordered `(cue_substring, action_id)` list.
- `parse_intent(message)` (`:528`): lowercase; for each cue `find` its index; keep first-occurrence
  per action_id; sort by index; return ordered action_ids. Empty ⇒ advisory turn.
- `is_capability_query(message)` (`:573`): empty→True; if `parse_intent` non-empty→False
  (action wins over "help"); else any `_CAPABILITY_CUES` substring.

### Capability discovery (`:588`–`:647`)
- `Capability(action_id, label, tier, description, example)` + `to_dict()`.
- `describe_capabilities(policy)` (`:608`): one card per `ACTION_SPECS.values()`, tier from
  `policy.tier_for`. `capability_reply(policy)` (`:629`): warm intro + `• label — description` +
  `e.g. "example"` lines.

### Conversational understanding — LLM proposer (`:660`–`:948`)
- `ConversationalPlan(action_ids, params_by_action, reply, is_capability_query=False)`.
- `_runtime_is_mock()` (`:677`): `AGENT_RUNTIME_MODE == "mock"` (explicit). `is_mock_runtime()` alias.
- `OLYMPUS_KNOWLEDGE` (`:706`) — a large client-blind platform digest (10 lines, 8 dispositions,
  15 gates, 3 tiers, architecture). `_grounding_preamble(portfolio_context)` (`:783`) —
  identity + knowledge + optional live portfolio snapshot; reused by BOTH the JSON planner and the
  tool-use loop prompt (`nl_agent.agent_system_prompt`). GOTCHA: the tool-use loop must NOT reuse
  the JSON-contract prompt (caused the model to emit raw JSON as prose).
- `_planner_system_prompt(policy, ctx)` (`:820`) — grounding + catalog + STRICT-JSON contract
  `{"reply","actions":[{action_id,params}],"is_capability_query"}`. Rules enforce: only catalog ids;
  action only for imperatives; never propose with missing required params; never decide a gate.
- `ACTION_SENTINEL = "\n<<<OLYMPUS_ACTIONS>>>\n"` (`:878`). `_planner_stream_prompt` (`:881`) emits
  prose first, then sentinel + compact JSON tail. `parse_streamed_plan(full_text, policy)` (`:909`):
  partition on sentinel; parse tail JSON between first `{` / last `}`; validate ids against
  `ACTION_SPECS` (drop unknown/dupes); if `is_capability_query`→capability reply; empty reply →
  `_deterministic_reply`.
- `_invoke_planner_model(system_prompt, message)` (`:958`): boto3 bedrock-runtime `invoke_model`
  (`CHAT_MODEL_ID` default `us.anthropic.claude-sonnet-4-6`, `max_tokens=1024`); extract text blocks;
  parse first-`{`…last-`}`. Any failure → `None` (fall back to deterministic).
- `plan_conversationally(message, policy, portfolio_context)` (`:1009`):
  ```
  if is_capability_query(message): return capability plan
  if not mock: raw = _invoke_planner_model(...); if raw: validate ids→ return plan (else fall through)
  # deterministic path:
  if _looks_like_question(message): return advisory answer (_deterministic_answer)
  return plan from parse_intent + _deterministic_reply
  ```
- `_looks_like_question` (`:1101`) — ends with `?` or matches `_QUESTION_CUES`. `_deterministic_answer`
  (`:1109`) / `_deterministic_reply` (`:1148`) — grounded offline templates. `_PARAM_LABELS` /
  `_humanize_missing` (`:1129`, `:1140`) phrase missing params.

### `NLActionEngine` (`:1171`–end)
`__init__(executor, profile=None)` → stores executor + `load_policy(profile)`.
- **`plan(session_id, message, params_by_action=None, action_ids=None)`** (`:1194`):
  ```
  resolved = action_ids if given else parse_intent(message)
  intent_id = "intent-"+uuid4
  for seq, action_id in enumerate(resolved):
     spec = ACTION_SPECS.get(action_id); if None: continue
     tier = policy.tier_for(action_id); params = params_by_action.get(action_id, {})
     action = PlannedAction(...)
     missing = [p for p in spec.required_params if not params.get(p)]     # REQ-NL-013 checked FIRST
     if missing: action.status="needs_input"; explanation asks for humanized missing; append; continue
     if tier == GATE_DECISION: action.status="staged"; explanation = _stage_gate_explanation(...)
     append action
  ```
- `understand(message, portfolio_context)` (`:1259`): delegate to `plan_conversationally`.
- `capabilities()` → `describe_capabilities(policy)`.
- `_stage_gate_explanation(spec, params)` (`:1278`): names gate id, required roles, states a human must decide.
- **`execute_plan(db, user, plan)`** (`:1300`) — executes ONLY reversible directly:
  ```
  for action in plan.actions:
     if status in {staged,executed,denied,needs_input}: continue
     spec = ACTION_SPECS.get(action.action_id)
     if spec.gate_staged:  action.status="staged"; ensure explanation; continue   # by SPEC identity (hardening)
     if tier == HIGH_STAKES: action.status="awaiting_confirmation"; explanation; continue
     if tier == REVERSIBLE: await _run_action(...)
  ```
- **`confirm_and_execute(db, user, plan, action_seq, confirmation_id)`** (`:1341`): find action by seq
  (ValueError if none); if `spec.gate_staged` → raise `PermissionError` (never execute a gate, by SPEC
  identity, defeating a forged tier); set confirmation_id; `_run_action(..., confirmation_id)`.
- **`_run_action(db, user, plan, action, confirmation_id=None)`** (`:1379`):
  ```
  spec = ACTION_SPECS[action.action_id]
  if spec.gate_staged: action.status="staged"; raise PermissionError   # DEFENSE IN DEPTH REQ-NL-004
  if spec.required_roles is not None and not user.has_role(*required_roles):
      action.status="denied"; result={status_code:403, detail:...}; log; return   # inherit, never widen
  status_code, result = await executor(spec, action.params, user)
  action.result = {status_code, **result}
  if status_code in (401,403): action.status="denied"; log; return    # do NOT retry under other identity
  if status_code >= 400: action.status="failed"; return
  action.status="executed"
  details = {action_label, tier, endpoint, intent_text, (confirmation_id)}
  resource_id = _resource_id_from_result(result, params)
  await agent_attribution.record_agent_action(db, acting_user=user.sub, session_id, intent_id,
      resource_type=spec.resource_type, resource_id, action=action.action_id, details)   # REQ-NL-006
  ```
- `_resource_id_from_result(result, params)` (`:1482`): prefer result `id/workflow_id/app_id/
  application_id/portfolio_id`, then params `app_id/gate_id/portfolio_id/line_name`, else `"unknown"`.

---

## `capabilities/` — single-skill capability dispatch (P9-W18)

Wraps the existing standalone single-skill dispatch (`dispatch_via_a2a` / `POST /a2a/tasks`) as a
tiered product endpoint. Tiers form a strict superset chain: **bare ⊂ provenance ⊂ verified**.

### `capabilities/models.py` (143 LOC) — HTTP edge
- `CapabilityRunRequest(capability="", inputs={}, tier: ProvenanceTier|None=None, skill_id=None,
  app_id=None, profile_id=None)`. `tier=None` = "unspecified" (picks per-capability default),
  distinct from an explicit `bare`.
- `CapabilityRunResponse(run_id, capability, tier, skill_id, status, artifact_refs=[],
  artifact_files=[], error="", profile_id=None, work_log_ref=None, evidence_content_hash=None,
  verified: bool|None=None, verifier_verdict=None, output_schema_validated: bool|None=None,
  output_schema_errors: tuple=())`. `verified is None` = "no verification ran" (≠ False = ran & failed).

### `capabilities/defaults.py` (114 LOC) — per-capability default tier (S18.8)
- `CAPABILITY_DEFAULT_TIER = {"generate-architecture": BARE, "extract-business-rules": PROVENANCE}`.
- `_UNKNOWN_CAPABILITY_DEFAULT_TIER = BARE`.
- `resolve_default_tier(capability)` → map.get(capability, BARE). Only consulted when caller omitted tier.
- OWNER FORK documented: flip extraction to `VERIFIED` for accredited work is a one-line change.

### `capabilities/allowlist.py` (77 LOC) — generic-runner allowlist (S18.4, REQ-CAP-007)
- `CAPABILITY_ALLOWLIST = frozenset({"generate-architecture","extract-business-rules"})`.
- Import-time invariant: `assert set(CAPABILITY_SKILL_MAP).issubset(CAPABILITY_ALLOWLIST)`.
- `is_capability_allowlisted(capability) -> bool`. Imports `CAPABILITY_SKILL_MAP` from `service.py`
  (keep that constant defined ABOVE the allowlist import to avoid a cycle — GOTCHA).

### `capabilities/store.py` (98 LOC) — in-process run projection
- `CapabilityRunStore` — `threading.Lock` + insertion-ordered `OrderedDict` keyed by `run_id`,
  FIFO-capped `_MAX_RECORDS=2000`. `record()` (re-inserts key to move to newest, evicts oldest),
  `get(run_id)`, `list_records(profile_id=None, limit=100)` (reversed = newest-first, profile filter),
  `clear()`. Shared singleton `CAPABILITY_RUN_STORE`.

### `capabilities/service.py` (687 LOC) — `CapabilityService`
- `CAPABILITY_SKILL_MAP = {"generate-architecture":"target-architecture-blueprint",
  "extract-business-rules":"extraction"}`.
- `_A2A_AGENT_BASE_URL = os.environ["A2A_AGENT_BASE_URL"]` (read at import); `_CAPABILITY_TASK_TYPE="capability"`.
- **`bare_artifact_projection(result)`** (`:116`) — THE single load-bearing bare-tier contract
  (S18.3 byte-parity): returns `{"artifact_refs": list(result.output_artifacts),
  "artifact_files": [{"path","content","encoding"} for f in result.output_files]}`. Zero provenance,
  no mutation, key order (path→content→encoding) is part of the contract.
- **`opportunistic_output_schema_validation(skill_id, result)`** (`:145`) → `(bool|None, tuple)`:
  advisory (S18.9). If skill declares no `output_schemas` → `(None,())` (dormant). Else find first
  produced file whose `path` is a declared schema path AND content parses as a JSON object → run
  `validate_return_output_payload` → `(not violations, tuple(violations))`. No match/unparseable → `(None,())`.
- Errors: `CapabilityResolutionError(ValueError)` (→4xx), `CapabilityNotAllowlistedError(ValueError)` (→403).
- `CapabilityService.__init__(registry=None, store=CAPABILITY_RUN_STORE, agent_url=_A2A_..., db=None)`.
  `db` typed `object` so importing never forces SQLAlchemy on bare path.
- `_skill_is_known(registry, skill_id)` (`:270`): `registry.find(skill_id)` OR any `skill.variants[].id == skill_id`.
- `_capability_exposes_skill(registry, capability, skill_id)` (`:289`): base = `CAPABILITY_SKILL_MAP.get(capability)`;
  True iff `skill_id==base` or a variant of base. False if no base (made-up capability can't expose a skill).
- `_enforce_allowlist(request)` (`:320`): if `not is_capability_allowlisted(capability)` → raise;
  resolve `skill_id or map.get(capability, capability)`; if `not _capability_exposes_skill(...)` → raise.
- `_resolve_skill_id(request)` (`:360`): candidate = `skill_id or map.get(capability, capability)`;
  if empty → resolution error; validate `_skill_is_known` else resolution error. Allowlist-agnostic.
- `_effective_tier(request)` (`:391`): `request.tier if not None else resolve_default_tier(capability)`.
- `_mint_run_id(run_id)` (`:418`): `run_id or str(uuid4())`.
- **`run(request, actor, run_id=None, enforce_allowlist=False)`** (`:428`):
  ```
  if enforce_allowlist: _enforce_allowlist(request)           # FIRST — no dispatch on rejection
  skill_id = _resolve_skill_id(request); run_id = _mint_run_id(run_id); tier = _effective_tier(request)
  task_input = AgentTaskInput(task_type="capability", app_id=request.app_id or "", skill_id, context=inputs)
  result = await dispatch_via_a2a(agent_url, task_input)      # canonical single-skill path
  artifact = bare_artifact_projection(result)                # S18.3 byte-parity
  (validated, errors) = opportunistic_output_schema_validation(skill_id, result)   # S18.9 advisory
  response = CapabilityRunResponse(run_id, capability, tier, skill_id, status=result.status.value,
      artifact_refs, artifact_files, error=result.error, profile_id,
      work_log_ref=None, evidence_content_hash=None, verified=None, verifier_verdict=None,
      output_schema_validated=validated, output_schema_errors=errors)
  if tier is not BARE:                                        # provenance (and verified) — lazy import
      attachment = await attach_provenance(run_id, capability, skill_id, tier, result,
          artifact_refs, inputs, profile_id, app_id, actor, db=self._db,
          portfolio_id=_resolve_portfolio_id(request))
      response.work_log_ref = attachment.work_log_ref; response.evidence_content_hash = attachment.evidence_content_hash
  if tier is VERIFIED:                                        # S18.7 — lazy import
      verification = await run_verifier_pass(run_id, capability, skill_id, result)
      response.verified = verification.verified; response.verifier_verdict = verification.verdict
  if self._db is not None:                                    # S18.6 — outbox event on EVERY tier
      await emit_capability_run_event(run_id, capability, skill_id, tier, status, inputs,
          work_log_ref, evidence_content_hash, profile_id, app_id, db)
      await _commit_run_event()                               # best-effort commit
  store.record(response); return response
  ```
- `_commit_run_event()` (`:646`): `try: await db.commit() except: log warning` (never break the run).
- `_resolve_portfolio_id(request)` (`:659`): `inputs["portfolio_id"]` if a non-empty str, else None.
- `get_run(run_id)` → `store.get`.

### `capabilities/provenance.py` (578 LOC) — post-dispatch provenance attach (S18.5)
Runs strictly AFTER bare projection; writes ONLY response sibling fields (never artifact). Fail-soft on
absent backbone/scope; fail-CLOSED on a hard evidence write failure. maker≠verifier enforced via HMAC.
- Constants: `_WORKLOG_DIR_ENV="OLYMPUS_CAPABILITY_WORKLOG_DIR"`, `_WORKLOG_FILENAME="work_log.json"`,
  `_CAPABILITY_TASK_TYPE="capability"`, `_ASSESSED_BY_SKILL="capability-provenance"`,
  `_DEFAULT_CONTROL_ID="CA-7"`, `_DEFAULT_CATALOG_ID="nist-800-53"`,
  `_META_REVIEW_SIG="review_sig"`, `_SIGNING_KEY_ENV="OLYMPUS_WORKLOG_SIGNING_KEY"`,
  `_DEFAULT_SIGNING_KEY="olympus-worklog-verifier-provenance-v1"`.
- `ProvenanceVerifierAuthorshipError(RuntimeError)`; `ProvenanceAttachment(work_log_ref, evidence_content_hash,
  work_log, skip_reason=None)`.
- Verifier-provenance HMAC (byte-identical to agent-runtime worklog): `_signing_key()`, `_review_payload(run_id,
  skill, outcomes)` = canonical JSON `{run_id, skill, outcomes:list}`; `_sign_review(log)` = HMAC-SHA256;
  `review_is_verifier_authored(log)` (`:172`): False if empty outcomes; else `hmac.compare_digest(log.metadata[review_sig],
  _sign_review(log))`.
- `_author_verifier_review(log, verdict, author="verifier")` (`:188`): if `author != "verifier"` → raise
  `ProvenanceVerifierAuthorshipError`; append verdict to outcomes; sign over the NEW outcomes (prevents lifting a
  valid sig onto self-authored outcomes); return new frozen WorkLog. **Only writer of `outcomes` in this module.**
- `_worklog_base_dir()` = env or `tempfile.gettempdir()/olympus-capability-worklogs`.
  `work_log_ref_for(run_id, base_dir=None)` = `<base>/<run_id>/capability/work_log.json` (pure).
- `_serialize_work_log`, `_inputs_hash(inputs)` = `"sha256:"+sha256(canonical-JSON)`.
- `build_capability_work_log(...)` (`:277`): maker authors `plan`/`checklist`(4 items, all done)/`decisions`
  (tier, capability, skill_id, inputs_hash, profile_id, artifact_count), `outcomes=()`; then verifier authors
  the verdict (`dispatch status=…; error=…; artifacts=N`) via `_author_verifier_review`. Returns a log where
  `review_is_verifier_authored` is True.
- `_persist_work_log(log, run_id)` (`:341`): makedirs + json.dump (indent=2, sort_keys). OSError → warn, return None (fail-soft).
- **`attach_provenance(...)`** (`:361`): build+persist work-log (always); then
  `_emit_evidence(...)`; return `ProvenanceAttachment(work_log_ref, evidence_content_hash, work_log, skip_reason)`.
- **`_emit_evidence(...)`** (`:444`) → `(content_hash|None, skip_reason|None)`:
  ```
  if db is None: return (None,"no_db")
  if not portfolio_id: return (None,"no_portfolio")
  try import evidence backbone (control_mapping, evidence_envelope, evidence_record, evidence_emit)
     except: return (None,"evidence_backbone_absent")
  parse portfolio_uuid (bad→"no_portfolio"); parse application_uuid (bad→None, portfolio-scoped record)
  build EvidenceRecordInput(control_id="CA-7", family="CA", status="partial", statement, evidence_refs=[capability_run ref],
      assessed_by_skill="capability-provenance", last_assessed=now)
  envelope=CtEnvelope(profile_id, owner_scope=app_id); mappings=[ControlMapping("nist-800-53","CA-7")]
  try emission = EvidenceEmitService(db).emit(evidence, envelope, mappings, subject_kind="capability_run",
      subject_id=run_id, commit=True)
      except DanglingControlMapping: raise      # REQ-EV-010, surface a dangle
      except EvidenceWriteError: warn; raise     # fail-closed on durability
  if emission is None: return (None,"evidence_suppressed")
  return (emission.record.content_hash, None)
  ```

### `capabilities/verification.py` (307 LOC) — verified-tier independent verifier (S18.7)
- Verdict-prefix constants: `VERIFIER_UNAVAILABLE_PREFIX="verifier_unavailable"`, `VERIFIED_PASS_PREFIX="verified"`,
  `VERIFIED_FAIL_PREFIX="not_verified"`.
- `VerificationOutcome(verified: bool, verdict: str)`. `_unavailable(reason)` = the SINGLE constructor for
  every fail-closed branch → `(False, "verifier_unavailable: reason")`.
- **`run_verifier_pass(run_id, capability, skill_id, result)`** (`:133`) — called ONLY when tier is VERIFIED:
  ```
  try import EvalCase, validate_case   except: return _unavailable("verifier_substrate_absent")
  try:
    declared = load_output_schemas_for_skill(skill_id); if not declared: return _unavailable("no_criterion")
    criterion = "produced artifact conforms to skill <id> declared output_schema … authored with the skill, not this run"
    case = EvalCase(eval_case_id="capability-verify:"+run_id, gate_type="capability-verified",
        ground_truth_verdict="APPROVE", criterion, version="1")
    validate_case(case)                              # rejects self-grading / criterion-less (REQ-EH-006)
    # resolve the artifact: first output_file whose path ∈ declared paths & content parses to JSON object
    if none: return _unavailable("no_artifact_to_verify")
    violations,_ = validate_return_output_payload(skill_id, output_payload=parsed, payload_path=target_path)
    if not violations: return VerificationOutcome(True, "verified: artifact … conforms …")   # ONLY True branch
    return VerificationOutcome(False, "not_verified: artifact … violates … (N violations; first: …)")
  except Exception as exc: warn; return _unavailable("verifier_error:"+type(exc).__name__)   # fail closed
  ```

### `capabilities/run_event.py` (214 LOC) — reliable `capability.run` outbox event (S18.6)
- `CAPABILITY_RUN_EVENT="capability.run"`, `_AGGREGATE_TYPE="capability_run"`.
- `compute_input_hash(inputs)` = `"sha256:"+sha256(canonical JSON)` (byte-identical to provenance `_inputs_hash`).
- `capability_run_idempotency_key(skill_id, input_hash, tier)` (`:90`) = `"capability.run:"+sha256(canonical
  JSON {skill_id, input_hash, tier.value})`. Same triple → same key; any axis change → new key.
- `emit_capability_run_event(...)` (`:115`) → `(outbox_id|None, skip_reason|None)`: `db is None`→`(None,"no_db")`;
  compute hash+key; payload {run_id, capability, skill_id, tier.value, status, input_hash, work_log_ref,
  evidence_content_hash, profile_id}; `enqueue_event(db, CAPABILITY_RUN_EVENT, payload, aggregate_type,
  aggregate_id=run_id, profile_id, owner_scope=app_id, idempotency_key)`. Exception → `(None,"emit_failed")`
  (best-effort). Idempotency is enforced at the OUTBOX DRAIN layer via the key (not a second store) — GOTCHA.

---

## `autonomy/` — autonomy-gating API surface (P10-S18.1)

Task-8-INDEPENDENT: on the default path nothing imports the Phase-8 evidence layer. Resolution LOGIC is the
pure `olympus_workflows.autonomy` engine; this package resolves inputs + records escalations + reads status.

### `autonomy/models.py` (244 LOC)
- `AutonomyLevel = Literal["report_only","assisted","unattended"]`; `EscalationStatus=Literal["open","resolved"]`.
- `GateRefModel(id, label="")` — API projection of contract `GateRef`.
- `EscalateRequest(application_id, profile_id, requested_level="report_only", risk_tier=None, paths=[],
  attempts=0, reason="", portfolio_id=None, control_ids=[])`. `actor` is NOT in the body (set server-side).
- `EscalationRecord(loop_item_id, application_id, profile_id, permitted_level, requested_level, risk_tier,
  escalate, reason, actor, recorded_at, status="open", denylisted=False, attempt_capped=False, paths=[],
  gate: GateRefModel, evidence_content_hash=None, evidence_skipped=False)`.
- `EscalateResult(escalation, evidence_emitted=False)`.
- `LoopPatternStatus(name, cadence, requested_level, permitted_level, capped=False, description="")`.
- `AutonomyStatusPage(profile_id, risk_tier, loop_patterns=[], open_escalations=[], open_escalation_count=0,
  readiness_ladder=[])`.
- Error-triage (P9-S17.6): `TriageDecision=Literal["report_only","fix_proposal","escalate"]`;
  `CaptureSource=Literal["ai_work_log","agent_run","event_outbox","prometheus_alert","mixed"]`;
  `IncidentStatus=Literal["open","resolved"]`; `IncidentRecord(fingerprint, service, error_class, source,
  occurrence_count, risk_tier, triage_decision, requested_level, permitted_level, first_seen, last_seen,
  profile_id, evidence_ref, status)`; `IncidentPage(profile_id, incidents=[], open_incident_count=0)`.

### `autonomy/policy.py` (121 LOC) — profile autonomy policy loader
- Uses ONLY pure engine (`policy_from_mapping`, `merge_policy_over_defaults`) — never imports `autonomy_eval`
  (which pulls Temporal runtime). `_repo_root()` = `parents[4]`. `_defaults_file()` =
  `temporal/olympus_workflows/registries/defaults/autonomy.yaml`.
- `_default_policy()`: parse defaults file; if empty → fully fail-closed `AutonomyPolicy()`.
- `_profile_root_for(profile_id)`: `OLYMPUS_PROFILES_DIR`/repo `profiles/<id>` else `OLYMPUS_PROFILE_ROOT`.
- `load_autonomy_policy(profile_id)`: layer `<root>/autonomy.yaml` over defaults; missing → defaults verbatim
  (never fail open, REQ-AG-008).

### `autonomy/store.py` (106 LOC) — `AutonomyEscalationStore`
Mirror of the capability store: Lock + OrderedDict keyed by `loop_item_id` (latest per item wins), FIFO cap
`_MAX_RECORDS=2000`. `record()`, `list_records(profile_id, application_id, only_open, limit)` (newest-first,
filters), `clear()`. Singleton `ESCALATION_STORE`.

### `autonomy/escalation.py` (279 LOC) — `AutonomyEscalationService`
- `EVIDENCE_EMIT_FLAG="AUTONOMY_EVIDENCE_EMIT"`; `_DEFAULT_CONTROL_ID="CA-7"`.
  `evidence_emit_enabled()` = env in {1,true,yes,on}.
- `escalate(loop_item_id, body, actor, recorded_at=None)` (`:98`):
  ```
  ts = recorded_at or now; policy = load_autonomy_policy(body.profile_id)
  base = resolve_autonomy_level(requested_level, risk_tier, policy, paths, attempts)   # pure engine
  reason = base.reason if base.escalate else "operator_escalation"; if body.reason: reason += ": "+note
  record = EscalationRecord(permitted_level=DEFAULT_AUTONOMY_LEVEL(report_only), escalate=True,
      denylisted=base.denylisted, attempt_capped=base.attempt_capped, gate=GateRefModel(AUTONOMY_GATE_ID,"Autonomy gate"), ...)
  if evidence_emit_enabled(): (content_hash, skipped) = await _emit_evidence(...); record.evidence_* set
  store.record(record)                          # AFTER optional evidence write
  return EscalateResult(record, evidence_emitted=content_hash is not None)
  ```
- `_emit_evidence(...)` (`:182`): `if not portfolio_id or db is None: return (None,True)`; lazy import backbone
  (absent→`(None,True)`); build EvidenceRecordInput(status="partial", assessed_at_gate=AUTONOMY_GATE_ID,
  assessed_by_skill="autonomy-escalation"); `EvidenceEmitService(db).emit(..., subject_kind="gate",
  subject_id=AUTONOMY_GATE_ID, commit=True)`; return `(content_hash, content_hash is None)`.

### `autonomy/status.py` (116 LOC) — `AutonomyStatusService`
- `status(profile_id, risk_tier, application_id, limit)` (`:58`): `policy = load_autonomy_policy(profile_id)`;
  `tier_max = policy.tier_max(risk_tier) if risk_tier else None`; for each pattern in sorted
  `LOOP_PATTERN_REGISTRY.list_all()`: `permitted = cap_level(requested, tier_max) if tier_max else requested`,
  `capped = permitted != requested`; `open_escalations = store.list_records(profile_id, application_id,
  only_open=True, limit)`; return `AutonomyStatusPage(..., readiness_ladder=list(READINESS_LADDER))`.

### `autonomy/incidents.py` (146 LOC) — error-triage incidents
- `IncidentStore` (Lock + OrderedDict keyed by `fingerprint`, FIFO cap `_MAX_RECORDS=5000`); `record()`,
  `list_records(profile_id, service, only_open=True, limit)`, `clear()`. Singleton `INCIDENT_STORE`.
- `AutonomyIncidentsService.list_open(profile_id, service, limit)` → `IncidentPage`.

---

## `nl_tools/` — read + navigate tool catalog (P10-W6, REQ-NL-016)

Single source of truth for the tools an AI agent may use to READ/NAVIGATE. Write/action tools stay in
`nl_engine.ACTION_SPECS`. MCP will consume THIS catalog (never duplicate).

### `nl_tools/catalog.py` (471 LOC)
- `ReadTool(name, description, path, path_params=(), query_params=(), input_schema={})` with `kind="read"`.
- `NavTool(name, description, input_schema={})` with `kind="navigate"`.
- `_obj(props, required)` builds a JSON-Schema object node; `_STR={"type":"string"}`.
- `_CURATED_READ_TOOLS` (`:92`) — 13 curated tools each mapping to an EXISTING GET endpoint:
  `list_skills`(/api/v1/skills), `get_skill`(/skills/{skill_id}), `list_assembly_lines`(/lines),
  `describe_assembly_line`(/lines/{line_name}/status), `list_applications`(/applications),
  `application_status`(/applications/{app_id}), `list_waves`(/waves), `wave_status`(/waves/{wave_id}),
  `list_artifacts`(/artifacts/{app_id}), `get_artifact`(/artifacts/{app_id}/{artifact_path}),
  `list_pending_gates`(/gates/pending), `list_my_tasks`(/me/tasks), `portfolio_analytics`
  (/analytics/{report}, enum report ∈ {readiness-scores, portfolio-health, portfolio-scoring,
  gate-pass-rate, compound-growth, disposition-confidence, model-usage}).
- `GENERIC_GET_TOOL` (`olympus_api_get`, `:332`) — escape hatch: GET any `/api/v1/` path; args `path`+`query`.
- `NAV_ROUTES` (`:367`) — 24 stable page-id → route-template pairs (overview, applications,
  application_detail, waves, gate_queue, gate_review, skills, compliance, cato_evidence,
  target_architecture, capability_lineage, traceability, readiness_analytics, cost_analytics, …).
- `NAV_TOOL` (`navigate_to`, `:394`) — enum `page` + `params`.
- `READ_TOOLS`/`NAV_TOOLS` dicts; `get_read_tool`, `get_nav_tool`, `tool_names()`; `bedrock_tool_defs()`
  (`:446`) renders `{name, description, input_schema}` for Bedrock native tool-use.

### `nl_tools/executor.py` (521 LOC) — deterministic read/nav executor
- `ReadHttpGet = Callable[[path, query, token], Awaitable[(int, body)]]` (injected loopback GET).
- `EntityPortfolioResolver = Callable[[kind, entity_id], Awaitable[str|None]]` (injected). Enforces the
  ACTIVE-PORTFOLIO CONTEXT boundary (not access control) — fixes the cross-portfolio "Mezzanine" bug.
- `MAX_RESULT_CHARS=24000`. `_PORTFOLIO_SCOPED_LIST_TOOLS` = {list_applications, list_waves,
  list_pending_gates, portfolio_analytics} → forced `portfolio_id`. `_SCOPED_ID_ARGS` = {app_id→application,
  wave_id→wave, gate_id→gate}. `_PATH_ENTITY_SEGMENTS` for generic path UUID checks. `_UUID_RE`.
- `ToolExecutionError` — only for a call the executor refuses to make (unknown tool / non-GET / off-API path);
  an endpoint 4xx is a normal result the model sees.
- `_validate_api_get_path(path)` (`:99`): reject non-str/empty; reject `://` or `//` (SSRF/loopback-only);
  prepend `/`; must start `/api/v1/`; reject `..`.
- `_resolve_read_path(tool, args)` (`:122`): generic tool → validated path + query dict; else substitute
  path_params (missing → error), collect declared query_params.
- `run_read_tool(tool_name, args, http_get, token, active_portfolio_id=None, resolve_portfolio=None)` (`:151`):
  ```
  tool = get_read_tool(tool_name) or raise
  if active_portfolio_id and tool in _PORTFOLIO_SCOPED_LIST_TOOLS: force args[param]=active_portfolio_id
  if active_portfolio_id and resolve_portfolio: redirect = _check_active_portfolio(...); if redirect: return it
  path, query = _resolve_read_path(...)
  if active_portfolio_id and tool==olympus_api_get and "portfolio_id" in query: force it
  status, body = await http_get(path, query, token)
  return {"ok": 200<=status<300, "status_code": status, "data": _cap(body)}
  ```
- `_check_active_portfolio(...)` (`:221`): gather (kind, uuid) from id args or generic-path entity;
  for each `resolve_portfolio(kind, id)`; if resolved owner ≠ active → return a `409 cross_portfolio` result dict
  telling the model it belongs to another portfolio (fail-open on resolver error).
- `_cap(body)` (`:369`) — result-size cap for the model context: if serialized ≤ cap return as-is; else for a
  paginated dict preserve the `pagination` block + scalar keys, project every row to `_ROW_IDENTITY_KEYS`
  (id/name/line/step/type/…; description clipped to 200), return the COMPLETE projected set if it fits, else
  a slice at (200,100,50,25,5) rows with `_truncated`/`_note`, else pagination-only, else a truncated preview.
  GOTCHA: projecting the full set beats a 5-row full sample that misrepresented the line/type mix.
- `resolve_navigation(args)` (`:473`): look up `NAV_ROUTES[page]` (unknown→`ok=False`); fill `{param}` from
  `params` (missing→`ok=False`); append leftover params as query string; return `{ok, page, route}`.

---

## `scoring.py` (1082 LOC) — scoring engine service

Query engine over `score_history` + `application.portfolio_score` (JSONB). Full pseudocode:

- `GATE_TYPE_TO_ASSEMBLY_LINE` (`:42`) — the single source mapping gate_type → line (G-DC→Discovery,
  G-RR/G-DA→Rationalization, G-02→Architecture, G-DT→Data, G-04a/b/c→Modernization, G-NEW-1/2/3→Build,
  G-DE-1/2→Disposition Execution, G-V1/2/3→Validation, G-DP-1/2→Deployment).
- `_aggregate_pass_rates_by_line(rows)` (`:65`): bucket by mapped line; total++ per row; first_pass++ when
  `status=='approved' and retry_count==0`; return sorted `[{assembly_line,total,first_pass}]`.
- Dimension registry: `DEFAULT_DIMENSIONS` (code_quality .20, test_coverage .15, security_posture .20,
  documentation .10, dependency_currency .15, architecture_clarity .20), `DIMENSION_DESCRIPTIONS`,
  mutable `_dimension_registry`. `get_dimension_registry()` → entries + total_weight + valid(|Σ-1|<.001).
  `update_dimension_weights(weights)`: if `|Σ-1|≥.001` → 400 INVALID_WEIGHTS; else replace registry.
- **`_normalize_score(raw)`** (`:151`) — coerce to 0..1: None→None; float()→ValueError→None; `<0`→0.0;
  `≤1.0`→value; `≤5.0`→value/5 (Likert); `≤100`→value/100 (percent); else 1.0. GOTCHA: three score conventions
  coexist in seeds; without this the dashboard rendered 410%/268% readiness (P5-AUDIT-003).
- `get_all_readiness_scores(db, portfolio_id=None, portfolio_ids=None)` (`:188`): build WHERE from
  `portfolio_ids` (empty→[]) + `portfolio_id`; select apps; per app `SELECT DISTINCT ON (dimension)` latest
  per non-`overall` dimension; normalize; weighted overall = Σ(score·weight)/Σweight; return flat dicts.
- `calculate_readiness_score(db, app_id, dimension_filter=None)` (`:272`): app_id None → empty response;
  latest-per-dimension; normalize; per registry dim (filtered) build DimensionScore; overall = weighted/Σw,
  round 2; calculated_at = latest row's recorded_at.
- `_resolve_portfolio_id(db, portfolio_id, portfolio_ids)` (`:339`): explicit wins; else first of allowlist
  (empty→None) ordered by created_at; else first portfolio overall.
- `calculate_overlap_matrix(...)` (`:373`): resolve portfolio; <2 apps → empty; for each app pair count shared
  `traceability_link.target_artifact` (self-join) and per-app distinct targets; `composite = shared/max(total_a,
  total_b,1)*100` rounded 2; OverlapPair per pair.
- `calculate_portfolio_health(...)` (`:474`): counts total/completed apps; `disposition_pct=completed/total*100`;
  avg latest `overall` score; stale artifacts = distinct `source_artifact` where `source_version != analyzed_commit_sha`;
  `drift_penalty=min(stale*2,20)`; `overall = max(0, disposition_pct*.5 + (avg/5*100)*.3 + (100-penalty)*.2)`
  clamped to 100.
- `calculate_disposition_confidence(db, app_id)` (`:575`): confidence = 30 (has disposition) + min(evidence*2,40)
  + min(gate_pass*10,30), clamped 100; detail lists gaps.
- `calculate_compound_growth(...)` (`:655`): gate_pass_rate = first_attempt/decided; wave_velocity =
  completed/total_waves; pattern_reuse = apps_with_shared_targets/total_apps.
- `calculate_gate_pass_rate(...)` (`:779`): overall first-pass/decided; per-gate_type breakdown via SQL
  `FILTER`; per-line via `_aggregate_pass_rates_by_line` on decided rows (line derived in Python — the
  `gate` table has no `assembly_line` column, GOTCHA).
- `get_score_history(db, app_id, dimension=None, limit=100)` (`:897`): time-series newest-first.
- `_normalize_portfolio_score(raw)` (`:954`): dict → itself; str → json.loads (dict else {}); else {}.
- `get_portfolio_scoring_heat_map(...)` (`:975`): per app read `portfolio_score` JSONB, project `scores`
  dimensions → PortfolioScoreDimension(score, rationale, evidence[]); `overall_weighted` counts a `scored`
  app when numeric; apps without a score still appear (overall=None).

---

## `gate.py` (2706 LOC) — gate lifecycle, quorum, evidence, Temporal signalling

Owns the human-decision gate state machine (`gate` table statuses: `preparing`, `pending`, `approved`,
`rejected`, `escalated`, `merge_blocked`) plus evidence hydration and Temporal signals.

### Reads / helpers
- `list_pending_gates(db, params, portfolio_id, portfolio_ids, wave_id, status="pending")` (`:282`): status
  filter unless `"all"`; `portfolio_ids` empty→`FALSE` clause; intersect with `portfolio_id`; wave filter;
  order `decided_at DESC NULLS LAST` for `rejected` else `requested_at ASC`; join app/wave names; paginate.
- `list_pending_wave_gates(db, wave_id, gate_type=None)` (`:369`): pending gate ids for a wave, optional type,
  ordered by requested_at. Backs wave batch-approve (each id fanned out through per-gate approval+quorum).
- `_get_gate_or_404` (`:395`); `get_gate_type_and_portfolio(db, gate_id)` (`:408`): `(gate_type,
  COALESCE(app.portfolio_id, wave.portfolio_id))` or 404; `_gate_detail_from_row` (`:436`).
- `_persist_card_review(...)` (`:452`): W8 card-per-check payload written under `gate.evidence_data.review`
  (untouched `passes`/`steps`); no-op when empty. Casts via `CAST(:ev AS JSONB)`.

### Decisions
- **`approve_gate(...)`** (`:499`): 404 or 409 if not `pending`; `UPDATE gate SET status='approved',
  decided_at, decided_by, justification`; `_persist_card_review`; commit; log; return GateDetail.
  `approve_reason_category` is logged only (not persisted this PR).
- **`record_gate_approval(...)`** (`:622`) — quorum + oversight (rbac §6.3):
  ```
  404/409-if-not-pending
  INSERT gate_approval (gate_id, approved_by, role, is_oversight, is_management_override, comment)
      ON CONFLICT (gate_id, approved_by) DO NOTHING     # idempotent per approver
  approvals = load; received=len; quorum_met = received>=minimum_approvals
  oversight_met = oversight_role is None or any(a.is_oversight for a in approvals)
  advanced = quorum_met and oversight_met
  if advanced: UPDATE gate → 'approved' (decided_by=this approver); _persist_card_review
  commit; log
  return (GateDetail, advanced); if not advanced GateDetail.pending_approvals = _build_pending_approvals(...)
  ```
  Caller MUST NOT fire the Temporal signal unless `advanced` is True.
- `_build_pending_approvals(approvals, minimum, oversight_role)` (`:590`): received/remaining, oversight
  required+satisfied, per-approval records.
- **`reject_gate(...)`** (`:731`): 409 if not pending; `UPDATE status='rejected', decided_*, justification,
  reject_reason_category`; `_persist_card_review`; commit; reflect columns into the returned row.
- **`send_gate_temporal_signal(db, gate_id, action, actor, message, reason_category, card_decisions,
  reviewer_notes)`** (`:808`): look up `workflow_id, gate_type`; if no workflow_id → warn+return; get temporal
  client:
  - `approve` → signal `gate_approved` (GateApprovedSignal). **GOTCHA:** if `gate_type=="G-DA"` ALSO signal
    `stakeholder_approved` (StakeholderApprovedSignal scope="g-da") because the wave_rationalization workflow
    waits for a second signal; the single approver fires both.
  - `reject` → `gate_rejected`; `merge_retry` → `merge_retry` (GateMergeRetrySignal).
  - Any exception → warn (DB state already updated; signal retriable).

### Evidence hydration (`:929`–`:1980`)
- `_DISCOVERY_ORDER`/`_RATIONALIZATION_ORDER` from `pass_order(...)` (contract yaml is single source).
  `_GUIDANCE_BY_GATE`. `_build_generic_findings_artifacts`, `_substitute_app_names`,
  `_parse_pr_number_from_url`, `_resolve_evidence_branch`.
- `_hydrate_modernization_from_target_repo` (`:1135`) and `_hydrate_slim_evidence_contents` (`:1289`) — each
  has an inner `_fetch_one(full_path, file_info)` that pulls file contents from the artifact/target repo
  (async fan-out). `_build_unit_artifacts` (`:1483`); `_line_config_for_prefix`; `_unit_is_summary`.
- `get_gate_evidence(...)` (`:1652`) and `get_gate_evidence_for_application(...)` (`:1980`) — assemble the
  gate-review evidence payload (cards/passes/steps), hydrating file contents from Git as needed.

### Merge-block / retry / force-advance / escalation
- `set_gate_merge_blocked(db, gate_id, failure_detail)` (`:2023`): `UPDATE status='merge_blocked',
  merge_failure_detail=CAST(:detail AS JSONB)`; preserves `decided_at/decided_by`. Idempotent
  (Temporal at-least-once). Payload shape: `{reason, failure_type, conflicting_files?, base_sha?, head_sha?,
  detected_at}`.
- `retry_merge_gate(db, gate_id, retried_by, note=None)` (`:2087`): 409 if not `merge_blocked`; revert to
  `approved`, clear `merge_failure_detail` (decided_* untouched); fire `merge_retry` signal.
- `_verify_gate_evidence_exists(row, config)` (`:2164`).
- **`force_advance_gate(db, gate_id, advanced_by, comment, bypass_evidence_check, config)`** (`:2216`):
  ```
  404 / 409 GATE_NOT_PREPARING if status != 'preparing'
  if not bypass_evidence_check and not _verify_gate_evidence_exists: 409 GATE_EVIDENCE_NOT_FOUND
  UPDATE status='approved', decided_at/decided_by/justification
  if app-scoped: read current_status; advance_to = _APP_STATUS_ADVANCE.get(current); if set UPDATE application
  INSERT audit_log (actor, 'human', 'gate.force_advance', 'gate', gate_id, details JSONB)
  commit; log.warning
  ```
- `resolve_escalation(db, gate_id, resolved_by, resolution_category, notes=None)` (`:2355`): only `escalated`;
  `re-extract`/`manual-augment`/`re-disposition` → back to `pending`; `rejected-as-escalated` → stays `rejected`
  (rework loop). Requires a structured `resolution_category`.
- Capability-lineage rework: `_persist_capability_lineage_rework_block` (`:2422`),
  `_apply_capability_lineage_row_decisions` (`:2465`).
- **`submit_gate_decision(...)`** (`:2556`) — the top-level decision orchestrator the router delegates to
  (drives approve/reject + quorum + signalling + lineage decisions in one place).

---

## `wave.py` (2604 LOC) — wave lifecycle + rationalization + fan-out orchestration

Wave state machine (`wave.status`: `draft` → `ready` → (rationalizing) → … ; plus `cancelled`) and per-app
fan-out coordination. Reproduced logic for the load-bearing transitions:

- `get_or_create_draft_wave(db, portfolio_id)` (`:42`): return current `draft` wave (min wave_number) else
  create one with `wave_number = COALESCE(MAX,0)+1`, name `"Wave N"`, status `draft`. Caller commits.
- `_load_draft_wave_for_onboard(db, portfolio_id, wave_id)` (`:104`): 404 WAVE_NOT_FOUND / 400
  WAVE_PORTFOLIO_MISMATCH / 400 WAVE_NOT_DRAFT.
- `bulk_onboard_apps(db, portfolio_id, application_ids, target_wave_id=None)` (`:146`): auto-assign apps to
  the (draft) wave; returns WaveDetail.
- **State transitions (all idempotent on the target status, 400 on illegal source):**
  - `mark_wave_ready(db, wave_id, stakeholder)` (`:247`): only `draft`→`ready` (400 WAVE_NOT_DRAFT otherwise;
    idempotent if already `ready`). `UPDATE ... WHERE id AND status='draft'`.
  - `cancel_wave(db, wave_id, stakeholder="")` (`:320`): only `draft`→`cancelled` (400 WAVE_NOT_CANCELLABLE);
    idempotent on `cancelled`. `ready` must be reverted first.
  - `revert_wave_to_draft(db, wave_id, stakeholder="")` (`:393`): `ready`→`draft` (unlock the cohort).
- **Rationalization orchestration:**
  - `start_wave_rationalization(...)` (`:477`): start the `WaveRationalizationWorkflow` for a `ready` wave.
  - `cancel_wave_rationalization(...)` (`:599`) — inner `_hammer()` (`:670`) retries the cancel signal/kill.
  - `retry_wave_rationalization(...)` (`:728`); `reset_wave_to_ready(...)` (`:781`).
  - `start_wave(...)` (`:879`): kick the `WaveWorkflow` (per-app pipelines).
- **Progress / status reads:**
  - `get_wave_app_progress(...)` (`:1028`); `_count_apps_in_wave` (`:1116`).
  - `_load_step_timeline` (`:1374`), `_extract_failure_reason` (`:1460`), `_truncate_error` (`:1358`),
    `_temporal_ui_url` (`:1516`), `_temporal_status_from_reported` (`:1546`).
  - `get_wave_progress(...)` (`:1552`) — the big aggregate view (per-app step timelines + gate positions).
  - `list_pending_fanout_gates(...)` (`:1811`).
  - `get_wave_app_activity(...)` (`:2525`).
- **Assignment / fan-out:**
  - `assign_apps_to_wave(...)` (`:1129`); `remove_apps_from_wave(...)` (`:1274`).
  - `cancel_all_wave_children(...)` (`:1951`) — cancel all per-app child workflows.
  - `_target_workflow_is_live` (`:2064`); `_seed_lineage_from_artifacts` (`:2086`);
    `_lineage_relationship_for_seeded(disposition)` (`:2164`); **`resume_wave_fanout(...)`** (`:2173`) — the
    recovery path that re-seeds lineage + re-dispatches per-app pipelines for a partially-run wave.

---

## `application.py` (1947 LOC) — application onboarding + status

- Disposition display helpers: `_disposition_from_relationship` (`:43`), `_display_disposition` (`:67`).
- Line-status decode: `_decode_line_status` (`:123`), `_build_line_status` (`:144`),
  `_load_step_progress()` (`:164`) — step→fraction map used for progress.
- `_fetch_latest_scores` (`:186`), `fetch_target_systems_for_app` (`:219`),
  `fetch_realizes_capability_for_app` (`:262`), `fetch_agent_activity_by_line` (`:392`),
  `_resolve_capability_id(...)` (`:480`) — resolve a capability by id/external-id/target-system.
- `_validate_source_repo(body, config)` (`:571`): token = `body.source_git_token or config.github_token`;
  no token → 422 GIT_NOT_CONFIGURED; `GitService(...).validate_repo_access(require_push=False)`; GitServiceError
  → 422 REPO_VALIDATION_FAILED (source repos are read-only for onboarding).
- **`create_application(db, body, portfolio_id, *, app_id=None, intake_result=None)`** (`:606`):
  ```
  is_non_git = body.source_type != GIT
  if not is_non_git and not body.skip_repo_validation: _validate_source_repo(body, AppConfig())
  app_id = app_id or uuid4(); now = utcnow
  effective_repo_url = intake_result.local_path if intake_result else body.repository_url  # non-git stores local path
  resolved_capability_id = _resolve_capability_id(...)                                     # fail fast
  if body.target_system_id: verify system row exists in portfolio (retired_at IS NULL) else 422 SYSTEM_NOT_FOUND
  metadata = {} ; if capability: metadata["capability_id"]=str(id)
  if is_non_git: metadata["source_type"]=..., metadata["source_uri"]=...     # Discovery Build fork needs these
  INSERT application(... current_status='onboarded', metadata JSONB, ...) with git creds NULL for non-git
  if target_system_id: INSERT system_application(role='primary') ON CONFLICT DO NOTHING
  commit; return ApplicationDetail (echoes repository_url for git, local path for non-git)
  ```
- `list_applications` (`:783`), `get_application` (`:900`), `update_application` (`:955`).
- Workflow-link helpers: `_build_temporal_ui_url` (`:1007`), `_canonical_line_name` (`:1040`),
  `_line_from_workflow_id` (`:1080`), `_build_line_workflow_links` (`:1097`).
- **`get_application_status(...)`** (`:1149`) — assembles the per-app line/step/gate status page.
- **`start_discovery(...)`** (`:1309`) — kicks the Discovery workflow for an app.
- Step-execution reads: `_looks_like_artifact_path` (`:1416`), `_artifact_from_ref` (`:1436`),
  `_status_from_task_rows` (`:1469`), `_infer_status_from_progress` (`:1506`), `_envelope_artifact_refs`
  (`:1549`), `_step_execution_from_envelope(...)` (`:1580`, inner `_coerce_json`), `get_step_execution(...)`
  (`:1728`).

---

## `bundle.py` (1066 LOC) — delegated-bundle service (Phase 5 W20)

Human-paired-agent "delegated bundle" lifecycle: `offered` → `claimed` → `submitted`/`accepted` (or
`released`/`rejected`/`expired`). Uses `fastapi.HTTPException(detail={code,message})` (not OlympusHTTPException).

- `_SCHEMAS_ROOT = parents[3]/schemas` (import-time). `_naive_utc_now()` (`:61`) — GOTCHA: naive UTC because
  `delegated_bundle` timestamp columns are `TIMESTAMP WITHOUT TIME ZONE`; aware datetimes 500 on real Postgres.
- `_resolve_schema_path(schema_ref)` (`:78`): reject `..`; strip `schemas/` prefix; resolve under root.
- Row→wire mappers: `_row_to_summary`, `_row_to_input_ref`, `_row_to_output_view`, `_row_to_session_view`,
  `_row_to_validation_view` (parses `violations` JSON if str).
- `get_bundle(db, bundle_id)` (`:165`): 404 if missing; loads bundle + input_refs + output_refs +
  session_artifacts + validation_history → BundleDetail. `list_bundles(...)` (`:259`): portfolio + status +
  scope + app/wave + mine_only filters; `portfolio_ids=[]`→[] short-circuit; ORDER BY created_at DESC.
- `active_bundle_exists(...)` (`:321`): open = status NOT IN (expired,released,rejected,accepted); matches
  the `ux_bundle_one_open_per_scope` partial unique index; exactly one of app_id/wave_id matched (other NULL).
- `dispatch(...)` (`:376`): INSERT bundle status `offered` + input/output rows; stash `_expires_in_hours`
  into `local_agent_descriptor` JSONB; commit; return id. `dispatch_from_kickoff(...)` (`:475`): from the
  workflow-routing dialog; if an open bundle already covers the scope → return None (idempotent).
- **`claim(...)`** (`:552`): `SELECT ... FOR UPDATE`; terminal (accepted/rejected/expired/released) → 409
  BUNDLE_TERMINAL; already claimed/submitted → same user returns state, else 409 BUNDLE_ALREADY_CLAIMED;
  `offered` → read `_expires_in_hours` (default 24*7), merge caller descriptor (drop `_`-keys), set
  `claimed`, `claimed_by`, `claimed_at=now`, `expires_at=now+hours`.
- `release(...)` (`:656`): terminal→409; non-owner non-admin→403 BUNDLE_NOT_OWNER; set `released`; optional
  reason → session_artifact `release_reason://…`.
- `_validate_against_schemas(payload, output_specs)` (`:753`): per output spec — missing required →
  MISSING_REQUIRED_OUTPUT; empty ref → EMPTY_ARTIFACT_REF; schema file absent on disk → SCHEMA_REF_MISSING;
  any submitted kind not on contract → UNKNOWN_OUTPUT_KIND. Returns a list (not first-error-wins).
- `validate_payload(...)` (`:835`) — dry run, no state change. **`submit(...)`** (`:902`): `FOR UPDATE`;
  not claimed/submitted → 409 BUNDLE_NOT_CLAIMED; non-owner non-admin → 403; validate; persist sessions
  always (even on failure); if violations → history `rejected` + return; else fill output refs, flip
  `accepted`, history `accepted`.
- `expire_due_bundles(db)` (`:1005`): `UPDATE ... SET 'expired' WHERE status='claimed' AND expires_at<now
  RETURNING id`. `get_audit_narrative(...)` (`:1058`) + `_format_actor_sentence` (`:1033`).

---

## `step_mapping.py` (990 LOC) — step → skill / task_type / gate mapping

Backend mirror of `dashboard/.../stepRegistry.ts` (CI lint `scripts/verify_step_registry.py` keeps them in
sync). No DDL — derives relevant `agent_task.task_type` per step.

- `_LINE_NAME_BY_ENUM` maps the 10 `AssemblyLine` enum members → contract names.
- `LINE_STEP_IDS` (`:63`) — **contract-driven** per line via `olympus_contracts.get_line(name).step_ids()`
  (edit the line yaml, picked up at import). `UI_STEP_IDS` (`:76`) — the reviewer-visible subset; matches
  `LINE_STEP_IDS` 1:1 except Disposition Execution which is the flat union of per-disposition sub-steps
  (hand-listed, `:97`–`:144`).
- `_TASK_TYPES` (`:163`) — hand-mapped `(line, step) → [agent_task.task_type]`. Naming patterns:
  `discovery-{step}`, `wave-{step}`/`wave-per-app-*` (Rationalization), `modernization-{step}`,
  `architecture-{step}`, `data-{step}`, `disposition-{disposition}-{step}` (a step in multiple dispositions
  aggregates variants), `sustainment-{activity}`, `governance-{activity}`. Git/gate/code steps → `[]`.
- `_SKILLS` (`:594`) — `(line, step) → [skill_id]` for the Overview tab. `_GATES` (`:903`) —
  gate-bearing steps → `GateType` (G_DC, G_RR, G_DA, G_02, G_DT, G_04A/B/C, G_DE_1/2, G_V1/2/3, G_DP_1/2).
- Public: `is_known_step(line, step)`, `steps_for(line)` (workflow superset), `ui_steps_for(line)`,
  `task_types_for(line, step)`, `skills_for(line, step)`, `gate_for(line, step)`,
  `task_type_to_line_map()` (`:975`) — inverted `task_type → line` (first line wins, deterministic via StrEnum
  declaration order); backs `/skills/metrics/by-line`.

---

## `workflow_control.py` (878 LOC) — cancel / retry / start / reset any line

Generic Temporal control. Signal-first cancellation (send `cancel_workflow` to `HILSignalsMixin`, wait up to
`workflow_cancel_grace_seconds`, then `handle.cancel()`).

- `_workflow_name_for(line)` (`:82`): route `AssemblyLineName` → concrete workflow name; continuous lines
  (Sustainment/Governance) + Disposition Execution have no per-app start path → `WORKFLOW_NOT_IMPLEMENTED`.
- `_fetch_app_row` / `_fetch_wave_id` / `_fetch_disposition`; `_temporal_status_from_app_status`;
  `_temporal_ui_url`.
- `start_line_workflow(...)` (`:183`) — dispatch to the matching Temporal workflow with resolved inputs.
- `cancel_workflow(...)` (`:318`): signal-first then fallback cancel. `retry_workflow(...)` (`:380`).
- `_parse_line(value)`; `get_workflow_details(...)` (`:418`); `_recent_errors(...)` (`:534`);
  `_scan_history(events)` (`:589`) — walk Temporal history for state.
- **`compute_reset_point(...)`** (`:644`) — pure function computing the safe Temporal reset event id.
  `_resolve_app_in_progress_status(line)`; `reset_workflow(...)` (`:720`) — issues a
  `ResetWorkflowExecutionRequest`; `list_reset_points(...)` (`:825`).

---

## `git_service.py` (865 LOC) — branch-per-task / PR-based gates (PyGitHub)

Per-portfolio artifact-repo operations. `GITHUB_TOKEN` / `GITHUB_BASE_URL` (Enterprise supported). Uses
frozen contract types (`GitServiceConfig`, `CommitResult`, `FileReadResult`, `MergeBranchProtectionRejected`,
`MergeConflict`, `GitServiceError`, `BRANCH_PATTERN`).
- `_is_pr_already_exists(exc)` (`:38`). Dataclasses `RebaseResult` (`:62`), `ReconcileMergeResult` (`:81`).
- `GitService` (`:113`): create-branch, commit-file(s), read-file, create-PR, validate_repo_access,
  rebase, reconcile-and-merge. Instantiated per portfolio repo.

---

## `layer_resolution.py` (753 LOC) — layered profile resolution (P10-W11)

Enterprise **base** ⊕ portfolio **override** → single effective `Profile`, governed by a per-dimension lock
policy. Runs BEFORE `profile_overrides.apply_profile`.
- Errors: `LayerResolutionError`, `LockPolicyViolation` (structured `{dimension, policy, base_value,
  attempted_value, reason}` for UI), `CardinalityViolation`.
- `DimensionRule` / `LockPolicy` / `default_lock_policy()` (`:203`) / `load_lock_policy(path)` (`:253`):
  compliance regime + control_catalog LOCKED (REQ-LP-004); risk_tiers/gate_thresholds/scoring_weights/branding
  overridable; risk_tiers + gate_thresholds are **stricter-only** (looser numeric rejected, REQ-LP-005);
  agent_dispatch defaults LOCKED.
- `BaseRef` / `resolve_base_ref(inherits)` / `resolve_versioned_base(...)` — enterprise-base resolution.
- Merge helpers: `_override_wins`, `_merge_dict` (`:374`) — more-specific layer wins per field, dicts merge
  (not wholesale replace). `_is_stricter` / `_check_stricter_only`. `_rbac_thresholds`.
- Per-dimension resolvers: `_resolve_compliance` (`:449`, rejects locked-field change), `_resolve_risk`,
  `_resolve_gates`, `_resolve_scoring`; `_guard_cardinality(effective)` (`:620`).
- **`resolve_effective_profile(...)`** (`:658`) — the public entry: applies the lock policy while merging.

---

## `scoped_execution.py` (662 LOC) — scoped-execution assurance (P10-W9)

THE single resolution + assurance authority ("one common API layer" — router/CLI/MCP/UI all delegate here).
Extends the S16.5 standalone-line-start path.
- `InputProposal` / `ResolveResult` / `ConfirmedInput` / `AssuranceInputs` / `PrerequisiteDecision` /
  `ScopedRunRecord` dataclasses.
- `_input_type_of(path)` (`:168`). **`propose_inputs(...)`** (`:179`) — proposes each input from the app's
  last-completed upstream line's committed outputs, stamping W1's `{path, origin, attestation}` via
  `traceability.record_input_provenance` (operator MUST confirm — proposes, never seeds unattended, REQ-SE-001).
  `_committed_paths_for_app(...)` (`:235`).
- `confirm_override(...)` (`:270`) — accepts an override ONLY to a same-type source (REQ-SE-002), recorded.
- `normalize_run_mode(value)` (`:313`). **`compute_assurance(inputs)`** (`:352`) — deterministic function of
  `(run_mode, input origins, coverage, gate verdicts)` → `AssuranceLevel`; a partial/isolated run is
  measurably LOWER than the full-pipeline equivalent (`ASSURANCE_RANK`). `assurance_rank` / `is_lower_assurance`.
- `assert_not_a_waiver(...)` (`:412`); `resolve_prereq_policy(...)` / `evaluate_prerequisites(...)` (`:490`);
  `cap_assurance(...)` (`:548`); `valid_origins()`; `record_scoped_run(...)` (`:599`) / `get_scoped_run(...)`.

---

## `skill_bootstrap.py` (630 LOC) — load SKILL.md into DB at startup

Scans `cross-cutting/skills/` + active-profile `profiles/<id>/skills/`, parses SKILL.md, upserts `skill`
table. Idempotent; health check requires ≥1 skill loaded. Client-neutral (tags profile skills
`{profile_id}-profile`, never literal `faa-profile`).
- `_parse_frontmatter(fm_lines, body)` (`:64`), `parse_skill_md(path)` (`:123`), `_load_text_dir`,
  `_load_config`, `_determine_enrichment_level(skill_dir)` (`:186`) → Minimal/Partial/Full, `_title_case`.
- `_build_skill_record(...)` (`:256`); `_apply_profile_overlay(core, overlay_dir, source)` (`:321`) —
  more-specific (profile) overlay wins per field; `_overlay_has_content`; `_active_profile_id()` (`:385`)
  (active_profile / `OLYMPUS_PROFILE` / `faa` default).
- `collect_skills(repo_root, profile_id=None)` (`:415`); `upsert_skills(db, skills)` (`:546`);
  `_find_skills_root()`; `bootstrap_skills(db)` (`:607`) — the startup entry.

---

## `oidc.py` (438 LOC) — OIDC/SSO scaffold (P4-S1.11)

IdP-agnostic (OKTA/Entra/Ping declared in `profiles/<client>/config/identity.yaml`; pure OIDC — nothing
hardcoded). Secret via env named by `client_secret_env` (default `OIDC_CLIENT_SECRET`) — never in YAML/logs.
- `OIDCConfigError` / `OIDCAuthError`; `OIDCProviderConfig` (immutable, safe-to-log); `OIDCUserClaims`;
  `OIDCClient` (`:131`) — authorization-code + PKCE; `validate_id_token` fetches JWKS lazily + caches;
  `MockOIDCProvider` (`:301`) for tests; `load_identity_config(profile_root)` (`:360`) — returns None for
  local-only auth.

---

*(Continued in `01-api-services-part2.md` — the remaining ~55 supporting service modules and the
`decomp/`, `drift/`, `drift_control/`, `feedback/` sub-packages, each with responsibility + entry points.)*
