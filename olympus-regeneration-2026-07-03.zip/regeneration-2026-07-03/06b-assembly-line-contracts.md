# Olympus Regeneration Spec — 06b: Assembly-Line YAML Contracts (VERBATIM)

> Companion to `06-contracts.md`. Source of truth: `olympus-contracts/olympus_contracts/data/assembly-lines/*.yaml`.
> These 12 YAML files ARE the contract; the loader (`assembly_lines.py`, see 06-contracts.md §7) parses them
> at import time into frozen dataclasses. **Rebuild these files byte-for-byte.** Every downstream consumer
> (Temporal workflows, olympus-api gate service, step-progress mapping, dashboard step registry) reads step
> lists / skills / artifacts / side-effects from here — nothing is hardcoded (policed by
> `test_no_hardcoded_step_lists`, see 06-contracts.md §8).
>
> GOTCHA — canonical location: the authoritative YAMLs live at
> `olympus-contracts/olympus_contracts/data/assembly-lines/`. Any copy under `build/lib/` is a build artifact
> and must NOT be treated as source.
>
> GOTCHA — loader ignores files whose name starts with `_` or does not end in `.yaml`
> (`assembly_lines._load_all`, `.../assembly_lines.py:355-357`).
>
> Step counts (via `yaml.safe_load`, authoritative): Architecture 19, Build 15, Data 13, Deployment 18,
> Discovery 15, Disposition Execution 13, Governance 10, Modernization 33, Rationalization 21,
> Reverse Engineering 4, Sustainment 8, Validation 20. **TOTAL = 189 steps across 12 lines.**
>
> GOTCHA — 11 vs 12: there are 12 YAML line contracts but the `AssemblyLine` StrEnum
> (`enums.py:309-325`) has only 11 members. `Build` IS an enum member; `Reverse Engineering` is NOT.
> Both `Build` and `Reverse Engineering` are registered additively by the contract loader picking up their
> YAMLs — but reverse-engineering.yaml is a *drift item*: it is a canonical assembly-line contract that has
> no corresponding enum member (by design per the file header, to keep the enum pinned at 11 for the
> `test_assembly_line_enum_is_exactly_ten`/eleven interface invariants).

---

## Discovery — `discovery.yaml` (15 steps)

```yaml
# Discovery — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Discovery's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.

name: Discovery
description: >
  Per-application intake. Ingests an application's source tree, produces a
  standardized catalog entry, runs a four-pass structural + behavioral
  analysis, establishes a TCO baseline, and writes a reviewable artifact
  bundle to the portfolio's artifact repo. Terminal gate G-DC signals that
  the application is ready for Rationalization. Every downstream line
  depends on Discovery outputs.
trigger: onboarding
depends_on: []
gates:
  - id: G-DC
    label: Discovery Complete
mode: per-app
inputs:
  - legacy-source
  - documentation
  - stakeholder-context
outputs:
  - application-catalog-entry
  - tech-fingerprint
  - structural-analysis
  - business-logic
  - quality-risk
  - ux-accessibility
  - data-domains
  - shared-db-analysis
  - capability-catalog
  - compliance-citations
  - discovery-synthesis
  - tco-baseline

steps:
  - id: catalog
    label: Catalog
    kind: agent
    scope: per-app
    sequence: 1
    progress_pct: 10
    progress_weight: 10
    artifact_filename: catalog.json
    purpose: >
      Produce the standardized Application Catalog entry and tech fingerprint
      from the application's source tree. First step in Discovery; populates
      the application-detail page.
    skills: [catalog-application]
    agent_role: Analysis Agent
    inputs:
      artifacts: []
      context: [source-repo-clone, cmdb-exports, existing-docs]
    outputs:
      artifacts: [application-catalog-entry, tech-fingerprint]
      side_effects:
        - target: application
          fields:
            - description
            - architecture.archetype
            - tech_stack
            - business_domain
            - size_metrics
            - complexity_tier
            - safety_tier
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: structural-analysis
    label: Application & Data Mapping
    kind: agent
    scope: per-app
    sequence: 2
    progress_pct: 25
    progress_weight: 15
    artifact_filename: structural-analysis.json
    purpose: >
      Map the application's architecture: modules, components, call graphs,
      database schema, external interfaces, configuration, and deployment
      topology. The module/component map produced here defines the
      decomposition boundaries used by every downstream pass and by the
      Modernization line's Extract step. `legacy-architecture-mapper`
      produces the generic structural skeleton; conditional tech-stack
      specialists (`discovery-patterns-*`) augment it with
      idiom-specific findings (mainframe, oracle, sqlserver, dotnet,
      doc-only). Dispatch of the tech-stack specialist is runtime-routed
      by `olympus_workflows.workflows.discovery_patterns_router` based
      on the `tech_fingerprint` emitted by `catalog-application`; when
      no specialist matches, the generic `discovery-patterns` base
      runs.
      # Stage 8 ATLAS integration (2026-05-06): Pass 1 expanded with
      # deep-analysis helpers — legacy-language-reader (shared
      # language-detection + reader-dispatch manifest),
      # legacy-database-archaeologist (stored-proc classification,
      # shadow schemas, ADABAS DDMs, EOL engines, cross-app schema
      # sharing), legacy-data-flow-tracer (per-app data-element
      # lifecycle tracing for cross-system chains), identity-landscape-
      # analyzer (portfolio-scope NIST 800-63 identity inventory),
      # and tiff-corpus-assessor (conditional — fires only when the
      # application catalog sets `has_image_corpus: true`; workflow-
      # level dispatch routing arrives in Stage 11).
      # `compliance-citation-mapper` was promoted out of this skill set
      # into its own sequence-3 evidence step (`compliance-citation-
      # mapping`, P6-S15.3) so per-citation regulatory traceability
      # surfaces as its own G-DC gate-review card instead of being
      # folded into the structural skeleton.
    skills:
      - legacy-architecture-mapper
      - legacy-language-reader
      - legacy-database-archaeologist
      - legacy-data-flow-tracer
      - identity-landscape-analyzer
      - tiff-corpus-assessor
      - discovery-patterns
      - discovery-patterns-mainframe
      - discovery-patterns-oracle
      - discovery-patterns-sqlserver
      - discovery-patterns-dotnet
      - discovery-patterns-doc-only
    agent_role: Analysis Agent
    inputs:
      artifacts: [application-catalog-entry, tech-fingerprint]
      context: [source-repo-clone]
    outputs:
      artifacts:
        - structural-analysis
        - database-schema-summary
        - interface-inventory
      side_effects:
        - target: application
          fields:
            - architecture.major_components
            - architecture.integrations
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: business-logic-extraction
    label: Business Logic Extraction
    kind: agent
    scope: per-app
    sequence: 3
    progress_pct: 35
    progress_weight: 10
    artifact_filename: business-logic.json
    purpose: >
      Extract explicit and implicit business rules, validation logic,
      workflows, state machines, and edge cases from the legacy source.
      Includes regulatory traceability where a compliance profile applies.
    skills: [legacy-business-rule-extractor]
    agent_role: Business Logic Extractor
    inputs:
      artifacts: [structural-analysis, database-schema-summary]
      context: [source-repo-clone, regulatory-knowledge-base]
    outputs:
      artifacts:
        - business-logic
        - state-machines
        - implicit-logic
      side_effects:
        - target: application
          fields:
            - business_logic.rule_count
            - business_logic.critical_rules_count
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with:
      - quality-risk-assessment
      - ux-accessibility-assessment
      - data-domain-discovery
      - shared-database-analysis
      - capability-extraction
      - compliance-citation-mapping
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: quality-risk-assessment
    label: Quality & Risk Assessment
    kind: agent
    scope: per-app
    sequence: 3
    progress_pct: 35
    progress_weight: 10
    artifact_filename: quality-risk.json
    purpose: >
      Score technical debt, identify CVEs, measure test-coverage gaps,
      catalogue code-quality smells, and produce a rolled-up risk summary.
      Feeds Rationalization's risk scoring.
    skills: [quality-risk-assessor]
    agent_role: Analysis Agent
    inputs:
      artifacts: [structural-analysis]
      context: [source-repo-clone, dependency-manifests, sca-output]
    outputs:
      artifacts: [quality-risk]
      side_effects:
        - target: application
          fields:
            - quality.technical_debt_score
            - quality.test_coverage
            - quality.vulnerabilities_summary
            - quality.code_smells_summary
            - risk_tier
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with:
      - business-logic-extraction
      - ux-accessibility-assessment
      - data-domain-discovery
      - shared-database-analysis
      - capability-extraction
      - compliance-citation-mapping
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: ux-accessibility-assessment
    label: UX & Accessibility Assessment
    kind: agent
    scope: per-app
    sequence: 3
    progress_pct: 35
    progress_weight: 10
    artifact_filename: ux-accessibility.json
    purpose: >
      Capture who uses the system, how they use it, current adoption and
      training state, and where the UI fails Section 508 / WCAG 2.1 AA.
      Composes with accessibility-checker for automated WCAG audit. This
      is the baseline adoption-analytics compares against post-cutover.
    skills: [ux-accessibility-assessor]
    agent_role: UX Journey Analyzer
    inputs:
      artifacts: [structural-analysis, interface-inventory]
      context: [source-repo-clone, usage-telemetry, training-inventory, support-tickets]
    outputs:
      artifacts: [ux-accessibility]
      side_effects:
        - target: application
          fields:
            - ux.personas_count
            - ux.adoption_baseline_summary
            - ux.accessibility_score
            - ux.ui_inventory_summary
            - ux.ui_complexity_score
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with:
      - business-logic-extraction
      - quality-risk-assessment
      - data-domain-discovery
      - shared-database-analysis
      - capability-extraction
      - compliance-citation-mapping
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: data-domain-discovery
    label: Data Domain Discovery
    kind: agent
    scope: per-app
    sequence: 3
    progress_pct: 35
    progress_weight: 5
    artifact_filename: data-domains.json
    purpose: >
      Discovery-line pass that catalogs the application's existing data
      domains — logical groupings of entities that change together, are
      queried together, and share an ownership / lifecycle boundary.
      Produces a descriptive map of "what data domains does this app
      actually carry today?" which feeds Rationalization's cross-app
      redundancy matrix (shared identifiers, overlapping domains) and
      is refined later by the Data line's own `domain-discovery` step
      on the target application. This is a Discovery pass — it describes
      the legacy landscape; it does NOT design the target-state domain
      model.
    skills: [data-domain-patterns]
    agent_role: Data Landscape Analyst
    inputs:
      artifacts:
        - structural-analysis
        - database-schema-summary
      context:
        - source-repo-clone
    outputs:
      artifacts: [data-domains]
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with:
      - business-logic-extraction
      - quality-risk-assessment
      - ux-accessibility-assessment
      - shared-database-analysis
      - capability-extraction
      - compliance-citation-mapping
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: shared-database-analysis
    label: Shared Database Analysis
    kind: agent
    scope: per-app
    sequence: 3
    progress_pct: 35
    progress_weight: 5
    artifact_filename: shared-db-analysis.json
    purpose: >
      Discovery-line pass that catalogs the application's participation
      in shared database clusters as observed today: which tables it
      reads / writes / owns, which other apps likely share the same
      tables (based on schema evidence), stored-procedure / trigger /
      DB-link entanglement, and coupling severity. Produces the
      application's descriptive perspective on the shared-DB landscape,
      which feeds Rationalization's redundancy + dependency analysis.
      Refined later by the Data line's own `shared-db-analysis` step
      on the target application — Data inherits this artifact as input
      so it refines rather than re-discovers.
    skills: [decomposition-patterns]
    agent_role: Data Landscape Analyst
    inputs:
      artifacts:
        - structural-analysis
        - database-schema-summary
      context:
        - source-repo-clone
    outputs:
      artifacts: [shared-db-analysis]
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with:
      - business-logic-extraction
      - quality-risk-assessment
      - ux-accessibility-assessment
      - data-domain-discovery
      - capability-extraction
      - compliance-citation-mapping
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: capability-extraction
    label: Capability + System Grain
    kind: agent
    scope: per-app
    sequence: 3
    progress_pct: 35
    progress_weight: 5
    artifact_filename: capability-catalog.json
    purpose: >
      Discovery-line pass that extracts the capability + business-domain
      + legacy-system grain for a single application from already-
      discovered artifacts. Runs in the sequence-3 parallel cluster
      alongside the other passes; emits a structured
      ``capability-catalog.json`` artifact that the Discovery persist
      activity UPSERTs into the ``business_domain``, ``capability``
      (kind=legacy), ``system`` (kind=legacy), ``system_application``,
      and ``capability_business_domain`` tables. This is the source of
      truth Rationalization reads from when proposing target-state
      consolidation; without it the rationalization recommender has no
      FK-grounded grain to consolidate. Replaces the one-shot
      ``seed_capability_system_backfill.py`` script — Discovery is now
      the writer.
    skills: [capability-extraction]
    agent_role: Analysis Agent
    inputs:
      artifacts:
        - application-catalog-entry
        - structural-analysis
        - data-domains
        - interface-inventory
      context:
        - source-repo-clone
        - client-profile
    outputs:
      artifacts: [capability-catalog]
      side_effects:
        - target: legacy_system_grain
          fields:
            - business_domain_rows
            - capability_rows
            - system_row
            - system_application_row
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with:
      - business-logic-extraction
      - quality-risk-assessment
      - ux-accessibility-assessment
      - data-domain-discovery
      - shared-database-analysis
      - compliance-citation-mapping
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: compliance-citation-mapping
    label: Compliance Citation Mapping
    kind: agent
    scope: per-app
    sequence: 3
    progress_pct: 35
    progress_weight: 5
    artifact_filename: compliance-citations.json
    purpose: >
      Discovery-line pass that scans the application's source code and
      documentation for U.S. Code, CFR, Public Law, Federal Register,
      Executive Order, and agency-order citations and emits a per-citation
      traceability artifact linking each citation back to the file:line
      where it appears. Detection only — it does NOT judge whether a
      citation is current or correctly implemented; that judgment belongs
      to `cato-compliance` (OSCAL mapping) and `safety-critical-verifier`.
      Produces the regulatory-provenance map Rationalization and
      Modernization consume so every business rule encoding a statutory
      obligation stays linked to the statute it implements through a
      disposition. Promoted out of `structural-analysis`'s skill set into
      its own sequence-3 evidence step (P6-S15.3) so per-citation evidence
      surfaces as its own G-DC gate-review card.
    skills: [compliance-citation-mapper]
    agent_role: Analysis Agent
    inputs:
      artifacts:
        - application-catalog-entry
        - structural-analysis
      context:
        - source-repo-clone
        - client-profile
    outputs:
      artifacts: [compliance-citations]
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with:
      - business-logic-extraction
      - quality-risk-assessment
      - ux-accessibility-assessment
      - data-domain-discovery
      - shared-database-analysis
      - capability-extraction
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: synthesis
    label: Discovery Synthesis
    kind: agent
    scope: per-app
    sequence: 4
    progress_pct: 65
    progress_weight: 10
    artifact_filename: synthesis.json
    summary: true
    purpose: >
      Merge the four Discovery pass outputs into a consolidated digest.
      Reconciles contradictions, scores per-finding confidence, and produces
      the Discovery output set that Rationalization and Modernization's
      Extract step consume as authoritative. Rendered first in gate review
      as the reviewer-facing summary of the whole line.
      # Stage 8 ATLAS integration (2026-05-06): terminal rollup also
      # dispatches srs-from-discovery to transform descriptive Discovery
      # findings into a prescriptive SRS, bridging Discovery →
      # Architecture/Modernization before G-DC.
    skills: [discovery-synthesizer, srs-from-discovery]
    agent_role: Synthesis Agent
    inputs:
      artifacts:
        - structural-analysis
        - business-logic
        - quality-risk
        - ux-accessibility
        - data-domains
        - shared-db-analysis
        - capability-catalog
        - compliance-citations
      context: []
    outputs:
      artifacts: [discovery-synthesis]
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [tco-baseline]
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: tco-baseline
    label: TCO Baseline
    kind: agent
    scope: per-app
    sequence: 4
    progress_pct: 65
    progress_weight: 10
    artifact_filename: tco-baseline.json
    purpose: >
      Establish the per-application TCO baseline following the client
      profile's cost formula. Best-effort when a cost-context bundle is not
      supplied at onboarding — in that case the skill infers from
      code/IaC/repo signals and flags low confidence for gate review.
    skills: [tco-analyzer]
    agent_role: TCO Analyzer
    inputs:
      artifacts: [application-catalog-entry, structural-analysis]
      context:
        - source-repo-clone
        - cost-context-bundle
        - client-profile
    outputs:
      artifacts: [tco-baseline]
      side_effects:
        - target: application
          fields:
            - tco.annual_total
            - tco.breakdown
            - tco.formula_applied
            - tco.confidence
            - tco.data_sources
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [synthesis]
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: commit-artifacts
    label: Commit Artifacts
    kind: git
    scope: per-app
    sequence: 5
    progress_pct: 75
    progress_weight: 5
    purpose: >
      Commit all Discovery artifacts to the per-task branch in the
      portfolio's artifact repo. Also projects the decomposition map onto
      the application record so the insights UI can render it.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - application-catalog-entry
        - structural-analysis
        - business-logic
        - quality-risk
        - ux-accessibility
        - data-domains
        - shared-db-analysis
        - capability-catalog
        - compliance-citations
        - discovery-synthesis
        - tco-baseline
      context: []
    outputs:
      artifacts: []
      side_effects:
        - target: artifact-repo
          fields: [branch_created, artifacts_committed]
        - target: application
          fields: [decomposition_map]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-pr
    label: Create Gate PR
    kind: git
    scope: per-app
    sequence: 6
    progress_pct: 80
    progress_weight: 5
    purpose: >
      Open a pull request against the portfolio's artifact repo carrying
      every Discovery artifact. The PR is the vehicle for G-DC review and
      the long-term audit trail for this application's Discovery outputs.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [git-branch]
    outputs:
      artifacts: []
      side_effects:
        - target: artifact-repo
          fields: [pr_url, pr_number]
        - target: gate_record
          fields: [gate_id, evidence_package_url]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: gate-readiness-check
    label: Gate Readiness Check
    kind: agent
    role: pre-review
    scope: per-app
    sequence: 7
    progress_pct: 85
    progress_weight: 5
    purpose: >
      Automated readiness check of the Discovery PR. Surfaces likely
      rejections (coverage gaps, traceability breaks, missing evidence) so
      humans only see PRs that meet the automated bar. Advisory — does not
      block. Single-attempt to avoid delaying gate review.
    skills: [gate-pre-review]
    agent_role: Pre-Review Agent
    inputs:
      artifacts: [gate-packet]
      context: [pr-url]
    outputs:
      artifacts: [gate-readiness-check]
      side_effects:
        - target: gate_record
          fields: [ai_pre_review_verdict, ai_pre_review_notes]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]
      max_attempts_override: 1

  - id: gate-review
    label: Discovery Complete Gate
    kind: gate
    scope: per-app
    sequence: 8
    progress_pct: 90
    progress_weight: 10
    purpose: >
      Portfolio Manager signs off that this application is fully catalogued,
      analyzed, and ready to enter Rationalization. Blocks downstream lines
      until approved. Rejection carries rework feedback back into the passes.
    skills: []
    agent_role: null
    inputs:
      artifacts: [gate-packet, gate-readiness-check]
      context: []
    outputs:
      artifacts: [gate-decision]
      side_effects:
        - target: gate_record
          fields: [state, decided_at, decided_by, decision_notes]
        - target: application
          fields: [discovery_status, discovery_completed_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: G-DC
    retry_policy:
      category: validation_failure
```

## Reverse Engineering — `reverse-engineering.yaml` (4 steps)

```yaml
# Reverse Engineering — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for the Reverse-Engineering (brownfield
# legacy-ingestion) line's steps, skills, artifacts, side-effects, and agent
# contract. Every downstream consumer (Temporal workflow, Olympus API gate
# service, step-progress mapping) loads FROM this file via
# olympus_contracts.assembly_lines. Do not hardcode a copy in application
# code. Drift is policed by the `test_no_hardcoded_step_lists` CI check.
#
# ADDITIVE REGISTRATION — mirrors Build exactly (P8 legacy-ingestion §0).
# This line is registered by `_load_default_lines_from_contract` picking up
# this YAML at import time (the same mechanism that registers Build). It is
# NOT an `AssemblyLine` enum member: the frozen `enum.StrEnum` at
# `olympus_contracts/enums.py` stays EXACTLY 10 members (pinned by
# `temporal/tests/test_interfaces.py` and the profile-hardening invariant
# `test_assembly_line_enum_is_exactly_ten`). The 10 core lines and their
# `depends_on` are unchanged — this file only ADDS a line. (REQ-LI-007.)
#
# CLIENT-BLIND: no agency / client / domain token appears here. The line
# knows nothing about which legacy system it ingests; client specifics live
# only in profiles/. (Constitution §2.)
#
# Read-only by construction (REQ-LI-005): every step's agent_contract grants
# `source: ro` and `target: none`. The line NEVER gets write access to the
# legacy system — the ingestion activity raises on any simulated write.
#
# Spec: specifications/phase-8/specs/legacy-ingestion.md.

name: Reverse Engineering
description: >
  Brownfield reverse-engineering (legacy-ingestion). Ingests a legacy
  codebase READ-ONLY and reconstructs a typed specification: every recovered
  obligation carries provenance='reverse_engineered' and a confidence score.
  Sub-floor-confidence obligations are routed to human confirmation before
  they can gate a build; reconstructed obligations are enrolled in
  drift-tracking. A safety-classifier domain hit (e.g. a crypto-primitive
  region) is surfaced on the IngestionReport and routed to fallback/human via
  the existing FedRAMP fail-closed provider/tier resolution — never silently
  dropped. The clean-outcomes anchor for legacy decommission and the core
  brownfield-modernization on-ramp. Source-code-only in v1 (runtime behavior
  capture is deferred, owner-gated).
trigger: legacy-source-intake
# Strict upstream only; transitive deps are reached via the depends_on graph.
# Discovery already unpacks the legacy source tree to the shared workspace
# (its `legacy-source` input); reverse-engineering reads that tree read-only.
depends_on:
  - Discovery
gates:
  - id: G-RE-1
    label: Reconstruction Review
  - id: G-RE-2
    label: Obligation Confirmation
mode: per-app
inputs:
  - legacy-source
  - tech-fingerprint
  - structural-analysis
outputs:
  - reconstructed-spec
  - ingestion-report

steps:
  # -------------------------------------------------------------------------
  # Step 1 — Ingest (read-only walk of the legacy source tree; G-RE-1)
  # -------------------------------------------------------------------------
  - id: ingest
    label: Ingest (read-only)
    kind: agent
    scope: per-app
    sequence: 1
    progress_pct: 30
    progress_weight: 30
    artifact_filename: ingestion-report.json
    purpose: >
      Walk the unpacked legacy source tree READ-ONLY and emit an
      IngestionReport: per-region observations, the safety-classifier domain
      hits surfaced for fallback/human routing, and the count of refused write
      attempts. No write to the legacy system is ever performed — a simulated
      write RAISES rather than degrading to a no-op (REQ-LI-005). A
      safety-classifier domain hit is surfaced + routed, never swallowed
      (REQ-LI-006). Composes any profile-supplied legacy-* analysis skill via
      skill-composition (REQ-LI-008).
    skills: [reverse-engineer-spec]
    agent_role: Reverse-Engineering Agent
    inputs:
      artifacts: []
      context: [source-repo-clone, tech-fingerprint, structural-analysis]
    outputs:
      artifacts: [ingestion-report]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [ReadOnlyViolationError, SafetyClassifierError]

  # -------------------------------------------------------------------------
  # Step 2 — Reconstruct (typed ReconstructedSpec: provenance + confidence)
  # -------------------------------------------------------------------------
  - id: reconstruct
    label: Reconstruct Spec
    kind: agent
    scope: per-app
    sequence: 2
    progress_pct: 70
    progress_weight: 40
    artifact_filename: reconstructed-spec.json
    purpose: >
      Reconstruct a typed ReconstructedSpec from the read-only observations.
      Every obligation is stamped provenance='reverse_engineered' and a
      deterministic confidence score (REQ-LI-002); an obligation below the
      profile-configured floor is flagged needs_confirmation so it cannot gate
      a build until a human confirms it (REQ-LI-004). The reconstructed
      obligations are enrolled in drift-tracking via the drift-detection
      surface (REQ-LI-003).
    skills: [reverse-engineer-spec]
    agent_role: Reverse-Engineering Agent
    inputs:
      artifacts: [ingestion-report]
      context: [source-repo-clone]
    outputs:
      artifacts: [reconstructed-spec]
      side_effects:
        - target: artifact-repo
          fields:
            - obligations
            - provenance
            - confidence
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  # -------------------------------------------------------------------------
  # Step 3 — Reconstruction Review gate (G-RE-1)
  # -------------------------------------------------------------------------
  - id: reconstruction-review
    label: Reconstruction Review
    kind: gate
    scope: per-app
    sequence: 3
    progress_pct: 90
    purpose: >
      Human review of the ReconstructedSpec + IngestionReport. The reviewer
      confirms the reconstruction and acknowledges any surfaced
      safety-classifier domain hit before downstream modernization consumes
      the spec.
    role: pre-review
    gate: G-RE-1

  # -------------------------------------------------------------------------
  # Step 4 — Obligation Confirmation gate (G-RE-2)
  # -------------------------------------------------------------------------
  - id: obligation-confirmation
    label: Obligation Confirmation
    kind: gate
    scope: per-app
    sequence: 4
    progress_pct: 100
    purpose: >
      Human confirmation of sub-floor-confidence obligations. A reconstructed
      obligation whose confidence is below the profile floor is
      needs_confirmation and CANNOT gate a build until confirmed here
      (REQ-LI-004). This gate is the human-in-the-loop checkpoint for
      low-confidence reverse-engineered obligations.
    summary: true
    role: rollup
    gate: G-RE-2
```

## Rationalization — `rationalization.yaml` (21 steps)

```yaml
# Rationalization — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Rationalization's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.

name: Rationalization
description: >
  Wave-scoped portfolio analysis. Operates on every application in a wave
  simultaneously, detecting cross-app and intra-app redundancy, recommending
  per-app dispositions with evidence citations, classifying risk, scoring
  readiness across six dimensions, and sequencing the wave for downstream
  factories. Produces the executive-readable wave-outcome-synthesis.json
  that drives the portfolio target-state rollup and feeds every downstream
  line's marching orders. Rationalization is where strategy is set; it runs
  once per wave, not per-application, and consumes Discovery artifacts as
  its primary input.
trigger: wave-ready
depends_on:
  - Discovery
gates:
  - id: G-RR
    label: Redundancy Review
  - id: G-DA
    label: Disposition Approval
mode: per-wave
inputs:
  - discovery-synthesis
  - catalog-application
  - business-logic
  - structural-analysis
  - ux-accessibility
  - quality-risk
  - tco-baseline
outputs:
  - redundancy-matrix
  - consolidation-report
  - ux-overlap-matrix
  - intra-app-redundancy
  - integration-graph
  - portfolio-redundancy-matrix
  - disposition-recommendation
  - disposition-governance
  - user-impact-analysis
  - classification
  - complexity-classification
  - portfolio-score
  - capability-consolidation-plan
  - wave-plan
  - wave-plan-validation
  - factory-routing
  - wave-outcome-synthesis
  - portfolio-manifest

steps:
  - id: cross-app-redundancy
    label: Cross-App Redundancy
    kind: agent
    scope: per-wave
    sequence: 1
    progress_pct: 5
    purpose: >
      Detect overlapping business capabilities, data entities, operations, APIs,
      and technology patterns across every app in the wave. Produces the
      cross-app redundancy matrix that anchors Consolidate-disposition evidence.
    skills: [redundancy-analyzer]
    agent_role: Rationalization Analyst
    inputs:
      artifacts:
        - discovery/{app_id}/catalog-application.json
        - discovery/{app_id}/business-logic.json
        - discovery/{app_id}/structural-analysis.json
        - discovery/{app_id}/ux-accessibility.json
      context: [wave_id, app_ids]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/redundancy-matrix.json
        - rationalization/wave-{wave_id}/consolidation-report.md
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [intra-app-redundancy, compare-ux-overlap]
    gate: null
    retry_policy:
      category: agent_failure

  - id: intra-app-redundancy
    label: Intra-App Redundancy
    kind: agent
    scope: per-wave
    sequence: 2
    progress_pct: 5
    fanout: per-app-in-wave
    purpose: >
      For each app in the wave, detect within-app redundancy — duplicate
      capability implementations, copy-paste business rules, internal data
      duplication. Feeds Modernization (not Rationalization's own downstream)
      with dedup targets for the Extract/Design phases.
    skills: [redundancy-analyzer]
    agent_role: Rationalization Analyst
    inputs:
      artifacts:
        - discovery/{app_id}/business-logic.json
        - discovery/{app_id}/structural-analysis.json
        - discovery/{app_id}/quality-risk.json
      context: [wave_id, scope=intra-app]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/intra-app-redundancy.json
      side_effects: []
      consumers: [Modernization]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [cross-app-redundancy, compare-ux-overlap]
    gate: null
    retry_policy:
      category: agent_failure

  - id: compare-ux-overlap
    label: UX Overlap Analysis
    kind: agent
    scope: per-wave
    sequence: 3
    progress_pct: 5
    purpose: >
      Detect persona-task-app overlap — same user role performing the same task
      across multiple apps. Catches swivel-chair patterns and fragmented user
      journeys that structural redundancy analysis misses. Feeds HCD
      (cross-cutting) and Consolidate-disposition evidence.
    skills: [compare-ux-overlap]
    agent_role: UX Journey Analyzer
    inputs:
      artifacts:
        - discovery/{app_id}/ux-accessibility.json
        - discovery/{app_id}/catalog-application.json
      context: [wave_id, app_ids]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/ux-overlap-matrix.json
      side_effects: []
      consumers: [HCD]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [cross-app-redundancy, intra-app-redundancy]
    gate: null
    retry_policy:
      category: agent_failure

  - id: portfolio-integration-mapping
    # Stage 6 ATLAS integration (2026-05-06): portfolio-scope cross-app
    # integration-graph synthesis before per-app disposition. Decomposes
    # multi-subsystem apps and enumerates cross_system_capabilities[] that
    # downstream disposition-recommender + capability-consolidation-advisor
    # consume. Parallel with analyze-portfolio-redundancy.
    label: Portfolio Integration Mapping
    kind: agent
    scope: per-wave
    sequence: 4
    progress_pct: 8
    purpose: >
      Synthesize per-app Discovery artifacts for every application in the
      wave into a single cross-application integration graph — systems,
      data flows, shared identifiers, external dependencies, and
      cross_system_capabilities[]. Decomposes multi-subsystem applications
      into their constituent parts before cross-app integration analysis.
      Without this pass, disposition decisions collapse to per-app 7Rs
      and miss capability-level Retire/Replace opportunities.
    skills: [portfolio-integration-mapper]
    agent_role: Portfolio Integration Analyst
    inputs:
      artifacts:
        - discovery/{app_id}/catalog-application.json
        - discovery/{app_id}/dependency-graph.json
        - discovery/{app_id}/structural-analysis.json
      context: [wave_id, app_ids]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/integration-graph.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [analyze-portfolio-redundancy]
    gate: null
    retry_policy:
      category: agent_failure

  - id: analyze-portfolio-redundancy
    # Stage 6 ATLAS integration (2026-05-06): portfolio-wide redundancy
    # synthesis between per-pair redundancy-analyzer output and
    # per-app disposition. Produces the portfolio redundancy matrix plus
    # the shared-identity report via detect_shared_identifiers.py.
    label: Portfolio Redundancy Analysis
    kind: agent
    scope: per-wave
    sequence: 5
    progress_pct: 11
    purpose: >
      Synthesize per-pair redundancy findings (from redundancy-analyzer
      running at cross-app and intra-app scope) and per-app Discovery
      artifacts into a portfolio-wide redundancy matrix that identifies
      which applications duplicate each other's functionality. Emits the
      shared-identity report that disposition scoring consumes. Privacy
      findings for regulated identifiers are emitted on a separate track.
    skills: [analyze-portfolio-redundancy]
    agent_role: Portfolio Redundancy Analyst
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/redundancy-matrix.json
        - rationalization/wave-{wave_id}/{app_id}/intra-app-redundancy.json
        - rationalization/wave-{wave_id}/integration-graph.json
        - discovery/{app_id}/business-logic.json
      context: [wave_id, app_ids]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/portfolio-redundancy-matrix.json
        - rationalization/wave-{wave_id}/shared-identity-report.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [portfolio-integration-mapping]
    gate: null
    retry_policy:
      category: agent_failure

  - id: commit-redundancy-artifacts
    label: Commit Redundancy Artifacts
    kind: git
    scope: per-wave
    sequence: 6
    progress_pct: 15
    purpose: >
      Commit the cross-app redundancy matrix, consolidation report, UX overlap
      matrix, portfolio integration graph, portfolio redundancy matrix,
      shared-identity report, and all per-app intra-app-redundancy artifacts
      to the wave branch in the portfolio's artifact repo. Stage 6 ATLAS
      integration (2026-05-06): expanded to include portfolio-scope
      artifacts from portfolio-integration-mapping and
      analyze-portfolio-redundancy.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/redundancy-matrix.json
        - rationalization/wave-{wave_id}/consolidation-report.md
        - rationalization/wave-{wave_id}/ux-overlap-matrix.json
        - rationalization/wave-{wave_id}/integration-graph.json
        - rationalization/wave-{wave_id}/portfolio-redundancy-matrix.json
        - rationalization/wave-{wave_id}/shared-identity-report.json
        - rationalization/wave-{wave_id}/{app_id}/intra-app-redundancy.json
      context: []
    outputs:
      artifacts: []
      side_effects:
        - target: artifact_repo
          fields: [commit_sha, branch]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-grr-pr
    label: Create G-RR PR
    kind: git
    scope: per-wave
    sequence: 7
    progress_pct: 18
    purpose: >
      Open the Gate G-RR review PR against the portfolio's artifact repo main
      branch. Body lists wave-scoped redundancy artifacts and the per-app
      intra-app breakdown for stakeholder review.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [wave_id, wave_name]
    outputs:
      artifacts:
        - gate-packet
      side_effects:
        - target: gate_record
          fields: [evidence_package_url, gate_type, portfolio_id, workflow_id]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: gate-review-rr
    label: Redundancy Review Gate
    kind: gate
    scope: per-wave
    sequence: 8
    progress_pct: 22
    purpose: >
      Stakeholder reviews the wave's cross-app redundancy matrix, UX overlap
      matrix, consolidation report, and per-app intra-app findings. PR merge =
      approval; rejection loops rework back through cross-app-redundancy with
      feedback context. Approval unlocks the per-app disposition pipeline.
    skills: []
    agent_role: null
    inputs:
      artifacts: [gate-packet]
      context: []
    outputs:
      artifacts: [gate-decision]
      side_effects:
        - target: gate_record
          fields: [state, decided_at, decided_by, decision_notes]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: G-RR
    retry_policy:
      category: validation_failure

  - id: disposition-recommendation
    label: Disposition Recommendation
    kind: agent
    scope: per-wave
    sequence: 9
    progress_pct: 35
    fanout: per-app-in-wave
    purpose: >
      For each app in the wave, synthesize Discovery evidence and wave-scoped
      redundancy/UX overlap findings into one of seven dispositions (Retire,
      Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate) with
      traceable evidence citations. Per-app dispatch in parallel. Stage 6
      ATLAS integration (2026-05-06): now also consumes the portfolio
      integration-graph and portfolio-redundancy-matrix so per-app 7R
      decisions are reconcilable against cross_system_capabilities[].
    skills: [disposition-recommender]
    agent_role: Analysis Agent
    inputs:
      artifacts:
        - discovery/{app_id}/catalog-application.json
        - discovery/{app_id}/business-logic.json
        - discovery/{app_id}/quality-risk.json
        - discovery/{app_id}/ux-accessibility.json
        - discovery/{app_id}/tco-baseline.json
        - rationalization/wave-{wave_id}/redundancy-matrix.json
        - rationalization/wave-{wave_id}/ux-overlap-matrix.json
        - rationalization/wave-{wave_id}/integration-graph.json
        - rationalization/wave-{wave_id}/portfolio-redundancy-matrix.json
        - rationalization/wave-{wave_id}/{app_id}/intra-app-redundancy.json
      context: [wave_id]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: disposition-governance
    label: Disposition Governance
    kind: agent
    scope: per-wave
    sequence: 10
    progress_pct: 45
    fanout: per-app-in-wave
    purpose: >
      For each app, validate the recommendation against stakeholder sign-off
      policy: required stakeholders identified, evidence package complete,
      user transition path documented for Retire/Replace. Produces the
      per-app governance artifact consumed by the G-DA checklist PR.
    skills: [disposition-governance]
    agent_role: Validation Agent
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
      context: [wave_id]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/disposition-governance.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: user-impact-analysis
    label: User Impact Analysis
    kind: agent
    scope: per-wave
    sequence: 11
    progress_pct: 50
    fanout: per-app-in-wave
    condition: disposition in [Retire, Replace]
    purpose: >
      For Retire/Replace dispositions only — quantify affected users, disrupted
      journeys, training burden, transition risk. Drives the transition plan
      that Disposition Execution consumes.
    skills: [assess-user-impact]
    agent_role: Impact Analyzer
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
        - discovery/{app_id}/ux-accessibility.json
      context: [wave_id, disposition]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: classification
    label: Classification & Risk Tiering
    kind: agent
    scope: per-wave
    sequence: 12
    progress_pct: 60
    fanout: per-app-in-wave
    purpose: >
      For each app, assign a risk tier (Tier 1 / 2 / 3 per client profile).
      Stage 6 ATLAS integration (2026-05-06): also emits a complexity
      classification (Simple/Moderate/Complex) via classify-complexity
      that drives Modernization dispatch pattern and agent-tier selection.
      Risk-tier cites archetype from Discovery's catalog artifact (Discovery
      owns archetype); complexity combines catalog counts with Pass 1
      structural findings per classify-complexity/references. Tier 1
      assignments pause the workflow for stakeholder confirmation.
    skills: [classify-application, classify-complexity]
    agent_role: Classification Agent
    inputs:
      artifacts:
        - discovery/{app_id}/catalog-application.json
        - discovery/{app_id}/structural-analysis.json
        - discovery/{app_id}/quality-risk.json
        - rationalization/wave-{wave_id}/integration-graph.json
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
      context: [wave_id]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/classification.json
        - rationalization/wave-{wave_id}/{app_id}/complexity-classification.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: portfolio-scoring
    label: Portfolio Scoring
    kind: agent
    scope: per-wave
    sequence: 13
    progress_pct: 68
    fanout: per-app-in-wave
    purpose: >
      For each app, produce a six-dimensional evidence vector (business value,
      technical debt, user impact, cost, redundancy, modernization complexity).
      Runs after classification so risk_tier and archetype can be cited.
      Drives both disposition confidence and wave-planning sequencing.
    skills: [portfolio-scorer]
    agent_role: Scoring Model
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/classification.json
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
        - discovery/{app_id}/quality-risk.json
        - discovery/{app_id}/tco-baseline.json
        - rationalization/wave-{wave_id}/redundancy-matrix.json
      context: [wave_id]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/portfolio-score.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: capability-consolidation-advisory
    # Stage 6 ATLAS integration (2026-05-06): cross-app capability-level
    # disposition advice. Runs after ≥2 per-app dispositions exist.
    # Consumes integration-graph cross_system_capabilities[] and per-app
    # dispositions; emits capability-consolidation-plan.json that
    # sequencer uses for cross-capability wave ordering.
    label: Capability Consolidation Advisory
    kind: agent
    scope: per-wave
    sequence: 14
    progress_pct: 73
    purpose: >
      Produce the capability-consolidation-plan.json turning portfolio-
      level observations into executable consolidation guidance. For each
      capability in integration-graph.cross_system_capabilities[] with ≥2
      participating apps having a disposition recommendation, pick the
      aggregate disposition (7R + keep-separate), choose a consolidation
      pattern (strangler-fig / bulk-replace / keep-separate), sequence
      the work, score risks, and estimate effort.
    skills: [capability-consolidation-advisor]
    agent_role: Capability Consolidation Advisor
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/integration-graph.json
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
        - rationalization/wave-{wave_id}/{app_id}/disposition-governance.json
        - rationalization/wave-{wave_id}/{app_id}/classification.json
        - rationalization/wave-{wave_id}/{app_id}/portfolio-score.json
      context: [wave_id]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/capability-consolidation-plan.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: wave-planning
    label: Wave Planning
    kind: agent
    scope: per-wave
    sequence: 15
    progress_pct: 78
    purpose: >
      Build the wave plan — critical path, dependency ordering, capacity-loaded
      schedule, risk-balanced distribution. Extended responsibility: validate
      the disposition mix is feasible given dependencies and DB clusters, and
      emit structured infeasibilities as first-class output (absorbs the former
      ghost `validate-disposition` skill). Blocks G-DA if validation fails.
    skills: [sequencer]
    agent_role: Sequencing Optimizer
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
        - rationalization/wave-{wave_id}/{app_id}/classification.json
        - rationalization/wave-{wave_id}/{app_id}/complexity-classification.json
        - rationalization/wave-{wave_id}/{app_id}/portfolio-score.json
        - rationalization/wave-{wave_id}/redundancy-matrix.json
        - rationalization/wave-{wave_id}/capability-consolidation-plan.json
      context:
        - wave_id
        - profile_capacity
        - dependency_graph
        - shared_db_cluster_map
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/wave-plan.json
        - rationalization/wave-{wave_id}/wave-plan-validation.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: factory-routing
    label: Factory Routing
    kind: code
    scope: per-wave
    sequence: 16
    progress_pct: 82
    purpose: >
      Bookkeeping — flatten per-app disposition decisions into a single
      wave-scoped route list that downstream factories (Modernization,
      Disposition Execution, Retain) consume without re-parsing each per-app
      disposition recommendation. No agent call; pure workflow code.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
      context: [wave_id, app_ids]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/factory-routing.json
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: commit-disposition-artifacts
    label: Commit Disposition Artifacts
    kind: git
    scope: per-wave
    sequence: 17
    progress_pct: 85
    purpose: >
      Commit all per-app disposition, governance, user-impact,
      classification, complexity-classification, and portfolio-score
      artifacts, plus the capability consolidation plan, wave plan,
      feasibility validation, factory routing, and scoring methodology
      digest to the wave branch. Stage 6 ATLAS integration (2026-05-06):
      includes capability-consolidation-plan.json and per-app
      complexity-classification.json.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
        - rationalization/wave-{wave_id}/{app_id}/disposition-governance.json
        - rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json
        - rationalization/wave-{wave_id}/{app_id}/classification.json
        - rationalization/wave-{wave_id}/{app_id}/complexity-classification.json
        - rationalization/wave-{wave_id}/{app_id}/portfolio-score.json
        - rationalization/wave-{wave_id}/capability-consolidation-plan.json
        - rationalization/wave-{wave_id}/wave-plan.json
        - rationalization/wave-{wave_id}/wave-plan-validation.json
        - rationalization/wave-{wave_id}/factory-routing.json
        - rationalization/wave-{wave_id}/scoring-methodology.md
      context: []
    outputs:
      artifacts: []
      side_effects:
        - target: artifact_repo
          fields: [commit_sha, branch]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-gda-pr
    label: Create G-DA PR
    kind: git
    scope: per-wave
    sequence: 18
    progress_pct: 88
    purpose: >
      Open the Gate G-DA review PR. Body aggregates per-app dispositions,
      wave-scoped artifacts, scoring methodology, wave plan, factory routing,
      and the stakeholder sign-off checklist.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [wave_id, wave_name, per_app_dispositions]
    outputs:
      artifacts: [gate-packet]
      side_effects:
        - target: gate_record
          fields: [evidence_package_url, gate_type, portfolio_id, workflow_id]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: gate-review-da
    label: Disposition Approval Gate
    kind: gate
    scope: per-wave
    sequence: 19
    progress_pct: 92
    purpose: >
      Dual-signal gate — BOTH a PM gate_approved signal (PR merge) AND a
      stakeholder StakeholderApprovedSignal with scope="g-da" are required.
      Rejection loops rework back through the per-app disposition pipeline
      with feedback context; rework preserves redundancy/intra-app results.
      Approval triggers DB projection of classification + portfolio-score +
      disposition side-effects and unlocks wave-outcome-synthesis.
    skills: []
    agent_role: null
    inputs:
      artifacts: [gate-packet]
      context: []
    outputs:
      artifacts: [gate-decision]
      side_effects:
        - target: gate_record
          fields: [state, decided_at, decided_by, decision_notes]
        - target: application
          fields:
            - risk_tier
            - risk_tier_source
            - portfolio_score
            - disposition
            - disposition_source
            - disposition_rationale_ref
          notes: >
            Applied via persist_rationalization_side_effects activity after gate
            approval; exclusive owner of these fields within Rationalization.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: G-DA
    retry_policy:
      category: validation_failure

  - id: wave-outcome-synthesis
    label: Wave Outcome Synthesis
    kind: agent
    scope: per-wave
    sequence: 20
    progress_pct: 96
    summary: true
    purpose: >
      Consolidate the approved wave into an executive-readable target-state
      readout. Reads every per-app disposition / classification / portfolio-
      score / user-impact artifact plus the wave plan and redundancy matrix;
      emits the single wave-outcome-synthesis.json artifact the dashboard's
      wave page surfaces and the portfolio target-state rollup API aggregates
      across waves. Schema in schemas/rationalization/. Spec:
      specifications/phase-5/rationalization-outputs.md.
    skills: [wave-outcome-synthesizer]
    agent_role: Rationalization Analyst
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
        - rationalization/wave-{wave_id}/{app_id}/disposition-governance.json
        - rationalization/wave-{wave_id}/{app_id}/classification.json
        - rationalization/wave-{wave_id}/{app_id}/portfolio-score.json
        - rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json
        - rationalization/wave-{wave_id}/redundancy-matrix.json
        - rationalization/wave-{wave_id}/wave-plan.json
      context: [wave_id, wave_name, portfolio_id]
    outputs:
      artifacts:
        - rationalization/wave-{wave_id}/wave-outcome-synthesis.json
      side_effects: []
      consumers: [Architecture, Data, Modernization, Disposition-Execution, Governance, Dashboards]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: portfolio-manifest-generation
    # Stage 6 ATLAS integration (2026-05-06): terminal portfolio-scope
    # closeout pass. Runs only on the final wave of the portfolio; earlier
    # waves skip this step. Emits the sponsor-facing portfolio-manifest
    # packet that rolls up every wave-outcome-synthesis into a single
    # inventory + disposition summary + wave sequencing + exception
    # register. Distinct from per-wave wave-outcome-synthesizer.
    label: Portfolio Manifest Generation
    kind: agent
    scope: per-wave
    sequence: 21
    progress_pct: 99
    condition: is_final_wave == true
    purpose: >
      Produce the portfolio-level manifest after the last wave of
      Rationalization finishes. Packages the full inventory
      (app_id, risk_tier, disposition, wave), HCD summary, Section 508
      overview, wave sequencing, and exception register into a single
      reviewable packet. Emits both portfolio-manifest.json (schema-
      validated) and portfolio-manifest.md (sponsor-facing). Failsclosed
      if any wave in the portfolio lacks a wave-outcome-synthesis.json.
    skills: [portfolio-manifest-generator]
    agent_role: Portfolio Close-out Analyst
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/wave-outcome-synthesis.json
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
        - discovery/{app_id}/catalog-application.json
        - rationalization/wave-{wave_id}/ux-overlap-matrix.json
      context: [portfolio_id, wave_ids]
    outputs:
      artifacts:
        - rationalization/portfolio/{portfolio_id}/portfolio-manifest.json
        - rationalization/portfolio/{portfolio_id}/portfolio-manifest.md
      side_effects: []
      consumers: [Architecture, Modernization, Disposition-Execution, Governance]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
```

## Architecture — `architecture.yaml` (19 steps)

```yaml
# Architecture — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Architecture's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.

name: Architecture
description: >
  Architecture designs the target state. It consumes Rationalization's
  disposition decisions and produces a blueprint per target application —
  which may be the source application (Refactor/Rearchitect/Replatform), a
  brand-new application (Replace), or a consolidated application merging
  multiple sources (Consolidate). Retire and Retain skip most of the line.
  Architecture decides what will be built and how it will fit — cloud
  pattern, EA compliance, integration contracts, data architecture,
  security posture, UI/UX design system, accessibility commitments, and
  AI/ML considerations — then assembles those into one cohesive blueprint
  per target.
trigger: rationalization-g-da-approved
# Strict upstream only. Architecture and Data run in parallel and sync via
# signals (TargetProvisioned, DataPlanReady) — that coordination lives in
# step contracts, not in line-level dependencies.
depends_on:
  - Rationalization
gates:
  - id: G-02
    label: Architecture Alignment Review
mode: per-target-app
inputs:
  - disposition-recommendation
  - disposition-governance
  - redundancy-matrix
  - catalog-application
  - tco-baseline
  - structural-analysis
  - business-logic
  - ux-accessibility
outputs:
  - target-application-map
  - cloud-pattern
  # Stage 5 ATLAS integration (2026-05-06)
  - deployment-topology
  - target-architecture-blueprint
  - ea-compliance
  - integration-arch
  # Stage 5 ATLAS integration (2026-05-06)
  - resilience-matrix
  - security-arch
  - cato-evidence-seed
  - design-system
  - accessibility-review
  - ai-ml-integration
  - architecture-blueprint
  - blueprint-summary
  # Stage 5 ATLAS integration (2026-05-06)
  - cost-estimate
  - well-architected-review
  # Stage 9 ATLAS integration (2026-05-06)
  - traceability-validation

steps:
  - id: target-state-mapping
    label: Target-State Mapping
    kind: agent
    scope: per-target-app
    sequence: 1
    progress_pct: 10
    purpose: >
      Reconcile Rationalization's disposition decision into a concrete target
      application record. For Refactor/Rearchitect/Replatform: confirm the
      source=target linkage. For Replace: provision a new application row for
      the target. For Consolidate: provision (or promote) the target app and
      record the N source → 1 target lineage. For Retire/Retain: short-circuit
      downstream steps. Emits target-application-map.json as the authoritative
      source→target record every downstream line consumes.
    skills: [target-state-mapper]
    agent_role: Target-State Architect
    inputs:
      artifacts:
        - rationalization/wave-{wave_id}/{source_app_id}/disposition-recommendation.json
        - rationalization/wave-{wave_id}/{source_app_id}/disposition-governance.json
        - rationalization/wave-{wave_id}/redundancy-matrix.json
        - discovery/{source_app_id}/catalog-application.json
      context:
        - wave_id
        - source_app_ids
        - disposition
    outputs:
      artifacts:
        - architecture/{target_app_id}/target-application-map.json
      side_effects:
        - target: application
          fields: [id, name, portfolio_id, source_app_ids]
          notes: >
            New row created for Replace/Consolidate targets; existing row
            updated for other dispositions. Projection via
            persist_architecture_side_effects post-G-02.
        - target: application_lineage
          fields: [target_app_id, source_app_id, relationship]
          notes: >
            New rows recording source→target edges. Relationship enum:
            replace | consolidate-source | refactor-of | rearchitect-of |
            replatform-of | retain.
        - signal: TargetProvisionedSignal
          fields: [target_app_id, portfolio_id, architecture_workflow_id, wave_id, disposition]
          target: DataWorkflow (for this target)
          notes: >
            Fired immediately after target-application-map.json commits so the
            Data line can unblock its wait-for-target-provisioned step. Signal
            shape defined in olympus_workflows.types.TargetProvisionedSignal
            (2026-05-01, Data line contract). Emission wiring lands in Data
            line PR 2 alongside the Data workflow reshape — the signal type
            is imported from Data line PR 0.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: cloud-pattern-selection
    label: Target Architecture Strategy
    kind: agent
    scope: per-target-app
    sequence: 2
    progress_pct: 15
    # Stage 5 ATLAS integration (2026-05-06): deployment-topology and
    # target-architecture-blueprint co-run on this step. Both consume the
    # selected cloud pattern plus the source Discovery inputs and emit
    # sibling artifacts that feed blueprint-assembly. All three skills are
    # cloud-var skills — the active profile's common.yaml pins cloud_provider,
    # cloud_region, cloud_container_service, cloud_serverless_service.
    purpose: >
      Select the cloud-native pattern (serverless, microservices, modular
      monolith, event-driven, batch, or hybrid) best-fit to the target's
      archetype, complexity, risk tier, and non-functional requirements.
      Produces the pattern decision, the deployment topology (container /
      function sizing, VPC topology, scaling, CI/CD, IaC module
      composition), and the target-architecture blueprint (approved-
      service selection, ADRs, C4 diagrams) per the active profile's
      cloud-provider pin.
    skills: [migration-strategy-advisor, deployment-topology, target-architecture-blueprint]
    agent_role: Cloud Architect
    inputs:
      artifacts:
        - architecture/{target_app_id}/target-application-map.json
        - discovery/{source_app_id}/catalog-application.json
        - discovery/{source_app_id}/tco-baseline.json
      context:
        - wave_id
        - target_app_id
        - archetype
        - complexity_tier
        - risk_tier
    outputs:
      artifacts:
        - architecture/{target_app_id}/cloud-pattern.json
        # Stage 5 ATLAS integration (2026-05-06): deployment-topology +
        # target-architecture-blueprint sibling artifacts.
        - architecture/{target_app_id}/deployment-topology.json
        - architecture/{target_app_id}/target-architecture-blueprint.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: ea-compliance
    label: EA Compliance Verification
    kind: agent
    scope: per-target-app
    sequence: 3
    progress_pct: 22
    purpose: >
      Verify the selected pattern against enterprise architecture standards.
      Cite any BLOCK findings that must be resolved before the pattern can be
      assembled into the blueprint. Produces the ea-compliance.json artifact
      that G-02 evidence attaches.
    skills: [ea-compliance]
    agent_role: EA Compliance Reviewer
    inputs:
      artifacts:
        - architecture/{target_app_id}/cloud-pattern.json
        - architecture/{target_app_id}/target-application-map.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts:
        - architecture/{target_app_id}/ea-compliance.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: integration-arch
    label: Integration Architecture
    kind: agent
    scope: per-target-app
    sequence: 4
    progress_pct: 30
    # Stage 5 ATLAS integration (2026-05-06): resilience-designer folded in.
    # Resilience patterns (circuit breakers, retries, DLQs, bulkheads) pair
    # naturally with integration-contract design since they are integration-
    # boundary concerns. Cloud-var skill — cloud_region pins region-pair
    # failover options via the active profile's common.yaml.
    purpose: >
      Design API contracts, event schemas, external interface preservation
      (consumer compatibility), anti-corruption layers, and the resilience
      architecture (RTO/RPO per risk tier, circuit breakers, retries,
      bulkheads, DLQs, chaos-test plan). Covers both synchronous (API)
      and asynchronous (event) integration paths.
    skills: [api-contract-validator, event-contract, resilience-designer]
    agent_role: Integration Architect
    inputs:
      artifacts:
        - architecture/{target_app_id}/cloud-pattern.json
        - architecture/{target_app_id}/deployment-topology.json
        - discovery/{source_app_id}/structural-analysis.json
        - discovery/{source_app_id}/business-logic.json
      context: [wave_id, target_app_id, source_app_ids, risk_tier]
    outputs:
      artifacts:
        - architecture/{target_app_id}/integration-arch.json
        # Stage 5 ATLAS integration (2026-05-06): resilience-designer
        # emits the resilience matrix.
        - architecture/{target_app_id}/resilience-matrix.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [data-architecture]
    gate: null
    retry_policy:
      category: agent_failure

  - id: data-architecture
    label: Data Architecture Handshake
    kind: code
    scope: per-target-app
    sequence: 5
    progress_pct: 35
    purpose: >
      Lightweight bookkeeping step. The Data line runs in parallel once
      target-state-mapping emits; this step waits for Data's terminal gate to
      approve and pulls the authoritative data-architecture.json + data-
      migration-plan.json artifact refs into this line's state, so blueprint
      assembly and G-02 evidence reference the same shape Data approved.
      Not an agent dispatch — pure workflow code (signal wait + artifact ref
      capture).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - data/{target_app_id}/data-architecture.json
        - data/{target_app_id}/data-migration-plan.json
      context: [wave_id, target_app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: none
    parallel_with: [integration-arch]
    gate: null
    retry_policy:
      category: transient

  - id: security-arch
    label: Security Architecture
    kind: agent
    scope: per-target-app
    sequence: 6
    progress_pct: 42
    purpose: >
      Map security controls against the chosen pattern and integration shape:
      identity architecture, Zero Trust posture, continuous-ATO evidence
      seeds, secrets management, network segmentation. Produces the security-
      arch.json artifact and the cATO-evidence-seed.json referenced by the
      Compliance cross-cutting line.
    skills: [cato-compliance, security-posture-analyzer]
    agent_role: Security Architect
    inputs:
      artifacts:
        - architecture/{target_app_id}/cloud-pattern.json
        - architecture/{target_app_id}/integration-arch.json
        - data/{target_app_id}/data-architecture.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts:
        - architecture/{target_app_id}/security-arch.json
        - architecture/{target_app_id}/cato-evidence-seed.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: design-system
    label: Design System Mapping
    kind: agent
    scope: per-target-app
    sequence: 7
    progress_pct: 50
    purpose: >
      Narrow design-system scope to component-library mapping only. Establish
      which reusable UI components the target consumes, what new components
      the target contributes, and the tokens/theme alignment. Accessibility
      is deliberately a separate step — see accessibility-review.
    skills: [design-system]
    agent_role: Design System Architect
    inputs:
      artifacts:
        - architecture/{target_app_id}/cloud-pattern.json
        - discovery/{source_app_id}/ux-accessibility.json
      context: [wave_id, target_app_id, archetype]
    outputs:
      artifacts:
        - architecture/{target_app_id}/design-system.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [accessibility-review]
    gate: null
    retry_policy:
      category: agent_failure

  - id: accessibility-review
    label: Accessibility Review
    kind: agent
    scope: per-target-app
    sequence: 8
    progress_pct: 55
    purpose: >
      Act as a design review for accessibility — WCAG + Section 508 commitments
      the target will honor, identified conformance risks, remediation notes
      that feed Modernization's acceptance criteria. Separate from
      design-system because accessibility is a cross-cutting commitment, not
      a component concern.
    skills: [accessibility-reviewer]
    agent_role: Accessibility Reviewer
    inputs:
      artifacts:
        - architecture/{target_app_id}/design-system.json
        - discovery/{source_app_id}/ux-accessibility.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts:
        - architecture/{target_app_id}/accessibility-review.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [design-system]
    gate: null
    retry_policy:
      category: agent_failure

  - id: ai-ml-integration
    label: AI/ML Integration
    kind: agent
    scope: per-target-app
    sequence: 9
    progress_pct: 62
    purpose: >
      Always runs — every target is considered for AI/ML integration potential.
      Emits one of three outcomes: ai-ml-required (target has AI/ML in scope),
      ai-ml-applicable (future opportunity, not in this modernization),
      ai-ml-not-applicable (no use case identified). Replaces the string-match
      heuristic in the current workflow.
    skills: [ai-ml-integration]
    agent_role: AI/ML Solutions Architect
    inputs:
      artifacts:
        - architecture/{target_app_id}/target-application-map.json
        - architecture/{target_app_id}/cloud-pattern.json
        - discovery/{source_app_id}/business-logic.json
      context: [wave_id, target_app_id, archetype]
    outputs:
      artifacts:
        - architecture/{target_app_id}/ai-ml-integration.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: blueprint-assembly
    label: Blueprint Assembly
    kind: agent
    scope: per-target-app
    sequence: 10
    progress_pct: 68
    summary: true
    # Stage 5 ATLAS integration (2026-05-06): deployment-topology,
    # target-architecture-blueprint, and resilience-matrix are now sibling
    # inputs from earlier steps. blueprint-assembly's scope is unchanged
    # (pure synthesis) but its input set widens so the assembled
    # blueprint can cite the concrete service selection + resilience
    # matrix rather than leaving them as open questions.
    purpose: >
      Synthesize every upstream artifact (target-map, pattern, target-
      architecture-blueprint, deployment-topology, EA, integration,
      resilience-matrix, data, security, design-system, accessibility,
      AI/ML) into one cohesive architecture blueprint. Produces
      architecture-blueprint.json — authoritative input for Modernization
      — plus a human-readable blueprint-summary.md for G-02 reviewers.
    skills: [blueprint-assembly]
    agent_role: Architecture Synthesizer
    inputs:
      artifacts:
        - architecture/{target_app_id}/target-application-map.json
        - architecture/{target_app_id}/cloud-pattern.json
        - architecture/{target_app_id}/deployment-topology.json
        - architecture/{target_app_id}/target-architecture-blueprint.json
        - architecture/{target_app_id}/ea-compliance.json
        - architecture/{target_app_id}/integration-arch.json
        - architecture/{target_app_id}/resilience-matrix.json
        - data/{target_app_id}/data-architecture.json
        - architecture/{target_app_id}/security-arch.json
        - architecture/{target_app_id}/design-system.json
        - architecture/{target_app_id}/accessibility-review.json
        - architecture/{target_app_id}/ai-ml-integration.json
      context: [wave_id, target_app_id, source_app_ids]
    outputs:
      artifacts:
        - architecture/{target_app_id}/architecture-blueprint.json
        - architecture/{target_app_id}/blueprint-summary.md
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  # Stage 5 ATLAS integration (2026-05-06): cloud-cost-estimator as its
  # own pre-G-02 evidence step. Runs after blueprint-assembly (needs the
  # final service inventory to cost) and emits cost-estimate.yaml that
  # attaches to the G-02 PR alongside blueprint-summary.md. Cloud-var
  # skill — cloud_region pins region pricing via the active profile.
  - id: cloud-cost-estimate
    label: Cloud Cost Estimate
    kind: agent
    scope: per-target-app
    sequence: 11
    progress_pct: 72
    purpose: >
      Produce an itemized cloud-cost projection for the assembled
      blueprint and compare against the Discovery TCO baseline to
      quantify net savings. Feeds G-02 evidence so reviewers see
      architectural decisions alongside their cost implications.
    skills: [cloud-cost-estimator]
    agent_role: Cloud Cost Analyst
    inputs:
      artifacts:
        - architecture/{target_app_id}/architecture-blueprint.json
        - architecture/{target_app_id}/deployment-topology.json
        - discovery/{source_app_id}/tco-baseline.json
      context: [wave_id, target_app_id, archetype, risk_tier]
    outputs:
      artifacts:
        - architecture/{target_app_id}/cost-estimate.yaml
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [well-architected-review]
    gate: null
    retry_policy:
      category: agent_failure

  # Stage 5 ATLAS integration (2026-05-06): well-architected-reviewer as
  # its own pre-G-02 evidence step. Runs in parallel with cloud-cost-
  # estimate; both depend only on the assembled blueprint. Cloud-var
  # skill — well_architected_framework pins the framework lens via the
  # active profile.
  - id: well-architected-review
    label: Well-Architected Review
    kind: agent
    scope: per-target-app
    sequence: 12
    progress_pct: 74
    purpose: >
      Evaluate the assembled architecture blueprint against the active
      profile's Well-Architected-style framework. Score each pillar 1-5
      with evidence citations, identify top risks, and produce a review
      report that attaches to G-02 evidence.
    skills: [well-architected-reviewer]
    agent_role: Architecture Quality Reviewer
    inputs:
      artifacts:
        - architecture/{target_app_id}/architecture-blueprint.json
        - architecture/{target_app_id}/resilience-matrix.json
        - architecture/{target_app_id}/security-arch.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts:
        - architecture/{target_app_id}/well-architected-review.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [cloud-cost-estimate, traceability-validation]
    gate: null
    retry_policy:
      category: agent_failure

  # Stage 9 ATLAS integration (2026-05-06): architecture-traceability-
  # validator as its own pre-G-02 evidence step. Runs in parallel with
  # cloud-cost-estimate + well-architected-review; all three depend
  # only on the assembled blueprint + upstream Discovery artifacts.
  # Independent second-pass validator that verifies every ADR traces
  # to a Discovery finding and every architecturally-significant
  # finding is addressed. Complements traceability-checker (which runs
  # at Validation for requirement→test coverage) — this skill is
  # specialised for the ADR→finding edge on the Architecture gate.
  - id: traceability-validation
    label: Architecture Traceability Validation
    kind: agent
    scope: per-target-app
    sequence: 13
    progress_pct: 76
    purpose: >
      Independently verify that every ADR in the assembled blueprint
      traces to a Discovery finding and that every architecturally-
      significant Discovery finding is addressed by at least one ADR.
      Emits a traceability-validation report that attaches to G-02
      evidence. Tier-adjusted coverage threshold: >= 95% for T1/T2,
      >= 90% for T3. Zero orphan ADRs.
    skills: [architecture-traceability-validator]
    agent_role: Traceability Validator
    inputs:
      artifacts:
        - architecture/{target_app_id}/architecture-blueprint.json
        - architecture/{target_app_id}/blueprint-summary.md
        - discovery/{source_app_id}/structural-analysis.json
        - discovery/{source_app_id}/business-logic.json
        - discovery/{source_app_id}/quality-risk.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts:
        - architecture/{target_app_id}/traceability-validation.md
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: [cloud-cost-estimate, well-architected-review]
    gate: null
    retry_policy:
      category: agent_failure

  - id: commit-blueprint-artifacts
    label: Commit Blueprint Artifacts
    kind: git
    scope: per-target-app
    sequence: 14
    progress_pct: 78
    purpose: >
      Workflow code (not an agent dispatch). Commits every architecture
      artifact produced in this run to the per-target branch in the artifact
      repo. One commit; commit message references wave_id + target_app_id.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - architecture/{target_app_id}/*.json
        - architecture/{target_app_id}/blueprint-summary.md
      context: [wave_id, target_app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-02-pr
    label: Create G-02 Review PR
    kind: git
    scope: per-target-app
    sequence: 15
    progress_pct: 83
    purpose: >
      Open the gate-review PR against the artifact repo's main branch. PR body
      aggregates the blueprint summary + side-by-side source→target diff (when
      applicable) + links to every upstream artifact. Tier-1 PRs explicitly
      tag EA board + security officer for stakeholder sign-off.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - architecture/{target_app_id}/architecture-blueprint.json
        - architecture/{target_app_id}/blueprint-summary.md
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: ai-pre-review
    label: AI Pre-Review
    kind: agent
    scope: per-target-app
    sequence: 16
    progress_pct: 87
    purpose: >
      Advisory readiness check before the human gate opens — flags likely
      blocker findings (missing evidence, stale data-architecture, AI/ML
      decision incoherent with pattern, accessibility commitments below risk-
      tier floor, trace gaps, orphan ADRs) so reviewers and the workflow
      can short-circuit obvious rejections.
    skills: [gate-pre-review]
    agent_role: Gate Pre-Reviewer
    inputs:
      artifacts:
        - architecture/{target_app_id}/architecture-blueprint.json
        - architecture/{target_app_id}/blueprint-summary.md
        # Stage 5 ATLAS integration (2026-05-06): cost + WAR feed
        # pre-review so tier-adjusted-minima and budget-overrun checks
        # can surface blockers before the human gate opens.
        - architecture/{target_app_id}/cost-estimate.yaml
        - architecture/{target_app_id}/well-architected-review.json
        # Stage 9 ATLAS integration (2026-05-06): traceability-validation
        # feeds pre-review so ADR-trace gaps and orphan decisions can
        # surface as blockers before the human gate opens.
        - architecture/{target_app_id}/traceability-validation.md
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts:
        - architecture/{target_app_id}/pre-review.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
          notes: Persisted so the gate-review UI can surface pre-review findings.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-02
    label: G-02 Architecture Alignment Review
    kind: gate
    scope: per-target-app
    sequence: 17
    progress_pct: 91
    purpose: >
      Human review of the blueprint by EA board (plus security officer for
      Tier-1). Dual/triple-signal approval model — PM merges PR AND
      stakeholder(s) fire the matching scope signal(s). Rejection loops back
      through the contested steps (up to 3 rework iterations before workflow
      fails).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - architecture/{target_app_id}/architecture-blueprint.json
        - architecture/{target_app_id}/blueprint-summary.md
        - architecture/{target_app_id}/pre-review.json
        # Stage 9 ATLAS integration (2026-05-06): traceability report is
        # part of the G-02 evidence bundle alongside the blueprint.
        - architecture/{target_app_id}/traceability-validation.md
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
        - target: application
          fields:
            - architecture_blueprint_ref
            - architecture_pattern
            - architecture_decided_at
          notes: >
            Applied via persist_architecture_side_effects activity after gate
            approval. architecture_blueprint_ref is the committed path of
            architecture-blueprint.json at the merged commit.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: G-02
    retry_policy:
      category: validation_failure

  - id: persist-architecture-side-effects
    label: Persist Architecture Side-Effects
    kind: code
    scope: per-target-app
    sequence: 18
    progress_pct: 95
    purpose: >
      Post-gate projection. Parses the merged blueprint + target-application-
      map and writes the authoritative architecture fields onto application
      (target row) plus the application_lineage rows (for Replace and
      Consolidate). Single consolidated activity following the Discovery /
      Rationalization pattern — one writer per field.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - architecture/{target_app_id}/architecture-blueprint.json
        - architecture/{target_app_id}/target-application-map.json
      context: [wave_id, target_app_id, source_app_ids]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields:
            - architecture_blueprint_ref
            - architecture_pattern
            - architecture_decided_at
        - target: application_lineage
          fields: [target_app_id, source_app_id, relationship, created_at]
        - target: application
          fields: [id, name, portfolio_id, source_app_ids]
          notes: >
            Only for Replace/Consolidate — new row(s) created here (row
            provisioning happens in target-state-mapping but the DB projection
            is deferred to this step, matching Discovery/Rationalization
            consolidation).
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: validation_failure

  - id: merge-blueprint-pr
    label: Merge Blueprint PR
    kind: git
    scope: per-target-app
    sequence: 19
    progress_pct: 98
    purpose: >
      Final merge of the approved blueprint PR. Wrap-up: updates
      application.current_line to the next line's id (Modernization or
      Disposition Execution depending on disposition), status to
      `awaiting-modernization` / `awaiting-disposition-execution`.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [wave_id, target_app_id, pr_number]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [current_line, current_status, updated_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
```

## Data — `data.yaml` (13 steps)

```yaml
# Data — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Data's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.

name: Data
description: >
  Data designs the target-state data architecture per target application.
  It defines how each target owns its data, how shared databases decompose
  into target-owned stores, how data migrates from legacy to modern, and
  how each target exposes its data as data products for the broader
  enterprise. Data runs in parallel with Architecture for every non-skip
  disposition. Both lines begin after Architecture's target-state-mapping
  emits TargetProvisionedSignal; Data's terminal gate fires
  DataReadyForTargetSignal back to Architecture so its blueprint can
  reference the approved data shape. Data migration planning lives here;
  migration execution lives in Modernization.
trigger: architecture-target-provisioned
# Strict upstream only. Data coordinates with Architecture via signals
# (TargetProvisioned, DataReadyForTarget) — that coordination lives in
# step contracts, not in line-level dependencies. Discovery is reached
# transitively through Rationalization.
depends_on:
  - Rationalization
gates:
  - id: G-DT
    label: Data Architecture Review
mode: per-target-app
inputs:
  - target-application-map
  - catalog-application
  - structural-analysis
  - business-logic
  - wave-plan
  - cloud-pattern
  - integration-arch
outputs:
  - data-domains
  - shared-db-analysis
  - decomposition-strategy
  - co-wave-constraints
  - data-migration-plan
  - data-product-design
  - data-architecture
  - data-architecture-summary

steps:
  - id: wait-for-target-provisioned
    label: Wait for Target Provisioned
    kind: code
    scope: per-target-app
    sequence: 1
    progress_pct: 8
    purpose: >
      Block until Architecture's target-state-mapping emits
      TargetProvisionedSignal for this target_app_id. Captures the
      architecture_workflow_id from the signal so the post-G-DT signal can
      route back to the correct Architecture workflow. Not an agent
      dispatch — pure workflow code (signal wait + id capture).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - architecture/{target_app_id}/target-application-map.json
      context:
        - wave_id
        - target_app_id
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: domain-discovery
    label: Data Domain Discovery
    kind: agent
    scope: per-target-app
    sequence: 2
    progress_pct: 15
    purpose: >
      Identify logical data domains from schema analysis, business capability
      mapping, and entity relationship analysis. Assign every data entity the
      target touches to exactly one domain. Domains follow business capability
      boundaries, not application boundaries — a single domain may span many
      targets; a single target may participate in many domains.
    skills: [data-domain-patterns]
    agent_role: Data Architecture Lead
    inputs:
      artifacts:
        - architecture/{target_app_id}/target-application-map.json
        - discovery/{source_app_id}/catalog-application.json
        - discovery/{source_app_id}/structural-analysis.json
        - rationalization/wave-{wave_id}/{source_app_id}/disposition-recommendation.json
      context:
        - wave_id
        - target_app_id
        - source_app_ids
        - disposition
    outputs:
      artifacts:
        - data/{target_app_id}/data-domains.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: shared-db-analysis
    label: Shared Database Analysis
    kind: agent
    scope: per-target-app
    sequence: 3
    progress_pct: 25
    purpose: >
      Identify this target's participation in any shared database clusters:
      which tables it reads, writes, owns; which other apps share the same
      tables; coupling severity; stored-procedure / trigger / DB-link
      entanglement that creates invisible coupling. Produces the target's
      perspective on the cluster, not a global cluster view (global view is
      synthesized at wave level from all targets' shared-db-analysis outputs).
    skills: [decomposition-patterns]
    agent_role: Data Decomposition Architect
    inputs:
      artifacts:
        - data/{target_app_id}/data-domains.json
        - discovery/{source_app_id}/structural-analysis.json
        - discovery/{source_app_id}/business-logic.json
      context:
        - wave_id
        - target_app_id
        - source_app_ids
    outputs:
      artifacts:
        - data/{target_app_id}/shared-db-analysis.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: decomposition-strategy
    label: Decomposition Strategy
    kind: agent
    scope: per-target-app
    sequence: 4
    progress_pct: 35
    purpose: >
      Select the decoupling approach for each shared-DB cluster the target
      participates in. Whitelisted patterns: database-per-service |
      strangler-fig | db-facade | dedicated | shared-read-only. For each
      cluster, emits the target's role (read | write | owner | both) and the
      pattern. Produces co-wave constraints (must co-wave, must sequence,
      adjacent-wave) that feed observability — the Rationalization feedback
      loop is observational, not automatic.
    skills: [decomposition-patterns]
    agent_role: Data Decomposition Architect
    inputs:
      artifacts:
        - data/{target_app_id}/shared-db-analysis.json
        - data/{target_app_id}/data-domains.json
        - rationalization/wave-{wave_id}/wave-plan.json
      context:
        - wave_id
        - target_app_id
        - disposition
    outputs:
      artifacts:
        - data/{target_app_id}/decomposition-strategy.json
        - data/{target_app_id}/co-wave-constraints.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: migration-planning
    label: Migration Planning
    kind: agent
    scope: per-target-app
    sequence: 5
    progress_pct: 45
    purpose: >
      Design the detailed migration path for each database the target consumes:
      schema transformation rules, data-sync strategy (CDC / dual-write /
      batch / event-driven), cutover strategy (big-bang / rolling /
      blue-green), rollback plan, and executable data-quality validation rules.
      Plans only — Modernization's Generate step executes them. Consumes
      Architecture's cloud-pattern best-effort to pick migration targets
      (e.g., Oracle → Aurora PostgreSQL vs. Oracle → DynamoDB).
    skills: [data-migration-planner]
    agent_role: Data Migration Planner
    inputs:
      artifacts:
        - data/{target_app_id}/decomposition-strategy.json
        - data/{target_app_id}/shared-db-analysis.json
        - architecture/{target_app_id}/cloud-pattern.json
        - architecture/{target_app_id}/integration-arch.json
      context:
        - wave_id
        - target_app_id
        - disposition
    outputs:
      artifacts:
        - data/{target_app_id}/data-migration-plan.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: data-product-design
    label: Data Product Design
    kind: agent
    scope: per-target-app
    sequence: 6
    progress_pct: 55
    purpose: >
      Define the data products this target exposes: formal contracts with
      owner, SLA (availability, latency, freshness), versioned schemas,
      access API, quality guarantees, lineage documentation. Data products
      are the enduring interface through which this target's data is
      consumed by the broader enterprise (data mesh, lake, warehouse, or
      whichever construct the org adopts). Consumes Architecture's
      integration-arch.json best-effort to align API gateway routes.
    skills: [data-product-specification]
    agent_role: Data Product Designer
    inputs:
      artifacts:
        - data/{target_app_id}/data-domains.json
        - data/{target_app_id}/decomposition-strategy.json
        - architecture/{target_app_id}/integration-arch.json
      context:
        - wave_id
        - target_app_id
        - disposition
    outputs:
      artifacts:
        - data/{target_app_id}/data-product-design.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: data-synthesis
    label: Data Architecture Synthesis
    kind: agent
    scope: per-target-app
    sequence: 7
    progress_pct: 65
    summary: true
    purpose: >
      Synthesize every upstream Data artifact (domains, shared-db analysis,
      decomposition strategy, migration plan, data products) plus Architecture
      context (best-effort) into one cohesive data architecture artifact.
      Produces data-architecture.json — authoritative input for Architecture's
      blueprint assembly and Modernization's Generate step — plus a
      human-readable data-architecture-summary.md for G-DT reviewers.
      data-mesh-architecture skill methodology is a reference consideration
      here, not a dispatched skill; data-modeling owns the synthesis.
    skills: [data-modeling]
    agent_role: Data Architecture Lead
    inputs:
      artifacts:
        - data/{target_app_id}/data-domains.json
        - data/{target_app_id}/shared-db-analysis.json
        - data/{target_app_id}/decomposition-strategy.json
        - data/{target_app_id}/data-migration-plan.json
        - data/{target_app_id}/data-product-design.json
        - architecture/{target_app_id}/cloud-pattern.json
        - architecture/{target_app_id}/integration-arch.json
      context:
        - wave_id
        - target_app_id
        - source_app_ids
    outputs:
      artifacts:
        - data/{target_app_id}/data-architecture.json
        - data/{target_app_id}/data-architecture-summary.md
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: commit-data-artifacts
    label: Commit Data Artifacts
    kind: git
    scope: per-target-app
    sequence: 8
    progress_pct: 72
    purpose: >
      Workflow code (not an agent dispatch). Commits every data artifact
      produced in this run to the per-target branch in the artifact repo.
      One commit; commit message references wave_id + target_app_id.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - data/{target_app_id}/*.json
        - data/{target_app_id}/data-architecture-summary.md
      context: [wave_id, target_app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-dt-pr
    label: Create G-DT Review PR
    kind: git
    scope: per-target-app
    sequence: 9
    progress_pct: 78
    purpose: >
      Open the gate-review PR against the artifact repo's main branch. PR body
      aggregates the data-architecture-summary + co-wave constraints callout
      (if any) + data-product catalog preview + links to every upstream
      artifact. Tier-1 PRs explicitly tag data-governance board + security
      officer for stakeholder sign-off.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - data/{target_app_id}/data-architecture.json
        - data/{target_app_id}/data-architecture-summary.md
        - data/{target_app_id}/co-wave-constraints.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: ai-pre-review
    label: AI Pre-Review
    kind: agent
    scope: per-target-app
    sequence: 10
    progress_pct: 82
    purpose: >
      Advisory readiness check before the human gate opens — flags likely
      blocker findings (write-ownership conflicts on shared tables,
      unreversible migration plans, data-product SLAs incoherent with cloud-
      pattern choice, accessibility of data products, quality rules not
      executable) so reviewers and the workflow can short-circuit obvious
      rejections.
    skills: [gate-pre-review]
    agent_role: Gate Pre-Reviewer
    inputs:
      artifacts:
        - data/{target_app_id}/data-architecture.json
        - data/{target_app_id}/data-architecture-summary.md
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts:
        - data/{target_app_id}/pre-review.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
          notes: Persisted so the gate-review UI can surface pre-review findings.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-dt
    label: G-DT Data Architecture Review
    kind: gate
    scope: per-target-app
    sequence: 11
    progress_pct: 88
    purpose: >
      Human review of the data architecture by data-governance board (plus
      security officer for Tier-1). Dual/triple-signal approval model — PM
      merges PR AND stakeholder(s) fire the matching scope signal(s).
      Rejection loops back through the contested steps (up to 3 rework
      iterations before workflow fails).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - data/{target_app_id}/data-architecture.json
        - data/{target_app_id}/data-architecture-summary.md
        - data/{target_app_id}/pre-review.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
        - target: application
          fields:
            - data_architecture_ref
            - data_migration_plan_ref
            - data_pattern
            - data_decided_at
            - data_domains
          notes: >
            Applied via persist_data_side_effects activity after gate
            approval. data_architecture_ref is the committed path of
            data-architecture.json at the merged commit.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: G-DT
    retry_policy:
      category: validation_failure

  - id: persist-data-side-effects
    label: Persist Data Side-Effects
    kind: code
    scope: per-target-app
    sequence: 12
    progress_pct: 94
    purpose: >
      Post-gate projection. Parses the merged data-architecture +
      decomposition-strategy and writes the authoritative data fields onto
      application (target row) plus shared_db_cluster rows (one per cluster
      this target participates in). Single consolidated activity following
      the Discovery / Rationalization / Architecture pattern — one writer
      per field. Fires DataReadyForTargetSignal at the end so Architecture's
      step 5 unblocks.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - data/{target_app_id}/data-architecture.json
        - data/{target_app_id}/decomposition-strategy.json
      context: [wave_id, target_app_id, architecture_workflow_id]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields:
            - data_architecture_ref
            - data_migration_plan_ref
            - data_pattern
            - data_decided_at
            - data_domains
        - target: shared_db_cluster
          fields: [target_app_id, cluster_id, role, pattern, created_at]
          notes: >
            One row per shared-DB cluster this target participates in. role
            enum: read | write | owner | both. pattern enum matches
            application.data_pattern whitelist.
        - signal: DataReadyForTargetSignal
          fields: [target_app_id, data_architecture_ref, data_migration_plan_ref, approved_at]
          target: ArchitectureWorkflow (architecture_workflow_id from Step 0)
          notes: >
            Fired at the end of this step so Architecture's data-architecture
            handshake unblocks. The target architecture_workflow_id was
            captured from TargetProvisionedSignal in Step 0.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: validation_failure

  - id: merge-data-pr
    label: Merge Data PR
    kind: git
    scope: per-target-app
    sequence: 13
    progress_pct: 98
    purpose: >
      Final merge of the approved data PR. Wrap-up: updates
      application.current_line to Architecture (when Architecture is still
      running; Data's merge is usually the gate-blocker, not the wave-exit
      point), status to `data_complete`. Note: Data's terminal step does not
      advance current_line to Modernization — Architecture's G-02 merge is
      the wave-exit for the target.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [wave_id, target_app_id, pr_number]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [data_current_status, updated_at]
          notes: >
            Data-line-specific status tracking; does NOT touch current_line
            (Architecture owns that for the target).
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
```

## Modernization — `modernization.yaml` (33 steps)

```yaml
# Modernization — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Modernization's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.

name: Modernization
description: >
  Modernization transforms a target application's legacy source (or, for
  net-new Replace targets, its specification) into production code and
  tests — committed to the target repo, gated at three points, and ready
  for Validation and Deployment. It is the first line that produces running
  software, not just artifacts about software. The line has three phases:
  Extract (Legacy → Specifications) gated at G-04a; Design (Specifications
  → Architecture detail) gated at G-04b; and Generate (Architecture →
  Working Software) via the per-bounded-context Ralph Loop, gated at G-04c.
  The repo-split rule: everything self-contained about the target
  application lives in the target repo.
trigger: architecture-g02-approved-and-data-g-dt-approved
# Strict upstream only; transitive deps (Rationalization -> Discovery)
# reached via the depends_on graph, not restated here.
depends_on:
  - Architecture
  - Data
gates:
  - id: G-04a
    label: Post-Extract Review
  - id: G-04b
    label: Post-Design Review
  - id: G-04c
    label: Post-Generate Review
mode: per-target-app
inputs:
  - architecture-blueprint
  - target-application-map
  - integration-arch
  - data-architecture
  - data-migration-plan
  - business-logic
  - structural-analysis
  - catalog-application
outputs:
  - pre-processing
  - business-rules
  - test-scenarios
  - user-guide
  - extraction-report
  - traceability-matrix
  - module-map
  - context-map
  - openapi
  - event-contracts
  - api-coverage
  - data-model
  - ddl
  - batch-design
  - design-review
  - generated-application
  - security-posture
  - adversarial-review
  - gate-review-package

steps:
  - id: wait-for-upstream-ready
    label: Wait for Architecture + Data
    kind: code
    scope: per-target-app
    sequence: 1
    progress_pct: 3
    purpose: >
      Block until AppWorkflow (or Wave coordinator) signals
      ``modernization_ready`` — fired only once Architecture's G-02 merge
      lands AND Data's G-DT approval has fired DataReadyForTargetSignal.
      Captures the refs to the upstream artifacts so Extract can feed them
      into the pre-processing activity.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - architecture/{target_app_id}/architecture-blueprint.json
        - architecture/{target_app_id}/target-application-map.json
        - architecture/{target_app_id}/integration-arch.json
        - data/{target_app_id}/data-architecture.json
        - data/{target_app_id}/data-migration-plan.json
      context:
        - wave_id
        - target_app_id
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: ro
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: pre-processing
    label: Pre-Processing
    kind: agent
    scope: per-target-app
    sequence: 2
    progress_pct: 6
    purpose: >
      Dependency analysis, schema extraction, configuration consolidation,
      external interface documentation. Identify candidate bounded contexts
      and integration seams from the architecture blueprint and legacy
      source. Emits the pre-processing report that drives extraction
      fanout decisions.
    skills: [dependency-mapper]
    agent_role: Extraction Lead
    inputs:
      artifacts:
        - architecture/{target_app_id}/architecture-blueprint.json
        - discovery/{source_app_id}/structural-analysis.json
        - discovery/{source_app_id}/catalog-application.json
      context:
        - wave_id
        - target_app_id
        - source_app_ids
        - archetype
        - complexity_tier
    outputs:
      artifacts:
        - modernization/{target_app_id}/extract/pre-processing.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: ro
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: extraction
    label: Extraction
    kind: agent
    scope: per-target-app
    sequence: 3
    progress_pct: 10
    purpose: >
      Three-pass deep dive: (1) comprehensive rule extraction — all
      business rules, validations, calculations, workflows; (2) test
      scenario generation — testable assertions for every rule; (3)
      synthesis and validation — reconcile passes, catch contradictions
      and implicit behaviors. Dispatches the language-appropriate variant
      (extraction-cobol / -java / -python / -coldfusion) selected by the
      agent from the archetype + source tech stack. For batch/ETL
      archetype, dispatches ``batch-extraction`` instead. For user-facing
      archetypes (web-app / hybrid), also dispatches ``ux-flow-derivation``
      and ``ux-page-specification`` to produce the flow inventory and
      per-page specs that downstream Design consumes (Stage 7 ATLAS
      integration, 2026-05-06).
    skills: [extraction, ux-flow-derivation, ux-page-specification]
    agent_role: Business Logic Extractor
    inputs:
      artifacts:
        - modernization/{target_app_id}/extract/pre-processing.json
        - discovery/{source_app_id}/business-logic.json
        - discovery/{source_app_id}/catalog-application.json
      context:
        - wave_id
        - target_app_id
        - archetype
        - tech_stack
        - risk_tier
    outputs:
      artifacts:
        - modernization/{target_app_id}/extract/business-rules.yaml
        - modernization/{target_app_id}/extract/test-scenarios.yaml
        - modernization/{target_app_id}/extract/user-guide.md
        # Stage 7 ATLAS integration (2026-05-06): UX pipeline outputs
        # emitted only for user-facing archetypes (web-app / hybrid).
        - modernization/{target_app_id}/extract/ux-flow-inventory.yaml
        - modernization/{target_app_id}/extract/ux-page-inventory.yaml
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: ro
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: cross-validation
    label: Cross-Validation
    kind: agent
    scope: per-target-app
    sequence: 4
    progress_pct: 14
    purpose: >
      Cross-domain validation ensuring no rule conflicts or gaps. Measures
      coverage (> 95% of source modules represented) and traceability
      (every rule links to source file:line). Emits the validation report
      that G-04a thresholds evaluate.
    skills: [cross-validation]
    agent_role: Cross-Validator
    inputs:
      artifacts:
        - modernization/{target_app_id}/extract/business-rules.yaml
        - modernization/{target_app_id}/extract/test-scenarios.yaml
        - discovery/{source_app_id}/business-logic.json
      context:
        - wave_id
        - target_app_id
        - risk_tier
    outputs:
      artifacts:
        - modernization/{target_app_id}/extract/extraction-report.json
        - modernization/{target_app_id}/extract/traceability-matrix.yaml
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: ro
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: commit-extract-artifacts
    label: Commit Extract Artifacts
    kind: git
    scope: per-target-app
    sequence: 5
    progress_pct: 17
    purpose: >
      Commits every Extract artifact (pre-processing, business rules,
      test scenarios, user guide, extraction report, traceability matrix)
      to the target repo on the per-target branch. One commit; commit
      message references wave_id + target_app_id.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/extract/*.json
        - modernization/{target_app_id}/extract/*.yaml
        - modernization/{target_app_id}/extract/*.md
      context: [wave_id, target_app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-04a-pr
    label: Create G-04a Review PR
    kind: git
    scope: per-target-app
    sequence: 6
    progress_pct: 20
    purpose: >
      Open the Extract gate-review PR against the target repo's main
      branch. PR body aggregates the extraction report + traceability
      matrix summary + Tier-1 SME tag (if applicable). Links to every
      Extract artifact.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/extract/extraction-report.json
        - modernization/{target_app_id}/extract/traceability-matrix.yaml
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: extract-pre-review
    label: Extract AI Pre-Review
    kind: agent
    scope: per-target-app
    sequence: 7
    progress_pct: 22
    purpose: >
      Advisory readiness check before G-04a human review opens — flags
      likely blocker findings (traceability below threshold, TBDs
      present, contradictory rules, coverage gaps) so reviewers and
      the workflow can short-circuit obvious rejections.
    skills: [gate-pre-review]
    agent_role: Gate Pre-Reviewer
    inputs:
      artifacts:
        - modernization/{target_app_id}/extract/extraction-report.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts:
        - modernization/{target_app_id}/extract/pre-review.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
          notes: >
            Persisted to the artifact repo (gate_pre_review table); the
            findings JSON body duplicates into the target repo for
            traceability from the PR.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-04a
    label: G-04a Post-Extract Review
    kind: gate
    scope: per-target-app
    sequence: 8
    progress_pct: 25
    purpose: >
      Human review of the extracted specifications by Tech Lead (PM) +
      SME (Tier-1). Single-signal model for PM (SME signal recommended
      for Tier-2, required for Tier-1 via StakeholderApprovedSignal
      scope="g-04a-sme"). Rejection loops back through Extract steps
      (up to 3 rework iterations).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/extract/extraction-report.json
        - modernization/{target_app_id}/extract/traceability-matrix.yaml
        - modernization/{target_app_id}/extract/pre-review.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
        - target: application
          fields:
            - extraction_ref
            - extraction_at
            - bounded_contexts
          notes: >
            Applied via persist_modernization_side_effects activity after
            gate approval. extraction_ref is the committed path of
            extraction-report.json at the merged commit.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: G-04a
    retry_policy:
      category: validation_failure

  - id: persist-extract-side-effects
    label: Persist Extract Side-Effects
    kind: code
    scope: per-target-app
    sequence: 9
    progress_pct: 28
    purpose: >
      Post-gate projection. Parses the extraction report and writes
      application.extraction_ref, extraction_at, and bounded_contexts
      (JSONB array of identified BC names the Design step will use for
      fanout). First of three per-gate projections in this line.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/extract/extraction-report.json
      context: [wave_id, target_app_id]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields:
            - extraction_ref
            - extraction_at
            - bounded_contexts
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: ro
    parallel_with: []
    gate: null
    retry_policy:
      category: validation_failure

  - id: merge-extract-pr
    label: Merge Extract PR
    kind: git
    scope: per-target-app
    sequence: 10
    progress_pct: 31
    purpose: >
      Final merge of the approved G-04a PR. Updates
      application.current_step to the first Design step; current_line
      stays Modernization.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [wave_id, target_app_id, pr_number]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [current_step, updated_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: domain-modeling
    label: Domain Modeling
    kind: agent
    scope: per-target-app
    sequence: 11
    progress_pct: 34
    purpose: >
      Define modular architecture boundaries using DDD. Identify bounded
      contexts, aggregate roots, domain events, and context maps from the
      extracted business rules + Architecture blueprint. Emits the module
      map that drives per-BC fanout in Generate. For user-facing archetypes,
      also dispatches ``ux-component-specification`` to produce typed
      component contracts (profile-sanctioned design system mapping + ARIA/
      keyboard/focus specs) that tdd-generation and code-generation-*
      variants consume (Stage 7 ATLAS integration, 2026-05-06).
    skills: [module-design, ux-component-specification]
    agent_role: Design Lead
    inputs:
      artifacts:
        - modernization/{target_app_id}/extract/business-rules.yaml
        - modernization/{target_app_id}/extract/test-scenarios.yaml
        - modernization/{target_app_id}/extract/ux-page-inventory.yaml
        - architecture/{target_app_id}/architecture-blueprint.json
        - data/{target_app_id}/data-architecture.json
      context: [wave_id, target_app_id, archetype, complexity_tier]
    outputs:
      artifacts:
        - modernization/{target_app_id}/design/module-map.yaml
        - modernization/{target_app_id}/design/context-map.md
        # Stage 7 ATLAS integration (2026-05-06): UX component inventory
        # emitted only for user-facing archetypes.
        - modernization/{target_app_id}/design/ux-component-inventory.yaml
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: ro
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: api-design
    label: API Design
    kind: agent
    scope: per-target-app
    sequence: 12
    progress_pct: 37
    purpose: >
      Generate complete OpenAPI 3.0 specifications per bounded context.
      Define API contracts between contexts, including anti-corruption
      layers where legacy integration is needed. Include coverage table
      mapping every business operation to an API endpoint.
    skills: [api-specification, event-contract]
    agent_role: API Designer
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/module-map.yaml
        - architecture/{target_app_id}/integration-arch.json
        - modernization/{target_app_id}/extract/business-rules.yaml
      context: [wave_id, target_app_id]
    outputs:
      artifacts:
        - modernization/{target_app_id}/design/openapi.yaml
        - modernization/{target_app_id}/design/event-contracts.yaml
        - modernization/{target_app_id}/design/api-coverage.md
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: ro
        target: rw
    parallel_with: [data-model-design]
    gate: null
    retry_policy:
      category: agent_failure

  - id: data-model-design
    label: Data Model Design
    kind: agent
    scope: per-target-app
    sequence: 13
    progress_pct: 40
    purpose: >
      Design modern entity-relationship diagrams, indexing strategies
      within each bounded context. Align with Data line's schema
      transformation plans and target data stores. Runs in parallel with
      API design.
    skills: [data-modeling]
    agent_role: Data Modeler
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/module-map.yaml
        - data/{target_app_id}/data-architecture.json
        - data/{target_app_id}/data-migration-plan.json
      context: [wave_id, target_app_id]
    outputs:
      artifacts:
        - modernization/{target_app_id}/design/data-model.yaml
        - modernization/{target_app_id}/design/ddl.sql
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: [api-design]
    gate: null
    retry_policy:
      category: agent_failure

  - id: batch-design
    label: Batch Design
    kind: agent
    scope: per-target-app
    sequence: 14
    progress_pct: 43
    purpose: >
      Batch / ETL target architecture — Step Functions state machines,
      EventBridge rules, Lambda handler contracts. Runs only when
      archetype includes batch/scheduled. Skipped for pure web-app / API
      targets.
    skills: [batch-design]
    agent_role: Batch Architect
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/module-map.yaml
        - modernization/{target_app_id}/extract/business-rules.yaml
      context: [wave_id, target_app_id, archetype]
    outputs:
      artifacts:
        - modernization/{target_app_id}/design/batch-design.yaml
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: traceability-audit
    label: Traceability Audit
    kind: agent
    scope: per-target-app
    sequence: 15
    progress_pct: 46
    purpose: >
      Verify every Extract business rule maps to a Design element
      (module / API / data model). Emits design-review.json with
      forward-traceability metrics that G-04b thresholds evaluate. Also
      checks journey preservation against Discovery Pass 4 outputs.
    skills: [traceability-audit]
    agent_role: Design Lead
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/module-map.yaml
        - modernization/{target_app_id}/design/openapi.yaml
        - modernization/{target_app_id}/design/data-model.yaml
        - modernization/{target_app_id}/extract/business-rules.yaml
        - discovery/{source_app_id}/ux-accessibility.json
      context: [wave_id, target_app_id]
    outputs:
      artifacts:
        - modernization/{target_app_id}/design/design-review.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: ro
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: commit-design-artifacts
    label: Commit Design Artifacts
    kind: git
    scope: per-target-app
    sequence: 16
    progress_pct: 49
    purpose: >
      Commits every Design artifact (module-map, openapi, data-model,
      ddl, batch-design if present, design-review, context-map) to the
      target repo on the per-target branch. Single commit.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/*.yaml
        - modernization/{target_app_id}/design/*.json
        - modernization/{target_app_id}/design/*.md
        - modernization/{target_app_id}/design/*.sql
      context: [wave_id, target_app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-04b-pr
    label: Create G-04b Review PR
    kind: git
    scope: per-target-app
    sequence: 17
    progress_pct: 51
    purpose: >
      Open the Design gate-review PR against the target repo main branch.
      PR body aggregates design-review summary, forward-traceability
      percentage, DDD alignment callouts, journey-preservation status.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/design-review.json
      context: [wave_id, target_app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: design-pre-review
    label: Design AI Pre-Review
    kind: agent
    scope: per-target-app
    sequence: 18
    progress_pct: 54
    summary: true
    purpose: >
      Advisory readiness check before G-04b human review — flags likely
      blocker findings (forward-traceability below threshold, DDD
      misalignment, missing journey preservation, EA drift from
      Architecture blueprint).
    skills: [gate-pre-review]
    agent_role: Gate Pre-Reviewer
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/design-review.json
      context: [wave_id, target_app_id]
    outputs:
      artifacts:
        - modernization/{target_app_id}/design/pre-review.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-04b
    label: G-04b Post-Design Review
    kind: gate
    scope: per-target-app
    sequence: 19
    progress_pct: 57
    purpose: >
      Human review of the design by Tech Lead (PM) + Architecture Lead.
      Single PM signal for merge; Architecture Lead review expressed via
      PR comments only (no signal wait). Rejection loops back through
      Design steps (up to 3 rework iterations).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/design-review.json
        - modernization/{target_app_id}/design/pre-review.json
      context: [wave_id, target_app_id]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
        - target: application
          fields:
            - design_ref
            - design_at
            - modernization_pattern
          notes: >
            Applied via persist_modernization_side_effects after G-04b
            approval. modernization_pattern is the whitelisted
            decomposition approach (monolith-lift | microservices-
            decompose | bc-per-service | hybrid).
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: G-04b
    retry_policy:
      category: validation_failure

  - id: persist-design-side-effects
    label: Persist Design Side-Effects
    kind: code
    scope: per-target-app
    sequence: 20
    progress_pct: 60
    purpose: >
      Post-G-04b projection. Writes application.design_ref, design_at,
      modernization_pattern. The bounded_contexts array from step 9 is
      refined here — Design may collapse or split BCs from Extract's
      initial list.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/module-map.yaml
        - modernization/{target_app_id}/design/design-review.json
      context: [wave_id, target_app_id]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields:
            - design_ref
            - design_at
            - modernization_pattern
            - bounded_contexts
        - target: bounded_context
          fields: [target_app_id, bc_name, status, created_at]
          notes: >
            One row per BC in module-map.yaml. status starts at
            ``design-complete`` and transitions through ``generate-active``
            / ``generate-complete`` / ``escalated`` as Generate runs.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: ro
    parallel_with: []
    gate: null
    retry_policy:
      category: validation_failure

  - id: merge-design-pr
    label: Merge Design PR
    kind: git
    scope: per-target-app
    sequence: 21
    progress_pct: 62
    purpose: >
      Final merge of the approved G-04b PR. Advances
      application.current_step to the Generate phase.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [wave_id, target_app_id, pr_number]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [current_step, updated_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: bc-fanout
    label: BC Fanout
    kind: code
    scope: per-target-app
    sequence: 22
    progress_pct: 65
    purpose: >
      Workflow code (not an agent dispatch). Reads the approved
      module-map.yaml and fans out one child ``GenerateBCWorkflow`` per
      bounded context, up to ``MAX_BC_CHILDREN_PER_APP`` (default 5,
      configurable; emits warning if module-map has more BCs than the
      cap — extra BCs queue and run after earlier children complete).
      ``asyncio.gather`` awaits all children.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/module-map.yaml
      context: [wave_id, target_app_id, MAX_BC_CHILDREN_PER_APP]
    outputs:
      artifacts: []
      side_effects:
        - target: bounded_context
          fields: [status]
          notes: Transition to ``generate-active`` per BC on spawn.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: generate-bc-ralph-loop
    label: Ralph Loop (per BC)
    kind: code
    scope: per-target-app
    sequence: 23
    progress_pct: 70
    purpose: >
      Child workflow per bounded context. Implements the Ralph Loop:
      (1) tdd-generation writes tests from specs; (2) a code-generation
      variant (resolved at dispatch time by the
      ``code_generation_router`` from the blueprint's target_framework /
      target_frontend / primary_language) writes code to pass tests;
      (3) test-validation runs the tests; (4) loop until green or
      MAX_RALPH_ITERATIONS (default 10) hit. On exhaustion, dispatches
      escalation-handler and waits for an EscalationResolvedSignal with
      one of four outcomes: ``re-extract`` | ``manual-augment`` |
      ``re-disposition`` | ``abandon``. Emits per-BC generated source
      files committed to target_repo on a BC-scoped branch.

      Stage 3 ATLAS integration (2026-05-06): the ``code-generation``
      skill now has seven target-framework-keyed variants (see
      ``cross-cutting/skills/registry.yaml`` under
      ``- id: code-generation``). The Ralph Loop dispatches exactly one
      per iteration; the ``skills:`` list below enumerates every
      candidate because any of them may fire based on runtime routing.
    skills:
      - tdd-generation
      - code-generation
      - code-generation-springboot
      - code-generation-dotnet
      - code-generation-fastapi
      - code-generation-node
      - code-generation-react
      - code-generation-cobol-to-java
      - code-generation-natural-to-springboot
      - test-validation
      - escalation-handler
    agent_role: Ralph Loop Controller
    inputs:
      artifacts:
        - modernization/{target_app_id}/design/module-map.yaml
        - modernization/{target_app_id}/design/openapi.yaml
        - modernization/{target_app_id}/design/data-model.yaml
        - modernization/{target_app_id}/extract/test-scenarios.yaml
      context: [wave_id, target_app_id, bc_name, archetype]
    outputs:
      artifacts:
        - modernization/{target_app_id}/generate/{bc_name}/src/**
        - modernization/{target_app_id}/generate/{bc_name}/tests/**
        - modernization/{target_app_id}/generate/{bc_name}/ralph-metrics.json
      side_effects:
        - target: bounded_context
          fields: [status, ralph_iterations, escalations, generated_path]
          notes: >
            status transitions to ``generate-complete`` on green or
            ``escalated`` on exhaustion. ralph_iterations records the
            loop count; escalations captures the escalation-handler
            outcome plus resolution type when applicable.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: ro
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: code-synthesis
    label: Code Synthesis
    kind: agent
    scope: per-target-app
    sequence: 24
    progress_pct: 76
    purpose: >
      Merge per-BC generated code into a coherent, buildable application
      codebase. Resolves cross-context concerns: shared authentication,
      API gateway routes, event bus wiring, shared utility modules,
      unified build configuration. Runs after every BC Ralph Loop has
      reached green or explicitly escalated. For Simple complexity with
      a single BC, synthesis is a no-op pass-through.
    skills: [code-synthesis]
    agent_role: Synthesis Agent
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/{bc_name}/**
        - modernization/{target_app_id}/design/module-map.yaml
        - modernization/{target_app_id}/design/openapi.yaml
      context: [wave_id, target_app_id]
    outputs:
      artifacts:
        - modernization/{target_app_id}/generate/application/**
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: security-posture-review
    label: Security-Posture Review
    kind: agent
    scope: per-target-app
    sequence: 25
    progress_pct: 79
    purpose: >
      Reviews the synthesized code for intentional security posture
      adherence — authN/authZ implementation matches the approved
      architecture's security pattern, secrets handling, input
      validation coverage, defense-in-depth layering. Distinct from
      ``security-scan-review`` (Validation line): that skill triages
      CI/CD scanner output; this skill reasons about security design
      intent inside the generated code. Emits findings as a posture
      report for G-04c evidence.
    skills: [security-posture-review]
    agent_role: Security Reviewer
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/application/**
        - architecture/{target_app_id}/security-arch.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts:
        - modernization/{target_app_id}/generate/security-posture.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: [adversarial-review]
    gate: null
    retry_policy:
      category: agent_failure

  - id: adversarial-review
    label: Adversarial Review
    kind: agent
    scope: per-target-app
    sequence: 26
    progress_pct: 82
    purpose: >
      Adversarial code review before Ralph Loop results are packaged
      for the gate. Looks for code smells, anti-patterns, brittle
      edge-case handling, missing error paths. Distinct from
      test-validation (correctness) and security-posture-review
      (security design). Runs in parallel with security-posture-review.
    skills: [adversarial-review]
    agent_role: Adversarial Reviewer
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/application/**
      context: [wave_id, target_app_id]
    outputs:
      artifacts:
        - modernization/{target_app_id}/generate/adversarial-review.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: [security-posture-review]
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-package
    label: Gate Review Package
    kind: agent
    scope: per-target-app
    sequence: 27
    progress_pct: 85
    purpose: >
      Assemble the G-04c gate submission package — test coverage
      summary (by layer), Ralph Loop iteration histogram, per-BC
      escalation roll-up, structure-vs-design conformance report,
      security posture summary, adversarial review summary. Produces
      the `gate-review-package.json` artifact that reviewers consume.
    skills: [gate-review-package]
    agent_role: Gate Pre-Reviewer
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/application/**
        - modernization/{target_app_id}/generate/{bc_name}/ralph-metrics.json
        - modernization/{target_app_id}/generate/security-posture.json
        - modernization/{target_app_id}/generate/adversarial-review.json
      context: [wave_id, target_app_id]
    outputs:
      artifacts:
        - modernization/{target_app_id}/generate/gate-review-package.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: commit-generate-artifacts
    label: Commit Generate Artifacts
    kind: git
    scope: per-target-app
    sequence: 28
    progress_pct: 88
    purpose: >
      Commits all synthesis + review + package artifacts to the target
      repo main branch (per-BC branches were committed inside the child
      workflows).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/application/**
        - modernization/{target_app_id}/generate/**.json
      context: [wave_id, target_app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-04c-pr
    label: Create G-04c Review PR
    kind: git
    scope: per-target-app
    sequence: 29
    progress_pct: 90
    purpose: >
      Open the Generate gate-review PR against the target repo main.
      PR body aggregates gate-review-package (coverage, Ralph metrics,
      security posture summary, adversarial review summary). Tier-1
      PRs tag EA board + security officer for stakeholder sign-off.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/gate-review-package.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: generate-pre-review
    label: Generate AI Pre-Review
    kind: agent
    scope: per-target-app
    sequence: 30
    progress_pct: 92
    purpose: >
      Advisory readiness check before G-04c human review — flags likely
      blocker findings (coverage below threshold, critical security
      posture findings, critical adversarial findings, structure drift
      from Design).
    skills: [gate-pre-review]
    agent_role: Gate Pre-Reviewer
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/gate-review-package.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts:
        - modernization/{target_app_id}/generate/pre-review.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-04c
    label: G-04c Post-Generate Review
    kind: gate
    scope: per-target-app
    sequence: 31
    progress_pct: 94
    purpose: >
      Human review of the generated code. Dual/triple-signal model —
      PM merges PR (`gate_approved`) AND for Tier-1 both
      `StakeholderApprovedSignal(scope="g-04c-ea")` (EA adherence) AND
      `scope="g-04c-security"` (security review). Rejection loops back
      through Generate steps (up to 3 rework iterations).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/gate-review-package.json
        - modernization/{target_app_id}/generate/pre-review.json
      context: [wave_id, target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
        - target: application
          fields:
            - generated_module_refs
            - generate_at
          notes: >
            Applied via persist_modernization_side_effects after G-04c
            approval. generated_module_refs is a JSONB array of
            per-BC committed paths.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: G-04c
    retry_policy:
      category: validation_failure

  - id: persist-generate-side-effects
    label: Persist Generate Side-Effects + Signals
    kind: code
    scope: per-target-app
    sequence: 32
    progress_pct: 97
    purpose: >
      Post-G-04c projection. Writes application.generated_module_refs,
      generate_at, finalizes bounded_context rows (status =
      generate-complete for green BCs, retains escalated for escaped
      ones), and fires handoff signals:
      - ``ModernizationReadySignal`` to ValidationWorkflow for this target
      - ``ModernizationCodeReadySignal`` to DeploymentWorkflow (Deployment
        starts staging environment provisioning in parallel with
        Validation).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/gate-review-package.json
      context: [wave_id, target_app_id, validation_workflow_id, deployment_workflow_id]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields:
            - generated_module_refs
            - generate_at
            - modernization_current_status
        - target: bounded_context
          fields: [status, ralph_iterations, escalations, generated_path]
          notes: Per-BC terminal state finalization.
        - signal: ModernizationReadySignal
          fields: [target_app_id, generated_module_refs, approved_at]
          target: ValidationWorkflow (captured via peer_workflow_ids)
        - signal: ModernizationCodeReadySignal
          fields: [target_app_id, target_repo_url, approved_at]
          target: DeploymentWorkflow (captured via peer_workflow_ids)
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: ro
    parallel_with: []
    gate: null
    retry_policy:
      category: validation_failure

  - id: merge-generate-pr
    label: Merge Generate PR
    kind: git
    scope: per-target-app
    sequence: 33
    progress_pct: 99
    purpose: >
      Final merge of the approved G-04c PR. Advances
      application.current_line to Validation (or Deployment for apps
      skipping Validation — rare). application.modernization_current_status
      set to ``modernization_complete``.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [wave_id, target_app_id, pr_number]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [current_line, current_status, modernization_current_status, updated_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
```

## Build — `build.yaml` (15 steps)

```yaml
# Build — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for the Build line's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.
#
# Build is the third downstream execution line (alongside Modernization and
# Disposition Execution). It is selected by the `Build` disposition. Discovery,
# Rationalization, Architecture, and Data are reused wholesale; only the
# implementation line is new. Build replaces Modernization's legacy-Extract
# step with a `spec-from-requirements` step that consumes the requirements/
# capability artifact, then reuses Modernization's source-agnostic Design
# (module-design / api-specification / data-modeling / traceability-audit) and
# Generate (Ralph Loop: tdd-generation / code-synthesis / adversarial-review /
# security-scan-review) skills unchanged. Escalation path is "Refine Spec",
# not "Re-Extract" — there is no legacy code to re-read.
#
# Design: specifications/phase-6/greenfield-build-line.md §7 (P6-S5.7, P6-S5.9, P6-S5.10).

name: Build
description: >
  Spec-driven new construction. Transforms a validated requirements/capability
  artifact into working, tested, compliant code through a three-step pipeline —
  Spec-from-Requirements → Design → Generate — with quality gates at each
  transition (G-NEW-1/2/3, equivalents of Modernization's G-04a/b/c). No legacy
  source is required; the requirements artifact's acceptance criteria are the
  validation oracle. Runs within portfolio waves alongside Modernization work,
  reusing Modernization's source-agnostic Design and Generate skills.
trigger: architecture-g02-approved-and-data-g-dt-approved
# Strict upstream only; transitive deps (Architecture -> Rationalization ->
# Discovery) are reached via the depends_on graph, not restated here.
depends_on:
  - Architecture
  - Rationalization
gates:
  - id: G-NEW-1
    label: Spec Review
  - id: G-NEW-2
    label: Design Review
  - id: G-NEW-3
    label: Code & Test Review
mode: per-app
inputs:
  - requirements-capability
  - architecture-blueprint
  - data-models
  - rationalization-outputs
outputs:
  - scenario-spec
  - module-map
  - openapi-specs
  - er-diagrams
  - source-code
  - test-suites
  - coverage-report
  - 508-audit-report
  - security-scan-report
  - compliance-artifacts

steps:
  # -------------------------------------------------------------------------
  # Step 1 — Spec-from-Requirements (Build-path equivalent of Extract; G-NEW-1)
  # -------------------------------------------------------------------------
  - id: spec-from-requirements
    label: Spec-from-Requirements
    kind: agent
    scope: per-app
    sequence: 1
    progress_pct: 8
    purpose: >
      Convert the requirements/capability artifact (plus Architecture and Data
      outputs) into validated, implementation-ready business-rule specs and
      scenario specs. The Build-path equivalent of Modernization's Extract step.
      The source of business rules is requirements-capability FR-xxx items with
      acceptance criteria, not legacy code — traceability is FR-xxx ->
      interview:{question-id} or FR-xxx -> doc:{section}. Output feeds Step 2
      Design via the same contracts Design already consumes from Modernization.
    skills: [spec-from-requirements]
    agent_role: olympus-agent
    inputs:
      artifacts:
        - build/{app_id}/requirements/requirements-capability.json
        - architecture/{app_id}/architecture-blueprint.json
        - data/{app_id}/data-architecture.json
      context:
        - wave_id
        - app_id
        - risk_tier
        - complexity_tier
        - archetype
    outputs:
      artifacts:
        - build/{app_id}/specs/scenario-spec.json
        - build/{app_id}/specs/business-rules-catalog.yaml
        - build/{app_id}/specs/traceability-matrix.md
      side_effects:
        - target: application
          fields:
            - build.spec_rule_count
            - build.spec_scenario_count
            - build.spec_coverage_pct
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: commit-spec-artifacts
    label: Commit Spec Artifacts
    kind: git
    scope: per-app
    sequence: 2
    progress_pct: 12
    purpose: >
      Commit every Spec artifact (scenario-spec, business-rules-catalog,
      traceability-matrix) to the artifact repo on the per-app branch. One
      commit; message references wave_id + app_id.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - build/{app_id}/specs/*.json
        - build/{app_id}/specs/*.yaml
        - build/{app_id}/specs/*.md
      context: [wave_id, app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-new-1-pr
    label: Create G-NEW-1 Review PR
    kind: git
    scope: per-app
    sequence: 3
    progress_pct: 15
    purpose: >
      Open the Spec gate-review PR. PR body aggregates the scenario coverage
      summary, requirement traceability, and any spec-from-requirements
      escalation flags. Tier-1 apps tag the stakeholder for sign-off.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - build/{app_id}/specs/scenario-spec.json
        - build/{app_id}/specs/traceability-matrix.md
      context: [wave_id, app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: spec-gate-readiness-check
    label: Spec AI Gate Readiness Check
    kind: agent
    scope: per-app
    sequence: 4
    progress_pct: 17
    role: pre-review
    purpose: >
      Advisory readiness check before G-NEW-1 human review opens — flags likely
      blocker findings (must-have capability coverage below 100%, requirement
      coverage below 95%, unresolved escalation flags, contradictory business
      rules) so reviewers and the workflow can short-circuit obvious rejections.
      Single-attempt; do not delay human review.
    skills: [gate-pre-review]
    agent_role: olympus-agent
    inputs:
      artifacts:
        - build/{app_id}/specs/scenario-spec.json
      context: [wave_id, app_id, risk_tier]
    outputs:
      artifacts:
        - build/{app_id}/specs/pre-review.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      max_attempts_override: 1

  - id: gate-review-new-1
    label: G-NEW-1 Spec Review
    kind: gate
    scope: per-app
    sequence: 5
    progress_pct: 20
    purpose: >
      Human review of the derived specs by Tech Lead (PM) + stakeholder (Tier-1).
      Equivalent rigor to G-04a. Single PM signal for merge; stakeholder sign-off
      required for Tier-1 (StakeholderApprovedSignal scope="g-new-1-stakeholder").
      Rejection triggers the "Refine Spec" escalation path — the requirements
      artifact is returned to the stakeholder with structured feedback, re-
      elicited, and Step 1 re-runs (up to 3 rework iterations). This is distinct
      from Modernization's "Re-Extract" path; there is no legacy code to re-read.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - build/{app_id}/specs/scenario-spec.json
        - build/{app_id}/specs/traceability-matrix.md
        - build/{app_id}/specs/pre-review.json
      context: [wave_id, app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
        - target: application
          fields:
            - build.spec_ref
            - build.spec_gate_status
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: G-NEW-1
    retry_policy:
      category: validation_failure

  # -------------------------------------------------------------------------
  # Step 2 — Design (direct reuse of Modernization Design skills; G-NEW-2)
  # -------------------------------------------------------------------------
  - id: design
    label: Design
    kind: agent
    scope: per-app
    sequence: 6
    progress_pct: 40
    purpose: >
      Transform validated scenario specs and business rules into a DDD
      architecture design. Direct reuse of Modernization Step 2 — the skills
      (module-design, api-specification, data-modeling, traceability-audit) are
      source-agnostic and consume the same artifact schemas regardless of
      whether inputs came from legacy extraction or requirements elicitation.
      Because Step 1's business-rules-catalog and scenario-spec conform to the
      same schemas as Modernization Step 1 outputs, this step receives identical
      input shapes regardless of path.
    skills:
      - module-design
      - api-specification
      - data-modeling
      - traceability-audit
    agent_role: olympus-agent
    inputs:
      artifacts:
        - build/{app_id}/specs/scenario-spec.json
        - build/{app_id}/specs/business-rules-catalog.yaml
        - build/{app_id}/specs/traceability-matrix.md
        - architecture/{app_id}/architecture-blueprint.json
        - data/{app_id}/data-architecture.json
      context: [wave_id, app_id, archetype, complexity_tier]
    outputs:
      artifacts:
        - build/{app_id}/design/module-map.yaml
        - build/{app_id}/design/openapi.yaml
        - build/{app_id}/design/data-model.yaml
        - build/{app_id}/design/compliance-map.md
        - build/{app_id}/design/context-map.md
        - build/{app_id}/design/design-review.json
      side_effects:
        - target: application
          fields:
            - build.contexts_count
            - build.api_endpoints_count
            - build.design_traceability_pct
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError]

  - id: commit-design-artifacts
    label: Commit Design Artifacts
    kind: git
    scope: per-app
    sequence: 7
    progress_pct: 44
    purpose: Commit every Design artifact to the artifact repo. Single commit.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - build/{app_id}/design/*.yaml
        - build/{app_id}/design/*.json
        - build/{app_id}/design/*.md
      context: [wave_id, app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-new-2-pr
    label: Create G-NEW-2 Review PR
    kind: git
    scope: per-app
    sequence: 8
    progress_pct: 46
    purpose: >
      Open the Design gate-review PR. PR body aggregates the design-review
      summary, forward-traceability percentage, DDD alignment callouts, and
      accessibility/security coverage.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - build/{app_id}/design/design-review.json
      context: [wave_id, app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: design-gate-readiness-check
    label: Design AI Gate Readiness Check
    kind: agent
    scope: per-app
    sequence: 9
    progress_pct: 48
    role: pre-review
    summary: true
    purpose: >
      Advisory readiness check before G-NEW-2 human review — flags likely
      blocker findings (forward-traceability below threshold, DDD misalignment,
      missing accessibility/security contracts, EA drift from the Architecture
      blueprint). Single-attempt.
    skills: [gate-pre-review]
    agent_role: olympus-agent
    inputs:
      artifacts:
        - build/{app_id}/design/design-review.json
      context: [wave_id, app_id]
    outputs:
      artifacts:
        - build/{app_id}/design/pre-review.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      max_attempts_override: 1

  - id: gate-review-new-2
    label: G-NEW-2 Design Review
    kind: gate
    scope: per-app
    sequence: 10
    progress_pct: 52
    purpose: >
      Human review of the design by Tech Lead (PM) + Architecture Lead.
      Equivalent rigor to G-04b. Single PM signal for merge; Architecture Lead
      review expressed via PR comments. Rejection loops back through Design (up
      to 3 rework iterations).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - build/{app_id}/design/design-review.json
        - build/{app_id}/design/pre-review.json
      context: [wave_id, app_id]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
        - target: application
          fields:
            - build.design_ref
            - build.design_gate_status
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: G-NEW-2
    retry_policy:
      category: validation_failure

  # -------------------------------------------------------------------------
  # Step 3 — Generate (direct reuse of Modernization Ralph Loop; G-NEW-3)
  # -------------------------------------------------------------------------
  - id: generate
    label: Generate
    kind: agent
    scope: per-app
    sequence: 11
    progress_pct: 80
    purpose: >
      Test-driven code generation from approved design specs. Direct reuse of
      Modernization Step 3 (Ralph Loop TDD cycle). The scenario-spec — derived
      from the requirements artifact's acceptance criteria — is the test oracle.
      Fans out per bounded context exactly as Modernization does. Escalation
      path is "Refine Spec" rather than "Re-Extract": if the Ralph Loop cannot
      converge on a module, the spec needs clarification, not legacy re-reading.
      Other escalation outcomes: "Manual Augment" (genuinely complex edge cases)
      and "Re-Disposition" (return to Rationalization). There is no "Re-Extract".
    skills:
      - tdd-generation
      - code-synthesis
      - adversarial-review
      - security-scan-review
      - escalation-handler
    agent_role: olympus-agent
    inputs:
      artifacts:
        - build/{app_id}/design/module-map.yaml
        - build/{app_id}/design/openapi.yaml
        - build/{app_id}/design/data-model.yaml
        - build/{app_id}/specs/scenario-spec.json
        - build/{app_id}/design/compliance-map.md
      context: [wave_id, app_id, archetype, complexity_tier]
    outputs:
      artifacts:
        - build/{app_id}/src/**
        - build/{app_id}/tests/**
        - build/{app_id}/generate/coverage-report.json
        - build/{app_id}/generate/508-audit-report.json
        - build/{app_id}/generate/security-scan-report.json
        - build/{app_id}/compliance/**
        - build/{app_id}/metrics/ralph-loop-metrics.yaml
        - build/{app_id}/specs/traceability-matrix.md
      side_effects:
        - target: application
          fields:
            - build.test_coverage_pct
            - build.ralph_loop_iterations
            - build.ralph_loop_escalations
            - build.generate_status
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      non_retryable_errors: [SchemaValidationError, RalphLoopMaxEscalationsError]

  - id: commit-generate-artifacts
    label: Commit Generate Artifacts
    kind: git
    scope: per-app
    sequence: 12
    progress_pct: 88
    purpose: >
      Commit generated source, tests, coverage, accessibility, security, and
      compliance artifacts to the target repo on the per-app branch.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - build/{app_id}/src/**
        - build/{app_id}/tests/**
        - build/{app_id}/generate/**
      context: [wave_id, app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-new-3-pr
    label: Create G-NEW-3 Review PR
    kind: git
    scope: per-app
    sequence: 13
    progress_pct: 90
    purpose: >
      Open the Generate gate-review PR against the target repo main. PR body
      aggregates the coverage report, acceptance-criteria coverage, accessibility
      and security scan summaries, structure-vs-design conformance, and Ralph
      Loop metrics. Tier-1 PRs tag EA board + security officer.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - build/{app_id}/generate/coverage-report.json
        - build/{app_id}/metrics/ralph-loop-metrics.yaml
      context: [wave_id, app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: generate-gate-readiness-check
    label: Generate AI Gate Readiness Check
    kind: agent
    scope: per-app
    sequence: 14
    progress_pct: 92
    role: pre-review
    purpose: >
      Advisory readiness check before G-NEW-3 human review — flags likely
      blocker findings (coverage below threshold, P1 scenarios without automated
      tests, critical accessibility/security findings, structure drift from the
      Step 2 module map). Single-attempt.
    skills: [gate-pre-review]
    agent_role: olympus-agent
    inputs:
      artifacts:
        - build/{app_id}/generate/coverage-report.json
        - build/{app_id}/generate/security-scan-report.json
      context: [wave_id, app_id, risk_tier]
    outputs:
      artifacts:
        - build/{app_id}/generate/pre-review.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
      max_attempts_override: 1

  - id: gate-review-new-3
    label: G-NEW-3 Code & Test Review
    kind: gate
    scope: per-app
    sequence: 15
    progress_pct: 96
    purpose: >
      Human review of the generated code. Equivalent rigor to G-04c. Dual/triple-
      signal model — PM merges the PR (gate_approved) AND for Tier-1 both
      StakeholderApprovedSignal(scope="g-new-3-ea") (EA adherence) AND
      scope="g-new-3-security" (security review). Rejection loops back through
      Generate (Refine Spec / Manual Augment / Re-Disposition; never Re-Extract),
      up to 3 rework iterations.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - build/{app_id}/generate/coverage-report.json
        - build/{app_id}/generate/pre-review.json
      context: [wave_id, app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
        - target: application
          fields:
            - build.generated_module_refs
            - build.generate_gate_status
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: G-NEW-3
    retry_policy:
      category: validation_failure
```

## Validation — `validation.yaml` (20 steps)

```yaml
# Validation — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Validation's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.

name: Validation
description: >
  Validation is the quality firewall between Modernization and Deployment.
  It independently verifies the modernized code is correct, compliant, and
  — for Tier-1 applications — safe, across four parallel streams:
  Functional Parity, Security & Compliance, Accessibility & UX, and (Tier-1
  only) Safety Assurance. Streams run in parallel; gates run serially. The
  three always-on streams (Parity, Security, Accessibility) fan out together
  after Validation opens; their outputs feed G-V1 (Parity) and G-V2
  (Security + Accessibility rolled up). Tier-1 then runs the Safety stream
  and G-V3 sequentially. Validation does not modify code — if findings
  exceed thresholds the rework loop kicks back to Modernization.
trigger: modernization-g-04c-approved-with-generate-artifacts
# Strict upstream only; Architecture/Data/Discovery reached transitively.
depends_on:
  - Modernization
gates:
  - id: G-V1
    label: Functional Parity
  - id: G-V2
    label: Compliance & Security
  - id: G-V3
    label: Safety Assurance
mode: per-app
inputs:
  - gate-review-package
  - architecture-blueprint
  - data-architecture
  - accessibility-review
  - security-arch
  - cato-evidence-seed
  - data-migration-plan
  - ux-accessibility
  - quality-risk
  - structural-analysis
  - business-logic
  - integration-arch
  - design-system
outputs:
  - parity-report
  - api-contract-report
  - external-consumer-compat
  - acceptable-divergences
  - security-assessment-report
  - ssp
  - poam
  - authorization-recommendation
  - accessibility-audit
  - design-system-compliance
  - uat-results
  - training-package
  - g-v1-evidence
  - g-v2-evidence
  - safety-case
  - ivnv-results
  - traceability-report
  - safety-impact-assessment
  - g-v3-evidence
  # Stage 9 ATLAS integration (2026-05-06)
  - test-plan
  - remediation-plan
  - compliance-gap-matrix

steps:
  - id: intake
    label: Validation Intake
    kind: code
    scope: per-app
    sequence: 1
    progress_pct: 5
    purpose: >
      Workflow code (not an agent dispatch). Resolves the target app's
      disposition, risk tier, and input artifact refs; sets
      application.current_line to "Validation" and current_step to
      "intake"; initialises the per-stream state objects.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - modernization/{target_app_id}/gate-review-package-g-04c.json
        - architecture/{target_app_id}/architecture-blueprint.json
        - data/{target_app_id}/data-architecture.json
      context: [target_app_id, portfolio_id, risk_tier, disposition]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [current_line, current_step, updated_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: ro
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  # Stage 9 ATLAS integration (2026-05-06): formal-test-plan-generator
  # authors the IEEE-829 / ISO-29119 formal test plan document ahead
  # of the three parallel Validation streams so auditors and T1 gate
  # reviewers have a signed, traceable test plan in the G-V1 evidence
  # packet. Mandatory for T1 and T2 (before G-V1); T3 receives a
  # lightweight smoke-test-only plan so Deployment reviewers still
  # have a signed document in the package. Authoring only — does not
  # run tests; test-validation + parity-verifier produce the results
  # the plan's §9 Test Deliverables cites.
  - id: formal-test-plan-authoring
    label: Formal Test Plan Authoring
    kind: agent
    scope: per-app
    sequence: 2
    progress_pct: 8
    purpose: >
      Author the reviewer-ready formal test plan document
      (test-plan.md) per IEEE-829 / ISO 29119 canonical structure.
      Synthesizes the extracted business rules catalog, the target
      architecture blueprint, the application's risk tier, and the
      selected disposition into the fourteen-section test plan.
      Required ahead of G-V1 for T1/T2 apps; T3 produces the smoke-
      test-only variant so Deployment reviewers still have a signed
      document in the package.
    skills: [formal-test-plan-generator]
    agent_role: Validation Lead (Test Plan Author)
    inputs:
      artifacts:
        - discovery/{source_app_id}/business-logic.json
        - architecture/{target_app_id}/architecture-blueprint.json
        - discovery/{source_app_id}/catalog-application.json
      context: [target_app_id, source_app_ids, risk_tier, disposition]
    outputs:
      artifacts:
        - validation/{target_app_id}/test-plan.md
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: ro
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: functional-parity
    label: Functional Parity Verification
    kind: agent
    scope: per-app
    sequence: 3
    progress_pct: 15
    purpose: >
      Compare modernized behaviour to the legacy baseline (or the
      approved target spec for Replace/Rearchitect). Runs the generated
      test suite, compares API contracts, verifies external-consumer
      compatibility, and computes the parity score. Emits the
      parity-report artifact G-V1 evidence references.
    skills: [parity-verifier, acceptable-divergences]
    agent_role: Parity Verification Agent
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/*/
        - discovery/{source_app_id}/structural-analysis.json
        - discovery/{source_app_id}/business-logic.json
        - architecture/{target_app_id}/integration-arch.json
      context: [target_app_id, source_app_ids, disposition, risk_tier]
    outputs:
      artifacts:
        - validation/{target_app_id}/parity-report.json
        - validation/{target_app_id}/api-contract-report.json
        - validation/{target_app_id}/external-consumer-compat.json
        - validation/{target_app_id}/acceptable-divergences.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: ro
        target: rw
    parallel_with: [security-compliance, accessibility-ux]
    gate: null
    retry_policy:
      category: agent_failure

  - id: security-compliance
    label: Security & Compliance Assessment
    kind: agent
    scope: per-app
    sequence: 4
    progress_pct: 20
    purpose: >
      Triage CI/CD scanner output (SAST / SCA / container / IaC findings),
      classify vulnerabilities, compile the SSP / SAR / POA&M package,
      and validate cATO evidence completeness. Zero critical vulns is
      the absolute threshold; the skill emits the authorization
      recommendation in client-profile format (default OSCAL).
    skills: [security-scan-review, cato-evidence-validator]
    agent_role: Security & Compliance Agent
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/*/
        - architecture/{target_app_id}/security-arch.json
        - architecture/{target_app_id}/cato-evidence-seed.json
      context: [target_app_id, risk_tier, compliance_baseline]
    outputs:
      artifacts:
        - validation/{target_app_id}/security-assessment-report.json
        - validation/{target_app_id}/ssp.json
        - validation/{target_app_id}/poam.json
        - validation/{target_app_id}/authorization-recommendation.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: none
        target: rw
    parallel_with: [functional-parity, accessibility-ux]
    gate: null
    retry_policy:
      category: agent_failure

  - id: accessibility-ux
    label: Accessibility & UX Audit
    kind: agent
    scope: per-app
    sequence: 5
    progress_pct: 25
    purpose: >
      Automated WCAG 2.1 AA + Section 508 audit against the modernized
      code, design-system compliance check, UAT result packaging, and
      training / change-communication package assembly. Distinct from
      Architecture-stage accessibility-reviewer (design-time commitment);
      this stream audits the actual shipped UI.
    skills: [accessibility-checker, design-system]
    agent_role: Accessibility Auditor
    inputs:
      artifacts:
        - modernization/{target_app_id}/generate/*/
        - architecture/{target_app_id}/accessibility-review.json
        - architecture/{target_app_id}/design-system.json
        - discovery/{source_app_id}/ux-accessibility.json
      context: [target_app_id, source_app_ids, risk_tier]
    outputs:
      artifacts:
        - validation/{target_app_id}/accessibility-audit.json
        - validation/{target_app_id}/design-system-compliance.json
        - validation/{target_app_id}/uat-results.json
        - validation/{target_app_id}/training-package.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: ro
        target: rw
    parallel_with: [functional-parity, security-compliance]
    gate: null
    retry_policy:
      category: agent_failure

  # Stage 9 ATLAS integration (2026-05-06): security-anomaly-resolution
  # consumes the triaged findings emitted by security-scan-review (run
  # inside security-compliance at seq 4), runs the anomaly-detection
  # pass (George SRS methodology), maps findings to OWASP Top 10 and
  # the active profile's compliance controls, prioritizes via composite
  # risk score, and emits a remediation plan with effort estimates,
  # compliance gap matrix, and gate-ready evidence. Runs ahead of
  # G-V2 (the compliance gate) so remediation evidence is attached to
  # the G-V2 bundle. Runs sequentially after security-compliance —
  # anomaly resolution requires the triaged finding list.
  - id: security-anomaly-resolution
    label: Security Anomaly Resolution
    kind: agent
    scope: per-app
    sequence: 6
    progress_pct: 30
    purpose: >
      Downstream of security-scan-review: consume the triaged finding
      list plus anomaly-detection results, map every item to OWASP
      Top 10 and the active profile's compliance controls, prioritize
      via composite risk score, and emit a remediation plan with
      effort estimates, before/after code samples, a compliance gap
      matrix, and gate-ready evidence artifacts. Authored output
      feeds the G-V2 evidence bundle.
    skills: [security-anomaly-resolution]
    agent_role: Security Anomaly Resolver
    inputs:
      artifacts:
        - validation/{target_app_id}/security-assessment-report.json
        - architecture/{target_app_id}/security-arch.json
        - architecture/{target_app_id}/cato-evidence-seed.json
        - discovery/{source_app_id}/structural-analysis.json
      context: [target_app_id, risk_tier, compliance_baseline]
    outputs:
      artifacts:
        - validation/{target_app_id}/remediation-plan.json
        - validation/{target_app_id}/compliance-gap-matrix.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: ro
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: bundle-g-v1-evidence
    label: Bundle G-V1 Parity Evidence
    kind: code
    scope: per-app
    sequence: 7
    progress_pct: 32
    purpose: >
      Workflow code. Waits for the Parity stream to complete (via
      asyncio.gather), synthesises the G-V1 evidence bundle
      (parity-report + api-contract + external-consumer-compat +
      acceptable-divergences + formal test-plan.md), computes the
      pass/fail verdict against the tier-adjusted threshold, and
      commits the bundle for G-V1 review.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/parity-report.json
        - validation/{target_app_id}/api-contract-report.json
        - validation/{target_app_id}/external-consumer-compat.json
        - validation/{target_app_id}/acceptable-divergences.json
        # Stage 9 ATLAS integration (2026-05-06): formal test plan
        # authored in seq 2 is part of the G-V1 evidence packet.
        - validation/{target_app_id}/test-plan.md
      context: [target_app_id, risk_tier]
    outputs:
      artifacts:
        - validation/{target_app_id}/g-v1-evidence.json
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-v1-pr
    label: Create G-V1 Review PR
    kind: git
    scope: per-app
    sequence: 8
    progress_pct: 36
    purpose: >
      Open the gate-review PR against target_repo main. PR body carries
      the parity verdict + divergence list + test-suite summary; tags
      PM for the acknowledgement merge (G-V1 is automated pass/fail — PM
      merges to acknowledge, does not re-evaluate).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/g-v1-evidence.json
      context: [target_app_id, portfolio_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: gate-review-v1
    label: G-V1 Functional Parity
    kind: gate
    scope: per-app
    sequence: 9
    progress_pct: 40
    purpose: >
      Automated pass/fail. If parity >= threshold and no test-suite
      failures: PM merges PR and the workflow advances to G-V2. If
      parity < threshold: workflow auto-rejects and routes contested
      findings back to Modernization (rework iteration bump). Parity
      threshold is tier-adjusted: Tier-1 >= 99%, Tier-2 >= 98%, Tier-3
      >= 95%.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/g-v1-evidence.json
      context: [target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: G-V1
    retry_policy:
      category: validation_failure

  - id: bundle-g-v2-evidence
    label: Bundle G-V2 Compliance Evidence
    kind: code
    scope: per-app
    sequence: 10
    progress_pct: 45
    purpose: >
      Synthesises the G-V2 evidence bundle: security assessment + SSP +
      POA&M + cATO evidence + accessibility audit + design-system
      compliance + UAT results + remediation plan + compliance gap
      matrix. Computes the vuln-classification roll-up (must have zero
      critical). Commits the bundle.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/security-assessment-report.json
        - validation/{target_app_id}/ssp.json
        - validation/{target_app_id}/poam.json
        - validation/{target_app_id}/authorization-recommendation.json
        - validation/{target_app_id}/accessibility-audit.json
        - validation/{target_app_id}/design-system-compliance.json
        - validation/{target_app_id}/uat-results.json
        - validation/{target_app_id}/training-package.json
        # Stage 9 ATLAS integration (2026-05-06): remediation plan +
        # compliance gap matrix emitted by security-anomaly-resolution
        # (seq 6) are part of the G-V2 evidence packet.
        - validation/{target_app_id}/remediation-plan.json
        - validation/{target_app_id}/compliance-gap-matrix.json
      context: [target_app_id, risk_tier, compliance_baseline]
    outputs:
      artifacts:
        - validation/{target_app_id}/g-v2-evidence.json
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-v2-pr
    label: Create G-V2 Review PR
    kind: git
    scope: per-app
    sequence: 11
    progress_pct: 48
    purpose: >
      Open the G-V2 gate-review PR. Body aggregates the security + cATO
      + accessibility evidence + roll-up verdict. Tier-1 PRs tag the
      compliance lead + security officer for stakeholder sign-off.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/g-v2-evidence.json
      context: [target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: ai-pre-review-v2
    label: AI Pre-Review (G-V2)
    kind: agent
    scope: per-app
    sequence: 12
    progress_pct: 52
    purpose: >
      Advisory readiness check before G-V2 opens — flags likely blocker
      findings (critical vulns still present, SSP gaps, accessibility
      barriers above threshold, incomplete POA&M). Reviewers can short-
      circuit obvious rejections.
    skills: [gate-pre-review]
    agent_role: Gate Pre-Reviewer
    inputs:
      artifacts:
        - validation/{target_app_id}/g-v2-evidence.json
      context: [target_app_id, risk_tier]
    outputs:
      artifacts:
        - validation/{target_app_id}/pre-review-v2.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-v2
    label: G-V2 Compliance & Security
    kind: gate
    scope: per-app
    sequence: 13
    progress_pct: 56
    purpose: >
      Human review of the compliance + security + accessibility bundle.
      Tier-1 triple-signal: PM merges PR AND compliance lead
      (scope="g-v2-compliance") AND security officer
      (scope="g-v2-security") all fire stakeholder_approved. Tier-2/3
      single-signal (PM only). Rejection routes contested findings back
      to Modernization (rework iteration bump). Zero critical vulns is
      the hard floor — rejection is automatic when present.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/g-v2-evidence.json
        - validation/{target_app_id}/pre-review-v2.json
      context: [target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: G-V2
    retry_policy:
      category: validation_failure

  - id: safety-assurance
    label: Safety Assurance
    kind: agent
    scope: per-app
    sequence: 14
    progress_pct: 62
    purpose: >
      Tier-1 only. Runs IV&V (independent verification & validation),
      traceability verification (requirement → test coverage must be
      >= 99%), safety case updates, and safety impact assessment. Only
      runs after G-V1 + G-V2 approve — the safety case references the
      parity + compliance evidence those gates produced.
    skills: [safety-critical-verifier, traceability-checker]
    agent_role: Safety Assurance Agent
    inputs:
      artifacts:
        - validation/{target_app_id}/g-v1-evidence.json
        - validation/{target_app_id}/g-v2-evidence.json
        - architecture/{target_app_id}/security-arch.json
      context: [target_app_id, risk_tier]
    outputs:
      artifacts:
        - validation/{target_app_id}/safety-case.json
        - validation/{target_app_id}/ivnv-results.json
        - validation/{target_app_id}/traceability-report.json
        - validation/{target_app_id}/safety-impact-assessment.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: bundle-g-v3-evidence
    label: Bundle G-V3 Safety Evidence
    kind: code
    scope: per-app
    sequence: 15
    progress_pct: 68
    purpose: >
      Synthesises the G-V3 evidence bundle for safety board review.
      Combines safety case + IV&V + traceability + impact assessment.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/safety-case.json
        - validation/{target_app_id}/ivnv-results.json
        - validation/{target_app_id}/traceability-report.json
        - validation/{target_app_id}/safety-impact-assessment.json
      context: [target_app_id]
    outputs:
      artifacts:
        - validation/{target_app_id}/g-v3-evidence.json
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-v3-pr
    label: Create G-V3 Review PR
    kind: git
    scope: per-app
    sequence: 16
    progress_pct: 72
    purpose: >
      Open the G-V3 gate-review PR. Body aggregates the safety case +
      IV&V + traceability verdict. Tags safety board + certifying
      authority.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/g-v3-evidence.json
      context: [target_app_id]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: ai-pre-review-v3
    label: AI Pre-Review (G-V3)
    kind: agent
    scope: per-app
    sequence: 17
    progress_pct: 76
    purpose: >
      Advisory readiness check before G-V3. Flags likely safety-board
      blockers (traceability < 99%, IV&V gaps, safety case missing
      hazard analysis).
    skills: [gate-pre-review]
    agent_role: Gate Pre-Reviewer
    inputs:
      artifacts:
        - validation/{target_app_id}/g-v3-evidence.json
      context: [target_app_id]
    outputs:
      artifacts:
        - validation/{target_app_id}/pre-review-v3.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-v3
    label: G-V3 Safety Assurance
    kind: gate
    scope: per-app
    sequence: 18
    progress_pct: 82
    purpose: >
      Safety board review of the safety case. Tier-1 triple-signal: PM
      merges PR AND safety board chair (scope="g-v3-safety") AND
      certifying authority (scope="g-v3-cert") fire
      stakeholder_approved. Rejection routes safety-case gaps back to
      Architecture (safety-arch re-design) or traceability gaps back to
      Modernization.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/g-v3-evidence.json
        - validation/{target_app_id}/pre-review-v3.json
      context: [target_app_id]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: G-V3
    retry_policy:
      category: validation_failure

  - id: persist-validation-side-effects
    label: Persist Validation Side-Effects
    kind: code
    scope: per-app
    sequence: 19
    progress_pct: 90
    purpose: >
      Post-gate projection. Parses the merged G-V1 / G-V2 (+ G-V3 for
      Tier-1) evidence bundles and writes the authoritative validation
      fields onto application. Single consolidated activity following
      the Discovery / Rationalization pattern — one writer per field.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/g-v1-evidence.json
        - validation/{target_app_id}/g-v2-evidence.json
        - validation/{target_app_id}/g-v3-evidence.json
      context: [target_app_id, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields:
            - validation_parity_score
            - validation_critical_vuln_count
            - validation_accessibility_score
            - validation_safety_case_ref
            - validation_completed_at
            - validation_current_status
          notes: >
            validation_current_status enum: validation_in_progress →
            validation_parity_approved → validation_compliance_approved →
            validation_complete (all gates merged) OR validation_failed
            (rework exhausted). validation_safety_case_ref is NULL for
            Tier-2/Tier-3 by design.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: ro
    parallel_with: []
    gate: null
    retry_policy:
      category: validation_failure

  - id: merge-final-gate-pr
    label: Merge Final Gate PR
    kind: git
    scope: per-app
    sequence: 20
    progress_pct: 98
    purpose: >
      Final merge of the last approved gate PR (G-V2 for Tier-2/Tier-3,
      G-V3 for Tier-1). Emits ValidationApprovedSignal to Deployment so
      it can proceed with environment provisioning + deploy execution.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [target_app_id, portfolio_id, pr_number, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [current_line, current_status, updated_at]
        - signal: ValidationApprovedSignal
          fields:
            - target_app_id
            - portfolio_id
            - validation_output_refs
            - approved_at
          target: DeploymentWorkflow
          notes: >
            Signal shape is new in this contract. Deployment reads the
            signal's validation_output_refs to compile its cATO package.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
```

## Disposition Execution — `disposition-execution.yaml` (13 steps)

```yaml
# Disposition Execution — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Disposition Execution's steps, skills,
# artifacts, side-effects, and agent contract. Every downstream consumer
# (Temporal workflow, Olympus API gate service, step-progress mapping,
# frontend step registry) loads FROM this file via
# olympus_contracts.assembly_lines. Do not hardcode a copy in application
# code. Drift is policed by the `test_no_hardcoded_step_lists` CI check.

name: Disposition Execution
description: >
  Disposition Execution executes the five non-modernization dispositions
  Rationalization decided on: Retire, Retain, Replace, Replatform, and
  Consolidate. Refactor and Rearchitect flow through Architecture →
  Modernization → Validation → Deployment; this line owns everything else.
  Each non-modernization disposition is a project in its own right —
  Retire is a data-archival project with user-transition, consumer-
  migration, infrastructure decommission, license reclamation, and cost-
  savings certification; Replace means vendor evaluation + integration
  specification + cutover; Consolidate means target selection + feature
  gap analysis + enhancement planning + data reconciliation. Produces the
  canonical disposition-output bundle that Deployment, Sustainment, and
  Governance all consume as the authoritative "what did this app become?"
  record.
trigger: rationalization-g-da-approved-non-modernization
depends_on:
  - Rationalization
gates:
  - id: G-DE-1
    label: Disposition Execution Plan Approval
  - id: G-DE-2
    label: Decommission Readiness Sign-off
mode: per-app
inputs:
  - disposition-recommendation
  - disposition-governance
  - catalog-application
  - structural-analysis
  - business-logic
  - ux-accessibility
  - tco-baseline
outputs:
  - disposition-output

steps:
  - id: pre-gate-strategy
    label: Pre-Gate Strategy Steps
    kind: agent
    scope: per-app
    sequence: 1
    progress_pct: 12
    purpose: >
      Per-disposition strategy work. Produces an artifact under
      dispositions/{portfolio_id}/{app_id}/{step-id}.json that the
      G-DE-1 evidence bundle aggregates.
    skills: []
    agent_role: Disposition Execution Agent
    inputs:
      artifacts:
        - discovery/{app_id}/catalog-application.json
        - discovery/{app_id}/business-logic.json
        - discovery/{app_id}/tco-baseline.json
        - rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json
      context: [app_id, wave_id, portfolio_id, disposition]
    outputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/{step-id}.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: bundle-pre-gate-evidence
    label: Bundle Pre-Gate Evidence
    kind: code
    scope: per-app
    sequence: 2
    progress_pct: 25
    purpose: >
      Workflow code (not an agent dispatch). Synthesises the per-step
      artifacts from pre-gate steps into disposition-output.json (partial
      shape — fields corresponding to pre-gate steps populated, post-gate
      fields left as ``null`` or empty arrays). Commits the bundle for
      G-DE-1 evidence.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/*.json
      context: [app_id, portfolio_id, disposition]
    outputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-de1-pr
    label: Create G-DE-1 Review PR
    kind: git
    scope: per-app
    sequence: 3
    progress_pct: 30
    purpose: >
      Open the gate-review PR against the artifact repo's main branch. PR
      body aggregates the disposition-output bundle (pre-gate subset) + a
      per-disposition summary tailored to reviewers (Retire checklist,
      Retain risk profile, Replace vendor comparison, etc.).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
      context: [app_id, portfolio_id, disposition]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: ai-pre-review-de1
    label: AI Pre-Review (G-DE-1)
    kind: agent
    scope: per-app
    sequence: 4
    progress_pct: 35
    purpose: >
      Advisory readiness check before the human gate opens — flags likely
      blocker findings (missing plan components, stale dependencies,
      unaddressed user-impact risks, cost-savings estimate missing baseline)
      so reviewers and the workflow can short-circuit obvious rejections.
    skills: [gate-pre-review]
    agent_role: Gate Pre-Reviewer
    inputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
      context: [app_id, portfolio_id, disposition, risk_tier]
    outputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/pre-review-de1.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-de1
    label: G-DE-1 Disposition Execution Plan Approval
    kind: gate
    scope: per-app
    sequence: 5
    progress_pct: 42
    purpose: >
      Human review of the disposition execution plan. Single-signal
      approval model (PM merges PR). Rejection loops back through the
      contested pre-gate steps (up to 3 rework iterations before workflow
      escalates).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
        - dispositions/{portfolio_id}/{app_id}/pre-review-de1.json
      context: [app_id, portfolio_id, disposition, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: G-DE-1
    retry_policy:
      category: validation_failure

  - id: merge-g-de1-pr
    label: Merge G-DE-1 Review PR
    kind: git
    scope: per-app
    sequence: 6
    progress_pct: 48
    purpose: >
      Final merge of the approved G-DE-1 PR. Plan is locked; the workflow
      proceeds to execution (post-gate steps) for all dispositions except
      Retain.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [app_id, portfolio_id, pr_number]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [current_step, current_status, updated_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: post-gate-execution
    label: Post-Gate Execution Steps
    kind: agent
    scope: per-app
    sequence: 7
    progress_pct: 60
    purpose: >
      Per-disposition execution work — carries out the plan approved at
      G-DE-1. Produces an artifact the G-DE-2 decommission-readiness
      bundle aggregates.
    skills: []
    agent_role: Disposition Execution Agent
    inputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
        - discovery/{app_id}/*.json
      context: [app_id, wave_id, portfolio_id, disposition]
    outputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/{step-id}.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: ro
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: bundle-post-gate-evidence
    label: Bundle Decommission-Readiness Evidence
    kind: code
    scope: per-app
    sequence: 8
    progress_pct: 72
    summary: true
    purpose: >
      Updates disposition-output.json to the complete shape: merges post-
      gate artifact refs + decommission certificates + cost savings
      certification + approvals array (G-DE-1 record) into the bundle.
      Commits the finalized bundle for G-DE-2 evidence.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/*.json
      context: [app_id, portfolio_id, disposition]
    outputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-de2-pr
    label: Create G-DE-2 Review PR
    kind: git
    scope: per-app
    sequence: 9
    progress_pct: 78
    purpose: >
      Open the G-DE-2 gate-review PR. Body aggregates the finalized
      disposition-output bundle with decommission evidence + cost savings
      + user-migration attestations. Only runs for non-Retain dispositions.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
      context: [app_id, portfolio_id, disposition]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: ai-pre-review-de2
    label: AI Pre-Review (G-DE-2)
    kind: agent
    scope: per-app
    sequence: 10
    progress_pct: 82
    purpose: >
      Advisory readiness check before the decommission-readiness gate —
      flags data-archival gaps, missing user-migration attestation, infra
      still running, license-reclamation incomplete. Only runs for non-
      Retain dispositions.
    skills: [gate-pre-review]
    agent_role: Gate Pre-Reviewer
    inputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
      context: [app_id, portfolio_id, disposition, risk_tier]
    outputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/pre-review-de2.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_id, findings_json]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-de2
    label: G-DE-2 Decommission Readiness Sign-off
    kind: gate
    scope: per-app
    sequence: 11
    progress_pct: 88
    purpose: >
      Human review of decommission readiness. Single-signal approval (PM
      merges PR). Only runs for non-Retain dispositions. Rejection loops
      back through the contested post-gate steps (up to 3 rework
      iterations). Approval authorizes Deployment to execute the
      infrastructure teardown.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
        - dispositions/{portfolio_id}/{app_id}/pre-review-de2.json
      context: [app_id, portfolio_id, disposition, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_id, status, approved_by, approved_at]
        - target: application
          fields: [disposition_output_ref, disposition_completed_at]
          notes: >
            Applied via persist_disposition_side_effects activity after
            gate approval. disposition_output_ref is the committed path
            of disposition-output.json at the merged commit.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: G-DE-2
    retry_policy:
      category: validation_failure

  - id: persist-disposition-side-effects
    label: Persist Disposition Side-Effects
    kind: code
    scope: per-app
    sequence: 12
    progress_pct: 94
    purpose: >
      Post-gate projection. Parses the merged disposition-output.json and
      writes the authoritative disposition fields onto application.
      Single consolidated activity following the Discovery / Rationalization
      pattern — one writer per field. Runs after G-DE-2 for non-Retain
      dispositions; runs after G-DE-1 for Retain (which has no G-DE-2).
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
      context: [app_id, portfolio_id, disposition]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields:
            - disposition_output_ref
            - disposition_completed_at
            - disposition_current_status
            - cost_savings_annual_usd
          notes: >
            disposition_current_status enum: ``disposition_in_progress``
            (set at workflow start), ``disposition_plan_approved`` (post-
            G-DE-1), ``disposition_complete`` (post-G-DE-2 approved, or
            post-G-DE-1 for Retain), ``disposition_failed`` (rework
            exhausted). cost_savings_annual_usd is populated from the
            bundle's cost_savings_cert payload when present.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: validation_failure

  - id: merge-g-de2-pr
    label: Merge G-DE-2 Review PR
    kind: git
    scope: per-app
    sequence: 13
    progress_pct: 98
    purpose: >
      Final merge of the approved G-DE-2 PR. For Replace/Replatform/
      Consolidate: signals Deployment to execute infrastructure teardown
      of the legacy app. For Retire: signals Deployment for decommission
      execution. Retain skips this step (no G-DE-2).
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [app_id, portfolio_id, pr_number, disposition]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [current_line, current_status, updated_at]
        - signal: DispositionExecutedSignal
          fields:
            - app_id
            - disposition
            - disposition_output_ref
            - portfolio_id
          target: DeploymentWorkflow (when disposition ∈ {Retire, Replace, Replatform, Consolidate})
          notes: >
            Signal shape is new in this contract. Retain does not emit —
            Retain registers with Sustainment via the sustainment-handoff
            skill's output artifact ref, not via a signal.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
```

## Deployment — `deployment.yaml` (18 steps)

```yaml
# Deployment — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Deployment's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.

name: Deployment
description: >
  Deployment is the irreversible bridge between validated / dispositioned
  applications and production operation. It owns five responsibilities:
  deploy the modernized application (or execute the disposition teardown
  plan); shift traffic via API-gateway weighted routing; monitor parallel
  run where legacy and modern operate simultaneously; verify user adoption
  against Discovery-captured baselines; and decommission the legacy
  infrastructure and certify realized cost savings. Traffic shift is
  reversible; decommission is not. Deployment is the one line that consumes
  from both upstream tracks — the Modernization path (Refactor/Rearchitect
  via Validation) and the non-modernization path (Retire/Replace/Replatform/
  Consolidate via Disposition Execution). Retain dispositions skip
  Deployment entirely.
trigger: validation-approved-or-disposition-executed
# Strict upstream only. Deployment sits at the confluence of the
# modernization track (Validation) and the non-mod track (Disposition
# Execution). Upstream transitive deps are not restated here.
depends_on:
  - Validation
  - Disposition Execution
gates:
  - id: G-DP-1
    label: Cutover Go
  - id: G-DP-2
    label: Deployment Complete
mode: per-app
inputs:
  - parity-report
  - authorization-recommendation
  - disposition-output
  - deployment-topology
  - rollback-plan
  - tco-baseline
  - adoption-baseline
  - data-migration-plan
outputs:
  - deployment-manifest
  - smoke-test-results
  - traffic-shift-log
  - parallel-run-report
  - adoption-verification
  - gate-review-package-g-dp1
  - decommission-certificate
  - license-reclamation-record
  - cost-savings-certification
  - gate-review-package-g-dp2

steps:
  - id: intake
    label: Deployment Intake
    kind: code
    scope: per-app
    sequence: 1
    progress_pct: 5
    purpose: >
      Workflow code (not an agent dispatch). Resolves the app's
      disposition from the triggering signal, loads disposition-output
      bundle (non-modernization path) or Validation evidence
      (modernization path), selects the active path, initialises
      per-step state, and sets application.current_line = "Deployment"
      and current_step = "intake".
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - validation/{target_app_id}/parity-report.json
        - validation/{target_app_id}/authorization-recommendation.json
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
        - architecture/{target_app_id}/deployment-topology.json
        - architecture/{target_app_id}/rollback-plan.json
        - discovery/{source_app_id}/tco-baseline.json
        - discovery/{source_app_id}/adoption-baseline.json
      context: [app_id, target_app_id, portfolio_id, risk_tier, disposition]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [current_line, current_step, updated_at]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: ro
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: orchestration
    label: Deployment Orchestration
    kind: agent
    scope: per-app
    sequence: 2
    progress_pct: 12
    purpose: >
      Deploy the modernized application to production using the
      tier-appropriate strategy (canary for Tier-1, blue-green for
      Tier-2/3). Runs pre-deploy verification (all Validation gates
      passed, authorization approved, environment provisioned, rollback
      tested), executes the deploy itself, runs smoke tests across
      critical paths, activates production monitoring, and registers
      data products in the API gateway + data catalog. Emits the
      deployment-manifest.json artifact with strategy, target env,
      route config, smoke test results, rollback verification status.
    skills: [deploy-modernized-app, monitoring-bootstrap]
    agent_role: Deployment Orchestrator
    inputs:
      artifacts:
        - validation/{target_app_id}/authorization-recommendation.json
        - architecture/{target_app_id}/deployment-topology.json
      context: [target_app_id, portfolio_id, risk_tier, disposition, strategy]
    outputs:
      artifacts:
        - deployment/{target_app_id}/deployment-manifest.json
        - deployment/{target_app_id}/smoke-test-results.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: traffic-shifting
    label: Traffic Shifting
    kind: agent
    scope: per-app
    sequence: 3
    progress_pct: 20
    purpose: >
      Gradually migrate user traffic from legacy to modern via API
      gateway weighted routing. Follows the tier-driven schedule:
      Tier-1 canary 5%→25%→50%→100% over 14 days; Tier-2 instant
      blue-green with 24h validation; Tier-3 instant blue-green with 4h
      validation. Monitors error thresholds at each increment; auto-
      reverts on breach. Emits the traffic-shift-log.json artifact.
    skills: [traffic-shift]
    agent_role: Traffic Shift Controller
    inputs:
      artifacts:
        - deployment/{target_app_id}/deployment-manifest.json
      context: [target_app_id, portfolio_id, risk_tier, shift_schedule]
    outputs:
      artifacts:
        - deployment/{target_app_id}/traffic-shift-log.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: parallel-run
    label: Parallel Run
    kind: agent
    scope: per-app
    sequence: 4
    progress_pct: 30
    purpose: >
      Legacy and modern operate simultaneously for the tier-minimum
      duration (Tier-1: 90 days; Tier-2: 30 days; Tier-3: 14 days).
      Continuous parity comparison at defined comparison points (API
      responses, batch outputs, data writes) with divergence
      classification (regression / expected / environmental). Daily
      reports summarize divergence rate + trend. Workflow-level
      Temporal timer collapses under time-skipping tests. Emits the
      parallel-run-report.json artifact (daily + final).
    skills: [parallel-run-monitor]
    agent_role: Parallel Run Monitor
    inputs:
      artifacts:
        - deployment/{target_app_id}/traffic-shift-log.json
        - validation/{target_app_id}/parity-report.json
      context: [target_app_id, portfolio_id, risk_tier, parallel_run_days]
    outputs:
      artifacts:
        - deployment/{target_app_id}/parallel-run-report.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: timeout

  - id: adoption-verification
    label: Adoption Verification
    kind: agent
    scope: per-app
    sequence: 5
    progress_pct: 40
    purpose: >
      Verify users are actually using the modernized application.
      Tracks active-user ratio vs. Discovery baseline, feature-usage
      pattern consistency, training completion rate, support ticket
      trend, and critical user-reported issues. Populates G-DP-1
      evidence thresholds. Emits the adoption-verification.json
      artifact with each metric + threshold status.
    skills: [adoption-analytics, user-adoption-coordinator]
    agent_role: Adoption Tracker
    inputs:
      artifacts:
        - deployment/{target_app_id}/parallel-run-report.json
        - discovery/{source_app_id}/adoption-baseline.json
      context: [target_app_id, portfolio_id, risk_tier, adoption_thresholds]
    outputs:
      artifacts:
        - deployment/{target_app_id}/adoption-verification.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: bundle-g-dp1-evidence
    label: Bundle G-DP-1 Evidence
    kind: code
    scope: per-app
    sequence: 6
    progress_pct: 46
    purpose: >
      Workflow code. Synthesises deployment-manifest, smoke-test,
      traffic-shift-log, parallel-run-report, adoption-verification
      into the G-DP-1 evidence bundle; commits to target_repo for PR.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - deployment/{target_app_id}/deployment-manifest.json
        - deployment/{target_app_id}/smoke-test-results.json
        - deployment/{target_app_id}/traffic-shift-log.json
        - deployment/{target_app_id}/parallel-run-report.json
        - deployment/{target_app_id}/adoption-verification.json
      context: [target_app_id, portfolio_id]
    outputs:
      artifacts:
        - deployment/{target_app_id}/gate-review-package-g-dp1.json
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-dp1-pr
    label: Create G-DP-1 PR
    kind: git
    scope: per-app
    sequence: 7
    progress_pct: 50
    purpose: >
      Opens PR against target_repo main carrying the G-DP-1 evidence
      bundle. PR title/body follow the conventional gate format.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - deployment/{target_app_id}/gate-review-package-g-dp1.json
      context: [target_app_id, portfolio_id]
    outputs:
      artifacts: []
      side_effects:
        - target: target_repo
          fields: [pr]
          notes: PR number returned and stored for gate wiring.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: ai-pre-review-dp1
    label: AI Pre-review (G-DP-1)
    kind: agent
    scope: per-app
    sequence: 8
    progress_pct: 54
    purpose: >
      Pre-review agent reads the G-DP-1 evidence bundle and produces a
      structured recommendation (approve / reject / request changes)
      that lands on the PR as a comment before human reviewers engage.
      Thresholds: active-user ratio ≥ 80%, training completion ≥ 70%,
      zero unresolved critical issues.
    skills: [gate-pre-review]
    agent_role: Gate Pre-review Agent
    inputs:
      artifacts:
        - deployment/{target_app_id}/gate-review-package-g-dp1.json
      context: [target_app_id, portfolio_id, risk_tier]
    outputs:
      artifacts:
        - deployment/{target_app_id}/ai-pre-review-g-dp1.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_type, recommendation, reasoning, created_at]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-dp1
    label: Gate Review (G-DP-1)
    kind: gate
    scope: per-app
    sequence: 9
    progress_pct: 58
    purpose: >
      Waits on gate_approved signal (PM merges PR) and — for Tier-1 —
      stakeholder_approved signals from Operations Lead + Safety Board
      Chair. Tier-2/Tier-3: PM + Operations Lead dual-signal.
      Rejections route to adoption-verification rerun. Exhaustion
      escalates.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [target_app_id, portfolio_id, pr_number, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_type, status, decision_at, approvers]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: none
    parallel_with: []
    gate: G-DP-1
    retry_policy:
      category: validation_failure

  - id: merge-g-dp1-pr
    label: Merge G-DP-1 PR
    kind: git
    scope: per-app
    sequence: 10
    progress_pct: 62
    purpose: >
      Merges the G-DP-1 PR after approval. Marks adoption-verification
      phase complete. Clears rollback window timer start.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [target_app_id, portfolio_id, pr_number]
    outputs:
      artifacts: []
      side_effects:
        - target: target_repo
          fields: [merge_commit]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: legacy-decommission
    label: Legacy Decommission
    kind: agent
    scope: per-app
    sequence: 11
    progress_pct: 68
    purpose: >
      Post rollback-window expiration, formally retire the legacy
      system. Removes legacy API gateway routes, updates DNS, archives
      legacy databases (with reconstruction capability), tears down VMs
      / containers / storage / networking, retires legacy security
      authorization (ATO/cATO), reclaims licenses. Emits the
      decommission-certificate.json artifact. **Irreversible after
      rollback window expires.**
    skills: [legacy-decommission, environment-cleanup]
    agent_role: Decommission Orchestrator
    inputs:
      artifacts:
        - deployment/{target_app_id}/adoption-verification.json
        - dispositions/{portfolio_id}/{app_id}/disposition-output.json
      context: [target_app_id, source_app_id, portfolio_id, rollback_window_expired_at]
    outputs:
      artifacts:
        - deployment/{target_app_id}/decommission-certificate.json
        - deployment/{target_app_id}/license-reclamation-record.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: rw
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: infrastructure

  - id: cost-certification
    label: Cost Savings Certification
    kind: agent
    scope: per-app
    sequence: 12
    progress_pct: 74
    purpose: >
      Calculates realized annual cost savings: pre-modernization TCO
      (from Discovery baseline) minus post-modernization TCO (current
      operational cost) plus license reclamation value. Shared
      infrastructure costs apportioned per client profile. Development
      costs excluded (operational only). Emits the
      cost-savings-certification.json artifact.
    skills: [tco-analyzer]
    agent_role: Cost Savings Certifier
    inputs:
      artifacts:
        - discovery/{source_app_id}/tco-baseline.json
        - deployment/{target_app_id}/decommission-certificate.json
        - deployment/{target_app_id}/license-reclamation-record.json
      context: [target_app_id, source_app_id, portfolio_id]
    outputs:
      artifacts:
        - deployment/{target_app_id}/cost-savings-certification.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: bundle-g-dp2-evidence
    label: Bundle G-DP-2 Evidence
    kind: code
    scope: per-app
    sequence: 13
    progress_pct: 80
    purpose: >
      Synthesises decommission-certificate, license-reclamation-record,
      cost-savings-certification into the G-DP-2 evidence bundle.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - deployment/{target_app_id}/decommission-certificate.json
        - deployment/{target_app_id}/license-reclamation-record.json
        - deployment/{target_app_id}/cost-savings-certification.json
      context: [target_app_id, portfolio_id]
    outputs:
      artifacts:
        - deployment/{target_app_id}/gate-review-package-g-dp2.json
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: create-g-dp2-pr
    label: Create G-DP-2 PR
    kind: git
    scope: per-app
    sequence: 14
    progress_pct: 84
    purpose: >
      Opens PR against target_repo main carrying the G-DP-2 evidence
      bundle.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - deployment/{target_app_id}/gate-review-package-g-dp2.json
      context: [target_app_id, portfolio_id]
    outputs:
      artifacts: []
      side_effects:
        - target: target_repo
          fields: [pr]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: ai-pre-review-dp2
    label: AI Pre-review (G-DP-2)
    kind: agent
    scope: per-app
    sequence: 15
    progress_pct: 87
    purpose: >
      Pre-review on the G-DP-2 bundle. Thresholds: rollback window
      expired = true, data-archival-complete = true, all legacy
      infrastructure rows in decommission-certificate marked "torn
      down", zero license-reclamation discrepancies.
    skills: [gate-pre-review]
    agent_role: Gate Pre-review Agent
    inputs:
      artifacts:
        - deployment/{target_app_id}/gate-review-package-g-dp2.json
      context: [target_app_id, portfolio_id, risk_tier]
    outputs:
      artifacts:
        - deployment/{target_app_id}/ai-pre-review-g-dp2.json
      side_effects:
        - target: gate_pre_review
          fields: [gate_type, recommendation, reasoning, created_at]
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: ro
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure

  - id: gate-review-dp2
    label: Gate Review (G-DP-2)
    kind: gate
    scope: per-app
    sequence: 16
    progress_pct: 91
    purpose: >
      PM + Operations Lead dual-signal (Tier-2/Tier-3). Tier-1 adds
      Certifying Authority signal for continuous-ATO acknowledgment.
      Rejections route to legacy-decommission + cost-certification
      rerun. Exhaustion escalates.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [target_app_id, portfolio_id, pr_number, risk_tier]
    outputs:
      artifacts: []
      side_effects:
        - target: gate_record
          fields: [gate_type, status, decision_at, approvers]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: none
    parallel_with: []
    gate: G-DP-2
    retry_policy:
      category: validation_failure

  - id: persist-deployment-side-effects
    label: Persist Deployment Side Effects
    kind: code
    scope: per-app
    sequence: 17
    progress_pct: 95
    purpose: >
      Workflow code. Projects fields from the G-DP-2 evidence bundle
      onto application (deployed_at, deployment_env, cutover_strategy,
      parallel_run_duration_days, cost_savings_realized_usd,
      license_reclamation_usd, legacy_decommissioned_at,
      deployment_current_status). Best-effort — swallows DB failures so
      the workflow doesn't block on transient DB errors.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - deployment/{target_app_id}/gate-review-package-g-dp2.json
      context: [target_app_id, portfolio_id]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields:
            - deployed_at
            - deployment_env
            - cutover_strategy
            - parallel_run_duration_days
            - cost_savings_realized_usd
            - license_reclamation_usd
            - legacy_decommissioned_at
            - deployment_current_status
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: merge-final-gate-pr
    label: Merge Final Gate PR
    kind: git
    scope: per-app
    sequence: 18
    progress_pct: 99
    purpose: >
      Final merge of the G-DP-2 PR. Updates application.current_line to
      "Sustainment", current_status to "sustainment_active". The
      Sustainment line picks the app up on its next scheduled sweep —
      Deployment does not emit a signal here because Sustainment is
      portfolio-scoped and cron-triggered, not per-app-signal-driven.
      The state flip is the handoff.
    skills: []
    agent_role: null
    inputs:
      artifacts: []
      context: [target_app_id, portfolio_id, pr_number]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields: [current_line, current_status, updated_at]
        - target: target_repo
          fields: [merge_commit]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: rw
    parallel_with: []
    gate: null
    retry_policy:
      category: agent_failure
```

## Sustainment — `sustainment.yaml` (8 steps)

```yaml
# Sustainment — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Sustainment's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.

name: Sustainment
description: >
  Sustainment keeps the active portfolio operational while the factory runs.
  It owns four continuous responsibilities: security patching (AI-assisted
  CVE triage against client-profile SLA windows); incident response
  (symptom-driven diagnosis before remediation); Sustainment ↔ Modernization
  coordination (the "do not modify" flag register and critical-patch
  override protocol); and SLA + cost monitoring (continuous availability /
  response-time tracking and cost-anomaly detection). The sustainment
  portfolio shrinks over time as applications complete modernization. Runs
  on Temporal schedules at daily / weekly / ad-hoc cadences; no per-app
  workflow. No gates.
trigger: temporal-schedule
# Strict upstream only — Sustainment runs after an application has been
# deployed or dispositioned; the rest of the lineage is transitive.
depends_on:
  - Deployment
  - Disposition Execution
gates: []
mode: continuous
inputs:
  - wave-plan
  - sustainment-handoff
  - deployment-env-status
  - catalog-application
  - tco-baseline
outputs:
  - cve-triage
  - incident-response
  - sla-monitoring
  - change-conflict
  - cost-anomaly
  - sweep-summary

steps:
  - id: intake
    label: Sustainment Sweep Intake
    kind: code
    scope: portfolio
    sequence: 1
    progress_pct: 10
    purpose: >
      Workflow code (not an agent dispatch). Resolves the portfolio's
      active inventory (legacy + modern), selects which activities to
      run based on schedule_id prefix, loads the wave plan for "do
      not modify" flag computation, and initialises per-activity
      state objects.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - rationalization/wave-*/wave-plan.json
        - dispositions/{portfolio_id}/*/sustainment-handoff.json
      context: [portfolio_id, schedule_id, triggered_at, cadence]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: cve-triage
    label: CVE Triage
    kind: agent
    scope: portfolio
    sequence: 2
    progress_pct: 25
    purpose: >
      Assess open CVE advisories against the portfolio inventory,
      prioritize per client-profile SLA windows, generate per-app
      patch recommendations, flag critical CVEs on "do not modify"
      apps for override coordination. Emits cve-triage.json with the
      portfolio-wide patching status + per-app action list.
    skills: [patch-assessment]
    agent_role: Patch Manager
    inputs:
      artifacts: []
      context: [portfolio_id, schedule_id, triggered_at, do_not_modify_list]
    outputs:
      artifacts:
        - sustainment/{portfolio_id}/{schedule_id}/cve-triage.json
      side_effects:
        - target: patching_compliance
          fields:
            - portfolio_id
            - sweep_id
            - critical_open_count
            - high_open_count
            - medium_open_count
            - low_open_count
            - sla_compliance_pct
            - evaluated_at
          notes: >
            New table this contract adds (migration 037). Projected by
            persist_sustainment_sweep_side_effects.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [incident-response, sla-monitoring, change-conflict-detection, cost-anomaly-detection]
    gate: null
    retry_policy:
      category: agent_failure

  - id: incident-response
    label: Incident Response Sweep
    kind: agent
    scope: portfolio
    sequence: 3
    progress_pct: 35
    purpose: >
      Symptom-driven diagnosis across active incidents. Reads open
      incident records (from monitoring + user reports + operations),
      identifies affected systems, investigates root cause per
      symptom taxonomy (CPU, API errors, data inconsistency,
      degradation), emits resolution recommendations + incident
      resolution records. Principle: investigate before remediating.
    skills: [incident-response]
    agent_role: Incident Responder
    inputs:
      artifacts: []
      context: [portfolio_id, schedule_id, triggered_at, open_incidents]
    outputs:
      artifacts:
        - sustainment/{portfolio_id}/{schedule_id}/incident-response.json
      side_effects:
        - target: incident_log
          fields:
            - portfolio_id
            - sweep_id
            - app_id
            - severity
            - symptom
            - status
            - resolution_summary
            - recorded_at
          notes: >
            New table this contract adds (migration 037). One row per
            incident processed during the sweep.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [cve-triage, sla-monitoring, change-conflict-detection, cost-anomaly-detection]
    gate: null
    retry_policy:
      category: agent_failure

  - id: sla-monitoring
    label: SLA Compliance Monitoring
    kind: agent
    scope: portfolio
    sequence: 4
    progress_pct: 45
    purpose: >
      Continuous monitoring of availability / response-time / incident-
      resolution against per-client SLA thresholds. Reads per-app
      monitoring data from external observability, compares against
      thresholds, flags breaches, emits the SLA compliance report.
    skills: [sla-breach-investigation]
    agent_role: SLA Monitor
    inputs:
      artifacts: []
      context: [portfolio_id, schedule_id, triggered_at, sla_thresholds]
    outputs:
      artifacts:
        - sustainment/{portfolio_id}/{schedule_id}/sla-monitoring.json
      side_effects:
        - target: sla_compliance_record
          fields:
            - portfolio_id
            - sweep_id
            - app_id
            - availability_pct
            - response_time_p95_ms
            - incident_resolution_mean_hours
            - breach_count
            - recorded_at
          notes: >
            New table this contract adds (migration 037). One row per
            app measured during the sweep.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [cve-triage, incident-response, change-conflict-detection, cost-anomaly-detection]
    gate: null
    retry_policy:
      category: agent_failure

  - id: change-conflict-detection
    label: Change Conflict Detection
    kind: agent
    scope: portfolio
    sequence: 5
    progress_pct: 55
    purpose: >
      Detect sustainment-modernization overlaps. Reads the "do not
      modify" flag register and compares against active change /
      patch / enhancement tickets. Flags conflicts for coordination;
      emits the change-conflict-resolution log + override requests.
    skills: [change-conflict-resolver]
    agent_role: Change Conflict Resolver
    inputs:
      artifacts:
        - modernization/*/generate/*/
      context: [portfolio_id, schedule_id, triggered_at, do_not_modify_list]
    outputs:
      artifacts:
        - sustainment/{portfolio_id}/{schedule_id}/change-conflict.json
      side_effects:
        - target: do_not_modify_flag
          fields:
            - portfolio_id
            - app_id
            - flagged_at
            - wave_id
            - expires_at
            - active
            - override_count
          notes: >
            New table this contract adds (migration 037). One row per
            flagged app; sweep updates expires_at + override_count.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [cve-triage, incident-response, sla-monitoring, cost-anomaly-detection]
    gate: null
    retry_policy:
      category: agent_failure

  - id: cost-anomaly-detection
    label: Cost Anomaly Detection
    kind: agent
    scope: portfolio
    sequence: 6
    progress_pct: 65
    purpose: >
      Cost spike investigation for modernized systems. Reads observed
      spend vs. per-app TCO baselines; flags anomalies before they
      compound; generates right-sizing recommendations for AIOps-
      enabled apps. Emits cost-anomaly.json.
    skills: [cost-anomaly-investigation]
    agent_role: Cost Optimizer
    inputs:
      artifacts:
        - discovery/*/tco-baseline.json
        - deployment/*/cost-savings-certification.json
      context: [portfolio_id, schedule_id, triggered_at, cost_baselines]
    outputs:
      artifacts:
        - sustainment/{portfolio_id}/{schedule_id}/cost-anomaly.json
      side_effects:
        - target: cost_anomaly_record
          fields:
            - portfolio_id
            - sweep_id
            - app_id
            - baseline_usd
            - observed_usd
            - variance_pct
            - flagged
            - recorded_at
          notes: >
            New table this contract adds (migration 037).
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [cve-triage, incident-response, sla-monitoring, change-conflict-detection]
    gate: null
    retry_policy:
      category: agent_failure

  - id: persist-sustainment-sweep-side-effects
    label: Persist Sustainment Sweep Side Effects
    kind: code
    scope: portfolio
    sequence: 7
    progress_pct: 80
    purpose: >
      Workflow code. Projects per-activity findings into the new
      Sustainment DB tables (patching_compliance, incident_log,
      sla_compliance_record, do_not_modify_flag, cost_anomaly_record).
      Also rolls per-app status markers onto application
      (sustainment_current_status, sustainment_last_sweep_at).
      Best-effort — swallows DB failures so the workflow doesn't block
      the sweep summary commit on transient DB errors.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - sustainment/{portfolio_id}/{schedule_id}/cve-triage.json
        - sustainment/{portfolio_id}/{schedule_id}/incident-response.json
        - sustainment/{portfolio_id}/{schedule_id}/sla-monitoring.json
        - sustainment/{portfolio_id}/{schedule_id}/change-conflict.json
        - sustainment/{portfolio_id}/{schedule_id}/cost-anomaly.json
      context: [portfolio_id, schedule_id, triggered_at]
    outputs:
      artifacts: []
      side_effects:
        - target: application
          fields:
            - sustainment_current_status
            - sustainment_last_sweep_at
        - target: patching_compliance
          fields: [...]
        - target: incident_log
          fields: [...]
        - target: sla_compliance_record
          fields: [...]
        - target: do_not_modify_flag
          fields: [...]
        - target: cost_anomaly_record
          fields: [...]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: commit-sweep-summary
    label: Commit Sweep Summary
    kind: code
    scope: portfolio
    sequence: 8
    progress_pct: 95
    summary: true
    purpose: >
      Workflow code. Synthesises per-activity findings + override
      decisions consumed via signal into the portfolio-wide sweep
      summary artifact. This artifact is what Governance reads on its
      next scheduled sweep and what the dashboard surfaces on the
      Sustainment portfolio view.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - sustainment/{portfolio_id}/{schedule_id}/cve-triage.json
        - sustainment/{portfolio_id}/{schedule_id}/incident-response.json
        - sustainment/{portfolio_id}/{schedule_id}/sla-monitoring.json
        - sustainment/{portfolio_id}/{schedule_id}/change-conflict.json
        - sustainment/{portfolio_id}/{schedule_id}/cost-anomaly.json
      context: [portfolio_id, schedule_id, triggered_at, override_decisions]
    outputs:
      artifacts:
        - sustainment/{portfolio_id}/{schedule_id}/sweep-summary.json
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient
```

## Governance — `governance.yaml` (10 steps)

```yaml
# Governance — Assembly Line Contract (authoritative)
#
# THIS IS THE SOURCE OF TRUTH for Governance's steps, skills, artifacts,
# side-effects, and agent contract. Every downstream consumer (Temporal
# workflow, Olympus API gate service, step-progress mapping, frontend
# step registry) loads FROM this file via olympus_contracts.assembly_lines.
# Do not hardcode a copy in application code. Drift is policed by the
# `test_no_hardcoded_step_lists` CI check.

name: Governance
description: >
  Governance has two superordinate responsibilities with six parallel
  activities. A) Govern the portfolio: portfolio health monitoring; drift
  detection across architecture / compliance / performance / cost /
  adoption; new application intake review; user outcome tracking. B)
  Improve Olympus: pattern extraction & skill evolution (the compound-
  growth engine), factory analytics & capacity management. Runs on Temporal
  schedules at weekly and quarterly cadences; quarterly adds model
  benchmarking. Governance reads from every upstream line and writes ZERO
  fields to the application row — all its writes land in portfolio-scoped
  tables. No gates. The only line whose outputs feed every other line.
trigger: temporal-schedule
# Governance is a continuous cross-line observer; it reads from every
# upstream line but does not block on any. Per the extensibility registry,
# its ``depends_on`` is empty so it can run regardless of assembly-line
# completion state.
depends_on: []
gates: []
mode: continuous
inputs:
  - wave-plan
  - sweep-summary
  - architecture-blueprint
  - data-architecture
  - cost-savings-certification
  - pattern-extraction
  - ralph-loop-metrics
  - escalation-record
outputs:
  - drift-detection
  - pattern-extraction
  - latest-patterns
  - health-report
  - skill-evolution
  - factory-capacity
  - model-evaluation
  - sweep-summary

steps:
  - id: intake
    label: Governance Sweep Intake
    kind: code
    scope: portfolio
    sequence: 1
    progress_pct: 8
    purpose: >
      Workflow code (not an agent dispatch). Resolves the portfolio's
      cadence from schedule_id prefix (weekly vs. quarterly), selects
      the active activity set, loads portfolio inventory + upstream-
      line completion metadata (from application row + per-line
      artifact paths), and initialises per-activity state objects.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - rationalization/wave-*/wave-plan.json
        - sustainment/{portfolio_id}/*/sweep-summary.json
      context: [portfolio_id, schedule_id, triggered_at, cadence]
    outputs:
      artifacts: []
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: ro
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: drift-detection
    label: Drift Detection
    kind: agent
    scope: portfolio
    sequence: 2
    progress_pct: 20
    purpose: >
      Detect applications deviating from approved baselines across 5
      drift categories: architecture (runtime config vs. blueprint),
      compliance (security + accessibility + authorization),
      performance (P95 latency / error-rate / availability trends),
      cost (observed vs. certified-savings baseline), adoption
      (post-deployment active-user trend). Critical drift generates
      immediate alerts to line leads; non-critical drift aggregates
      into the quarterly health report. Emits drift-detection.json.
    skills: [drift-detection]
    agent_role: Governance Drift Monitor
    inputs:
      artifacts:
        - architecture/*/architecture-blueprint.json
        - data/*/data-architecture.json
        - deployment/*/cost-savings-certification.json
      context: [portfolio_id, schedule_id, triggered_at, cadence, drift_thresholds]
    outputs:
      artifacts:
        - governance/{portfolio_id}/{schedule_id}/drift-detection.json
      side_effects:
        - target: drift_alert
          fields:
            - portfolio_id
            - sweep_id
            - app_id
            - drift_type
            - severity
            - details
            - acknowledged
            - created_at
          notes: >
            Existing table (migration 025). Governance appends rows;
            dashboard surface + ack workflow already in place.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [pattern-extraction, health-report, skill-evolution, factory-capacity]
    gate: null
    retry_policy:
      category: agent_failure

  - id: pattern-extraction
    label: Pattern Extraction
    kind: agent
    scope: portfolio
    sequence: 3
    progress_pct: 30
    purpose: >
      Compound growth engine. Analyzes completed modernization
      artifacts (code templates, architecture patterns, integration
      patterns) + gate-pass correlation data to extract reusable
      patterns. Adds to pattern library, records acknowledgments from
      downstream Modernization workflows. Emits pattern-extraction.json
      + feeds _propagate_patterns + _commit_latest_patterns_registry
      helpers.
    skills: [skill-builder]
    agent_role: Pattern Extractor
    inputs:
      artifacts:
        - modernization/*/generate/*/
        - modernization/*/ralph-loop-metrics.json
        - modernization/*/escalation-record.json
      context: [portfolio_id, schedule_id, triggered_at, cadence, pattern_library_state]
    outputs:
      artifacts:
        - governance/{portfolio_id}/{schedule_id}/pattern-extraction.json
        - governance/{portfolio_id}/latest-patterns.json
      side_effects:
        - target: pattern
          fields:
            - name
            - category
            - wave_id
            - source_apps
            - reuse_count
            - content
            - portfolio_id
            - created_at
          notes: >
            Existing table (migration 025). Governance appends new
            patterns. Reuse_count updated on wave_patterns_ready ack.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [drift-detection, health-report, skill-evolution, factory-capacity]
    gate: null
    retry_policy:
      category: agent_failure

  - id: health-report
    label: Portfolio Health Report
    kind: agent
    scope: portfolio
    sequence: 4
    progress_pct: 40
    purpose: >
      Portfolio health monitoring + quarterly deep scans. Aggregates
      Sustainment's patching_compliance + incident_log +
      sla_compliance_record + cost_anomaly_record tables;
      Validation's parity + vuln + accessibility columns;
      Deployment's cost-savings-realized column into a single
      health index + per-dimension breakdown. Emits health-report.json.
    skills: [portfolio-health-check]
    agent_role: Portfolio Health Checker
    inputs:
      artifacts: []
      context: [portfolio_id, schedule_id, triggered_at, cadence, health_thresholds]
    outputs:
      artifacts:
        - governance/{portfolio_id}/{schedule_id}/health-report.json
      side_effects:
        - target: health_check
          fields:
            - portfolio_id
            - health_index
            - checks
            - date
          notes: >
            Existing table (migration 025). One row per sweep for
            trend analysis.
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [drift-detection, pattern-extraction, skill-evolution, factory-capacity]
    gate: null
    retry_policy:
      category: agent_failure

  - id: skill-evolution
    label: Skill Evolution
    kind: agent
    scope: portfolio
    sequence: 5
    progress_pct: 50
    purpose: >
      Skill lifecycle management — observe → extract → create → test →
      publish → measure → refine. Analyzes factory execution for
      successful patterns and failures; produces new / refined SKILL.md
      recommendations + test plans. Skill approval is dashboard-
      mediated (humans review before publish); workflow produces the
      recommendation, not the publish decision.
    skills: [skill-builder]
    agent_role: Skill Evolution Agent
    inputs:
      artifacts:
        - governance/*/pattern-extraction.json
        - modernization/*/ralph-loop-metrics.json
      context: [portfolio_id, schedule_id, triggered_at, cadence, skill_registry_state]
    outputs:
      artifacts:
        - governance/{portfolio_id}/{schedule_id}/skill-evolution.json
      side_effects: []
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [drift-detection, pattern-extraction, health-report, factory-capacity]
    gate: null
    retry_policy:
      category: agent_failure

  - id: factory-capacity
    label: Factory Capacity Management
    kind: agent
    scope: portfolio
    sequence: 6
    progress_pct: 60
    purpose: >
      Factory analytics + concurrent-wave capacity planning. Computes
      throughput, cost-per-app, gate-first-pass-rate, Ralph-Loop-
      iteration average, escalation-rate, pattern-reuse-rate,
      automation-ratio, time-to-modernize. Produces the concurrent-
      wave capacity plan that Rationalization consumes. Emits
      factory-capacity.json + compound-growth metrics feed.
    skills: [factory-capacity-manager]
    agent_role: Factory Capacity Planner
    inputs:
      artifacts:
        - rationalization/wave-*/wave-plan.json
      context: [portfolio_id, schedule_id, triggered_at, cadence, historical_metrics]
    outputs:
      artifacts:
        - governance/{portfolio_id}/{schedule_id}/factory-capacity.json
      side_effects:
        - target: factory_capacity_plan
          fields:
            - portfolio_id
            - sweep_id
            - concurrent_wave_max
            - throughput_apps_per_month
            - cost_per_app_usd
            - gate_first_pass_rate
            - ralph_loop_iteration_avg
            - escalation_rate
            - pattern_reuse_rate
            - automation_ratio
            - time_to_modernize_days
            - computed_at
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [drift-detection, pattern-extraction, health-report, skill-evolution]
    gate: null
    retry_policy:
      category: agent_failure

  - id: model-evaluation
    label: Model Evaluation
    kind: agent
    scope: portfolio
    sequence: 7
    progress_pct: 70
    purpose: >
      Quarterly model-benchmark run. Evaluates Tier-1/Tier-2/Tier-3
      models on held-out task suites; identifies regressions,
      cost-effectiveness changes, refresh recommendations. Output
      feeds Orchestration's skill-to-model routing. Skipped on weekly
      cadence.
    skills: [model-benchmark]
    agent_role: Model Evaluator
    inputs:
      artifacts:
        - governance/*/pattern-extraction.json
      context: [portfolio_id, schedule_id, triggered_at, cadence, model_registry_state]
    outputs:
      artifacts:
        - governance/{portfolio_id}/{schedule_id}/model-evaluation.json
      side_effects:
        - target: model_benchmark_result
          fields:
            - portfolio_id
            - sweep_id
            - model_id
            - tier
            - task_suite
            - pass_rate
            - cost_per_call_usd
            - latency_p95_ms
            - regression_flag
            - refresh_recommended
            - benchmarked_at
    agent_contract:
      mcp_servers: [olympus]
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: [drift-detection, pattern-extraction, health-report, skill-evolution, factory-capacity]
    gate: null
    retry_policy:
      category: agent_failure

  - id: propagate-patterns
    label: Propagate Patterns to Modernization
    kind: code
    scope: portfolio
    sequence: 8
    progress_pct: 80
    purpose: >
      Workflow code. Pushes the pattern bundle from this sweep to
      every active Modernization workflow in the portfolio via
      Temporal external-handle signal emission. Best-effort — a
      sweep that can't reach any consumers still commits the
      summary. Also commits the cold-start registry artifact so
      Modernization workflows that start later can load patterns at
      intake.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - governance/{portfolio_id}/{schedule_id}/pattern-extraction.json
        - governance/{portfolio_id}/latest-patterns.json
      context: [portfolio_id, schedule_id, triggered_at, active_mod_workflow_ids]
    outputs:
      artifacts: []
      side_effects:
        - signal: WavePatternsReadySignal
          fields:
            - wave_id
            - patterns
            - portfolio_id
            - ready_at
          target: ModernizationWorkflow (each active instance)
          notes: >
            Existing signal shape; reality already emits. Contract
            documents the shape here for cross-line visibility.
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: persist-governance-sweep-side-effects
    label: Persist Governance Sweep Side Effects
    kind: code
    scope: portfolio
    sequence: 9
    progress_pct: 88
    purpose: >
      Workflow code. Projects per-activity findings into the
      Governance DB tables (drift_alert, pattern, health_check exist;
      factory_capacity_plan + model_benchmark_result are new). Best-
      effort — swallows DB failures so the workflow doesn't block
      the sweep summary commit on transient DB errors.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - governance/{portfolio_id}/{schedule_id}/drift-detection.json
        - governance/{portfolio_id}/{schedule_id}/pattern-extraction.json
        - governance/{portfolio_id}/{schedule_id}/health-report.json
        - governance/{portfolio_id}/{schedule_id}/skill-evolution.json
        - governance/{portfolio_id}/{schedule_id}/factory-capacity.json
        - governance/{portfolio_id}/{schedule_id}/model-evaluation.json
      context: [portfolio_id, schedule_id, triggered_at, cadence]
    outputs:
      artifacts: []
      side_effects:
        - target: drift_alert
          fields: [...]
        - target: pattern
          fields: [...]
        - target: health_check
          fields: [...]
        - target: factory_capacity_plan
          fields: [...]
        - target: model_benchmark_result
          fields: [...]
    agent_contract:
      mcp_servers: []
      repos:
        artifact: none
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient

  - id: commit-sweep-summary
    label: Commit Sweep Summary
    kind: code
    scope: portfolio
    sequence: 10
    progress_pct: 96
    summary: true
    purpose: >
      Workflow code. Synthesises per-activity findings + pattern-
      ready acknowledgments (consumed via wave_patterns_ready signal
      mid-sweep) into the portfolio-wide sweep summary artifact.
      This artifact is what the dashboard Governance panel renders
      and what Sustainment / Rationalization / Orchestration consume
      on their next cycles.
    skills: []
    agent_role: null
    inputs:
      artifacts:
        - governance/{portfolio_id}/{schedule_id}/drift-detection.json
        - governance/{portfolio_id}/{schedule_id}/pattern-extraction.json
        - governance/{portfolio_id}/{schedule_id}/health-report.json
        - governance/{portfolio_id}/{schedule_id}/skill-evolution.json
        - governance/{portfolio_id}/{schedule_id}/factory-capacity.json
        - governance/{portfolio_id}/{schedule_id}/model-evaluation.json
      context: [portfolio_id, schedule_id, triggered_at, cadence, wave_patterns_ready_log]
    outputs:
      artifacts:
        - governance/{portfolio_id}/{schedule_id}/sweep-summary.json
      side_effects: []
    agent_contract:
      mcp_servers: []
      repos:
        artifact: rw
        source: none
        target: none
    parallel_with: []
    gate: null
    retry_policy:
      category: transient
```
