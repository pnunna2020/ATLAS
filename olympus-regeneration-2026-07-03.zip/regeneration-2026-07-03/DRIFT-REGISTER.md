# DRIFT-REGISTER — consolidated drift, gotchas & tech-debt

> ATOMIC regeneration spec. Premise: the codebase is deleted; this document set is the only
> surviving artifact. **The bar is BEHAVIORAL PARITY.** All facts below are derived from LIVE
> code at `/Users/pnunna/Documents/GitHub/olympus` on 2026-07-03 (branch `main`, HEAD
> `6c99bb6b214d65cc6a5ed65dddbc7a399404decb`). Every claim cites `path:line`. This set SUPERSEDES
> the 2026-07-02 set (commit `22976138`), which was ~184 commits stale.
>
> **How to read this doc.** It has three parts:
> 1. **§A — Verified drift** (code diverges from its own docs/specs): the seed D1–D13 table from
>    `00-overview.md` re-verified against live code, plus additional confirmed items.
> 2. **§B — Consolidated GOTCHA register**: 1,167 `GOTCHA` lines across 74 docs, de-duplicated
>    into thematic clusters. Per-line behavioral gotchas stay in their home doc (they ARE the
>    regeneration spec for that unit); this section captures the cross-cutting, load-bearing, and
>    surprising ones a rebuild must know regardless of which file it is rebuilding.
> 3. **§C — TODO/FIXME/HACK/XXX** the rebuild must know about.
>
> **Regeneration rule (LOAD-BEARING).** Always regenerate against a **fully-synced PRIMARY tree**.
> The Capabilities subsystem (`olympus-api/src/services/capabilities/`) once existed ONLY under
> `.claude/worktrees/` before `main` was synced; it is now in the primary tree
> (verified present at `olympus-api/src/services/capabilities/`, HEAD `6c99bb6b`). **HARD-EXCLUDE**
> these stale/duplicate trees when deriving counts or reading source:
> `build/lib/`, `.claude/worktrees/`, `node_modules/`, `.venv/`, `dist/`, `__pycache__/`.

---

## §A — Verified drift (code vs its own docs/specs)

### A.0 Seed drift table (D1–D13, re-verified live)

| # | Discrepancy | Verified evidence (live) | Status |
|---|---|---|---|
| **D1** | `RiskTier` is an **`enum.IntEnum`** (tiers compare/order as ints), not a str enum | `olympus-contracts/olympus_contracts/enums.py:44` (`class RiskTier(enum.IntEnum)`) | CONFIRMED |
| **D2** | Assembly-line contract YAMLs canonical at `olympus-contracts/olympus_contracts/data/assembly-lines/` with a **stale duplicate** at `olympus-contracts/build/lib/olympus_contracts/data/assembly-lines/`. `build/lib/` is a packaging artifact — NOT source | `olympus-contracts/build/lib` present; do not read it | CONFIRMED |
| **D3** | `RiskTier` defined in TWO places: the canonical IntEnum in contracts AND a **plain (non-Enum) `class RiskTier`** in the API profile loader | `olympus-api/src/services/profile_loader.py:150` (`class RiskTier:`) | CONFIRMED |
| **D4** | `@foundry_activity` is a **wrapper around `@activity.defn`** (adds observability + standard error-wrapping), not a bare Temporal decorator | `temporal/olympus_workflows/temporal_base/activities.py:79-100` (`@activity.defn(name=name, **activity_kwargs)` inside `decorator`) | CONFIRMED |
| **D5** | **"7th extension registry" is a trap:** `loop_pattern.py` LOOKS like a 7th extension point but is explicitly NOT one — DECISION-010 caps extension registries at **6**; `loop_pattern` is a read-only *catalog* on the shared `Registry` engine (like `analysis_pass`) | `temporal/olympus_workflows/registries/loop_pattern.py:9-25` | CARRIED (unchanged) |
| **D6** | The **6 canonical extension registries**: `assembly_line`, `disposition`, `analysis_pass`, `scoring_dimension`, `gate_provider`, `skill_composition` (module-level `*_REGISTRY` singletons) | `registries/*.py:186,490,170,222,406,194` | CARRIED |
| **D7** | Assembly-line dir count is **12** live (adds `reverse-engineering/`); `CLAUDE.md` narrates "10 assembly lines" and the 2026-07-02 spec recorded 11 | `ls -d assembly-lines/*/` → 12 dirs | CONFIRMED |
| **D8** | Cross-cutting dir count is **12** live (`templates/` is the 12th); `CLAUDE.md` narrates "11 cross-cutting concerns" | `ls -d cross-cutting/*/` → 12 dirs | CONFIRMED |
| **D9** | Temporal coverage floor is **80**, not 87 as `CLAUDE.md` states | `temporal/pyproject.toml:123` | CONFIRMED |
| **D10** | Dashboard **statements** floor is **78**, not 79 as `CLAUDE.md` states (P5-S26 dropped 79→78 to match main drift) | `dashboard/vitest.config.ts:71` | CONFIRMED |
| **D11** | The agent LB is **HAProxy** (`haproxy:2.9-alpine`), though compose comments still say "nginx LB" from an earlier task | `docker-compose.yml:487` (`image: haproxy:2.9-alpine`); stale "nginx LB" comments at `:257,354,358` | CONFIRMED |
| **D12** | `olympus2` API host port is **18000**, not the naive +1000 (9000) — a host-level Ztunnel occupies 9000 | `docker-compose.olympus2.yml` port map | CARRIED |
| **D13** | `temporal-server` dynamicconfig overrides `blobSize.error` 2 MiB → 4 MiB as a band-aid for oversized gate-evidence payloads (durable fix pending) | `docker-compose.yml:77-83`, `infra/temporal/dynamicconfig.yaml` | CONFIRMED |

### A.1 Additional verified drift (task-directed items)

| # | Discrepancy | Verified evidence (live) | Status |
|---|---|---|---|
| **D14** | **`reverse-engineering` is STILL NOT in the `AssemblyLine` enum.** It NOW HAS a canonical contract YAML (`olympus-contracts/olympus_contracts/data/assembly-lines/reverse-engineering.yaml`, 7,344 bytes) AND a workflow (`IngestionWorkflow`, `temporal/olympus_workflows/workflows/ingestion.py:91`), but the `AssemblyLine` StrEnum still has only **11 members** (Discovery, Rationalization, Architecture, Data, Modernization, Build, Disposition Execution, Validation, Deployment, Sustainment, Governance) — no `REVERSE_ENGINEERING`. So the on-disk line dir (12), the contract YAML, and the workflow exist, but the enum lags. **NOT reconciled — this is live drift.** | enum: `olympus-contracts/olympus_contracts/enums.py:309` (`class AssemblyLine(enum.StrEnum)`), 11 values, no `reverse`; YAML present; workflow at `ingestion.py:91` | CONFIRMED (still drift) |
| **D15** | **Migration number 055 is SKIPPED.** The Alembic chain runs `001 → 091` but there are only **90** version files — `055` does not exist (`…054…`, then `056…`). The chain is linear via `down_revision`, so the gap is cosmetic (a renumber during a fork), but a rebuild that generates migrations by count `001..091` will mis-number by one after 054. | `db/alembic/versions/` — `054_add_architecture_workflow_id_to_wave.py` then `056_create_portfolio_membership.py`; no `055*`; 90 files; head = `091` | CONFIRMED |
| **D16** | **`models.py` was SPLIT into a `models/` package.** The API no longer has a single `olympus-api/src/models.py`; it is now a package `olympus-api/src/models/` (with `__init__.py`, `application.py`, `bundle.py`, `control_mapping.py`, `evidence_record.py`, `evidence_envelope.py`, `gate.py`, `agent*.py`, `analytics.py`, `common.py`, `delegation.py`, …). A rebuild must recreate the package layout, not one file. | `olympus-api/src/models/` is a dir; no `olympus-api/src/models.py` | CONFIRMED |
| **D17** | **`schemas/validate.sh` validates only a FIXED allow-list of subdirs** and silently EXCLUDES others. The metaschema loop at `schemas/validate.sh:12` iterates only: `common, discovery, rationalization, architecture, data, modernization, build, gates, cross-cutting, compliance, profiles, dispositions`. **EXCLUDED from metaschema validation:** `schemas/design/` (6 FAA-domain schemas, all `$id` relative), `schemas/drift/` (1), `schemas/evidence/` (1), `schemas/ingestion/` (2, ship with `.sample.json` twins), `schemas/oscal/` (1). A rebuild that "validates all schemas" would tighten behavior beyond parity — these dirs must stay excluded from the metaschema loop. (The separate `scripts/validate_schema_samples.py` round-trip at `validate.sh:43` covers a different, backlog-tracked set.) | `schemas/validate.sh:12,43,49`; excluded dirs exist under `schemas/` | CONFIRMED |
| **D18** | **Capability `bare` tier claims BYTE-PARITY with the existing standalone dispatch.** `tier=bare` is a "thin pass-through of the existing dispatch: it returns exactly the dispatch artifact and runs NO provenance code (this is the seam S18.3 asserts byte-parity on)". `provenance`/`verified` run everything `bare` does and THEN attach provenance to SIBLING fields only — never the artifact payload — so parity is preserved. `verified is None` means "no verification ran" (tri-state). A rebuild MUST keep `bare` a true pass-through of `dispatch_via_a2a` (`agent_client.py:179`). | `olympus-api/src/services/capabilities/service.py:9-25`; `capabilities/models.py:106` (byte-parity note) | CONFIRMED |
| **D19** | **NL-console `ACTION_SPECS` gating is DATA-driven per profile; `vba` and `baseline` LACK the policy file.** `nl_engine.load_policy(profile)` reads tiering from `profiles/<profile>/nl-action-policy.yaml`. Only **`faa`** and **`test-generic`** ship this file; **`vba` and `baseline` do NOT.** **Fallback chain (`nl_engine.py:368-397`):** try `<profile>/nl-action-policy.yaml` → try `test-generic/nl-action-policy.yaml` → else a **fail-safe built-in default** where `default_tier=HIGH_STAKES`, `reversible=∅`, `high_stakes=∅`, `gate_agent_may_approve=False` (every non-gate action confirms; unknown → confirm). So a `vba`/`baseline` NL console falls through to `test-generic`'s policy if present, otherwise to fail-safe-confirm-everything. A rebuild must preserve this exact three-step fallback. | `olympus-api/src/services/nl_engine.py:12-17,368-397`; policy files present only for `faa`, `test-generic` | CONFIRMED |

### A.2 The client-agnostic (cATO/OSCAL) blocker — current status

Historically the #1 blocker to client-agnosticism (per user MEMORY). Live status is **partially
resolved**:

- **Control catalog: RESOLVED (profile-driven).** `olympus-api/src/services/compliance_pack.py`
  reads the control catalog, framework, and artifact format from the **active profile's
  `compliance.security` block** at runtime (`compliance_pack.py:1-18`). A profile with no catalog
  yields an **empty** catalog, NOT FAA's. Agency-neutral fallbacks: `_FALLBACK_FRAMEWORK = "NIST
  800-53 Rev 5"`, `_FALLBACK_ARTIFACT_FORMAT = "generic"` (`compliance_pack.py:28-30`), used only
  when no profile is active. `evidence_emit.py:161` consumes `active_compliance_pack()`.
- **OSCAL format/pipeline: STILL CORE-RESIDENT (residual blocker).** The OSCAL export/evidence
  machinery lives in core: `evidence_oscal.py` (`OSCAL_VERSION = "1.1.2"` hardcoded at
  `evidence_oscal.py:31`), `evidence_export.py`, and routers `governance.py`, `evidence_ledger.py`,
  `evidence_runs.py`. The *artifact format* is a profile string
  (`compliance.security.artifact_format`; `CompliancePack.is_oscal` at `compliance_pack.py:52-55`),
  but the OSCAL 1.1.2 serialization is **not itself profile-pluggable** — it is cross-cutting
  concern #11 (compliance), not a profile plugin.
- **What VBA inherits from FAA:** VBA **inherits the shared OSCAL evidence PIPELINE and the cATO
  view shell** (core code), but supplies its OWN control catalog/framework via its profile
  (`profiles/vba/compliance.yaml`: NIST 800-53 Rev 5 + OSCAL + VA Handbook 6500 + FedRAMP Moderate;
  `artifact_format: "OSCAL"` at `compliance.yaml:43`). VBA declares **no `control_catalog` list →
  empty**, so it does NOT inherit FAA's SF3/NIST controls. The residual blocker is purely the OSCAL
  *pipeline* + evidence models being core, not swappable.

---

## §B — Consolidated GOTCHA register (thematic, de-duplicated)

1,167 `GOTCHA` lines span 74 docs. Most are unit-local behavioral notes and stay in their home doc
(they are the parity spec for that function/component). The clusters below are the cross-cutting,
load-bearing, and surprising ones a rebuild must honor regardless of which file it touches. Each
cites a representative live source.

### B.1 Count / cardinality drift (docs lag filesystem)
- Assembly-line dirs **12** (adds `reverse-engineering/`) vs CLAUDE.md "10" / prior spec 11
  (`00-overview.md:24`; `ls -d assembly-lines/*/`). `assembly-lines/overview.md` is a FILE, not a dir.
- Cross-cutting dirs **12** (`templates/` is the extra) vs CLAUDE.md "11" (`00-overview.md:26`).
- Coverage floors: temporal **80** (not 87), dashboard statements **78** (not 79)
  (`00-overview.md:144`; `temporal/pyproject.toml:123`, `dashboard/vitest.config.ts:71`).
- `AssemblyLine` enum has **11** members but there are 12 line dirs (D14) — worker boot guards on
  `profile.lines` values "outside the 11" precisely because of this mismatch (`worker_bootstrap.py`).

### B.2 Enum serialization across the Temporal boundary (LOAD-BEARING, recurs many times)
Temporal's payload converter deserializes `str`-enum fields as a **list of single characters** in
some paths. Multiple activities defensively `"".join(...)` a value before comparing, or accept both
a real enum (`.value`) and a raw string (`str(...)`):
- `03b-activities/…:179,259` — test-status + resolution-type checks `"".join(...)` a char-list.
- `gate_type` normalization: `input.gate_type.value if isinstance(input.gate_type, GateType) else
  str(input.gate_type)`.
- `OverrideType` handled as enum-or-string.
- Dataclass re-hydration: `if isinstance(input, dict): input = XInput(**input)` tolerates a raw
  dict from payload deserialization (e.g. `context_priors.py`, DevSecOps baseline validator `:294-295`).
- **Serialization base types (`06-contracts.md`):** exactly two enums use `IntEnum`/`StrEnum`
  explicitly — `RiskTier` (`IntEnum`, 1=Critical/2=Standard/3=Low-Risk, chosen for the Temporal
  payload reason) and `AssemblyLine` (`StrEnum`); the rest are `(str, Enum)` style.
A rebuild MUST preserve these defensive coercions or replay/round-trip breaks.

### B.3 Empty-string → None coercion at activity/resolver boundaries
Dataclass defaults are often `""`; resolvers coerce empty string to `None` so the active-profile
path is taken rather than a literal-empty lookup:
- `params = resolve_baseline_params(input.profile_id or None)` (`:156`).
- `wave_id` hardcoded `""` marks a single-app (non-wave) handoff path.
Preserve `X or None` coercions.

### B.4 Idempotency & at-least-once (Temporal may re-run any activity)
- All DB writes are transactional + idempotent so a whole-activity retry is safe; but on retry the
  returned counts reflect only rows the retry newly inserted (`03b-activities` retry-semantics gotchas).
- `xmax = 0` insert-detection: `persist_capability_catalog` distinguishes a true INSERT (`xmax=0`)
  from `ON CONFLICT DO UPDATE` — `xmax` is nonzero on conflict-update.
- Guarded flips: e.g. risk-tier migration UPDATE only touches rows currently `risk_tier='1'`
  (string literal); idempotent claim uses `WHERE (consumed_at IS NULL OR …)`; publishing the same
  key **resets** (writer-is-source-of-truth).
- Some idempotency is deliberately happy-path-only (no `WHERE status != 'failed'` guard) — a second
  call overwrites `failed_at`; chosen "idempotent on happy path over racy on retry."

### B.5 Determinism sandbox discipline (workflows)
- All activity/type/registry imports go inside `with workflow.unsafe.imports_passed_through():`
  (`cve_triage.py:60-71`) — mandatory so the determinism sandbox passes them through.
- Workflows "read no clock / env / DB" — all decision + clock logic lives in activities
  (`ci_repair.py:49-52`). I/O (enumeration) stays in an activity; signal dispatch stays in the
  workflow to preserve determinism.
- `@foundry_activity` wraps a **raw** exception in an ApplicationError-family type — matters for
  retry classification (D4; `activities.py:79-100`).

### B.6 Temporal `workflow.patched(...)` versioning branches (replay determinism)
Several workflows carry `workflow.patched("…-v1")` branches; old (unpatched) histories take the
legacy path. A rebuild must keep BOTH branches or replay of in-flight histories breaks. Examples:
`modernization-gate-pre-review-v1` (`ModernizationWorkflow:2002`), G-DA dual-signal, patch-gate
determinism notes. See the per-workflow docs under `03-workflows/`.

### B.7 Child-workflow ID keying (WORKFLOW_ALREADY_EXISTS hazards)
- Modernization decomposition child ids key on the **plan SLUG, not the provisioned UUID** —
  keying on UUID collapsed every 1→N target onto one id and tripped `WORKFLOW_ALREADY_EXISTS`
  (`ModernizationWorkflow:716-724`).
- App child id embeds the wave (`app-{app_id}-wave-{wave_id}`) but the Discovery child id does NOT
  (`discovery-{app_id}`) — same `app_id` in two concurrent waves collides on Discovery.
- Cancel handles must match the launch id **byte-for-byte** (`app-{app_id}-wave-{_wave_id}`).

### B.8 Disposition-specific step skipping / bundle emission (Modernization + Deployment)
- For `Retire`, `orchestration` is absent from `active_steps`, so the whole deploy/shift/
  parallel-run/adoption-verify + G-DP-1 block is SKIPPED (`Deployment:456`).
- Disposition-output bundle (Step 18) emitted ONLY for `Refactor`/`Rearchitect`; Replace/
  Replatform/Consolidate run all 18 steps but their bundle is owned by Disposition
  (`Deployment:503`). Retain never sets `_disposition_output_json`.
- `bounded_context_map_ref` added to payload ONLY for `Rearchitect`, not `Refactor` (`:947-950`).
- A disposition-signal timeout after 30 min does NOT fail — it silently defaults to `Refactor`
  (`Deployment:556-561`); `_disposition_signal` wins over `_validation_signal` if both arrive (`:563`).

### B.9 Rework counter semantics (uniform across gates)
- `_bump_rework` runs BEFORE the strict `> MAX_REWORK_ITERATIONS` check → up to **3** rework
  attempts, the 4th (`4 > 3`) fails.
- Rework scope is gate-specific: G-DP-1 rejection re-runs ONLY adoption-verification; G-DP-2
  re-runs BOTH legacy-decommission AND cost-certification; the Extract/rationalization rework
  re-runs only the sequence-3 parallel passes (catalog + Pass-1 NOT re-run).
- **CRITICAL (`03-workflows`):** a failed deterministic baseline validation triggers a rework that
  increments the G-04c counter and resets Tier-1 flags but **never created a gate record** — a
  known sharp edge to reproduce, not "fix."

### B.10 Gate lifecycle: `preparing` (hidden) → `pending` (visible)
Gate rows are inserted `status='preparing'` — **hidden** from the reviewer queue. AI pre-review
runs, then `mark_gate_ready_for_review` flips to `'pending'`; the queue filters `status='pending'`.
G-V1 pre-review is what flips `preparing→pending`. Preserve the two-phase visibility.

### B.11 Sustainment / continuous-line quirks
- `SustainmentWorkflow`: `pending_gate` is ALWAYS `None` (`:636`) and `current_line` ALWAYS
  `AssemblyLine.SUSTAINMENT` — hardcoded because Sustainment runs no gates.
- The three "spine" coordinator classes' `run()` methods read **no HIL flag** — no
  `wait_condition(lambda: self.cancelled)` — so `cancel_workflow`/approve signals mutate mixin
  state that `run()` never checks. Signal handlers exist for interface conformance; they are inert
  on the spine.

### B.12 Autonomy / CI-repair (P9) safety invariants
- **Flaky → quarantine only, NEVER code-fix** — enforced in the TRIAGE activity
  (`activities/ci_repair.py:237-247`), not the workflow.
- `requested_level` is data-driven: `LOOP_PATTERN_REGISTRY.get(_PATTERN_NAME).default_autonomy_level`
  (not hardcoded).
- `gated_report_only=1` requires BOTH `escalate is False` AND `permitted_level == "report_only"`
  (`cve_triage.py:166`); an escalating decision also pins `report_only` but is bucketed as
  escalated (bucket order checks `escalate` first, `ci_repair.py:178-183`).
- Error classification is a **fragile substring match on the exception TYPE NAME**
  (`"timeout"`,`"connection"`,`"network"`,…) — false-positive-prone (a `ConnectionError` whose
  cause is not transient is still retried). Preserve behavior; note the debt.
- Adapter exists because Temporal cannot round-trip a bare `dict[str, object]` in
  `AutonomyDecision.metadata` — keep the adapter.

### B.13 Ingestion / reverse-engineering line (drift D14 subsystem)
- `file_count` metadata = number of INGESTIBLE files ingested (`seen`), not all files.
- Identical bytes always score identically (dedup by content hash, 4-dp score, `ingestion.py:238`).
- Symlink handling: a `rel_path` that resolves to `base` raises; `str(p.relative_to(base))` used
  (`ingestion.py:100-113`).
- At enrollment time `citations` is empty (`ingestion_drift.py`).
- `_obligation_needs_confirmation` is empty until the first activity returns; a query issued during
  the ingest activity sees empty (`ingestion.py:97-101`). `_status="awaiting_confirmation"` is
  written BEFORE the wait and only inside the `if` (all-above-floor → status never becomes it,
  `ingestion.py:219-223`). Terminal ternary yields `"cancelled"` if the wait woke on `_cancelled`
  (`ingestion.py:222,225`).

### B.14 Migration / DB-schema gotchas
- `055` skipped (D15); chain is per-migration `down_revision`, transaction-per-run in `env.py`
  (not per-migration).
- Enum `ADD VALUE` always appends to the END of the enum (ordering matters for any positional use).
- `application.metadata` (051) collides with SQLAlchemy's reserved `metadata` attr — column-name
  gotcha. `archetype_source` reuses `tier_source_enum`; DB `archetype` enum vs projection can
  mismatch. `dispatching_workflow_id` added in migration 063 — bundles created before 063 (or via
  manual admin dispatch) have it NULL.
- 084/085 module docstrings are misleading (comments describe the wrong thing); trust the SQL.
- Partial UNIQUE index `ux_bundle_one_open_per_scope` uses `COALESCE(application_id, 0-uuid)` (057).
- One migration deliberately OMITS `from __future__ import annotations`.

### B.15 Dashboard (UI) gotchas
- Statements coverage floor 78 (D10).
- Several actions surface a toast only with **no backend endpoint yet** (e.g. `filterByApp`
  `:524-528`) — parity means the toast-only behavior, not a real call.
- `GateReview.tsx:301` carries a `TODO` cast to be removed once a backend shape lands (see §C).
- App-shell height uses `min-height:0` deliberately, NOT `calc(100vh - topnav)` (`:6-20`).
- `fetchSkills({page, per_page})` paginates; a behavior-inverting signature guard exists.

### B.16 Compliance / OSCAL residue (see §A.2)
- `evidence_oscal.py:31` hardcodes `OSCAL_VERSION = "1.1.2"`.
- A `cato_target_uuid` parameter is **accepted but never used** inside one function body — dead
  parameter, keep the signature for parity.
- Hardcoded fallback `"CA-7"` (NIST continuous-monitoring control) when no control is resolved;
  noted as SHOULD-be-de-hardcoded but currently baselined.
- Schema `status` enum mismatch: `schemas/dispositions/disposition-output.schema.json` declares
  `["completed","partial","rolled-back","abandoned"]` but code writes a different set in one path —
  reproduce the code's set, not the schema's.

### B.17 Routing (P10 W5/W6) — the 5 Python routers were RETIRED
"How routing works NOW (P10 W5 retired the 5 Python routers)": former hardcoded routers are gone;
routing is agentic via the NL/Action console (W6 `ACTION_SPECS` + `nl-action-policy.yaml`, §A.1
D19). Do not resurrect the retired routers.

### B.18 Build / CI environment gotchas (from `08-build-ci.md`, `00b-environment.md`)
- Full CI matrix runs **only on main-targeting PRs** and its logs are unavailable until the run
  completes — reproduce guards locally (`make validate-schemas`, `make validate-objectives`,
  `make check-*`).
- Against a secured API (`DEV_AUTH_BYPASS=false`, e.g. `olympus2`): mint service tokens FIRST
  (`make seed-tokens` → `.service-tokens.env`); `JWT_SECRET` must match the stack's
  `olympus-dev-secret`. Agent-runtime must present a token.
- Local `python3` is 3.9.6 (too old) — build `.venv` on 3.12 via `scripts/dev-setup.sh`; run tests
  with `AGENT_RUNTIME_MODE=mock APP_ENV=test`.
- Editable installs point at the PRIMARY checkout, not a worktree (`PYTHONPATH` gotcha).

---

## §C — TODO / FIXME / HACK / XXX in the primary tree

Sweep (excluding `build/lib`, `.claude/worktrees`, `node_modules`, `.venv`, `dist`, `__pycache__`):
**16 raw matches**; 11 are false positives (skill IDs/descriptions in `db/seeds/initial-data.sql`
that contain the substring "todo"/skill names, not actual markers). The genuine, actionable ones:

| File:line | Marker | What a rebuild must know |
|---|---|---|
| `olympus-api/src/services/source_intake.py:502` | TODO | Connector base raises `not yet implemented. TODO: {self.todo}` — the following four connectors are **stubs that raise**, not working intake sources |
| `olympus-api/src/services/source_intake.py:509` | TODO | **Confluence** connector: auth via Atlassian API token + email header; iterate pages — NOT implemented |
| `olympus-api/src/services/source_intake.py:524` | TODO | **SharePoint** connector: auth via Azure AD client credentials; Microsoft Graph — NOT implemented |
| `olympus-api/src/services/source_intake.py:539` | TODO | **Google Drive** connector: service account + domain-wide delegation — NOT implemented |
| `olympus-api/src/services/source_intake.py:554` | TODO | **GCS** connector: `google-cloud-storage` + application-default creds — NOT implemented |
| `dashboard/src/pages/GateReview/GateReview.tsx:301` | TODO | A TS cast is in place "so it works without further dashboard work. TODO: remove the cast once" a backend shape lands — parity = keep the cast |

No `FIXME`, `HACK`, or `XXX` markers exist in the primary source tree. (The `db/seeds/initial-data.sql`
"TODO" hits are inside seed skill descriptions such as `code-generation-cobol-to-java` and are NOT
code markers.)
