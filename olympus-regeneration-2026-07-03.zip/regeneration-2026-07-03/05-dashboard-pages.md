# 05 — Dashboard Pages (Part 1: ApplicationDetail + tabs)

Atomic regeneration spec. Behavioral parity target: an engineer must be able to
rebuild each page component so it behaves identically. All facts derived from live
code under `/Users/pnunna/Documents/GitHub/olympus/dashboard/src/pages`.

Stack: React 18 + `react-router-dom` (`useParams`/`useNavigate`/`useLocation`/`Link`),
`@trussworks/react-uswds` (USWDS components: `Alert`, `Button`, `Label`, `Tag`,
`TextInput`, `Textarea`), `sonner` `toast`, `recharts` for charts. API access is
via named async functions imported from `../../api/client` (documented in the
API-client spec). Chart theming via `useChartTheme()` hook returning `ct` with
keys `{muted, grid, text, primary, warning, series[], tooltipBg, tooltipText}`.

Parts:
- Part 1 (this file): `ApplicationDetail.tsx` + its 10 tab components.
- Part 2 (`05-dashboard-pages-part2.md`): Waves (WaveDetail, WaveManagement),
  Applications, PortfolioOverview.
- Part 3 (`05-dashboard-pages-part3.md`): Skills, Compliance, Admin, AssemblyLines,
  MyTasks, MyBundles, Analytics.

---

## ApplicationDetail.tsx (1059 LOC) — route `/applications/:id`

Tabbed application detail view with reorganized header, split edit actions,
per-line workflow controls.

### Params / hooks
- `id` from `useParams<{id}>` (:122). `navigate`, `location` (:123-124).
- `backLink = _readBackLink(location.state)` (:125). `_readBackLink` (:110-119):
  reads `state.from`; returns `{pathname, label}` only if both are non-empty
  strings, else `null`.
- `useBreadcrumbContext()` → `{setBreadcrumbContext, clearBreadcrumbContext}` (:185).
- `useWorkflowDetails(id)` → `{data: workflowDetails, error: workflowError,
  refresh: refreshWorkflow}` (:170-174) — polling hook for workflow control.

### State (:126-178)
- `app: AppDetail|null`, `status: ApplicationStatus|null`, `lineage:
  ApplicationLineageResponse|null`, `wave: WaveDetailType|null`, `loading=true`,
  `error:string|null`, `activeTab="insights"`.
- Edit: `editingInfo`, `editingRepos` (bool); `infoForm={name,description}`;
  `repoForm={repository_url,target_repo_url,target_git_token,target_git_base_url}`;
  `saving`.
- `reposExpanded=false`.
- Discovery: `discoveryResult: DiscoverResponse|null`, `discoveryLoading`,
  `startingLine: AssemblyLineName|null`, `routingLine: AssemblyLineName|null`.
- Workflow control: `detailsOpen`, `pendingAction:"cancel"|"retry"|"restart"|null`,
  `confirm: WorkflowAction|null`.

### Effects
1. Breadcrumb (:186-198): sets `{appName: app?.name, assemblyLine:
   status?.current_line ?? app?.current_line ?? null}`; cleanup clears context.
2. Primary load (:200-241): guard on `id`; `Promise.all([fetchApplicationDetail,
   fetchApplicationStatus])` → sets app+status; catch sets error; finally clears
   loading. THEN a SEPARATE try loads `fetchApplicationLineage` — GOTCHA: lineage
   is a secondary fetch inside the same async fn but its own try/catch so a 500 on
   `/lineage` does not block the page (badge silently omitted). `cancelled` flag
   guards all setState.
3. Wave fetch (:247-267): keyed on `app?.wave_id`; if no waveId → `setWave(null)`;
   else `fetchWaveDetail(waveId)`; failure → `setWave(null)` silently.
4. Discovery poll (:270-290): only while `app.status === "discovery_in_progress"`;
   `setInterval` every 3000ms re-fetches detail+status; ignores transient errors.
   GOTCHA: dep array is `[id, app?.status]` with eslint-disable — intentionally
   re-polls only when status changes.

### Key handlers
- `handleStartLine(lineName)` (:298-300): opens the routing dialog by setting
  `routingLine`. Every line start is a prompted decision (Phase 6 W1).
- `executeStartLine(lineName, delegation?)` (:311-356): sets `startingLine`; if
  `Discovery` also sets `discoveryLoading`. GOTCHA: Discovery still uses legacy
  `startDiscovery(id)` (returns `DiscoverResponse` with `temporal_ui_url`) to keep
  the onboarded→in-progress transition; any other line uses `startLineWorkflow(id,
  lineName, delegation)`. Toast success text differs when
  `delegation?.mode==="delegate"` ("delegated to a pair" + "claimable bundle
  created"). Toast `action` opens Temporal URL in new tab when present. After
  success re-fetches detail+status and calls `refreshWorkflow()`. finally resets
  loading flags.
- `handleStartDiscovery()` (:360-362): shim → `handleStartLine("Discovery")`.
- `runWorkflowAction(action)` (:364-394): action ∈ cancel|retry|restart. Sets
  `pendingAction`, clears `confirm`. cancel→`cancelWorkflow(id)` (toast "stop within
  30s"); retry→`retryWorkflow(id)` (toast `Retry started (${res.line})`);
  restart→`startDiscovery(id)` (toast "Restarted from Discovery"). Then re-fetch +
  refreshWorkflow. finally clears pendingAction.
- `startEditingInfo()` (:397-402): seeds infoForm from app, sets editingInfo.
- `handleSaveInfo()` (:404-427): builds `ApplicationUpdate` patch only for changed
  name/description; if empty patch just closes edit; else `updateApplication(id,
  patch)` → setApp(updated), toast success/error.
- `startEditingRepos()` (:430-441): seeds repoForm (token blanked), sets
  editingRepos + reposExpanded=true.
- `handleSaveRepos()` (:443-471): patch for changed repository_url,
  target_repo_url, target_git_base_url; `target_git_token` only added when
  truthy (blank = keep existing). Empty patch closes; else updateApplication.

### Render
- Loading → `role=status aria-busy` "Loading application..." (:473-479).
- error||!app → `Alert type=error` with message + Link "/" (:481-489).
- `overallScore = app.scores?.overall`; `hasRepos = repository_url ||
  target_repo_url` (:491-492).
- Back-nav (:503-520): if `backLink` → Link to backLink.pathname "← Back to
  {label}"; else if `location.key !== "default"` → button `navigate(-1)` "← Back";
  else Link "/" "← Back to Portfolio".
- `PhaseRibbon currentLine={status?.current_line ?? app.current_line ?? null}`
  (:526-529).
- `ConsolidatedBanner` when `app.status === "consolidated_into_target"`, passing
  first lineage target id/name (:539-544).
- Header row 1 (:548-599): `<h1 id="app-heading">{app.name}</h1>` + `StatusBadge` +
  `ApplicationDispositionChips appId fallbackDisposition showTargetServices`.
  Description `<p>` when not editing. `LineageBadge lineage`.
  `CapabilitySystemCallout targetSystems realizesCapability portfolioId={wave?.portfolio_id}`.
  Actions (Edit Info / Configure Repos buttons) shown only when not editing.
- Inline info edit form (:602-634): TextInput name + Textarea description; Save
  (disabled while saving) / Cancel.
- Metrics strip (:637-678): conditionally renders Risk Tier (with `Glossary`),
  Complexity (Glossary), Current Line (`Tag` with `line-tag--${lineKey(...)}`
  class; `lineKey` (:75-77) lowercases + replaces non-alpha with `-`), Current
  Step, Readiness (`Math.round(overallScore <= 1 ? overallScore*100 :
  overallScore)}%` — GOTCHA: dual-scale handling).
- Repos row (:681-803): if `hasRepos||editingRepos`: toggle button "Show/Hide
  Repositories" (▴/▾), expanded shows Source Repository + Modernization Target
  cards using `toAbsoluteRepoUrl()`. Edit form has two fieldsets (Source Repo,
  Modernization Target with Target URL / Git API Base URL / Access Token
  type=password placeholder "Leave blank to keep existing"). Else "No repositories
  configured. Configure now" inline button.
- Tech stack tags (:806-824): `Object.entries(app.tags)` → `{k}: {v}` chips.
- When `!discoveryResult && !editingInfo && !editingRepos` (:826-888): renders
  `NeedsAttentionBanner` (props: app,status,workflow=workflowDetails,
  onStartDiscovery, onRetry=()=>setConfirm("retry"), onCancel, onOpenDetails,
  onReviewGate/onViewReworkFeedback navigate to `/gates/{id}/review` with from-state,
  onResumeAfterRework, onViewWorkflow, busy), `OperationsStrip` (details,
  onDetails/onCancel/onRetry/onRestart, pendingAction, appStatus), `AppActionsPanel`
  (appId, appStatus, dataStatus, disposition, isTarget=`lineage?.sources?.length>0`,
  temporalUiUrl, onOpenDetails, onActionComplete re-fetches).
- `AgentActivityByLine` when `app.agent_activity_by_line.length>0` (:897-899).
- `TabNav tabs={TABS}` (:902). TABS (:79-95): insights, pipeline, decisions, scores,
  artifacts, duplication, traceability, impact, rationale, outcome.
- TabPanels (:904-1007): each `TabPanel id activeTab`. Notably:
  - pipeline→StatusTab with computed `target` (:933-957): GOTCHA — the
    Architecture/Data handoff target is computed only when this app's own
    disposition is `replace` or `consolidate` (self-target dispositions
    Rearchitect/Refactor/Replatform/Retain run in place; no handoff). Picks the
    lineage target edge with matching relationship and `related_app_id !== app.id`.
  - artifacts→ArtifactsTab lineage + targetRepoUrl.
  - duplication/impact/rationale/outcome get `active={activeTab===id}` to defer
    fetch.
- `WorkflowDetailsDrawer` (:1009-1023): open=detailsOpen, details, loading=
  `!workflowDetails && !workflowError`, error, onClose/onCancel/onRetry.
- `ConfirmModal` when `confirm` (:1024-1033): spreads `confirmContent(confirm,
  {line: workflowDetails?.current_line, graceSeconds:30})`, onConfirm→
  runWorkflowAction, onCancel clears.
- `WorkflowRoutingDialog` when `routingLine` (:1034-1046): submitting=
  `startingLine===routingLine`, onConfirm(delegation)→clears routingLine then
  `executeStartLine(line, delegation)`.

---

## ApplicationDetail tabs

### InsightsTab.tsx (609 LOC)
Props: `{appId, onStartDiscovery?, discoveryLoading?, onNavigateToArtifacts?}` (:36-41).
State: `data: InsightsResponse|null`, `error`, `loading=true`, `qualityRisk:
QualityRiskSummaryView|null` (:86-90).
Effects:
1. `fetchApplicationInsights(appId)` → data (:92-113).
2. Quality-risk (:118-141): `fetchApplicationGateEvidence(appId)` then walks
   packages calling `findQualityRiskArtifact(pkg.artifacts)`; first hit →
   `summarizeQualityRisk(found.data)`. All errors swallowed ("no data yet").
`findQualityRiskArtifact` (:50-78): returns first artifact whose
`artifact_type==="quality_risk"` or path ends `quality-risk.json`, checking nested
`supporting_artifacts` too.
Render: loading `role=status`; error → Alert. `showEmptyCta = !data.has_data &&
onStartDiscovery` → info Alert "No analysis yet" + Start Discovery button. Grid of 8
cards: Description; `ArchitectureCard`; Tech Stack (`Tag` per `data.tech_stack`);
Maturity (`MaturityTrendChart` per dim); `DecisionsCard`; `MetricsCard`;
`QualityRiskCard`; `LineProgressCard`. Each has a section-specific empty state
steering to the line that populates it.
- `ArchitectureCard` (:269-336): summary + Major components list + Integrations
  tags, each with own empty state; hasAny gates whole card.
- `DecisionsCard` (:338-391): dl of Disposition/Risk Tier (`Tier {n}`)/Complexity/
  Last changed; hasAny = any of disposition/risk_tier/complexity_tier set.
- `MetricsCard` (:393-433): test_coverage_pct, dependency_currency_pct (via
  `formatPct`), open/resolved escalations, agent_cost_to_date ($x.xx).
- `LineProgressCard` (:435-499): filters `status!=="not_started"`; shows table
  (Assembly Line/Status/Pending Gate/Last Event); shows "N not yet started" footer.
- `QualityRiskCard` (:501-586): dl of tier/debt score/modules/complexity breaches
  (`> 50`)/coverage below baseline/critical+high smells + top 3 drivers + "View full
  quality-risk evidence" button calling onNavigateToArtifacts.
- `formatPct(v)` (:598-609): GOTCHA triple-scale — `v<=1`→`v*100`; `v<=5`→`(v/5)*100`
  (ordinal 0-5 score); else `v`. Rounds. null→"—".

### StatusTab.tsx (204 LOC)
Props (:24-44): `{appId, appName, appStatus?, status: ApplicationStatus|null,
discoveryResult, discoveryLoading?, onStartDiscovery?, onRerunLine?, startingLine?,
wave?, target?}`.
State: `selectedLine = useState(status?.current_line ?? null)`;
`effectiveSelectedLine = selectedLine ?? status?.current_line ?? null` (:63-68).
Logic (:73-95): `lineWorkflows = status?.line_workflows ?? {}`; `hasLineWorkflows`;
`appLevelUrl = discoveryResult?.temporal_ui_url ?? status?.temporal_ui_url`. GOTCHA
(#249): temporal link follows selected line — if `effectiveSelectedLine &&
hasLineWorkflows` use `lineWorkflows[line]` (or hide if that line has no run — never
cross-route); else app-level URL. Label "View {line} in Temporal" vs "View in
Temporal".
Render: Temporal drill-through link (:103-114) shown whenever `temporalUrl`.
`WorkflowStepper` (:120-135) controlled via `selectedLine`/`onSelectLine`.
Gates section (:139-201): IIFE splits `status.gates` into openGates (status
pending|preparing) and decidedGates. GOTCHA (#271): decided gates collapsed to the
LATEST decision per `gate_type` via a Map keyed by gate_type, comparing
`decided_at` timestamps (missing → 0). Renders `GateCardList` for open ("Awaiting
review") then decided; onReview navigates to `/gates/{gateId}/review` with from-state
`{pathname:/applications/{appId}, label:appName}`.

### ScoresTab.tsx (295 LOC)
Props: `{appId, scores: ReadinessScores|null}` (:33-36).
State: `apiScores: ReadinessScoreEntry|null`, `history: ScoreHistoryEntry[]` (:49-50).
Effect (:52-67): `Promise.all([fetchReadinessScores({appId}), fetchScoreHistory(appId)])`;
`apiScores = scoresRes.find(app_id===appId)`; catch falls back to prop scores.
Memos: `effectiveScores` (:70-84) prefers apiScores, else builds from `scores` prop.
`hasAnyDimension` (:91-99) — true if any of 6 DIMENSION_LABELS keys non-null.
GOTCHA (P5-AUDIT-009): previously coerced null dims to 0 producing a collapsed radar;
now detects aggregate-only case. `radarData` (:101-109) built only when hasAnyDimension,
maps each dim `Math.round(v*100)`. `aggregateOnly` (:114-117) = overall set but no
dims. `historyData` (:120-129): groups history by `toLocaleDateString`, per-dimension
`Math.round(score*100)`.
DIMENSION_LABELS (:38-45): code_quality→Code Quality, test_coverage→Test Coverage,
security_posture→Security, documentation→Documentation, dependency_currency→
Dependencies, architecture_clarity→Architecture.
Render: `!effectiveScores`→"Scores will be available after Discovery...". aggregateOnly
banner. 2-col grid: RadarChart (recharts, domain 0-100) or muted message; Score
Breakdown with `ScoreBar` for Overall then 6 dims (or aggregate-only note). Score
History LineChart (one `Line` per dimension, `ct.series[i % len]`) or empty state.

### TraceabilityTab.tsx (305 LOC)
Props: `{appId}` (:26-28).
State: `coverage: TraceabilityCoverage|null`, `links: TraceabilityLink[]`, `issues:
CrossValidationIssue[]`, `structural: StructuralAnalysis|null`, `loading=true` (:32-40).
Effect (:42-62): `Promise.all` of `fetchTraceabilityCoverage/.catch(null)`,
`fetchTraceability/.catch([])`, `fetchCrossValidation/.catch([])`,
`fetchStructuralAnalysis/.catch(null)`. Guards non-array for links/issues
(P5-AUDIT-001).
Memo `artifactSuggestions` (:67-75): Set of all source/target artifact paths from
links (kept above early returns for stable hook order).
Coverage compat (:90-109): GOTCHA — live backend returns
`{coverage_pct,total_artifacts,traced_artifacts}` but mocks/old drafts return
`{forward_coverage,backward_coverage,total_items,traced_items}`. Reads both families:
`forwardCoverageValue = forward_coverage ?? coverage_pct/100`, etc.
`coverageHasData` true if any of the 4 values non-null.
`structuralModules` from `structural.modules`; `mermaidSource` from trimmed
`structural.mermaid`.
Empty state when `!coverageHasData && !hasLinks && !hasIssues && !hasStructural`.
Render: 4-col coverage cards (Forward/Backward %, Total/Traced Items); Module
Dependencies section (`MermaidBlock` + `ModuleMapViewer`) or empty; Trace Links table
(first 50 of N; "Showing 50 of N"); `TraceabilityExplorer appId artifactSuggestions`;
Cross-Validation Issues table (severity via StatusBadge / type / source / detail).

### ArtifactsTab.tsx (818 LOC)
Props: `{appId, lineage?: ApplicationLineageResponse|null, targetRepoUrl?: string|null}`
(:45-60).
State: `renditions: RenditionItem[]`, `gateGroups: GateArtifactGroup[]`, `sourceIndex:
SourceArtifactsIndex|null`, `loading=true`, `generating: RenditionType|null`, `error`,
`expandedArtifact: string|null`, `dispatchFocus: {gateId, artifact}|null` (:111-124).
Effect (:126-175): `Promise.allSettled([fetchRenditions, fetchApplicationGateEvidence,
fetchSourceArtifactsIndex])`. GOTCHA (#260): single batched gate-evidence call instead
of status-then-fanout. Builds one `GateArtifactGroup{gateId,gateType,assemblyLine,
artifacts}` per package that has artifacts.
`handleGenerate(type)` (:177-209): `generateRendition(appId,{rendition_type})` returns
a pending row; then polls `fetchRenditions` up to `MAX_POLLS=30` at 2000ms (~60s) until
that id's status !== "pending"; on "failed" sets error. GOTCHA: bounded poll so a stuck
render can't spin forever.
Memos: `isTarget = (lineage?.sources.length ?? 0) > 0` (:218-221). Partition (:228-239)
gate groups by `isTargetStateLine(assemblyLine)` where TARGET_STATE_LINES = {Architecture,
Data, Modernization} (:69-77) → sourceStateGroups / targetStateGroups.
`renderGroup(group)` (:256-394): header (assemblyLine + gate name via `getGateName` +
gate type + "View gate review" Link to `/gates/{gateId}/review` with from-state), then per
artifact an expandable card: toggle button (title/type/vN), "Which skill produced this?"
button opening `SkillDispatchExplorer` (via setDispatchFocus, `e.stopPropagation()`),
expanded body `ArtifactViewer` (error-boundary-wrapped) + `SupportingArtifactsList`.
Render: error Alert. Source Materials section when `sourceIndex.source_apps.length>0`
(peer links to each source app's discovery/rationalization counts). If `isTarget`: two
cards Source State Artifacts / Target State Artifacts each with own empty states (source
falls back to lineage source links when no groups). Else single "Assembly Line Artifacts"
card. Generate Renditions card (RENDITION_TYPES :87-103: requirements_doc,
architecture_deck, test_report) — per type shows StatusBadge if exists + Generate/
Regenerate button. Generated Documents table (type/generated_at/expandable content).
Final empty state suppressed for target apps.

### UserImpactTab.tsx (414 LOC)
Props: `{appId, appName, waveId: string|null, active?=true}` (:153-159).
State: `artifact: UserImpactArtifact|null`, `loading=false`, `error`, `absent=false`
(:172-175).
Effect (:177-226): guard `!active || !waveId`; `fetchWaveArtifact(waveId,
"{appId}/user-impact-analysis.json")`; res===null→`setAbsent(true)`;
`normalizeUserImpactArtifact(res.data)` (:68-151, exported, defensive: coerces personas
with default transition_risk="medium", disruption_profile severity default "medium",
cutover_model whitelist, accessibility_regressions). Sets loading before load.
Render branches: `!waveId`→info Alert "No wave assigned"; loading; error Alert;
`absent||!artifact`→info "No user impact analysis yet" (mentions Retire/Replace/
Consolidate). Else: 3 headline cards (Affected Users across N personas, Disrupted
Journeys, Training Burden `{h}h`); Disruption Profile dl (severity colored via
RISK_TONES low=#00a91c/medium=#e5a000/high=#d83933, cutover model, duration weeks,
fallback Yes/No); Persona table (name/headcount/journeys affected/transition risk
colored); Accessibility Regressions list (WCAG criterion + severity + description) or
"No accessibility regressions".
`formatNumber` (:161-164): null→"—" else `toLocaleString()`.

### DecisionsTimeline.tsx (254 LOC)
Props: `{appId}` (:25-27).
State: `data: DecisionsTimelineResponse|null`, `agentEntries: DecisionEntry[]`, `error`,
`loading=true`, `activeKinds: Set<kind>` (init all), `expanded: Set<string>` (:68-75).
Effect (:77-111): `fetchApplicationDecisions(appId)`→data; then best-effort
`fetchAuditLog({event_type:"agent_action"})` mapped via `auditEventToEntry`
(:48-65 — id `agent-action-{target}-{occurred_at|index}`, kind agent_action,
actor_kind default human_with_agent). 403 (non-admin) → empty agentEntries.
Memos: `allEntries` (:113-120): merge base + agentEntries, sort newest-first.
`filtered` (:122-124): filter by activeKinds.
KIND_LABELS (:29-36): gate→Gates, disposition→Disposition, risk→Risk, escalation→
Escalations, rework→Rework, agent_action→Agent-assisted. ALL_KINDS (:38-45).
`toggleKind`/`toggleExpanded` mutate Sets immutably.
Render: filter chips toolbar (aria-pressed); ordered list `<ol>`. Each item: colored
marker `--{kind}`; expandable title button (Enter/Space via button). Agent-action
rows render `ActorKindBadge labelOverride="Agent-assisted"` instead of `Tag`. Detail
reveals actor/status/gate_type/detail.

### InternalDuplicationTab.tsx (328 LOC)
Props: `{appId, waveId: string|null, active?=true}` (:93-98).
State: `artifact: ReturnType<normalizeArtifact>`, `loading=false`, `error`, `absent`
(:105-110).
Effect (:112-161): guard `!active||!waveId`; `fetchWaveArtifact(waveId,
"{appId}/intra-app-redundancy.json")`; null→absent; `normalizeArtifact(res.data)`.
`normalizeArtifact` (:64-91, exported): accepts `duplicate_clusters` OR `clusters` alias;
coerces cluster_id default `cluster-{idx}`, filters non-object occurrences.
Render branches: `!waveId` info; loading; error; absent/!artifact info "No duplication
report yet"; `clusters.length===0`→success "No internal duplication detected". Else:
header count + totalOccurrences (`summary.total_occurrences ?? sum of occurrences`);
list of cluster cards each with description, kind tag (uppercase, `_`→space),
`<details>` occurrences (location as `<code>`, snippet as `<pre>`), suggested
consolidation note.

### OutcomeTab.tsx (784 LOC)
Props: `{appId, active, onOpenArtifact?}` (:39-46).
State: `bundle: DispositionOutputBundle|null`, `loading=false`, `err:
DispositionOutputError|null` (:49-51).
`load` (:53-75): `fetchDispositionOutput(appId)`; catches `DispositionOutputError`
(else wraps in `new DispositionOutputError("UNKNOWN",0,msg)`).
Effect (:77-80): fetches only when `active`.
Render branches: `!active`→null; loading; err by code:
`DISPOSITION_OUTPUT_NOT_EMITTED`→friendly "Outcome not yet available";
`APP_NOT_FOUND`→"Application not found"; `PORTFOLIO_NOT_CONFIGURED`→config message;
else `err.message`. `!bundle`→"No outcome bundle". Else renders `EnvelopeHeader` +
`ImpactTiles` + `PayloadCard`.
- `EnvelopeHeader` (:150-213): app name + disposition chip (class
  `outcome-disposition--{lc}`), Completed date, Duration `~{days} day(s)` computed
  `max(1, round((completed-started)/86400000))`, Wave `{id.slice(0,8)}…`, status
  badge, approvals count + list.
- `ImpactTiles` (:219-274): Annual savings (`formatUsd`), One-time cost, Users
  affected — each via `ImpactTile` showing "not reported" when null. `formatUsd`
  (:276-282): `toLocaleString("en-US",{style:currency,USD,maxFractionDigits:0})`.
- `PayloadCard`→`PayloadBody` (:302-319) switches on `payload.disposition`:
  Retire/Retain/Refactor/Rearchitect/Replace/Replatform/Consolidate → dedicated Body.
  GOTCHA: `RearchitectBody` (:557-577) renders `RefactorBody` (casting payload to
  Refactor shape) + a bounded-context-map ref. `Ref` helper (:323-360): null path→
  muted "n/a"; with onOpen→button calling onOpen(path); else span with title=path.
  Each Body renders a `<dl>` of labeled artifact refs (see file for exact field
  layout per disposition — decommission cert, migration reports, coverage before/
  after, vendor eval, perf/cost deltas, features ported/dropped table, etc.).

### RationaleTab.tsx (495 LOC)
Props: `{appId, active}` (:25-29).
State: `rationale: ApplicationRationale|null`, `loading=false`, `error` (:32-34).
`load` (:36-50): `fetchApplicationRationale(appId)`. Effect fetches only when active.
Render branches: `!active`→null; loading; error `role=alert`; `!rationale`→"No
rationale"; `!rationale.is_target`→"Not a rationalization target" empty
(data-testid=rationale-empty); `sources.length===0`→"No source applications
recorded". Else header ("N source applications fed into this target... G-DC → G-RR →
G-DA") + one `SourceCard` per source.
- `SourceCard` (:163-237): source app Link + disposition badge + relationship tag,
  then `GateChain` + `ArtifactList`.
- `GateChain` (:243-295): table Gate/Status/Decided/By/Reason/Justification; empty →
  "No gates recorded". `GateRow` (:297-365): gate_type `<code>`, status colored
  (approved green / rejected red), decided_at localeString, decided_by, reason_category
  chip, `JustificationCell` + evidence link. `JustificationCell` (:368-394): truncates
  at 120 chars with show more/less toggle.
- `ArtifactList` (:400-495): per artifact a link
  `/api/v1/artifacts/{sourceAppId}/?path={encodeURIComponent(path)}` + kind tag + path
  `<code>`. Empty → "No supporting artifacts linked".
