# 14 — Capabilities Service, NL Action Console, Autonomy-Gating Runtime

> ATOMIC regeneration spec. Repo root: `/Users/pnunna/Documents/GitHub/olympus`.
> Everything below is derived from LIVE code at that path (branch `main`, 2026-07-03). Rebuild to BEHAVIORAL PARITY: reproduce HOW, not WHAT.
> Citations are `path:line`; when a file is named at a section head, a bare `(:NN)` refers to that file.
> Excludes stale trees (`build/lib/`, `.claude/worktrees/`, `node_modules/`, `.venv/`, `dist/`, `__pycache__/`).
>
> This file covers three subsystems added since the prior spec:
> 1. **Capabilities Service** (P9-W18) — tiered single-skill dispatch (`bare`/`provenance`/`verified`).
> 2. **NL Action Console** (P10-W6) — plan+execute conversational actions under the user's token.
> 3. **Autonomy-Gating Runtime** (P9/P10-S18) — the RUNTIME view of the 4 executor cron workflows and the autonomy gate. The POLICY MODEL lives in `07-framework.md`; workflow shells in `03-workflows/`. This section captures how they OBTAIN and ENFORCE the decision.

---

# PART 1 — CAPABILITIES SERVICE (P9-W18)

A "capability service" wraps the EXISTING standalone single-skill dispatch (`dispatch_via_a2a` → `POST /a2a/tasks`) as a product endpoint: validated inputs, the right skill chosen for the caller, the schema'd artifact returned, and a caller-chosen **provenance tier**. It adds NO new dispatch mechanism — everything routes through the one canonical single-skill path.

Files:
- Contract: `olympus-contracts/olympus_contracts/capability_types.py`
- Service: `olympus-api/src/services/capabilities/{service,provenance,verification,defaults,run_event,store,models,allowlist}.py`
- Router: `olympus-api/src/routers/capabilities.py`

## 1.1 The contract types — `capability_types.py`

### `ProvenanceTier` (StrEnum) (:39-62)
```
BARE = "bare"; PROVENANCE = "provenance"; VERIFIED = "verified"
```
- Ordered ASCENDING by strength; each tier is a STRICT SUPERSET of the one before (:44-46).
- Is a `enum.StrEnum` (:39) SPECIFICALLY so Temporal's default payload converter round-trips it across workflow boundaries (the converter special-cases StrEnum) (:48-52).
- GOTCHA: it is a run DIMENSION, NOT a `GateType` member — INVARIANT-GUARD (:52-53). Adds no gate/tier/disposition/line/provider enum member.

### `CapabilityRequest` (frozen dataclass, slots) (:65-96)
Fields: `capability: str`; `inputs: dict[str,object] = {}`; `tier: ProvenanceTier = BARE`; `skill_id_override: str|None`; `profile_id: str|None`; `owner: str|None` (:91-96).
- GOTCHA: `frozen=True` freezes BINDINGS, not the mutable `inputs` dict it points at — held by reference, NOT deeply immutable; treat read-only by convention (:80-84).

### `CapabilityResult` (frozen dataclass, slots) (:99-132)
Fields: `run_id`, `capability`, `tier`, `artifact_ref`, `skill_id`; then all-`None`-default provenance fields `work_log_ref`, `evidence_content_hash`, `verified: bool|None`, `verifier_verdict: str|None`, `metadata: dict={}` (:123-132).
- `verified is None` ⇒ "no verification ran"; distinct from `verified is False` (verifier ran and did NOT pass — fail-closed, never a false "verified") (:116-120).

> NOTE: the HTTP edge does NOT use these frozen dataclasses directly — it mirrors them with pydantic models (`models.py`). The frozen dataclasses stay the single cross-package source of truth; the pydantic models sit additively on top.

## 1.2 HTTP-edge models — `capabilities/models.py`

### `CapabilityRunRequest(BaseModel)` (:26-82)
- `capability: str = ""` (:55) — ignored by the two named endpoints (they overwrite it server-side).
- `inputs: dict[str,object] = {}` (:59).
- `tier: ProvenanceTier | None = None` (:63) — GOTCHA: OPTIONAL. `None` = "unspecified" (picks up per-capability default); an explicit `bare` is DISTINCT from `None` and is honored verbatim (:37-47, 64-70).
- `skill_id: str | None = None` (:71) — pins exact skill, bypassing capability→skill resolution.
- `app_id: str | None`, `profile_id: str | None` (:75-82).

### `CapabilityRunResponse(BaseModel)` (:85-138)
Required: `run_id`, `capability`, `tier: ProvenanceTier`, `skill_id`, `status: str` (:114-118).
Defaulted: `artifact_refs: list[str]=[]`, `artifact_files: list[dict]=[]`, `error: str=""`, `profile_id: str|None=None`, and provenance siblings `work_log_ref=None`, `evidence_content_hash=None`, `verified: bool|None=None`, `verifier_verdict: str|None=None`, `output_schema_validated: bool|None=None`, `output_schema_errors: tuple[dict[str,str],...]=()` (:119-137).

## 1.3 The router — `routers/capabilities.py`

Prefix `/api/v1/capabilities`, tag `Capabilities` (:93). FOUR endpoints.

GOTCHA (path disambiguation) (:14-20): the read is `/capabilities/runs/{run_id}`, NOT `/capabilities/{run_id}`. The single-segment `/api/v1/capabilities/{capability_id}` (UUID) is ALREADY owned by the Phase-5 systems router mounted first; a bare `/capabilities/{run_id}` would be shadowed. The `/runs/` segment keeps it collision-free.

### Role sets
- `CAPABILITY_RUN_ROLES` (:72-78) = `[TECH_LEAD, ARCH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN, SERVICE]`. VIEWER deliberately EXCLUDED (a viewer cannot run a capability).
- `CAPABILITY_READ_ROLES` (:81-91) = broad set incl. `VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN, SERVICE`.

### Shared handler `_run_capability(request, actor, *, enforce_allowlist=False, db=None)` (:96-136)
- Instantiates `CapabilityService(db=db)` (:124), calls `svc.run(request, actor=actor, enforce_allowlist=enforce_allowlist)` (:126-128).
- Maps errors: `CapabilityNotAllowlistedError` → `OlympusHTTPException(403, "CAPABILITY_NOT_ALLOWLISTED", …)` (:129-132); `CapabilityResolutionError` → `(400, "CAPABILITY_UNRESOLVABLE", …)` (:133-136). Allowlist mapped ahead of resolution because it is raised first (no dispatch on rejection).

### Endpoints
1. `POST /generate-architecture` (:139-171). Deps: `require_role(*CAPABILITY_RUN_ROLES)`, `get_current_user`, `get_db`. Body arrives, then **overwrites** `body.capability = "generate-architecture"` (:170) (ignores any body value), calls `_run_capability(body, actor=user.sub, db=db)` (:171) — `enforce_allowlist=False`.
2. `POST /extract-business-rules` (:174-208). Same shape; overwrites `body.capability = "extract-business-rules"` (:207).
3. `POST /run` (generic) (:211-244). Calls `_run_capability(body, actor=user.sub, enforce_allowlist=True, db=db)` (:242-244) — **the only endpoint that enforces the allowlist**.
4. `GET /runs/{run_id}` (:247-273). Deps: `require_role(*CAPABILITY_READ_ROLES)`. `svc = CapabilityService()` (no db), `svc.get_run(run_id)`; `None` → `OlympusHTTPException(404, "CAPABILITY_RUN_NOT_FOUND", …)` (:267-272).
- GOTCHA: actor is ALWAYS `user.sub` from the authenticated principal, NEVER from the body (:36, 171, 208).

## 1.4 The service — `capabilities/service.py`

### `CAPABILITY_SKILL_MAP` (:99-102)
```
{"generate-architecture": "target-architecture-blueprint",
 "extract-business-rules": "extraction"}
```
GOTCHA: must be defined ABOVE any import of `.allowlist` (allowlist imports THIS constant → cycle avoided by ordering) (:96-98, 44 in allowlist.py).

Module constants: `_A2A_AGENT_BASE_URL = os.environ.get("A2A_AGENT_BASE_URL", "")` read at IMPORT (:108); `_CAPABILITY_TASK_TYPE = "capability"` (:113).

### `bare_artifact_projection(result) -> dict` (:116-142) — LOAD-BEARING
The SINGLE definition of the `bare`-tier artifact contract (S18.3 byte-parity). Returns EXACTLY:
```
{"artifact_refs": list(result.output_artifacts),
 "artifact_files": [{"path": f.path, "content": f.content, "encoding": f.encoding}
                    for f in result.output_files]}
```
- Adds ZERO provenance/evidence fields, mutates nothing, no reorder (:124-127).
- GOTCHA: the dict key ORDER `path`→`content`→`encoding` (:139) is PART of the contract the serialized byte-level parity test (`test_capability_bare_parity`) pins. A change that sneaks a field, drops/reorders one, or mutates diverges from a direct `POST /a2a/tasks` dispatch and FAILS the parity test (:128-134).

### `opportunistic_output_schema_validation(skill_id, result) -> (bool|None, tuple[dict,...])` (:145-214) — S18.9, ADVISORY
Activates the platform's normally-DORMANT skill artifact-schema validation on the standalone/API path. Reuses `validate_return_output_payload` (the SAME mechanism `/agent-tasks/{id}/return` uses) — does NOT reimplement JSON-Schema (:150-156). Branches:
1. `if not skill_id:` → `(None, ())` (:177-178).
2. `declared = load_output_schemas_for_skill(skill_id)`; `if not declared:` → `(None, ())` — the DORMANT path preserved: skill declares no `output_schemas` → skip exactly as before (:182-184).
3. `declared_paths = {entry["path"] for entry in declared}` (:186). For each `file in result.output_files` (:190):
   - `if file.path not in declared_paths: continue` (:191-192).
   - `parsed = json.loads(file.content)`; on `(ValueError, TypeError)` → `continue` (record "not validated", not a spurious failure) (:193-199).
   - `if not isinstance(parsed, dict): continue` (:200-201).
   - Else run `validate_return_output_payload(skill_id=…, output_payload=parsed, payload_path=file.path)` and `return (not violations), tuple(violations)` (:205-210). `payload_path` pins the exact schema entry.
4. Schema declared but no matching parseable structured artifact → `(None, ())` (:212-214).
- Result recorded on `output_schema_validated`/`output_schema_errors` SIBLING fields ONLY; never folded into artifact (S18.3 preserved) (:170-173). NEVER a hard gate.

### Errors
- `CapabilityResolutionError(ValueError)` (:217-224) → 400.
- `CapabilityNotAllowlistedError(ValueError)` (:227-239) → 403; raised BEFORE any dispatch.

### `CapabilityService` (:242-677)
Constructor `(*, registry=None, store=CAPABILITY_RUN_STORE, agent_url=_A2A_AGENT_BASE_URL, db=None)` (:245-264). `db` typed `object` so importing the module never forces a SQLAlchemy import on the bare path (:257-264). `_registry_or_default()` lazy-loads `get_registry()` (:266-268).

#### Skill-knownness — `_skill_is_known(registry, skill_id)` (:270-287)
True iff `registry.find(skill_id) is not None`, OR `skill_id` matches any `skill.variants[].id` across `registry.skills` (:281-286). GOTCHA: variants (e.g. `extraction-java`) dispatch under their OWN id and each have a SKILL.md dir — a caller pinning a variant is legitimate and must validate as known (mirrors `skill_registry._build_dispatch_to_dir`) (:272-280).

#### `_capability_exposes_skill(registry, capability, skill_id)` (:289-318)
`base = CAPABILITY_SKILL_MAP.get(capability)`; `if base is None: return False` (a made-up capability can never expose a skill) (:308-310). True if `skill_id == base` (:311-312) OR `skill_id` matches a variant id of `base_entry` (:313-318). This is the SECOND allowlist door.

#### `_enforce_allowlist(request)` (:320-358) — S18.4, REQ-CAP-007
Applied by `run` on the generic path BEFORE resolution/dispatch. Local import `from …allowlist import is_capability_allowlisted` (avoids cycle) (:336). TWO gates:
- **Reject 1**: `if not is_capability_allowlisted(capability): raise CapabilityNotAllowlistedError(…"is not on the generic-runner allowlist"…)` (:339-345). NO dispatch.
- **Reject 2**: `resolved = request.skill_id or CAPABILITY_SKILL_MAP.get(capability, capability)` (:350-352); `if not self._capability_exposes_skill(registry, capability, resolved): raise CapabilityNotAllowlistedError(…"is not exposed by the allowlisted capability"…)` (:353-358). Blocks a raw `skill_id` reaching an arbitrary internal skill under cover of an allowlisted capability name.

#### `_resolve_skill_id(request)` (:360-389)
`candidate = request.skill_id or CAPABILITY_SKILL_MAP.get(request.capability, request.capability)` (:376-378). Precedence: explicit `skill_id` wins → map lookup → treat capability AS a skill id directly. `if not candidate: raise CapabilityResolutionError("No capability or skill_id supplied…")` (:379-382). Then `if not self._skill_is_known(registry, candidate): raise CapabilityResolutionError(f"…resolved to skill {candidate!r}, which is not in the skill registry.")` (:384-388). Allowlist-AGNOSTIC (the gate is upstream in `run`) so the named endpoints reuse it unchanged (:369-374).

#### `_effective_tier(request)` (:391-416) — S18.8, REQ-CAP-012 (tier-selection branch)
```
if request.tier is not None:
    return request.tier                      # explicit ALWAYS wins (incl explicit bare)
return resolve_default_tier(request.capability)   # per-capability default
```
(:414-416). Returns a CONCRETE tier (never None).

#### `_mint_run_id(run_id)` (:418-426): `return run_id or str(uuid.uuid4())` — injectable for deterministic/idempotency tests.

#### `run(request, actor, *, run_id=None, enforce_allowlist=False)` (:428-644) — THE ORCHESTRATION
Exact ordering (branches reproduced, none collapsed):
1. `if enforce_allowlist: self._enforce_allowlist(request)` (:467-468) — FIRST, before resolve/dispatch (REQ-CAP-007: no dispatch on rejection).
2. `skill_id = self._resolve_skill_id(request)` (:470).
3. `resolved_run_id = self._mint_run_id(run_id)` (:471).
4. `tier = self._effective_tier(request)` (:478).
5. `task_input = AgentTaskInput(task_type="capability", app_id=request.app_id or "", skill_id=skill_id, context=dict(request.inputs))` (:480-485).
6. Log `capability_run_dispatch` with `tier_source = "explicit" if request.tier is not None else "default"` (:487-495).
7. **Dispatch**: `result = await dispatch_via_a2a(self._agent_url, task_input)` (:499) — the single canonical single-skill path. On bare, the result IS the response; no provenance code runs.
8. `artifact = bare_artifact_projection(result)` (:505).
9. `(output_schema_validated, output_schema_errors) = opportunistic_output_schema_validation(skill_id, result)` (:513-516); if `is False` log `capability_output_schema_advisory_mismatch` (:517-523).
10. Build `CapabilityRunResponse(...)` with `status=result.status.value`, artifact fields from projection, all provenance siblings seeded `None`, `verified=None`, advisory fields set (:525-549).
11. **PROVENANCE branch**: `if tier is not ProvenanceTier.BARE:` (:551) — lazy `from …provenance import attach_provenance` (:560); `attachment = await attach_provenance(run_id=…, capability=…, skill_id=…, tier=…, result=…, artifact_refs=artifact["artifact_refs"], inputs=dict(request.inputs), profile_id=…, app_id=…, actor=actor, db=self._db, portfolio_id=self._resolve_portfolio_id(request))` (:562-575); then `response.work_log_ref = attachment.work_log_ref; response.evidence_content_hash = attachment.evidence_content_hash` (:576-577). Writes SIBLING fields only.
12. **VERIFIED branch**: `if tier is ProvenanceTier.VERIFIED:` (:579) — lazy `from …verification import run_verifier_pass` (:596); `verification = await run_verifier_pass(run_id=…, capability=…, skill_id=…, result=result)` (:598-603); `response.verified = verification.verified; response.verifier_verdict = verification.verdict` (:604-605). GOTCHA: the maker has NO path to `verified=True` — seeded `None` at :542, this pass is the SOLE writer.
13. **RUN EVENT branch**: `if self._db is not None:` (:617) — lazy `from …run_event import emit_capability_run_event` (:618-620); `await emit_capability_run_event(run_id=…, …, tier=tier, status=result.status.value, inputs=dict(request.inputs), work_log_ref=response.work_log_ref, evidence_content_hash=response.evidence_content_hash, …, db=self._db)` (:622-634); then `await self._commit_run_event()` (:641). Emitted on EVERY tier (a bare run reports its run too, with `None` provenance refs).
14. `self._store.record(response)` (:643); `return response` (:644).

`_commit_run_event()` (:646-657): `try: await self._db.commit()` except → log `capability_run_event_commit_failed` and SWALLOW (best-effort; never break the run).

`_resolve_portfolio_id(request)` (:659-673): `value = request.inputs.get("portfolio_id")`; `return value if isinstance(value, str) and value else None`. GOTCHA: the request has NO dedicated `portfolio_id` field — the portfolio scope for evidence is carried inside the structured `inputs["portfolio_id"]`. Absent/non-string → provenance degrades (evidence skipped, work-log still produced) (:659-673).

`get_run(run_id)` (:675-677): `return self._store.get(run_id)`.

## 1.5 The generic-runner allowlist — `capabilities/allowlist.py`

```
CAPABILITY_ALLOWLIST: frozenset[str] = frozenset({"generate-architecture", "extract-business-rules"})   # (:56-61)
```
- GOTCHA: keyed on CAPABILITY NAME, not skill id (:11-21). Keying on capability + requiring the resolved skill to be one the capability exposes bounds BOTH doors and stays stable as skills gain variants.
- GOTCHA: a MODULE-LEVEL constant, NOT profile DATA (:23-32) — the product surface is uniform across profiles (contrast the autonomy `auto_merge_allowlist` which IS profile DATA).
- INVARIANT-GUARD assert at IMPORT: `assert set(CAPABILITY_SKILL_MAP).issubset(CAPABILITY_ALLOWLIST)` (:67-69) — every named-endpoint capability MUST be allowlisted; an edit adding a named capability but forgetting the allowlist trips at import.
- `is_capability_allowlisted(capability) -> bool: return capability in CAPABILITY_ALLOWLIST` (:72-74).

## 1.6 Per-capability defaults — `capabilities/defaults.py`

```
CAPABILITY_DEFAULT_TIER: dict[str, ProvenanceTier] = {
    "generate-architecture": ProvenanceTier.BARE,
    "extract-business-rules": ProvenanceTier.PROVENANCE,
}                                                              # (:81-87)
_UNKNOWN_CAPABILITY_DEFAULT_TIER = ProvenanceTier.BARE          # (:94)
```
`resolve_default_tier(capability) -> ProvenanceTier: return CAPABILITY_DEFAULT_TIER.get(capability, _UNKNOWN_CAPABILITY_DEFAULT_TIER)` (:97-108).
- Rationale: architecture is exploratory (`bare` floor); extraction is FOUNDATIONAL (downstream trusts it → `provenance` floor) (:23-33). Unknown allowlisted capability → `bare` (safest/cheapest; makes NO unearned provenance claim) (:34-44).
- OPEN OWNER FORK (:46-56, 77-80): to hard-default extraction to `verified` for accredited engagements, change the ONE map value from `PROVENANCE` to `VERIFIED` — nothing else in service/router moves. Deliberately isolated here.

## 1.7 Provenance attach — `capabilities/provenance.py` (PROVENANCE tier body, S18.5)

Runs everything `bare` does + additively produces two artifacts, writes SIBLING fields only.

### Constants (:89-112)
- `_WORKLOG_DIR_ENV = "OLYMPUS_CAPABILITY_WORKLOG_DIR"`, `_WORKLOG_FILENAME = "work_log.json"`, `_CAPABILITY_TASK_TYPE = "capability"`.
- `_ASSESSED_BY_SKILL = "capability-provenance"`; `_DEFAULT_CONTROL_ID = "CA-7"`; `_DEFAULT_CATALOG_ID = "nist-800-53"`.
- Verifier-provenance signature (maker≠verifier, REQ-WL-005): `_META_REVIEW_SIG = "review_sig"`, `_SIGNING_KEY_ENV = "OLYMPUS_WORKLOG_SIGNING_KEY"`, `_DEFAULT_SIGNING_KEY = "olympus-worklog-verifier-provenance-v1"`. GOTCHA: BYTE-IDENTICAL mechanism/key/default/canonical payload to `olympus-agent-runtime/src/services/worklog.py` — kept in lockstep intentionally so a reader/verifier in EITHER package validates the other (:103-112).

### maker≠verifier signature machinery (REQ-WL-005)
- `_signing_key() -> bytes` reads env or default (:144-146).
- `_review_payload(run_id, skill, outcomes) -> bytes`: `json.dumps({"run_id","skill","outcomes":list(outcomes)}, sort_keys=True, separators=(",",":")).encode()` (:149-160) — binds the verdict to run identity + exact outcomes.
- `_sign_review(log) -> str`: `hmac.new(_signing_key(), _review_payload(log.run_id, log.skill, tuple(log.outcomes)), hashlib.sha256).hexdigest()` (:163-169).
- `review_is_verifier_authored(log) -> bool` (:172-185): `if not log.outcomes: return False`; `stored = log.metadata.get(_META_REVIEW_SIG)`; `if not isinstance(stored,str) or not stored: return False`; `return hmac.compare_digest(stored, _sign_review(log))`. Empty outcomes or maker-written (no valid sig) → False.
- `_author_verifier_review(log, verdict, *, author="verifier") -> WorkLog` (:188-223): the ONLY writer of `outcomes`. `if author != "verifier": raise ProvenanceVerifierAuthorshipError(…)` (:199-204) — the maker structurally cannot grade its own work. Appends verdict, mints a FRESH signature over the NEW outcomes (via a `signed_probe` WorkLog) (:205-212) so a maker cannot lift a valid signature and pair it with different self-authored outcomes; returns a new frozen WorkLog (input not mutated).

### Work-log build + persist
- `work_log_ref_for(run_id, *, base_dir=None) -> str` (:239-248): `<base_dir>/<run_id>/capability/work_log.json` — deterministic PURE path; rediscoverable from run id alone (no DB). base_dir from `OLYMPUS_CAPABILITY_WORKLOG_DIR` or `tempfile.gettempdir()/olympus-capability-worklogs` (:226-236).
- `_inputs_hash(inputs) -> str` (:266-274): `"sha256:" + sha256(json.dumps(inputs, sort_keys=True, separators=(",",":")))` — records WHAT was fed without copying possibly-sensitive values.
- `build_capability_work_log(...) -> WorkLog` (:277-338): four sections. `plan = f"run {capability} via {skill_id} at {tier.value} tier"` (:305). `checklist` = 4 items (resolve→dispatch→project bare artifact (S18.3)→attach provenance), each `done=True` (:306-311). `decisions` (MAKER) = tier/capability/skill_id/`inputs_hash`/profile_id/`artifact_count` tuple (:312-319). Maker log has `outcomes=()`, `agent_role="maker"`, `workspace_path=work_log_ref_for(run_id)`, `metadata={"capability","tier"}` (:320-330). Then VERIFIER authors the verdict: `verdict = f"dispatch status={status}" + (f"; error={error}" if error else "") + f"; artifacts={len(artifact_refs)}"` (:333-337); returns `_author_verifier_review(maker_log, verdict, author="verifier")` (:338).
- `_serialize_work_log(log: WorkLog) -> dict[str, object]` (:251-263): serializes a frozen `WorkLog` to its persisted/round-trip JSON shape — the EXACT field set and order is a reproducible contract: `{"run_id": log.run_id, "skill": log.skill, "plan": log.plan, "checklist": [{"text": i.text, "done": i.done} for i in log.checklist], "decisions": list(log.decisions), "outcomes": list(log.outcomes), "agent_role": log.agent_role, "workspace_path": log.workspace_path, "metadata": dict(log.metadata)}`. GOTCHA: `checklist` is re-projected item-by-item to only `{text, done}` (drops any other ChecklistItem attrs); `decisions`/`outcomes` are copied to `list(...)` and `metadata` to `dict(...)` (defensive copies of the frozen tuples/mapping). Called by `_persist_work_log` to produce the dict that is JSON-dumped.
- `_persist_work_log(log, run_id) -> str|None` (:341-358): writes JSON (`json.dumps(_serialize_work_log(log), indent=2, sort_keys=True)`) to the deterministic path; on `OSError` logs `capability_work_log_write_failed` and returns `None` (FAIL-SOFT — a write failure is not a run failure; the content is still on the response object). GOTCHA: `sort_keys=True` re-sorts the `_serialize_work_log` keys alphabetically on disk, so serialization insertion order is NOT the on-disk key order.

### `attach_provenance(...) -> ProvenanceAttachment` (:361-441) — the tier-gated hook
Called ONLY when `tier in {PROVENANCE, VERIFIED}`, strictly AFTER bare projection.
1. `work_log = build_capability_work_log(...)` (always produced, no DB/scope) (:397-407).
2. `work_log_ref = _persist_work_log(work_log, run_id)` (:408).
3. `(evidence_content_hash, skip_reason) = await _emit_evidence(...)` (:412-424).
4. Log `capability_provenance_attached` and return `ProvenanceAttachment(work_log_ref, evidence_content_hash, work_log, skip_reason)` (:426-441).

`ProvenanceAttachment` frozen dataclass (:125-141): `work_log_ref`, `evidence_content_hash`, `work_log`, `skip_reason=None`.

### `_emit_evidence(...) -> (str|None, str|None)` (:444-568) — FAIL-SOFT / FAIL-CLOSED (reproduce every branch)
Returns `(content_hash, skip_reason)`:
1. `if db is None: return (None, "no_db")` (:472-473) — CLEAN skip.
2. `if not portfolio_id: return (None, "no_portfolio")` (:474-475) — CLEAN skip.
3. Lazy import block: `try: import uuid; from src.models.control_mapping import ControlMapping, DanglingControlMapping; from src.models.evidence_envelope import CtEnvelope; from src.models.evidence_record import EvidenceRecordInput; from src.services.evidence_emit import EvidenceEmitService, EvidenceWriteError` except `Exception` → log `capability_provenance_backbone_absent` and `return (None, "evidence_backbone_absent")` (:477-492) — CLEAN skip (backbone absent, never fail).
4. `portfolio_uuid = uuid.UUID(str(portfolio_id))`; on `(ValueError, AttributeError, TypeError)` → `return (None, "no_portfolio")` (:494-497).
5. `application_uuid`: if `app_id`, try `uuid.UUID(str(app_id))`; on failure `application_uuid = None` (non-uuid → portfolio-scoped record) (:499-504).
6. Build `EvidenceRecordInput(portfolio_id=portfolio_uuid, application_id=application_uuid, control_id="CA-7", family="CA", status="partial", implementation_statement=<statement>, evidence_refs=[{ref_type:"capability_run", artifact:run_id, finding_id:skill_id, description:f"actor={actor}; capability=…; tier=…; recorded_at=…"}], assessed_by_skill="capability-provenance", last_assessed=captured_at)` (:506-539). `family = primary.split("-")[0]` = `"CA"` (:510).
7. `envelope = CtEnvelope(profile_id=profile_id, owner_scope=app_id)` (:540); `mappings = [ControlMapping(catalog_id="nist-800-53", control_id="CA-7")]` (:541-543).
8. `emitter = EvidenceEmitService(db)`; `try: emission = await emitter.emit(evidence, envelope=envelope, mappings=mappings, subject_kind="capability_run", subject_id=run_id, commit=True)` (:544-553).
   - `except DanglingControlMapping: raise` (:554-557) — GOTCHA: the record IS persisted but a mapping dangled; SURFACE it (REQ-EV-010), never silently drop.
   - `except EvidenceWriteError:` log `capability_provenance_evidence_write_failed` and `raise` (:558-562) — FAIL-CLOSED on a durability failure (backbone engaged): never report a hash the run could not durably write.
9. `if emission is None: return (None, "evidence_suppressed")` (:564-567) — suppressed by the evidence-suppression table (deliberate, not a failure).
10. `return (emission.record.content_hash, None)` (:568).

## 1.8 Verified pass — `capabilities/verification.py` (VERIFIED tier, S18.7)

Verdict-prefix constants: `VERIFIER_UNAVAILABLE_PREFIX="verifier_unavailable"`, `VERIFIED_PASS_PREFIX="verified"`, `VERIFIED_FAIL_PREFIX="not_verified"` (:92-94). `VerificationOutcome(verified: bool, verdict: str)` frozen (:104-118). `_unavailable(reason) -> VerificationOutcome(verified=False, verdict=f"verifier_unavailable: {reason}")` (:120-130) — the SINGLE constructor for every fail-closed branch.

### `run_verifier_pass(*, run_id, capability, skill_id, result) -> VerificationOutcome` (:133-298)
maker≠verifier honored: the correctness check is the skill's OWN declared output schema (`output_schemas`), expressed as an eval-harness `EvalCase` with an explicit INDEPENDENT criterion; the schema is authored WITH the skill, not by this run. FAIL-CLOSED everywhere. Branches (reproduce all):
1. `try: from src.models.eval_harness import EvalCase; from src.services.evals_run import validate_case` except → log `capability_verifier_substrate_absent`; `return _unavailable("verifier_substrate_absent")` (:165-172).
2. Inside a wrapping `try` (any failure fails CLOSED) (:176):
   a. `from src.services.return_payload_validator import load_output_schemas_for_skill, validate_return_output_payload` (:182-185); `declared = load_output_schemas_for_skill(skill_id)`; `if not declared: return _unavailable("no_criterion")` (:187-189) — no schema = no independent rule.
   b. Build `criterion = f"produced artifact conforms to skill {skill_id!r} declared output_schema …"` (:200-205). `case = EvalCase(eval_case_id=f"capability-verify:{run_id}", gate_type="capability-verified", ground_truth_verdict="APPROVE", criterion=criterion, version="1")` (:206-212). `validate_case(case)` (:215) — rejects a self-grading/criterion-less case (REQ-EH-006) → `IllFormedEvalCaseError` caught below → fail closed.
   c. Resolve target artifact: `declared_paths = {entry["path"] for entry in declared}` (:223); loop `result.output_files` for first file whose path is declared AND whose content `json.loads` parses to a `dict` (:226-237). `if parsed_artifact is None or target_path is None: return _unavailable("no_artifact_to_verify")` (:238-239).
   d. `violations, _debug = validate_return_output_payload(skill_id=…, output_payload=parsed_artifact, payload_path=target_path)` (:245-249).
   e. `if not violations:` → log `capability_verified_pass`; `return VerificationOutcome(verified=True, verdict=f"verified: artifact {target_path!r} conforms to skill {skill_id!r} declared output_schema (independent maker≠verifier check passed)")` (:251-268) — THE ONLY branch that yields `verified=True`.
   f. Else (RAN and FAILED): log `capability_verified_fail`; `first = violations[0]`; `return VerificationOutcome(verified=False, verdict=f"not_verified: artifact {target_path!r} violates … ({len(violations)} violation(s); first: {first.get('path','/')} {first.get('message','')!r})")` (:270-291). GOTCHA: this is a REAL not-verified (verifier judged), NOT a fail-closed "unavailable".
3. `except Exception as exc:` → log `capability_verifier_error`; `return _unavailable(f"verifier_error:{type(exc).__name__}")` (:292-298) — FAIL CLOSED on ANY error, never a run failure, never a false pass.

GOTCHA (provenance ≠ verified): this module NEVER runs on `provenance` (or `bare`) — the service calls it ONLY on `VERIFIED` (:12-16). A provenance run leaves `verified`/`verifier_verdict` = `None` ("no verification ran").

## 1.9 Run-event + idempotency — `capabilities/run_event.py` (S18.6)

Constants: `CAPABILITY_RUN_EVENT = "capability.run"` (:70), `_AGGREGATE_TYPE = "capability_run"` (:73).

### `compute_input_hash(inputs) -> str` (:76-87)
`"sha256:" + sha256(json.dumps(inputs, sort_keys=True, separators=(",",":")))`. GOTCHA: byte-for-byte identical to `provenance._inputs_hash` so the work-log hash and the idempotency key axis AGREE.

### `capability_run_idempotency_key(*, skill_id, input_hash, tier) -> str` (:90-112)
```
payload = json.dumps({"skill_id","input_hash","tier": tier.value}, sort_keys=True, separators=(",",":"))
return f"capability.run:{sha256(payload).hexdigest()}"
```
Stable over ALL THREE axes `(skill_id, input_hash, tier)` (REQ-CAP-011). Tier uses `.value` (no enum-identity leakage). Changing ANY axis changes the key; identical calls yield the SAME key.

### `emit_capability_run_event(...) -> (str|None, str|None)` (:115-206)
1. `if db is None: return (None, "no_db")` (:154-155) — CLEAN skip.
2. `input_hash = compute_input_hash(inputs)`; `idempotency_key = capability_run_idempotency_key(...)` (:157-160).
3. `payload = {run_id, capability, skill_id, tier: tier.value, status, input_hash, work_log_ref, evidence_content_hash, profile_id}` (:165-175).
4. `try: from src.services.event_outbox import enqueue_event; outbox_id = await enqueue_event(db, "capability.run", payload, aggregate_type="capability_run", aggregate_id=run_id, profile_id=profile_id, owner_scope=app_id, idempotency_key=idempotency_key)` (:177-189).
5. `except Exception as exc:` log `capability_run_event_emit_failed`; `return (None, "emit_failed")` (:190-194) — SWALLOWED (reliability side effect, never a hard gate).
6. Log `capability_run_event_emitted`; `return (outbox_id, None)` (:196-206).

GOTCHA (where idempotency is enforced — HONESTLY) (:28-42): this module adds NO service-level dedup store. The `CapabilityRunStore` is keyed by `run_id` (fresh uuid per call), NOT by `(skill_id, input_hash, tier)`. The stable key is stamped on the OUTBOX row and the outbox DRAIN dedupes downstream (`_key_already_delivered`, REQ-EO-006) — a duplicate row with an already-delivered key is delivered at most once. "Repeated identical calls don't duplicate provenance" holds at the DELIVERY layer. Emitted on EVERY tier (a bare run carries `None` provenance refs in the payload).

## 1.10 Run store — `capabilities/store.py`

In-process, append-only, thread-safe projection (a derived, rebuildable read cache; NO new DB table in scope for this scaffold) (:1-18). Mirrors `services/autonomy/store.py` exactly: `threading.Lock`, `OrderedDict`, FIFO cap `_MAX_RECORDS = 2000` (:30).
- `record(record)` (:49-58): under lock, if `run_id` already present `del` it first (a re-run with an idempotency-stable id overwrites in place, moving to newest) (:54-56); insert; while `len > max` `popitem(last=False)` (evict oldest FIFO) (:57-58).
- `get(run_id) -> CapabilityRunResponse|None` (:60-63).
- `list_records(*, profile_id=None, limit=100)` (:65-86): snapshot copy, `reverse()` (newest-first), filter by `profile_id` if given, cap at `limit`.
- `clear()` (test isolation) (:88-91).
- Singleton `CAPABILITY_RUN_STORE = CapabilityRunStore()` (:95).

## 1.11 Capabilities — UNITS RECAP (tiers + endpoints)
- Tiers: **bare**, **provenance**, **verified** (3).
- Endpoints: `POST /generate-architecture`, `POST /extract-business-rules`, `POST /run`, `GET /runs/{run_id}` (4).

---

# PART 2 — NL ACTION CONSOLE (P10-W6)

File: `olympus-api/src/services/nl_engine.py` (~1501 lines). Read tools: `services/nl_tools/{catalog,executor}.py`. Attribution: `services/agent_attribution.py`.

Turns the advisory chat surface into an ACTION-TAKING engine: a NL request → a PLAN of actions, each mapped to an EXISTING Olympus API endpoint, executed UNDER THE USER'S OWN TOKEN so every RBAC boundary + gate is inherited for free.

Four LOAD-BEARING design constraints (:11-33):
1. Adds NO new action endpoint — every `ACTION_SPECS` id names an existing W2-hardened endpoint (REQ-NL-002).
2. The tiered-confirmation policy is profile-configurable DATA (`profiles/<p>/nl-action-policy.yaml`), NOT a code constant. GOTCHA: there is deliberately no high-stakes action-list literal in the file; grep enforces it (REQ-NL-003).
3. Gate decisions are STAGED + EXPLAINED, never made by the agent (REQ-NL-004). NO code path calls a gate-decision endpoint.
4. Attribution is W2's `record_agent_action` — does NOT reinvent the write; adds NO `ActorKind` value (REQ-NL-006).

## 2.1 Tier vocabulary (:65-69)
`ActionTier = Literal["reversible","high_stakes","gate_decision"]`; constants `REVERSIBLE`, `HIGH_STAKES`, `GATE_DECISION`. GOTCHA: these are tier NAMES; WHICH action is which tier is profile DATA, not here.

## 2.2 `ActionSpec` (frozen) + `ACTION_SPECS` catalog (:78-283)

`ActionSpec` fields (:97-118): `action_id`, `label`, `endpoint` (an EXISTING endpoint string), `method`, `resource_type`, `required_roles: tuple[RBACRole,...]|None`, `gate_staged: bool=False`, `description`, `example`, `param_hints: tuple`, `required_params: tuple`.
- `required_roles=None` means the endpoint enforces a portfolio-SCOPED role at call time (not a flat role) — the engine never widens it (:89-92).
- `required_params`: params without which the call would 422 — if any is absent when planned, the action is returned as `needs_input` and NOT staged/executed (REQ-NL-013) (:114-118).

Role groups mirrored from routers (referenced, not re-declared) (:124-137): `_MANAGER_ROLES=(PORTFOLIO_MANAGER, PORTFOLIO_ADMIN)`; `_ADMIN_ROLES=(PORTFOLIO_ADMIN,)`; `_REVIEWER_ROLES=(TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN)`.

**Full `ACTION_SPECS` vocabulary** (:142-283) — 10 actions:

| action_id | endpoint | method | resource_type | required_roles | required_params | gate_staged |
|---|---|---|---|---|---|---|
| `onboard_application` | `POST /api/v1/applications` | POST | application | `_MANAGER_ROLES` | name, repository_url | — |
| `create_portfolio` | `POST /api/v1/portfolio` | POST | portfolio | `_ADMIN_ROLES` | — | — |
| `start_line` | `POST /api/v1/applications/{app_id}/workflow/start` | POST | line_run | `_MANAGER_ROLES` | app_id, line | — |
| `start_discovery` | `POST /api/v1/applications/{app_id}/discovery/start` | POST | line_run | `_MANAGER_ROLES` | app_id | — |
| `rerun_step` | `POST /api/v1/applications/{app_id}/steps/{step}/rerun` | POST | step_execution | `_MANAGER_ROLES` | app_id, step | — |
| `retry_step` | `POST /api/v1/applications/{app_id}/steps/{step}/retry` | POST | step_execution | `_MANAGER_ROLES` | app_id, step | — |
| `reset_step` | `POST /api/v1/applications/{app_id}/steps/{step}/reset` | POST | step_execution | `_MANAGER_ROLES` | app_id, step | — |
| `cancel_step` | `POST /api/v1/applications/{app_id}/steps/{step}/cancel` | POST | step_execution | `_MANAGER_ROLES` | app_id, step | — |
| `dispatch_skill` | `POST /api/v1/skills/{skill_id}/dispatch` | POST | agent_task | `None` (scoped) | skill_id, app_id | — |
| `gate_decision` | `POST /api/v1/gates/{gate_id}/decision` | POST | gate | `_REVIEWER_ROLES` | gate_id | **True** |

- GOTCHA (`start_line`): maps to the PER-APPLICATION `workflow/start` endpoint (needs only app+line), NOT the heavyweight `/lines/{line}/start` recovery endpoint (which would 422 without wave_id/artifact_repo/target_repo_url/disposition) (:170-176).
- GOTCHA (`create_portfolio`): W2 closed a hole — now requires `PORTFOLIO_ADMIN` (:159).
- GOTCHA (`dispatch_skill`): `required_roles=None` because W2 made it portfolio-scoped — the endpoint resolves the target app's portfolio and enforces a scoped manager role at call time (:252-259).
- `gate_decision.required_roles=_REVIEWER_ROLES` is recorded ONLY so the staged card can tell the human what authority is needed; the engine NEVER calls this endpoint (:270-274).

## 2.3 Profile policy — `ActionPolicy` + `load_policy` (:291-420)

`ActionPolicy` (frozen) (:291-321): `profile`, `default_tier: ActionTier`, `reversible: frozenset[str]`, `high_stakes: frozenset[str]`, `gate_agent_may_approve: bool`.

`tier_for(action_id) -> ActionTier` (:305-321) — THE GATING BRANCH:
```
spec = ACTION_SPECS.get(action_id)
if spec is not None and spec.gate_staged: return GATE_DECISION   # gate ALWAYS gate, regardless of tier lists
if action_id in self.reversible:  return REVERSIBLE
if action_id in self.high_stakes: return HIGH_STAKES
return self.default_tier                                          # fail-safe: unknown → default (high_stakes)
```

`_profiles_root()` (:324-342): honors `OLYMPUS_PROFILES_DIR`, else walks up from the module for a `profiles/` dir, else repo-relative guess.
`_active_profile_id()` (:345-364): prefers `src.services.profile_activation.active_profile().metadata.id`; falls back to `OLYMPUS_PROFILE` env, then `"test-generic"`.

`load_policy(profile=None)` (:367-397, `@lru_cache(maxsize=8)`): `profile_id = profile or _active_profile_id()`; for `candidate_profile in (profile_id, "test-generic")` try `<root>/<candidate>/nl-action-policy.yaml`; first existing → `_parse_policy`. If none: log `nl_engine.no_policy_file` and return a FAIL-SAFE default (`default_tier=HIGH_STAKES`, empty reversible/high_stakes, `gate_agent_may_approve=False`) — everything non-gate confirms (:389-397). `clear_policy_cache()` (:418-420) resets the cache (tests mutating the file on disk call it).

`_parse_policy(path, profile_id)` (:400-415): reads `raw["nl_action_policy"]`; `tiers=block["tiers"]`, `gate=block["gate_decision"]`, `default_tier=block["default_tier"]`; if `default_tier not in (REVERSIBLE, HIGH_STAKES): default_tier=HIGH_STAKES`; builds `ActionPolicy(profile=block["profile"], default_tier=…, reversible=frozenset(tiers["reversible"]), high_stakes=frozenset(tiers["high_stakes"]), gate_agent_may_approve=bool(gate["agent_may_approve"]))`.

**The policy DATA** (`profiles/test-generic/nl-action-policy.yaml`): `default_tier: "high_stakes"`; `tiers.reversible = [start_line, start_discovery, rerun_step, retry_step, reset_step, dispatch_skill]`; `tiers.high_stakes = [onboard_application, create_portfolio, cancel_step]`; `gate_decision.mode = "staged_human_decides"`, `agent_may_approve: false`. (FAA profile has its own copy at `profiles/faa/nl-action-policy.yaml`.)

## 2.4 Plan / action models (:428-495)

`PlannedAction` (:428-466): `action_id`, `label`, `tier`, `params: dict`, `seq: int`, `status="planned"`, `result: dict|None`, `explanation: str|None`, `confirmation_id: str|None`. Status lifecycle: `planned`, `executed`, `awaiting_confirmation` (high-stakes blocked), `staged` (gate), `denied` (RBAC), plus `needs_input` and `failed` set at runtime. `to_dict()` (:455-466).

`ActionPlan` (:469-484): `session_id`, `intent_id`, `intent_text`, `actions: list[PlannedAction]`. `to_dict()` (:478-484).

`ActionExecutor` type (:492-495): `Callable[[ActionSpec, dict, CurrentUser], Awaitable[tuple[int, dict]]]` — injected; performs the real endpoint call under the user's token, returns `(status_code, result_dict)`. RBAC denials come back as a 401/403 status_code (not a raise).

## 2.5 Intent parsing (deterministic) (:506-585)

`_INTENT_CUES` (:506-525): ordered `(cue, action_id)` tuples — `("onboard","onboard_application")`, `("create portfolio"/"new portfolio","create_portfolio")`, `("start discovery"/"run discovery","start_discovery")`, `("start the"/"start line","start_line")`, `("re-run"/"rerun","rerun_step")`, `("retry","retry_step")`, `("reset","reset_step")`, `("cancel","cancel_step")`, `("dispatch"/"run the skill"/"ad-hoc","dispatch_skill")`, `("approve the gate"/"decide the gate"/"gate decision","gate_decision")`.

`parse_intent(message) -> list[str]` (:528-545): lower-cases; for each cue `idx = lowered.find(cue)`; if `idx != -1` and action_id not seen → `hits.append((idx, action_id))`; sort by first-mention index; return ordered action ids (REQ-NL-001). Empty when no cue → advisory turn.

`_CAPABILITY_CUES` (:556-570) + `is_capability_query(message) -> bool` (:573-585): empty message → `True`; if `parse_intent(lowered)` non-empty → `False` (an actionable request always beats a help phrasing); else any capability cue present.

## 2.6 Capability discovery (REQ-NL-012) (:588-647)
`Capability` frozen card (:588-605). `describe_capabilities(policy) -> list[Capability]` (:608-626): builds a card per `ACTION_SPECS` value with `tier=policy.tier_for(spec.action_id)`. GOTCHA: sourced from `ACTION_SPECS` so "what can you do?" is EXACTLY the plannable set — it cannot claim/omit a capability. `capability_reply(policy) -> str` (:629-647): a warm intro + bulleted list with examples.

## 2.7 Conversational understanding (live path) (:660-1078)

`ConversationalPlan` (:660-674): `action_ids: list[str]`, `params_by_action: dict[str,dict]`, `reply: str`, `is_capability_query: bool=False`. A PROPOSER only — never executes, never picks a tier, never decides a gate.

`_runtime_is_mock() -> bool` (:677-690): `os.environ.get("AGENT_RUNTIME_MODE","").lower() == "mock"`. Mock must be OPTED INTO explicitly (tests always do). `is_mock_runtime()` (:693-696) public alias.

`OLYMPUS_KNOWLEDGE` (:706-780): a large platform-knowledge digest injected into the system prompt (10 lines, 8 dispositions, 15 gates, 3 risk tiers, architecture). CLIENT-BLIND — the active profile is named at runtime, not baked in.

`_grounding_preamble(portfolio_context=None) -> str` (:783-817): shared identity + `OLYMPUS_KNOWLEDGE` + optional live-portfolio snapshot block. GOTCHA: reused by BOTH the single-shot JSON prompt AND the tool-use loop prompt — kept in one place so they can't drift; the tool-use loop must NOT reuse the JSON-contract prompt (that caused the model to emit a raw JSON blob as prose).

`_planner_system_prompt(policy, portfolio_context=None)` (:820-872): grounding + enumerated action catalog (`action_id: description (needs: param_hints)`); STRICT-JSON contract `{"reply":str,"actions":[{"action_id":str,"params":{..}}],"is_capability_query":bool}`; rules (only catalog ids; never propose an action with missing required params — ask instead; never decide a gate; preserve ordering).

`ACTION_SENTINEL = "\n<<<OLYMPUS_ACTIONS>>>\n"` (:878). `_planner_stream_prompt` (:881-906): same grounding, but prose reply FIRST then (only if proposing) the sentinel + one compact JSON line. `build_stream_prompt` (:951-955) public accessor.

`parse_streamed_plan(full_text, *, policy)` (:909-948): `reply, _, tail = full_text.partition(ACTION_SENTINEL.strip())`; parse tail JSON (`{`…`}`); for each entry drop unknown/duplicate action_ids (validated against `ACTION_SPECS` — REQ-NL-002 defense); `is_cap` → return capability reply; empty reply → `_deterministic_reply`.

`_invoke_planner_model(system_prompt, message) -> dict|None` (:958-1006): isolated Bedrock call; `region=AWS_REGION|us-east-1`, `model_id=CHAT_MODEL_ID|"us.anthropic.claude-sonnet-4-6"`, `invoke_model` with `anthropic_version="bedrock-2023-05-31"`, `max_tokens=1024`; extracts text, tolerates fenced/leading prose, parses `{`…`}`; ANY failure → `None` (caller falls back). Not called in mock mode.

`plan_conversationally(message, *, policy, portfolio_context=None) -> ConversationalPlan` (:1009-1078) — branches:
1. `if is_capability_query(message):` → capability reply, `is_capability_query=True` (:1030-1036) — answered deterministically REGARDLESS of runtime (always the true catalog).
2. `if not _runtime_is_mock():` → `raw = _invoke_planner_model(_planner_system_prompt(...), message)` (:1038-1041). If `raw is not None`: if `raw["is_capability_query"]` → capability reply; else validate proposed action entries against `ACTION_SPECS` (drop unknown/dup), build `params_by_action`, `reply = raw["reply"] or _deterministic_reply(...)` (:1042-1061). If `raw is None` → fall through.
3. Deterministic path: `if _looks_like_question(message):` → `_deterministic_answer` reply, no actions (:1067-1072). Else `action_ids = parse_intent(message)`, `_deterministic_reply` (:1073-1078).

`_QUESTION_CUES` (:1084-1098) + `_looks_like_question` (:1101-1106): ends-with-`?` or matches an interrogative cue. `_deterministic_answer` (:1109-1126) grounded offline answer. `_PARAM_LABELS`/`_humanize_missing` (:1129-1145) phrase missing params. `_deterministic_reply(action_ids, policy)` (:1148-1163) warm plan reply.

## 2.8 The engine — `NLActionEngine` (:1171-1479)

Constructor `(*, executor: ActionExecutor, profile: str|None=None)` (:1181-1188): `self._executor = executor`; `self._policy = load_policy(profile)`. `policy` property (:1190-1192). Stateless w.r.t. DB — receives an `AsyncSession` + `CurrentUser` per turn.

### `plan(*, session_id, message, params_by_action=None, action_ids=None) -> ActionPlan` (:1194-1257)
`resolved = action_ids if action_ids is not None else parse_intent(message)` (:1219) — a caller may supply a pre-resolved ordered list (from the conversational planner) or fall to deterministic. `intent_id = f"intent-{uuid.uuid4()}"` (:1220). For each `(seq, action_id)`:
- `spec = ACTION_SPECS.get(action_id)`; `if spec is None: continue` (:1227-1229).
- `tier = self._policy.tier_for(action_id)` (:1230) — ENGINE decides the tier, never the proposer.
- `params = params_by_action.get(action_id, {})` (:1231).
- Build `PlannedAction(...)` (:1232-1238).
- **needs_input branch (checked FIRST, before tiering/gate-staging)** (:1243-1252): `missing = [p for p in spec.required_params if not params.get(p)]`; if `missing`: `action.status="needs_input"`, explanation asks the human, append, `continue` — a doomed 422 call is never fired (REQ-NL-013).
- **gate-staging branch**: `if tier == GATE_DECISION: action.status="staged"; action.explanation=self._stage_gate_explanation(spec, action.params)` (:1253-1255).
- append.

### `understand(message, *, portfolio_context=None) -> ConversationalPlan` (:1259-1272): delegates to `plan_conversationally`. Proposer only.
### `capabilities() -> list[Capability]` (:1274-1276): `describe_capabilities(self._policy)`.

### `_stage_gate_explanation(spec, params) -> str` (:1278-1298): names `gate_id`, lists `spec.required_roles` values (or "a gate reviewer"), and states explicitly that a HUMAN must decide through the gate-decision screen. The agent EXPLAINS, does not decide (REQ-NL-004).

### `execute_plan(db, *, user, plan) -> ActionPlan` (:1300-1339) — reversible-only executor
For each `action`:
- `if action.status in ("staged","executed","denied","needs_input"): continue` (:1316).
- **gate hard-stop by SPEC IDENTITY** (:1321-1328): `spec = ACTION_SPECS.get(action.action_id)`; `if spec is not None and spec.gate_staged: action.status="staged"; (set explanation if absent); continue`. GOTCHA: guarded by spec identity, NOT the (possibly forged) tier — adversarial-review hardening.
- `if action.tier == HIGH_STAKES: action.status="awaiting_confirmation"; action.explanation=<needs your explicit confirmation>; continue` (:1329-1336). NOT executed (REQ-NL-005).
- `if action.tier == REVERSIBLE: await self._run_action(db, user=user, plan=plan, action=action)` (:1337-1338). Executed directly (REQ-NL-007).

### `confirm_and_execute(db, *, user, plan, action_seq, confirmation_id) -> PlannedAction` (:1341-1377) — the confirmation boundary
`action = next(a for a in plan.actions if a.seq == action_seq)`; `None` → `ValueError` (:1358-1363). **Gate refusal by SPEC IDENTITY** (:1367-1372): `spec = ACTION_SPECS.get(action.action_id)`; `if spec is not None and spec.gate_staged: raise PermissionError("A gate decision cannot be executed by the engine; a human must decide it…")`. GOTCHA: refuses by spec identity even if `tier="reversible"` was forged. Then `action.confirmation_id = confirmation_id`; `await self._run_action(db, user=user, plan=plan, action=action, confirmation_id=confirmation_id)`.

### `_run_action(db, *, user, plan, action, confirmation_id=None)` (:1379-1479) — the executor under the user's token
`spec = ACTION_SPECS[action.action_id]` (:1396).
1. **DEFENSE IN DEPTH — gate hard stop** (:1403-1408): `if spec.gate_staged: action.status="staged"; raise PermissionError("A gate decision is never executed by the engine…")`. The executor (the only thing that drives an endpoint) must NEVER be handed a gate spec, no matter how reached (REQ-NL-004, LOAD-BEARING).
2. **RBAC inherit — never widen** (:1413-1428): `if spec.required_roles is not None and not user.has_role(*spec.required_roles): action.status="denied"; action.result={"status_code":403,"detail": …one of {roles}}; log nl_engine.action_denied; return`. `None` required_roles ⇒ endpoint enforces its own scoped role — let the executor surface that 403.
3. **Execute**: `status_code, result = await self._executor(spec, action.params, user)`; `action.result = {"status_code": status_code, **result}` (:1430-1431).
4. `if status_code in (401, 403): action.status="denied"; log nl_engine.action_denied_by_endpoint; return` — surface the denial, do NOT retry under another identity (REQ-NL-008) (:1433-1443).
5. `if status_code >= 400: action.status="failed"; return` (:1445-1447).
6. `action.status = "executed"` (:1449).
7. **Attribution (W2)** (:1451-1472): build `details = {action_label, tier, endpoint, intent_text}`; if `confirmation_id is not None: details["confirmation_id"]=confirmation_id`; `resource_id = _resource_id_from_result(result, action.params)`; `await agent_attribution.record_agent_action(db, acting_user=user.sub, session_id=plan.session_id, intent_id=plan.intent_id, resource_type=spec.resource_type, resource_id=resource_id, action=action.action_id, details=details)`; log `nl_engine.action_executed`. GOTCHA: attribution is called ONLY after a successful mutation; does NOT reinvent the write.

`_resource_id_from_result(result, params) -> str` (:1482-1500): prefers a created-resource id from result (`id`/`workflow_id`/`app_id`/`application_id`/`portfolio_id`), then params (`app_id`/`gate_id`/`portfolio_id`/`line_name`), else `"unknown"` — attribution linkage is never dropped.

## 2.9 Read/nav tools — `nl_tools/catalog.py`

READ vs NAV vs WRITE branches: WRITE actions live in `nl_engine.ACTION_SPECS` (tiered/confirmed). READS + NAV live here and need NO tiering/confirmation (a read can't mutate; nav touches no server state) (:5-16).

`ReadTool` frozen (:29-50): `name`, `description`, `path` (template), `path_params`, `query_params`, `input_schema` (JSON-Schema for Bedrock tool-use). `kind="read"`. `NavTool` frozen (:52-67): `name`, `description`, `input_schema`; `kind="navigate"`. `_obj(props, required=None)` builds a JSON-Schema object node with `additionalProperties: False` (:70-79).

`_CURATED_READ_TOOLS` (:92-323) — 13 curated GETs, each targeting an EXISTING endpoint:
`list_skills` (`/api/v1/skills`), `get_skill` (`/api/v1/skills/{skill_id}`), `list_assembly_lines` (`/api/v1/lines`), `describe_assembly_line` (`/api/v1/lines/{line_name}/status`), `list_applications` (`/api/v1/applications`), `application_status` (`/api/v1/applications/{app_id}`), `list_waves` (`/api/v1/waves`), `wave_status` (`/api/v1/waves/{wave_id}`), `list_artifacts` (`/api/v1/artifacts/{app_id}`), `get_artifact` (`/api/v1/artifacts/{app_id}/{artifact_path}`), `list_pending_gates` (`/api/v1/gates/pending`), `list_my_tasks` (`/api/v1/me/tasks`), `portfolio_analytics` (`/api/v1/analytics/{report}` with a `report` enum of `readiness-scores, portfolio-health, portfolio-scoring, gate-pass-rate, compound-growth, disposition-confidence, model-usage`).

`GENERIC_GET_TOOL = ReadTool(name="olympus_api_get", path="")` (:332-357) — the ESCAPE HATCH: GET any `/api/v1/` path the user's token can reach; `path` supplied dynamically.

`NAV_ROUTES: dict[str,str]` (:367-392) — 24 page-id → route-template entries (e.g. `application_detail: "/applications/{app_id}"`, `gate_review: "/gates/{gate_id}/review"`, `cato_evidence: "/compliance/cato"`). `NAV_TOOL = NavTool(name="navigate_to", …)` (:394-420) with a `page` enum = `sorted(NAV_ROUTES)`.

Registries: `READ_TOOLS = {t.name: t for t in (*_CURATED_READ_TOOLS, GENERIC_GET_TOOL)}` (:427-429); `NAV_TOOLS = {NAV_TOOL.name: NAV_TOOL}` (:430). `get_read_tool`/`get_nav_tool`/`tool_names` accessors (:433-443). `bedrock_tool_defs() -> list[dict]` (:446-471) renders `{name, description, input_schema}` per tool for Bedrock native tool-use.

## 2.10 Read executor — `nl_tools/executor.py`

Injected types (:39-52): `ReadHttpGet = Callable[[str, dict, str|None], Awaitable[tuple[int, Any]]]` (loopback GET under the user's token); `EntityPortfolioResolver = Callable[[str, str], Awaitable[str|None]]` (entity→owning portfolio). `MAX_RESULT_CHARS = 24_000` (:55).

Portfolio-context boundary tables: `_PORTFOLIO_SCOPED_LIST_TOOLS = {list_applications, list_waves, list_pending_gates, portfolio_analytics → "portfolio_id"}` (:59-66); `_SCOPED_ID_ARGS = {app_id→application, wave_id→wave, gate_id→gate}` (:69-73); `_PATH_ENTITY_SEGMENTS = {applications→application, artifacts→application, waves→wave, gates→gate}` (:77-82); `_UUID_RE` (:83-86).

`_validate_api_get_path(path) -> str` (:99-119) — SSRF/hardening (REQ-NL-016): reject empty; reject `"://"` or `"//"` prefix (loopback only, no scheme/host); prepend `/` if missing; require `startswith("/api/v1/")`; reject `".."`. Raises `ToolExecutionError` otherwise. GOTCHA: the read method is HARD-CODED GET and the path is validated so a creative model cannot turn a read into a write or an SSRF (:9-13).

`_resolve_read_path(tool, args) -> (path, query)` (:122-148): for `olympus_api_get` use the validated `path` arg + `query` dict; else substitute `path_params` into the template (raise if a required path param is empty), collect declared `query_params` present in args.

`run_read_tool(tool_name, args, *, http_get, token, active_portfolio_id=None, resolve_portfolio=None) -> dict` (:151-218) — order (reproduce branches):
1. `tool = get_read_tool(tool_name)`; `if tool is None: raise ToolExecutionError(f"Unknown read tool: {tool_name}")` (:179-181).
2. `args = dict(args or {})` (:183).
3. **Force active portfolio on scoped list tools** (:186-187): `if active_portfolio_id and tool_name in _PORTFOLIO_SCOPED_LIST_TOOLS: args[<param>] = active_portfolio_id` — overrides any model-supplied value so a name→id resolution can never span portfolios.
4. **Verify entity id resolves to active portfolio** (:190-195): `if active_portfolio_id and resolve_portfolio is not None: redirect = await _check_active_portfolio(...)`; `if redirect is not None: return redirect`.
5. `path, query = _resolve_read_path(tool, args)` (:197).
6. **Force portfolio_id on the generic escape hatch** (:201-202): `if active_portfolio_id and tool_name == "olympus_api_get" and "portfolio_id" in query: query["portfolio_id"] = active_portfolio_id`.
7. `status_code, body = await http_get(path, query, token)` (:204); log `nl_tools.read`; `data = _cap(body)`; `return {"ok": 200 <= status_code < 300, "status_code": status_code, "data": data}` (:213-218). GOTCHA: an endpoint 4xx is a legitimate `ok=False` result the model SEES and explains — NOT an exception (:161-166); `ToolExecutionError` is ONLY for a call we refuse to make at all (:89-97).

`_check_active_portfolio(tool, args, active_portfolio_id, resolve_portfolio) -> dict|None` (:221-278) — CONTEXT boundary (NOT access control; the user may have access, we tell them to switch): builds `checks` (for `olympus_api_get`, an entity from the path via `_entity_from_path`; else UUID-valued `_SCOPED_ID_ARGS`); for each `(kind, entity_id)`: `owning = await resolve_portfolio(kind, entity_id)` (any error → swallowed, `owning=None`, fail-open to endpoint RBAC); `if owning is not None and str(owning) != str(active_portfolio_id):` log `nl_tools.cross_portfolio_redirect` and return a `{"ok":False,"status_code":409,"cross_portfolio":True,"data":{"error":"different_portfolio",…}}` redirect. `_entity_from_path(path)` (:281-289) extracts `(kind, uuid)` from `/api/v1/<seg>/<uuid>`.

`_cap(body) -> Any` (:369-470) — result-truncation to protect the model context (MAX 24_000 chars). GOTCHA (load-bearing): when a listing overflows, PRESERVE the `pagination` block + scalars (so "how many?" is answerable) and PROJECT every row to identifying fields (`_ROW_IDENTITY_KEYS`) FIRST — a COMPLETE projected set beats a 5-row full sample that misrepresents the line/type mix (observed bug: an 87-artifact app whose first 5 rows were all Rationalization made the agent report "no Discovery artifacts", hiding 34 real ones) (:437-441). Falls back through partial slices (200/100/50/25/5), then pagination-only, then an honest truncated-string preview.

`resolve_navigation(args) -> dict` (:473-521): `page`/`params`; `template = NAV_ROUTES.get(page)`; unknown page → `{"ok":False, reason:…}`; fill `{param}` placeholders (report first missing → `ok=False`); append leftover params as a query string; `return {"ok":True,"page":page,"route":route}`. Touches no server state — the frontend performs the navigation.

## 2.11 Attribution — `agent_attribution.py`

Stamps the ALREADY-SHIPPED `ActorKind` value `"human_with_agent"` (from `models/human_paired_agent.py` — NO new value added) + `session_id` + `intent_id` onto the EXISTING `audit_log` table via the `details` JSONB — NO migration required (`audit_log` from migration 004 already carries actor/actor_type/action/resource_type/resource_id/details) (:1-28).

Constants: `AGENT_ACTION = "agent.action"` (:46) — the row-level `action` value the read-side projection keys on to classify the row as an `agent_action` event. GOTCHA: `ActorKind` `{human_with_agent, human}` is a SEPARATE vocabulary from the `audit_log.actor_type` DB enum `{human, agent, system}` (:48-59). An agent-taken action is stored `actor_type='agent'` (machine took it) while the finer `actor_kind='human_with_agent'` (the human it acted for) lives in `details` — keeping the two vocabularies separate avoids extending either enum. `_INSERT_SQL` (:61-66) inserts with `CAST(:actor_type AS actor_type_enum)` and `CAST(:details AS jsonb)`.

`record_agent_action(db, *, acting_user, session_id, intent_id, resource_type, resource_id, action=None, details=None, commit=True) -> uuid.UUID` (:69-130): `payload = dict(details or {})`; sets `actor_kind="human_with_agent"`, `session_id`, `intent_id`, `human_user_id=acting_user`; if `action is not None: payload["domain_action"]=action`. Inserts with `actor=acting_user`, `actor_type='agent'`, `action=AGENT_ACTION` (row-level always `agent.action` so the projection keys on it; the DOMAIN action rides in `details.domain_action`). `if commit: await db.commit()`; return row id. GOTCHA: `actor` is the HUMAN whose token the agent carried — the acting identity stays answerable.

`record_human_action(db, *, acting_user, resource_type, resource_id, action, details=None, commit=True) -> uuid.UUID` (:133-172) — the negative control (REQ-AA-006): stamps `actor_kind="human"`, `actor_type='human'`, carries NEITHER session_id NOR intent_id, and the row-level `action` is the DOMAIN action (not `AGENT_ACTION`) so the projection never surfaces it as an `agent_action`. A direct human action is never mislabeled `human_with_agent`.

## 2.12 NL Console — UNITS RECAP (nl actions)
10 `ACTION_SPECS` write actions (see 2.2 table) + 13 curated read tools + 1 generic read escape-hatch + 1 nav tool. The 10 write actions are the action VOCABULARY that maps NL → plan → existing endpoints.

---

# PART 3 — AUTONOMY-GATING RUNTIME (P9/P10-S18)

> The POLICY MODEL (ladder, per-tier caps, denylist, `autonomy.yaml` schema, `AutonomyPolicy`, gate-as-a-gate predicates) is captured in **`07-framework.md`**. The WORKFLOW SHELLS (cron cadence, one-shot design) are in **`03-workflows/`**. This section is the RUNTIME view: how the 4 executor workflows OBTAIN an autonomy decision, the acting-on lock, attempt caps, and evidence emit. CROSS-LINK; not duplicated. Key files: `temporal/olympus_workflows/autonomy.py` (pure engine — see 07-framework), `activities/autonomy_eval.py` (the activity), the per-workflow gate adapter activities, and `workflows/{dependency_sweep,cve_triage,ci_repair,error_triage}.py`.

## 3.1 The runtime shape — how a workflow obtains a decision

All four executors are ONE-SHOT cron workflows (started by the Temporal Schedules API, no signal handlers, no inter-run state). Each `@workflow.run`:
1. Reads its requested rung from the loop-pattern registry: `LOOP_PATTERN_REGISTRY.get(<pattern>).default_autonomy_level` — dependency_sweep.py:124-126, cve_triage.py:132-134, ci_repair.py:141-143, error_triage.py:155-157.
2. Calls a TRIAGE/CAPTURE activity ONCE to produce proposals/incidents.
3. Routes EACH proposal/incident through a per-workflow GATE ADAPTER activity (`gate_dependency_proposal`/`gate_cve_report`/`gate_ci_proposal`/`gate_error_proposal`).
4. Tallies the verdicts into a summary dict for operator visibility. **No git mutation, no real PR, no code change** — the executors are a GOVERNANCE / PROPOSAL layer.

GOTCHA (Temporal determinism): the workflow reads NO clock/env/DB — all decision + clock logic lives in activities (`evaluate_autonomy` captures the timestamp). Clustering + digest in error_triage are PURE and run in workflow code. Activity imports pass through the sandbox via `with workflow.unsafe.imports_passed_through():` (e.g. dependency_sweep.py:58).

GOTCHA (the boundary-serialisation seam): each `gate_*_proposal` activity calls the real `evaluate_autonomy` IN-PROCESS then projects the verdict onto a boundary-serialisable `GatedProposalOutcome` (plain str/bool fields). This adapter adds NO gate logic — it exists purely because Temporal's payload converter cannot decode the pure engine's richer types across the workflow boundary (dependency_sweep.py:268-304).

## 3.2 The activity — `activities/autonomy_eval.py`

`EVIDENCE_EMIT_FLAG = "AUTONOMY_EVIDENCE_EMIT"` (:57). `evidence_emit_enabled() -> bool` (:60-72): truthy = `{1,true,yes,on}` case-insensitive; else (incl. unset) OFF → the Task-8-INDEPENDENT decision-log path.

### Policy loading (profile DATA over conservative defaults)
`_DEFAULTS_FILE = <…>/registries/defaults/autonomy.yaml` (:79-84). `_profile_root_for(profile_id)` (:92-114): explicit `OLYMPUS_PROFILES_DIR` / repo `profiles/<id>` first, else bootstrap `OLYMPUS_PROFILE_ROOT`. `_load_yaml(path)` (:117-125): returns `{}` on missing/unparseable (non-fatal). `_default_policy()` (:128-138): reads defaults file → `policy_from_mapping`, else in-code fully fail-closed `AutonomyPolicy()`. `load_autonomy_policy(profile_id)` (:141-157): `defaults = _default_policy()`; if no profile root or no `autonomy.yaml` → defaults verbatim (never fail open); else `merge_policy_over_defaults(policy_from_mapping(profile_doc), defaults)`.

### `EvaluateAutonomyInput` (:165-192)
`loop_id`, `application_id`, `requested_level`, `risk_tier: str|int|None`, `profile_id=None`, `paths: tuple=()`, `attempts: int=0`, `control_ids: tuple=()`, `policy_override: AutonomyPolicy|None=None`, `portfolio_id: str|None=None`.

### `EvaluateAutonomyResult` (:194-211)
`decision: AutonomyDecision`, `decision_log: dict`, `recorded_at: str`, `emitted=False`, `evidence_content_hash: str|None=None`, `evidence_skipped=False`.

### `evaluate_autonomy(payload) -> EvaluateAutonomyResult` (:213-262) — the core runtime path
1. `captured_at = datetime.now(timezone.utc)` (:225) — timestamp captured HERE (REQ-TEMP-001).
2. `policy = payload.policy_override or load_autonomy_policy(payload.profile_id)` (:227) — test/override wins, else profile DATA.
3. `decision = resolve_autonomy_level(requested_level=…, risk_tier=…, policy=policy, paths=tuple(payload.paths), attempts=payload.attempts)` (:228-234) — the PURE engine (see 07-framework: denylist beats tier → attempt cap → per-tier cap; fail-closed to `report_only` on unknown tier).
4. `record = build_decision_log_record(decision=…, loop_id=…, application_id=…, recorded_at=captured_at.isoformat(), profile_id=policy.profile_id, control_ids=tuple(payload.control_ids))` (:236-243).
5. `result = EvaluateAutonomyResult(decision=decision, decision_log=record.to_dict(), recorded_at=captured_at.isoformat())` (:245-249).
6. **EVIDENCE-EMIT SEAM** (:252-260): `if evidence_emit_enabled():` → `emitted, content_hash, skipped = await _emit_evidence_for_decision(...)`; set the three result fields. GOTCHA: the DEFAULT (flag-OFF) path imports NOTHING from the evidence layer (proved by `tests/autonomy/test_no_evidence_import.py`) — this is the Task-8-INDEPENDENCE seam.
7. `return result` (:262).

### `_emit_evidence_for_decision(*, payload, decision, captured_at) -> (bool, str|None, bool)` (:265-322) — flag-ON, lazy
1. `if not payload.portfolio_id: return (False, None, True)` (:281-284) — no scope → clean skip; the decision log already recorded it.
2. `try: from olympus_workflows.activities.evidence_emit import ControlMappingInput, EmitEvidenceInput, emit_evidence` except → `return (False, None, True)` (:285-292) — backbone absent → clean skip, never fail.
3. `control_ids = tuple(payload.control_ids) or ("CA-7",)`; `primary = control_ids[0]`; `family = primary.split("-")[0] if "-" in primary else primary` (:294-296).
4. `status = "non-compliant" if decision.escalate else "compliant"` (:297).
5. Build `EmitEvidenceInput(portfolio_id=…, control_id=primary, family=…, status=…, application_id=…, implementation_statement=<statement>, assessed_at_gate="autonomy_level", run_id=payload.loop_id, subject_kind="gate", subject_id="autonomy_level", profile_id=…, mappings=[ControlMappingInput(catalog_id="nist-800-53", control_id=c) for c in control_ids])` (:304-320).
6. `emit_result = await emit_evidence(emit_input)`; `return (bool(emit_result.emitted), emit_result.content_hash, False)` (:321-322).

### Acting-on lock + attempt-cap activities
`AttemptCapInput(item_id, attempts, attempt_cap=3, last_output="", diagnosis="")` (:325-333). `record_attempt(payload) -> dict` (:336-359): thin wrapper over pure `evaluate_attempt_cap`; returns `{item_id, attempts, attempt_cap, escalated, should_retry, context}`. The activity owns the durable attempt count; the engine decides. Escalation flips once `attempts > attempt_cap` (the (cap+1)th failure — with default cap 3, the 4th consecutive failure escalates; see autonomy.py:356-389).

`AcquireLockInput(target, loop_id, current_holder=None)` (:362-369). `acquire_acting_on_lock(payload) -> dict` (:371-390): thin wrapper over pure `evaluate_acting_on_lock`; returns `{target, acquired, skipped, holder, reason}`. A SECOND loop on a target already held by a DIFFERENT loop is skipped + logged; a loop re-acquiring its OWN lock is idempotent (`reason="reentrant"`, still `acquired=True`) so a retry of the same loop is not blocked (autonomy.py:413-443, REQ-AG-005). GOTCHA: the activity owns the durable lock TABLE; the pure helper only DECIDES. The lock activity is a standalone runtime primitive; the four cron workflows call `evaluate_autonomy` per proposal but the lock is acquired by whichever orchestration drives a loop against a target (the pure decision is total and never raises).

## 3.3 The per-workflow gate adapters (the OBTAIN path per executor)

### `gate_dependency_proposal(payload) -> GatedProposalOutcome` (activities/dependency_sweep.py:264-304)
Lazy `from …autonomy_eval import EvaluateAutonomyInput, evaluate_autonomy`; `result = await evaluate_autonomy(EvaluateAutonomyInput(loop_id, application_id, requested_level, risk_tier, profile_id, paths, control_ids=(), policy_override, portfolio_id))`; projects `decision` onto `GatedProposalOutcome(permitted_level, escalate, reason, requested_level, risk_tier)` (:284-304). The workflow (dependency_sweep.py:158-166) tallies: `if outcome.escalate → escalated`; `elif outcome.permitted_level == "report_only" → gated_report_only`; else `→ proposed` (would open a PR-proposal at assisted/unattended).

### `gate_cve_report` (cve_triage — requests `report_only`, the floor)
The workflow (cve_triage.py:166-167): `if not outcome.escalate and outcome.permitted_level == "report_only": gated_report_only = 1`. GOTCHA: because the request is the floor rung, the cap never inflates — it holds at `report_only` on any normal path even for a Tier-3 app; only a denylist hit escalates.

### `gate_ci_proposal` (ci_repair — requests `assisted`)
Same tally as dependency_sweep (ci_repair.py:178-184). GOTCHA (triage invariant): a flaky failure is ONLY ever quarantined, never code-fixed (enforced in the triage activity, ci_repair.py:9-12).

### `gate_error_proposal(payload) -> GatedProposalOutcome` (activities/error_triage.py:829-881) — the richest adapter
Decision constants: `DECISION_REPORT_ONLY="report_only"`, `DECISION_FIX_PROPOSAL="fix_proposal"`, `DECISION_ESCALATE="escalate"` (:99-101). Calls the real `evaluate_autonomy` (:849-861), then buckets via the pure `_bucket_decision(*, escalate, permitted_level, propose_fix_enabled)` (:800-826):
```
if escalate:                        return "escalate"      # denylist/attempt cap, regardless of tier
if permitted_level == "report_only": return "report_only"  # tier cap / low tier
if propose_fix_enabled:             return "fix_proposal"  # gate permits assisted/unattended AND profile opted in → RECORD-ONLY
return "report_only"                                        # permits but opt-in OFF → fail-closed default (REQ-ET-011)
```
`evidence_ref = result.evidence_content_hash or f"decision-log:{result.recorded_at}"` (:871) — the evidence content hash when the flag emitted one, else the decision-log timestamp (the Task-8-independent default key). Returns `GatedProposalOutcome(fingerprint, decision=bucket, permitted_level, requested_level, escalate, reason, risk_tier, evidence_ref)` (:872-881).
The workflow (error_triage.py:198-245) requests `sweep.fix_level if sweep.propose_fix_enabled else pattern_level` (:166-168) — GOTCHA: EVERY incident still passes THROUGH the gate (REQ-ET-004); opt-in only raises the REQUESTED rung. Folds `outcome.decision`/`requested_level`/`evidence_ref` back onto the incident and tallies `escalate`/`fix_proposal`/else → `report_only`; a `fix_proposal` appends a RECORD-ONLY `FixProposal` (no PR, no code mutation — REQ-ET-006).

## 3.4 Requested rungs per executor (the ladder in practice)
| Workflow | Pattern | Requested rung | Cadence | Gate adapter | Records |
|---|---|---|---|---|---|
| `DependencySweepWorkflow` | dependency-sweep | `assisted` | `0 6 * * 1` (Mon 06:00) | `gate_dependency_proposal` | per patch proposal |
| `CveTriageWorkflow` | cve-triage | `report_only` | `0 * * * *` (hourly) | `gate_cve_report` | one report action |
| `CiRepairWorkflow` | ci-repair | `assisted` | `*/15 * * * *` | `gate_ci_proposal` | per quarantine/fix proposal |
| `ErrorTriageWorkflow` | error-triage | `report_only` (or profile `fix_level` if opt-in) | `0 3 * * *` (nightly) | `gate_error_proposal` | per incident |

## 3.5 Autonomy runtime — PATHS RECAP
Runtime paths captured: (1) obtain-decision path (`evaluate_autonomy` in the activity, per proposal), (2) acting-on lock (`acquire_acting_on_lock`), (3) attempt-cap (`record_attempt`), (4) evidence-emit seam (`_emit_evidence_for_decision`, flag-gated), (5-8) the 4 per-workflow gate adapters and their verdict-tally logic. = 8 runtime paths.

---

# UNITS DOCUMENTED SUMMARY
- Capabilities: 3 tiers + 4 endpoints = 7.
- NL actions: 10 write actions (the action vocabulary) = 10.
- Autonomy runtime paths: 8.
- TOTAL units_documented = 25.
