# 02 — Agent Runtime (`olympus-agent-runtime/`)

ATOMIC regeneration spec. Behavioral parity target. All citations are
`olympus-agent-runtime/src/...:LINE` unless a file is named at the top of a
section (then bare `:NN`). Rebuild so behavior is byte-identical.

The agent runtime is a FastAPI service. It receives an A2A task
(`POST /a2a/tasks`), resolves a skill definition, resolves a
`(provider, tier)` pair, selects a concrete model, and dispatches the skill —
for the default provider (`bedrock-claude`) through the Claude Agent SDK's
`query()` streaming loop inside `execute_skill`. Output files are collected as
a delta, validated against declared JSON Schemas with a one-shot retry, gated
through a maker/verifier work-log, and returned as an `A2ATaskResponse`.

---

## 0. Package layout & entrypoints

- `src/main.py` — `create_app()` FastAPI factory.
- `src/config.py` — `AgentRuntimeConfig` (pydantic-settings).
- `src/routers/a2a.py` — the `/a2a/tasks` endpoint + dispatch pipeline.
- `src/routers/health.py` — health/readiness.
- `src/services/agent_executor.py` — the `execute_skill` pipeline (~2600 LOC).
- `src/services/skill_loader.py` — SKILL.md loading (API-first + FS fallback).
- `src/services/model_selector.py` — tier/alias → concrete model id.
- `src/services/model_rates.py` — cost rates + fedramp flag + fallback order.
- `src/services/provider_selection.py` — five-layer provider/tier resolution.
- `src/services/provider_factory.py` — provider registry + `get_provider`.
- `src/services/provider_client.py` — `ProviderClient` ABC + `ProviderCapabilities`.
- `src/providers/*` — concrete providers (bedrock_claude live; openai live;
  gemini_vertex/bedrock_nova/bedrock_mistral/bedrock_llama scaffolds).
- `src/services/output_validator.py` — strict JSON-Schema validation.
- `src/services/profile_context.py` — mission context + `agent_dispatch` block.
- `src/services/memory_backend.py` — workspace backend abstraction (spike).
- `src/services/task_recorder.py` — fire-and-forget telemetry to olympus-api.
- `src/services/tool_executor.py` — Olympus-owned tool runtime for non-Claude.
- `src/services/worklog.py` — maker/verifier work-log gate.
- `src/models/a2a.py` — A2A pydantic models.
- `config/models.yaml` — the model catalog / rate table / fallback chain.

### 0.1 App factory (`main.py`)

`create_app()` (:26):
1. `config = get_config()` (:28), `_configure_logging(config.log_level)` (:29) —
   stdlib `logging.basicConfig(level=getattr(logging, level.upper(), INFO), format="%(asctime)s %(levelname)s %(name)s — %(message)s")` (:19-24).
2. `import src.providers as _providers` at MODULE TOP (:12) — this is
   load-bearing: importing the `providers` package registers every
   `ProviderClient` in the factory registry at startup, before any request.
3. `FastAPI(title="Olympus Agent Runtime", description=..., version=config.version)` (:31).
4. `setup_tracing(service_name=config.service_name)` + `app.add_middleware(TracingMiddleware)` (:45-46) — OpenTelemetry, no-op unless OTel SDK installed AND `OTEL_TRACING_ENABLED` truthy; failure-swallowing.
5. `semaphore = asyncio.Semaphore(config.max_concurrent_tasks)` (:52) — SHARED between health + a2a routers. `health_router.init_concurrency(semaphore, config.max_concurrent_tasks)` (:53); `a2a_router.init_semaphore(semaphore, max_concurrent=config.max_concurrent_tasks, max_queued_waiters=config.max_queued_waiters)` (:54-58).
6. `app.include_router(health_router.router)` then `a2a_router.router` (:61-62).

### 0.2 Config (`config.py`, `AgentRuntimeConfig`)

pydantic-settings; env vars are the upper-cased field names. Defaults:
- `service_name="olympus-agent-runtime"`, `version="0.1.0"`, `log_level="INFO"` (:18-20).
- `agent_name="discovery-analyst"`, `agent_port=8100` (:22-23).
- `skills_dir="/app/skills"`, `skill_api_url=""` (:25-26).
- `inference_provider="bedrock-claude"`, `default_model_tier="tier-2"` (:33-34).
- `aws_region="us-east-1"`, `bedrock_model_prefix="us"` (:37-38).
- `bedrock_inference_profile_arns: dict[str,str] = {}` — `Annotated[..., NoDecode]` (:48). `@field_validator(..., mode="before")` `_parse_arns` (:50-59): `None` or blank/whitespace string → `{}`; string → `json.loads(v)`; else pass-through. GOTCHA: `NoDecode` disables pydantic-settings' built-in JSON decode so a blank env var doesn't raise a parse error.
- `claude_code_use_bedrock="1"` (:62).
- `permission_mode="acceptEdits"` (:70) — SILENTLY ACCEPTS edits without prompting. The prior `dontAsk` mode silently DENIED edits, which burned turns.
- `workspace_dir="/workspace"` (:73).
- Spike flags (P6-S3): `olympus_agentcore_memory_enabled=False`, `olympus_agentcore_gateway_enabled=False` (:93-94), `agentcore_memory_id=""` (:98). GOTCHA: there is deliberately NO `OLYMPUS_AGENTCORE_RUNTIME_ENABLED` flag (would displace the Temporal activity boundary).
- `max_concurrent_tasks=12` (:106), `max_queued_waiters=2` (:112).
- `skill_timeout_seconds=10500` (175 min absolute backstop, < worker 3h) (:145).
- `skill_idle_timeout_seconds=600` (10 min of true silence — PRIMARY hang-guard) (:158).
- `skill_max_turns: int|None = None` (OFF) (:170); `skill_max_budget_usd: float|None = None` (OFF) (:177).
- `model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}` (:179).

`get_config()` (:186) is a module-level singleton created on first call (`_config` global).

---

## 1. A2A models (`models/a2a.py`)

`A2AContext` (:10): `app_id: str`, `skill_id: str`, `task_type: str` (all
required), `input_artifacts: list[str]=[]`, `optional_input_artifacts:
list[str]=[]`, `source_repo=""`, `artifact_repo=""`, `artifact_ref=""`,
`model_preference=""`, `workspace_key=""`, `extras: dict[str,Any]={}`.

`A2ATaskRequest` (:36): `task: str`, `context: A2AContext`,
`model_preference=""`, `model=""` (legacy). `@model_validator(mode="after")`
`_normalise_preference` (:52-59): if `model_preference` empty and `model` set →
copy `model` in; then if still empty and `context.model_preference` set → copy
that in. So precedence for the tier hint that arrives on the request:
top-level `model_preference` > legacy top-level `model` > `context.model_preference`.

`TokenUsage` (:62): `input=0`, `output=0`, `llm_ms=0`, `tool_ms=0`,
`tool_call_count=0`.

`OutputFile` (:81): `path: str` (relative to artifacts dir), `content: str`
(utf-8 text OR base64), `encoding="utf-8"` (`"utf-8"`|`"base64"`).

`A2ATaskResponse` (:89): `status="completed"` (`"completed"`|`"failed"`; the
executor also emits `"timeout"`), `output_artifacts: list[str]=[]`,
`output_files: list[OutputFile]=[]`, `model_used=""`, `token_usage: TokenUsage`,
`cost_estimate_usd=0.0`, `duration_ms=0`, `error=""`.

---

## 2. The A2A endpoint & dispatch pipeline (`routers/a2a.py`)

Router prefix `/a2a`, tag `A2A` (:30). Module globals set at startup by
`init_semaphore` (:46-63): `_task_semaphore`, `_max_concurrent`,
`_max_queued_waiters=2`, `_queued_waiters=0`, `_RETRY_AFTER_SECONDS="5"` (:43).

### 2.1 `POST /a2a/tasks` → `execute_task` (:66)

Signature: `(request: A2ATaskRequest, response: Response, config=Depends(get_config))`.

1. `start_ms = int(time.time()*1000)` (:86). Log the received task (skill_id,
   app_id, task_type, model_preference) (:88).
2. `semaphore = _task_semaphore or asyncio.Semaphore(config.max_concurrent_tasks)` (:98). `max_queued = _max_queued_waiters if _task_semaphore is not None else config.max_queued_waiters` (:99-103).
3. SATURATION CHECK (:109-133): if `max_queued >= 0 AND semaphore.locked() AND _queued_waiters >= max_queued`: log warning, set `response.status_code = 503`, set `Retry-After: "5"` header, and RETURN a failed `A2ATaskResponse(status="failed", model_used="", duration_ms=..., error="agent runtime saturated — retry against a different replica (Retry-After set)")`. GOTCHA: `semaphore.locked()` is True only when value hit 0. This is the health-aware-routing hook the worker's 503-retry relies on.
4. Else: `_queued_waiters += 1` (:135); `acquired=False`; `await semaphore.acquire()` (:138); `acquired=True`; `_queued_waiters -= 1` (:141); `return await _execute(request, config, start_ms)` (:142). `finally`: if acquired → `semaphore.release()`; else if `_queued_waiters>0` → decrement (:143-150).

### 2.2 `_execute` — core pipeline (:240)

Signature `(request, config, start_ms) -> A2ATaskResponse`.

**Phase B — load skill** (:246-261):
- `config_dir = str(Path(__file__).resolve().parents[2] / "config")` (:248) — the runtime's own `config/` dir (holds `models.yaml`).
- `skill = resolve_and_load_skill(request.context.skill_id, config.skills_dir, config_dir, api_url=config.skill_api_url)` (:250). On `(KeyError, FileNotFoundError)` → log warning, leave `skill=None` (:260-261) — the pipeline CONTINUES with `skill=None`; the None is handled after telemetry start (see below).

**Phase C — resolve provider + tier, then select model** (:263-327):
- `profile_cfg = load_agent_dispatch_config()` (:270) — reads active profile's `agent_dispatch:` block (§8).
- `resolved_provider, preference = resolve_provider_and_tier(skill, profile_cfg, config.inference_provider, config.default_model_tier, request, config_dir=config_dir, skill_id=request.context.skill_id)` (:272-280).
- If `FedRampComplianceError` (:281): compute `duration_ms`, log error, allocate a task id `task_recorder.new_task_id()`, `record_task_start(task_id, agent_id="fedramp-rejected", skill_id, task_type, application_id=app_id or None)` (:285-291), `record_task_complete(task_id, status="failed", duration_ms, error_code=ERROR_CODE_FEDRAMP)` (:292-297), RETURN `A2ATaskResponse(status="failed", model_used="", duration_ms, error=str(exc))`.
- `selector = ModelSelector(config_dir, provider=resolved_provider, prefix=config.bedrock_model_prefix, inference_profile_arns=config.bedrock_inference_profile_arns)` (:307). `selection = selector.select(preference, default_tier=config.default_model_tier)` (:313). `model_id = selection.model_id` (sent to provider; may be ARN); `canonical_model = selection.canonical_model` (telemetry key) (:316-317).

**Phase D — execute** (:329-505):
- `duration_ms = now-start_ms` (:330) (recomputed later).
- Telemetry START: `task_id = new_task_id()` (:336); `agent_id = derive_agent_id(canonical_model)` (:337); `record_task_start(task_id, agent_id, skill_id, task_type, application_id=app_id or None, model_requested=preference or None, model_used=canonical_model, agent_backend=config.inference_provider, provider_name=resolved_provider)` (:338-348). Fire-and-forget.
- If `not skill` (:350): `record_task_complete(task_id, status="failed", duration_ms, error_code=ERROR_CODE_EXECUTION, model_used=canonical_model)` (:351-357), RETURN `A2ATaskResponse(status="failed", model_used=canonical_model, duration_ms, error="Skill '<id>' could not be loaded")`.
- `mission_context = load_mission_context()` (:369) — cached; `None` unless `OLYMPUS_PROFILE_ROOT` set & profile declares `mission_context`.
- `fallback_from = None` (:371). `result = await _dispatch(provider_name=resolved_provider, skill, request, config, config_dir, model_id, mission_context)` (:373-381).
- **On `_ProviderUnavailable`** (:382) — the fallback hop (§4.6):
  - `fallback = select_fallback_provider(resolved_provider, profile_cfg, config_dir)` (:388).
  - If `fallback is None` (:391): `record_task_complete(status="failed", error_code=ERROR_CODE_SDK_UNAVAILABLE, model_used=canonical_model)`, RETURN failed with `error=str(exc)`.
  - Else: log warning, `fallback_from = resolved_provider` (:416); re-select via `fb_selector = ModelSelector(config_dir, provider=fallback, ...)`; `fb_selection = fb_selector.select(preference, default_tier=...)`; `canonical_model = fb_selection.canonical_model` (:418-427). Record a SECOND `record_task_start` with a NEW task id + `provider_fallback_from=fallback_from` (:429-440). Then `result = await _dispatch(provider_name=fallback, ..., model_id=fb_selection.model_id, ...)`; `resolved_provider = fallback` (:442-451).
  - If the fallback ALSO raises `_ProviderUnavailable` (:452): at most one hop — `record_task_complete(status="failed", error_code=ERROR_CODE_SDK_UNAVAILABLE)`, RETURN failed with `error=str(exc2)`. NO cascade.
- Map executor status → terminal status (:471-481): `"completed"→"completed"`, `"timeout"→"timed_out"`, else `"failed"`. `error_code`: if `failed` and `result.error` → `ERROR_CODE_EXECUTION`; if `timed_out` → `ERROR_CODE_TIMEOUT`.
- `record_task_complete(task_id, status=term_status, duration_ms=result.duration_ms, input_tokens=result.token_usage.input or None, output_tokens=..., cost_estimate=result.cost_estimate_usd or None, model_used=canonical_model, error_code, llm_ms=..., tool_ms=..., tool_call_count=...)` (:482-500).
- `result.model_used = canonical_model` (:504) — overwrite the ARN with the canonical name before returning. RETURN `result`.

### 2.3 `_dispatch` — provider routing (:163)

`_ProviderUnavailable(Exception)` (:153) is a DISTINCT signal (missing
creds/SDK/scaffold) that triggers the fallback hop; a provider that RAN and
returned `status="failed"` does NOT trigger fallback.

`_dispatch(*, provider_name, skill, request, config, config_dir, model_id, mission_context)`:
- If `provider_name in ("bedrock-claude", "bedrock")` (:182): call
  `execute_skill(...)` DIRECTLY (:184-206) with kwargs mapped straight off the
  request/config: `task_message=request.task`, `model_id`, `app_id`,
  `source_repo`, `workspace_key`, `workspace_dir=config.workspace_dir`,
  `permission_mode=config.permission_mode`, `task_type`,
  `input_artifacts=list(request.context.input_artifacts)`,
  `optional_input_artifacts=list(...)`, `artifact_repo`, `artifact_ref`,
  `mission_context`, `timeout_seconds=config.skill_timeout_seconds`,
  `idle_timeout_seconds=config.skill_idle_timeout_seconds`,
  `max_turns=config.skill_max_turns`, `max_budget_usd=config.skill_max_budget_usd`,
  `extras=dict(request.context.extras or {})`. GOTCHA: the Claude path is called
  directly (not through the factory) so every test that patches
  `a2a.execute_skill` still works. If `execute_skill` raises `RuntimeError`
  (SDK not installed) → `raise _ProviderUnavailable(str(exc))` (:207-211).
- Else (non-Claude) (:213-237): `provider = provider_factory.get_provider(provider_name, config_dir, prefix=config.bedrock_model_prefix, inference_profile_arns=config.bedrock_inference_profile_arns)`; on `(ValueError, RuntimeError)` → `raise _ProviderUnavailable(str(exc))`. Then `await provider.execute(skill, task_message=request.task, model_id, system_prompt="", tools=skill.allowed_tools, app_id, source_repo, workspace_key, workspace_dir, permission_mode, task_type, mission_context)`.

---

## 3. `execute_skill` — the full pipeline (`services/agent_executor.py`)

The heart. `async def execute_skill(...)` (:1721). Args (:1721-1744): `skill:
SkillDefinition`, `task_message`, `model_id`, `app_id=""`, `source_repo=""`,
`workspace_key=""`, `workspace_dir="/workspace"`, `permission_mode="acceptEdits"`,
`task_type=""`, `input_artifacts=None`, `optional_input_artifacts=None`,
`artifact_repo=""`, `artifact_ref=""`, `mission_context=None`,
`timeout_seconds=None`, `idle_timeout_seconds=None`, `max_turns=None`,
`max_budget_usd=None`, `memory_backend=None`, `extras=None`, `profile_id=""`,
`work_log_gate=True`.

### 3.0 SDK availability guard

Module tries `from claude_agent_sdk import (AssistantMessage, ClaudeAgentOptions,
ResultMessage, UserMessage, query)` + `from claude_agent_sdk.types import
(ToolResultBlock, ToolUseBlock)` (:80-90). On success sets `_SDK_AVAILABLE=True`
and stashes the message classes in module sentinels `_ResultMessage`,
`_AssistantMessage`, `_UserMessage`, `_ToolUseBlock`, `_ToolResultBlock`
(:92-97). On `ImportError`, `_SDK_AVAILABLE=False` (:98-99). If SDK is an
optional dep and absent, `execute_skill` raises `RuntimeError("claude_agent_sdk
is not installed. Install with: pip install 'olympus-agent-runtime[agent]'")`
at :1772-1776.

### 3.1 Pipeline steps (in exact order)

**S1. `start_ms = int(time.time()*1000)`** (:1778).

**S2. Resolve memory backend** (:1790-1794): if `memory_backend is None`,
`from src.config import get_config; from src.services.memory_backend import
resolve_memory_backend; memory_backend = resolve_memory_backend(get_config())`.
DEFAULT: flag off → `LocalWorkspaceMemoryBackend` which delegates verbatim to
`_setup_workspace` / `_cleanup_workspace` (§9).

**S3. `os.makedirs(workspace_dir, exist_ok=True)`** (:1797).

**S4. Set up workspace** (:1804-1834): `try: workspace_path, source_dir,
artifacts_dir = memory_backend.setup_workspace(workspace_dir, workspace_key,
source_repo, task_type)`. Then agent CWD: `cwd = source_dir if
_repo_already_cloned(source_dir) else workspace_path` (:1813-1816). On any
exception (:1827): log, RETURN `A2ATaskResponse(status="failed", model_used,
duration_ms=now-start_ms, error="Failed to set up workspace: <exc>")`.

**S5. Fetch input artifacts** (:1836-1871): if `(input_artifacts or
optional_input_artifacts) and artifact_repo`: `input_artifacts_dir =
<workspace_path>/input-artifacts` (:1838).
- Required inputs (:1839-1855): `_fetch_input_artifacts(artifact_repo, list(input_artifacts), input_artifacts_dir, artifact_ref=artifact_ref, required=True)`. On exception → RETURN failed (`error="Failed to fetch input artifacts: <exc>"`).
- Optional inputs (:1856-1871): same with `required=False`. On exception → LOG warning and CONTINUE (never fail the dispatch).

**S6. Stage structured dispatch context** (:1873-1913): if `extras and
workspace_path`: build `_structured = {k:v for k,v in extras.items() if
isinstance(v, (list,dict)) and v}` (:1890-1894) — only non-empty list/dict
values. If non-empty: write pretty JSON (`json.dump(_structured, fh, indent=2,
default=str)`) to `<workspace_path>/input-artifacts/_dispatch-context.json`
(:1897-1901); wrapped best-effort. GOTCHA: this exists because `extras` used to
reach the agent only through the worker's `k=v` stringify (`_build_task_message`),
which flattened a 132-row capability list into one unreadable blob → the agent
fabricated placeholder UUIDs. Now the agent can Read the file and copy exact ids.

**S7. Stage skill resources** (:1924-1925): if `cwd`, `_stage_skill_resources(cwd, skill)` (§3.6).

**S8. Resolve mission context** (:1931-1933): `resolved_mission_context =
mission_context if mission_context is not None else load_mission_context()` —
falls back to env-var profile even when caller passed None.

**S9. Read prior-failure marker** (:1939-1941): `previous_failure_feedback =
_read_failure_marker(workspace_path) if workspace_path else ""` (§3.2).

**S10. Build system prompt** (:1943-1950): `system_prompt =
build_system_prompt(skill, app_id, artifacts_dir, input_artifacts_dir,
mission_context=resolved_mission_context,
previous_failure_feedback=previous_failure_feedback)`. NOTE the positional args:
`app_id`, then `output_dir=artifacts_dir`, then `input_artifacts_dir`. (§3.3)

**S11. Compute tools** (:1954-1956): `tools = skill.allowed_tools or ["Read",
"Glob", "Grep", "Write", "Bash"]`; if `"Agent" not in tools: tools = [*tools,
"Agent"]`. The `Agent` sub-agent tool is ALWAYS appended.

**S12. System-prompt spill-to-file** (:1983-1999): `system_prompt_param =
system_prompt`; `_SYSTEM_PROMPT_FILE_THRESHOLD = 64*1024`. If `workspace_path
and len(system_prompt.encode("utf-8")) > 64KB`: write to
`<workspace_path>/system-prompt.txt`, set `system_prompt_param = {"type":
"file", "path": <path>}`. GOTCHA: the SDK passes a string system prompt as a
single `--system-prompt <inline>` argv element; a >~150KB umbrella prompt hit
`ARG_MAX` (`[Errno 7] Argument list too long`). The file shape switches the CLI
to `--system-prompt-file`.

**S13. Build `ClaudeAgentOptions`** (:2014-2029): `ClaudeAgentOptions(allowed_tools=tools,
system_prompt=system_prompt_param, permission_mode=permission_mode,
model=model_id, cwd=cwd, add_dirs=[workspace_path] if workspace_path else [],
include_partial_messages=True)`. GOTCHA (read isolation): ONLY `workspace_path`
is passed to `add_dirs` (never the parent `workspace_dir`), so an agent can't
Read a sibling app's artifacts on a shared replica (the 2026-06-12 cross-app
bleed incident). `include_partial_messages=True` makes the SDK emit token-level
StreamEvents — required for the idle-timeout heartbeat.
- `if max_turns is not None: options.max_turns = max_turns` (:2037-2038); `if max_budget_usd is not None: options.max_budget_usd = max_budget_usd` (:2039-2040).
- `options.stderr = _log_cli_stderr` (:2045-2048) — logs child CLI stderr at WARNING.
- `if skill.mcp_servers: options.mcp_servers = skill.mcp_servers` (:2051-2052).

**S14. Snapshot pre-existing artifacts** (:2064-2072): `_pre_existing_files:
set[str]` = every relative path currently under `artifacts_dir` (`rglob("*")`,
files only). Used later to collect ONLY the delta.

**S15. Maker work-log PRE-WRITE** (:2074-2093): `_wl_profile_id = profile_id or
os.path.basename(os.environ.get("OLYMPUS_PROFILE_ROOT","").rstrip("/"))`;
`_wl_run_id = f"{app_id or 'run'}:{task_type or skill.name}"`;
`_maker_work_log = _begin_maker_worklog(skill, task_message, run_id=_wl_run_id,
workspace_dir, workspace_key, task_type, profile_id=_wl_profile_id)`. Best-effort. (§10)

**S16. Init telemetry accumulators** (:2095-2126): `result_text=None`,
`total_cost=0.0`, `input_tokens=0`, `output_tokens=0`, `tool_call_counts={}`,
`tool_call_samples=[]`, `_SAMPLE_CAP=20`, `llm_ms=0`, `tool_ms=0`,
`phase="llm"`, `phase_start_ns=time.monotonic_ns()`. `_flush_phase(new_phase)`
(:2128-2138): compute `delta_ms=(now_ns-phase_start_ns)//1_000_000`, add to
`llm_ms` if `phase=="llm"` else `tool_ms` if `"tool"`, set `phase=new_phase`,
`phase_start_ns=now_ns`.

**S17. Set up idle/absolute deadline** (:2161-2180): `_idle =
idle_timeout_seconds if idle_timeout_seconds and >0 else None`; `_absolute =
timeout_seconds if timeout_seconds and >0 else None`; `_absolute_deadline =
_loop.time()+_absolute if _absolute else None`; `_last_event_at =
time.monotonic()`. `_next_deadline()` (:2173-2180): if `_idle is None` return
`_absolute_deadline`; else `idle_deadline = _loop.time()+_idle`; return
`idle_deadline` if no absolute else `min(idle_deadline, _absolute_deadline)`.

**S18. The stream loop** (:2182-2289):
```
try:
  async with asyncio.timeout(None) as _timeout_cm:
    if _next_deadline() is not None: _timeout_cm.reschedule(_next_deadline())
    async for message in query(prompt=task_message, options=options):
      _last_event_at = time.monotonic()
      if _next_deadline() is not None: _timeout_cm.reschedule(_next_deadline())   # heartbeat
      # ResultMessage — final
      if _ResultMessage and isinstance(message, _ResultMessage):
        _flush_phase("llm")
        result_text = message.result or ""
        total_cost = getattr(message,"total_cost_usd",None) or 0.0
        usage = getattr(message,"usage",None)
        if isinstance(usage, dict):
          input_tokens = usage.get("input_tokens",0); output_tokens = usage.get("output_tokens",0)
        num_turns = getattr(message,"num_turns",None); stop_reason = getattr(message,"stop_reason",None)
        log(...cost, llm_ms, tool_ms, num_turns, stop_reason, tool_call_counts)
        continue
      # AssistantMessage — tool_use blocks
      if _AssistantMessage and isinstance(message, _AssistantMessage):
        has_tool_use = False
        for block in getattr(message,"content",[]) or []:
          if _ToolUseBlock and isinstance(block, _ToolUseBlock):
            has_tool_use = True
            name = getattr(block,"name","unknown")
            tool_call_counts[name] = tool_call_counts.get(name,0)+1
            if len(tool_call_samples) < 20:
              raw_input = getattr(block,"input",{}) or {}
              truncated = {k:(v if not isinstance(v,str) or len(v)<240 else v[:240]+"…") for k,v in raw_input.items()}
              tool_call_samples.append({"tool":name,"input":truncated})
              log("Agent tool call #<n>: <name> input=<truncated>")
        _flush_phase("tool" if has_tool_use else "llm")
        continue
      # UserMessage — tool_result completion
      if _UserMessage and isinstance(message, _UserMessage):
        has_tool_result = any(isinstance(b,_ToolResultBlock) for b in getattr(message,"content",[]) or []) if _ToolResultBlock else False
        if has_tool_result: _flush_phase("llm")
        continue
```
GOTCHA (idle model): every stream event reschedules the deadline, so the timeout
fires ONLY after `_idle` seconds of true SILENCE. The OLD design wrapped the
whole stream in one `asyncio.timeout(N)` — a blunt wall-clock deadline that
killed actively-working agents mid-synthesis. The absolute ceiling still caps
total wall-clock as a runaway backstop.

**S19. Timeout handler** (:2290-2335): on `(TimeoutError,
asyncio.TimeoutError)`: `_flush_phase("llm")`; `duration_ms = now-start_ms`;
`silent_for = time.monotonic()-_last_event_at`; `hit_absolute = _absolute is not
None and (duration_ms/1000) >= (_absolute-1)`. Build `cause` — either "absolute
ceiling Ns reached (still emitting activity — possible runaway)" or "no stream
activity for ~<silent_for>s (idle limit <idle>s — stalled stream / sub-agent)".
Log error; `memory_backend.cleanup_workspace(workspace_path, workspace_key)` if
path; RETURN `A2ATaskResponse(status="timeout", model_used, duration_ms,
error="skill execution timed out: <cause>")`.

**S20. Generic exception handler** (:2336-2360): if `result_text is not None`
(SDK raised AFTER yielding a valid `ResultMessage`, e.g. non-zero CLI exit but
success content) → LOG warning "treating as success" and FALL THROUGH to the
normal collection path (do NOT return). Else: log error, cleanup workspace,
RETURN `A2ATaskResponse(status="failed", model_used, duration_ms, error=str(exc))`.

**S21. `duration_ms = now-start_ms`** (:2362).

**S22. Collect delta artifacts** (:2364-2375): `output_files =
_collect_artifacts(artifacts_dir, exclude=_pre_existing_files) if artifacts_dir
else []`. (§3.5)

**S23. Write-before-finish continuation** (:2377-2426): `missing_declared =
_missing_declared_outputs(output_files, skill.output_schemas)` (§3.4). If
`missing_declared and result_text is not None and artifacts_dir`: log warning;
`await _reprompt_write_missing_outputs(query, options, missing_paths=missing_declared,
idle_timeout=_idle, absolute_timeout=min(_absolute or 1800, 1800))` (§3.7);
wrapped best-effort. Then RE-COLLECT `output_files`; `still_missing =
_missing_declared_outputs(...)`; log outcome. GOTCHA targets: agent generated
artifact inline in final turn and never called Write.

**S24. Fix-schema continuation** (:2428-2495): if `skill.output_schemas and
result_text is not None and artifacts_dir`: `pre_failures =
collect_output_violations(output_files, skill.output_schemas)` (NON-raising);
`actionable = [f for f in pre_failures if getattr(f,"agent_actionable",True)]`
(skips infra failures like missing schema file / jsonschema not installed);
`coalesced = coalesce_violations(actionable)`. If `coalesced is not None`: log
warning; `await _reprompt_fix_schema_violations(query, options,
summary=str(coalesced), idle_timeout=_idle, absolute_timeout=min(_absolute or
1800, 1800))` (§3.7); RE-COLLECT; recompute `still_invalid`; log outcome.
GOTCHA targets: agent wrote a byte-present but semantically-EMPTY skeleton
(correct metadata, empty required arrays) — passes S23's byte-presence check but
fails schema.

**S25. Strict terminal validation** (:2497-2524): `try:
validate_output_files(output_files, skill.output_schemas)` (§5). On
`OutputValidationError` (:2511): log error; if `workspace_path`:
`_write_failure_marker(workspace_path, exc)` (§3.2) THEN
`memory_backend.cleanup_workspace(...)`; RETURN
`A2ATaskResponse(status="failed", model_used, duration_ms, output_files,
error="output validation failed: <exc>")`.

**S26. Clear marker on clean run** (:2526-2529): if `workspace_path`:
`_clear_failure_marker(workspace_path)`.

**S27. Work-log finalize + gate** (:2531-2549): `_wl_verdict =
_finalize_and_gate_worklog(_maker_work_log, status="completed", output_files,
workspace_dir, workspace_key, task_type, profile_id=_wl_profile_id)`. Done
BEFORE cleanup (the verdict reads the on-disk artifact). (§10)

**S28. Cleanup ephemeral workspace** (:2551-2555): if `workspace_path`:
`memory_backend.cleanup_workspace(workspace_path, workspace_key)` (no-op for
persistent workspace_key).

**S29. No-result guard** (:2557-2564): if `result_text is None` → RETURN
`A2ATaskResponse(status="failed", model_used, duration_ms, output_files,
error="No result message received from SDK")`.

**S30. Work-log gate block** (:2566-2580): if `work_log_gate and
_wl_verdict.blocked` → log error, RETURN `A2ATaskResponse(status="failed",
model_used, output_files, duration_ms, error="work-log verification failed —
disposition blocked (REQ-WL-007): <reason>")`. GOTCHA: `work_log_gate=False`
disables ONLY the blocking decision (the artifact is still written).

**S31. Success** (:2582-2600): `tool_call_total = sum(tool_call_counts.values())`;
RETURN `A2ATaskResponse(status="completed", output_artifacts=[result_text],
output_files, model_used=model_id, token_usage=TokenUsage(input=input_tokens,
output=output_tokens, llm_ms=int(llm_ms), tool_ms=int(tool_ms),
tool_call_count=int(tool_call_total)), cost_estimate_usd=total_cost, duration_ms)`.

### 3.2 Failure marker (`.previous-validation-failure.json`)

`_FAILURE_MARKER_FILENAME = ".previous-validation-failure.json"` (:144). The
marker rides on the persistent workspace across Temporal retries.

`_read_failure_marker(workspace_path)` (:147-164): returns `""` if no path;
opens `<workspace_path>/.previous-validation-failure.json`, on
`(FileNotFoundError, ValueError, OSError)` returns `""`; returns `data["feedback"]`
if a non-blank str, else `""`.

`_write_failure_marker(workspace_path, exc: OutputValidationError)` (:167-199):
builds `feedback_lines = ["Path: <exc.path>", "Schema: <exc.schema_path>",
"Violations:", *("  - <v>" for v in exc.violations)]`; payload =
`{"feedback": "\n".join(...), "path", "schema_path", "violations": list(...)}`;
`os.makedirs(workspace_path, exist_ok=True)`; `json.dump` to the marker file.
On `OSError` → log warning, swallow.

`_clear_failure_marker(workspace_path)` (:202-215): `os.remove(marker)`;
`FileNotFoundError` returns; `OSError` logs+swallows.

GOTCHA (retry-with-feedback protocol): on validation failure the executor
returns `status="failed"`; the worker maps that to `RetryableError`; Temporal
retries the SAME `workspace_key`; the NEXT `execute_skill` reads the marker and
folds it into the system prompt (§3.3 last block); the agent gets exactly ONE
feedback retry. A clean run clears the marker.

### 3.3 `build_system_prompt` — the exact envelope (:218)

`build_system_prompt(skill, app_id="", output_dir="", input_artifacts_dir="",
mission_context=None, previous_failure_feedback="") -> str`. Builds
`parts: list[str]` and returns `"\n".join(parts)`. In EXACT order:

1. **Mission context** (:243-248): if `mission_context is not None and
   mission_context.body.strip()`: append `f"# {heading}\n\n{body.rstrip()}\n\n---"`.
   FIRST thing the agent sees — the strategic framing.
2. **Skill body** (:250-251): if `skill.system_prompt`: append it (the markdown
   body below SKILL.md frontmatter).
3. **Reference docs** (:254-255): for each `(ref_name, ref_content)` in
   `skill.references.items()`: append `f"\n\n--- Reference: {ref_name} ---\n{ref_content}"`.
4. **Output templates** (:258-259): for each `(asset_name, asset_content)` in
   `skill.assets.items()`: append `f"\n\n--- Output Template: {asset_name} ---\n{asset_content}"`.
5. **Output contract** (:267-307): if `skill.output_schemas`: `contract_lines =
   ["\n\n--- Output Contract (STRICT — your output MUST conform) ---", "<preamble
   telling the agent the runtime validates against these schemas>"]`. For each
   `entry` in `output_schemas`: read `path = entry.get("path","")`, `schema_ref =
   entry.get("schema","")`; skip if either empty; `schema_doc =
   load_schema(schema_ref)`. If `None`: append a `### {path}\nDeclared schema:
   {schema_ref}\nSchema file could not be loaded...` block. Else:
   `schema_text = json.dumps(schema_doc, indent=2)` (fallback `str(schema_doc)`
   on TypeError/ValueError); append `### {path}\nSchema source: {schema_ref}\n
   ```json\n{schema_text}\n```` `. `parts.append("\n".join(contract_lines))`.
6. **Context block** (:310-334): build `ctx_parts`. If `app_id`: `"Application
   ID: {app_id}"`. If `input_artifacts_dir`: a multi-line message pointing at the
   dir + explicit instructions to READ `_dispatch-context.json` FIRST and copy ids
   VERBATIM (never fabricate). If `output_dir`: `"Output Directory: {output_dir}\n
   All output files MUST be written to this directory..."`. If any: `parts.append(
   "\n\n--- Context ---\n" + "\n".join(ctx_parts))`.
7. **Platform Capability: Parallel Sub-Agents** (:341-362): a static block
   telling the agent it has the `Agent` tool and should decompose into parallel
   sub-agents + include batching guidance in sub-agent prompts.
8. **Platform Capability: Parallel Tool Calls** (:373-396): a static block
   telling the agent to emit independent tool calls in a single turn.
9. **Previous-attempt feedback** (:406-419): if
   `previous_failure_feedback.strip()`: append `"\n\n--- IMPORTANT: PREVIOUS
   ATTEMPT FAILED SCHEMA VALIDATION ---\n<preamble>\n\n{previous_failure_feedback.strip()}
   \n\n<instruction to re-run from staged inputs and re-emit every output file>"`.
   LAST section — freshest in context.

`normalize_system_prompt(raw, provider)` (:424-459): for `provider in ("",
"bedrock-claude", "anthropic")` → return `raw` verbatim. Else: find marker
`"\n\n--- Platform Capability: Parallel Sub-Agents ---"`; if not found return
`raw`; else excise the sub-agent block up to the next `"\n\n--- "` section (or
to end if none), preserving the Output Contract. GOTCHA: only non-Claude
providers get the sub-agent block stripped (they lack the `Agent` tool); the
Output Contract is provider-agnostic and preserved.

### 3.4 `_missing_declared_outputs` (:1403)

`(output_files, output_schemas) -> list[str]`. If no schemas → `[]`. Build
`produced: dict[path→content]` where BOTH the full relative path AND its
basename map to content. For each schema `entry`: `decl = entry.get("path","")`;
match by exact path then by basename; a file is MISSING if content is `None` OR
`not content.strip()` (empty stub counts as missing). Returns the missing
declared paths.

### 3.5 `_collect_artifacts` (:1331)

`(artifacts_dir, exclude=None) -> list[OutputFile]`. Returns `[]` if dir absent.
Walks with `os.walk` and prunes `dirnames[:] = [d for d in dirnames if d not in
_ARTIFACT_IGNORE_DIRS]` (:1356) so it never descends into dependency/build/VCS
trees. `_ARTIFACT_IGNORE_DIRS` (:121-130) includes `.git .hg .svn node_modules
bower_components jspm_packages .venv venv env virtualenv site-packages
__pycache__ .pytest_cache .mypy_cache .ruff_cache .tox .nox .gradle .m2 target
dist build out .next .nuxt .svelte-kit .cache .parcel-cache .turbo coverage
.nyc_output vendor Pods .terraform .serverless`. GOTCHA: collecting these inline
overflows Temporal's 4MB gRPC activity-result limit (a greenfield `npm install`
produced 9608 files / 216MB → ResourceExhausted). For each file in `sorted(...)`:
`rel_path = relative_to(artifacts_path)`; skip if in `exclude`. If suffix in
`_BINARY_EXTENSIONS` (:102-108) → base64-encode, `encoding="base64"`. Else try
utf-8 read (`encoding="utf-8"`); on `UnicodeDecodeError` → base64.

### 3.6 `_stage_skill_resources` (:1246)

`(cwd, skill)`. Materializes skill-bundled resources as real files under `cwd`.
`groups = [("scripts", skill.scripts, executable=True), ("references",
skill.references, False), ("assets", skill.assets, False), ("",
skill.bundled_resources, False)]` (:1267-1272). If `skill.config`: write
`json.dumps(config, indent=2)` to `<cwd>/config.json` (:1273-1281, best-effort).
For each group: `base = Path(cwd)/subdir if subdir else Path(cwd)`; for each
`(rel_name, content)`: `dest = (base/rel_name).resolve()`; SKIP if `not
str(dest).startswith(str(base_resolved))` (path-traversal guard); `mkdir`
parents; `dest.write_text(content)`; if executable → chmod +x
(`S_IXUSR|S_IXGRP|S_IXOTH`). Per-file failures log+continue. GOTCHA: before this,
28 skills that say "run `scripts/foo.py`" silently failed because scripts were
dropped and refs/assets reached the agent only as prompt text.

### 3.7 The two continuations (`_reprompt_*`)

Both (:1435, :1486) re-invoke `query(prompt=<narrow instruction>,
options=options)` in the SAME cwd/workspace, guarded by the same idle/absolute
deadline machinery (`asyncio.timeout(None)` + `cm.reschedule(_deadline())` on
each event). `_reprompt_write_missing_outputs` hands the agent the exact missing
path(s) and says "you already produced this — use Write NOW, then stop".
`_reprompt_fix_schema_violations` hands the exact schema errors and says
"re-save the COMPLETE content, batch large writes, then stop". Deadline helper:
`idle_deadline = loop.time()+idle`; `min(idle_deadline, absolute_deadline)` when
both present (:1470-1476, :1534-1540).

### 3.8 Source clone & input-artifact fetch helpers

- `_setup_workspace(workspace_dir, workspace_key, source_repo, task_type="")` (:784-882): validates `workspace_key`/`task_type` against `_SAFE_PATH_SEGMENT = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")` (:61); an unsafe key → fresh `tempfile.mkdtemp(prefix="olympus-workspace-", dir=workspace_dir)`; unsafe task_type → unscoped artifacts dir. `source_dir = workspace_path/source`; `artifacts_dir = workspace_path/artifacts[/task_type]`. Defense-in-depth: `realpath`+`commonpath` check that all paths stay under `workspace_dir`, else `raise ValueError("workspace path escape detected...")`. `os.makedirs(source_dir)`; if `safe_task_type and isdir(artifacts_dir)`: `shutil.rmtree(artifacts_dir)` (clean the task-scoped subdir on each dispatch so retries don't leak pre_existing files) then recreate. If `source_repo and not _repo_already_cloned(source_dir)`: try `_restore_source_from_cache`; on miss `_clone_repo` then `_upload_source_to_cache`. Returns `(workspace_path, source_dir, artifacts_dir)`.
- `_repo_already_cloned(source_dir)` (:885): `isdir(<source_dir>/.git)`.
- S3 source-clone cache (:928-1090): `_workspace_cache_bucket()` reads `AGENT_WORKSPACE_S3_BUCKET` (cache OFF when unset) and honors `AGENT_WORKSPACE_CACHE_ENABLED` kill switch (`0/false/no/off`). `_source_cache_key = "<prefix>/<sanitized-repo-slug>/<rev|default>/source.tar.gz"`. `_restore_source_from_cache` downloads + extracts (`tar.extractall(..., filter="data")` for traversal safety) — best-effort, any error → False → clone. `_upload_source_to_cache` tars `source_dir` (`arcname="."`) + uploads — best-effort. GOTCHA: purely a cost/perf optimization; git remains the artifact source of truth.
- `_clone_repo(repo_url, target_dir)` (:1172-1243): if `OLYMPUS_LOCAL_SOURCE_MAP` maps the repo to an on-disk clone (`_local_source_path`, substring match, must have `.git`), clone from `file://<abspath>` with `--depth 1 --single-branch`. Else `_resolve_clone_url` (full URL passthrough; slug expanded against `GITHUB_BASE_URL` host, `api.github.com`→`github.com`, `.git` suffix added). Inject `GITHUB_TOKEN` into HTTPS URL ONLY when `target_host == base_host` (never leak an enterprise PAT to public github.com). `git clone --depth 1 --single-branch`, `timeout=_clone_timeout_seconds()` (env `GIT_CLONE_TIMEOUT_SECONDS`, default 1800).
- `_fetch_input_artifacts(artifact_repo, artifact_paths, target_dir, artifact_ref="", required=True)` (:631-781): uses the GitHub Trees + Blobs API. Normalizes repo slug; builds `path→sha` maps: for `artifact_ref` (via `_build_path_to_sha_map`, may be `None` if ref 404s) and for `HEAD` (default branch; raises if missing). Resolves each requested path preferring the ref tree, falling back to HEAD. Missing paths: if `required` → `raise FileNotFoundError` (first 5 + count); else log+skip. Fetches resolved blobs in parallel (`ThreadPoolExecutor(max_workers=8)`), base64-decodes, writes under `target_dir`. GOTCHA: replaced a serial per-file contents-API loop with 5×2s retries (~17 min for 100 artifacts) with 2 tree calls + N parallel blob fetches (~10s). `_resolve_ref_to_commit_sha` resolves `HEAD` via repo default_branch, branch names via `git/refs/heads/{quoted}` (per-segment URL-quoted so slashes stay literal — GHE router stops at the first `/` otherwise). A truncated tree (>100k entries) → `raise RuntimeError`.

---

## 4. Model selection & providers

### 4.1 `ModelSelector` (`services/model_selector.py`)

`ModelSelection` (frozen) (:19): `model_id` (what's sent to Bedrock — plain
`{prefix}.{base}` or an application inference profile ARN), `canonical_model`
(stable prefix-free name for telemetry).

`ModelSelector.__init__(config_dir, provider="bedrock", prefix="us",
inference_profile_arns=None)` (:49): calls `_load_config(config_dir)`.

`_load_config` (:143-182): loads `<config_dir>/models.yaml` (warns + returns if
absent). `providers = data.get("providers", {})`. BACK-COMPAT SHIM (:154-168): if
`self._provider` not a key, try `{"bedrock":"bedrock-claude",
"bedrock-claude":"bedrock"}` alias; a `bedrock` request logs a DEPRECATION
warning. Sets `_models = provider_cfg["models"]`, `_fallback =
provider_cfg["fallback_order"]`, `_aliases = data["aliases"]`,
`_fedramp_compliant = bool(provider_cfg.get("fedramp_compliant", False))`,
`_hosting_provider = provider_cfg.get("hosting_provider", "bedrock" if
provider_key in ("bedrock","bedrock-claude") else "")`.

`select(preference, default_tier="tier-2") -> ModelSelection` (:81-106):
- `tier = _resolve_tier(preference, default_tier)`.
- `chain = _fallback.get(tier, [tier])`; for each `candidate_tier` in chain:
  `base = _models.get(candidate_tier, "")`; if `base` → `_build_selection(base)`.
- Last resort: `base = _models.get(tier, "") or _models.get("tier-2", "")`; if
  `base` → `_build_selection(base)`. Else `ModelSelection("", "unknown-agent")`.

`_resolve_tier(preference, default_tier)` (:129-141): empty → `default_tier`; in
`{"tier-1","tier-2","tier-3"}` → itself; in `_aliases` → mapped tier; else log
debug + `default_tier`.

`_build_selection(base)` (:108-127): `canonical = derive_agent_id(base)`; if
`self._arns.get(canonical)` → `ModelSelection(model_id=arn,
canonical_model=canonical)`. Else if `_hosting_provider=="bedrock" or
provider=="bedrock"` → `ModelSelection(f"{prefix}.{base}", canonical)`; else
`ModelSelection(base, canonical)` (direct-vendor SDKs send the bare id).

GOTCHA (:72-79): the `fedramp_compliant` property returns AFTER the constructor
body, so the `_availability_cache`/`_cache_ttl` init lines below it (:78-79) are
DEAD CODE (never executed). `check_availability` (:184-208) therefore rebuilds
its own state expectations — it reads `self._availability_cache` which is never
set in `__init__`, so an `AttributeError` would occur if reached; it is
best-effort (`try boto3.list_foundation_models`, on any Exception assume
available → True). Preserve this quirk verbatim.

### 4.2 `models.yaml` catalog (`config/models.yaml`)

Providers (each declares `hosting_provider`, `sdk`, `fedramp_compliant`,
`models` per tier, `fallback_order` per tier, `rates`):
- `bedrock-claude` (:16): hosting `bedrock`, sdk `anthropic`, `fedramp_compliant: true`. tier-1 `anthropic.claude-opus-4-8[1m]`, tier-2 `anthropic.claude-sonnet-5[1m]`, tier-3 `anthropic.claude-haiku-4-5-20251001-v1:0`. `fallback_order`: tier-1 `[tier-1,tier-2]`, tier-2 `[tier-2,tier-3,tier-1]`, tier-3 `[tier-3,tier-2]`. rates keyed by canonical name (opus 15/75, sonnet-5 3/15, haiku 1/5 per 1M).
- `anthropic` (:43): hosting `anthropic-api`, sdk `anthropic`, `fedramp_compliant: false`. tier-1/2/3 `claude-opus-4-8` / `claude-sonnet-5` / `claude-haiku-4-5-20251001`.
- `openai` (:68): hosting `openai-api`, sdk `openai`, `fedramp_compliant: false`, LIVE. tier-1 `o3`, tier-2 `gpt-4.1`, tier-3 `gpt-4.1-mini`. rates o3 10/40, gpt-4.1 2/8, gpt-4.1-mini 0.40/1.60.
- `gemini-vertex` (:93): hosting `gcp-vertex`, sdk `gemini`, `fedramp_compliant: false`, SCAFFOLD. tier-1/2/3 `gemini-2.5-pro`/`flash`/`flash-lite`.
- `bedrock-nova` / `bedrock-mistral` / `bedrock-llama` (:115/:133/:149): hosting `bedrock`, sdk `bedrock-converse`, `fedramp_compliant: true`, SCAFFOLD.
- `provider_fallback_order` (:185-189): `[bedrock-claude, anthropic, openai]` (scaffolds excluded).
- `aliases` (:192-207): map model names → tiers for reverse lookup (e.g. `claude-opus-4-8: tier-1`, `claude-sonnet-5: tier-2`, `o3: tier-1`, `gpt-4.1: tier-2`, `o4-mini: tier-3`).

### 4.3 `derive_agent_id` (`task_recorder.py`:89)

Maps a Bedrock model id → canonical `agent_id`. `_MODEL_TO_AGENT` (:76-86) is an
ordered tuple of substring→canonical pairs (opus-4-8→claude-opus-4-8,
sonnet-5→claude-sonnet-5, sonnet-4-6, haiku-4-5, etc.). First substring match
wins; else strip known prefixes (`us.anthropic.`, `global.anthropic.`,
`eu.anthropic.`, `anthropic.`); else return `model_id`; empty → `"unknown-agent"`.

### 4.4 `ProviderClient` ABC (`services/provider_client.py`)

`ProviderCapabilities` (frozen) (:22): `name`, `hosting_provider`, `sdk`,
`fedramp_compliant`, `supports_tools`, `supports_streaming`,
`supports_sub_agents`, `live`.

`ProviderClient` (ABC) (:50): abstract classmethod `capabilities()`; abstract
async `execute(*, skill, task_message, model_id, system_prompt, tools, app_id,
source_repo, workspace_key, workspace_dir, workspace_path, artifacts_dir, cwd,
permission_mode) -> A2ATaskResponse`; abstract `is_available() -> bool`.
Contract: MUST return `status="failed"` + non-empty `error` on failure (NEVER
raise), populate `token_usage`/`cost_estimate_usd`/`model_used` (canonical, not
ARN), be stateless per-task, never block the loop, never `sys.exit`.

### 4.5 `provider_factory` (`services/provider_factory.py`)

`_REGISTRY: dict[str, type[ProviderClient]] = {}` (:20) populated at import by
each provider module calling `register(name, cls)` (:23-31; duplicate →
warning + overwrite). `get_provider(name, *, config_dir, prefix="us",
inference_profile_arns=None)` (:34-74): `ValueError` for unknown name;
instantiate `cls(config_dir, prefix, inference_profile_arns or {})`; if `not
instance.is_available()` → `RuntimeError` ("scaffold stub (live=False)" if
`not caps.live`, else "not available — check credentials and SDK"). Callers MUST
NOT cache the instance. `get_capabilities(name)` (:82) reads class-level
`capabilities()` WITHOUT instantiating. `list_providers()` (:95) sorted names.

### 4.6 Provider selection & fallback (`services/provider_selection.py`)

`_DEFAULT_PROVIDER="bedrock-claude"`, `_DEFAULT_TIER="tier-2"` (:22-23).

`resolve_provider_and_tier(skill, profile_cfg, runtime_inference_provider,
runtime_default_tier, request, *, config_dir="", skill_id="") -> (provider,
tier)` (:48-117):
- `overrides = profile_cfg.get("skill_provider_overrides", {})`; `resolved_skill_id = skill_id or (skill.name if skill else "")`.
- **Provider precedence** (:74-80): `skill.provider` (1a) → `overrides.get(resolved_skill_id)` (2) → `profile_cfg.get("default_provider")` (3) → `runtime_inference_provider` (4) → `_DEFAULT_PROVIDER` (5).
- If `provider == "bedrock"` → log DEPRECATION, set `"bedrock-claude"` (:83-88).
- **Tier precedence** (:95-102): `request.model_preference` → `skill.config_model_tier` → `skill.model_tier` → `profile_cfg.get("default_tier")` → `runtime_default_tier` → `_DEFAULT_TIER`.
- **FedRAMP enforcement (fail-closed)** (:105-115): if `profile_cfg.get("require_fedramp_provider", False)` and `not provider_is_fedramp_compliant(provider, config_dir)` → `raise FedRampComplianceError(...)`.

`provider_is_fedramp_compliant(provider, config_dir)` (:35-45): prefer live
`ProviderCapabilities.fedramp_compliant` (via `get_capabilities`); else read
`model_rates.provider_is_fedramp_compliant`. Unknown → non-compliant (fail-closed).

`select_fallback_provider(original_provider, profile_cfg, config_dir) -> str |
None` (:120-155): `chain = model_rates.provider_fallback_order(config_dir)`;
`require_fedramp = profile_cfg.get("require_fedramp_provider", False)`. Start
scanning at `chain.index(original)+1` (or 0 if not found). Skip the original;
skip any `caps is None or not caps.live` (scaffold/unregistered); skip
non-compliant when `require_fedramp`. Return first eligible, else `None`. One hop
is the caller's contract.

`model_rates.py`: `load_rates(config_dir, provider)` → `{model_id:
{input_per_1m, output_per_1m}}` (empty on absence, honors `bedrock` alias).
`provider_is_fedramp_compliant(config_dir, provider)` → bool (unknown → False).
`provider_fallback_order(config_dir)` → the `provider_fallback_order` list.

### 4.7 Concrete providers

**`bedrock_claude.py` (LIVE)**: `BedrockClaudeProvider`. `capabilities()`
(:45-56): `name="bedrock-claude"`, hosting `bedrock`, sdk `anthropic`,
`fedramp_compliant=True`, tools/streaming/sub_agents True, `live=True`.
`is_available()` (:58-65): `bool(agent_executor._SDK_AVAILABLE)`. `execute(...)`
(:67-122): delegates verbatim to `agent_executor.execute_skill(...)` (the Claude
path builds its own system prompt + tools inside `execute_skill`, so the
`system_prompt`/`tools` interface params are ignored). `register("bedrock-claude",
BedrockClaudeProvider)` (:125). NOTE: in practice the `_dispatch` router calls
`execute_skill` directly for `bedrock-claude`/`bedrock` and never routes through
this provider (§2.3); the provider exists for factory uniformity + `is_available`.

**`openai_provider.py` (LIVE)**: guarded `from openai import AsyncOpenAI`
(`_OPENAI_AVAILABLE`) (:31-37). `_MAX_TOOL_ROUNDS=25` (:40). `capabilities()`:
hosting `openai-api`, sdk `openai`, `fedramp_compliant=False`, `supports_sub_agents=False`,
`live=True`. `is_available()` (:138-145): `_OPENAI_AVAILABLE and
bool(os.environ.get("OPENAI_API_KEY").strip())` — re-read every call (secret
rotation without restart). `execute` (:172-338):
- `tools = tools or skill.allowed_tools or [Read,Glob,Grep,Write,Bash]`.
- If no `workspace_path` (own_workspace): `agent_executor._setup_workspace(...)`; `cwd = source_dir if cloned else workspace_path`. On exception → failed response.
- If no `system_prompt`: build via `agent_executor.build_system_prompt(skill, app_id, artifacts_dir, "", mission_context=...)`; then `prompt = agent_executor.normalize_system_prompt(system_prompt, "openai")` (strips sub-agent block).
- `executor = ToolExecutor(sandbox_root)`; `tool_schema = _openai_tools_schema([t for t in tools if t != "Agent"])` (:238) — Agent tool excluded.
- Client via `_make_client()` (:147-155): `AsyncOpenAI(api_key=OPENAI_API_KEY[, base_url=OPENAI_BASE_URL][, organization=OPENAI_ORG_ID])`. On exception → failed response.
- `messages = [{"role":"system","content":prompt}, {"role":"user","content":task_message}]`. Tool loop `for _round in range(25)`: `client.chat.completions.create(model=model_id, messages, [tools=tool_schema])`; accumulate `prompt_tokens`/`completion_tokens`. If no `tool_calls` → `final_text = message.content or ""`, break. Else echo the assistant tool-call message, run each tool via `_run_tool(executor, tc)` (:340-356) and append a `{"role":"tool","tool_call_id":tc.id,"content":result}`. Loop `else` (exhausted) → log warning. On Exception → cleanup (if own_workspace) + failed response.
- Collect `agent_executor._collect_artifacts(artifacts_dir)`; cleanup if own_workspace; RETURN `status="completed"`, `output_artifacts=[final_text] if final_text else []`, `token_usage=TokenUsage(total_input,total_output)`, `cost_estimate_usd=self._cost(model_id, ...)` (`load_rates` per-1M; unknown model → 0.0). GOTCHA: OpenAI provider does NOT run the terminal `validate_output_files` schema check that the Claude path runs — it collects artifacts and returns them.

**`gemini_vertex.py` (SCAFFOLD)**: `capabilities()` `live=False`,
`supports_streaming=False`, `supports_sub_agents=False`, `fedramp_compliant=False`.
`is_available()` → `False`. `execute()` → `raise NotImplementedError(_SCAFFOLD_MESSAGE)`.
`register("gemini-vertex", ...)`. `bedrock_nova/mistral/llama` are analogous
Converse scaffolds; `_bedrock_converse_scaffold.py` is the shared stub.

### 4.8 `ToolExecutor` (`services/tool_executor.py`)

Olympus-owned tool runtime for non-Claude providers (Claude ships its own).
`SUPPORTED_TOOLS = ("Read","Write","Glob","Grep","Bash")` — `Agent` intentionally
absent. `_BASH_TIMEOUT_SECONDS=120`, `_GREP_TIMEOUT_SECONDS=60`. `__init__(root)`
sets `self._root = Path(root).resolve()`. `_resolve_within_sandbox(path)`:
relative resolves against root; must stay under root else `raise
ToolExecutionError("...escapes the workspace sandbox; refused")`. `read` (utf-8),
`write` (mkdir parents, returns "wrote N bytes"), `glob` (rglob, relative paths),
`grep` (prefers `rg --no-heading --line-number` subprocess; falls back to pure
Python `_grep_python` substring scan; both timeout-bounded), `bash`
(`create_subprocess_shell`, cwd=root, stdout+stderr merged, `wait_for` 120s;
timeout → kill + `ToolExecutionError`). `dispatch(tool_name, arguments)` routes
by name (Read/Write accept `file_path` OR `path`); unknown → `ToolExecutionError`.

---

## 5. Output validation (`services/output_validator.py`)

`OutputValidationError(RuntimeError)` (:38): fields `path`, `schema_path`,
`violations: list[str]`, `agent_actionable=True`. `agent_actionable` is False for
INFRASTRUCTURE problems (schema file missing/unreadable, jsonschema not
installed) so the in-process fix-schema continuation skips them.

`_resolve_schema_root()` (:84-100): `OLYMPUS_SCHEMA_ROOT` env wins (must be a
dir); else walk up from this file for a `schemas/` sibling and return its parent
(the repo root).

`load_schema(schema_path)` (:103-133): absolute path used as-is; relative
resolved against schema root; returns parsed JSON, or `None` (logged loudly) if
root unresolvable / file missing / parse error.

`collect_output_violations(output_files, schemas) -> list[OutputValidationError]`
(NON-raising) (:152-247):
- No schemas → `[]`.
- `from jsonschema import Draft202012Validator`; on ImportError → single
  `OutputValidationError("jsonschema not installed...", agent_actionable=False)`.
- `by_path = {entry["path"]: entry["schema"]}`.
- For each output file: match `schema_path = by_path.get(rel_path) or
  by_path.get(basename)`; skip if no match. Skip if `encoding != "utf-8"`
  (base64 not structured). Empty content (`not content.strip()`) → violation
  "empty file". `json.loads(content)`; on `ValueError` → violation with
  first-120-char head. `load_schema(schema_path)`; `None` → violation
  `agent_actionable=False`. Run `Draft202012Validator(schema).iter_errors`;
  format each error as `"<json_path or <root>>: <message>"` (capped 10 +
  "... and N more") → violation "N schema violation(s)".

`coalesce_violations(failures) -> OutputValidationError | None` (:250-274): folds
all per-file failures into ONE summary error (semicolon-joined path/schema_path,
combined violation lines) or `None` if clean.

`validate_output_files(output_files, schemas) -> list` (:277-306): no schemas →
return `output_files`; else `raise coalesce_violations(collect_output_violations(...))`
if any failures, else return `output_files`. The ENTIRE set is checked (all
failures coalesced), raised once after the loop.

GOTCHA (retry-once semantics): validation is STRICT — no advisory mode, no
env escape. On first failure `execute_skill` writes the failure marker + returns
`status="failed"` → Temporal retry → next attempt reads the marker into the
prompt (one self-correction chance). On the SECOND failure the executor again
returns `status="failed"` and writes the marker again; the retry-once behavior is
enforced by Temporal's `AGENT_RETRY_POLICY` (`maximum_attempts=3`), not by
in-process counting — the executor itself does not track attempt number. What the
executor guarantees per-attempt: the two in-process continuations (S23, S24) each
fire AT MOST ONCE before terminal validation.

---

## 6. Mission / profile context (`services/profile_context.py`)

`MissionContext` (frozen) (:43): `heading`, `body`. Module cache `_CACHE`,
`_CACHE_POPULATED`; `reset_cache()` for tests (:51).

`load_mission_context(profile_root=None)` (:58-90): explicit root bypasses the
cache; env-var path (`OLYMPUS_PROFILE_ROOT`) caches. Returns `None` when both
absent. Delegates to `_resolve`.

`_resolve(profile_root)` (:93-176): returns `None` if falsy / not a dir / no
`profile.yaml`; parses `profile.yaml`; `_extract_mission_block` (tolerates
top-level `mission_context:` OR nested under `profile:`); needs `path` (else
warn+None); relative path resolved against the profile dir (so `../../docs/foo.md`
works); reads the file; `heading` from block (default `"Program Context"`).
Every failure logs a warning and returns `None` — dispatch NEVER fails on a
missing/malformed mission doc.

`load_agent_dispatch_config(profile_root=None)` (:179-217): reads the
`agent_dispatch:` block (top-level OR nested under `profile:`) —
`default_provider`, `default_tier`, `require_fedramp_provider`,
`skill_provider_overrides`. Returns `{}` on absence.

---

## 7. Skill loading (`services/skill_loader.py`)

`_AGENT_TIER_MAP` (:22-29): `opus→tier-1, sonnet→tier-2, haiku→tier-3` plus the
tier names mapping to themselves.

`SkillDefinition` (dataclass) (:32-79): `name`, `description`, `skill_dir`,
`model_tier="tier-2"`, `allowed_tools=[]`, `system_prompt=""`, `references={}`,
`assets={}`, `scripts={}`, `bundled_resources={}`, `config={}`, `mcp_servers={}`,
`provider=""` (per-skill override; config.json wins over frontmatter),
`config_model_tier=""`, `output_schemas=[]`.

### 7.1 The `/skills/dispatch/{id}` contract the runtime relies on

`load_skill_from_api(dispatch_id, api_url, *, timeout=10.0, token=None)`
(:228-287): `GET {api_url}/api/v1/skills/dispatch/{dispatch_id}` with
`Authorization: Bearer <token or OLYMPUS_API_TOKEN>`. On any exception → log
debug + return `None` (fall through to FS). Maps the JSON response into a
`SkillDefinition`:
- `name` = `data["name"]` (default dispatch_id), `description`, `skill_dir` = `data["skill_path"]`.
- `model_tier` = `data["model_tier"]` (default `"tier-2"`), `allowed_tools` = `data["allowed_tools"]`.
- `system_prompt` = `data["system_prompt"]`, `references` = `data["references_data"]`, `assets` = `data["assets_data"]`, `scripts` = `data["scripts_data"] or {}`, `bundled_resources` = `data["bundled_resources"] or {}`, `config` = `data["config_data"] or {}`.
- `mcp_servers` = `_coerce_mcp_servers(config_data)` (config's `mcp_servers` dict, else `{}`).
- `provider` = `_coerce_provider(config_data.get("provider"))` OR `_coerce_provider(data.get("provider"))` (config.json wins).
- `config_model_tier` = `_coerce_str(config_data.get("model_tier"))`.
- `output_schemas` = `_coerce_output_schemas(data.get("output_schemas"))`.

**Server side** (`olympus-api/src/routers/skills.py`:174-181): `GET
/api/v1/skills/dispatch/{dispatch_id}` (role `VIEWER_PLUS`) → `SkillDetail` via
`skill_svc.get_skill_by_dispatch_id`. That query (`services/skill.py`:230-254)
does `SELECT * FROM skill WHERE dispatch_ids @> CAST(:dispatch_ids AS jsonb) AND
status='active'` (GIN-indexed JSONB containment; 404 `SKILL_NOT_FOUND` if none).
`_row_to_detail` (:21-60) surfaces `output_schemas` by re-reading the SKILL.md
frontmatter from disk (`load_output_schemas_for_skill(skill_id)`, not stored in
the table) so the contract stays authoritative against the same SKILL.md the
prompt is built from; sets `output_schemas or None`. The returned `SkillDetail`
carries `system_prompt`, `references_data`, `assets_data`, `scripts_data`,
`bundled_resources`, `config_data`, `allowed_tools`, `dispatch_ids`, `skill_path`,
`model_tier`, etc. GOTCHA: before `output_schemas` was surfaced, the dispatch
response carried `output_schemas: null` and strict validation silently never ran.

### 7.2 Filesystem fallback + resolution

`resolve_and_load_skill(skill_id, skills_dir, config_dir, *, api_url=None)`
(:290-341): `effective_url = api_url or SKILL_API_URL`. If set: try
`load_skill_from_api`; on `None` log + fall through. FS fallback (deprecated,
logs WARNING): `mapping = load_skill_mapping(config_dir)` (reads
`<config_dir>/skill_mapping.yaml`); `dir_name = mapping.get(skill_id)`; `KeyError`
if unknown; `load_skill(skills_dir, dir_name)`.

`load_skill(skills_dir, skill_dir_name)` (:93-151): reads
`<skills_dir>/<name>/SKILL.md`; `FileNotFoundError` if absent; `_parse_frontmatter`
splits YAML frontmatter + body; `agent_hint = frontmatter.get("agent","sonnet")`
→ `_AGENT_TIER_MAP`; loads references/assets/scripts/bundled_resources/config from
disk; `provider = config["provider"] or frontmatter["provider"]` (config wins).

`_parse_frontmatter(raw)` (:349-367): `---`-delimited; `raw.split("---", 2)`;
YAML-parse part[1]; body is part[2].

`_load_text_tree(base)` (:370-392): recursive `rglob("*")`, utf-8 files only
(binary skipped), keyed by POSIX-relative path. References/assets/scripts use it;
`_load_bundled_resources` (:421-430) loads `schemas/`, `templates/`, `fixtures/`
keyed `<dir>/<relpath>`.

`_coerce_output_schemas(value)` (:187-225): canonical form is a list of
`{path,schema}` mappings; anything else → `[]` (debug-logged), and each entry
must have str `path` + str `schema`.

`load_skill_with_profile(skills_dir, skill_dir_name, *, profile_root=None)`
(:534-619): `base = load_skill(...)`; if `profile_root None` → base. Else layer:
(1) references merged (profile `references/*.md` override base on collision,
`_merge_profile_references`); (2) full SKILL.md overlay if
`<profile>/skills/<id>/SKILL.md` exists — overlay body replaces base body,
frontmatter merged (overlay wins per-key: description/agent/allowed-tools/provider),
overlay provider wins only when declared; (3) `{{var}}` substitution from
`<profile>/config/common.yaml` + `<profile>/config/<id>.yaml` (per-skill wins,
unknown tokens left literal). NOTE: this profile-overlay path is a distinct entry
point; the A2A runtime path uses `resolve_and_load_skill` (API-first).

---

## 8. Telemetry / task recording (`services/task_recorder.py`)

Fire-and-forget, idempotent (server dedupes on `task_id`), PII-free (enum error
codes only). Enabled iff `OLYMPUS_API_URL` set (`_enabled`). Error codes (:41-51):
`SDK_UNAVAILABLE`, `WORKSPACE_SETUP_FAILED`, `ARTIFACT_FETCH_FAILED`, `NO_RESULT`,
`EXECUTION_FAILED`, `TIMEOUT`, `FEDRAMP_REJECTED`.

`new_task_id()` → `str(uuid4())` (:67). `_headers()` (:59): `Content-Type:
application/json` + `Authorization: Bearer <OLYMPUS_API_TOKEN>` if set.

`record_task_start(*, task_id, agent_id, skill_id, task_type, application_id=None,
workflow_id=None, model_requested=None, model_used=None, agent_backend=None,
provider_name=None, provider_fallback_from=None, started_at=None, timeout=2.0)`
(:113-170): `POST {OLYMPUS_API_URL}/api/v1/agents/tasks` with the non-None
fields. On exception → debug log, swallow. `provider_fallback_from` set only on
the fallback dispatch's start event.

`record_task_complete(*, task_id, status, duration_ms=None, input_tokens=None,
output_tokens=None, cache_read_tokens, cache_write_tokens, cost_estimate,
model_used, quality_score, error_code, artifact_id, completed_at, llm_ms,
tool_ms, tool_call_count, timeout=2.0)` (:173-246): `POST
.../api/v1/agents/tasks/{task_id}/complete`; `status ∈
{completed,failed,timed_out}`; packs `llm_ms/tool_ms/tool_call_count` into a
`timing` sub-object (Task #94) so the API persists `agent_task.token_usage.timing`.
On exception → debug log, swallow.

---

## 9. Memory backend (`services/memory_backend.py`) — SPIKE

`MemoryBackend(ABC)` (:45): abstract `setup_workspace(*, workspace_dir,
workspace_key, source_repo, task_type="") -> (workspace_path, source_dir,
artifacts_dir)` and `cleanup_workspace(*, workspace_path, workspace_key)`.

`LocalWorkspaceMemoryBackend` (:91, `name="local-workspace"`): DEFAULT.
`setup_workspace` delegates to `agent_executor._setup_workspace(workspace_dir,
workspace_key, source_repo, task_type)` (lazy import); `cleanup_workspace`
delegates to `agent_executor._cleanup_workspace(workspace_path, workspace_key)`.
Byte-for-byte identical to pre-spike behavior.

`AgentCoreMemoryUnavailableError(RuntimeError)` (:126); `AgentCoreMemoryBackend`
(:137, `name="agentcore-memory"`): flag-gated, honest spike — `setup_workspace`
always raises the named error (`_load_client` lazily imports boto3 and tries
`boto3.client("bedrock-agentcore")` which raises UnknownServiceError today);
`cleanup_workspace` is a no-op.

`resolve_memory_backend(config)` (:249-275): `enabled =
bool(getattr(config,"olympus_agentcore_memory_enabled", False))`; flag off →
`LocalWorkspaceMemoryBackend()`; flag on → log warning + `AgentCoreMemoryBackend(
memory_id=getattr(config,"agentcore_memory_id",""),
region=getattr(config,"aws_region",""))`. GOTCHA: `_cleanup_workspace(workspace_path,
workspace_key)` (agent_executor:1391) removes the dir ONLY when `workspace_key`
is empty (ephemeral); a persistent key survives for reuse.

---

## 10. Maker/verifier work-log gate (`services/worklog.py`)

The runtime side of the "maker != verifier" guarantee (P8 agent-worklog-delta).
The executing skill = MAKER; a separate signed VERIFIER verdict gates the
disposition. Consumes the frozen `olympus_contracts.WorkLog` (four sections:
`plan`/`checklist`/`decisions`/`outcomes`).

- `work_log_path(workspace_dir, workspace_key, task_type)` (:210-232): pure —
  `<workspace_dir>[/<workspace_key>][/<task_type>]/work_log.json`. Empty segments
  skipped so ephemeral runs still get a stable path.
- `_begin_maker_worklog(...)` (agent_executor:1598-1640): `resume(...)` an
  interrupted run if a prior log exists (REQ-WL-006), else `MakerWorkLog.begin(
  run_id, skill=skill.name, plan, checklist, decisions, workspace_dir,
  workspace_key, task_type, agent_role="maker", profile_id)`. `_worklog_sections`
  (agent_executor:1572-1595): plan restates the task (`task_message[:500]`);
  checklist = `["prepare workspace and inputs","execute skill", *("produce
  declared output: <path>" per output_schemas), "collect and validate outputs"]`;
  decisions = `["skill=<name>", "allowed_tools=[...]"]`. Best-effort — never
  breaks dispatch.
- `_finalize_and_gate_worklog(maker, *, status, output_files, workspace_dir,
  workspace_key, task_type, profile_id)` (agent_executor:1656-1718): if maker
  present: tick every `open_items` (`complete_item`), `wl.bind(log, profile_id,
  evidence_ids=tuple(f.path for f in output_files))` (REQ-WL-003), `verified =
  wl.author_review(bound, _verifier_verdict(status, output_files),
  author=wl.Author.VERIFIER)`, `wl.write_work_log(verified, ...)`. Then the
  AUTHORITATIVE gate `verdict = wl.verify_disposition(workspace_dir,
  workspace_key, task_type)`. If no `workspace_key` (ephemeral): remove the log
  after the verdict. `_verifier_verdict` (agent_executor:1643-1653):
  `"PASS: skill completed; N output artifact(s) produced"` or `"FAIL: ..."`.
- `author_review(log, verdict, author)` (worklog:561): raises
  `VerifierAuthorshipError` unless `author is Author.VERIFIER`; mints an HMAC
  signature over `{run_id, skill, outcomes}` (`_sign_review`, key from
  `_SIGNING_KEY_ENV` else default) stored in `metadata`.
- `verify_disposition(workspace_dir, workspace_key, task_type) ->
  DispositionVerdict` (worklog:621-...): reads the log; `None` → `blocked=True`
  ("no WorkLog artifact..."); not conformant (missing any of the 4 sections) →
  blocked with the missing list; a conformant log MUST ALSO carry a valid
  verifier-provenance signature (`review_is_verifier_authored` HMAC compare) —
  a maker who hand-crafts a self-authored verdict via public `write_work_log`
  produces no valid signature and stays blocked. GOTCHA (behavior-inverting,
  REQ-WL-007): a MISSING/partial log BLOCKS the disposition — the OPPOSITE of
  best-effort telemetry (which swallows a missing row and proceeds).
