# 07 — The Extensibility Framework: Registries, Substrate, Line Contract, Autonomy Gating

> ATOMIC regeneration spec. Sole source of truth is live code at `/Users/pnunna/Documents/GitHub/olympus`.
> This file covers: (1) the shared registry **substrate** `engine.py`; (2) the **7 pluggable registries** built on it
> plus the **loop-pattern catalog** and **worker_bootstrap** wiring layer; (3) the **line-to-line artifact contract**;
> (4) the **autonomy-gating framework** (P9/P10-S18). The **profile system** (all 4 profiles reproduced fully,
> override-key-by-key) is in the companion file **`07b-profiles.md`** (split for length). Read both.

Directory under spec: `temporal/olympus_workflows/registries/`

```
registries/
  engine.py             # shared substrate (Registry[T], errors, semver)
  assembly_line.py      # EXT-1  Assembly Line Registry
  disposition.py        # EXT-2  Disposition Strategy Registry
  analysis_pass.py      # EXT-3  Analysis Pass Registry
  scoring_dimension.py  # EXT-4  Scoring Dimension Registry
  gate_provider.py      # EXT-5  Gate Provider Registry
  skill_composition.py  # EXT-6  Skill Composition Registry
  loop_pattern.py       # CATALOG (P10-S18.1) — NOT a 7th extension point (see §2.8)
  profile_overrides.py  # single seam that applies a Profile to the 6 registries
  worker_bootstrap.py   # worker-side profile activation + cardinality guard
  defaults/             # canonical on-disk YAML mirrors of the Python defaults
    dispositions.yaml scoring-dimensions.yaml skill-compositions.yaml
    gate-providers.yaml autonomy.yaml
```

> **GOTCHA — "6 vs 7" naming.** The prior spec said "6 extension registries". The prompt for this task says "7 pluggable
> registries" and lists `loop_pattern.py` as the 7th. The **live code is explicit that this is NOT true**:
> `loop_pattern.py:9-14` states *"DECISION-010 (<=6 extension registries) — IMPORTANT: this is **NOT** a 7th
> extension-point registry. It is a *catalog entry set* built on the existing shared `Registry` engine … It declares no
> new extension point; it is read-only data."* The `__init__.py:116` comment agrees. So the **canonical count is 6
> extension points** (EXT-1..6) plus the **Loop-Pattern catalog** (data, on the same substrate) plus **`worker_bootstrap`**
> (the wiring/activation layer, not an extension point). This doc documents all of them so nothing is lost, but do not
> re-materialize a "7th extension registry" — the substrate/count invariant is guarded (`tests/invariants/`).

---

## 1. The shared registry substrate — `engine.py`

Every concrete registry composes (does NOT inherit) a `Registry[T]` engine instance stored as `self._engine`
(`assembly_line.py:104`, `disposition.py:188`, etc.). The engine is a thin, type-safe, **in-memory, non-database**
CRUD + versioning + dependency-cycle layer (`engine.py:21-27`).

### 1.1 Design invariants (`engine.py:1-41`)
- Registries are **populated at module import** for Temporal determinism; profile overrides apply **once at worker
  startup** via `apply_profile`. The engine only makes the CRUD surface uniform.
- Entity types are **frozen dataclasses** in the concrete modules (workflow code passes them freely; the engine stores
  them keyed by id, **case-insensitive by default**).
- **Version tracking lives alongside the entities, not on them** — a separate `_versions: dict[str, VersionRecord]`,
  so the frozen dataclass stays source-of-truth and a bump does not require field mutation.

### 1.2 Errors (`engine.py:67-92`)
| Class | Base | Raised when |
|---|---|---|
| `RegistryError` | `RuntimeError` | base for all engine errors |
| `EntityExists` | `RegistryError` | `register(overwrite=False)` and id already present |
| `EntityNotFound` | `KeyError, RegistryError` | `get`/`delete`/`bump_version`/`version` miss — inherits `KeyError` so legacy dict-lookup catchers still work |
| `EntityHasDependents` | `RegistryError` | `delete` would orphan an entity that declares the id in its dep list |
| `RegistryValidationError` | `RegistryError` | a configured validator rejected an entity |
| `CircularDependencyError` | `RegistryError` | a registration would complete a cycle in the dep graph |

Each concrete registry subclasses `EntityNotFound` into a domain error (`UnknownAssemblyLineError`,
`UnknownDispositionError`, `UnknownAnalysisPassError`, `UnknownSkillCompositionError`, `UnknownGateProviderError`,
`UnknownLoopPatternError`) so `get()` misses surface a typed, message-rich error listing the known ids.

### 1.3 Semver helpers (`engine.py:100-165`)
- `parse_semver(value)` — strips a leading `v`/`V`, strips a `-prerelease`/`+build` suffix at the first `-`/`+`, splits
  on `.`, requires **exactly 3** integer components, rejects negatives; returns `(major, minor, patch)`
  (`engine.py:100-123`).
- `bump_semver(current, kind)` — `kind ∈ {major, minor, patch}` (case-insensitive); **major/minor zero the lower
  components** (`1.2.3`→`2.0.0` major, `1.3.0` minor, `1.2.4` patch); unknown kind raises `ValueError`
  (`engine.py:126-141`).
- `VersionRecord` dataclass — `version="1.0.0"`, append-only `history: list[str]`. `__post_init__` eagerly validates the
  semver and seeds `history=[version]` if empty. `bump(kind)` mutates `version`, appends to `history`, returns new value
  (`engine.py:144-165`).

### 1.4 `Registry[T]` construction (`engine.py:181-213`)
Keyword-only constructor:
```python
Registry(
    id_getter: Callable[[T], str],          # required — extract the id
    dep_getter: Callable[[T], Iterable[str]] | None = None,  # default () — no deps
    validators: Iterable[Callable[[T], None]] | None = None,
    case_sensitive: bool = False,
)
```
State: `_entities: dict[str, T]`, `_versions: dict[str, VersionRecord]`. `_key(id)` lower-cases unless `case_sensitive`
(`engine.py:219-220`). `_id_of(entity)` = `_key(id_getter(entity))`.

### 1.5 Validation hooks (`engine.py:229-250`)
- `add_validator(v)` appends; `validate(entity)` runs every validator. A validator may raise anything; the engine
  **re-raises `RegistryValidationError` as-is** but **wraps any other exception** in `RegistryValidationError` with the
  entity id and validator name (`engine.py:242-250`). GOTCHA: the wrap uses `_id_getter(entity)` (the raw label, not the
  normalized key) for the message.

### 1.6 CRUD (`engine.py:256-359`)
- **`register(entity, *, overwrite=True, version=None)`** (`engine.py:256-303`):
  1. `validate(entity)` first.
  2. Compute key; if `not overwrite and key in _entities` → raise `EntityExists`.
  3. **Stage then rollback on cycle failure**: save `previous`/`previous_version`, set `_entities[key]=entity`, call
     `_assert_no_cycle(key)`. On `CircularDependencyError`, restore `previous` (or delete if it was new) then re-raise —
     **a rejected registration leaves the registry unchanged** (GOTCHA: this rollback is why cycle detection is safe to
     do post-insert).
  4. Version seeding: explicit `version` → new `VersionRecord(version)`; else if no prior record → fresh `1.0.0`; else
     **keep the existing record across overwrite** (`engine.py:299-303`).
  - Default `overwrite=True` preserves the legacy "later registration wins" behaviour that profile overrides and
    re-imports depend on (`engine.py:263-268`).
- **`upsert(entity, *, version=None)`** = `register(overwrite=True)` (`engine.py:305-307`).
- **`get(id)`** — raises `EntityNotFound` with a sorted "Known:" list (`engine.py:309-316`).
- `has(id)`, `list_all()` (insertion order), `ids()` (canonical/lower ids), `labels()` (id as the entity reports it,
  casing preserved) (`engine.py:318-331`).
- **`delete(id)`** — raises `EntityNotFound` if absent; computes `dependents(id)` and raises `EntityHasDependents`
  (sorted list) if any; else pops entity + version and returns the removed entity (`engine.py:333-354`).
- `clear()` empties both dicts (`engine.py:356-359`).

### 1.7 Versioning surface (`engine.py:365-387`)
`version(id)` (lazily seeds a `VersionRecord` if the entity exists but has none), `version_history(id)` (copy),
`bump_version(id, kind)` (raises `EntityNotFound` for unknown id, else `record.bump(kind)`).

### 1.8 Dependencies & cycle detection (`engine.py:393-438`)
- `dependencies(id)` — returns the entity's declared deps **as declared** (no re-normalization — `_id_getter_of_dep`
  is identity, `engine.py:398-401`).
- `dependents(id)` — scans every OTHER entity; matches deps **normalized** (`_key(dep) == needle`); returns a set of the
  dependents' **reported ids** (`engine.py:403-414`).
- `_assert_no_cycle(start_key)` — DFS with `visiting`/`visited` sets; raises `CircularDependencyError` on a back-edge.
  Deps that are not registered ids are skipped (`if dep_key in self._entities`) so a forward reference to a
  not-yet-registered line is not a cycle (`engine.py:416-438`).
- Dunder helpers: `__iter__` (values), `__len__`, `__contains__` (str only, via `has`) (`engine.py:444-453`).

---

## 2. The extension registries (EXT-1..6) + the Loop-Pattern catalog

For each: the entity contract, the registry wrapper API, the registration mechanism, defaults, and a worked example.
All are declared/re-exported from `registries/__init__.py:22-159`.

### 2.1 EXT-1 — Assembly Line Registry (`assembly_line.py`)

**Entity `AssemblyLine`** (frozen dataclass, `assembly_line.py:41-60`):
`name`, `description=""`, `steps: tuple[str,...]=()`, `gates: tuple[str,...]=()`, `depends_on: tuple[str,...]=()`,
`inputs: tuple[str,...]=()`, `outputs: tuple[str,...]=()`, `mode="per-app"`, `metadata: dict=()`.

**Validator `_validate_assembly_line`** (`assembly_line.py:75-86`): name non-empty; `mode ∈
{"per-app","per-wave","per-target-app","continuous"}` (`_VALID_MODES`, line 72); **`depends_on` must be distinct** —
duplicate → `ValueError` (silent dedupe would hide profile bugs).

**Registry `AssemblyLineRegistry`** (`assembly_line.py:94-149`): composes `Registry(id_getter=name,
dep_getter=depends_on, validators=[_validate_assembly_line])`. Methods `register` (→`upsert`), `get` (wraps miss in
`UnknownAssemblyLineError` with known-lines list), `has`, `list_all`, `labels`, `delete` (re-raises `EntityHasDependents`,
wraps `EntityNotFound`), `version`, `bump_version`, `dependents`.

**Registration mechanism** (`assembly_line.py:156-187`): defaults are **loaded from the authoritative contract YAML**,
not hardcoded. `_load_default_lines_from_contract()` calls `olympus_contracts.list_lines()` and maps each contract
line → `AssemblyLine(name, description, steps=line.step_ids(), gates=tuple(g.id ...), depends_on, inputs, outputs,
mode)`. `_DEFAULT_LINES` computed at import; `register_default_lines(registry)` upserts each; module singleton
`ASSEMBLY_LINE_REGISTRY` is created and populated at import (line 186-187). **Editing a `data/assembly-lines/*.yaml`
contract file changes the registry at import time.**

> The 11 canonical line names come from `olympus_contracts.enums.AssemblyLine` (`enums.py:309`, docstring "The 11
> assembly line names"): `Discovery, Rationalization, Architecture, Data, Modernization, Build, Disposition Execution,
> Validation, Deployment, Sustainment, Governance`. There are 12 contract YAMLs (the extra is
> `reverse-engineering.yaml`); `Build` is registry-additive at the framework level, NOT a profile-declarable line.

### 2.2 EXT-2 — Disposition Strategy Registry (`disposition.py`)

**`StepSpec`** (frozen, `disposition.py:52-63`): `step`, `skill_id`, `artifact` — a single dispatchable step (agent
activity name, skill to load, artifact file committed to the branch).

**`DispositionStrategy`** (frozen, `disposition.py:66-149`): `label` (canonical casing preserved), `pre_gate1_steps:
tuple[StepSpec,...]`, `post_gate1_steps: tuple[StepSpec,...]`, `has_gate2: bool`, `max_rework_iterations=3`,
`workflow="DispositionWorkflow"`, `required_gates: tuple[str,...]=()`, `metadata`. Derived properties:
- `has_gate1` → always `True` (property, not a field — every current strategy uses G-DE-1) (`disposition.py:102-111`).
- `title_label` = `label` (alias to match the pre-registry field name) (`disposition.py:113-121`).
- `steps` = `pre_gate1_steps + post_gate1_steps` (`disposition.py:123-126`).
- `skills` = `{step: skill_id for each step}` (`disposition.py:128-131`).
- `effective_required_gates()` (`disposition.py:133-149`): if `required_gates` set → it wins; else derive
  `["G-DE-1"] + (["G-DE-2"] if has_gate2)`.

**Validator `_validate_disposition`** (`disposition.py:166-176`): label non-empty; `max_rework_iterations >= 0`;
`workflow` non-empty.

**Registry `DispositionStrategyRegistry`** (`disposition.py:179-243`): `Registry(id_getter=label, dep_getter=()`
[dispositions have no inter-deps], `validators=[_validate_disposition])`. `get()` misses raise
`UnknownDispositionError` — **Retire is not a safe default; unknown dispositions fail loudly** (`disposition.py:203-218`).

**Registration** (`disposition.py:261-491`): five module-level `DispositionStrategy` constants — `_RETIRE`, `_RETAIN`,
`_REPLACE`, `_REPLATFORM`, `_CONSOLIDATE`. `_DEFAULT_STRATEGIES` tuple; `register_default_strategies()`; module singleton
`DISPOSITION_REGISTRY` populated at import.

> **GOTCHA — only 5 of 8 dispositions are registered.** `Refactor` and `Rearchitect` flow through
> `ModernizationWorkflow` and are **intentionally NOT registered**; `DispositionWorkflow` short-circuits them before
> registry lookup (`disposition.py:9-14`, `474-483`). `Build` (the 8th) runs via Modernization's Generate fan-out, not
> here. So `DISPOSITION_REGISTRY.labels()` == `["Retire","Retain","Replace","Replatform","Consolidate"]`.

**Worked example — `_RETIRE`** (`disposition.py:261-303`): `pre_gate1_steps` = user-transition-plan
(skill `user-transition-planning`), data-archival-plan (`data-archival-planning`); `post_gate1_steps` =
consumer-migration (`consumer-migration-planning`), infrastructure-decommission (`legacy-decommission`),
security-decommission (`security-decommission`), license-reclamation (`license-reclamation`),
cost-savings-certification (`tco-analyzer`); `has_gate2=True`. `Retain` uniquely has `has_gate2=False` and empty
`post_gate1_steps` (no decommission phase) (`disposition.py:306-337`).

> **GOTCHA — Python vs YAML skill-id divergence.** The runtime authority is the Python `_DEFAULT_STRATEGIES`
> (`disposition.py:250-252`). The on-disk `defaults/dispositions.yaml` uses **different skill ids** for the SAME steps
> (e.g. Retire's `user-transition-plan` → `plan-retirement` in YAML vs `user-transition-planning` in Python;
> Replace's `data-migration` → `data-modeling` in YAML vs `data-migration-planning` in Python). The YAML is described as
> the "canonical YAML representation for the Admin/API surface" (`defaults/dispositions.yaml:1-9`) but is **not** what the
> workflow runs. Reproduce the Python constants for behavioral parity; the YAML is documentation.

### 2.3 EXT-3 — Analysis Pass Registry (`analysis_pass.py`)

**`AnalysisPass`** (frozen, `analysis_pass.py:34-50`): `name`, `skill_id`, `artifact`, `depends_on: tuple=()`,
`pass_number=0`, `synthesis_rule="synthesis"`, `parallel_with: tuple=()`, `metadata`.

**Validator** (`analysis_pass.py:57-67`): name/skill_id/artifact non-empty; `pass_number >= 0`.

**Registry `AnalysisPassRegistry`** (`analysis_pass.py:70-113`): `Registry(id_getter=name, dep_getter=depends_on,
validators=[_validate_analysis_pass])`. Note the accessor is `names()` (not `labels()`).

**Registration** (`analysis_pass.py:116-171`): `_load_default_passes_from_contract()` reads the Discovery contract line
(`olympus_contracts.get_line("Discovery")`), iterates `line.evidence_steps()` (skipping steps with no skills), and for
each builds an `AnalysisPass(name=step.id, skill_id=step.skills[0], artifact=..., depends_on=<producer step ids derived
by matching input artifacts to producer output artifacts, deduped>, pass_number=step.sequence,
synthesis_rule="none" if is_terminal else "synthesis", parallel_with=step.parallel_with)`. `is_terminal` =
`step.summary OR (summary_step.id in step.parallel_with)` (`analysis_pass.py:135-137`). Singleton
`ANALYSIS_PASS_REGISTRY` populated at import.

### 2.4 EXT-4 — Scoring Dimension Registry (`scoring_dimension.py`)

**`ScoringDimensionEntry`** (frozen, `scoring_dimension.py:31-48`): `name`, `weight: float`, `default_weight=None`,
`rationale=""`, `data_source=""`, `scoring_function=""`, `bounds=(0.0,1.0)`, `metadata`.

**Validator** (`scoring_dimension.py:51-64`): name non-empty; `weight >= 0`; `weight <= 1.0 + 1e-6`; `bounds` low<=high.

**Registry `ScoringDimensionRegistry`** (`scoring_dimension.py:67-151`): `Registry(id_getter=name,
case_sensitive=True` [dimension names are canonical ids], `validators=[...])`. Key behaviors:
- The registry does **not** enforce weight-sum on each individual register (intermediate bulk-override states may be
  off-total).
- **`replace_all(dimensions)`** (`scoring_dimension.py:90-106`): sums weights, raises `ValueError` unless
  `isclose(total, 1.0, abs_tol=1e-3)`; validates every entry up front; then `clear()` + upsert each. Atomic-ish (a bad
  entry rejects the whole batch).
- `validate_weights()` / `validate_ready()` — assert sum≈1.0 (`scoring_dimension.py:135-151`).
- `get(name)` returns `None` on miss (NOT an exception) (`scoring_dimension.py:108-112`); `delete` wraps miss in
  `KeyError`.

**Defaults** (`scoring_dimension.py:154-215`): 7 entries. Six scoring dimensions summing to 1.0:
`code-quality 0.20, test-coverage 0.15, security-posture 0.20, documentation 0.10, dependency-currency 0.15,
architecture-clarity 0.20`. Plus a **7th diagnostic dimension** `autonomy-readiness` at **weight 0.0**
(`scoring_dimension.py:203-214`, P10-S18.1 REQ-AG-007): non-scoring, never perturbs the composite, `data_source=
"autonomy-eval"`, `scoring_function="autonomy_readiness_score"`, bounds (0.0,1.0). `register_default_dimensions()` calls
`replace_all(list(_DEFAULT_DIMENSIONS))`; singleton `SCORING_DIMENSION_REGISTRY` at import (line 222-223).

> GOTCHA: weight-sum still holds because the six original weights already sum to 1.0 and the 7th is 0.0. If you re-add
> the 7th at any non-zero weight the whole set must be re-normalized or `replace_all` raises.

### 2.5 EXT-5 — Gate Provider Registry (`gate_provider.py`)

**Adapter protocol `GateProviderAdapter`** (runtime-checkable, `gate_provider.py:71-90`): attribute `provider_id: str`,
methods `initiate(request) -> GateApprovalStatus`, `poll(request) -> GateApprovalStatus`, `close(request, status) ->
None`. **`GateApprovalRequest`** (frozen, `:44-52`): `gate_id`, `artifact_url=""`, `title=""`, `reviewers=()`,
`context: dict=()`. **`GateApprovalStatus`** (frozen, `:55-68`): `state ∈ {pending,approved,rejected,cancelled}`,
`decided_by=""`, `reason=""`, `metadata`.

**Concrete adapters:**
- `GitHubPRGateProvider` (`provider_id="github-pr"`, `:93-138`) — default, fully wired. `initiate` returns `pending`
  (echoing `artifact_url`); `poll` reads `request.context["decision"]` — `{approved,merged}`→`approved`,
  `{rejected,changes_requested,closed}`→`rejected`, else `pending` (echoes reviewer/reason); `close` no-op. Olympus
  pushes PR state into the workflow via signals; the adapter just normalizes.
- `AutomatedOnlyGateProvider` (`provider_id="automated-only"`, `:141-177`) — no human. `poll` reads
  `request.context["predicates"]` (a `dict[str,bool]`): **empty/non-dict → `pending`** with reason "no predicates
  provided" (a zero-predicate automated gate is a misconfiguration); any `False` predicate → `rejected` with sorted
  failing names; all `True` → `approved` decided_by "automated". **This is the adapter the autonomy gate rides on (§4).**
- `ServiceNowGateProvider` (`provider_id="servicenow"`, `:180-206`) and `JIRAGateProvider` (`provider_id="jira"`,
  `:209-233`) — **stubs**; every method raises `NotImplementedError`.
- `_BUILTIN_ADAPTERS` maps provider_id → shared instance (`:236-241`); `builtin_adapter(id)` looks up lower-cased
  (`:244-246`).

**Entity `GateProvider`** (frozen, `:254-268`): `id`, `description=""`, `supports_automated=False`,
`requires_human=True`, `metadata`, `implemented=True`. **Validator** (`:275-285`): id non-empty; **`supports_automated`
and `requires_human` cannot BOTH be True** (raises — no such provider exists today).

**Registry `GateProviderRegistry`** (`:288-365`): `Registry(id_getter=id, validators=[...])` PLUS two extra fields:
`_gate_overrides: dict[str, dict]` (per-gate profile overrides keyed by gate id) and `_default_provider_id: str`.
Methods beyond the standard set: `set_default(id)` (raises `UnknownGateProviderError` if unknown), `default_provider`
property, `set_gate_overrides(gate_id, dict)` / `gate_overrides(gate_id)` / `clear_gate_overrides()` /
`all_gate_overrides()`, `adapter_for(id)` (returns the built-in adapter instance or `None` if provider unregistered).

**Registration** (`:368-407`): `_DEFAULT_PROVIDERS` = the four above; `register_default_providers()` registers all +
`set_default("github-pr")`; singleton `GATE_PROVIDER_REGISTRY` at import.

### 2.6 EXT-6 — Skill Composition Registry (`skill_composition.py`) — **the retired-router mechanism (P10 W5)**

`VALID_MODES = {"sequential","parallel","conditional"}` (`skill_composition.py:39`).

**`SkillComposition`** (frozen, `:42-71`): `name`, `skills: tuple[str,...]`, `mode="sequential"`, `description=""`,
`conditions: dict[str,str]=()` (skill-id → free-form expression string, for `conditional` mode), `variant_selectors:
dict[str,str]=()`, `metadata: dict=()`. Values are strings to preserve Temporal determinism (no live function refs).

**Validator** (`:83-101`): name non-empty; `mode ∈ VALID_MODES`; at least one skill; for `conditional` mode every skill
must have a `conditions[skill]` entry. **`make_skill_presence_validator(known_skill_ids)`** (`:104-132`) builds a
validator that rejects a composition naming an unknown skill — but **returns early (permissive) when the id set is
empty**, keeping Temporal imports decoupled from the API-side skill YAML.

**Registry `SkillCompositionRegistry`** (`:140-192`): `Registry(id_getter=name, validators=[_validate_skill_composition])`.
`add_validator(v)` forwards to the engine (used at API startup to attach the presence validator). Standard CRUD +
version. Singleton `SKILL_COMPOSITION_REGISTRY` created **empty** at import (`:194-195`) — no defaults populated at
import time.

**GOTCHA — how routing works now (P10 W5 retired the 5 Python routers).** The former hardcoded routers
(`discovery_patterns_router`, `data_router`, `architecture_patterns_router`, `modernization._select_extraction_skill`,
`code_generation_router`) are replaced by **data-driven variant-selection compositions**. Mechanism spans three modules:

1. **`composition/rules.py`** — the rule model (`rules.py:1-33`):
   - `normalize(value)` — lower+strip, `None`→`""` (`rules.py:40-47`).
   - `SelectionRule` (frozen, `:50-98`): exactly one `match` kind of `{token, substring, equals, pair, field_in_map}`,
     `skill: str|None` (None models a skip-step router), `needles`, `fields`, `pairs`, `value_map`. `__post_init__`
     validates the match kind requires its companion field.
   - `SelectorInputs` (frozen, `:101-121`): `fields: dict[str,str]` (normalized scalars), `tokens: frozenset[str]`,
     `candidates: tuple[str,...]` (raw lower-cased for substring probes). Built **once** from raw runtime inputs so the
     expansion is a pure function of the snapshot.
   - `VariantSelectionTable` (`:124-228`): ordered `rules` + a `default: str|None`. `select(inputs)` → **first matching
     rule wins, else default** (pure). `_match` implements each kind (`:183-228`): `token` = set-intersection of
     normalized needles with `inputs.tokens`; `substring` = normalized needle in any candidate (scans `tokens +
     candidates` when no `fields`, else the named fields); `equals` = field value in normalized needles; `pair` = the
     two named fields equal one of `pairs`; `field_in_map` = field value is a key of `value_map` → returns
     `value_map[value]`. `candidate_skills()` enumerates every possible selection for validity checks.

2. **`composition/registered.py`** — the five router-replacement compositions carrying a `VariantSelectionTable` in
   `metadata["selection_table"]`, each `mode="conditional"` with a single always-on skill and a `default`:
   - `discovery-patterns-selection` (default `discovery-patterns`, `registered.py:105-119`): rules encode
     doc-only-when-no-source (`equals has_source_available=false`), mainframe token/substring family
     (`_MAINFRAME_TOKENS_DISCOVERY`, `:35-38`), then DB matchers (`_DISCOVERY_DB_MATCHERS`) then language matchers
     (`_DISCOVERY_LANG_MATCHERS`) as ordered substring rules. **Ordering is load-bearing — it reproduces the router's
     most→least-specific resolution exactly** (`registered.py:14`).
   - `data-product-design-selection` (default `data-product-specification`, `:250-264`): mainframe token rule, then a
     `field_in_map` on `database` via `_DATA_DATABASE_MAP`, then one `token` rule per map key.
   - `architecture-blueprint-selection` (default `target-architecture-blueprint`, `:325-339`): one `equals` rule on
     `disposition` per `_DISPOSITION_BLUEPRINT_MAP` (`:301-310`) — Retire/Retain map to `skill=None` (skip step).
   - `extraction-selection` (default `extraction`, `:379-393`): substring rules per language in `_LANGUAGE_SKILL_MAP`.
   - `code-generation-selection` (default `code-generation`, `:464-478`, **retired LAST — most complex**): `pair` rules
     for `(primary_language, target_framework)` specialists (cobol→springboot etc., `_CODE_GENERATION_PAIR_MAP`), then
     `field_in_map` on `target_frontend`, then on `target_framework`.
   - Each module also exports a `*_selector_inputs(...)` builder that mirrors the retired router's tokenization exactly
     (e.g. `discovery_selector_inputs`, `:122-187`, reproduces `_fingerprint_tokens` + `_raw_text_candidates` and leads
     the substring candidate list with `database` + `primary_language`).
   - `register_router_compositions(registry=None)` (`:509-520`) upserts all five into `SKILL_COMPOSITION_REGISTRY` at
     worker/API startup. **This is called from `reset_registries_to_defaults`** (`profile_overrides.py:305-310`),
     lazily imported to avoid a cycle.

3. **`composition/evaluator.py`** — the deterministic expander (`evaluator.py:1-26`, "Model 2 orchestration-level
   composition"; Model 1 = one agent loading N bodies is REJECTED):
   - `SkillDispatch` (frozen, `:40-65`): one independent single-skill dispatch — `skill`, `order`, `mode`,
     `provenance_key` (defaults to the skill id via `__post_init__`), `condition`.
   - `evaluate_composition(composition, inputs=None)` (`:131-196`, PURE): if the composition carries a
     `selection_table`, `table.select(snapshot)` picks ONE skill (None → empty expansion); otherwise dispatch by mode —
     `parallel` (all order 0), `conditional` (only truthy-condition skills, preserving order), `sequential` (ascending
     order).
   - `_condition_truthy(expr, inputs)` (`:101-128`) — a tiny deterministic grammar (NOT `eval`): `""`/`"true"`/`"always"`
     → True; `has:<token>` → token in bag; `<field> == <value>`; `<field> in a|b|c`; **anything unrecognized → True
     (fail-open, advisory)**.
   - `select_skill(composition, inputs)` (`:199-209`) — the router-parity convenience returning the single selected id.

### 2.7 The Loop-Pattern **catalog** (`loop_pattern.py`) — a catalog on the substrate, **NOT** EXT-7

**`LoopPattern`** (frozen, `loop_pattern.py:48-64`): `name`, `cadence` (a cron expression — the Temporal Schedule
cadence; the catalog declares *how often*, not a scheduler), `default_autonomy_level`, `description=""`,
`inputs: tuple=()`, `outputs: tuple=()`, `metadata`.

`VALID_AUTONOMY_LEVELS = {"report_only","assisted","unattended"}` (frozenset, `:43-45`) — kept in lock-step with the
autonomy resolver and the `autonomy-policy.schema.json` enum; defined here so the validator rejects an unknown level
without importing the resolver (avoids a cycle; keeps the module free of any evidence-layer dependency).

**Validator** (`:71-83`): name non-empty; cadence non-empty; `default_autonomy_level ∈ VALID_AUTONOMY_LEVELS`.

**Registry `LoopPatternRegistry`** (`:86-132`): plain `Registry(id_getter=name, validators=[_validate_loop_pattern])`,
`names()` accessor. Singleton `LOOP_PATTERN_REGISTRY` populated at import via `register_default_patterns`.

**The 6 default patterns** (`:138-220`, REQ-AG-009 + P9-S17.6):
| name | cadence | default_autonomy_level | inputs → outputs |
|---|---|---|---|
| `dependency-sweep` | `0 6 * * 1` (weekly Mon 06:00) | `assisted` | dependency-manifest → dependency-upgrade-pr |
| `cve-triage` | `0 * * * *` (hourly) | `report_only` | vulnerability-feed, dependency-manifest → cve-exposure-report |
| `ci-repair` | `*/15 * * * *` (every 15 min) | `assisted` | ci-run-status → ci-repair-pr |
| `pr-babysit` | `*/10 * * * *` (every 10 min) | `report_only` | open-pull-requests → pr-status-digest |
| `post-merge-cleanup` | `0 2 * * *` (daily 02:00) | `unattended` | merged-branch-event → cleanup-summary |
| `error-triage` | `0 3 * * *` (nightly 03:00) | `report_only` | error-signal-sources → incident-digest |

`error-triage` (P9-S17.6, `:194-219`) is the nightly error-signal sweep: capture from structured sources
(`ai_work_log`/`agent_run`/`event_outbox.last_error`, optional Prometheus ALERTS), cluster into deduplicated incident
candidates, route each remediation THROUGH the `autonomy_level` gate; conservative `report_only` floor — opens no PR,
mutates no code (STOP-AND-ASK default).

> **GOTCHA — a pattern's `default_autonomy_level` is only *requested*.** The catalog never grants autonomy; the gate
> (§4) caps the requested rung to the touched app's tier max (REQ-AG-002), and a profile denylist match forces
> escalation regardless of tier (REQ-AG-003) (`loop_pattern.py:16-19`). There is **no `loop-patterns.yaml`** under
> `defaults/` — the catalog is Python-only (unlike the other registries which also mirror to YAML).

### 2.8 `__init__.py` re-exports & count discipline

`registries/__init__.py:1-19` docstring lists the "six extension points" (EXT-1..6). The loop-pattern block
(`:116-122`) is explicitly annotated `"P10-S18.1; on the shared substrate, NOT a 7th registry"`. Everything above is
re-exported in `__all__` (`:96-159`).

---

## 3. `profile_overrides.py` — the single apply seam over the 6 registries

`profile_overrides.py:1-20`. Precedence (`:9-14`): (1) registry defaults at import → (2) profile overrides applied once
at startup → (3) tests may `reset_registries_to_defaults`. Temporal stays loosely coupled: the module accepts a
**duck-typed** profile object matching Protocols (`_ScoringShape`, `_GatesShape`, `_ProfileMetadataShape`,
`_ProfileShape`, `:66-102`) rather than importing `olympus_api`'s `Profile`.

**`RegistryBundle`** (`:109-132`) holds the 6 registries (assembly_lines, dispositions, analysis_passes,
scoring_dimensions, gate_providers, skill_compositions). `default_registries()` returns the module singletons
(`:135-144`).

**`apply_profile(profile, bundle=None)`** (`:152-179`) — idempotent; calls, in order:
- `_apply_scoring` (`:182-202`): maps `profile.scoring.dimensions` → `ScoringDimensionEntry` list → `replace_all` (which
  re-validates sum≈1.0). GOTCHA: the profile's dimensions must sum to 1.0 or startup raises.
- `_apply_gates` (`:205-234`): if `gates.default_provider` set and unknown → raise `ValueError`; else `set_default`.
  Then `clear_gate_overrides()` and for each override `set_gate_overrides(gate_id, {"profile_additions": additions,
  "faa_additions": additions, "reviewer_override": ...})`. **GOTCHA — the deprecated `faa_additions` mirror**: written
  alongside the client-neutral `profile_additions` for one release (P6-S10.4) so old readers don't break mid-migration.
- `_apply_skill_composition` (`:237-268`): if the profile ships skills, register a `SkillComposition` named
  `"<profile_id>-profile-skills"` (mode sequential) whose skills are the directory names extracted from
  `"skills/<id>/SKILL.md"` entries (takes `parts[-2]`).
- Assembly-line / disposition / analysis-pass overrides are **no-ops today** — the hook exists but FAA ships none
  (`:174-178`).

**`reset_registries_to_defaults(bundle=None)`** (`:271-312`): re-`__init__`s each registry and re-registers defaults.
**GOTCHA — the skill-composition reset does NOT restore an empty registry**: it re-`__init__`s then calls
`register_router_compositions` (lazily imported, `:305-310`) — i.e. reset **seeds the five router-replacement
compositions** (the mechanism that replaced the retired Python routers). This is the only registry whose "defaults"
differ between import (empty) and reset (5 router compositions).

---

## 4. `worker_bootstrap.py` — worker-side profile activation + the cardinality guard

Not an extension point — the **wiring layer** that activates a profile on the Temporal worker
(`worker_bootstrap.py:1-17`). Mirrors the API's `profile_activation` but lives inside the Temporal package with a
**minimal YAML-to-stub parser** so Temporal stays dependency-light.

- `bootstrap_profile_from_env()` (`:311-351`): reads `OLYMPUS_PROFILE`; if unset → returns None (default registries).
  Resolves candidates from `OLYMPUS_PROFILES_DIR` then walks up from `__file__` looking for `profiles/<id>`; on the
  first dir, `load_profile_stub` then `apply_profile`; wraps failures in `ProfileBootstrapError` (fail fast). Called by
  `olympus_workflows.worker.run_worker` before the worker accepts tasks (`:14-16`).
- `load_profile_stub(root)` (`:239-303`): parses `profile.yaml`/`scoring.yaml`/`gates.yaml` into duck-typed dataclasses
  (`_ProfileStub` etc., `:78-118`) matching the Protocols in `profile_overrides.py`. Handles the `profile_additions`→
  `faa_additions` fallback on read.
- **`_reject_cardinality_drift(root, prof, gates)`** (`:139-236`) — the worker-path mirror of the API loader's
  REQ-PF-102/103/104 guard (see §6). Re-derives canonical sets from the **frozen `olympus_contracts` enums**
  (`_CANONICAL_GATE_IDS`, `_CANONICAL_DISPOSITIONS`, `_CANONICAL_ASSEMBLY_LINES`, `:55-70`) so the worker and API can
  never diverge. Rejects: a `gates.overrides` key outside the 18-gate set; a `gates.gate_records`/`gate_ids` set that
  isn't exactly the canonical set; a `profile.dispositions` value outside the 8; a
  `profile.assembly_lines`/`profile.lines` value outside the 11. **GOTCHA — this guard exists because the worker uses a
  SEPARATE minimal parser** (`:38-53`), so the API loader's guard does NOT run on the worker boot path — without this a
  drifting profile would be silently pushed into the live production registries.

---

## 5. The line-to-line contract (how artifacts couple producer→consumer)

### 5.1 Coupling model
Lines communicate through **versioned artifacts** with schema-validated contracts (see repo `CLAUDE.md` architecture
section). The **producer→consumer coupling is by artifact id**: `AssemblyLine.outputs` / `.inputs` are the declared
artifact-id tuples (`assembly_line.py:57-58`), sourced from the contract YAMLs. The Analysis Pass registry derives
`depends_on` by **matching each consumer step's input artifact names back to the producer step whose `outputs.artifacts`
contains them** (`analysis_pass.py:143-147`) — this is the concrete producer→consumer resolution in code.

### 5.2 Line dispatch handoff (`orchestration.py`)
`start_next_line_workflow(input)` (`orchestration.py:103-214`) is the transition activity that hands one line's output to
the next line:
- **Dispatchability is registry-driven** (`_resolve_line_workflow`, `:74-93`): a line is dispatchable iff it is
  REGISTERED in `ASSEMBLY_LINE_REGISTRY` **AND** its workflow (an override in `_LINE_WORKFLOW_OVERRIDES` — only
  `"Disposition Execution" → "DispositionWorkflow"`, `:61-63` — else the `{Name}Workflow` naming convention,
  `_derive_workflow_name` strips spaces) is one of `_REGISTERED_LINE_WORKFLOWS` (`:47-58`). Unknown/continuous/
  no-standalone-workflow lines (Build) → `None` → `NonRetryableError` (`:113-117`). This replaced the old hardcoded
  3-entry map (P7-S16.4).
- The activity resolves app + portfolio rows from Postgres, threads `architecture_blueprint_ref` into
  `prior_artifacts` (Modernization's Extract/Design/Generate uses it as the target-state contract, empty for pre-G-02
  apps → source-only Ralph Loop fallback, `:151-160`), starts the next workflow with a fixed input dict
  (`app_id, app_name, wave_id, portfolio_id, artifact_repo, source_repo, target_repo_url, prior_artifacts`,
  `:165-179`), then flips `application.current_status/current_line/workflow_id` for the dashboard.
- `fetch_application_source_repos` (`:217-276`) and `load_app_intake_modes` (`:279-333`) supply source-repo URLs and
  legacy-vs-Build partitioning for wave fan-out (a Build app has `source_type ∈ {requirements_doc, interview}` per
  `_BUILD_SOURCE_TYPES`, `:45`).

### 5.3 Schema validation on read & transition gates
- **Schema validation on read**: consumer lines re-validate the upstream artifact against its JSON schema before use;
  the transition gate (G-* per line) verifies completeness (the producer must have committed every declared
  `outputs.artifact`). The 12 per-line transition modules under `activities/line_transitions/` (architecture.py,
  data.py, modernization.py, validation.py, etc.) each project the prior line's artifacts into the next; the
  detailed per-line projection logic is documented in the assembly-line/workflow spec docs — at the **framework** level
  the contract is: *(producer declares `outputs`) → (Git-committed versioned artifact) → (transition gate verifies the
  declared set is present + schema-valid) → (consumer declares matching `inputs`, resolved by artifact-id match)*.
- Gate completeness verification routes through the **Gate Provider** subsystem (§2.5): the `automated-only` adapter's
  `poll` treats each completeness check as a boolean predicate in `context["predicates"]`; all-True → `approved`, any
  False → `rejected` (the same mechanism the autonomy gate reuses).

---

## 6. Risk-tier, disposition, and gate models — hard enums vs data

Canonical source: `olympus-contracts/olympus_contracts/enums.py`.

| Model | Definition | Hard enum or data? | Notes |
|---|---|---|---|
| **Disposition** | `Disposition(StrEnum)` — 8 members: Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate, Build (`enums.py:14-43`) | **HARD enum** | StrEnum (Temporal payload round-trip). Profiles may NOT add/remove. A disposition selects the downstream line. |
| **Risk tier** | `RiskTier(IntEnum)` — TIER_1=1, TIER_2=2, TIER_3=3 (`enums.py:46-64`) | **HARD enum** (count) | IntEnum; 1=Critical, 3=Low-Risk. Tier **labels/definitions/parameters** are profile DATA; the **count (3) and keys `tier_1/2/3` are hard** (loader requires exactly `{tier_1,tier_2,tier_3}`, `profile_loader.py:395-400`). |
| **Gate** | `GateType(StrEnum)` — **18 members** (`enums.py:70-...`): G-DC, G-RR, G-DA, G-02, G-DT, G-04a/b/c, **G-NEW-1/2/3** (Build line), G-DE-1/2, G-V1/2/3, G-DP-1/2 | **HARD enum** | Value is the stable code (URLs, Git, DB columns) — MUST NOT rename without migration. Friendly names in `GATE_FRIENDLY_NAMES` (`enums.py`). Profiles may ADD per-gate *criteria/reviewers* but not add/remove a gate. |
| **Assembly line** | `AssemblyLine(StrEnum)` — 11 members (`enums.py:309`) | **HARD enum** | Build is registry-additive, not enum/profile-declarable. |
| **Complexity** | `ComplexityTier(StrEnum)` — simple/moderate/complex | HARD enum | |
| **Archetype** | `Archetype(StrEnum)` — web-app/batch-etl/api-service/scheduled-job/hybrid | HARD enum | |
| **Disposition strategy bodies** | `DispositionStrategy` records in the registry | **DATA** (registry) | The 5 registered strategies' steps/skills/gates are registry data, profile-overridable. |
| **Scoring dimensions** | `ScoringDimensionEntry` records | **DATA** (registry) | Weights profile-overridable; sum must be 1.0. Names are canonical (case-sensitive registry). |

> **Enum→varchar/CHECK ("flexibility") migrations vs still-hard enums.** The domain identity vocabulary above is
> **still hard Python enums** (`Disposition`, `RiskTier`, `GateType`, `AssemblyLine`) — the count guard in the profile
> loader/worker bootstrap (`profile_loader.py:91-93`, `worker_bootstrap.py:55-57`) re-derives its rejection sets from
> these enums precisely so they cannot drift. The **advisory autonomy gate is deliberately NOT a `GateType` member**
> (`autonomy.py:32-39`, `65`) — it rides the free-form `automated-only` predicate mechanism (like `G-DRIFT`/`G-AUDIT`)
> so the 18-gate cardinality is preserved. The flexibility that DOES exist is at the **registry/data** layer (strategy
> bodies, scoring weights, gate criteria, providers, compositions, loop patterns), never at the enum-cardinality layer.

**GATE-COUNT DISCREPANCY (verify carefully on rebuild):** `enums.py:70` docstring and `GATE_FRIENDLY_NAMES` enumerate
**18** gates (the standard 15 + the 3 Build gates G-NEW-1/2/3). The **profile YAML comments** and some guard messages
still say "15 standard gates" (e.g. `profile_loader.py:439-451`, `vba/gates.yaml`, `test-generic/gates.yaml`,
`baseline/gates.yaml`). The **runtime guard uses `len(_CANONICAL_GATE_IDS)` derived from the enum**, so the effective
canonical set is **18** (the message string interpolates the real count). Reproduce **18** `GateType` members; treat the
"15" in comments as stale prose.

---

## 7. The AUTONOMY-GATING framework (P9/P10-S18)

The backbone the autonomy executors ride on. Three code units + profile DATA:
`autonomy.py` (pure engine), `registries/loop_pattern.py` (§2.7 — the pattern catalog), `activities/autonomy_eval.py`
(the Temporal activity wrapper), and `profiles/<p>/autonomy.yaml` layered over `registries/defaults/autonomy.yaml`.

### 7.1 `autonomy.py` — the pure engine (`autonomy.py:1-47`)
Intentionally **free of any Temporal/IO import AND any evidence-layer import** (Task-8-INDEPENDENT) — deterministic,
unit-testable. The activity wrapper is the only thing that touches durable state or (behind a flag) the evidence
backbone.

**The ladder** (`autonomy.py:65-80`):
- `AUTONOMY_GATE_ID = "autonomy_level"` — the advisory gate id, **NOT a `GateType` member** (preserves 18-gate count).
- `AUTONOMY_LADDER = ("report_only", "assisted", "unattended")` — lowest rung first; **the list index is the ordinal**
  used for capping. Maps to loop-engineering L1→L2→L3: `report_only` (L1) propose only; `assisted` (L2) open a PR,
  verifier + human merge; `unattended` (L3) act + auto-merge within the allowlist.
- `DEFAULT_AUTONOMY_LEVEL = "report_only"` — the most restrictive rung; fail-closed default (REQ-AG-008).
- `DEFAULT_ATTEMPT_CAP = 3`.
- `_ladder_rank(level)` (`:83-92`): index on the ladder, **unknown → -1** (can never clear a cap or beat `report_only`).

**`cap_level(requested, tier_max)`** (`:95-111`) — returns the LOWER of the two rungs. **Fail-closed rules**: a bogus
`tier_max` (rank<0) → `DEFAULT_AUTONOMY_LEVEL` (never open); an off-ladder `requested` → grant only up to `tier_max`;
else `AUTONOMY_LADDER[min(req_rank, cap_rank)]`. Pure & total, never raises.

### 7.2 `AutonomyPolicy` — per-profile policy as DATA (`autonomy.py:119-186`)
Frozen dataclass (additive; NOT one of the 8 frozen `olympus_contracts` dataclasses). Fields: `profile_id="_defaults"`,
`tier_caps: tuple[tuple[str,str],...]=()` (tier key → max rung), `denylist: tuple[str,...]=()` (fnmatch globs forcing
escalation), `auto_merge_allowlist: tuple[str,...]=()`, `attempt_cap=3`, `default_level="report_only"`,
`deny_by_default=True`. Methods:
- `tier_max(tier)` (`:149-162`) — normalizes tier (`_normalise_tier_key` accepts `"tier_1"`/`1`/`"1"`, `:189-204`);
  **unknown/absent tier or a mapped-to-bogus value → `default_level`** (fail-closed).
- `is_denylisted(paths)` (`:164-172`) — True iff ANY path matches ANY denylist glob (via `path_matches_any`). **A
  denylist match beats the tier.**
- `is_allowlisted(paths)` (`:174-186`) — True iff EVERY path is covered; **empty allowlist → False for any non-empty
  paths** (nothing auto-merges — conservative default); empty `paths` → True.
- `path_matches_any(path, globs)` (`:207-224`) — fnmatch, plus a `**`→`*` collapsed retry so `**/secrets/**` matches
  `a/b/secrets/c.txt` (fnmatch has no `**` operator but `*` already spans `/`). Strips a leading `./`.

### 7.3 `resolve_autonomy_level(...)` — the single pure entry point (`autonomy.py:264-330`)
Applies, **in this order**:
1. **Denylist beats tier (REQ-AG-003)** — checked FIRST: if `paths and policy.is_denylisted(paths)` → return
   `AutonomyDecision(permitted_level=report_only, escalate=True, reason="denylist_match", denylisted=True)`. So a
   denylisted path can never slip through even on Tier-3.
2. **Attempt cap (REQ-AG-004)** — `cap = policy.attempt_cap if >0 else DEFAULT_ATTEMPT_CAP`; if `attempts >= cap` →
   `permitted_level=report_only, escalate=True, reason="attempt_cap_exceeded", attempt_capped=True`.
3. **Per-tier cap (REQ-AG-002)** — else `permitted = cap_level(requested_level, policy.tier_max(risk_tier))`;
   `capped = rank(permitted) < rank(requested)`; `reason = "capped_to_tier" if capped else "within_tier_cap"`,
   `escalate=False`.
Pure, deterministic, never raises, **never fails open** (unknown tier → report_only via `tier_max`).

`AutonomyDecision` (frozen, `:232-261`): `permitted_level`, `requested_level`, `risk_tier`, `escalate`, `reason`,
`denylisted=False`, `attempt_capped=False`, `paths=()`, `metadata`. Property `capped` = `rank(permitted) <
rank(requested)`.

### 7.4 The guardrails — attempt-cap counter & acting-on lock
- `evaluate_attempt_cap(item_id, attempts, attempt_cap=3, last_output, diagnosis)` (`:356-389`) → `AttemptCapResult`
  (`:338-353`). **`escalated = attempts > cap`** — the (cap+1)th failure flips it (with default 3, the **4th**
  consecutive failure escalates). On escalation the full diagnostic context (attempts, cap, last_output, diagnosis) is
  captured; the item is NOT retried. `should_retry = not escalated`. Pure.
- `evaluate_acting_on_lock(target, loop_id, current_holder)` (`:413-443`) → `LockOutcome` (`:397-411`). If no holder or
  holder == loop_id → **acquired** (reason "acquired" / "reentrant" — a loop re-acquiring its OWN lock is idempotent, so
  a retry isn't blocked); a DIFFERENT holder → **skipped** (reason `"acting_on lock held by <holder>"`). Pure — the
  activity owns the durable lock table; this just decides. `target` is an app/branch key like `"APP-7@feature/x"`.

### 7.5 Autonomy-as-a-gate (fail-closed, maker≠verifier routing) (`autonomy.py:451-519`)
- `autonomy_gate_predicates(decision)` (`:451-485`) → a **non-empty** `dict[str,bool]` for the `automated-only` provider:
  `not_escalated`, `no_denylist_hit`, `within_attempt_cap`, `level_permitted` (non-empty permitted level), and
  **`requested_within_tier` = `not decision.capped`**. The last is **defense-in-depth**: without it a loop that asked
  for `unattended` on a Tier-1 app gets an `approved` verdict (just at a lower level), which reads as "approved" to an
  AO and relies on callers honoring `permitted_level`; WITH it, an over-ask makes a predicate False → the gate rejects →
  routes to a human. The control is self-enforcing, not caller-dependent.
- `evaluate_autonomy_gate(decision, provider)` (`:488-519`) — builds a `GateApprovalRequest(gate_id="autonomy_level",
  context={"predicates": ..., "permitted_level", "risk_tier", "reason"})` (lazily importing `GateApprovalRequest` to
  stay Temporal-sandbox-safe) and returns `provider.poll(request)`. Against `automated-only`: non-escalating → `approved`
  (loop may proceed at `permitted_level`); escalating → `rejected` (**route to the human `github-pr` provider**). This
  is the **maker≠verifier, fail-closed** routing: the loop (maker) proposes; a rejected gate forces a human/verifier
  (`github-pr`) before any merge.

### 7.6 Autonomy-readiness scoring (the weight-0 diagnostic dimension) (`autonomy.py:522-569`)
- `READINESS_LADDER = ("L0","L1","L2","L3")`; `READINESS_CRITERIA = ("has_machine_checkable_spec",
  "has_independent_verifier", "has_rollback_and_allowlist")` (`:530-538`).
- `autonomy_readiness_level(criteria)` (`:541-556`) — counts the **leading run** of satisfied criteria in order (a loop
  with a spec but no verifier is L1; +verifier = L2; +rollback/allowlist = L3; missing the first = L0). Unknown/missing
  criterion counts as unmet (never inflates).
- `autonomy_readiness_score(criteria)` (`:559-569`) — normalizes the rung onto `[0,1]`: L0→0.0, L1→1/3, L2→2/3, L3→1.0
  (`round(rung/3, 6)`). This is the `scoring_function` named by the weight-0.0 `autonomy-readiness` dimension (§2.4) —
  diagnostic only, never perturbs the composite.

### 7.7 Decision-log record + policy construction (`autonomy.py:577-729`)
- `AutonomyDecisionLogRecord` (frozen, `:577-621`) + `build_decision_log_record(...)` (`:624-653`) — the structured log
  entry written on the **default (flag-OFF) Task-8-independent path**; `to_dict()` produces `{"kind":
  "autonomy_decision", ...}`. Pure — the timestamp is captured by the *activity* and passed in as `recorded_at`.
- `policy_from_mapping(data)` (`:661-705`) — builds an `AutonomyPolicy` from a parsed `autonomy.yaml` mapping (accepts
  the full doc `{"autonomy": {...}}` or the inner block). Missing keys → conservative defaults; an off-ladder
  `default_level` falls back to `report_only`; a non-int `attempt_cap` → 3. Empty/None → the fully fail-closed default
  policy.
- `merge_policy_over_defaults(profile, defaults)` (`:708-729`) — layers a profile policy over the framework defaults
  (REQ-AG-008): a profile that omits a field inherits the conservative default (no `denylist` → the broad default
  denylist; no `auto_merge_allowlist` → empty → nothing auto-merges). Non-empty profile values win; `deny_by_default`
  always taken from the profile.

### 7.8 `activities/autonomy_eval.py` — the Temporal activity wrapper (`autonomy_eval.py:1-33`)
REQ-TEMP-001: the decision/lock/timestamp logic runs inside an ACTIVITY, never workflow code — **the timestamp is
captured HERE** (`datetime.now(timezone.utc)`, `:225`) so workflow code stays deterministic.
- `load_autonomy_policy(profile_id)` (`:141-157`) — layers `profiles/<p>/autonomy.yaml` over
  `registries/defaults/autonomy.yaml` (a missing profile file → defaults verbatim, never fails open). `_default_policy`
  reads the defaults file, falling back to the in-code fully-fail-closed `AutonomyPolicy()` if the file is
  missing/unparseable (`:128-138`) — **a missing file can never fail the gate open**. Profile root resolution mirrors
  `profile_devsecops` (`OLYMPUS_PROFILES_DIR`/repo `profiles/<id>`/`OLYMPUS_PROFILE_ROOT`, `:92-114`).
- **`evaluate_autonomy(payload)`** (`:213-262`) — the main activity (`@foundry_activity`): captures timestamp, loads
  policy (or uses `payload.policy_override`), calls `resolve_autonomy_level(...)`, builds the decision-log record. Then
  the **Task-8-independence seam** (REQ-AG-006): default (`AUTONOMY_EVIDENCE_EMIT` off) writes the structured
  decision-log to durable state importing **NOTHING** from the evidence layer; when the flag is on
  (`evidence_emit_enabled`, truthy ∈ {1,true,yes,on}, `:60-72`) it **lazily imports** the P8.1 evidence backbone inside
  `_emit_evidence_for_decision` (`:265-322`) and emits an `evidence_record` mapped to continuous-monitoring control(s)
  (default `CA-7`), status `non-compliant` iff escalated. A missing portfolio scope or an un-importable backbone → clean
  skip `(False, None, True)`, never fails the gate.
- `record_attempt(payload)` (`:336-359`) and `acquire_acting_on_lock(payload)` (`:371-390`) — thin activity wrappers
  over the pure `evaluate_attempt_cap` / `evaluate_acting_on_lock`; each returns a plain serialisable dict; the activity
  owns the durable attempt-count / lock tables.
- I/O dataclasses (`EvaluateAutonomyInput`/`Result`, `AttemptCapInput`, `AcquireLockInput`, `:165-211,325-369`) are
  plain + serialisable and are NOT added to the frozen `olympus_contracts` dataclasses.

### 7.9 `autonomy-policy.schema.json` (`schemas/cross-cutting/autonomy-policy.schema.json`)
Validates `profiles/<id>/autonomy.yaml`. `additionalProperties: false`, `required: ["autonomy"]`. `autonomy` requires
`profile, tier_caps, denylist, auto_merge_allowlist`; `attempt_cap` int 1..100; `tier_caps` keys constrained to
`^tier_[123]$` → `AutonomyLevel`; `TierId` enum `{tier_1,tier_2,tier_3}`; `AutonomyLevel` enum
`{report_only,assisted,unattended}`; `Glob` string 1..300. Optional `triage` block (error-triage sweep config): `sources`
enum `{ai_work_log,agent_run,event_outbox,prometheus_alert}`, `propose_fix_enabled` (default false, fail-closed),
`fix_level` (AutonomyLevel), `metrics_endpoint`, `control_ids`.

---

## 8. Continuation

The **profile system** — all 4 profiles reproduced fully with every override key and its effect, the load/overlay
mechanics, the CAN-vs-CANNOT-override matrix, and the client-agnostic (cATO/OSCAL) blocker — is in **`07b-profiles.md`**.
