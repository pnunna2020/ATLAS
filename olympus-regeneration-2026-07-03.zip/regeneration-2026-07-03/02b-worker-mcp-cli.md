# 02b — Worker, MCP Server, CLI

ATOMIC regeneration spec. Behavioral parity target. Citations are
`<pkg>/<path>:LINE`; bare `:NN` after a file is named at the top of a section.
Covers `olympus-worker/`, `mcp-server/`, `olympus-cli/`. The worker's Temporal
workflows/activities live in `temporal/olympus_workflows/` (documented
elsewhere); this doc covers the worker's dispatch/bootstrap glue.

---

## 1. Worker (`olympus-worker/src/`)

### 1.1 Bootstrap entrypoint (`worker.py`)

`python -m src.worker` → `asyncio.run(run_worker())` (:145-146).

`run_worker()` (:92-142):
1. `config = WorkerConfig()`; `_configure_logging(config.log_level)` (:94-95).
2. `config.validate_agent_runtime_mode()` (:100) — the DECISION-018 safety rail
   (see §1.3). Log resolved mode + app_env (:101-105).
3. `_load_agent_config()` (:108) — `olympus_agent_registry.load_from_config(
   os.environ.get("AGENT_CONFIG_PATH","config/agents.yaml"))` (:57-60).
4. `signal.signal(signal.SIGHUP, _handle_sighup)` (:111) — SIGHUP reloads the
   agent registry (`olympus_agent_registry.reload()`) (:63-66).
5. `foundry_config = BaseWorkerConfig.from_env()`; override `temporal_host`,
   `namespace`, `task_queue`, `max_concurrent_activities`,
   `max_concurrent_workflow_tasks`, and
   `worker_identity = _resolve_worker_identity(config.task_queue)` (:114-124).
6. `client = await create_temporal_client(foundry_config)`; `worker =
   create_worker_with_defaults(client, workflows=ALL_WORKFLOWS,
   activities=ALL_ACTIVITIES, config=foundry_config)` (:126-132).
7. `await worker.run()` (:142). `ALL_WORKFLOWS`/`ALL_ACTIVITIES` imported from
   `olympus_workflows.worker` (:27).

`_resolve_worker_identity(task_queue)` (:35-54): `WORKER_IDENTITY` env override;
else `f"olympus-worker-{task_queue}-{socket.gethostname() or 'local'}-{os.getpid()}"`.
GOTCHA: unique-per-replica identity is REQUIRED so `docker compose --scale
olympus-temporal-worker=N` replicas polling the shared `olympus-main` queue show
as distinct workers (P5-S15/W14).

`_configure_logging(log_level)` (:69-89): structlog with stdlib integration
(`merge_contextvars`, `filter_by_level`, `add_logger_name`, `add_log_level`,
`PositionalArgumentsFormatter`, ISO `TimeStamper`, `StackInfoRenderer`,
`format_exc_info`, `UnicodeDecoder`, `ConsoleRenderer`); `BoundLogger`;
`cache_logger_on_first_use=True`; `logging.basicConfig(level=...)`.

### 1.2 Worker config (`config.py`)

`WorkerConfig(BaseSettings)` (:36): `temporal_host="localhost:7233"`,
`temporal_namespace="default"`, `task_queue="olympus-main"`,
`max_concurrent_activities=100`, `max_concurrent_workflow_tasks=50`, DB component
vars (`database_host/port/name/user/password`), `log_level="INFO"`,
`agent_runtime_mode="live"` (:62), `app_env="development"` (:64), `env_file=".env"`.

`get_database_url()` (:88-104): requires host/name/user/password non-blank (else
`ValueError`); URL-encodes password (`quote_plus`);
`postgresql://user:pw@host:port/name`. `get_async_database_url()` (:106) replaces
scheme with `postgresql+asyncpg://`.

### 1.3 `validate_agent_runtime_mode` — DECISION-018 rail (:68-86)

`AGENT_RUNTIME_MODE_LIVE="live"`, `AGENT_RUNTIME_MODE_MOCK="mock"` (:14-15);
`_VALID_AGENT_RUNTIME_MODES = {live, mock}` (:16); `_NON_TEST_ENVS =
{production, prod, staging, stage}` (:21). Logic:
- `mode = (agent_runtime_mode or "").strip().lower()`; if not in valid set →
  `raise InvalidAgentRuntimeModeError` (:75-79).
- `env = (app_env or "").strip().lower()`; if `mode == "mock" and env in
  _NON_TEST_ENVS` → `raise MockInProductionError` (:81-86). LOUD, FATAL — the
  caller must NOT catch. Mock runtime is for automated tests only.

### 1.4 Model resolver (`model_resolver.py`)

`DEFAULT_PROVIDER = MODEL_DEFAULT_PROVIDER env or "claude"` (:26).
`DEFAULT_TIER = MODEL_DEFAULT_TIER env or "tier-2"` (:48). `DEFAULT_TIER_MAP`
(:29-45) keyed by tier→provider→model (env-overridable): tier-1
claude-opus-4/gpt-4o/gemini-2.5-pro; tier-2 claude-sonnet-5/gpt-4o-mini/
gemini-2.5-flash; tier-3 claude-haiku-3.5/gpt-4o-mini/gemini-2.0-flash-lite.

`ModelConfig` (:51): `task_type`, `default_model`, `default_model_tier=""`,
`recommended_alternatives=[]`. `ModelOverride` (:61): `application_id`,
`task_type`, `model`, `rationale`.

`ModelResolver(tier_map=None, default_tier=DEFAULT_TIER,
default_provider=DEFAULT_PROVIDER)` (:85-97): in-memory `_task_configs` +
`_app_overrides` (app_id→task_type→override).
- `resolve_tier(tier, provider=None)` (:99-105): map tier→provider→model; unknown
  tier → default_tier's entry; unknown provider → default_provider's entry →
  hardcoded `"claude-sonnet-5"`.
- `resolve_for_provider(tier, provider)` (:107) → `resolve_tier`.
- `load_task_configs` / `load_app_overrides` populate the caches.
- `resolve(task_type, app_id="", model_preference="", provider=None)` (:133-197):
  precedence — (1) explicit `model_preference`: if it's a tier name in
  `_tier_map` → `resolve_tier`, else treat as a direct model name; (2)
  `_app_overrides[app_id][task_type].model`; (3) `_task_configs[task_type].default_model`;
  (4) `resolve_tier(default_tier, provider)`.

NOTE: this resolver is worker-side. In the deployed A2A path the worker sends a
tier/alias `model_preference` and the AGENT RUNTIME's `ModelSelector` chooses the
concrete model (see `agent_client.dispatch_via_a2a`); the actual concrete-model
decision is delegated to the runtime.

### 1.5 A2A dispatch client (`agent_client.py`)

`AGENT_RETRY_POLICY = RetryPolicy(initial=5s, backoff=2.0, max_interval=60s,
maximum_attempts=3)` (:35-40). 503 retry knobs: `_RETRY_ON_503_MAX_ATTEMPTS=5`,
`_RETRY_ON_503_BASE_DELAY_S=1.0`, `_RETRY_ON_503_BACKOFF=2.0`,
`_RETRY_ON_503_MAX_DELAY_S=30.0` (:48-51).

`_keepalive_transport()` (:53-69): builds an `httpx.AsyncHTTPTransport` with TCP
keepalive socket options (`olympus_contracts.net.keepalive_socket_options`), or
`None` (falls back to httpx default; disabled via `A2A_TCP_KEEPALIVE=false`).
GOTCHA: keepalive keeps a byte-silent long-lived dispatch alive across the NLB's
~350s idle timeout, else the NLB severs the connection mid-skill.

`_build_task_message(task_input)` (:72-88): `f"Execute skill '{skill_id}' for
application '{app_id}'. Task type: {task_type}."` + if `context`: `" Context:
<k=v, sorted, joined by ', '>."`. GOTCHA: this `k=v` stringify is exactly why
structured `extras` needed the `_dispatch-context.json` file on the runtime side
— a list-of-dicts flattens into an unreadable blob.

`_build_context(task_input)` (:91-116): `{app_id, skill_id, task_type,
input_artifacts, optional_input_artifacts, model_preference}` + optional
`source_repo/artifact_repo/artifact_ref/workspace_key`; caller `context` goes
under an `extras` key.

`dispatch_via_a2a(agent_url, task_input, model_used="") -> AgentTaskResult`
(:292-360): `task_id = uuid4()`; build message + context; payload = `{"task":
task_message, "context": context, "model_preference": task_input.model_preference
or ""}`. GOTCHA (:331-338): leave `model_preference` BLANK when the caller has no
explicit preference so the runtime reads the skill's DECLARED tier; sending
`"tier-2"` here would clobber that and demote every Opus-declared skill to
Sonnet. `response = await _post_with_saturation_retry(...)`; `result =
_extract_result(response, task_id, "", start_ms)` (model_used comes from the
response, not the caller).

`_post_with_saturation_retry(agent_url, payload, timeout, task_id)` (:206-289):
loop up to 5 attempts. Each iteration opens a fresh `httpx.AsyncClient(timeout,
transport=_keepalive_transport())`, injects W3C trace headers
(`inject_trace_headers()`, no-op when OTel off), POSTs `f"{agent_url}/a2a/tasks"`.
If status != 503 → `raise_for_status()` + return `resp.json()`. On 503: if last
attempt break; else honor `Retry-After` header (float) else exponential backoff
`min(BASE * BACKOFF^(attempt-1), MAX)`; `delay = max(retry_after, backoff) +
random.uniform(0, 0.5)` (jitter so N workers don't retry in lockstep); `await
asyncio.sleep(delay)`. After the loop: `last_resp.raise_for_status()` (a 503
raises `HTTPStatusError`). GOTCHA: an HAProxy LB with `option redispatch` sits in
front, so a 503 reaching us means EVERY replica is saturated.

`_extract_result(response, task_id, model_used, start_ms)` (:119-203): maps an
A2A response dict → `AgentTaskResult`. Defaults `status=COMPLETED`. Extracts
`output_artifacts` (list of str), `output_files` (dicts with path+content →
`OutputFile`), `token_usage.input/output`, `cost_estimate_usd`, `model_used` (if
non-empty str). GOTCHA (:181-190): `status_val in ("failed","timeout","timed_out")`
maps to `TIMED_OUT` for timeout/timed_out else `FAILED` — a timeout MUST surface
as non-COMPLETED so `dispatch_agent_task` raises `RetryableError`; before this a
`timeout` fell through to COMPLETED with no output_files → downstream
`EmptyPortfolioRedundancyPlan`-type guards failed the whole wave on a transient
timeout. Keep in lockstep with `olympus-api/src/services/agent_client.py`.

### 1.6 Subprocess fallback adapter (`fallback_adapter.py`) — DEPRECATED

Emits a `DeprecationWarning` at import (:28-32). `_FALLBACK_ENABLED =
os.environ.get("ENABLE_SUBPROCESS_FALLBACK","0") == "1"` (:34).
`DEFAULT_SUBPROCESS_TIMEOUT=1800` (:37).

`dispatch_via_subprocess(module_name, task_input, model_used="",
python_executable="python", timeout_seconds=None) -> AgentTaskResult` (:40-192):
- `task_id = uuid4()`. If `not _FALLBACK_ENABLED` → RETURN `AgentTaskResult(status=FAILED, error="Subprocess fallback is disabled...")` (:72-82).
- `effective_timeout = timeout_seconds or task_input.timeout_seconds or 1800`.
- Build input JSON `{task_type, app_id, skill_id, input_artifacts, model_preference}`; `cmd = [python, "-m", module_name, "--task-input", input_json]` (:87-95).
- `create_subprocess_exec` + `wait_for(process.communicate(), timeout=effective_timeout)` (:107-116).
- Non-zero returncode → FAILED with `f"Subprocess exited with code {rc}: {stderr[:500]}"`.
- Parse stdout as JSON (`json.loads`); on `JSONDecodeError` → FAILED "Invalid JSON output". Extract `output_artifacts` (list→[str]), `token_usage_input/output`, `cost_estimate_usd`, `model_used`. RETURN COMPLETED.
- `TimeoutError` → `TIMED_OUT` "Subprocess timed out after Ns". Other exceptions → FAILED with `str(e)`.
The agent MUST print a single JSON object `{"status":"completed","output_artifacts":[...]}` to stdout.

### 1.7 Mock agent runtime (`testing/mock_agent_runtime.py`) — DECISION-018

Fixture-backed canned responses for deterministic workflow tests. Gated by
`AGENT_RUNTIME_MODE={live|mock}`; wired into dispatch only when the config gate
allows it. Fixtures live at `cross-cutting/skills/<skill_id>/fixtures/<scenario>.json`.

Exceptions: `FixtureError` base; `FixtureNotFoundError`, `FixtureResolutionError`,
`FixtureSchemaError` (:78-91).

`_skills_root()` (:116-120): `OLYMPUS_SKILLS_ROOT` env override; else
`_default_skills_root()` walks up from this file for `cross-cutting/skills` (then
`Path.cwd()/cross-cutting/skills`). `_fixtures_dir(skill_id)` (:123) =
`<root>/<skill_id>/fixtures`.

Fixture shape (docstring :22-40): top-level `{skill_id, scenario, description,
result}`; `result` = `{status, output_artifacts, output_files:[{path,content,
encoding}], model_used, token_usage:{input,output}, cost_estimate_usd,
duration_ms, error}`.

`_validate_shape(path, payload)` (:137-184): require top-level `skill_id`,
`scenario`, `result`; `result` must be dict; `status ∈ {completed,failed}`;
`failed` requires non-empty `error`; `output_artifacts` (if present) a list;
`output_files` (if present) a list of dicts each with `path`+`content`. Raises
`FixtureSchemaError` on any violation.

`_materialize(payload)` (:187-218): builds `AgentTaskResult(task_id=f"mock-
{uuid4().hex[:8]}", status=COMPLETED|FAILED, output_artifacts, output_files=[
OutputFile(path, content, encoding)], model_used=r.get("model_used","mock-model"),
duration_ms, token_usage_input/output, cost_estimate_usd, error)`.

`load_fixture(skill_id, scenario=None)` (:221-276): no dir →
`FixtureNotFoundError`; no `*.json` → `FixtureNotFoundError`. If `scenario is
None`: exactly one file else `FixtureResolutionError` (be explicit). If scenario:
`<scenario>.json` must exist. `_validate_shape`; if fixture's `skill_id` mismatches
requested → `FixtureSchemaError`. Returns `LoadedFixture`.

`validate_all_fixtures(skills_root=None)` (:291-303): loads + validates every
fixture (via `iter_all_fixtures`) — called from a conftest at collection time so
any schema drift aborts the test run.

`dispatch_via_mock(agent_url, task_input, model_used="") -> AgentTaskResult`
(:311-357): DROP-IN for `dispatch_via_a2a` (same signature). `scenario =
task_input.context.get("fixture_scenario")` (str-coerced) if context set.
`load_fixture(skill_id, scenario)`. If the fixture's `result.duration_ms == 0`,
rebuild the result with `duration_ms = max(elapsed_ms, 1)`. GOTCHA: `agent_url` +
`model_used` are accepted but UNUSED (parity only).

### 1.8 Rendition engine (`renditions/engine.py`)

`TEMPLATES_DIR = Path(__file__).parent/"templates"` (:9). `RenditionEngine`
(:12): Jinja2 `Environment(loader=FileSystemLoader(templates_dir),
autoescape=False, trim_blocks=True, lstrip_blocks=True,
keep_trailing_newline=True)` (:22-28). `list_templates()` → `.j2` templates
sorted (:30-32). `render_markdown(template_name, data)` → `env.get_template(name).
render(data=data)` (raises `TemplateNotFound` if absent) (:34-48). Renders
markdown docs from factory step outputs; each template receives a `data` dict.

### 1.9 Agent registry (`agent_registry.py`)

`_ENV_VAR_PATTERN = re.compile(r"\$\{([^}:]+)(?::-((?:[^}]|\\\})*)?)?\}")` (:25);
`_expand_env_vars` (:28-41) expands `${VAR}` / `${VAR:-default}`.

`OlympusAgentCard` (dataclass) (:44): `name`, `description`, `url`, `skill_ids=[]`,
`capabilities=[]`, `supported_models=[]`, `preferred_model_tier="tier-2"`,
`assembly_lines=[]`, `version="0.1.0"`, `metadata={}`.

`OlympusAgentRegistry` (:64): maintains `_cards`, `_skill_index`
(skill_id→[name]), `_url_index` (name→url), `_capability_index`
(capability→[name]), `_config_path`. `register(card)` (:79) indexes.
`load_from_config(config_path)` (:100-162): parse YAML; require `agents` list;
expand env vars in each `url`; build a card per entry; `register`.
`reload()` (:164-178): `_clear()` + reload from `_config_path` (SIGHUP path).
`find_agent_for_skill(skill_id)` (:187-210): explicit `_skill_index[skill_id][0]`;
else a catch-all card (empty `skill_ids`); else `None` (Olympus agents are
generic skill dispatchers, P5-S26 Q15). `get_agent_url`, `get_card`,
`list_agents`, `find_agents_with_capability`. Module singleton
`olympus_agent_registry` (:230).

---

## 2. MCP Server (`mcp-server/olympus_mcp/`)

A JSON-RPC 2.0 over HTTP-POST server exposing Olympus resources + tools. Some
resources/tools have LIVE handlers (DB queries or token-forwarded olympus-api
proxies); others return schema-only stubs.

### 2.1 Server & dispatch (`server.py`)

`_jsonrpc_response(id, result)` / `_jsonrpc_error(id, code, message, data=None)`
(:38-48).

`handle_method(method, params) -> Any` (:55-144):
- `"resources/list"` → `list_resources()` (:59-60).
- `"tools/list"` → `list_tools()` (:62-63).
- `"resources/read"` (:65-88): `uri = params["uri"]`; `resource_name =
  uri.split("://")[0]`; `schema = get_resource_schema(resource_name)` (None →
  `MethodError(-32602)`); `uri_param = uri.split("://",1)[1]`; `handler_result =
  _dispatch_resource_handler(resource_name, uri_param)`. If non-None → `{"uri",
  "data", "schema"}`; else `{"uri", "schema", "note": "Stub — ..."}`.
- `"tools/call"` (:90-116): `tool_name = params["name"]`; `arguments =
  params["arguments"] or {}`; `tool_schema = get_tool_schema(tool_name)` (None →
  error); `handler_result = _dispatch_tool_handler(tool_name, arguments)`.
  Non-None → `{"tool","data","schema"}`; else `{"tool","note":"Deferred —
  schema-only stub...","schema"}`.
- `"schema/get"` (:118-129): `name`, `kind ∈ {resource,tool}`; returns the schema
  (unknown kind or unknown name → error).
- `"initialize"` (:131-142): returns `{protocolVersion:"2024-11-05", serverInfo:
  {name:"olympus-mcp",version:"0.1.0"}, capabilities:{resources:{listChanged:
  False},tools:{listChanged:False}}}`.
- else → `MethodError(-32601, "Method not found: <method>")`.

`_dispatch_resource_handler(resource_name, uri_param)` (:147-199): a static map
(:171-180) `{catalog: read_catalog, analysis: read_analysis, disposition:
read_disposition, task: read_task, system: read_system, capability:
read_capability, artifact: read_artifact, "gate-evidence": read_gate_evidence}`.
No handler → `None` (→ schema stub). Handlers are ASYNC: run synchronously via
`loop = asyncio.new_event_loop(); loop.run_until_complete(handler(uri_param))`
(the HTTP handler is sync). Any exception → log warning + `None`.

`_dispatch_tool_handler(tool_name, arguments)` (:202-257): merges handler maps
`API_HANDLERS | ARTIFACT_HANDLERS | TASK_HANDLERS | BUNDLE_HANDLERS |
PROVENANCE_HANDLERS | LINES_HANDLERS | CONTROL_PLANE_HANDLERS`. No handler →
`None` (→ "Deferred" stub). Async, run via a fresh event loop; result coerced to
dict (non-dict → `{"result": result}`); exception → `{"error":
"handler_exception: <exc>"}`.

`MCPRequestHandler(BaseHTTPRequestHandler)` (:272): `do_POST` (:275-297) reads
Content-Length body, `json.loads` (parse error → JSON-RPC -32700, HTTP 400),
extracts `id/method/params`, calls `handle_method`, sends `_jsonrpc_response`;
`MethodError` → `_jsonrpc_error(id, code, msg, data)`. `do_GET` (:299-308) →
health JSON `{server, version, resources: len(RESOURCE_REGISTRY), tools:
len(TOOL_REGISTRY), status:"ok"}`. `_send_json` writes `json.dumps(..., indent=2,
default=str)` with Content-Type/Length.

`main(argv=None)` (:328-388): argparse `--host 127.0.0.1`, `--port 3001`,
`--verbose`, `--dump-schemas`. `--dump-schemas` prints every resource
`json_schema()` + every tool `{input, output}` schema and exits. Else
`HTTPServer((host,port), MCPRequestHandler)`, `serve_forever` (Ctrl+C →
`shutdown`).

### 2.2 DB connection (`db.py`)

`get_connection() -> asyncpg.Connection` (:17-57): reads `DATABASE_HOST`
(default localhost), `DATABASE_PORT` (5432), `DATABASE_USER` (olympus),
`DATABASE_PASSWORD` (olympus), `DATABASE_NAME` (olympus); requires host/user/
password/name non-blank (else `ValueError`); `asyncpg.connect(...)`. Handlers
open + close a single connection per read.

### 2.3 Resource registry (`resources/registry.py`)

`ResourceDefinition` (frozen) (:35): `uri_pattern`, `name`, `description`,
`schema_model: type[BaseModel]`, `available_from`, `uri_params=[]`;
`json_schema()` = `schema_model.model_json_schema()`.

`RESOURCE_REGISTRY` (:54-203) — 16 resources: `portfolio` (`portfolio://{id}`),
`catalog` (`catalog://{app_id}`), `analysis`, `redundancy` (`redundancy://{run_id}`),
`disposition`, `specs`, `design`, `code` (`code://{app_id}/{context}`),
`user_context`, `ux_assessment`, `user_impact` (the original 11); plus Phase 5
PR #5 human-paired families: `task` (`task://{task_id}`), `system`
(`system://{system_id}`), `capability` (`capability://{capability_id}`),
`artifact` (`artifact://{path}`), `gate-evidence` (`gate-evidence://{gate_id}`).

`list_resources()` (:206-217): list of `{uri, name, description, available_from,
uri_params}`. `get_resource_schema(name)` (:220-226): the JSON Schema or `None`.

### 2.4 Resource handlers (over the query DB / olympus-api)

- `catalog_handler.read_catalog(app_id)` (:16-67): `SELECT id, name, repo_url,
  business_domain, owner, current_line, current_step, current_status, risk_tier,
  complexity_tier, disposition, created_at, updated_at FROM application WHERE id
  = $1::uuid`. `None` row → `{error:"not_found", message:...}`. Maps row →
  CatalogResource-shaped dict (`app_id, name, description=business_domain,
  repository_url=repo_url, disposition, risk_tier, complexity_tier, current_line,
  status=current_status, scores=None, tags={}, created_at, updated_at`).
- `analysis_handler.read_analysis(app_id)` (:18-...): `SELECT g.evidence_data,
  g.gate_type, g.status, g.decided_at FROM gate g ...` (reads gate evidence).
- `disposition_handler.read_disposition(app_id)` (:16-...): `SELECT id, name,
  disposition FROM application WHERE id = $1::uuid`.
- `task_handler.read_task(uri_param)` (:19-53): NOT a DB query — calls
  `api_get(f"/api/v1/agent-tasks/{uri_param}/audit-narrative")`; `error` → `None`;
  maps narrative → TaskResource-shaped dict.
- `system_handler.read_system(uri_param)` (:13-30): `api_get(
  f"/api/v1/systems/{uri_param}")` → SystemResource dict.
  `read_capability(uri_param)` (:33-60): `api_get(f"/api/v1/capabilities/{id}")` +
  `api_get(".../lineage")` for `source/target_capability_count`.
- `artifact_handler.read_artifact(uri_param)` (:20-...): `api_get(
  "/api/v1/artifacts/by-path", params={"path": uri_param})`. `read_gate_evidence`
  (:42-...) similar. GOTCHA: `task/system/capability/artifact/gate-evidence` are
  token-forwarded olympus-api proxies (via `tools/http.py`), NOT direct DB reads;
  only `catalog/analysis/disposition` hit PostgreSQL directly.

### 2.5 Tool registry (`tools/registry.py`)

`ToolDefinition` (frozen) (:73): `name`, `description`, `input_model`,
`output_model`, `used_by=[]`; `input_schema()`/`output_schema()` =
`model_json_schema()`.

`TOOL_REGISTRY` (:93-463) — tools:
- Original 7 (spec-first, schema-only stubs, no live executor): `git.read`,
  `git.write`, `git.pr`, `schema.validate`, `test.run`, `scan.security`,
  `scan.accessibility`.
- `olympus.api.*` (read-only proxies to olympus-api REST): `list_applications`,
  `get_application`, `get_application_lineage`, `get_application_rationale`,
  `list_waves`, `get_wave`, `list_gates`, `get_gate`.
- `olympus.artifact.*`: `read`, `list_for_app`, `list_for_gate`.
- `olympus.provenance.get_run` (P10-W1).
- `olympus.lines.resolve_inputs` / `olympus.lines.start` (P10-W9; resolve is
  read/propose-only and never dispatches; start is a mutation).
- `olympus.task.*` (PR #5): `list_mine`, `return`, `feedback`, `transcript`.
- `olympus.bundle.*` (P5 W20): `list`, `get`, `claim`, `release`, `validate`,
  `submit`, `audit`.
- Control-plane mutating (P10-W10): `olympus.onboard`, `olympus.start_line`,
  `olympus.gate_stage` (STAGES + EXPLAINS, NEVER decides — REQ-NS-004),
  `olympus.skill_dispatch`.

`list_tools()` (:466-476): `{name, description, used_by, inputSchema}`.
`get_tool_schema(name)` (:479-491): `{name, description, inputSchema,
outputSchema}` or `None`.

### 2.6 Token forwarding + HTTP proxy (`tools/http.py`, `tools/auth.py`)

`http.py`: `_base_url()` = `OLYMPUS_API_URL` env or `http://localhost:8000`.
`_headers()` adds `Authorization: Bearer <get_request_token()>` if a token is set.
`api_get(path, params=None)` / `api_post(path, *, json=None)`: httpx async client
(30s GET / 60s POST); transport/timeout errors → `{"error":"transport: <exc>"}`;
`status >= 400` → `{"error": f"status=<code>: <detail>"}` (`_safe_detail` prefers
olympus-api's `{"error":{"message":...}}` then FastAPI `{"detail":...}` then
truncated body); empty POST body → `{}`; decode error → `{"error":"decode:..."}`.
GOTCHA: MCP tool contract is "always return a dict; the dict MAY contain an
error" — proxies never raise.

`auth.py`: `TOKEN_PARAM_KEYS = ("_token","token")` (:37); `SERVICE_TOKEN_ENV =
"OLYMPUS_SERVICE_TOKEN"` (:40). `_PUBLIC_TOOLS` (:45-76): read-only tools that
work anonymously (all `olympus.api.*`, `olympus.artifact.*`,
`olympus.provenance.get_run`, `olympus.lines.resolve_inputs`, and the 7 spec-first
tools). `_TOKEN_VAR` is a request-scoped `contextvars.ContextVar`.
`extract_token(arguments)` (:88-111): `_token` → `token` → `auth.token` → env
`OLYMPUS_SERVICE_TOKEN`. `require_external_token(arguments)` (:114-125): returns
an `{"error":"auth_required:..."}` dict if no token, else `None`.
`set_token_for_request(arguments)` (:128) stashes the resolved token in the
context var so `http.py` finds it. GOTCHA: mutating/write tools (`olympus.task.*`,
`olympus.bundle.*`, control-plane) REQUIRE a token (default rule); the token is
forwarded so olympus-api applies the SAME RBAC as the dashboard — an RBAC-denied
caller gets the endpoint's 401/403 as a tool error.

### 2.7 Tool handler pattern (`tools/handlers/task_handlers.py` — representative)

Each family exports a `<FAMILY>_HANDLERS: dict[name → async fn]`. Handler
pattern (task_handlers :42-...):
1. `auth_error = require_external_token(arguments)`; if not None → return it.
2. `set_token_for_request(arguments)`.
3. `parsed = _parse(<InputModel>, arguments)` (:35-39) — `model_validate`; on
   `ValidationError` → `{"error": f"invalid_arguments: <errors>"}`.
4. Call `api_get/api_post` to the underlying olympus-api endpoint. e.g.
   `return_task` → `POST /api/v1/agent-tasks/{task_id}/return` with `{status,
   result_artifact_refs, implementation_notes_ref, gate_evidence_refs,
   local_agent_session, feedback_text}`; `feedback` → same endpoint with
   `{status:"needs_help", feedback_text}`; `transcript` → same endpoint with a
   `local_agent_session` block; `list_mine` → `GET /api/v1/me/tasks`.
5. `_coerce_return_response(task_id, body)` (:146-165): `error` in body →
   `{task_id, status:"error", session_artifact_ids:[], validation_errors:[],
   error}`; else `{task_id, status, actor_kind, session_artifact_ids,
   validation_errors, error:None}`.
`TASK_HANDLERS = {"olympus.task.list_mine": list_mine, "olympus.task.return":
return_task, "olympus.task.feedback": feedback, "olympus.task.transcript":
transcript}` (:168-173). The other handler modules (`api_handlers`,
`artifact_handlers`, `bundle_handlers`, `provenance_handlers`, `lines_handlers`,
`control_plane_handlers`) follow the same auth→parse→proxy→coerce shape.

---

## 3. CLI (`olympus-cli/olympus_cli/`)

Built on `click`. Every command delegates to a testable function.
`python -m olympus_cli` → `main()` → `cli(standalone_mode=True)` (`main.py`:458-461).

### 3.1 Top-level group `cli` (`main.py`:48)

Options `--api-url` (env `OLYMPUS_API_URL`, default `http://localhost:8000`),
`--token` (env `OLYMPUS_TOKEN`, falls back to `~/.olympus/config.json`),
`--output {table|json}` (env `OLYMPUS_OUTPUT`, default `table`). `cli` (:66-68)
sets `ctx.obj = load_context(api_url, token, output)`.

Registered subgroups/commands (:76-121): `bundle` (§3.7), `lite` (§3.8),
`profile` (§3.9), `composition`, `lines`, control-plane top-level verbs
(`onboard`/`start`/`gate`/`dispatch`, §3.6), `delegation`.

### 3.2 `task` subgroup (`main.py`:129)

- `task list` (:134-152): `--include-claimable/--owned-only` (default include),
  `--limit 50`. `GET /api/v1/me/tasks?include_claimable=<t|f>&limit=<n>`; `emit`.
- `task show <task_id>` (:155-161): `GET /api/v1/agent-tasks/{id}/audit-narrative`.
- `task accept <task_id>` (:164-181): a no-op return recording
  `{status:"needs_help", feedback_text:"accepted via `olympus task accept`"}` via
  `POST /api/v1/agent-tasks/{id}/return` (writes the caller's human_user_id until
  a dedicated /accept endpoint exists).
- `task return <task_id>` (:184-252): `--payload <file>` (posts file JSON
  verbatim) OR inline flags (`--status {completed|needs_help}`,
  `--implementation-notes`, repeatable `--result`, repeatable `--evidence`,
  `--transcript-ref`) assembled by `_assemble_return_payload` (:255-274) into
  `{status (default completed), result_artifact_refs, implementation_notes_ref,
  gate_evidence_refs[, local_agent_session:{transcript_artifact_ref}]}`. `POST
  .../return`.
- `task transcript <task_id> <file>` (:277-330): `--tool claude-code`, `--model`,
  `--version`. SHA-256 the file (64KB chunks); `POST .../return` with
  `{status:"needs_help", feedback_text:..., local_agent_session:{
  transcript_artifact_ref, transcript_hash, tool, version, model}}`.
- `task feedback <task_id> <text>` (:333-341): `POST .../return` with
  `{status:"needs_help", feedback_text: text}`.

### 3.3 `artifact` subgroup (`main.py`:349)

- `artifact get <ref>` (:354-360): `GET /api/v1/artifacts/by-path?path=<ref>`.
- `artifact list` (:363-386): `--task <id>` → read the task audit-narrative and
  emit `{kind:output|session, ref}` list; `--app <id>` → `GET
  /api/v1/artifacts/{app_id}`; neither → `UsageError`.

### 3.4 `skill` subgroup (`main.py`:394)

- `skill install <skill_id>` (:399-431): `--source` (override
  cross-cutting/skills dir), `--target` (default `./.claude/skills/` or
  `~/.claude/skills/`). `install_skill(skill_id, source_dir, target_dir)`; on
  `SkillInstallError` → stderr + `sys.exit(2)`. Emits `{skill_id, installed_at}`.

### 3.5 `auth` subgroup (`main.py`:439)

- `auth login --token <token>` (:444-450): `write_token(token)` →
  `~/.olympus/config.json`; emit `{saved_to}`.

### 3.6 Control-plane top-level verbs (`control_plane.py`)

Thin token-authed clients over EXISTING W2-hardened endpoints (same bearer path
as `task`/`bundle`). `CONTROL_PLANE_COMMANDS = (onboard, start, gate, dispatch)`
(:119).
- `onboard` (:26-52): `--portfolio-id` (req), `--name` (req), `--source-type git`,
  `--repo-url`, `--description`. `POST /api/v1/applications`.
- `start <line_name>` (:55-73): `--app`, `--wave`. `POST /api/v1/lines/{line}/start`.
- `gate <gate_id>` (:76-100): `--message` (default "stage the gate decision").
  `POST /api/v1/chat` with `{message, mode:"action", action_params:{gate_decision:
  {gate_id}}}`. GOTCHA (REQ-NS-004, LOAD-BEARING): STAGES + EXPLAINS via W6's
  staging path; NEVER calls `POST /api/v1/gates/{id}/decision`. A human decides.
- `dispatch <skill_id>` (:103-113): `--app`. `POST /api/v1/skills/{id}/dispatch`.

### 3.7 `bundle` subgroup (`bundle.py`)

Delegated-bundle lifecycle (P5 W20). Commands (from `@bundle.command`):
`list` (:121), `show` (:195), `contract` (:209), `claim` (:256), `release`
(:282), `validate` (:306), `submit` (:338), `audit` (:381). Each is a token-authed
client over the `/api/v1/*bundles*` endpoints; session artifacts are SHA-256'd
client-side when the caller supplies no hash.

### 3.8 `lite` subgroup (`lite/cli.py`) — Olympus Lite (P6 W4)

Portable local skill orchestration — runs the same skill chains against the same
registry/schemas/gates WITHOUT Temporal/FastAPI/Postgres/agents, writing to
`.olympus-lite/`. Commands:
- `init [repo_path]` (:48-103): `--profile`, `--provider` (auto|dry-run|anthropic|
  claude-code|openai), `--runtime {temporalite|step-runner}`, `--force`.
  `temporalite` runtime requires the `temporal` binary — `check_runtime` fails
  clearly (never silently falls back). `ws_mod.init_workspace(...)` writes
  `.olympus-lite/` config (workspace_id, root, profile, provider, runtime,
  cli_version, registry_hash).
- `run <chain_or_skill_id>` (:111-171): `--dry-run` (fixture path, MockAgentRuntime
  semantics, no keys), `--scenario`, `--gate-policy`. `find_workspace` →
  `resolve_chain` → `runner_mod.run_chain(workspace, chain, dry_run, scenario,
  gate_policy, interactive_prompt=...)`. Emits `{chain, runtime, status, steps:[{
  skill_id, status, provider, artifacts, schemas_checked}], gates:[{gate_id,
  verdict, by}]}`. `RunAborted` → exit 1.
- `status` (:179-209): emit step statuses / gate verdicts / artifact counts.
- `show <step_or_gate_id>` (:217-238): gate decision record OR step detail; else
  fail.
- `gate <gate_id> {approve|reject}` (:246-274): `--note`. Writes a
  `fidelity.gate_decision_record(verdict=approved|rejected, verdicted_by=
  "local-user", reason)`, updates state + run-log.
- `reset` (:282-310): `--all` (also delete artifacts), `--step <id>` (reset one
  step). Clears state + gate decision records.
- `log` (:318-334): `--since`, `--skill`. Reads `.olympus-lite/run-log.jsonl`.
- `doctor` (:342-367): reports runtime availability (`temporalite`/`step-runner`),
  temporal binary path, registry resolvability,
  `dispatch_mod._builtin_default()`, and the Temporalite spike checklist.

`lite/dispatch.py`: `DEFAULT_PROVIDER="dry-run"`, `LITE_PROVIDER_ENV=
"OLYMPUS_LITE_PROVIDER"`, `LOCAL_LIVE_PROVIDERS=("anthropic","claude-code",
"openai")`. `resolve_provider(skill_dir, *, workspace_provider="",
dry_run=False)` (:89-107): `--dry-run` forces `"dry-run"`; else precedence
skill `config.json` `provider` → workspace profile (not ""/"auto") →
`OLYMPUS_LITE_PROVIDER` → `_builtin_default()`. `_builtin_default()` (:110-118):
`claude-code` if in a Claude Code session (`CLAUDE_CODE_SESSION`/`CLAUDECODE`);
else `anthropic` if `ANTHROPIC_API_KEY`; else `dry-run`.
`dispatch_fixture(skill_id, skill_dir, *, scenario=None)` (:159-190): resolves a
fixture the same way MockAgentRuntime does (`_resolve_fixture`: explicit scenario
→ file; exactly one file → it; else `DispatchError`) and returns a
`DispatchResult` (mirrors `A2ATaskResponse`). `dispatch_live(...)` (:198-250):
imports the W2 `provider_factory.get_provider` from olympus-agent-runtime
(READ-ONLY), proves the credential gate, but is a structural seam that raises
`DispatchError` in CI (DECISION-018 keeps tests on fixtures). `dispatch(...)`
(:267-287): `dry-run` → fixture; `LOCAL_LIVE_PROVIDERS` → live; else `DispatchError`.

### 3.9 Other subgroups

- `profile` (`profile.py`, P10 W7): `author` (:600), `validate` (:828), `assign`
  (:977), `resolve` (:1007) — profile-authoring-skill commands.
- `composition` (`composition.py`, P10 W5): `validate` (:27) — skill-composition
  author validation.
- `lines` (`lines.py`, P10 W9): `resolve` (:37), `start` (:56) — scoped
  standalone-line launch (token-forwarded to the common W9 API).
- `delegation` (`delegation.py`, P10 W10): `grant` (:31), `list` (:73), `revoke`
  (:81) — scoped, revocable on-behalf-of grant lifecycle.

`api.py` provides `get/post/...` helpers (bearer-authed httpx over the API base
URL); `config.py` provides `CLIContext`, `load_context`, `write_token`;
`output.py` provides `emit(ctx, body)` (table or JSON per `ctx.output`).
