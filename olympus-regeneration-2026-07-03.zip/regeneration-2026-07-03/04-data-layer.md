# 04 — Data Layer (Part 1 of 3): Migrations, Enums, Projection Model, Seeds

> **Scope.** The Olympus PostgreSQL query layer: the Alembic migration chain
> (`db/alembic/versions/`), the enum types, the Git→PG projection model, and the
> seed/init scripts. Column-by-column table catalogs are in **Part 2**
> (`04-data-layer-part2.md`) and **Part 3** (`04-data-layer-part3.md`).
>
> **Behavioral-parity contract.** To rebuild this layer, run migrations `001`→`091`
> in `down_revision` order (with the `039` merge fan-in), then apply the seed dump.
> The `metadata`/`decomposition_map`/side-effect JSONB columns are **derived** — they
> are re-projected from Git-committed artifact JSON by the `persist_*` Temporal
> activities (§5). PG can be dropped and rebuilt from Git + migrations at any time.

---

## 1. Where everything lives

| Path | Role |
|---|---|
| `db/alembic/versions/*.py` | 90 migration files, numbered `001`–`091` with **`055` skipped** (a real gap — verified below). |
| `db/alembic/env.py` | Alembic runtime. **Single transaction wraps the whole `run_migrations()`** (`env.py:115-117`), online mode uses `pool.NullPool` (`:110`), URL built by `_build_database_url()` from env vars. `target_metadata=None` — migrations are hand-authored DDL, no autogenerate. |
| `db/init/01-create-databases.sh` | Postgres container first-launch init: `CREATE DATABASE olympus; CREATE DATABASE temporal; CREATE DATABASE temporal_visibility;` + grants (`:9-15`). |
| `db/seeds/initial-data.sql` | `pg_dump --data-only` snapshot captured at alembic head **`050`**, 2026-05-20 (`db/seeds/README.md:9-13`). COPY-format (not INSERT). |
| `olympus-api/src/models/` | 34-file SQLAlchemy/Pydantic model **package** (~7288 LOC). These are ORM/API DTOs; the migrations are the authoritative DDL. |

**GOTCHA (transaction-per-run, not per-migration).** `env.py` runs the entire
upgrade batch inside one `context.begin_transaction()` (`:116-117`). There is **no**
`transaction_per_migration=True`. Every `ALTER TYPE … ADD VALUE` therefore executes
inside that outer transaction. Modern Postgres (12+) permits `ADD VALUE` in a
transaction **as long as the newly added label is not used in the same transaction**;
none of the `ADD VALUE` migrations use the new value, and each is guarded with
`IF NOT EXISTS` so a partial re-run is idempotent. If you rebuild on Postgres <12 you
must switch these migrations to autocommit or the batch will abort.

---

## 2. Migration DAG + single-head verification

**Verified single head = `091`.** A revision-graph walk (every `revision` that is never
someone's `down_revision`) yields exactly `['091']`. Total distinct revisions = **90**.
`055` is **absent** (confirmed — no file, no `revision="055"` anywhere).

The chain is linear except one **fan-out/fan-in around `033`** merged by `039`:

```
001→002→003→004→005→ … →032→033 ─┬→ 034 ┐
                                  ├→ 035 ┤
                                  ├→ 037 ┼→ 039 (merge: down_revision=("034","035","037","038"))
                                  └→ 038 ┘          │
                                                    ↓
                                       040→041→…→054→056→057→ … →091
```

- `034` down=`033`
- `035` down=`033`
- `036` down=`033`  ← **note:** `036` chains off `033` but `037` chains off `036`
- `037` down=`036`
- `038` down=`033`
- `039` **merge**, `down_revision=("034", "035", "037", "038")` (`039_merge_w19_reconciliation_heads.py`). This collapses the four W19-reconciliation branch heads back to a single head. `040` down=`039`.
- `054`→`056` (skips the missing `055`); `056` down=`054`.

**GOTCHA (084/085 misleading comments).** The module docstrings for `084` and `085`
say they "chain after the ACTUAL current head 075/076 to keep ONE head", but the
**actual** `revision`/`down_revision` assignments are `084` down=`083` and `085`
down=`084` (`084…py:51-52`, `085…py:44-45`). Trust the code, not the prose — the
comments are stale from an earlier rebase.

### 2.1 Per-migration ledger (what each does)

| # | File | Action |
|---|---|---|
| 001 | create_enum_types | `CREATE TYPE` × 12 native enums (§3). |
| 002 | create_core_tables | `portfolio`, `wave`, `application`, `wave_application`. |
| 003 | create_workflow_tables | `gate`, `agent_task`, `escalation`. |
| 004 | create_analytics_tables | `model_config`, `model_override`, `score_history`, `traceability_link`, `audit_log`. |
| 005 | create_indexes | 18 dashboard-query indexes across the above. |
| 006 | add_wave_name_timestamps | `wave`.{name, created_at, updated_at}. |
| 007 | add_wave_workflow_id | `wave.workflow_id` + `ix_wave_workflow_id`. |
| 008 | add_portfolio_artifact_repo_url | `portfolio.artifact_repo_url` TEXT. |
| 009 | add_application_git_columns | `application`.{source_git_token, source_git_base_url}. |
| 010 | add_application_workflow_id | `application.workflow_id`. |
| 011 | add_gate_workflow_columns | `gate`.{workflow_id, sla_deadline, evidence_package_url}. |
| 012 | add_gate_evidence_data | `gate.evidence_data` JSONB. |
| 013 | add_gate_escalated_status | `ALTER TYPE gate_status_enum ADD VALUE 'escalated'`. |
| 014 | create_chat_message_table | `chat_message`. |
| 015 | create_skill_table | `skill` + 3 indexes. |
| 016 | add_application_edit_columns | `application`.{description, target_repo_url, target_git_token, target_git_base_url}. |
| 017 | add_skill_structured_columns | 7 `skill` cols (system_prompt, references_data, assets_data, config_data, allowed_tools, dispatch_ids, skill_path) + GIN index on dispatch_ids. |
| 018 | add_skill_scripts_data | `skill.scripts_data` JSONB DEFAULT `'{}'`. |
| 019 | add_gate_preparing_status | `ADD VALUE 'preparing'` to gate_status_enum. |
| 020 | add_gate_reject_reason_category | `gate.reject_reason_category` TEXT. |
| 021 | add_application_archetype | `CREATE TYPE archetype_enum`; `application`.{archetype, archetype_source}. |
| 022 | normalize_wave_status_values | Data fix: `planned→draft`, `active→in_progress`. |
| 023 | wave_status_lifecycle | Add CHECK `wave_status_lifecycle_chk`; default→`draft` (§4.1). |
| 024 | add_application_portfolio_score | `application.portfolio_score` JSONB. |
| 025 | create_governance_tables | `health_check`, `drift_alert`, `pattern`. |
| 026 | create_user_table | `user_account` (username/email/password_hash/roles). |
| 027 | extend_agent_task_for_metrics | 12 `agent_task` metric cols + 5 indexes + `agent_benchmark` VIEW. |
| 028 | add_discovery_side_effect_columns | `application`.{tech_stack, size_metrics, safety_tier, architecture, business_logic, quality, tco}. |
| 029 | add_rationalization_disposition_columns | `application`.{disposition_source, disposition_rationale_ref}. |
| 030 | add_architecture_projection_columns | `application` arch cols + `application_lineage` table. |
| 031 | add_data_projection_columns | `application` data cols + `shared_db_cluster` table. |
| 032 | add_modernization_projection_columns | `application` mod cols + `bounded_context` table. |
| 033 | create_step_execution_table | `CREATE TYPE step_execution_kind_enum`, `…status_enum`; `step_execution` + 2 CHECK + 4 indexes. |
| 034 | add_disposition_projection_columns | `application` disposition cols (down=033, branch). |
| 035 | add_validation_projection_columns | `application` validation cols (down=033, branch). |
| 036 | add_deployment_projection_columns | `application` deployment cols (down=033; parent of 037). |
| 037 | create_sustainment_tables | 7 sustainment tables + 2 app lifecycle cols (down=036). |
| 038 | add_governance_sweep_tables | `factory_capacity_plan`, `model_benchmark_result` (down=033, branch). |
| 039 | merge_w19_reconciliation_heads | **Merge** 034/035/037/038 → single head; no DDL. |
| 040 | add_gate_merge_blocked | `ADD VALUE 'merge_blocked'`; `gate.merge_failure_detail` JSONB. |
| 041 | add_wave_description | `wave.description` TEXT. |
| 042 | gate_wave_scoped | `gate.application_id`→nullable, add `gate.wave_id`, exactly-one CHECK, `ix_gate_wave_id`. |
| 043 | wave_failed_status | Recreate wave CHECK adding `failed`; `wave`.{failed_at, failure_reason}. |
| 044 | agent_task_wave_scoped | `agent_task.application_id`→nullable, add `wave_id`, exactly-one CHECK, index. |
| 045 | wave_architecture_fanout_statuses | Recreate wave CHECK + 3 arch/data fan-out statuses. |
| 046 | create_arch_data_signal_registry | `arch_data_signal_registry` table. |
| 047 | add_consolidated_into_target_status | `COMMENT ON application.current_status` + partial index for `consolidated_into_target`. |
| 048 | create_workflow_signal_inbox | `workflow_signal_inbox` + status CHECK + 2 indexes. |
| 049 | add_stuck_awaiting_recovery_wave_status | Recreate wave CHECK + `stuck-awaiting-recovery`. |
| 050 | capability_system_grain | 10 tables (`system`, `system_application`, `capability`, `business_domain`, `capability_business_domain`, `capability_lineage`, `business_domain_lineage`, `system_lineage`, `agent_task_session_artifact`) + `agent_task` actor cols. |
| 051 | add_application_metadata | `application.metadata` JSONB NOT NULL DEFAULT `'{}'`. |
| 052 | rationalization_capability | `rationalization_capability` table + `capability`.{rationalization_capability_id, parent_capability_id, split_at}. |
| 053 | add_target_service_id_to_application | `application.target_service_id`. |
| 054 | add_architecture_workflow_id_to_wave | `wave.architecture_workflow_id`. |
| 056 | create_portfolio_membership | `portfolio_membership` table. |
| 057 | create_delegated_bundle | `delegated_bundle` + 4 child tables (input_ref/output_ref/session_artifact/validation_history). |
| 058 | application_disposition_capability_grain | `CREATE VIEW application_disposition` (grain-union). |
| 059 | wave_modernization_statuses | Recreate wave CHECK + modernization statuses. |
| 060 | create_skill_metrics | `skill_metrics` table. |
| 061 | create_viewer_event | `viewer_event` table. |
| 062 | rbac_gate_approval | `gate_approval` table + `gate`.{minimum_approvals, oversight_role, management_override_allowed}. |
| 063 | bundle_dispatching_workflow | `delegated_bundle.dispatching_workflow_id`. |
| 064 | agent_task_provider | `agent_task`.{provider_name, provider_fallback_from}. |
| 065 | create_design_annotation | `design_annotation` table + 2 CHECK. |
| 066 | create_interview_session | `interview_session` table + status/phase CHECK. |
| 067 | add_skill_bundled_resources | `skill.bundled_resources` JSONB DEFAULT `'{}'`. |
| 068 | create_eval_result | `eval_result` table. |
| 069 | create_ai_work_log | `ai_work_log` table. |
| 070 | create_reusable_parts_catalog | `catalog_entry` + `security_review_record` + CHECKs. |
| 071 | create_feedback_item | `feedback_item` table + partial unique index. |
| 072 | create_evidence_record | `evidence_record` table + hash CHECKs. |
| 073 | create_event_outbox | `event_outbox` table. |
| 074 | add_build_disposition | `ADD VALUE 'Build'` to disposition_enum. |
| 075 | add_build_assembly_line | `ADD VALUE 'Build'` to assembly_line_enum. |
| 076 | add_build_gate_types | `ADD VALUE 'G-NEW-1/2/3'` to gate_type_enum. |
| 077 | create_rendition | `rendition` table. |
| 078 | provenance_substrate | `agent_task_output`, `input_provenance` + `producing_skill` cols on traceability_link/ai_work_log/evidence_record. |
| 079 | add_profile_id | `portfolio.profile_id`, `application.profile_id`. |
| 080 | delegation_grant | `delegation_grant` table + status CHECK. |
| 081 | scoped_execution_assurance | `scoped_run` table + run_mode/assurance CHECK; `evidence_record.assurance_level`. |
| 082 | widen_event_outbox | 8 `event_outbox` cols (event_version, aggregate_type/id, profile_id, owner_scope, idempotency_key, publish_status, next_retry_at) + 2 indexes. |
| 083 | create_evidence_governance | 7 `evidence_record` governance cols + `control_mapping`, `control_ratification`, `evidence_suppression`. |
| 084 | create_drift_report | `drift_report` + `drift_reconcile_item`. |
| 085 | create_drift_control_block | `drift_control_block` table. |
| 086 | create_intent_record | `intent_record` table. |
| 087 | create_decomp_hierarchy | `decomp_hierarchy` + `decomp_node_review`. |
| 088 | feedback_loop_delta | `feedback_item`.{classification, closure_ref, escalated_from} + `feedback_work_order` + `feedback_ingest_cursor`. |
| 089 | extend_catalog_facets_consumers | 7 `catalog_entry` cols + 2 CHECK + `catalog_consumer` table. |
| 090 | create_eval_run | `eval_run` table (composite PK). |
| 091 | create_error_signal | `error_signal`, `incident_signal`, `capture_watermark`. |

---

## 3. Enum types (native `CREATE TYPE`) — final value sets

All 12 enums below are **native PostgreSQL enum types** created in `001`
(`001_create_enum_types.py:22-98`). Later migrations extend some via
`ALTER TYPE … ADD VALUE IF NOT EXISTS`. Two more native enums (`archetype_enum`,
`step_execution_kind_enum`, `step_execution_status_enum`) are created later.

| Enum type | Final values (in ordinal order) | Added-by |
|---|---|---|
| `risk_tier_enum` | `'1'`, `'2'`, `'3'` | 001 |
| `complexity_tier_enum` | `simple`, `moderate`, `complex` | 001 |
| `tier_source_enum` | `auto`, `confirmed`, `overridden` | 001 |
| `disposition_enum` | `Retire`, `Retain`, `Refactor`, `Rearchitect`, `Replace`, `Replatform`, `Consolidate`, **`Build`** | 001 + `Build` in **074** |
| `gate_type_enum` | `G-DC`, `G-RR`, `G-DA`, `G-02`, `G-DT`, `G-04a`, `G-04b`, `G-04c`, `G-DE-1`, `G-DE-2`, `G-V1`, `G-V2`, `G-V3`, `G-DP-1`, `G-DP-2`, **`G-NEW-1`, `G-NEW-2`, `G-NEW-3`** | 001 + G-NEW-* in **076** |
| `gate_status_enum` | `pending`, `approved`, `rejected`, `overridden`, **`escalated`**, **`preparing`**, **`merge_blocked`** | 001 + escalated(013) + preparing(019) + merge_blocked(040) |
| `assembly_line_enum` | `Discovery`, `Rationalization`, `Architecture`, `Data`, `Modernization`, `Disposition Execution`, `Validation`, `Deployment`, `Sustainment`, `Governance`, **`Build`** | 001 + `Build` in **075** |
| `task_status_enum` | `queued`, `dispatched`, `running`, `completed`, `failed`, `timed_out` | 001 |
| `escalation_status_enum` | `open`, `investigating`, `resolved` | 001 |
| `escalation_type_enum` | `Technical`, `Domain`, `Strategic`, `Safety`, `Infrastructure` | 001 |
| `escalation_severity_enum` | `Critical`, `Standard`, `Low` | 001 |
| `actor_type_enum` | `human`, `agent`, `system` | 001 |
| `archetype_enum` | `web-app`, `batch-etl`, `api-service`, `scheduled-job`, `hybrid` | **021** (`021…py:37-41`) |
| `step_execution_kind_enum` | `agent`, `git`, `gate`, `code`, `terminal` | **033** (`033…py:61-68`) |
| `step_execution_status_enum` | `queued`, `running`, `completed`, `failed`, `timed_out`, `skipped`, `escalated`, `abandoned` | **033** (`033…py:71-82`) |

**GOTCHA (enum ADD VALUE ordering).** Each `ADD VALUE` appends to the **end** of the
enum's ordinal ordering (Postgres default). The migrations do NOT use
`BEFORE`/`AFTER`, so `Build`, `G-NEW-*`, `escalated`, `preparing`, `merge_blocked`
all sort last. Any code that relies on enum ordinal ordering (rare) must account for
this. All `ADD VALUE` statements use `IF NOT EXISTS` for idempotent re-runs
(`013…py:21`, `019…py:24`, `040…py:49`, `074…py:31`, `075…py:33`, `076…py:35-37`).

**GOTCHA (`archetype` enum vs projection mismatch).** The DB enum
`archetype_enum` has values `web-app/batch-etl/api-service/scheduled-job/hybrid`
(`021`), but the Discovery projection `_extract_catalog_side_effects` accepts
`web-app/batch/api/scheduled-job/hybrid` (`discovery.py:254-257`) — `batch` and
`api` do **not** match the enum labels `batch-etl`/`api-service`. Writing those
projected values would violate the enum. Preserve this exactly (it is live code).

**GOTCHA (`archetype_source` reuses `tier_source_enum`).** `application.archetype_source`
is typed as `tier_source_enum` (auto/confirmed/overridden), NOT a dedicated type
(`021…py:60-64`).

---

## 4. Status columns stored as VARCHAR + CHECK (the "flexibility" pattern)

Beyond `wave.status` (below), most later status/kind columns are **plain `String`
with a `CHECK … IN (…)`** rather than native enums — deliberately, so the value set
can evolve with a `DROP CONSTRAINT` + re-`ADD CONSTRAINT` (which cannot fail mid-txn
the way `ALTER TYPE` can) without an enum migration. Every such value set is
enumerated in Part 2/3 per table. The wave lifecycle is the canonical example.

### 4.1 `wave.status` CHECK evolution (constraint name is stable: `wave_status_lifecycle_chk`)

`wave.status` starts as plain `String(50)` DEFAULT `planned` (002). Its allowed set
is governed by a named CHECK first added in 023 and **dropped+recreated** by each
subsequent status migration (the constraint name never changes so diagnostics keep
recognizing it):

| Migration | Default | Full allowed set |
|---|---|---|
| 002 (create) | `planned` | (no CHECK; free text) |
| 022 | — | data normalize only: `planned→draft`, `active→in_progress` |
| 023 | `draft` | `draft, ready, in_progress, completed, cancelled` |
| 043 | `draft` | + `failed` |
| 045 | `draft` | + `awaiting-architecture-dispatch, architecture-in-flight, data-in-flight` |
| 049 | `draft` | + `stuck-awaiting-recovery` |
| **059 (current head)** | `draft` | **`draft, ready, in_progress, awaiting-architecture-dispatch, architecture-in-flight, data-in-flight, modernization-in-flight, modernization-complete, completed, cancelled, failed, stuck-awaiting-recovery`** |

(Sets verified at `043…py:42-49`, `045…py:45-55`, `049…py:53-64`, `059…py` `_ALLOWED_STATUSES_NEW`.)

### 4.2 Exactly-one scoping CHECKs (gate / agent_task)

Migrations 042 & 044 make `application_id` nullable and add `wave_id`, enforcing a
mutually-exclusive scope:

- `gate_application_or_wave_ck` (042, `042…py:66-67`):
  `(application_id IS NOT NULL AND wave_id IS NULL) OR (application_id IS NULL AND wave_id IS NOT NULL)`
- `agent_task_application_or_wave_ck` (044, `044…py:72-73`): identical shape.

---

## 5. Git-as-source-of-truth + the projection model

**Principle (CLAUDE.md core principle 4).** Git is the source of truth; PostgreSQL is
a **derived, disposable query layer** rebuilt from Git + migrations. Artifacts are
committed to the artifact repo; the DB tables carry *projections* of those artifacts
so the dashboard/API can query without cloning Git.

### 5.1 How `persist_*` activities project artifact JSON → columns

The Temporal line-transition activities (`temporal/olympus_workflows/activities/line_transitions/`)
read the committed artifact JSON and UPDATE the relevant `application` columns. The
shared machinery is in `line_transitions/_shared.py`:

- **`_SIDE_EFFECT_COLUMNS`** (`_shared.py:70-153`) — the ordered allow-list of the ~60
  `application` columns a projection may touch. `_build_update_sql(projections)`
  (`:506-540`) walks this tuple, includes only keys present in the projection dict,
  JSON-encodes those in `_JSONB_COLUMNS`, **always** appends `updated_at = now()`, and
  ends with `WHERE id = $N`. Unset fields keep prior values (partial UPDATE).
- **`_JSONB_COLUMNS`** (`:156-171`) = `{tech_stack, size_metrics, architecture,
  business_logic, quality, ux_assessment, tco, portfolio_score, data_domains,
  bounded_contexts, generated_module_refs}` — these get `json.dumps()` before binding.
- **`_NATIVE_COLUMNS`** (`:174+`) = datetime / `list[UUID]` columns bound natively
  (architecture_decided_at, source_app_ids, data_decided_at, extraction_at, design_at,
  generate_at, validation_completed_at, …).
- **`_merge_application_metadata(conn, app_uuid, namespace, payload)`** (`:453-503`) —
  merges a per-line block into `application.metadata` via
  `SET metadata = COALESCE(metadata, '{}'::jsonb) || $1::jsonb`. It sets
  `payload.last_assessed = now().isoformat()` if absent, and **replaces the whole
  namespace block** (callers must pass the full namespace shape, not partial deltas).
  `COALESCE` defends against pre-051 NULL metadata.

**Connection pattern (every persist_* activity).** Raw `asyncpg.connect(_db_url())`
in a `try/finally: conn.close()` — **no SQLAlchemy session**. Multi-row UPSERTs (e.g.
`persist_capability_catalog`) wrap the whole persist in `async with conn.transaction():`
(`discovery.py:705`). Projection failures are **observability-only**: the workflow
continues even if a persist raises (docstring `discovery.py:517-524`).

### 5.2 Worked example: `persist_discovery_side_effects` (`discovery.py:513-607`)

1. Parse `app_id`→UUID (raise `NonRetryableError` on bad id, `:534`).
2. Parse each pass JSON best-effort with `_try_parse_json` (catalog / structural /
   business_logic / quality_risk / ux_accessibility / tco).
3. Build `projections` by `.update()` over six extractors:
   - `_extract_catalog_side_effects` (`:211-259`): `description`, `business_domain`,
     `tech_stack` (dict), `size_metrics` (dict), `complexity_tier`∈{simple,moderate,complex},
     `safety_tier`∈{T1,T2,T3}, `archetype`∈{web-app,batch,api,scheduled-job,hybrid}.
   - `_extract_structural_side_effects` (`:262-286`): `architecture.{major_components, integrations}`.
   - `_extract_business_logic_side_effects` (`:289-329`): `business_logic.{rule_count, critical_rules_count}` (critical = severity=="critical").
   - `_extract_quality_side_effects` (`:332-413`): `quality.{technical_debt_score, test_coverage (weighted avg if per-module), vulnerabilities_summary.{total,by_severity}, code_smells_summary.{total,by_type}}` + `risk_tier` from `risk_summary.tier`∈{1,2,3}.
   - `_extract_ux_side_effects` (`:416-469`): `ux_assessment.{personas_count, adoption_baseline_summary.{persona_count,total_active_users}, accessibility_score = max(0, 100 − crit*10 − serious*5), ui_inventory_summary.{screen_count}, ui_complexity_score}`.
   - `_extract_tco_side_effects` (`:472-510`): `tco.{annual_total, breakdown, formula_applied, confidence∈{high,medium,low} (default low), data_sources}`.
4. Also compute `compliance_metadata` via `_extract_discovery_compliance_metadata`
   (baseline `status="pending-ato"` + SAST/accessibility counters) merged into
   `metadata.compliance` (`:564-566, 583-586`).
5. If both empty → emit `columns_written=[]` and return. Else run one
   `_build_update_sql` UPDATE + the metadata merge.

### 5.3 The `application.decomposition_map` JSONB shape (`persist_decomposition_map`, `discovery.py:144-208`)

`_extract_decomposition(catalog, synthesis)` (`:48-141`) harvests into
`{modules: [{name}], integrations: [str] (deduped), tech_stack: [str] (deduped)}`.
Tolerates both W19-contract shape (`architecture.major_components`,
`architecture.integrations`, `tech_stack` object with language/framework sub-lists)
and the legacy dependency-mapper shape (flat `modules`/`integrations`/`tech_stack`).
Only writes if non-empty; UPDATE sets `decomposition_map` + `updated_at`.

### 5.4 Capability-grain UPSERT (`persist_capability_catalog`, `discovery.py:637-993`)

Projects a `capability-catalog` artifact into the `system` / `system_application` /
`business_domain` / `capability` / `capability_business_domain` tables:

- Validated by `_validate_capability_catalog` (`:615-634`): requires keys
  `{application_id, legacy_system, business_domains, capabilities}`, non-empty
  `legacy_system.name`, non-empty `business_domains` + `capabilities` lists; else
  logs + returns zero result (best-effort, no write).
- `system` row upsert keyed on `(portfolio_id, external_id)` **when external_id set**
  (`ON CONFLICT (portfolio_id, external_id) WHERE external_id IS NOT NULL`, `:714-715`),
  else SELECT-then-INSERT on `(portfolio_id, name)` because the only unique index is
  the partial one (`:735-758`). `kind='legacy'`.
- `system_application` upsert `ON CONFLICT (system_id, application_id) DO UPDATE SET role`.
- `business_domain` SELECT-then-INSERT on `(system_id, name)`.
- `capability` upsert on `(system_id, external_id)` partial (when set) using
  `RETURNING id, (xmax = 0) AS inserted` to count true inserts (`:884`), else
  SELECT-then-INSERT; `kind='legacy'`.
- `capability_business_domain` edges `ON CONFLICT DO NOTHING`; new edge detected by
  asyncpg result string ending `" 1"` (`:960`).

**GOTCHA (`(xmax = 0)` insert-detection).** `persist_capability_catalog` distinguishes
insert-vs-update by the Postgres system column `xmax = 0` on `RETURNING`
(`discovery.py:884`). This is an implementation-specific idiom; if you rebuild you must
preserve it or the `capability_rows` counter will be wrong.

### 5.5 Views projected from grain tables

- **`application_disposition`** (058, raw SQL VIEW): unions the rat-cap grain
  (`capability`→`system_application`→`rationalization_capability` where
  `disposition IS NOT NULL AND retired_at IS NULL`) with the capability grain
  (`capability.primary_disposition`/`secondary_disposition` via `CROSS JOIN LATERAL
  VALUES`), then `array_agg(DISTINCT …) FILTER (WHERE … NOT NULL)` into
  `{dispositions[], target_services[], rationalization_capability_ids[]}` grouped by
  `application_id`. **GOTCHA:** authored as a subquery-in-FROM (`FROM (…) per_app`),
  NOT a leading `WITH` CTE — required so `scripts/verify_sql_schema.py` reads the
  outer projected columns instead of the inner ones (`058…py:5-16`). Also inlined as a
  string literal to `op.execute` (not a module constant) for the same verifier reason.
- **`agent_benchmark`** (027, raw SQL VIEW `AGENT_BENCHMARK_VIEW_SQL`, `027…py:72-112`).

---

## 6. Seeds and init

### 6.1 `db/init/01-create-databases.sh`

Runs once on first Postgres launch (docker-entrypoint-initdb.d). Creates 3 DBs:
`olympus` (app), `temporal`, `temporal_visibility`; grants ALL to `$POSTGRES_USER`.

### 6.2 `db/seeds/initial-data.sql`

`pg_dump --data-only` at **alembic head 050**, 2026-05-20 (`README.md`). COPY-format.
Tables & row counts (per README): `skill` (157), `application` (20), `portfolio` (2),
`wave` (1), `wave_application` (8), `chat_message` (4), `score_history` (12).
Applied by `scripts/csn-fargate/migrate-local-data.sh` via an ECS `data-migrate` task
(`psql -f` inside the VPC) **after** Alembic has brought the schema to head.

The 2 seed portfolios: `Sample Portfolio (Demo)` (owner `demo`, repo
`olympus/sample-portfolio-demo`) and `ATLAS Challenge` (owner `Hephaestus`, repo
`ATLAS-CHALLENGE/challenge-portfolio`). Seed applications include "Flight Plan Filing
Portal", "Weather Integration Service", "Runway Inspection Tracker",
"Billing Reconciliation Batch", "Radar Feed Aggregator", "NOTAM Authoring Tool", … all
scoped to the demo portfolio with FAA-flavored descriptions.

> **Continue to Part 2** for the full column-by-column catalog of the core domain
> (portfolio/wave/application/gate/agent_task/escalation/analytics) and Part 3 for the
> capability-grain, governance, evidence, drift, delegation, eval, and feedback tables.
