# 05 — Dashboard Components (Part 4): Feature components (Wave*, Workflow*, Pipeline, Onboarding, etc.)

Continues Parts 1–3. Paths relative to `dashboard/src/components`. All default-export React FCs unless noted.
Convention repeated: self-fetching components use the `let cancelled=false` guard + `usePortfolioContext`/
route params; polling components read the response's terminal status to stop.

---

## BuildLineProgress/BuildLineProgress.tsx (default `BuildLineProgress`; exports types)
Presentational. Props `{data:BuildProgressData}`. Types: `BuildStepStatus` (not_started|in_progress|
complete), `BuildGateStatus` (pending|approved|rejected|not_started), `BuildSpecStep{status,rule_count?,
scenario_count?,coverage_pct?,escalation_flags?}`, `BuildDesignStep{status,contexts_count?,
api_endpoints_count?,design_traceability_pct?}`, `BuildGenerateStep{status,test_coverage_pct?,
ralph_loop_iterations?,ralph_loop_escalations?}`, `BuildProgressData{app_id,app_name?,spec,design,generate,
gates:{"G-NEW-1","G-NEW-2","G-NEW-3":BuildGateStatus}}`. `STEP_LABELS = ["Spec-from-Requirements","Design",
"Generate"]`. `gateClass`/`gateLabel`/`metric(v,suffix)` helpers. Renders a 3-step pipeline `<ol>` +
three per-step detail cards, each with a G-NEW-n gate badge and a `<dl>` of metrics (escalation_flags>0 ⇒
a flag Tag).

## MyTasksSummaryCard/MyTasksSummaryCard.tsx (default)
No props. Portfolio-scoped tile. `summarise(tasks)` (`:44`): counts total, claimable (`human_user_id==null`),
olympusAgent/human/humanWithAgent by `actor_kind`. Effect fetches `fetchMyTasks({include_claimable:true,
portfolio_id, limit:200})`; on error sets `hidden` (quiet fallback — no broken tile). Renders a card
"My Tasks" + "Open queue →" Link (`/me/tasks`) + Total/Claimable Tiles + per-actor-kind `<ActorKindBadge
size="sm">` + count.

## MoveToWaveDialog/MoveToWaveDialog.tsx (default; exports Props)
Props `{open, onCancel, onMoved:(destWaveId,destWaveName)=>void, portfolioId, applicationIds:string[],
sourceWaveName?, sourceWaveId?}`. State `picker:TargetWavePickerValue|null` + `pickerRef` mirror (so submit
reads the latest onChange even pre-flush), `submitting`, `error`, `reloadKey`. `!open` ⇒ null.
`handleSubmit` (`:82`): `newDraft` ⇒ `createWave({portfolio_id,name,application_ids:[]})`, else use chosen
wave; then `assignAppsToWave(destWaveId, applicationIds)` + `emitWaveEvent("wave.app.moved",…)` per app +
toast + `onMoved`. On error, reads `err.response.data.error.code`; `WAVE_NOT_DRAFT`/`SOURCE_WAVE_LOCKED` ⇒
bump `reloadKey` (refresh picker) and keep the error visible. Renders `<CreateModal>` with a
`<TargetWavePicker portfolioId disabled reloadKey onChange>` + Move/Cancel.

## WavePlanEmbed/WavePlanEmbed.tsx (default; exports `summariseDispositions`)
Props `{waveId, portfolioId?}` (portfolioId retained for compat, unused since PR6 tombstoned the route).
`isWavePlan(value)` guard (wave_id string + apps array + critical_path array + total_duration_days number).
`summariseDispositions(apps)` counts per disposition. Effect fetches `fetchWaveArtifact(waveId,"wave-plan.
json")`. Renders a disposition pill row + a per-app table (App · Disposition · Tier · Risk score).

## WaveBusinessRuleOverlap/WaveBusinessRuleOverlap.tsx (default; exports Props)
Props `{waveId}`. Effect fetches `fetchWaveArtifact(waveId, "rationalization/wave-{waveId}/
business-rule-redundancy.json")`; renders it via `<BusinessRuleRedundancyViewer>`. loading/error states.

## WorkflowFailureBanner/WorkflowFailureBanner.tsx (default; exports Props)
Props `{detail:WorkflowHealthDetail|null|undefined, onRetry?, onEscalate?, canRetry?=true, busy?=false}`.
`categorizeFailure(detail)` (from `./workflowFailureCategory`) → `{category,title,description,suggestion}`.
`CATEGORY_ICONS`: timeout ⏱, agent_error ⚠, gate_exhaustion 🚫, terminated ■, unknown ❓. null ⇒ null. Renders
`role="alert"` banner (class `--{category}`, `data-category`) with icon + title + category tag + description
+ suggestion + Retry (disabled when `busy||!canRetry`, hidden when no onRetry) + Escalate (hidden when no
onEscalate).

## CancelAllChildrenButton/CancelAllChildrenButton.tsx (default; exports Props)
Props `{waveId, waveName?, disabled?, onCancelled?}`. Sends `cancelAllWaveChildren(waveId)` (single
`cancel_all_children` signal — the wave orchestrator cancels each stored child handle; recorded gate
decisions NOT rolled back). Uses `<ConfirmModal>` for confirmation, `useQueryClient` to invalidate, toast.
Parent conditionally renders only in in-flight states.

## ConsolidatedBanner/ConsolidatedBanner.tsx (default; exports Props)
Props `{targetAppId?, targetAppName?, data-testid?, compact?=false}`. `hasTarget = targetAppId &&
targetAppName`. Rendered when app status is `consolidated_into_target`. `role="status"` Alert; compact variant
trims copy for cards; the target Link (`/applications/{targetAppId}`) has a spelled-out aria-label.

## AgentActivityByLine/AgentActivityByLine.tsx (default)
Props `{activity:AgentActivitySummaryView[]}`. Empty ⇒ null. Per-line rows: line name + most-recent
`<ActorKindBadge>` (+ tool); lines without a label grouped under "Other / unknown". `_formatTimestamp`
localeString helper. `aria-labelledby` section.

## PhaseRibbon/PhaseRibbon.tsx (default; exports `PhaseRibbonCounts`, `PhaseRibbonProps`)
Orientation ribbon of the assembly lines (order from `pages/AssemblyLines/assemblyLineConfig::ASSEMBLY_LINES`).
Props `{currentLine?:AssemblyLineName|null, counts?:PhaseRibbonCounts, showCounts?, ...}`. Two modes: app
mode (highlight `currentLine`, `aria-current="step"`) vs portfolio mode (emphasize non-zero-count lines +
count badge). Rendered as a `role="navigation"` `<ol>` of `<Link>`s to `/assembly-lines/{slug}`.

## PipelineNodeGraph/PipelineNodeGraph.tsx (default) + LineNode.tsx
`@xyflow/react` node-graph of the 10 lines; edges = app-flow arrows with live counts derived from portfolio
apps; continuous lines (Sustainment/Governance) in a top band with dashed overlay edges. `NODE_TYPES =
{lineNode:LineNode}`. `NARROW_BREAKPOINT_PX=900` — below it falls back to a stacked card list. Every node
has an aria-label; a hidden `<ul>` gives SR users the flow summary. Nodes navigate to `/assembly-lines/{slug}`.
`LineNode` (default; exports `LineNodeData`, `LineNodeType`): a custom react-flow node (`NodeProps
<LineNodeType>`) rendering an accessible tile (label/subtitle/count/color) with react-flow `<Handle>`s;
sizing from `./lineLayout` consts.

## AssemblyLinePipeline/AssemblyLinePipeline.tsx (default; exports `PipelineCounts`)
The full color-coded process diagram (Discovery → Rationalization → [parallel Architecture|Data|
Modernization, Disposition Execution below] → Validation → Deployment; Sustainment + Governance continuous
bands). Props `{counts?:PipelineCounts, onLineClick?, showCounts?, interactive?}`. Static `LineBox`
definitions per line.

## LineAnatomy/LineAnatomy.tsx (default; exports Props)
Props `{contract}` — build-time-parsed JSON from `src/data/line-contracts/{line_id}.json`. Renders the
canonical anatomy of one line at `/assembly-lines/{lineId}/anatomy`: header (name, gate list rendered
`Friendly Name (G-XX)` via `gateMetadata`, trigger, depends-on, scope model), per-step cards (kind·scope·…
chip row per `sectionSpec`/`STEP_BODY_BLOCK_ORDER`: purpose, skills, inputs, outputs, agent contract
(mcp_servers + repo access), retry policy, parallel_with, side-effect writes), a side-effect ledger table,
and execution-contract notes. Drops reconciliation-backlog/divergence/open-questions sections.

## OnboardingWizard/OnboardingWizard.tsx (default; Props `{onComplete}`)
Guided 6-step wizard that PERFORMS real API actions carrying state forward: Welcome → Create portfolio
(`createPortfolio`) → Add applications (`createApplication`) → Create a wave (`createWave`, optional) →
Kick off Discovery (`startDiscovery`) → Done. Each create step is idempotent from the user's view (a created
entity shows a confirmed summary, Back won't re-create). Every action surfaces a structured error + retry.
`StepId` union drives the flow.

## OnboardingCarousel/OnboardingCarousel.tsx (default; exports `ONBOARDING_STORAGE_KEY`, `OnboardingSlide`,
`OnboardingCarouselProps`, `hasDismissedOnboarding`, `rememberOnboardingDismissal`, `resetOnboardingDismissal`)
First-run 5-slide tour overlay (P3.5-O.1) mounted when no portfolio exists. `ONBOARDING_STORAGE_KEY =
"olympus.onboarding.dismissed.v1"`. `DEFAULT_SLIDES` (5). Keyboard: Escape closes, ArrowLeft/Right navigate,
focus-trapped dialog. Final slide has a "Load sample portfolio" CTA calling the caller handler (P3.5-O.2).
Dismissal persisted to localStorage via the exported helpers.

## ApplicationOnboardingForm/ApplicationOnboardingForm.tsx (default; exports Props)
Reusable onboarding form (inline or modal). Captures name, description, and a source-type dropdown (W13):
`git` (repo URL + optional creds), `zip` (multipart via `/applications/upload`), `s3` (`s3://bucket/prefix`,
server-side creds), and `confluence|sharepoint|gdrive|gcs` (DISABLED with "Coming in W13.2"). Embeds
`<TargetWavePicker>`. Returns a payload including `waveName` (P5-S27) so the post-onboard toast can name the
wave.

## ApplicationOnboardingForm/TargetWavePicker.tsx (default; exports `TargetWaveChoice`,
`TargetWavePickerValue`, `TargetWavePickerProps`)
Controlled three-radio picker. `TargetWaveChoice` = currentDraft|newDraft|existingDraft. Options: (1) current
draft wave (most-recent `created_at DESC`, hidden when no draft), (2) create new draft (inline name:
non-empty/≤60/unique via server 409; auto-selected when no draft, suggests `Draft Wave {maxWaveNumber+1}`),
(3) assign to existing DRAFT wave (dropdown filtered to draft — client half of cohort-lock; server enforces).
Props include `{portfolioId, disabled?, onChange, reloadKey?}`. Emits a discriminated `TargetWavePickerValue`.

## GateCardList/GateCardList.tsx (default; exports `GateCardItem`, `GateCardListProps`, `isGateStuckInPreparing`)
Reusable card-style gate list (used by GateQueue, PortfolioOverview gate queue, ApplicationDetail Status tab).
`GateCardItem` accepts both `GateSummary` (portfolio queue, has app fields) and `GateSummaryForStatus`
(app-detail, no app fields); `app_id`/`wave_id` mutually exclusive; `created_at`. Props `{gates:GateCardItem[],
caption, emptyMessage, showApplicationColumn?, onReview:(gateId)=>void, onForceAdvance?}`.
`isGateStuckInPreparing(gate)` (`:150`): a `preparing` gate older than `FORCE_ADVANCE_THRESHOLD_MS` (~10 min)
whose workflow terminated before `mark_gate_ready_for_review` — surfaces the manager-only "Advance gate"
button (only when `onForceAdvance` provided; role-gated off otherwise). Empty ⇒ `role="status"` message.

## PendingGatesQueue/PendingGatesQueue.tsx (default; exports Props)
Props `{waveId, waveName?}`. Aggregated reviewer queue for a wave's Architecture/Data fan-out cohort (G-02/
G-DT stay per-target). Polls `GET /waves/{id}/pending-gates` every 10s. One compact row per pending gate:
gate-type badge, app-name Link, external PR link, relative opened-at, "Open review" Link (to Gate Review with
`location.state.from={pathname,label:waveName}` referrer). Empty ⇒ "No pending gates in this wave"; errors
inline (poll continues).

## PreDispatchPanel/PreDispatchPanel.tsx (default; exports Props, ~1512 lines)
Props `{waveId, onDispatched?}`. Wave dispatch review for Architecture + Data fan-out.
v2 (preferred): one row per TARGET service from the wave-scoped `architecture-target-plan` (from
`target-state-mapper`). Operator can edit target name + repo per row, ADD a missed target, REMOVE a target
(with confirmation), and REASSIGN source apps between targets via a "Move to…" dropdown. v1 (legacy
fallback): one row per SOURCE app — used only when `GET /dispatch-target-preview` 404s / returns empty AND
`GET /dispatch-preview` returns the legacy shape. `loadPreview` tries v2 first, falls back to v1. On confirm,
dispatches the fan-out; `onDispatched` lets the parent re-fetch. GOTCHA: the largest dashboard component;
the v2/v1 detection + per-row edit/add/remove/reassign state machine is the load-bearing logic.

## SkillDispatchExplorer/SkillDispatchExplorer.tsx (default; exports Props)
Props `{open, onClose, artifactTitle?, artifactPath?, artifactType?, skillId?, dispatchId?, gateId?, appId?,
appName?}`. Drawer rendering the chain `dispatch_id → skill → artifact → gate → application`; each node is a
Link where reachable (skill catalog / gate review / app detail). Needs at minimum a `skillId` OR `dispatchId`
plus artifact path. Contextual (no standalone route).

## NeedsMyAttention/NeedsMyAttention.tsx (default; exports Props) + SummaryBar.tsx
Portfolio-scoped hero card (P3.5-U1.4). Props (`:66`): `{pendingGates:GateSummary[], escalatedGates?,
runningWorkflows?:WorkflowHealthSummary[], failedWorkflows?, currentUserId?, stalenessThresholdSeconds?
(default 24h), now?, maxItems?, loading?, activeWaves?:WaveListItem[], portfolioId?, applications?}`.
Prioritization: (1) pending gates (optionally scoped to `currentUserId`), (2) stuck RUNNING workflows
(staleness > threshold), (3) open escalations (`escalated`), (4) failed workflows (FAILED/TERMINATED/
TIMED_OUT); plus a Tier-1-undecided surface (P5-AUDIT-031: `risk_tier===1` app with no disposition and no
active line) and an active-wave redundancy-matrix quick link (P3.5-U3.5). Collapsed view via `<SummaryBar>`.
`SummaryBar` (default; exports `SummaryBarCounts`, `SummaryBarProps`): the whole bar is a `<button>`
(`aria-expanded`/`aria-controls`) — counts mode "N pending gate reviews · N escalations · N SLA at risk"
(any dimension >0; zeros still shown) vs positive-signal mode "Nothing needs your attention right now." (all
zero, no expand control). Focus stays on the bar when toggling.

## ComplianceDashboard/ComplianceDashboard.tsx (default; exports Props)
Props `{evidence:CatoEvidence, initialExpandedFamily?}`. Mock cATO SSP/POA&M viewer (demo quick-win; reads a
CatoEvidence shape today, swap `evidence` for a fetched artifact later). WAI-ARIA 1.2 accordion: each control
family is a `<button aria-expanded aria-controls>` toggling its panel.

## FanOutStatusTable/FanOutStatusTable.tsx (default; exports Props)
Props `{waveId, pollIntervalMs?=10000}`. Renders on Wave Detail during/after Architecture+Data fan-out. One
row per target app (current line/step/status) + row-level retry for failed targets (via `dispatch-retry`).
Polls `dispatch-status`; STOPS polling when the wave-level status is terminal (completed/cancelled).

## Tier1ApprovalPanel/Tier1ApprovalPanel.tsx (default; exports Props)
Props `{waveId, artifactRepoUrl?, artifactRepoBranch?="main", onApproved?:(item)=>void}`. Operator surface
for tier-1 stakeholder sign-offs — the wave rationalization workflow pauses on
`current_step="awaiting-tier1-approval-{app_id}"` for `risk_tier==="1"` apps, waiting for a
`StakeholderApprovedSignal` (scope `tier-1-classification`, approval_id `tier1-{app_id}-{n}`). Per-row state
`{rationale, submitting, error}`; a required rationale + a send button emit the signal (replacing the CLI
`temporal workflow signal`). Renders the classification-artifact path as a GitHub blob link when
`artifactRepoUrl` looks like `owner/name`, else a plain code element.

## CapabilityClusterSummary/CapabilityClusterSummary.tsx (default; exports Props)
Props `{waveId, portfolioId?, defaultExpanded?=true}`. Surfaces consolidation-candidate clusters from the
wave's redundancy-matrix artifact inline on Wave Detail. Artifact source preference: (1)
`portfolio-redundancy-matrix.json`, (2) `redundancy-matrix.json`. Cluster cards deep-link to the
RedundancyMatrix page when `portfolioId` supplied.

## CapabilitySystemCallout/CapabilitySystemCallout.tsx (default; exports Props)
Props `{targetSystems, realizesCapability, portfolioId}`. Surfaces the capability/system grain on
Application Detail: which SF3 S1–S11 target system(s) the app realizes (M:N admitted) and which SF1 M-row
capability it realizes — the demo-critical M:N case renders "Capability M9 realized in this app, routed to:
S2 + S6". `hasSystems`/`hasCapability` gate the sections.

## TraceabilityExplorer/TraceabilityExplorer.tsx (default; ~434 lines)
Props (an app id + optional initial artifact). Forward/backward chain navigation over the traceability graph:
pick an artifact path, view downstream (forward) + upstream (backward) tables, and run the gate-threshold
check for a selected gate (surfaces `/traceability/validate`). `DEFAULT_GATES` = [G-DC,G-RR,G-DA,G-02,G-DT,
G-04a,G-04b,G-04c]. `ValidateState` union (idle|loading|error|result{valid,coverage,threshold}). Clicking any
row re-focuses the explorer on that artifact (walk the chain).

## WaveGateDecisions/WaveGateDecisions.tsx (default; exports Props)
Props `{waveId, waveName?}`. Read-plus-click-through governance summary on Wave Detail — open (pending) +
recent (closed) gate decisions for the wave (G-RR/G-DA). Data via `fetchWaveGates(waveId)`. Each row Links to
`/gates/:gateId/review` with a `location.state.from` referrer back to this wave (task #123 pattern).

## WavePerformanceReport/WavePerformanceReport.tsx (default; exports Props)
Props `{waveId, initialReport?}`. Data `GET /waves/{waveId}/performance-report`. Renders: a horizontal bar
chart of per-line total time, a table of steps ranked by p95 wall clock, a table of agent-steps ranked by
LLM time vs tool time (thinking vs waiting), and a backend-supplied bottleneck one-liner list.

## WaveRoadmap/WaveRoadmap.tsx (default; exports Props, ~912 lines)
Props `{waveId}`. Gantt-style SVG timeline for the wave's apps, colored by `risk_tier` (1 red/2 amber/3
green), with dependency arrows from `application_lineage` (via `fetchApplicationLineage`) and diamond gate
markers (wave gates + per-app `pending_gate`). Computed client-side from existing endpoints — no new
workflows.

## WaveSynthesis/WaveSynthesisCard.tsx (default; Props `{waveId?, synthesis?}`)
Renders the W11 Wave Outcome Synthesis artifact. Self-fetching given `waveId`, or accepts a pre-loaded
`synthesis`. Layout: title row (wave number/name/timestamp), counts + disposition-mix donut, four net-impact
tiles (TCO, velocity, risk, users), target-state narrative (whitespace-preserving), and a consolidated
capabilities map with before/after chips.

## WaveSynthesis/TargetStateRollupBand.tsx (default; Props `{portfolioId}`)
Portfolio-wide rollup summing every wave's target-state synthesis; renders above the Applications table on
PortfolioOverview once ≥1 wave has emitted synthesis. Empty-state for empty portfolios; included/omitted
split for in-flight waves; per-wave deep-links to `/waves/{id}`.

## WaveWorkflowProgress/WaveWorkflowProgress.tsx (default; exports Props)
Props `{waveId, waveName?}` (task #95). Progress panel on Wave Detail for the WaveRationalizationWorkflow —
mirrors the per-app OperationsStrip + WorkflowDetailsDrawer pattern: a big status chip (Running/Completed/
Failed/Cancelled/Stalled), "Started X ago, updated Y ago", current-step label + 0-100% progress bar, a USWDS
error Alert (truncated last_error) on failure, and a "View timeline" drawer toggle.

## WaveRecoveryBanner/WaveRecoveryBanner.tsx (default; exports Props)
Props `{waveId, waveName?, status, failureReason:string|null, temporalUiUrl?, onResumed?, onRetried?,
onReset?}` (task #88). Renders ONLY for `stuck-awaiting-recovery` or `failed` (any other status → no-op).
`stuck-awaiting-recovery` (primary): "Resume Wave" (`POST /waves/{id}/resume`) + secondary "Retry
Rationalization" + Temporal link. `failed` (terminal): primary "Retry Rationalization"
(`POST /waves/{id}/retry-rationalization`) + Temporal link. Owns its loading state; callbacks let the parent
reload wave detail (WaveDetail's `reloadKey`).

## WorkflowControl/OperationsStrip.tsx (default; exports Props)
Props `{details:WorkflowDetailsResponse|null, onDetails, onCancel, onRetry, onRestart,
pendingAction?:"cancel"|"retry"|"restart"|null, appStatus?}`. Sticky control row on every ApplicationDetail
tab. Left: status chip (pending/running/completed/cancelled/failed/stalled), elapsed time, staleness
("updated 12s ago" → amber "stalled 14m ago"). Right: Details (drawer); Cancel/Retry (only when running);
Restart (terminal states → resets to Discovery). GOTCHA (P5-AUDIT-010): when `appStatus` claims running but
`details` has no `workflow_id`, shows a dedicated "Out of sync" state (vs "No run").

## WorkflowControl/NeedsAttentionBanner.tsx (default; exports Props)
Props `{app:ApplicationDetail, status:ApplicationStatus|null, workflow:WorkflowDetailsResponse|null,
onStartDiscovery, onRetry, onCancel, onOpenDetails, onViewWorkflow?, onReviewGate?, onResumeAfterRework?,
onViewReworkFeedback?, busy?}`. App-scoped "what does this app need next?" banner. First-matching-reason wins:
(1) pending gate → "Review gate"; (2) recently rejected gate → "Resume"/"View feedback"; (3) workflow failed
(terminal) → "View workflow"/"Retry"; (4) hung workflow → "Retry"/"Cancel"; (5) recent failed activity →
"Retry"/"Details"; (6) onboarded, no Discovery → "Start Discovery"; (7) stale analysis → "Re-run Discovery".

## WorkflowControl/WorkflowDetailsDrawer.tsx (default)
Right-side focus-trapped drawer (focus-trap-react, Escape closes, `aria-modal`) surfacing Temporal state,
recent errors, and a direct Temporal-UI link. Mirrors StepDetailDrawer.

## WorkflowRoutingDialog/WorkflowRoutingDialog.tsx (default; exports Props; Phase 6 W1)
Props `{open, onCancel, onConfirm:(delegation?:DelegationChoice)=>void, workflowLabel, defaultTargetId?,
defaultScopeKind?="gate_packet"|"line_step", submitting?}`. Prompted routing decision at every
workflow-start surface: "Run with Olympus agents" (internal default → `onConfirm(undefined)`) vs "Delegate to
a pair" (produces a claimable bundle for a scope: a gate packet or a single line step → `onConfirm(
DelegationChoice)`).

## WorkflowStepper suite (components/WorkflowStepper/)
### WorkflowStepper.tsx (default; exports `WorkflowStepperWaveContext`, `getLineStatus`,
`isWaveScopedRationalization`, `hasArchitectureTargetHandoff`)
SVG assembly-line progress viz with curved split/merge paths for parallel tracks. Props (`:302`):
`{appId?=null, currentLine, currentStep, pendingGate, workflowStatus, progressPct, lineStatus (map),
onRerunLine, startingLine?=null, wave?=null, target?=null, selectedLine? (controlled), onSelectLine}`. Each
line node is a clickable button that sets `selectedLine`; the bottom `<LineSteps>` renders that line's steps;
clicking a step opens `<StepDetailDrawer>`, hover shows `<StepTooltip>`; preview badges mark stubbed lines.
Snaps selection forward when `currentLine` advances (derived-state-during-render pattern). Exported pure
helpers: `getLineStatus` (`:112`), `isWaveScopedRationalization` (`:208`, D5 cross-level awareness for the
Rationalization node → links to the wave), `hasArchitectureTargetHandoff` (`:223`, D6 — surfaces the
source→target app transition so reviewers don't mistake where Architecture/Data run).
### LineSteps.tsx (default; exports `rerunButtonLabel`)
Bottom layer — renders steps for ANY selected line. `CONTINUOUS_LINES` set (Sustainment/Governance never get
a rerun button). Each step is a button (opens StepDetailDrawer, StepTooltip on hover/focus); gate steps carry
a "Gate" badge. Header hosts a per-line Start/Rerun button (`rerunButtonLabel(lineStatus)` (`:72`) →
"Start"|"Rerun"; disabled while another line is running). Uses per-line `line_status` so a parallel line
(Data) renders complete from its own status even when the cursor sits on its sibling (Architecture).
### StepDetailDrawer.tsx (default)
Right-side focus-trapped drawer, tabs Overview (static registry metadata) / Execution
(`GET /applications/:id/steps/:line/:step` — status/timings/retry/cost/errors/gate) / Artifacts (input +
output links). ChatDrawer focus-trap pattern; `STATUS_LABEL` map.
### StepTooltip.tsx (default)
Hover/focus tooltip (portal, mounts only when open). Props `{step:StepRegistryEntry, status:StepStatus,
anchor:HTMLElement|null, open, lineStubbed?}`. `STATUS_LABEL`: completed/active("In progress")/pending("Not
started")/blocked("Awaiting gate")/failed. `useLayoutEffect` positions it above the anchor.

## ModelUsageChart/ModelUsageChart.tsx (default; exports Props)
Props `{portfolioId?, waveId? (label-only), heading?="Model tier usage", headingLevel?="h3", initialRows?}`.
AI-oversight telemetry — per-model-tier (haiku/sonnet/opus/other) agent_task dispatch counts. Data `GET
/analytics/model-usage` (portfolio-scoped when `portfolioId`). Recharts chart.

## StaleArtifactsCard/StaleArtifactsCard.tsx (default; exports Props; P3.5-S.4)
Props `{appId?, maxItems?=5, heading?="Stale Artifacts", initialData?}`. Data `GET /artifacts/stale`. An
artifact is stale when `current_sha !== analyzed_sha`. `shortSha(sha)` → 7 chars. Top-N grouped by app +
"view all"; row click navigates to app detail to re-run analysis. Empty until source-drift pipeline runs.

## RenditionsDownloadMenu/RenditionsDownloadMenu.tsx (default; exports Props; P3.5-S.7)
Props `{appId, appName?, label?}`. Data `GET /applications/{app_id}/renditions`. `RENDITION_LABELS`:
requirements_doc/architecture_deck/test_report. Content returned inline (`RenditionItem.content`); download
builds a client-side Blob URL + synthetic `<a download>` click (`extensionFor` → "md" for all today).
Close on outside click + Escape (same idiom as CurrentUserMenu).

## ProfileBundleModal/ProfileBundleModal.tsx (default; exports Props)
Props `{open, portfolioId, onClose}`. "Export Profile" panel — fetches `GET /portfolio/{id}/profile-bundle`,
renders a file tree (left) + syntax-highlighted YAML (right, `react-syntax-highlighter` Prism `oneDark`).
Per-file download via `downloadText` (Blob, `text/yaml`); no bulk ZIP (JSZip not installed).

---

*(Continues in Part 5: the viewers group — ViewerRegistry dispatch + all 46 artifact viewers.)*
