# 05 — Dashboard Components (Part 3): GateReviewCards, Chat, Markdown, Charts, misc chips

Continues Parts 1–2. Paths relative to `dashboard/src`.

---

# GateReviewCards group (components/GateReviewCards/)

The card-per-check gate-review UI. Composed by `pages/GateReview/GateReview.tsx` → `GateReviewCardList`.

## CardStatusBadge.tsx (default `CardStatusBadge`; exports `CardStatus`, `CardStatusBadgeProps`, `STATUS_LABEL`)
`CardStatus` = pending|preparing|in_review|approved|rejected|escalated. `STATUS_LABELS` map (`:28`):
Pending/Preparing/In review/Approved/Rejected/Escalated. `StatusIcon({status})` (`:37`): a 14px inline SVG
per status (clock, magnifier, eye, check-circle, x-circle, warning-triangle), all `aria-hidden`+
`fill=currentColor`. Props `{status, ariaLabel?}`. Renders `<span role="status" aria-label={ariaLabel ??
label} data-testid=card-status-{status}>` = icon + label. Color from `--{status}` class (never color alone).

## ReviewerNoteEditor.tsx (default; exports `ReviewerNoteEditorProps`)
Props `{cardId, value, onChange, disabled?, defaultOpen?}`. State `open` (init `defaultOpen ??
value.trim().length>0`). Toggle button (`aria-expanded`/`aria-controls`) label flips Hide/Edit/Add reviewer
note. When open: a labelled USWDS `Textarea` (controlled by parent) placeholder "Add context for the agent
— rides with your decision."

## SupportingArtifactsList.tsx (default)
Props `{artifacts:SupportingArtifact[], parentId}`. State `openIds:Record<string,boolean>`, `rowRefs`.
`toggle(idx)` (`:220`): flips open; when OPENING, `queueMicrotask` → `scrollIntoView({block:"start"})` on
the row. Renders "Supporting artifacts (N)" + a `<ul>`; each row = a toggle button (chevron ▾/▸ + title +
type) and, when open, an `<ArtifactViewer artifactType data metadata schemaVersion>` (from ViewerRegistry).

## ApproveGateDialog.tsx (default; exports `ApproveGateDialogProps`, F4/P5-S18.5)
Props `{open, gateName, approvedCount, totalCards, onConfirm:(note)=>void, onCancel, submitting?=false}`.
`ApproveGateDialog` returns null when `!open`; else renders `<ApproveGateDialogImpl>` (sub-component so
state resets each open, `:342`). Impl: state `note`; focuses Cancel on mount; wraps `<CreateModal>` heading
"Approve {gateName}?"; body "{approvedCount} of {totalCards} cards approved. This decision is final…";
optional summary `Textarea`; Cancel + "Approve & submit" (calls `onConfirm(note.trim())`, disabled while
submitting).

## RejectGateDialog.tsx (default; exports `RejectGateDialogProps`, F4/P5-S18.5)
Same open/impl pattern. `WARN_THRESHOLD=10`. Impl state `reason`, `tipsOpen`. Derived: `trimmed`,
`isEmpty`, `isWarn = !isEmpty && length<=10`, `canSubmit = !isEmpty && !submitting`. `<CreateModal>` heading
"Reject {gateName}?"; body summary (reason becomes rework instruction); a REQUIRED reason `Textarea`
(`aria-required`, `aria-invalid={isEmpty}`), with a live hint: warn ("Short reasons produce poor reworks…")
when `isWarn`, else "Looks specific…"; a collapsible `<details>` of 5 tips for good rejection reasons;
Cancel + "Reject & submit" (secondary, disabled unless `canSubmit`, calls `onConfirm(trimmed)`). Policy:
warn at ≤10 chars, block at 0.

## GateReviewCard.tsx (default; exports `CardModel`, `GateReviewCardProps`, `SUMMARY_ARTIFACT_TYPES`,
`isSummaryArtifact`, `isSummaryCard`, `compareCardSeverity`, `compareCards`)
One horizontal card per artifact/finding/check. `CardModel` (`:634`): id, title, artifact, status,
severity?, confidence?, skillId?, model?, durationMs?, tokensIn/Out?, evidencePath?, commitSha?, isSummary?,
actorKind?, localAgentDescriptor?.
Pure helpers:
- `SEVERITY_ORDER` critical<high<medium<low. `SUMMARY_ARTIFACT_TYPES` = {review_summary,gate_summary,
  summary}. `isSummaryArtifact(a)` (`:698`): `metadata.is_summary===true` OR type in the set.
  `isSummaryCard(card)` = `card.isSummary===true || isSummaryArtifact(card.artifact)`.
- `compareCardSeverity(a,b)` (`:709`): by severity rank (missing=99), tiebreak lower confidence first
  (default 1).
- `compareCards(a,b,sortMode)` (`:727`): summaries ALWAYS lead regardless of sortMode; then `workflow`⇒0
  (stable/input order), else `compareCardSeverity`.
- `formatDuration` (`<1000`⇒"Nms", `<60000`⇒"N.Ns", else "Nm"), `formatTokens` (>=1000⇒"N.Nk"), `shortSha`
  (7 chars).
Props (`:757`): `{card, expanded, onToggleExpanded, note, onNoteChange, onApprove, onReject, disabled?,
rejectNoteRequired?=false}`. Refs headingId/bodyId/rejectNote ids + `inlineNoteRef`, `articleRef`,
`wasExpandedRef`. Effects: focus the inline required-note textarea when `rejectNoteRequired && expanded`
(F4); auto-`scrollIntoView` the card header when it transitions to expanded. `rejectDisabled = disabled ||
(rejectNoteRequired && !inlineNoteHasContent)`.
Render: `<article>` class `--{status}` `--expanded`. Header = a full-width unstyled toggle button
(chevron + title + "Show/Hide details" hint, `aria-expanded`/`aria-controls`) plus a status wrap
(`<CardStatusBadge>` + optional severity chip). A meta row (skill, actor-kind `<ActorKindBadge>`, model,
duration, tokens, evidence path + shortSha). (Remaining rows — summary text, required reject-note textarea,
action buttons Approve/Reject, and the expanded `<ArtifactViewer>` + `<SupportingArtifactsList>` — follow
the documented Row 4/5 layout; a second Reject click in the `rejectNoteRequired` state commits.)

## GateReviewCardList.tsx (default; ~971 lines — the orchestrator)
Props (composed by `GateReview.tsx`): `{evidence, onSubmit:(GateDecisionRequest)=>void, loading, aiPreReview,
autoOpenAiModal, openAiModalRequest, gateName, canApprove, canDecide, reviewerPolicy}`. Owns: building
`CardModel[]` from `evidence` artifacts (via `isSummaryArtifact`/`compareCards` sort with a workflow/severity
`CardSortMode` toggle), per-card expand + note + decision state, the gate-level toolbar (Approve gate /
Reject gate / Escalate / bulk-approve-remaining), the `ApproveGateDialog`/`RejectGateDialog`, the
`AIRecommendationModal` (re-opened when `openAiModalRequest` bumps or `autoOpenAiModal`), the
`CapabilityLineageReviewPanel` (threading its `capability_lineage_decisions` onto the submit payload), and
final `onSubmit(payload)` construction. `canApprove`/`canDecide`/`reviewerPolicy` gate the toolbar actions
(server RBAC is authoritative — see GateReview GOTCHA). [Large file — behavior summarized; sort/summary-pin
semantics live in GateReviewCard's exported comparators above.]

## RationalizationCapabilityCard.tsx (default; ~348 lines)
A specialized gate-review card for rationalization capability clusters (G-RR). Renders the
rat-cap grouping + per-capability disposition recommendation with approve/reject affordances feeding the
gate-decision payload. [Composed within GateReviewCardList for rationalization gates.]

---

# Chat subsystem (components/Chat/)

## AgentChatPanel.tsx (forwardRef default `AgentChatPanel`; exports `AgentChatPanelHandle`)
Advisory Q&A panel (NOT the action console — kept byte-for-byte unchanged per REQ-UNAC-006). Props
`{contextType:ChatContextType, contextId, section?, artifactContext?, suggestedQuestions?=DEFAULT_SUGGESTIONS,
onMessageCountChange?}`. Ref handle: `{resetMessages()}`. `Message = {role:"reviewer"|"agent", content,
timestamp:Date, sources?}`. `DEFAULT_SUGGESTIONS` (3). `SourceCitation({source})`: a Tag "artifact > file:line"
or "artifact > section > finding_id".
State: `messages, input, loading, historyLoading(true)`; refs `messagesEndRef`, `inputRef`.
`useImperativeHandle` exposes `resetMessages`. Effects: notify parent on `messages.length` change; autofocus
input after 100ms; load history via `fetchChatHistory(contextType, contextId, section)` (deps include
`section` so page nav reloads the right transcript; errors ignored → start fresh).
`handleSend(text?)` (`:158`): appends reviewer msg, clears input, `sendChat({context_type,context_id,
section?,message,artifact_context})`, appends agent msg (or an error msg on throw), scrolls. Enter (no shift)
submits. loading ⇒ "Loading conversation…". Render: messages region (empty ⇒ suggested-question buttons;
each message = header (You/Olympus AI + time) + body (agent ⇒ `<AgentMarkdown>`, reviewer ⇒ raw) + source
Tags), a "Thinking…" bubble while loading, and a composer form (textarea + Send, disabled while loading/empty).

## ChatDrawer.tsx (default `ChatDrawer`)
Floating FAB + drawer wrapping `AgentChatPanel`. Props `{contextType, contextId, section?, artifactContext?,
fabLabel?="Ask Olympus", drawerTitle?="Olympus AI", suggestedQuestions?, openSignal?}`. State `open,
messageCount, clearing`; ref `panelRef:AgentChatPanelHandle`. Effects: bump of `openSignal` (>0) opens the
drawer via `queueMicrotask(()=>setOpen(true))` (sidesteps the set-state-in-effect lint; 0→0 no-op); reset
`messageCount` on context change. `handleClear` (`:100`): `window.confirm`, then `clearChatHistory
(contextType,contextId,section)` → `panelRef.resetMessages()` + toast. Render: FAB button when closed; else
a `FocusTrap`-wrapped `role="dialog"` with header (title, Clear (disabled when clearing/0 msgs), Close ✕) +
`<AgentChatPanel ref onMessageCountChange=setMessageCount>`. Escape deactivates the trap → close.

---

# Markdown subsystem (components/Markdown/)

## AgentMarkdown.tsx (default)
The single markdown render seam for all agent output. Props `{children:string, components?, className?}`.
Wraps `react-markdown` + `remark-gfm`. `extractLanguage(className)` (`:52`): `language-(\w+)`.
`isMermaidCodeElement(node)` (`:60`): a `<code>` whose language === "mermaid". `DefaultCode` (`:72`): mermaid
+ !inline ⇒ `<MermaidBlock source={children.replace(/\n$/,"")}>`, else `<code>`. `DefaultPre` (`:88`): when
its sole child is a mermaid code element, skips the `<pre>` wrapper (MermaidBlock renders its own figure);
else styled `<pre>`. `defaults` (`:117`) override code/pre/table (USWDS bordered striped table).
The exported component composes a `codeOverride` (`:157`) so a caller-supplied `code` handles non-mermaid
langs while mermaid always routes to MermaidBlock; `pre` always stays the default. Runs
`replaceEmojiShortcodes(children)` (`:...`) BEFORE react-markdown so `:white_check_mark:` etc. render as
Unicode. Renders `<div className><Markdown remarkPlugins={[remarkGfm]} components={merged}>{rendered}</div>`.

## MermaidBlock.tsx (default; ~249 lines)
Renders a ```mermaid fenced block to SVG. Props `{source, title?}` (inferred). State machine
`{kind:"idle"|"rendering"|"ready"|"error", svg|message}`; refs `mountedRef`, `triggerRef`. Effect renders
via `mermaid.render(renderId, sanitized)` with a retry against raw source if a sanitizer pass fails; strict
security level. `deriveAriaLabel(source)` builds an accessible label. `openModal`/`closeModal` (closeModal
returns focus to the trigger). Render branches: error ⇒ a `mermaid-block--error` figure showing a "Diagram
failed to render — showing source" badge + raw `<pre>`; idle/rendering ⇒ loading figure (+ sr-only source);
ready ⇒ a figure with a trigger button (`dangerouslySetInnerHTML` the trusted SVG) + sr-only figcaption
(label + source), and a `<MermaidModal>` when `modalOpen`.

## MermaidModal.tsx (default; ~268 lines)
Full-screen zoom/pan viewer. Props `{svg, source, ariaLabel, onClose}`. `Transform = {scale,x,y}`; `INITIAL
{1,0,0}`, `MIN_SCALE=0.25`, `MAX_SCALE=16`, `ZOOM_STEP=0.2`, `PAN_STEP=40`; `clampScale`. State `transform`;
refs `dragStateRef`, `surfaceRef`. Keyboard (`:75`): Escape close; +/= zoom in, -/_ zoom out, 0 reset, arrows
pan (only when focus is inside the surface). `onWheel` (`:127`) zooms about the cursor. `onPointerDown/Move/Up`
implement click-drag pan (pointer capture). Render: `FocusTrap` + `role="dialog"` overlay (backdrop click
closes) with a header toolbar (zoom-out/scale%/zoom-in/Reset/Close) and a `role="application"` surface
(`tabIndex=0`) whose content div applies the transform + `dangerouslySetInnerHTML` the SVG; footer hint;
sr-only source `<pre>`.

---

# Charts (components/charts/) — all use `useChartTheme()` for palette

## ActivityTimeline.tsx (default)
Props `{events:ActivityEvent[]}`. `eventIcon(type)` (`:14`): gate_activity 🔒, discovery 🔍, workflow ⚡,
escalation ⚠️, default 📋. Empty ⇒ "No recent activity". Else a scrollable `<ul>` (maxHeight 320) of rows =
icon + description + `<time>` (localeString).

## HealthGauge.tsx (default)
Props `{value:number|null, label?="Health Index"}`. `gaugeColor(val)` (`:14`): <40 red, <70 amber (#FBBF24),
else green. null ⇒ "No health data". Else a recharts semicircle `RadialBarChart` (start 180→end 0) with the
value + absolute-positioned big number + label overlay.

## DispositionDonut.tsx (default; exports `computeDispositionData`)
Props `{data:{name,value}[]}`. `DISPOSITION_COLORS` (`:14`) map (8 dispositions incl. Build #00A91C, +
Undecided). `computeDispositionData(input)` (`:47`): rolls each app up into ONE slice using
`display_disposition ?? effective_dispositions[0] ?? disposition ?? "Undecided"`; also accepts a flat
string array; returns `{name,value}[]` sorted desc. Render: empty ⇒ "No disposition data"; else a recharts
`PieChart`/`Pie` donut (inner 60/outer 90) with per-slice `<Cell fill=DISPOSITION_COLORS>`, Tooltip, Legend,
and a center total label overlay.

## PipelineProgress.tsx (default; exports `computePipelineData`)
Props `{data:PipelineEntry[]}` (`{line,complete,inProgress,queued}`). `ASSEMBLY_LINE_ORDER` (10 lines,
`:26`). `computePipelineData(apps)` (`:38`): CUMULATIVE flow — an app on line N counts as `complete` for
every upstream line (indices < currentIdx); on its current line, classifies by status
(complete/done→complete, progress/active/running→inProgress, else queued). Render: no data ⇒ "No pipeline
data yet"; else a horizontal stacked `BarChart` (complete=success / inProgress=primary / queued=muted).

## Insights/MaturityTrendChart.tsx (default)
Props `{dimension:MaturityDimension}`. `DIMENSION_LABELS` map + `prettyLabel` fallback (titleize). `trendGlyph`
▲/▼/•. `formatPct(score)`: null⇒"—"; scores ≤1 treated as fractions ×100. Builds a two-point mini SVG line
(previous→latest, 60×24) with color class by trend; shows latest %, sparkline, delta (`+/-Math.round
(delta*100)`), and "{sample_count} sample(s)". No recharts (inline SVG, low footprint).

---

# Small shared chips / modals

## ActorKindBadge/ActorKindBadge.tsx (default)
Props `{actorKind:ActorKind, descriptor?:{tool?}, size?="sm"|"md", labelOverride?}`. `META` map (`:44`) per
kind: `olympus_agent` ("Olympus agent", ⚬, blue palette), `human` ("Human", ●, gold), `human_with_agent`
(orange). Each entry has label/icon/bg/border/fg/title verified ≥4.5:1 contrast. Renders a span chip with
icon + text label (color never load-bearing, WCAG 1.4.1) + a `title` definition; for `human_with_agent`
with a descriptor, appends "· {tool}".

## CreateModal/CreateModal.tsx (default; ~112 lines)
Reusable modal primitive (used by Approve/RejectGateDialog, etc.). Props `{open, onCancel, heading,
headingId, width?, children}`. Provides focus management, Escape dismiss, overlay-click-to-close, and
`role="dialog" aria-modal aria-labelledby={headingId}` ARIA wiring — the shared dialog shell for the app.

## LineageBadge/LineageBadge.tsx (default; exports `LineageBadgeProps`)
Props `{lineage:ApplicationLineageResponse, data-testid?}`. Renders app-lineage state on ApplicationDetail.
`formatRelationship(rel)` = trimmed lowercase. Separates a SELF edge (target===this app — in-place
dispositions Rearchitect/Refactor/Replatform/Retain) from genuine hand-off targets. Pristine (no sources +
no targets) ⇒ null. Renders up to three rows + callouts:
- Sources present ⇒ "Target" tag + "Rationalized from" + `<SourceChip>` per source (Link to
  `/applications/{related_app_id}` + relationship).
- `selfEdge` present ⇒ "In place" tag + "{relationship} on this application — Architecture & Data run here,
  no separate target."
- Real targets present ⇒ "Source" tag + "Rationalized to" + `<TargetChip>` per target (Link + relationship
  + optional external `repo ↗` link via `toAbsoluteRepoUrl`).
- D6 callouts: a `<RationalizedToCallout>` per target — a full-width Link "→ Rationalized to: {target} {rel}".
`edgeKey(edge)` = `${related_app_id}:${relationship}:${created_at}`. An app MAY be both target and source
(rows stack).

---

*(Continues in Part 4: feature components — Wave*, Workflow*, Pipeline, Onboarding, PreDispatchPanel,
SkillDispatchExplorer, NeedsMyAttention, ComplianceDashboard, and the remaining mid-size components.)*
