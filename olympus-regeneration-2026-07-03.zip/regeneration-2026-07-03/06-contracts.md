# Olympus Regeneration Spec — 06: The Contracts Layer (field-level, source of truth)

> Scope: `olympus-contracts/olympus_contracts/**` (the shared domain-type package) + `schemas/**`
> (the JSON-Schema wire contracts) + the anti-drift guards that pin them.
> **Rebuild verbatim.** The 12 assembly-line YAML contracts are reproduced byte-for-byte in the
> companion file `06b-assembly-line-contracts.md`; this file covers everything else at field level.
>
> Package version: `__version__ = "0.2.0"` (`olympus_contracts/__init__.py:148`).
> Package convention: nearly every dataclass here is `@dataclass(frozen=True, slots=True)` (immutable +
> memory-tight). The **8 frozen assembly-line dataclasses** additionally carry a golden-field guard (§8).

Modules present (excluding `build/lib/` build artifacts):
`__init__.py`, `assembly_lines.py`, `blueprint_types.py`, `capability_types.py`, `catalog_types.py`,
`connected_memory.py`, `drift_types.py`, `enums.py`, `errors.py`, `eval_types.py`, `event_outbox.py`,
`evidence_types.py`, `feedback_types.py`, `git_types.py`, `graph_types.py`, `ingestion_types.py`,
`intent_types.py`, `net.py`, `reusable_parts.py`, `signals.py`, `worklog_types.py`.

---

## 1. `enums.py` — the 10 canonical domain enums

`enums.py:10-12` — `from __future__ import annotations` + `import enum`. Module docstring
(`enums.py:1-8`): "canonical definitions consumed by olympus-api, olympus-workflows, olympus-worker, and the
MCP server … Aligned with `specifications/api/components/schemas.yaml`."

**GOTCHA (serialization base types).** Two enums use `IntEnum`/`StrEnum` explicitly (not `(str, Enum)` /
`(int, Enum)`) **because Temporal's default payload converter special-cases `IntEnum`/`StrEnum` subclasses**
so values round-trip across workflow input boundaries (`enums.py:28-31, 47-49`). Every StrEnum in the file
shares this rationale. Adding a new StrEnum member is backward-compatible for in-flight workflows.

### 1.1 `Disposition(enum.StrEnum)` — the 8 dispositions (`enums.py:15-41`)
The first 7 derive from analyzing an existing app; `BUILD` (P6-S5.2) is net-new construction. Values:

| member | value |
|---|---|
| `RETIRE` | `"Retire"` |
| `RETAIN` | `"Retain"` |
| `REFACTOR` | `"Refactor"` |
| `REARCHITECT` | `"Rearchitect"` |
| `REPLACE` | `"Replace"` |
| `REPLATFORM` | `"Replatform"` |
| `CONSOLIDATE` | `"Consolidate"` |
| `BUILD` | `"Build"` |

Disposition selects the downstream line: `Refactor`/`Rearchitect` → Modernization;
`Retire`/`Retain`/`Replace`/`Replatform` → Disposition Execution; `Consolidate` → hybrid; `Build` → Build line
(`enums.py:22-25`).

### 1.2 `RiskTier(enum.IntEnum)` (`enums.py:44-54`)
**GOTCHA: this is an `IntEnum`** (1 = Critical, 2 = Standard, 3 = Low-Risk) for the Temporal payload reason.
`TIER_1 = 1`, `TIER_2 = 2`, `TIER_3 = 3`.

### 1.3 `ComplexityTier(enum.StrEnum)` (`enums.py:57-66`)
`SIMPLE = "simple"`, `MODERATE = "moderate"`, `COMPLEX = "complex"`.

### 1.4 `Archetype(enum.StrEnum)` (`enums.py:69-80`)
Set by Rationalization Step 5 (Classification). `WEB_APP = "web-app"`, `BATCH_ETL = "batch-etl"`,
`API_SERVICE = "api-service"`, `SCHEDULED_JOB = "scheduled-job"`, `HYBRID = "hybrid"`.

### 1.5 `TierSource(enum.StrEnum)` (`enums.py:83-88`)
`AUTO = "auto"`, `CONFIRMED = "confirmed"`, `OVERRIDDEN = "overridden"`.

### 1.6 `GateType(enum.StrEnum)` — **18 gates** (`enums.py:91-122`)
The enum value is the **stable code** used in URLs, Git commits, contract schemas, registry IDs, DB columns —
MUST NOT be renamed without a migration.

| member | value | member | value |
|---|---|---|---|
| `G_DC` | `"G-DC"` | `G_NEW_3` | `"G-NEW-3"` |
| `G_RR` | `"G-RR"` | `G_DE_1` | `"G-DE-1"` |
| `G_DA` | `"G-DA"` | `G_DE_2` | `"G-DE-2"` |
| `G_02` | `"G-02"` | `G_V1` | `"G-V1"` |
| `G_DT` | `"G-DT"` | `G_V2` | `"G-V2"` |
| `G_04A` | `"G-04a"` | `G_V3` | `"G-V3"` |
| `G_04B` | `"G-04b"` | `G_DP_1` | `"G-DP-1"` |
| `G_04C` | `"G-04c"` | `G_DP_2` | `"G-DP-2"` |
| `G_NEW_1` | `"G-NEW-1"` | `G_NEW_2` | `"G-NEW-2"` |

**INVARIANT-GUARD:** `len(GateType) == 18` — pinned by `RunMode`/`AssuranceLevel`/`ProvenanceTier` docstrings
which repeatedly assert they add NO gate member. Advisory gate ids like `G-DRIFT`/`G-COMPOSE`/`G-RE-1`/`G-RE-2`
are NOT enum members.

**Companion table `GATE_FRIENDLY_NAMES: dict[GateType, str]`** (`enums.py:138-157`) — plain-English label per
gate (kept in sync with `dashboard/src/data/gateMetadata.ts`, `dashboard/src/config/glossary.ts`,
`cross-cutting/gates/README.md`):

`G-DC`→"Discovery Complete", `G-RR`→"Portfolio Rationalization Approval", `G-DA`→"Disposition Plan Approval",
`G-02`→"Architecture Alignment Review", `G-DT`→"Data Architecture Review", `G-04a`→"Extracted Specifications
Review", `G-04b`→"Modernization Design Review", `G-04c`→"Generated Code Review", `G-NEW-1`→"Spec Review",
`G-NEW-2`→"Build Design Review", `G-NEW-3`→"Code & Test Review", `G-DE-1`→"Disposition Execution Plan
Approval", `G-DE-2`→"Decommission Readiness Sign-off", `G-V1`→"Functional Parity Confirmation",
`G-V2`→"Compliance & Security Certification", `G-V3`→"Safety Assurance Sign-off", `G-DP-1`→"Production
Deployment Approval", `G-DP-2`→"Legacy Decommission Authorization".

`gate_friendly_name(gate_type: GateType | str) -> str` (`enums.py:160-173`): coerces via `GateType(gate_type)`
inside `try/except ValueError`; on unknown code returns `str(gate_type)` (defensive fallback so extension
gates don't crash logging). Returns `GATE_FRIENDLY_NAMES.get(key, str(gate_type))`.

**Companion table `GATE_ASSEMBLY_LINES: dict[GateType, str]`** (`enums.py:186-205`) — owning line per gate
(single source of truth for API gate service + scoring analytics; P5-AUDIT-014):
`G-DC`→Discovery; `G-RR`/`G-DA`→Rationalization; `G-02`→Architecture; `G-DT`→Data;
`G-04a`/`G-04b`/`G-04c`→Modernization; `G-NEW-1`/`G-NEW-2`/`G-NEW-3`→Build; `G-DE-1`/`G-DE-2`→Disposition
Execution; `G-V1`/`G-V2`/`G-V3`→Validation; `G-DP-1`/`G-DP-2`→Deployment.

`gate_assembly_line(gate_type: GateType | str) -> str` (`enums.py:208-219`): same try/except pattern;
**GOTCHA: unknown gate falls back to `"Discovery"`** (not the raw code) so legacy rows still render.

### 1.7 `RunMode(enum.StrEnum)` (`enums.py:222-244`) — P10-W9, REQ-SE-005
Tags each run's evidence scope. `FULL_PIPELINE = "full-pipeline"`, `ISOLATED = "isolated"`,
`PARTIAL = "partial"`, `COMPOSED = "composed"`. A run DIMENSION, NOT a gate.

### 1.8 `AssuranceLevel(enum.StrEnum)` (`enums.py:247-273`) — P10-W9, REQ-SE-006
Scope-of-claim on an evidence package, derived from `(run_mode, input origins, coverage, gate verdicts)`.
`FULL = "full"`, `PROVISIONAL = "provisional"`, `PARTIAL = "partial"`, `CONTEXT_STARVED = "context-starved"`.
**LOAD-BEARING:** assurance describes scope, NEVER waives a mandatory gate (REQ-SE-008).
Companion `ASSURANCE_RANK: dict[AssuranceLevel, int]` (`enums.py:279-284`): FULL=3, PROVISIONAL=2, PARTIAL=1,
CONTEXT_STARVED=0 (higher = stronger claim).

### 1.9 `GateStatus(enum.StrEnum)` (`enums.py:287-306`)
`PREPARING = "preparing"`, `PENDING = "pending"`, `APPROVED = "approved"`, `REJECTED = "rejected"`,
`OVERRIDDEN = "overridden"`, `ESCALATED = "escalated"`, `MERGE_BLOCKED = "merge_blocked"`.
`MERGE_BLOCKED` (W17/P5-S17.4) is a *post-decision* state: gate approved but the artifact-repo merge hit a
non-retryable condition; waits until a reviewer fires a `merge_retry` signal via
`POST /gates/{id}/retry-merge`.

### 1.10 `AssemblyLine(enum.StrEnum)` — **11 members** (`enums.py:309-325`)
**GOTCHA: exactly 11 values, and `"Reverse Engineering"` is NOT one of them** — even though
`reverse-engineering.yaml` is now a canonical assembly-line contract (a real drift item; the YAML is
registered additively by the loader but never added to this enum, per the reverse-engineering.yaml header,
pinned by `temporal/tests/test_interfaces.py` and `test_assembly_line_enum_is_exactly_ten`/eleven).

`DISCOVERY = "Discovery"`, `RATIONALIZATION = "Rationalization"`, `ARCHITECTURE = "Architecture"`,
`DATA = "Data"`, `MODERNIZATION = "Modernization"`, `BUILD = "Build"`,
`DISPOSITION_EXECUTION = "Disposition Execution"`, `VALIDATION = "Validation"`, `DEPLOYMENT = "Deployment"`,
`SUSTAINMENT = "Sustainment"`, `GOVERNANCE = "Governance"`.

Backward-compat alias: `AssemblyLineName = AssemblyLine` (`enums.py:330`) — API/MCP historically used
`AssemblyLineName`, Temporal used `AssemblyLine`.

---

## 2. `signals.py` — cross-service Temporal signal payloads (`signals.py:1-99`)

**GOTCHA (no deferred annotations).** This module deliberately OMITS `from __future__ import annotations`
(`signals.py:12-18`): Temporal's payload converter resolves field types via `typing.get_type_hints` against
module globals; deferred string annotations force `Any` lookups that fail at runtime with `NameError` in the
worker (W8 regression on `card_decisions: list[dict[str, Any]]`). Imports: `from dataclasses import dataclass,
field`; `from typing import Any, List, Optional` (`signals.py:20-21`). Only signals crossing service
boundaries live here; workflow-internal signals stay in `temporal/olympus_workflows/types.py`.

### 2.1 `@dataclass GateApprovedSignal` (`signals.py:24-43`)
| field | type | default |
|---|---|---|
| `gate_id` | `str` | — |
| `approved_by` | `str` | — |
| `justification` | `str` | `""` |
| `card_decisions` | `List[dict]` | `field(default_factory=list)` |
| `reviewer_notes` | `Optional[str]` | `None` |

`card_decisions` entries (W8 card-per-check, P5-S9): dicts with `card_id`, `artifact_type`, `decision`,
`note`, `ai_pre_review_used`; empty for legacy single-decision approvers.

### 2.2 `@dataclass GateRejectedSignal` (`signals.py:46-68`)
| field | type | default |
|---|---|---|
| `gate_id` | `str` | — |
| `rejected_by` | `str` | — |
| `reason` | `str` | — |
| `reason_category` | `Optional[str]` | `None` |
| `card_decisions` | `List[dict]` | `field(default_factory=list)` |
| `reviewer_notes` | `Optional[str]` | `None` |

### 2.3 `@dataclass GateMergeRetrySignal` (`signals.py:71-89`)
Emitted by `POST /api/v1/gates/{id}/retry-merge` when a reviewer clicks "Resolve & Retry Merge" on a
`merge_blocked` gate. Workflow catches via a `merge_retry` handler that flips `_merge_retry_signalled` and
wakes from `workflow.wait_condition`.
| field | type | default |
|---|---|---|
| `gate_id` | `str` | — |
| `retried_by` | `str` | — |
| `note` | `Optional[str]` | `None` |

`__all__` (`signals.py:94-99`): `GateApprovedSignal`, `GateMergeRetrySignal`, `GateRejectedSignal`, `Any`
(`Any` re-exported deliberately for future opaque per-card dicts).

---

## 3. `errors.py` + `git_types.py` — Git-service types & retryable semantics

### 3.1 `git_types.py` (`git_types.py:1-60`)
Pure-stdlib (no PyGithub) so importable anywhere. `from __future__ import annotations`; `import re`;
`from dataclasses import dataclass`.

**`BRANCH_PATTERN`** (`git_types.py:14-19`) — compiled regex enforcing branch naming
`olympus/{line}/{app_id}/{step}`:
```
^olympus/(?P<line>[a-z][a-z0-9-]*)/(?P<app_id>[a-z0-9][a-z0-9-]*)/(?P<step>[a-z0-9][a-z0-9-]*)$
```

| dataclass | fields (name: type = default) | src |
|---|---|---|
| `GitServiceConfig` | `token: str`; `repo: str`; `base_url: str = "https://api.github.com"` | `:22-28` |
| `PRResult` | `pr_number: int`; `pr_url: str`; `source_branch: str`; `target_branch: str` | `:31-38` |
| `FileReadResult` | `content: str`; `commit_sha: str`; `path: str` | `:41-47` |
| `CommitResult` | `commit_sha: str`; `path: str`; `branch: str` | `:50-56` |

`class GitServiceError(Exception)` (`git_types.py:59-60`) — base for all Git-service failures. The
`GitService` class itself lives in olympus-api (needs PyGithub) and is copied into the worker at Docker build.

### 3.2 `errors.py` — 3 merge error subclasses + retry semantics (`errors.py:1-69`)
`from olympus_contracts.git_types import GitServiceError` (`errors.py:34`). All three subclass
`GitServiceError` so legacy `except GitServiceError` sites keep working; new sites discriminate on subclass.
The type names are listed in `temporal/olympus_workflows/retry_policies.py`'s
`GIT_MERGE_RETRY_POLICY.non_retryable_error_types` so Temporal short-circuits retry on the non-retryable ones.
Strategy: `specifications/phase-5/artifact-repo-merge-strategy.md` §3.4.

| class | mergeable_state | retryable? | src |
|---|---|---|---|
| `MergeConflict` | `"dirty"` (real content conflict) | **NON-retryable** — needs human rebase+resolve | `:37-46` |
| `MergeDivergenceUnresolved` | `"behind"` still after update-branch | **Retryable** in bounded loops (racing merges resolve in seconds) | `:49-58` |
| `MergeBranchProtectionRejected` | `"blocked"` (branch protection) | **NON-retryable** — retry produces same rejection | `:61-68` |

---

## 4. NEW P7–P9 contract modules (data shapes only)

All frozen; all deliberately additive; all client-blind. Exported additively from `__init__.py`.

### 4.1 `capability_types.py` — Capabilities subsystem (P9-W18) (`capability_types.py:1-139`)
`from __future__ import annotations`; `import enum`; `from dataclasses import dataclass, field`.

**`ProvenanceTier(enum.StrEnum)`** (`:39-62`) — the provenance guarantee a capability run carries; ascending
strength, each tier a strict superset of the prior. StrEnum for Temporal round-trip; a run DIMENSION, adds NO
gate member.
`BARE = "bare"` (skill only; byte-for-byte the existing standalone dispatch, fastest),
`PROVENANCE = "provenance"` (skill + four-section work-log + immutable content-addressed evidence, S18.5),
`VERIFIED = "verified"` (provenance + independent maker≠verifier correctness check, S18.7).

**`@dataclass(frozen=True, slots=True) CapabilityRequest`** (`:65-96`):
| field | type | default |
|---|---|---|
| `capability` | `str` | — |
| `inputs` | `dict[str, object]` | `field(default_factory=dict)` |
| `tier` | `ProvenanceTier` | `ProvenanceTier.BARE` |
| `skill_id_override` | `str \| None` | `None` |
| `profile_id` | `str \| None` | `None` |
| `owner` | `str \| None` | `None` |

**GOTCHA:** `frozen=True` freezes the *binding*, not the mutable `inputs` dict it points at — treat `inputs`
as read-only by convention. Idempotency key `(skill_id, input_hash, tier)` (S18.6) is hashed upstream, not via
dataclass hashing.

**`@dataclass(frozen=True, slots=True) CapabilityResult`** (`:99-132`):
| field | type | default |
|---|---|---|
| `run_id` | `str` | — |
| `capability` | `str` | — |
| `tier` | `ProvenanceTier` | — |
| `artifact_ref` | `str` | — |
| `skill_id` | `str` | — |
| `work_log_ref` | `str \| None` | `None` |
| `evidence_content_hash` | `str \| None` | `None` |
| `verified` | `bool \| None` | `None` |
| `verifier_verdict` | `str \| None` | `None` |
| `metadata` | `dict[str, object]` | `field(default_factory=dict)` |

**GOTCHA (tri-state `verified`):** `verified is None` = "no verification ran" (bare/provenance), distinct from
`verified is False` = "verifier ran and check did NOT pass" (fail-closed, never a false "verified").
`__all__`: `CapabilityRequest`, `CapabilityResult`, `ProvenanceTier`.

### 4.2 `catalog_types.py` — asset-catalog facet/scope (P8) (`catalog_types.py:1-88`)
Re-exports the canonical `reusable_parts` catalog/security types (RECONCILE REQ-CT-RC-1 — does NOT author a
second `CatalogEntry`/`SecurityReviewRecord`): `PartKind, PartStatus, PublicationDecision, ScannerResult,
SecurityReview, evaluate_publication, is_valid_part_id, is_valid_semver` (`:33-42`). Adds only:

**`CatalogScope(str, enum.Enum)`** (`:45-56`) — three-scope tenancy, narrowest→widest:
`TENANT_PRIVATE = "tenant_private"`, `FIRM_WIDE = "firm_wide"`, `CONTRACT_SPEC = "contract_spec"`.

**`@dataclass(frozen=True, slots=True) CatalogFacet`** (`:59-74`) — scope/classification projection keyed to a
catalog entry by `part_id`:
| field | type | default |
|---|---|---|
| `part_id` | `str` | — |
| `scope` | `CatalogScope` | `CatalogScope.TENANT_PRIVATE` |
| `classification` | `str \| None` | `None` |
| `tenant_id` | `str \| None` | `None` |
| `tags` | `tuple[str, ...]` | `()` |
| `metadata` | `dict[str, object]` | `field(default_factory=dict)` |

### 4.3 `event_outbox.py` — transactional event outbox (P7-S16.10, widened P8) (`event_outbox.py:1-165`)
`import enum`; `from dataclasses import dataclass, field, replace`; `from typing import Any`.

**`OutboxStatus(str, enum.Enum)`** (`:41-52`): `PENDING = "pending"`, `DELIVERED = "delivered"`,
`FAILED = "failed"` (P8-additive terminal). P7 lifecycle (pending|delivered) is a strict subset.

**`@dataclass(frozen=True) OutboxEvent`** (`:55-98`) — typed view of one `event_outbox` row:
| field | type | default | note |
|---|---|---|---|
| `id` | `str` | — | dedupe key |
| `event_type` | `str` | — | |
| `payload` | `dict[str, Any]` | `field(default_factory=dict)` | opaque JSONB |
| `status` | `OutboxStatus` | `OutboxStatus.PENDING` | legacy P7 column |
| `attempts` | `int` | `0` | |
| `delivered_at` | `str \| None` | `None` | |
| `last_error` | `str \| None` | `None` | |
| `event_version` | `int` | `1` | P8 widening (REQ-EO-001), all additive/defaulted |
| `aggregate_type` | `str \| None` | `None` | |
| `aggregate_id` | `str \| None` | `None` | |
| `profile_id` | `str \| None` | `None` | |
| `owner_scope` | `str \| None` | `None` | |
| `idempotency_key` | `str \| None` | `None` | |
| `publish_status` | `OutboxStatus` | `OutboxStatus.PENDING` | the column the drainer advances |
| `next_retry_at` | `str \| None` | `None` | |

Properties: `is_delivered` (`:88-93`) = `status is DELIVERED or publish_status is DELIVERED`; `is_failed`
(`:95-98`) = `publish_status is FAILED` (terminal).

**`next_state_after_delivery(event, *, succeeded, now_iso, error=None, max_attempts=None, next_retry_at=None)
-> OutboxEvent`** (`:101-165`) — pure deterministic transition (no clock/I/O; caller injects time+backoff).
Reproduce this branch logic exactly:
1. If `event.is_delivered or event.is_failed`: **return `event` unchanged** (idempotent no-op; `attempts` NOT
   bumped) (`:137-138`).
2. `succeeded=True`: `replace(status=DELIVERED, publish_status=DELIVERED, attempts=attempts+1,
   delivered_at=now_iso, last_error=None, next_retry_at=None)` (`:139-148`).
3. `succeeded=False`: `new_attempts = attempts+1`;
   `exhausted = max_attempts is not None and new_attempts >= max_attempts` (`:149-150`). Then `replace`:
   - `status = PENDING` (**legacy column NEVER takes `failed`** so P7 readers never see an unfamiliar value),
   - `publish_status = FAILED if exhausted else PENDING`,
   - `attempts = new_attempts`, `last_error = error`,
   - `next_retry_at = None if exhausted else next_retry_at` (terminal rows cleared; retryable rows carry
     backoff) (`:151-165`).

   **GOTCHA:** `max_attempts=None` (the P7 default) = "retry forever" — always stays `pending` on failure,
   preserving original P7 behaviour exactly.

### 4.4 `reusable_parts.py` — catalog + publication gate (P7-S16.11, P8 eval delta) (`reusable_parts.py:1-401`)
`import enum`; `import re`; `from typing import Optional`; `from pydantic import BaseModel, Field,
field_validator`. **This is the only contracts module built on pydantic** (the rest are dataclasses).

Module-level constants:
- `SCANNER_CLASSES: tuple = ("sast","sca","secrets-scan","image-scan")` (`:57-62`).
- `REQUIRED_SCANNER_CLASSES: frozenset = frozenset({"sast","sca","secrets-scan"})` (`:68`) — image-scan
  excluded (not every part is a container image); frozenset for order-independent membership.
- `PART_KINDS: tuple = ("service","library","iac-module","agent","workflow","ui-component","dataset")` (`:72-80`).
- `PART_STATUSES: tuple = ("draft","in_review","published","deprecated")` (`:84-89`).
- `REVIEW_DECISIONS: tuple = ("approved","rejected","changes-requested")` (`:92-96`).
- `SCANNER_RESULT_STATUSES: tuple = ("passed","findings","failed","skipped")` (`:101-106`).
- `EVAL_STATUSES: tuple = ("current","stale","absent")` (P8; `:116-120`).
- `_SEMVER_RE` (`:125-127`): `^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$`.
- `_KEBAB_RE` (`:130`): `^[a-z0-9]+(?:-[a-z0-9]+)*$`.

Enums (all `(str, enum.Enum)`):
- `PartKind` (`:133-141`): SERVICE/LIBRARY/IAC_MODULE/AGENT/WORKFLOW/UI_COMPONENT/DATASET → the PART_KINDS
  values.
- `PartStatus` (`:143-148`): DRAFT/IN_REVIEW/PUBLISHED/DEPRECATED.
- `ReviewDecision` (`:150-153`): APPROVED="approved", REJECTED="rejected", CHANGES_REQUESTED="changes-requested".

Pydantic models:
- **`ScannerResult(BaseModel)`** (`:156-186`): `scanner: str`; `status: str = "passed"`;
  `blocking_findings: int = Field(default=0, ge=0)`. Validators: `scanner` must ∈ `SCANNER_CLASSES` else
  `ValueError`; `status` must ∈ `SCANNER_RESULT_STATUSES` else `ValueError`.
- **`SecurityReview(BaseModel)`** (`:189-211`): `decision: str`; `scanners_run: list[ScannerResult] =
  Field(default_factory=list)`; `notes: Optional[str] = None`. Validator: `decision` ∈ `REVIEW_DECISIONS`.
  Method `total_blocking_findings()` = sum of `r.blocking_findings`.
- **`PublicationDecision(BaseModel)`** (`:214-222`): `publishable: bool`; `reason_code: str`; `reason: str`;
  `blocking_findings: int = 0`; `missing_scanners: list[str] = []`; `failed_scanners: list[str] = []`.

Stable reason codes (`:226-236`): `PUB_OK="PUBLISHABLE"`, `PUB_NOT_APPROVED="REVIEW_NOT_APPROVED"`,
`PUB_BLOCKING_FINDINGS="BLOCKING_FINDINGS_PRESENT"`, `PUB_MISSING_SCANNERS="REQUIRED_SCANNER_MISSING"`,
`PUB_FAILED_SCANNERS="REQUIRED_SCANNER_FAILED"`, `PUB_NO_REVIEW="NO_SECURITY_REVIEW"`,
`PUB_EVALS_STALE_OR_ABSENT="EVALS_STALE_OR_ABSENT"` (P8 net-new).

**`evaluate_publication(review: SecurityReview | None, eval_status: str | None = None) ->
PublicationDecision`** (`:239-364`) — THE publication gate, pure/deterministic. Reproduce this exact ordering
(each check short-circuits with its reason_code; eval conjunct is evaluated LAST so review-failure codes take
precedence):
1. `review is None` → `PUB_NO_REVIEW` (`:278-286`).
2. `review.decision != ReviewDecision.APPROVED.value` → `PUB_NOT_APPROVED` (`:288-296`).
3. Build `by_scanner = {r.scanner: r for r in review.scanners_run}`;
   `missing = sorted(REQUIRED_SCANNER_CLASSES - by_scanner.keys())`;
   `failed = sorted(s for s in REQUIRED_SCANNER_CLASSES if s in by_scanner and by_scanner[s].status=="failed")`.
   If `missing` → `PUB_MISSING_SCANNERS` (+`missing_scanners`); elif `failed` → `PUB_FAILED_SCANNERS`
   (+`failed_scanners`) (`:298-325`).
4. `blocking = review.total_blocking_findings()`; if `blocking > 0` → `PUB_BLOCKING_FINDINGS`
   (+`blocking_findings`) (`:327-337`).
5. **P8 net-new conjunct:** `if eval_status is not None and eval_status != "current"` →
   `PUB_EVALS_STALE_OR_ABSENT` (fail-closed on stale/absent/unknown). `eval_status=None` skips the conjunct
   entirely (legacy review-only behaviour, preserving P7 tests) (`:339-354`).
6. Else `publishable=True, reason_code=PUB_OK` with reason text that appends " and evals are current." only
   when `eval_status == "current"` (`:356-364`).

Helpers: `is_valid_semver(version) -> bool` = `bool(_SEMVER_RE.match(version or ""))` (`:367-369`);
`is_valid_part_id(part_id) -> bool` = `bool(_KEBAB_RE.match(part_id or ""))` (`:372-374`).

---

## 5. Other cross-package contract modules (present, additive)

These are exported from `__init__.py` and belong to the contracts layer even though not enumerated in the
task list; capture at field level for completeness.

### 5.1 `worklog_types.py` — four-section agent work-log (P8) (`worklog_types.py:1-79`)
- **`ChecklistItem`** (`:25-34`): `text: str`; `done: bool = False`.
- **`WorkLog`** (`:37-73`): `run_id: str`; `skill: str`; `plan: str = ""`;
  `checklist: tuple[ChecklistItem, ...] = ()`; `decisions: tuple[str, ...] = ()`;
  `outcomes: tuple[str, ...] = ()`; `agent_role: str | None = None`; `workspace_path: str | None = None`;
  `metadata: dict[str, object] = field(default_factory=dict)`. Property `is_conformant` = all four sections
  (plan+checklist+decisions+outcomes) populated; `open_items` = checklist items with `done=False`. A dispatch
  without a conformant 4-section log is failed-to-verify.

### 5.2 `intent_types.py` — intent intake (P8) (`intent_types.py:1-71`)
- **`DerivedRequirement`** (`:23-34`): `ref: str`; `statement: str`; `status: str = "derived"`
  (derived|confirmed|rejected).
- **`IntentRecord`** (`:37-65`): `intent_id: str`; `statement: str`;
  `derived_requirements: tuple[DerivedRequirement, ...] = ()`; `status: str = "draft"`
  (draft|confirmed|rejected); `actor: str | None = None`;
  `metadata: dict[str, object] = field(default_factory=dict)`. Property `confirmed` = `status=="confirmed" AND
  bool(derived_requirements) AND all(r.status=="confirmed")` — the build-dispatch precondition.

### 5.3 `blueprint_types.py` — feature tree (P8) (`blueprint_types.py:1-85`)
- **`FeatureNode`** (`:27-46`): `id: str`; `parent_id: str | None`; `title: str`; `node_kind: str`;
  `traces_to: str`; `criticality: int = 3` (1=highest, 3-tier risk vocab); `review_decision: str = "pending"`
  (pending|approved|rejected); `description: str = ""`.
- **`BlueprintHierarchy`** (`:49-79`): `application_id: str`; `nodes: tuple[FeatureNode, ...] = ()`;
  `source_refs: dict[str, str] = field(default_factory=dict)`; `intent_ref: str | None = None`;
  `artifact_kind: str = "blueprint-hierarchy"`; `schema_version: str = "1.0"`. Property `root` = single node
  with `parent_id is None`; `unreviewed` = nodes with `review_decision=="pending"`.

### 5.4 `ingestion_types.py` — legacy ingestion (P8) (`ingestion_types.py:1-90`)
Const `REVERSE_ENGINEERED = "reverse_engineered"` (`:24`).
- **`ReconstructedObligation`** (`:27-42`): `ref: str`; `statement: str`; `confidence: float`;
  `provenance: str = REVERSE_ENGINEERED`; `needs_confirmation: bool = False`.
- **`ReconstructedSpec`** (`:45-63`): `app_id: str`; `source_root: str`;
  `obligations: tuple[ReconstructedObligation, ...] = ()`; `metadata: dict = field(default_factory=dict)`.
  Property `below_floor` = obligations with `needs_confirmation`.
- **`IngestionReport`** (`:66-82`): `app_id: str`; `obligations_total: int = 0`;
  `low_confidence_count: int = 0`; `classifier_domains: tuple[str, ...] = ()`;
  `write_attempts_refused: int = 0`; `metadata: dict = field(default_factory=dict)`.

### 5.5 `drift_types.py` — spec↔code drift envelope (P8) (`drift_types.py:1-95`)
- **`DriftFinding`** (`:30-47`): `kind: str`; `citation: str`; `detail: str`;
  `direction: str = "spec_ahead"` (spec_ahead|code_ahead); `severity: str = "medium"`; `blocking: bool = True`.
- **`DriftReport`** (`:50-89`): `app_id: str`; `findings: tuple[DriftFinding, ...] = ()`;
  `obligations_total: int = 0`; `obligations_satisfied: int = 0`; `content_digest: str | None = None`;
  `metadata: dict = field(default_factory=dict)`. Computed properties: `coverage_pct` =
  `100.0` if `obligations_total <= 0` else `round(100.0*satisfied/total, 4)`; `blocking_count` = count of
  blocking findings; `verdict` = `"pass"` iff `blocking_count == 0` else `"fail"` (derived, never stored).

### 5.6 `eval_types.py` — eval harness (P8) (`eval_types.py:1-94`)
- **`EvalCase`** (`:25-47`): `case_id: str`; `version: str`; `criterion: str`; `gate_type: str | None = None`;
  `ground_truth: str | None = None`; `metadata: dict = field(default_factory=dict)`. Property
  `has_independent_criterion` = `bool(criterion and criterion.strip())` — a case with no independent criterion
  is self-grading and rejected (REQ-EH-006, maker≠verifier).
- **`EvalResult`** (`:50-68`): `case_id: str`; `model_id: str`; `passed: bool`; `ai_verdict: str | None = None`;
  `ground_truth: str | None = None`; `run_index: int = 0`; `confidence_score: int | None = None`;
  `metadata: dict = field(default_factory=dict)`.
- **`VarianceReport`** (`:71-88`): `scope: str`; `runs: int = 0`; `pass_rate: float | None = None`;
  `pass_rate_stddev: float | None = None`; `cohens_kappa: float | None = None`;
  `metadata: dict = field(default_factory=dict)`.

### 5.7 `feedback_types.py` — feedback loop (P8) (`feedback_types.py:1-59`)
- **`FeedbackItem`** (`:25-54`): `id: str`; `source_type: str`; `signature: str`; `title: str`;
  `severity: str = "standard"`; `classification: str | None = None`; `status: str = "pending_review"`
  (pending_review|approved|dismissed); `occurrence_count: int = 1`; `source_id: str | None = None`;
  `closure_ref: str | None = None`; `metadata: dict = field(default_factory=dict)`. Property `is_actionable` =
  `status == "approved"`.

### 5.8 `evidence_types.py` — control mapping only (P8) (`evidence_types.py:1-44`)
RECONCILE REQ-CT-RC-3: the authoritative `EvidenceRecord` is the API-layer pydantic model at
`olympus-api/src/models/evidence_record.py`; this module authors ONLY the small envelope and deliberately does
NOT define/export `EvidenceRecord` (REQ-CT-007).
- **`ControlMapping`** (`:26-40`): `catalog_id: str`; `control_id: str`; `status: str = "proposed"`
  (proposed|dangling); `ratified: bool = False`.

### 5.9 `connected_memory.py` — project-memory projection interface (P7-S16.15) (`connected_memory.py:1-221`)
`from enum import StrEnum`; `from typing import Protocol, runtime_checkable`.
- **`MemoryNodeKind(StrEnum)`** (`:45-72`): P8 lifecycle chain `INTENT="intent"`, `REQUIREMENT="requirement"`,
  `FEATURE_NODE="feature_node"`, `WORK_ORDER="work_order"`, `TEST="test"`, `EVAL="eval"`, `CODE="code"`,
  `EVIDENCE="evidence"`; P7 originals retained `DECISION="decision"`, `FILE="file"`, `ARTIFACT="artifact"`.
- **`QueryDirection(StrEnum)`** (`:75-80`): `FORWARD="forward"`, `BACKWARD="backward"`, `BOTH="both"`.
- **`MemoryNode`** (`:83-94`): `id: str`; `kind: MemoryNodeKind`; `element: str | None = None`.
- **`MemoryEdge`** (`:97-108`): `source: str`; `target: str`; `relationship: str = "references"`.
- **`ConnectedMemoryView`** (`:111-134`): `app_id: str`; `nodes: tuple[MemoryNode, ...] = ()`;
  `edges: tuple[MemoryEdge, ...] = ()`. Method `node(node_id)`; property `is_empty`.
- **`MemoryQuery`** (`:137-148`): `node_id: str`; `direction: QueryDirection = BOTH`;
  `kinds: tuple[MemoryNodeKind, ...] = ()`.
- **`ContextResolution`** (`:151-162`): `enabled: bool`; `view: ConnectedMemoryView`.
- **`@runtime_checkable ContextResolver(Protocol)`** (`:164-182`): `async def resolve(self, app_id: str) ->
  ContextResolution`.
- `context_resolution_enabled(agent_contract, *, feature_enabled) -> bool` (`:185-207`): returns True only if
  `feature_enabled` AND the agent_contract declares ≥1 mcp server; reads `AgentContract` without mutating it.
- `disabled_resolution(app_id) -> ContextResolution` (`:210-220`): `enabled=False`, empty view.

### 5.10 `graph_types.py` — knowledge-graph typed edges + provenance (P8, DELTA over connected_memory) (`graph_types.py:1-206`)
`from enum import StrEnum`; imports `MemoryNodeKind` from connected_memory.
- **`LIFECYCLE_CHAIN: tuple[MemoryNodeKind, ...]`** (`:51-60`): ordered INTENT, REQUIREMENT, FEATURE_NODE,
  WORK_ORDER, TEST, EVAL, CODE, EVIDENCE. (DECISION/FILE/ARTIFACT deliberately excluded — supporting, not
  lifecycle.)
- **`EdgeKind(StrEnum)`** (`:63-80`): `DERIVES="derives"`, `REFINES="refines"`, `IMPLEMENTS="implements"`,
  `VALIDATES="validates"`, `EVIDENCES="evidences"`, `CONSTRAINS="constrains"`, `RELATES="relates"` (typed
  catch-all, never a raw string).
- `_RAW_TO_EDGE: tuple[tuple[str, EdgeKind], ...]` (`:87-101`) — ordered substring→EdgeKind map:
  `derive`→DERIVES, `refine`/`decompos`→REFINES, `implement`/`realiz`→IMPLEMENTS,
  `validat`/`verif`/`test`/`eval`→VALIDATES, `evidenc`/`attest`→EVIDENCES, `constrain`/`govern`→CONSTRAINS.
- `classify_edge(relationship: str | None) -> EdgeKind` (`:104-119`): lowercase+strip; empty→RELATES; first
  substring match wins; no match→RELATES (always typed, never raw).
- **`NodeProvenance`** (`:122-138`): `source: str = "traceability_link"`; `element: str | None = None`;
  `version: str | None = None`; `relationship_count: int = 0`.
- **`REQUIRED_UPSTREAM: dict[MemoryNodeKind, MemoryNodeKind]`** (`:150-154`): `REQUIREMENT→INTENT`,
  `FEATURE_NODE→REQUIREMENT`, `WORK_ORDER→FEATURE_NODE`.
- `required_upstream_kind(kind) -> MemoryNodeKind | None` (`:157-173`): `REQUIRED_UPSTREAM.get(kind)`.
- **`class BrokenTraceability(Exception)`** (`:176-206`): raised when a *required* upstream link is
  unresolvable (REQ-KG-005, reverses P7's silent empty view). `__init__(node_id, *, kind, missing_upstream)`
  stores `node_id`, `kind=str(kind)`, `missing_upstream=str(missing_upstream)`.

### 5.11 `net.py` — TCP keepalive socket options (`net.py:1-98`)
httpx-free (pure `os`+`socket`). Defaults: `_DEFAULT_IDLE_S=60`, `_DEFAULT_INTERVAL_S=30`, `_DEFAULT_COUNT=5`
(must stay well under the olympus-demo NLB's ~350s idle timeout). Helpers `_env_flag(name, default)` and
`_env_int(name, default)`. **`keepalive_socket_options() -> list[tuple[int,int,int]] | None`** (`:64-98`):
returns `None` if `A2A_TCP_KEEPALIVE` is falsy (`"0"/"false"/"no"/"off"`); else always appends
`(SOL_SOCKET, SO_KEEPALIVE, 1)` and, when the platform exposes them, `(IPPROTO_TCP, TCP_KEEPIDLE, idle_s)`,
`(TCP_KEEPINTVL, interval_s)`, `(TCP_KEEPCNT, count)`. Env overrides: `A2A_TCP_KEEPALIVE`,
`A2A_TCP_KEEPALIVE_IDLE_S`, `A2A_TCP_KEEPALIVE_INTERVAL_S`, `A2A_TCP_KEEPALIVE_COUNT`. (Not exported from
`__init__`.)

---

## 6. `__init__.py` — package surface (`__init__.py:1-252`)

`__version__ = "0.2.0"` (`:148`). Re-exports every public type/function from the modules above (import block
`:9-146`). **`__all__` is a sorted, collision-free list of 100+ names** (`:150-251`) — the sort + no-duplicate
+ authored-type-present invariants are enforced by `test_frozen_unchanged.py` (§8).

---

## 7. `assembly_lines.py` — the loader (yaml → frozen dataclasses + query API) (`assembly_lines.py:1-453`)

Imports: `from dataclasses import dataclass, field`; `from functools import lru_cache`;
`from importlib.resources import files`; `import yaml`.

### 7.1 The 8 frozen model dataclasses (all `frozen=True, slots=True`)
| dataclass | fields (name: type = default) | src |
|---|---|---|
| `RepoAccess` | `artifact: str="none"`; `source: str="none"`; `target: str="none"` (rw\|ro\|none) | `:65-71` |
| `AgentContract` | `mcp_servers: tuple[str,...]=()`; `repos: RepoAccess=field(default_factory=RepoAccess)` | `:74-79` |
| `SideEffect` | `target: str`; `fields: tuple[str,...]=()` | `:82-87` |
| `StepIO` | `artifacts: tuple[str,...]=()`; `context: tuple[str,...]=()`; `side_effects: tuple[SideEffect,...]=()` | `:90-96` |
| `RetryPolicy` | `category: str="transient"`; `non_retryable_errors: tuple[str,...]=()`; `max_attempts_override: int\|None=None` | `:145-151` |
| `GateRef` | `id: str`; `label: str=""` | `:154-159` |
| `StepContract` | see below | `:162-188` |
| `LineContract` | see below | `:191-241` |

**`StepContract`** fields in order (`:170-188`): `id: str`; `label: str`; `kind: str` (agent\|git\|gate\|
deterministic — plus `code`\|`terminal` accepted, see §8); `scope: str`; `sequence: int`; `purpose: str`;
`skills: tuple[str,...]=()`; `agent_role: str|None=None`; `role: str="analysis"` (analysis\|pre-review\|
rollup\|operational); `inputs: StepIO=field(default_factory=StepIO)`;
`outputs: StepIO=field(default_factory=StepIO)`;
`agent_contract: AgentContract=field(default_factory=AgentContract)`; `parallel_with: tuple[str,...]=()`;
`gate: str|None=None`; `retry_policy: RetryPolicy=field(default_factory=RetryPolicy)`;
`progress_pct: int|None=None`; `progress_weight: float|None=None`; `artifact_filename: str|None=None`;
`summary: bool=False`.

**`LineContract`** fields (`:195-203`): `name: str`; `description: str`; `trigger: str`;
`depends_on: tuple[str,...]`; `gates: tuple[GateRef,...]`; `mode: str` (per-app\|per-wave\|per-target-app\|
continuous); `inputs: tuple[str,...]`; `outputs: tuple[str,...]`; `steps: tuple[StepContract,...]`.
Methods: `step(step_id)` → raises `KeyError` if absent (`:209-214`); `step_ids()` (`:216-218`);
`agent_steps()` = kind=="agent" (`:220-222`); `evidence_steps()` = kind=="agent" AND role∈("analysis","rollup")
(`:224-234`); `summary_step()` = first step with `summary` True or None (`:236-241`).

**`InputProvenance` (Phase-10 W1)** (`:117-142`): `path: str`; `origin: str=DEFAULT_INPUT_ORIGIN`;
`attestation: str|None=None`. `INPUT_ORIGINS: tuple = ("upstream-line-output","operator-supplied",
"external-system","partial-prior-run")` (`:105-110`); `DEFAULT_INPUT_ORIGIN="upstream-line-output"` (`:114`).
**GOTCHA:** frozen `__post_init__` coerces an unknown `origin` back to the default via
`object.__setattr__` (never leaves an out-of-set value) (`:138-142`).

### 7.2 Parsers (yaml dict → dataclass)
- `_t(value) -> tuple` (`:249-255`): None→`()`; list/tuple→`tuple(value)`; scalar→`(value,)`. Normalizes every
  collection field.
- `_parse_step_io(raw)` (`:258-271`): builds `SideEffect(target=se.get("target",""), fields=_t(se.get("fields")))`
  per side_effect; wraps artifacts/context via `_t`.
- `_parse_agent_contract(raw)` (`:274-284`): `mcp_servers=_t(...)`; repos default each field to `"none"`.
- `_parse_retry_policy(raw)` (`:287-293`): category default `"transient"`.
- `_parse_gates(raw)` (`:296-304`): a gate item may be a bare str (→`GateRef(id=g)`) OR a dict
  (→`GateRef(id=g["id"], label=g.get("label",""))`).
- `_parse_step(raw)` (`:307-328`): `label` defaults to `id`; `kind` defaults `"agent"`; `scope` defaults
  `"per-app"`; `sequence=int(raw.get("sequence",0))`; `purpose` is `.strip()`ed; `role` defaults `"analysis"`;
  `summary=bool(raw.get("summary",False))`.
- `_parse_line(raw)` (`:331-343`): `description.strip()`; `mode` defaults `"per-app"`.

### 7.3 Load mechanism — `@lru_cache(maxsize=1) _load_all() -> dict[str, LineContract]` (`:346-376`)
- `data_root = files("olympus_contracts").joinpath("data/assembly-lines")` — **GOTCHA: uses
  `importlib.resources.files`, resolving the packaged data dir; the canonical YAMLs are at
  `olympus_contracts/data/assembly-lines/`, NOT the `build/lib/` copy.**
- Iterates `sorted(data_root.iterdir(), key=lambda p: p.name)`; **skips any entry not ending `.yaml` or
  starting with `_`** (`:355-357`).
- `yaml.safe_load` each file; **invariant: raise `ValueError` if the top-level object isn't a dict or lacks
  `"name"`** (`:360-363`); **raise `ValueError` on duplicate line name** (`:365-369`); **raise `RuntimeError`
  if zero lines loaded** (`:371-375`).
- Cached (contracts immutable at runtime); tests call `_load_all.cache_clear()` (`test_assembly_lines.py:29`).

### 7.4 Public query API (all read through `_load_all`)
`list_lines()` (sorted by name, `:384-386`); `line_names()` (`:389-391`); `get_line(name)` — raises `KeyError`
"unknown assembly line …" listing known names (`:394-401`); `get_step(line, step_id)` (`:404-406`);
`skill_for_step(line, step_id)` = first skill or None (`:409-414`); `pass_order(line)` = ordered evidence-step
ids (excludes pre-review/operational) (`:417-425`); `discovery_passes()` = `pass_order("Discovery")`
(`:428-431`); `step_progress(line)` = `{id: progress_pct}` for steps declaring one (`:434-439`);
`step_weights(line)` = `{id: float(progress_weight)}` (`:442-452`).

`__all__` (`:37-57`) lists 27 exported names. Note `AgentContract.repos` proxy: `context_resolution_enabled`
reads `mcp_servers` as the "resource-connected" signal.

---

## 8. Anti-drift mechanisms (CI guards) — what they pin and how

### 8.1 `test_no_hardcoded_step_lists.py` — the step-list drift guard (`tests/test_no_hardcoded_step_lists.py:1-177`)
**Guards against:** a literal cluster of step-id strings hand-typed in application code going stale when a
contract renames a step (the 2026-05-05 bug where a stale `_DISCOVERY_ORDER` in `olympus-api/src/services/
gate.py` dropped 4 of 7 gate-review cards, `:6-8`).
- Scans `olympus-api/src`, `olympus-worker/src`, `temporal/olympus_workflows` (`:37-41`); skips `.venv`,
  `__pycache__`, `build`, `.agents`, `.codex`, `tests`, `registries/defaults` (`:44-52`).
- For each line, collects `{step.id}` (`:71-77`). A file is flagged when it contains a **CLUSTER** = ≥5
  step-id string literals within any 10-line window (`CLUSTER_WINDOW=10`, `CLUSTER_THRESHOLD=5`, `:104-105`).
  Windowed so isolated per-step producer writes (`self._set_step("catalog", ...)`) pass.
- Waivers: `# allow: step-list-literal — <reason>` on the same/preceding line
  (`ALLOWLIST_RE`, `:56-59`, must have non-empty reason); or `# allow-file: step-list-literal — <reason>`
  anywhere (`FILE_ALLOWLIST_RE`, `:65-68`).
- Parametrized per line (`:108-111`); asserts no violations.

### 8.2 `test_frozen_unchanged.py` — golden field guard on the 8 frozen dataclasses (`tests/test_frozen_unchanged.py:1-249`)
**Guards contracts-v0.5.0-delta REQ-CT-005/004/007.** Pins the EXACT ordered field set (name + `str(field.type)`)
of `RepoAccess, AgentContract, SideEffect, StepIO, RetryPolicy, GateRef, StepContract, LineContract` captured
from baseline `cace7063` (`GOLDEN` dict, `:28-88`). ANY add/rename/retype/remove/reorder fails.
- `test_frozen_dataclasses_field_sets_unchanged` — `fields(cls)` must equal golden exactly (`:154-164`).
- `test_frozen_dataclasses_are_frozen_and_slotted` — all 8 `frozen is True AND slots is True` (`:167-173`).
- `test_frozen_dataclasses_count_is_eight` — `len(FROZEN_NAMES) == 8` (`:176-178`).
- `test_all_exports_sorted` — `c.__all__ == sorted(c.__all__)`; every `AUTHORED_TYPES` name present + resolves
  (`:186-191`). `AUTHORED_TYPES` (18 names, `:96-115`): BlueprintHierarchy, FeatureNode, CatalogFacet,
  CatalogScope, ChecklistItem, ControlMapping, DerivedRequirement, DriftFinding, DriftReport, EvalCase,
  EvalResult, VarianceReport, FeedbackItem, IngestionReport, ReconstructedObligation, ReconstructedSpec,
  IntentRecord, WorkLog.
- `test_no_duplicate_exports` — `len(__all__) == len(set(__all__))` (`:194-196`).
- `test_dod_types_are_frozen_dataclasses` — 12 DoD types frozen (`DOD_FROZEN_TYPES`, `:118-131`).
- `test_no_duplicate_canonical_type_definitions` — the 9 authored module files
  (`_AUTHORED_MODULE_FILES`, `:136-146`) must NOT contain `class {typ}` for forbidden names `OutboxEvent`,
  `MemoryNode`, `MemoryEdge`, `EvidenceRecord`, `CatalogEntry`, `SecurityReviewRecord` (REQ-CT-007, `:216-235`).
- `test_contracts_does_not_export_evidence_record` — no colliding `EvidenceRecord` in package/`__all__`
  (`:238-241`).
- `test_graph_concept_reused_not_duplicated` — `MemoryNode`/`MemoryEdge` resolve (`:244-248`).

### 8.3 `test_assembly_lines.py` — loader/contract invariants (`tests/test_assembly_lines.py:1-174`)
`setup_function` clears the lru_cache before each test (`:27-29`). Key pinned invariants:
- Discovery loads with `mode=="per-app"`, `trigger=="onboarding"`, `depends_on==()`, gate `G-DC` present
  (`:33-41`).
- **Every line: unique step ids** (`:43-48`); **≥1 step** (`:50-52`).
- **Every step kind ∈ `{"agent","git","gate","deterministic","code","terminal"}`** (`:54-63`) — note this
  ALLOWED set is wider than the StepContract docstring's four kinds (`code`, `terminal` are also valid).
- `line_names()` is sorted (`:65-67`); unknown line raises `KeyError` (`:69-71`).
- Discovery `discovery_passes()` pins the canonical 10-pass order (`:77-99`): `catalog, structural-analysis,
  business-logic-extraction, quality-risk-assessment, ux-accessibility-assessment, data-domain-discovery,
  shared-database-analysis, capability-extraction, synthesis, tco-baseline`. (Grew 7→9→10 across phases.)
- `synthesis` is the summary step (`:101-105`); `gate-readiness-check` is an agent but excluded from passes
  (pre-review) (`:107-114`); every evidence step has ≥1 skill (`:116-118`).
- `skill_for_step` mappings pinned: Discovery/catalog→`catalog-application`,
  Discovery/synthesis→`discovery-synthesizer`, git step `commit-artifacts`→None (`:120-124`).
- Progress monotonic within a line (`:126-137`); step IO fields are tuples not lists (`:156-161`);
  agent_contract repos preserved (catalog: artifact=rw, source=ro; mcp includes "olympus") (`:163-167`);
  contract is immutable — mutating raises AttributeError/TypeError (`:169-173`).

Other tests present (not detailed here): `test_capability_types.py`, `test_connected_memory_contract.py`,
`test_net.py`, `test_reusable_parts_contract.py`, `test_skill_manifest.py`.

---

## 9. JSON Schemas — `schemas/**` (113 schema files + 44 samples)

**Counts (verified via `find`, excluding `samples/`):** total **113** `*.schema.json` across 17 dirs;
**44** `*.sample.json` (41 in `samples/` + 3 in `ingestion/`: 2 samples counted there because
ingestion ships `.sample.json` alongside `.schema.json`).

Per-directory schema counts:
| dir | count | dir | count |
|---|---|---|---|
| architecture | 12 | ingestion | 2 (schemas) + 2 samples |
| build | 3 | modernization | 7 |
| common | 4 | oscal | 1 (NEW) |
| compliance | 1 (+ samples/ subdir) | profiles | 8 |
| cross-cutting | 15 | rationalization | 18 |
| data | 6 | drift | 1 (NEW) |
| design | 6 | evidence | 1 (NEW) |
| discovery | 17 | gates | 3 |
| dispositions | 8 | | |

> NOTE vs the task hint (cross-cutting "11"): live count is **15** cross-cutting schemas (attestation-chain,
> audit-event, autonomy-policy, capability-result, error-signal, event-envelope, incident-signal, journey-fsm,
> metric, oidc-server-config, rendition-manifest, score-snapshot, temporal-workflow-contract,
> traceability-report, triage-digest). ingestion has 2 schemas (ingestion-report, reconstructed-spec) + 2
> samples. compliance has 1 schema (`control-evidence`) plus a `samples/` subdir.

### 9.1 GOTCHA — `$id` host inconsistencies (load-bearing for `$ref` resolution)
The overwhelming majority use host `https://olympus.framework/schemas/...`. **These are the exceptions — a
`$ref` that assumes the framework host will fail to resolve against these:**

| file | anomalous `$id` |
|---|---|
| `build/blueprint-hierarchy.schema.json` | `blueprint-hierarchy.schema.json` (bare filename, no host) |
| `build/requirements-capability.schema.json` | `schemas/build/requirements-capability.schema.json` (relative, no host) |
| `build/scenario-spec.schema.json` | `schemas/build/scenario-spec.schema.json` (relative) |
| `cross-cutting/attestation-chain.schema.json` | `schemas/cross-cutting/attestation-chain.schema.json` (relative) |
| `cross-cutting/audit-event.schema.json` | `schemas/cross-cutting/audit-event.schema.json` (relative) |
| `cross-cutting/event-envelope.schema.json` | `schemas/cross-cutting/event-envelope.schema.json` (relative) |
| `cross-cutting/journey-fsm.schema.json` | `schemas/cross-cutting/journey-fsm.schema.json` (relative) |
| `cross-cutting/oidc-server-config.schema.json` | `schemas/cross-cutting/oidc-server-config.schema.json` (relative) |
| `cross-cutting/temporal-workflow-contract.schema.json` | `schemas/cross-cutting/temporal-workflow-contract.schema.json` (relative) |
| `design/*.schema.json` (all 6) | `schemas/design/<name>.schema.json` (relative) |
| `discovery/eligibility-rule-engine.schema.json` | `schemas/discovery/eligibility-rule-engine.schema.json` (relative) |
| `modernization/modern-requirements.schema.json` | `https://olympus.dev/schemas/...` (dev host) |
| `modernization/rule-reconciliation-matrix.schema.json` | `https://olympus.dev/schemas/...` (dev host) |
| `profiles/delegation.schema.json` | `https://olympus.dev/schemas/profiles/delegation.schema.json` (dev host) |
| `profiles/lock-policy.schema.json` | `https://olympus.dev/schemas/profiles/lock-policy.schema.json` (dev host) |
| `rationalization/rationalization-clustering-plan.schema.json` | `https://olympus.faa.gov/schemas/rationalization/rationalization-clustering-plan.json` (**faa.gov host + `.json` not `.schema.json`**) |

Host tally (113 total): **92 × `https://olympus.framework`**, **4 × `https://olympus.dev`**
(modernization/modern-requirements, modernization/rule-reconciliation-matrix, profiles/delegation,
profiles/lock-policy), **1 × `https://olympus.faa.gov`** (rationalization/rationalization-clustering-plan,
also `.json` not `.schema.json` suffix), **16 × relative/bare** (build 3, cross-cutting 6, design 6,
discovery 1 = discovery/eligibility-rule-engine). 92 + 4 + 1 + 16 = 113.

### 9.2 GOTCHA — schemas EXCLUDED from `schemas/validate.sh`
`validate.sh` (`schemas/validate.sh`) iterates an EXPLICIT dir list:
`common, discovery, rationalization, architecture, data, modernization, build, gates, cross-cutting,
compliance, profiles, dispositions`. **Omitted (NOT metaschema-validated by validate.sh): `design/`,
`drift/`, `evidence/`, `ingestion/`, `oscal/`.** The metaschema check requires each validated schema to have
`$schema`, `$id`, `title`, `description` (else FAIL). The `Summary` block recomputes `SCHEMA_COUNT` /
`SAMPLE_COUNT` via `find` over ALL dirs (so its reported total includes the excluded dirs even though they
weren't looped). Sample round-trip is delegated to `scripts/validate_schema_samples.py`: every schema must
have ≥1 sample instance (a tracked backlog of uncovered schemas lives in that helper).

### 9.3 Schema inventory — `$id` (relative to framework host unless noted in §9.1), required fields, key properties
For each: `title` — required=[...]. Full property list is verbatim-recoverable per file; the most load-bearing
required set is given.

**architecture/** (all type=object, host=framework)
- `accessibility-review` — "Accessibility Review"; req: schema_version, target_app_id, wave_id.
- `ai-ml-integration` — req: application_id, skill_id, step, target_app_id, wave_id.
- `architecture-blueprint` — req: application_id, skill_id, step, wave_id. (~40 props incl services, adrs,
  c4_diagrams, cost_estimate_*.)
- `architecture-target-plan` — req: wave_id, generated_at, targets, target_app_count, summary.
- `cloud-pattern` — req: skill, target_app_id, wave_id.
- `cost-estimate` — "Cloud Cost Estimate"; req: application_id, skill_id, step, wave_id.
- `design-system` — req: application_id, schema_version, wave_id.
- `ea-compliance` — req: application_id, schema_version, wave_id.
- `integration-arch` — req: application_id, schema_version, wave_id.
- `security-arch` — req: application_id, schema_version, wave_id.
- `target-application-map` — req: target_app_id, wave_id.
- `well-architected-review` — req: application_id, skill, wave_id.

**build/**
- `blueprint-hierarchy` ($id bare filename) — "BlueprintHierarchy"; req: artifact_kind, schema_version,
  application_id, source_refs, nodes, review_summary. (The wire twin of the `BlueprintHierarchy` dataclass §5.3.)
- `requirements-capability` ($id relative) — req: artifact_kind, schema_version, application_id, produced_by,
  produced_at, capabilities, functional_requirements, constraints, acceptance_criteria, stakeholders,
  portfolio_context.
- `scenario-spec` ($id relative) — req: artifact_kind, schema_version, application_id, scenarios,
  coverage_summary.

**common/**
- `confidence-level` — req: level, score, rationale.
- `evidence-reference` — req: title, artifact_path, artifact_type, finding_summary, citations.
- `risk-tier-annotation` — req: tier, source.
- `traceability-citation` — **req: [] and props: [] (a bare/patterned schema — no object properties declared).**

**compliance/**
- `control-evidence` — "Per-Control Compliance Evidence Record"; req: control_id, family, status,
  evidence_refs, last_assessed, assessed_at_gate.

**cross-cutting/** (15)
- `attestation-chain` ($id relative) — req: link_1_hash, link_2_signature, link_3_timestamp, signed_at, signer.
- `audit-event` ($id relative) — req: event_id, occurred_at, actor, verb, subject, row_hash.
- `autonomy-policy` — req: autonomy. (props: triage, autonomy.)
- `capability-result` — "Capability Result (tiered single-skill dispatch outcome)"; req: run_id, capability,
  tier, skill_id, status. (props incl artifact_refs, work_log_ref, evidence_content_hash, verified,
  verifier_verdict, output_schema_validated/errors — the wire form of `CapabilityResult` §4.1.)
- `error-signal` — req: source, source_row_id.
- `event-envelope` ($id relative) — req: event_id, aggregate_id, aggregate_type, type, version, occurred_at,
  payload.
- `incident-signal` — req: fingerprint.
- `journey-fsm` ($id relative) — req: id, initial, context, states.
- `metric` — "Metric Registry Entry"; req: metrics.
- `oidc-server-config` ($id relative) — req: provider, realm_id, clients, claims.
- `rendition-manifest` — req: application_name, renditions.
- `score-snapshot` — req: application_id, application_name, recorded_at, dimensions.
- `temporal-workflow-contract` ($id relative) — req: name, task_queue, activities. (props: signals, queries,
  deterministic_invariants.)
- `traceability-report` — req: application_name, coverage_percentage.
- `triage-digest` — "Error-Triage Digest"; req: incidents, new, recurring.

**data/** — all 6 share req: target_app_id, target_service_id, relationship, source_app_ids EXCEPT
`shared-db-analysis` (req: source_app_id, wave_id):
- `data-architecture`, `data-domains`, `data-migration-plan`, `data-product-design`, `decomposition-strategy`,
  `shared-db-analysis`. (These carry very wide property sets — full lists recoverable per file.)

**design/** (6, all $id relative, ALL EXCLUDED from validate.sh — FAA-domain design schemas):
- `8710-field-dependency-graph` — req: form_version, fields.
- `application-state-machine` — req: initial, states, transitions.
- `faa-pilot-cert-domain` — req: entities, migrations.
- `form-8710-rules` — req: form_variant, fields, dependencies.
- `medical-cert-class` — req: class, validity_periods, disqualifying_conditions, si_pathway, soda_pathway.
- `principal-mapping` — "JWT Claim → Principal Mapping"; req: principal_shape, claim_extractions.

**discovery/** (17)
- `analysis-report` — req: metadata, modernization_readiness_score.
- `application-catalog-entry` — req: application.
- `business-logic` — req: application_id, rules.
- `business-rule-inventory` — req: application, summary, rules.
- `capability-catalog` — req: application_id, legacy_system, business_domains, capabilities.
- `catalog` — "Application Catalog Entry"; req: application_id, tech_stack, architecture.
- `compliance-citations` — req: application, assessed_date, source_path, citations, summary.
- `data-flow-trace` — req: application, flows.
- `db-archaeology` — req: application, database_engine, schemas, tables, stored_procedures, triggers, findings.
- `discovery-synthesis` — req: application_id, summary.
- `eligibility-rule-engine` ($id relative) — req: rules.
- `identity-landscape` — req: portfolio_id, analyzed_date, identity_models, assurance_gaps,
  proliferation_findings.
- `mainframe-discovery` — req: application, platforms, findings.
- `quality-risk` — req: application_id, risk_summary.
- `tech-fingerprint` — req: application, technology.
- `tiff-corpus-assessment` — req: corpus_id, source_system, scale_estimate, sampling_strategy, ocr_readiness,
  metadata_inference_plan, migration_sequencing, cost_projection, risk_findings.
- `ux-accessibility` — req: application_id, ui_inventory, personas, accessibility_findings.

**dispositions/** (8)
- `disposition-output` — the bundle; req: application_id, application_name, portfolio_id, wave_id, disposition,
  status, started_at, completed_at, disposition_decision_ref, approvals, realized_net_impact, payload.
- `consolidate-output` — req: disposition, target_application, feature_gap_analysis_ref, features_ported,
  features_dropped, enhancement_plan_ref, data_reconciliation, user_migration_ref, absorbed_decommission_ref.
- `rearchitect-output` — req: disposition, modernized_repo_url, blueprint_ref, bounded_context_map_ref,
  generation_run_ref, parity_report_ref, test_coverage, deployment.
- `refactor-output` — req: disposition, modernized_repo_url, blueprint_ref, generation_run_ref,
  parity_report_ref, test_coverage, deployment.
- `replace-output` — req: disposition, selected_vendor, integration, data_migration, legacy_decommission_ref.
- `replatform-output` — req: disposition, target_platform, workflow_mapping_ref, component_configuration_ref,
  data_migration, validation_cutover_ref, legacy_decommission_ref, perf_delta, cost_delta.
- `retain-output` — req: disposition, retain_reason, remediation_outcome, sustainment_handoff,
  re_evaluation_triggers.
- `retire-output` — req: disposition, decommission_certificate_ref, archival, consumer_migration,
  license_reclamation_ref, infrastructure_torn_down.

**drift/** (1, NEW, EXCLUDED from validate.sh)
- `drift_report` — "Persisted Drift Report"; req: app_id, spec_artifact, profile_id, verdict, blocking_count,
  coverage_pct, in_sync, content_digest, findings. (Wire twin of `DriftReport` §5.5.)

**evidence/** (1, NEW, EXCLUDED from validate.sh)
- `evidence_record` — "Evidence Record CT-007/008 Envelope"; req: schema_version, classification,
  owner_scope_type, retention_policy.

**gates/** (3)
- `escalation-record` — req: id, type, severity, application_name, trigger, status.
- `gate-evidence-package` — req: gate_id, application_name, prepared_by, assembly_line, evidence_items.
- `gate-review-checklist` — req: gate_id, application_name, checklist_items.

**ingestion/** (2 schemas, NEW, EXCLUDED from validate.sh; ship with `.sample.json` twins)
- `ingestion-report` — req: app_id, obligations_total, low_confidence_count. (Wire twin of `IngestionReport` §5.4.)
- `reconstructed-spec` — req: app_id, source_root, obligations. (Wire twin of `ReconstructedSpec` §5.4.)

**modernization/** (7)
- `business-rules` — req: application, rules.
- `modern-requirements` ($id dev host) — req: metadata, requirements.
- `module-map` — req: application, contexts, context_map.
- `rule-reconciliation-matrix` ($id dev host) — req: metadata, reconciliation, summary.
- `test-scenarios` — req: application, scenarios.
- `ui-prototype` — req: prototype_type.
- `ux-flow-inventory` — req: target_app_id, flows.

**oscal/** (1, NEW, EXCLUDED from validate.sh)
- `assessment-results` — "OSCAL Assessment Results (run-scoped subset)"; req: assessment-results.

**profiles/** (8)
- `compliance` — req: compliance.
- `delegation` ($id dev host) — "DelegationPolicy"; req: fallback_policy.
- `gates` — req: gates.
- `lock-policy` ($id dev host) — "Layered Profile Lock Policy"; req: version, dimensions.
- `objectives` — "Agency Objectives"; req: version, objectives.
- `risk-classification` — req: risk_classification.
- `scoring` — req: scoring.
- `technology` — req: technology.

**rationalization/** (18)
- `business-rule-redundancy` — req: wave_id, summary, clusters.
- `capability-consolidation-plan` — req: metadata, capability_plans.
- `classification` — req: app_id, risk_tier, risk_confidence, risk_rationale, tier_1_flag, computed_at.
- `complexity-classification` — req: application, tier, classification_method, evidence, thresholds,
  dispatch_strategy.
- `disposition-governance` — req: schema_version, wave_id, application_id, disposition_summary,
  stakeholder_matrix, approval_tracking.
- `disposition-recommendation` — req: metadata, rationalization_capability_dispositions.
- `integration-graph` — req: metadata, systems, data_flows, shared_identifiers, cross_system_capabilities.
- `portfolio-score` — req: app_id, scores, overall_weighted, methodology_version, computed_at.
- `portfolio-target-state-rollup` — req: portfolio_id, computed_at, waves_included, waves_omitted, counts,
  disposition_mix, aggregate_net_impact.
- `rationalization-clustering-plan` ($id faa.gov host, `.json` suffix) — req: metadata,
  rationalization_capabilities, capability_assignments, capability_splits.
- `redundancy-matrix` — req: metadata, entity_overlap, operation_overlap.
- `shared-identity-report` — req: apps, cross_app_matches.
- `tco-analysis` — req: application_name, analyst, current_costs.
- `user-impact-analysis` — req: application_id, disposition, personas, disruption_profile,
  accessibility_regressions.
- `ux-overlap-matrix` — req: wave_id, personas, persona_task_matrix, swivel_chair_patterns,
  fragmented_journeys, pair_scores.
- `wave-outcome-synthesis` — req (16): wave_id, wave_number, wave_name, portfolio_id, synthesized_at,
  app_count, target_state_system_count, retired_count, consolidated_into_count, surviving_count,
  disposition_mix, estimated_net_impact, consolidated_capabilities_map, technology_simplification_score,
  narrative_target_state_architecture, source_artifact_refs.
- `wave-plan-validation` — req: wave_id, status, summary, errors, warnings.
- `wave-plan` — req: wave_id, apps, total_duration_days.

### 9.4 Samples — `schemas/samples/` (41 files) + `schemas/ingestion/*.sample.json` (2) + `schemas/compliance/samples/`
41 `*.sample.json` under `samples/` are instances used by `scripts/validate_schema_samples.py` for round-trip
validation. Each sample's `$schema` pointer is stripped before validation. Coverage requirement: every schema
must have ≥1 sample. Sample filenames mirror schema names (e.g. `redundancy-matrix.sample.json`,
`profile-scoring.sample.json`, `capability-result.sample.json`, `autonomy-policy.sample.json`,
`triage-digest.sample.json`, …).

---

## 10. Rebuild checklist (what must be byte-identical)
1. `enums.py`: 10 enum classes + `GATE_FRIENDLY_NAMES`/`GATE_ASSEMBLY_LINES` tables + `ASSURANCE_RANK` +
   2 helper fns + `AssemblyLineName` alias. `RiskTier` MUST be `IntEnum`; the rest `StrEnum`. `len(GateType)==18`;
   `len(AssemblyLine)==11` (no Reverse Engineering member).
2. `signals.py`: 3 dataclasses, **no `from __future__ import annotations`**, `Any` in `__all__`.
3. `git_types.py`/`errors.py`: `BRANCH_PATTERN` regex, 4 result dataclasses, `GitServiceError` + 3 merge
   subclasses with their exact mergeable_state → retryable mapping.
4. The 8 frozen `assembly_lines.py` dataclasses with EXACT golden field order (§8.2) + `frozen=True,slots=True`.
5. The loader's parse + `_load_all` invariants (skip `_`-prefixed/non-yaml; ValueError on missing name /
   duplicate; RuntimeError on empty).
6. All P7–P9 modules (§4, §5) with their tri-state / fail-closed / pure-transition semantics.
7. 12 assembly-line YAMLs (verbatim in `06b-assembly-line-contracts.md`).
8. 113 JSON schemas at their EXACT `$id` (honoring the host anomalies in §9.1), + validate.sh dir list
   (excluding design/drift/evidence/ingestion/oscal).
9. Both anti-drift tests (§8).
