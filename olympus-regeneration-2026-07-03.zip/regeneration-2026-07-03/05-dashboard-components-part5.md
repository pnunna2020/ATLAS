# 05 — Dashboard Components (Part 5): Artifact Viewers group (components/viewers/)

Continues Parts 1–4. Paths relative to `dashboard/src/components/viewers`.

The viewer library renders agent-produced artifacts "headline-first, reviewer-friendly" instead of raw
JSON. 46 viewer `.tsx` + 2 `.ts` (`ViewerRegistry.ts`, `ViewerProps.ts`) + `ViewerErrorBoundary.tsx`.

## Shared contract — ViewerProps.ts
```ts
interface ViewerProps { data: Record<string, unknown>; metadata: Record<string, unknown> | null; schemaVersion: string; }
```
Every viewer is a `ComponentType<ViewerProps>`. All viewers read `data` DEFENSIVELY (agent output is
untrusted / partial); missing optional fields degrade gracefully.

## ViewerRegistry.ts — the dispatch seam (LOAD-BEARING)
A `registry: Record<string, ComponentType<ViewerProps>>` mapping artifact-type strings (and common
filename-stem aliases) to viewers. `getViewerForType(artifactType)` = `registry[artifactType] ??
GenericStructuredViewer`.

`ArtifactViewer({artifactType, gateId?, appId?, ...props})` is the SOLE render entry point used by
GateReviewCard, ApplicationDetail Artifacts tab, DesignReview, and nl-console InlineArtifact:
- resolves `Viewer = registry[artifactType] ?? GenericStructuredViewer`;
- instruments dwell analytics via `useSectionDwell({artifactType, section:artifactType, gateId, appId})`
  (jsdom/IntersectionObserver-safe; swallows all errors — telemetry never breaks the viewer);
- wraps the resolved viewer in `<ViewerErrorBoundary artifactType data>` inside a
  `<div ref={dwellRef} className="artifact-viewer-dwell">`.

### The full registry map (artifact_type / alias → viewer)
GOTCHA: many `*_step` types deliberately route to `DiscoveryPassViewer` so the agent's `data.analysis`
markdown renders (headings/tables/Mermaid) rather than falling to GenericStructuredViewer's flat key-value
rendering (task #97). Both canonical types AND filename-stem aliases are registered for most gate artifacts.

- `discovery_analysis` → DiscoveryAnalysisViewer
- `discovery_pass` → DiscoveryPassViewer
- `rationalization_step`, `architecture_step`, `data_step`, `modernization_step`, `validation_step`,
  `deployment_step`, `disposition_execution_step`, `sustainment_step`, `governance_step` → **DiscoveryPassViewer**
- `file_artifact` → FileArtifactViewer
- `business_rules` → BusinessRulesViewer
- `test_scenarios` → TestScenariosViewer
- `module_map` → ModuleMapViewer
- `api_specification` → ApiSpecViewer
- `data_model` → DataModelViewer
- `compliance_map` → ComplianceMapViewer
- `test_results` → TestResultsViewer
- `security_scan` → SecurityScanViewer
- `accessibility_audit` → AccessibilityViewer
- `quality_risk` → QualityRiskViewer
- `gate_summary` → GateSummaryViewer
- `gate_finding` → GateFindingViewer
- `wave_plan` → WavePlanViewer
- `architecture_traceability` → ArchitectureTraceabilityViewer
- `integration_graph` → IntegrationGraphViewer
- `portfolio_manifest` → PortfolioManifestViewer
- `compliance_citations` → ComplianceCitationsViewer
- `ux_overlap_matrix` → UxOverlapViewer
- `business_rule_redundancy` → BusinessRuleRedundancyViewer
- `data_domain_model`, `data_domain` → DataDomainViewer
- `parity_report`, `parity_results` → ParityResultsViewer
- `compliance_certification`, `compliance_cert` → ComplianceCertViewer
- `safety_review_package`, `safety_assurance`, `safety_case` → SafetyAssuranceViewer
- `deployment_readiness` → DeploymentReadinessViewer
- `decomposition_strategy`, `"decomposition-strategy"` → DecompositionStrategyViewer
- `data_product_design`, `"data-product-design"`, `data_product` → DataProductViewer
- `parallel_run_report`, `"parallel-run-report"`, `parallel_run` → ParallelRunViewer
- `decommission_certificate`, `"decommission-certificate"`, `decommission` → DecommissionViewer
- `disposition_execution_plan`, `"disposition-execution-plan"`, `disposition_execution` → DispositionExecutionViewer
- `architecture_blueprint`, `"architecture-blueprint"`, `architecture_c4`, `c4_diagrams` → ArchitectureC4Viewer
- `data_flow_trace`, `"data-flow-trace"`, `data_flow` → DataFlowViewer
- `deployment_topology`, `"deployment-topology"` → DeploymentTopologyViewer
- `gate_history`, `"gate-history"`, `decision_history`, `decisions_timeline`, `gate_decision_log` → GateHistoryTimelineViewer
- `rule_reconciliation_matrix`, `"rule-reconciliation-matrix"`, `rule_reconciliation`, `comparative_rules` → ComparativeRulesViewer
- `parity_comparison`, `comparative_parity`, `behavioral_comparison` → ComparativeParityViewer
- `oscal_evidence`, `oscal_ssp`, `oscal_sar`, `oscal_poam`, `ssp`, `sar`, `poam`, `"system-security-plan"`,
  `"assessment-results"`, `"plan-of-action-and-milestones"` → OscalEvidenceViewer
- `ui_prototype`, `"ui-prototype"` → UiPrototypeViewer
- `design_review`, `"design-review"` → DesignReviewViewer
- `ux_flow_inventory`, `"ux-flow-inventory"` → UxFlowInventoryViewer
- `architecture_diagram`, `"architecture-diagram"` → ArchitectureDiagramViewer
- (anything unregistered) → GenericStructuredViewer

## ViewerErrorBoundary.tsx (default; class; exports Props; P5-S30.11)
Viewer-scoped error boundary (distinct from the section-scoped `ErrorBoundary`). Props `{children?,
artifactType?, data?, onCaught?}`. `getDerivedStateFromError` ⇒ `{hasError:true}`; `componentDidCatch`
console.errors (naming the `artifactType`) + calls `onCaught`. On error renders a slim error Alert "This
artifact could not be displayed" naming the type, plus `renderRawData()` — a `<details>` "Show raw artifact
data" with `JSON.stringify(data,null,2)`, double-guarded (`String(data)` fallback, then "(artifact data
could not be displayed)") so a circular/non-serializable payload can't throw a SECOND error inside the
fallback.

## GenericStructuredViewer.tsx (default) — the fallback
Renders arbitrary `data` as USWDS `Table` key-value pairs (508: proper th/td + aria). `MARKDOWN_KEYS =
{"analysis"}` (`:...`): a string value under `analysis` renders through `<AgentMarkdown>` (task #97 defense
— future `*_step` types that land here before the registry is updated still read well). `formatValue`
(null/undef → "N/A", strings raw, primitives stringified, else `JSON.stringify`), `isObject`,
`renderSection(key,value,depth)` recurses arrays/objects with indentation.

---

## The individual viewers

All accept `ViewerProps` (`{data, metadata, schemaVersion}`), read fields defensively, and surface the
decision-critical headline first with supporting tables below. Grouped by concern.

### Agent-output / Discovery
- **DiscoveryPassViewer** — a single Discovery/step pass: renders `data.analysis` as markdown via
  react-markdown, plus execution metadata (model, duration, token usage). The catch-all for every `*_step`
  artifact.
- **DiscoveryAnalysisViewer** — the aggregate discovery analysis artifact.
- **QualityRiskViewer** — `quality-risk.json` from `quality-risk-assessor` (Discovery Pass 3); quality +
  risk evidence.
- **FileArtifactViewer** — a raw committed file artifact (path + content, syntax-aware where possible).

### Business rules / modernization
- **BusinessRulesViewer** — extracted legacy business rules.
- **TestScenariosViewer** — extracted/derived test scenarios.
- **ModuleMapViewer** — module/component map.
- **ComparativeRulesViewer** — legacy BR → modern REQ rule-reconciliation matrix (disposition per rule).

### Architecture / data / API
- **ApiSpecViewer** — OpenAPI endpoints table with method badges (GET/POST/PUT/DELETE), path, description;
  searchable + expandable request/response details.
- **DataModelViewer** — target data model (entities/relations).
- **DataDomainViewer** — data domain model (G-DT); domain decomposition.
- **DataProductViewer** — data-product-design (G-DT step 5).
- **DataFlowViewer** — data-flow-trace (entry → transform → persist → exit + PII).
- **DecompositionStrategyViewer** — decomposition-strategy (G-DT step 3).
- **ArchitectureTraceabilityViewer** — architecture traceability (design element → approved rule).
- **ArchitectureC4Viewer** — architecture-blueprint `c4_diagrams[]` rendered as Mermaid (G-04b).
- **ArchitectureDiagramViewer** — freeform architecture diagram: Mermaid → `<MermaidBlock>`, PlantUML string,
  or DOMPurified SVG blob (the long tail; does NOT replace the topology-specific viewers). P6-S9.5.
- **IntegrationGraphViewer** — integration graph between services.
- **ModuleMapViewer** — (see above).
- **DeploymentTopologyViewer** — deployment-topology (compute/network/scaling/env/CI-CD/IaC).
- **PortfolioManifestViewer** — portfolio manifest.

### Validation / parity / compliance / safety
- **ParityResultsViewer** — Behavioral Parity Report (G-V1). Surfaces headline `result` (PASS/FAIL),
  `parity_score`%, scenario counts, per-suite test rows, and the `critical_divergences` list FIRST (go/no-go
  at a glance). Registered for `parity_report`/`parity_results`.
- **ComparativeParityViewer** — scenario-level parity diff (legacy vs modernized side-by-side); complements
  the go/no-go rollup rather than duplicating it.
- **ComplianceCertViewer** — compliance certification (G-V2).
- **ComplianceMapViewer** — compliance control map.
- **ComplianceCitationsViewer** — structured compliance citations.
- **SafetyAssuranceViewer** — safety-review-package / safety case (G-V3, Tier 1).
- **SecurityScanViewer** — security scan findings.
- **AccessibilityViewer** — accessibility audit findings.
- **TestResultsViewer** — test execution results.
- **OscalEvidenceViewer** — OSCAL 1.1.2 SSP/SAR/POA&M (P6-S8.9): system characteristics, per-control
  implementation status + evidence citations, and POA&M items (owner/milestone/risk) — NOT raw JSON; a
  collapsible raw-JSON escape hatch always present. Reused in G-V1/V2/V3 cards + CatoEvidence page.

### Deployment / disposition / sustainment
- **DeploymentReadinessViewer** — deployment-readiness (G-DP-1).
- **ParallelRunViewer** — parallel-run-report (cutover monitoring).
- **DecommissionViewer** — decommission-certificate (G-DE-2).
- **DispositionExecutionViewer** — disposition-execution plan (G-DE-1).

### Gate-review helpers
- **GateSummaryViewer** — generic gate-evidence summary (findings + recommendations shape, non-Discovery/
  non-Rationalization gates; see `gate.py::_build_generic_findings_artifacts`).
- **GateFindingViewer** — a single generic gate finding.
- **GateHistoryTimelineViewer** — the ViewerProps form of ApplicationDetail's DecisionsTimeline: renders
  `data.entries[]` (decision/escalation/rework) as a reverse-chronological, kind-filterable, expandable
  audit-trail timeline.

### Rationalization / wave
- **WavePlanViewer** — wave-plan artifact.
- **BusinessRuleRedundancyViewer** — cross-app business-rule semantic clusters
  (`business-rule-redundancy.json` from `cross-app-business-rule-analyzer`, ATLAS T2.6).
- **UxOverlapViewer** — UX overlap matrix.

### Design review (Phase 6 W9)
- **UiPrototypeViewer** — a generated clickable UI prototype. SECURITY (marquee property): the
  agent-generated HTML is UNTRUSTED and rendered in a sandboxed `<iframe>` served from a `blob:` URL (opaque
  origin, distinct from the platform origin) — so embedded `<script>`/SVG/CSS can't reach the platform.
- **DesignReviewViewer** — design-review.json F3 threshold-metrics table.
- **UxFlowInventoryViewer** — flow picker + step list + per-flow Mermaid.

---

## Verification of coverage

Page-dirs (35 total under `pages/`; the prompt said 34 pre-count — the NEW `nl-console` makes 35):
`AboutOverview, Admin, Analytics, ApplicationDetail, Applications,
AssemblyLines, Auth, BuildProgress, CapabilityLineage, Compliance, DemoColdOpen, DesignReview, Escalations,
GateQueue, GateReview, GettingStarted, Interview, MyBundles, MyTasks, OneStopShopDemo, PortfolioOverview,
RedundancyMatrix, ScopedLineLaunch, ScoringHeatMap, Skills, TargetArchitecture, Traceability, WaveDetail,
Waves, autonomy-ops, catalog, delegation-management, evidence-ledger, feedback, nl-console`. THIS doc set
covers 22 of them (the assigned "remaining" groups + the two NEW consoles); the other 12 (Admin, Analytics,
ApplicationDetail, Applications, AssemblyLines, Compliance, MyBundles, MyTasks, PortfolioOverview, Skills,
Traceability, WaveDetail, Waves) are in the two sibling dashboard docs. Also present at `pages/` root (not
dirs): `NotFound.tsx`, `PlaceholderPage.tsx`.

Component-dirs (56 total under `components/`, matching the `find components -type d` list minus `__tests__`/
`hooks`/`charts`/`viewers` wrappers): every component dir is covered across Parts 2–5 —
`ActorKindBadge, AgentActivityByLine, ApplicationOnboardingForm, AssemblyLinePipeline, BuildLineProgress,
CancelAllChildrenButton, CapabilityClusterSummary, CapabilitySystemCallout, Chat, ComplianceDashboard,
ConsolidatedBanner, CreateModal, DemoModeIndicator, EmptyState, ErrorBoundary, FanOutStatusTable,
GateCardList, GateReview, GateReviewCards, Glossary, Insights, Layout, LineAnatomy, LineageBadge, Markdown,
ModelUsageChart, MoveToWaveDialog, MyTasksSummaryCard, NeedsMyAttention, OnboardingCarousel, OnboardingWizard,
PendingGatesQueue, PhaseRibbon, PipelineNodeGraph, PreDispatchPanel, ProfileBundleModal, RenditionsDownloadMenu,
SkillDispatchExplorer, StaleArtifactsCard, Tier1ApprovalPanel, TraceId, TraceabilityExplorer,
WaveBusinessRuleOverlap, WaveGateDecisions, WavePerformanceReport, WavePlanEmbed, WaveRecoveryBanner,
WaveRoadmap, WaveSynthesis, WaveWorkflowProgress, WorkflowControl, WorkflowFailureBanner, WorkflowRoutingDialog,
WorkflowStepper, charts, viewers` — plus the top-level flat files `ActiveProfileBadge, ApplicationDispositionChips,
DataGrid, PortfolioPicker, RequireAuth, ScoreBar, StatusBadge, TabNav, ThemeToggle`.

## EmptyState/EmptyState.tsx (default; exports `EmptyStateIcon`, `EmptyStateAction`, `EmptyStateProps`)
The shared empty-state block (P3.5-O.3) used by autonomy-ops, CapabilityLineage, TargetArchitecture,
evidence-ledger, etc. `EmptyStateIcon` = applications|gates|waves|escalations|artifacts|analytics|agents|
traceability|generic. `EmptyStateAction = {label, onClick, variant?, disabled?}`. Props: `{icon?=("generic"|
ReactNode), headline, body?, primaryAction?, secondaryAction?, compact?=false, headingLevel?="h2"|"h3"|"h4"
(default "h2" — nests one level below the page `<h1>` to satisfy axe heading-order), className?,
data-testid?}`. `IconFor` renders the inline glyph for a string icon; renders `role="status"` with optional
illustration + headline (`HeadlineTag`) + body + up to two CTA `Button`s.
