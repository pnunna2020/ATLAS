# 04 — Data Layer (Part 3 of 3): Capability, Governance, Evidence, Drift, Catalog, Eval, Feedback, Signals

> Conventions per Part 2. All CHECK value sets are given **in full** (these are the
> "varchar+CHECK flexibility" columns). Cite migration in header.

---

## 1. Capability / system grain (`050`)

### system
`id` UUID PK; `portfolio_id` UUID FK→portfolio **CASCADE**; `name` String(255) NOT
NULL; `description` Text; `kind` String(32) NOT NULL (CHECK `system_kind_chk` =
`kind IN ('legacy','target','mixed')`); `external_id` String(64) (S1..S11 / IACRA /
RMS / MSS / DMS); `created_at`/`updated_at`/`retired_at`. Indexes: `ix_system_portfolio`,
partial unique `ix_system_portfolio_external_id (portfolio_id, external_id) WHERE
external_id IS NOT NULL`.

### system_application
`system_id` UUID FK→system **CASCADE**; `application_id` UUID FK→application
**CASCADE**; `role` String(32) NOT NULL DEFAULT `primary` (CHECK
`system_application_role_chk` = `role IN ('primary','contributing','deprecated')`);
`created_at`. PK `(system_id, application_id)`. Index on application_id.

### capability
`id` UUID PK; `system_id` UUID FK→system **CASCADE**; `name` String(255) NOT NULL;
`description` Text; `external_id` String(64) (M1..M19); `kind` String(32) NOT NULL
DEFAULT `legacy` (CHECK `capability_kind_chk` = `kind IN
('legacy','derived','net_new')`); `primary_disposition` String(32) (CHECK
`capability_primary_disposition_chk` = `IS NULL OR IN
('Retire','Retain','Refactor','Rearchitect','Replace','Replatform','Consolidate')`);
`secondary_disposition` String(32) (CHECK `capability_secondary_disposition_chk`, same
7-value set); `created_at`/`updated_at`/`retired_at`.
Added (052): `rationalization_capability_id` UUID FK→rationalization_capability **SET
NULL**; `parent_capability_id` UUID FK→capability **CASCADE** (split support);
`split_at` TIMESTAMPTZ.
Indexes: `ix_capability_system`, partial unique `(system_id, external_id) WHERE
external_id IS NOT NULL`, `ix_capability_rat_cap`, `ix_capability_parent`.

### business_domain
`id` UUID PK; `system_id` UUID FK→system **CASCADE**; `name` String(255) NOT NULL;
`description` Text; `external_id` String(64); timestamps + `retired_at`. Indexes:
`ix_business_domain_system`, partial unique `(system_id, external_id) WHERE external_id
IS NOT NULL`.

### capability_business_domain (N:M)
`capability_id` FK→capability **CASCADE**, `business_domain_id` FK→business_domain
**CASCADE**. PK `(capability_id, business_domain_id)`. Index on business_domain_id.

### capability_lineage
`id` UUID PK; `target_capability_id` UUID FK→capability **CASCADE** (nullable — NULL
only when relationship='dropped'); `source_capability_id` UUID FK→capability
**CASCADE** NOT NULL; `relationship` String(32) NOT NULL; `notes` Text; `confidence`
Numeric(3,2); `agent_emitted` Boolean NOT NULL DEFAULT false; `ratified_by`
String(255); `ratified_at`; `created_at`; `retired_at`.
UNIQUE `(target_capability_id, source_capability_id)`. CHECKs:
`capability_lineage_relationship_chk` = `relationship IN
('absorbed','partial','transformed','dropped')`; `capability_lineage_target_chk` =
`(relationship='dropped' AND target_capability_id IS NULL) OR (relationship<>'dropped'
AND target_capability_id IS NOT NULL)`; `capability_lineage_confidence_chk` =
`confidence IS NULL OR (confidence >= 0 AND confidence <= 1)`. Indexes on target, source.

### business_domain_lineage
Same shape at domain grain. `target_business_domain_id` (nullable),
`source_business_domain_id` (NOT NULL) FK→business_domain **CASCADE**; relationship
String(32); notes; confidence Numeric(3,2); agent_emitted; ratified_by/at; created_at;
retired_at. UNIQUE `(target, source)`. CHECK
`business_domain_lineage_relationship_chk` = same 4-value set;
`business_domain_lineage_target_chk` = dropped⇔target NULL.

### system_lineage
`target_system_id` FK→system **CASCADE**, `source_system_id` FK→system **CASCADE**,
`relationship` String(32) NOT NULL, `created_at`, `retired_at`. PK `(target, source)`.
CHECK `system_lineage_relationship_chk` = `relationship IN
('consolidate','rearchitect-of','replace','retire')`. Index on source.

### agent_task_session_artifact
`id` UUID PK; `agent_task_id` UUID FK→agent_task **CASCADE**; `kind` String(32) NOT
NULL (CHECK = `kind IN ('transcript','prompt','diff','summary')`); `artifact_ref` Text
NOT NULL; `hash` String(64) (SHA-256); `captured_at`. Index on agent_task_id.

### rationalization_capability (`052`)
`id` UUID PK; `portfolio_id` UUID FK→portfolio **CASCADE**; `wave_id` UUID FK→wave
**SET NULL** (nullable); `external_id` String(64); `name` String(255) NOT NULL;
`description` Text NOT NULL; `rationale` Text NOT NULL; `evidence_refs` JSONB NOT NULL
(shape `[{capability_id, application_id, application_name, capability_name,
citation}]`); `confidence` Numeric(3,2) (CHECK
`rationalization_capability_confidence_chk`, 0..1); `disposition` String(64) (CHECK
`rationalization_capability_disposition_chk` = `IS NULL OR IN (<7 dispositions>)`);
`target_service_external_id` String(64); `created_at`/`updated_at`/`retired_at`.
Indexes: `ix_rat_cap_portfolio`, `ix_rat_cap_wave`, partial unique
`(portfolio_id, external_id) WHERE external_id IS NOT NULL AND retired_at IS NULL`,
partial unique `(portfolio_id, name) WHERE retired_at IS NULL`.

### application_disposition VIEW (`058`) — see Part 1 §5.5.

---

## 2. Delegation / bundle

### delegated_bundle (`057`)
`id` UUID PK; `portfolio_id` UUID FK→portfolio; `application_id` UUID FK→application
(nullable); `wave_id` UUID FK→wave (nullable); `scope_kind` String(32) NOT NULL
(CHECK `chk_bundle_scope_kind` = `IN ('gate_packet','line_step')`); `target_id`
String(128) NOT NULL; `status` String(32) NOT NULL DEFAULT `offered` (CHECK
`chk_bundle_status` = `IN ('offered','claimed','submitted','accepted','rejected',
'expired','released')`); `claimed_by_user_id` String(255); `claimed_at`/`expires_at`/
`submitted_at`/`accepted_at` TIMESTAMP; `local_agent_descriptor` JSONB;
`fallback_policy` String(32) NOT NULL DEFAULT `internal_fallback` (CHECK
`chk_bundle_fallback` = `IN ('internal_fallback','escalate','fail','redispatch')`);
`created_by_user_id` String(255) NOT NULL; `created_at`/`updated_at`;
`dispatching_workflow_id` String(255) (**063**).
Additional CHECKs: `chk_bundle_app_or_wave` = `(application_id IS NOT NULL) OR (wave_id
IS NOT NULL)`; `chk_bundle_claim_consistency` = `(status='offered' AND claimed_by_user_id
IS NULL AND claimed_at IS NULL) OR (status IN
('claimed','submitted','accepted','rejected','released') AND claimed_by_user_id IS NOT
NULL AND claimed_at IS NOT NULL) OR (status='expired')`.
Indexes: `(portfolio_id, status)`, application_id, wave_id, claimed_by,
dispatching_workflow_id.

### delegated_bundle_input_ref (`057`)
`id` UUID PK; `bundle_id` FK→delegated_bundle **CASCADE**; `artifact_kind` String(64)
NOT NULL; `artifact_ref` Text NOT NULL; `description` Text. UNIQUE `(bundle_id,
artifact_ref)`. Index on bundle_id.

### delegated_bundle_output_ref (`057`)
`id` UUID PK; `bundle_id` FK **CASCADE**; `artifact_kind` String(64) NOT NULL;
`schema_ref` Text NOT NULL; `required` Boolean NOT NULL DEFAULT TRUE; `description`
Text; `submitted_artifact_ref` Text; `submitted_at` TIMESTAMP. UNIQUE `(bundle_id,
artifact_kind)`. Index on bundle_id.

### delegated_bundle_session_artifact (`057`)
`id` UUID PK; `bundle_id` FK **CASCADE**; `kind` String(32) NOT NULL (CHECK
`chk_bundle_session_kind` = `IN ('transcript','prompt','diff','summary')`);
`artifact_ref` Text NOT NULL; `hash` String(64); `captured_at`. Index on bundle_id.

### delegated_bundle_validation_history (`057`)
`id` UUID PK; `bundle_id` FK **CASCADE**; `submitted_at` TIMESTAMP DEFAULT now();
`submitted_by` String(255) NOT NULL; `outcome` String(32) NOT NULL (CHECK
`chk_bundle_validation_outcome` = `IN ('accepted','rejected')`); `violations` JSONB.
Index `(bundle_id, submitted_at)`.

### delegation_grant (`080`)
`id` UUID PK; `grantor` Text NOT NULL; `agent_id` Text NOT NULL; `scope` JSONB NOT
NULL DEFAULT `'{}'::jsonb` (shape `{"allowed_actions":[…],"portfolio_ids":[…]}`);
`scope_hash` Text; `status` Text NOT NULL DEFAULT `active` (CHECK
`ck_delegation_grant_status` = `IN ('active','revoked','expired')`); `created_at`;
`expires_at`; `revoked_at`. Index `(grantor, status)`.

---

## 3. Evidence / control (`072`, `083`)

### evidence_record (`072`)
`id` UUID PK; `portfolio_id` UUID FK→portfolio **CASCADE**; `application_id` UUID
FK→application **CASCADE**; `control_id` String(32) NOT NULL; `family` String(8);
`status` String(20) NOT NULL DEFAULT `unknown`; `content_hash` String(71) (`sha256:<64
hex>`) **UNIQUE** (`uq_evidence_record_content_hash`); `evidence_payload` JSONB;
`prev_hash` String(71); `assessed_at_gate` String(32); `assessed_by_skill`
String(128); `risk_tier` Integer; `inherited_from` String(128); `last_assessed`
TIMESTAMPTZ; `ratified` Boolean NOT NULL DEFAULT false; `ratified_by` String(255);
`ratified_at` TIMESTAMPTZ; `superseded_by` UUID FK→evidence_record **SET NULL**;
`recorded_at` TIMESTAMPTZ.
CHECKs: `ck_evidence_record_hash_prefix` = `content_hash LIKE 'sha256:%'`;
`ck_evidence_record_hash_length` = `char_length(content_hash) = 71`.
Indexes: `(portfolio_id, application_id, control_id, recorded_at)`,
`(portfolio_id, recorded_at)`.
Added (078): `producing_skill` String(150). Added (081): `assurance_level`
String(16). Added (083): `schema_version` String(32) DEFAULT `'1.0'`; `classification`
String(32) DEFAULT `'unclassified'`; `owner_scope` Text; `owner_scope_type`
String(32) DEFAULT `'portfolio'`; `retention_policy` String(32) DEFAULT `'standard'`;
`profile_id` Text; `profile_schema_version` String(32).

### control_mapping (`083`)
`id` UUID PK; `evidence_record_id` UUID FK→evidence_record **CASCADE**; `catalog_id`
String(64) NOT NULL; `control_id` String(64) NOT NULL; `status` String(16) NOT NULL
DEFAULT `proposed` (CHECK `ck_control_mapping_status` = `IN
('proposed','active','dangling')`); `ratified` Boolean NOT NULL DEFAULT false;
`created_at`. Indexes: on evidence_record_id, `(catalog_id, control_id)`.

### control_ratification (`083`)
`id` UUID PK; `catalog_id` String(64) NOT NULL; `control_id` String(64) NOT NULL;
`ratified_by` String(255); `ratified_at` TIMESTAMPTZ DEFAULT now(). UNIQUE
`(catalog_id, control_id)` = `uq_control_ratification_key`.

### evidence_suppression (`083`)
`id` UUID PK; `subject_kind` String(16) NOT NULL (CHECK
`ck_evidence_suppression_kind` = `IN ('gate','side_effect')`); `subject_id` Text NOT
NULL; `reason` Text; `created_at`. UNIQUE `(subject_kind, subject_id)`.

---

## 4. Drift (`084`, `085`)

### drift_report (`084`)
`id` UUID PK; `app_id` String(128) NOT NULL; `spec_artifact` String(512) NOT NULL;
`profile_id` String(128) NOT NULL; `verdict` String(8) NOT NULL (CHECK
`ck_drift_report_verdict` = `IN ('pass','fail')`); `blocking_count` Integer NOT NULL
DEFAULT 0; `coverage_pct` Numeric(7,4) DEFAULT 100.0; `in_sync` Boolean DEFAULT true;
`content_digest` String(71) (CHECK `ck_drift_report_digest_prefix` = `content_digest
LIKE 'sha256:%'`); `findings` JSONB DEFAULT `'[]'`; `proposed_diff` JSONB;
`evidence_content_hash` String(71); `recorded_at` TIMESTAMPTZ.
UNIQUE `(app_id, content_digest)` = `uq_drift_report_app_digest`. Indexes:
`(spec_artifact, recorded_at)`, `(app_id, recorded_at)`.

### drift_reconcile_item (`084`)
`id` UUID PK; `drift_report_id` UUID FK→drift_report **CASCADE**; `app_id` String(128)
NOT NULL; `spec_artifact` String(512) NOT NULL; `severity` String(16); `direction`
String(16); `summary` Text; `status` String(16) NOT NULL DEFAULT `open` (CHECK
`ck_drift_reconcile_item_status` = `IN ('open','resolved')`); `created_at`. Index on
report.

### drift_control_block (`085`)
`id` UUID PK; `disposition_id` String(256) NOT NULL **UNIQUE**
(`uq_drift_control_block_disposition`); `app_id` String(128) NOT NULL; `profile_id`
String(128); `action` String(16) NOT NULL DEFAULT `block` (CHECK
`ck_drift_control_block_action` = `IN ('advisory','at_risk','block')`); `status`
String(16) NOT NULL DEFAULT `blocked` (CHECK `ck_drift_control_block_status` = `IN
('blocked','risk_accepted','reconciled')`); `triggering_severity` String(16);
`coverage_regressed` Boolean DEFAULT false; `reasons` JSONB DEFAULT `'[]'`; `actor`
String(256); `reason` Text; `evidence_content_hash` String(71); `accepted_at`;
`recorded_at`. Indexes: `(app_id, recorded_at)`, `(status)`.

---

## 5. Intent / decomposition (`086`, `087`)

### intent_record (`086`)
`id` UUID PK; `intent_id` String(128) NOT NULL **UNIQUE**; `app_id` String(128);
`portfolio_id` String(128); `statement` Text NOT NULL; `derived_requirements` JSONB
DEFAULT `'[]'`; `status` String(16) NOT NULL DEFAULT `draft` (CHECK
`ck_intent_record_status` = `IN ('draft','confirmed','rejected')`); `actor`
String(256); `intent_metadata` JSONB DEFAULT `'{}'`; `created_at`/`updated_at`.
Indexes: `(app_id, created_at)`, `(portfolio_id, created_at)`.

### decomp_hierarchy (`087`)
`id` UUID PK; `application_id` String(128) NOT NULL; `intent_ref` String(256);
`profile_id` String(128); `gate_status` String(16) NOT NULL DEFAULT `open` (CHECK
`ck_decomp_hierarchy_gate_status` = `IN ('open','approved','rejected')`);
`content_digest` String(71); `payload` JSONB DEFAULT `'{}'`; `recorded_at`.
UNIQUE `(application_id, intent_ref, content_digest)` = `uq_decomp_hierarchy_identity`.
Index `(application_id, recorded_at)`.

### decomp_node_review (`087`)
`id` UUID PK; `hierarchy_id` UUID FK→decomp_hierarchy **CASCADE**; `node_id`
String(16) NOT NULL; `decision` String(16) NOT NULL DEFAULT `pending` (CHECK
`ck_decomp_node_review_decision` = `IN ('pending','approved','rejected')`);
`decided_by` String(256); `rationale` Text; `decided_at`. UNIQUE `(hierarchy_id,
node_id)`. Index on hierarchy_id.

---

## 6. Reusable-parts catalog (`070`, `089`)

### catalog_entry (`070`)
`id` UUID PK; `part_id` String(150) NOT NULL; `version` String(64) NOT NULL; `name`
Text NOT NULL; `kind` String(32) NOT NULL (CHECK `catalog_entry_kind_ck` = `IN
('service','library','iac-module','agent','workflow','ui-component','dataset')`);
`summary` Text DEFAULT `''`; `source_repo` Text; `source_ref` String(255); `status`
String(16) NOT NULL DEFAULT `draft` (CHECK `catalog_entry_status_ck` = `IN
('draft','in_review','published','deprecated')`); `tags` JSONB DEFAULT `'[]'`;
`published_at`; `created_by` String(255); `created_at`/`updated_at`. UNIQUE `(part_id,
version)`. Indexes: status, kind, part_id.
Added (089): `profile_id` String(128); `owner_scope` String(24) DEFAULT
`'tenant_private'` (CHECK `catalog_entry_owner_scope_ck` = `IN
('tenant_private','firm_wide','contract_spec')`); `classification` String(64);
`evidence_posture` String(32); `eval_status` String(16) DEFAULT `'absent'` (CHECK
`catalog_entry_eval_status_ck` = `IN ('current','stale','absent')`);
`eval_evaluated_at` TIMESTAMPTZ; `control_coverage` JSONB DEFAULT `'[]'`. Indexes on
owner_scope, eval_status.

### security_review_record (`070`)
`id` UUID PK; `catalog_entry_id` UUID FK→catalog_entry **CASCADE**; `decision`
String(24) NOT NULL (CHECK `security_review_decision_ck` = `IN
('approved','rejected','changes-requested')`); `scanners_run` JSONB NOT NULL DEFAULT
`'[]'`; `blocking_findings` Integer NOT NULL DEFAULT 0 (CHECK
`security_review_blocking_nonneg_ck` ≥ 0); `reviewed_by` String(255) NOT NULL;
`reviewer_role` String(64); `notes` Text; `reviewed_at`. Index on catalog_entry_id.

### catalog_consumer (`089`)
`id` UUID PK; `part_id` String(150) NOT NULL; `target_profile` String(128) NOT NULL;
`consumed_version` String(64); `last_notified_version` String(64); `consumed_by`
String(255); `consumed_at` TIMESTAMPTZ DEFAULT now(); `notified_at`. UNIQUE `(part_id,
target_profile)`. Indexes on part_id, target_profile.

---

## 7. Eval (`068`, `090`)

### eval_result (`068`)
`eval_case_id` String(255) (PK part); `model_id` String(255) (PK part); `gate_type`
String(20); `portfolio_id` UUID; `ai_verdict` String(32); `ground_truth_verdict`
String(32); `agreed` Boolean; `confidence_score` Integer; `scored_at` TIMESTAMPTZ
DEFAULT now(). Indexes on model_id, portfolio_id.

### eval_run (`090`)
Composite PK `(eval_case_id, model_id, run_id)`: `eval_case_id` String(255), `model_id`
String(255), `run_id` String(64) all PK; `case_version` String(64); `criterion` Text;
`passed` Boolean; `ai_verdict` String(32); `ground_truth_verdict` String(32);
`gate_type` String(20); `portfolio_id` UUID; `confidence_score` Integer; `run_at`
TIMESTAMPTZ DEFAULT now(). Indexes: `(eval_case_id, model_id)`, model_id, portfolio_id.

---

## 8. Feedback (`071`, `088`)

### feedback_item (`071`)
`id` UUID PK; `source_type` String(32) NOT NULL; `source_id` UUID (nullable);
`signature` String(255) NOT NULL; `title` String(512) NOT NULL; `severity` String(16)
NOT NULL; `status` String(32) NOT NULL DEFAULT `pending_review`; `occurrence_count`
Integer NOT NULL DEFAULT 1; `app_id` UUID FK→application **SET NULL**; `portfolio_id`
UUID; `detail` JSONB; `reviewed_by` String(255); `reviewed_at`; `promotion_ref`
String(512); `dismiss_reason` Text; `created_at`/`updated_at`.
UNIQUE `(source_type, source_id)` = `uq_feedback_item_source`. Indexes:
`ix_feedback_item_signature`, partial unique `uq_feedback_item_pending_signature
(signature)` (pending-review only), `(status, created_at)`.
Added (088): `classification` String(64); `closure_ref` String(512); `escalated_from`
(UUID/ref).

### feedback_work_order (`088`)
`id` UUID PK; `feedback_id` UUID FK→feedback_item **CASCADE**; `line` String(64) NOT
NULL; `app_id` UUID (nullable); `workflow_id` String(255); `status` String(32) NOT
NULL DEFAULT `generated` (CHECK `ck_feedback_work_order_status` = `IN
('generated','completed')`); `outcome` JSONB; `created_by` String(255); `created_at`;
`completed_at`. UNIQUE `(feedback_id)` = `uq_feedback_work_order_feedback`. Indexes:
on feedback_id, `(status, created_at)`.

### feedback_ingest_cursor (`088`)
`source_type` String(32) **PK** (values: `escalation | sustainment_finding`);
`last_ingested_at` TIMESTAMPTZ (high-water mark); `updated_at`.

---

## 9. Signals / capture (`091`)

### error_signal (`091`)
`id` UUID PK; `source` String(64) NOT NULL; `source_row_id` String(255) NOT NULL;
`service` String(255) DEFAULT `''`; `error_class` String(255) DEFAULT `''`; `message`
Text DEFAULT `''`; `trace_id` String(128); `occurred_at` TIMESTAMPTZ; `profile_id`
String(150); `captured_at` TIMESTAMPTZ DEFAULT now(). UNIQUE `(source, source_row_id)`
= `uq_error_signal_source_row`. Indexes on profile_id, service. **No CHECK
constraints** (free varchar).

### incident_signal (`091`)
`id` UUID PK; `fingerprint` String(128) NOT NULL **UNIQUE**
(`uq_incident_signal_fingerprint`); `service` String(255) DEFAULT `''`; `error_class`
String(255) DEFAULT `''`; `occurrence_count` Integer DEFAULT 0; `first_seen`/`last_seen`
TIMESTAMPTZ; `profile_id` String(150); `triage_decision` String(32); `requested_level`
String(32); `evidence_ref` String(255); `status` String(16) DEFAULT `open`;
`captured_at` TIMESTAMPTZ DEFAULT now(). Index on profile_id. (No CHECK.)

### capture_watermark (`091`)
`source` String(64) **PK** (capture-source token); `watermark` String(255) NOT NULL
DEFAULT `''` (last-processed source_row_id, advanced MONOTONICALLY); `updated_at`
TIMESTAMPTZ DEFAULT now().

---

## 10. Remaining tables

| Table (migration) | Key columns / notes |
|---|---|
| **arch_data_signal_registry** (046) | `id` UUID PK; `wave_id` UUID NOT NULL; `target_app_id` UUID NOT NULL; `signal_type` Text NOT NULL; `payload` JSONB NOT NULL; `created_at` TIMESTAMPTZ; `consumed_at` TIMESTAMPTZ; `consumed_by_workflow_id` Text. UNIQUE `(wave_id, target_app_id, signal_type)` = `arch_data_signal_registry_scope_uk`. |
| **workflow_signal_inbox** (048) | `id` UUID PK; `workflow_id` String(255) NOT NULL; `signal_name` String(255) NOT NULL; `payload` JSONB; `status` (CHECK `workflow_signal_inbox_status_ck` = `IN ('pending','sent','queued','consumed','failed')`); `created_at`; `consumed_at`. Indexes: workflow_id, partial `(workflow_id, created_at) WHERE status IN ('pending','sent','queued')`. |
| **skill_metrics** (060) | `skill_id` String(150) **PK**; `invocations_total` Integer NOT NULL DEFAULT 0; `gate_pass_rate` Numeric(5,4); `avg_quality_score` Numeric(3,2); `updated_at` TIMESTAMPTZ DEFAULT now(). |
| **viewer_event** (061) | `id` UUID PK; `artifact_type` String(150) NOT NULL; `section` String(200); `gate_id`; `app_id`; `dwell_ms` Integer; `occurred_at` TIMESTAMPTZ DEFAULT now(). Indexes: artifact_type, `(artifact_type, section)`. |
| **gate_approval** (062) | `id` UUID PK; `gate_id` UUID FK→gate **CASCADE**; `approved_by` String(255) NOT NULL; `approver_role` String(64); `is_oversight` Boolean DEFAULT false; `is_management_override` Boolean DEFAULT false; `justification` Text; `approved_at` TIMESTAMPTZ DEFAULT now(). UNIQUE `(gate_id, approved_by)` = `uq_gate_approval_gate_user`. Index on gate_id. |
| **design_annotation** (065) | `id` UUID PK; `app_id` UUID FK→application **CASCADE**; `artifact_id` String(512) NOT NULL; `artifact_type` Text NOT NULL; `skill_id` Text; `annotation_text` Text; `action` Text NOT NULL (CHECK `design_annotation_action_ck` = `IN ('flag_for_revision','mark_reviewed','note_only')`; CHECK `design_annotation_text_nonempty_ck`); `reviewer_id` String(255) NOT NULL; `feedback_sent_at`; timestamps. Indexes: app_id, artifact_id. |
| **interview_session** (066) | `id` UUID PK; `app_id` UUID FK→application **CASCADE**; `portfolio_id` UUID FK→portfolio **CASCADE**; `workflow_id` String(255); `stakeholder_name`/`role` Text; `status` Text DEFAULT `active` (CHECK `IN ('active','completed','expired')`); `phase` Integer DEFAULT 1 (CHECK `phase >= 1 AND phase <= 5`); `transcript` JSONB DEFAULT `'[]'` (list of `{question_id, phase, question, answer}`); `partial_artifact` JSONB DEFAULT `'{}'`; `created_by`; timestamps; `expires_at`; `completed_at`. Indexes: app_id, status. |
| **eval_result / eval_run** | §7 above. |
| **ai_work_log** (069) | `id` UUID PK; `agent_task_id` UUID; `skill_id` String(150); `outcome` String(32); `payload` JSONB; `created_at`. `producing_skill` String(150) added (078). Indexes: agent_task_id, skill_id. |
| **event_outbox** (073) | `id` UUID PK; `event_type` String(150) NOT NULL; `payload` JSONB DEFAULT `'{}'`; `status` String(16) DEFAULT `pending`; `attempts` Integer DEFAULT 0; `created_at`; `delivered_at`; `last_error` Text. Partial index `ix_event_outbox_pending (created_at, id)`. Widened (082): `event_version` Integer DEFAULT 1; `aggregate_type`/`aggregate_id`/`profile_id`/`owner_scope` Text; `idempotency_key` Text (UNIQUE `uq_event_outbox_idempotency_key`); `publish_status` String(16) DEFAULT `pending`; `next_retry_at` TIMESTAMPTZ; + `ix_event_outbox_publish_pending`. |
| **rendition** (077) | `id` UUID PK; `application_id` UUID FK→application **CASCADE**; `rendition_type` String(32); `status` String(16) DEFAULT `pending`; `template_name` String(128); `content` Text; `error` Text; `workflow_id` String(255); `created_at`; `completed_at`. Index `(application_id, created_at DESC)`. |
| **agent_task_output** (078) | `id` UUID PK; `agent_task_id` UUID; `output_path` Text NOT NULL; `producing_skill` String(150); `created_at`. UNIQUE `(agent_task_id, output_path)`. Indexes: agent_task_id, producing_skill. |
| **input_provenance** (078) | `id` UUID PK; `run_id` String(255) NOT NULL; `application_id`/`wave_id` UUID; `input_path` Text NOT NULL; `origin` String(32) DEFAULT `upstream-line-output` (CHECK `input_provenance_origin_ck` = `IN ('upstream-line-output','operator-supplied','external-system','partial-prior-run')`); `attestation` Text; `recorded_at`. UNIQUE `(run_id, input_path)`. Index on run_id. |
| **scoped_run** (081) | `id` UUID PK; `run_id` String(255) NOT NULL **UNIQUE**; `application_id`/`wave_id` UUID; `target_line` String(64); `run_mode` String(16) DEFAULT `full-pipeline` (CHECK `scoped_run_run_mode_ck` = `IN ('full-pipeline','isolated','partial','composed')`); `assurance_level` String(16) DEFAULT `full` (CHECK `scoped_run_assurance_level_ck` = `IN ('full','provisional','partial','context-starved')`); `context_starved` Boolean DEFAULT false; `prerequisite_decision` **`sa.JSON`** (nullable; shape `{gate_id: G-PREREQ, unmet[], policy, allowed, reason, assurance_ceiling}`); `recorded_at`. Indexes on run_id, application_id. |
| **portfolio_membership** (056) | `id` UUID PK; `portfolio_id` UUID FK→portfolio **CASCADE**; `user_id` String(255) NOT NULL; `role` String(32) NOT NULL; `granted_by` String(255) NOT NULL; `granted_at` TIMESTAMP DEFAULT now(). UNIQUE `(portfolio_id, user_id)` = `uq_portfolio_membership`. Indexes on user_id, portfolio_id. |

---

## 11. Cross-cutting gotchas

- **Loosely-typed FKs.** Several newer tables reference apps/portfolios/waves via
  **String id columns with no FK** (`chat_message.app_id`, `drift_report.app_id`,
  `intent_record.app_id`, `decomp_hierarchy.application_id`, all `_signal` tables).
  Intentional — these are CLIENT-BLIND opaque ids; do not add FKs on rebuild.
- **`content_hash`/`content_digest` = String(71).** The `sha256:` (7 chars) + 64 hex =
  71 exactly; enforced by CHECK on evidence_record & drift_report. Keep the length.
- **Soft-delete via `retired_at`** on all capability-grain tables — never hard-delete;
  the partial unique indexes are scoped `WHERE retired_at IS NULL` so a retired row can
  share a natural key with its successor.
- **`(xmax = 0)` insert-detection** in `persist_capability_catalog` (Part 1 §5.4).
- **Enum vs projection archetype mismatch** (Part 1 §3 gotcha) — live and intentional.
