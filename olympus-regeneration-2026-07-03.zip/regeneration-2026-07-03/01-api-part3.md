# Olympus API — Part 3 (remaining routers)

Atomic regeneration spec. Source tree: `/Users/pnunna/Documents/GitHub/olympus/olympus-api/src/routers/`.
Every claim cites `path:line` (bare `:NN` when the file is named at the section top).

## 0. Router inventory & mount order (authoritative)

`ls olympus-api/src/routers/*.py` → **50 routers** (+ `__init__.py`). Full set:
`activity, admin, admin_audit, admin_bundles, agent_roles, agent_runs, agents, analytics, applications, artifacts, auth, autonomy, autonomy_incidents, bundles, capabilities, chat, decomp, delegations, drift_control, drift_reports, escalations, evals, events, evidence_ledger, evidence_runs, feedback, gates, git, governance, health, human_paired_agent, intake, lines, me, portfolio, portfolio_members, profiles, registries, renditions, reusable_parts, runs, skills, system, systems, traceability, users, waves, webhooks, workflow_signals, workflows`.

Parts 1–2 cover: `applications, agents, agent_roles, agent_runs, gates, governance, lines, portfolio, portfolio_members, registries, skills, systems, waves`. **Part 3 (this file)** covers the remaining **37** routers listed below.

Mount order in `main.py` (`app.include_router(...)`, main.py:219–286) — preserved so path-shadowing resolves identically:
health, system, systems, auth, portfolio, profiles, portfolio_profile, registries, reusable_parts, applications, gates, wave_gates, events, activity, analytics, waves, git, lines, line_start, workflow_signals, traceability, artifacts, escalations, feedback, governance, evidence_ledger, evidence_runs, drift_reports, autonomy, autonomy_incidents, capabilities, evals, decomp, intake, chat, delegations, renditions, skills, webhooks, workflows, agent_runs, runs, agents, agent_roles, admin, admin_audit, portfolio_members, bundles, admin_bundles, users, me, human_paired_agent.

GOTCHA (capabilities.py:14–20): `/api/v1/capabilities/{capability_id}` is owned by the Phase-5 **systems** router (mounted first). Capabilities read endpoint is deliberately `/capabilities/runs/{run_id}` to avoid being shadowed.

---

## 1. capabilities.py — tiered single-skill dispatch (NEW P9-S18.2)

`router = APIRouter(prefix="/api/v1/capabilities", tags=["Capabilities"])` (:93).

### Role sets
- `CAPABILITY_RUN_ROLES` (:72) = TECH_LEAD, ARCH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN, SERVICE. (VIEWER excluded.)
- `CAPABILITY_READ_ROLES` (:81) = VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN, SERVICE.

### Shared handler `_run_capability(request, actor, *, enforce_allowlist=False, db=None)` (:96)
```
svc = CapabilityService(db=db)
try:
    return await svc.run(request, actor=actor, enforce_allowlist=enforce_allowlist)
except CapabilityNotAllowlistedError as exc:   # order matters: raised BEFORE resolution
    raise OlympusHTTPException(403, "CAPABILITY_NOT_ALLOWLISTED", str(exc))
except CapabilityResolutionError as exc:
    raise OlympusHTTPException(400, "CAPABILITY_UNRESOLVABLE", str(exc))
```
GOTCHA (:129–136): allowlist 403 is caught first because the service raises it before any dispatch; resolution 400 second.

### Endpoints (preserve order)
1. **POST /generate-architecture** → `CapabilityRunResponse` (:139). auth `require_role(*CAPABILITY_RUN_ROLES)` + separate `get_current_user` (actor = `user.sub`, never body) + `db`. Body: `CapabilityRunRequest`. Body's `capability` is **overwritten** server-side: `body.capability = "generate-architecture"` (:170) → target-architecture-blueprint skill. `enforce_allowlist=False` (named endpoints bypass gate). Default tier for this capability = `bare` (S18.8).
2. **POST /extract-business-rules** → `CapabilityRunResponse` (:174). Same auth/actor. `body.capability = "extract-business-rules"` (:207) → extraction skill. Per-capability default tier = `provenance` (REQ-CAP-012); provenance fields still None (scaffold).
3. **POST /run** → `CapabilityRunResponse` (:211). Generic. `enforce_allowlist=True` (:243) → REQ-CAP-007: non-allowlisted capability (or pinned skill_id no allowlisted capability exposes) rejected 403 `CAPABILITY_NOT_ALLOWLISTED` before any dispatch.
4. **GET /runs/{run_id}** → `CapabilityRunResponse` (:247). auth `CAPABILITY_READ_ROLES`. `run_id` opaque path. Logic:
```
svc = CapabilityService()          # no db needed for read
run = svc.get_run(run_id)          # in-process projection
if run is None: raise OlympusHTTPException(404, "CAPABILITY_RUN_NOT_FOUND", ...)
return run
```
Provenance tiers: `bare`/`provenance`/`verified`; `bare` is the working pass-through (S18.3 byte-parity seam); provenance/verified accepted but behave as bare with provenance fields None (scaffold). `__all__ = ["CAPABILITY_READ_ROLES","CAPABILITY_RUN_ROLES","router"]` (:276).

---

## 2. autonomy.py — autonomy gate (NEW P10-S18.1)

`router = APIRouter(prefix="/autonomy", tags=["autonomy"])` (:50). Reuses `LEDGER_RATIFY_ROLES`, `LEDGER_READ_ROLES` imported from `evidence_ledger` (:39).

1. **POST /{loop_item_id}/escalate** → `EscalateResult` (:53). Body `EscalateRequest`. auth: `get_current_user` (actor) + `require_role(*LEDGER_RATIFY_ROLES)` (elevated: COMPLIANCE_LEAD/PORTFOLIO_MANAGER/PORTFOLIO_ADMIN) + `db`. Logic (:75):
```
svc = AutonomyEscalationService(db=db)
return await svc.escalate(loop_item_id=loop_item_id, body=body, actor=user.sub)
```
Re-runs the pure autonomy resolver (reflects denylist hit / tier cap / attempt cap), then forces escalation (pins permitted level → `report_only`). Recorded as decision-log record; ALSO an `evidence_record` when `AUTONOMY_EVIDENCE_EMIT` on. Actor from principal, never body (unauthorized escalate impossible — role gate 403 before handler).
2. **GET /status** → `AutonomyStatusPage` (:83). Query: `profile_id` (resolve caps + filter escalations), `risk_tier` (resolve per-pattern permitted rung), `application_id` (filter escalations), `limit` (default 100, ge=1 le=500). auth `LEDGER_READ_ROLES`. Read-only, evidence-free.
```
svc = AutonomyStatusService()
return svc.status(profile_id=..., risk_tier=..., application_id=..., limit=...)
```
Surfaces every registered loop pattern with requested rung + (when `risk_tier` supplied) the rung the gate would permit after the per-tier cap, plus open escalations + L0→L3 readiness ladder. No write endpoint for the verdict — produced service-internally in the loop workflow's `evaluate_autonomy` activity.

---

## 3. autonomy_incidents.py — error-triage incidents read (NEW P9-S17.6)

`router = APIRouter(prefix="/autonomy", tags=["autonomy"])` (:38). Second router on the same `/autonomy` prefix.

1. **GET /incidents** → `IncidentPage` (:41). Query: `profile_id` (tenant filter), `service` (single-service filter), `limit` (default 100, ge=1 le=500). auth `require_role(*LEDGER_READ_ROLES)`. Logic (:61): `svc = AutonomyIncidentsService(); return svc.list_open(profile_id=..., service=..., limit=...)`. Read-only, evidence-free, newest-first; each incident carries capture source, cluster size (occurrence count), risk tier, triage decision. Incidents produced by the nightly `error-triage` Temporal sweep (routes each candidate remediation through the `autonomy_level` gate); NO write endpoint.

---

## 4. intake.py — mission-intent front door (NEW P8)

`router = APIRouter(prefix="/api/v1/intake", tags=["Intake"])` (:97). `_service(db) = IntakeService(db)` (:100).

Role sets: `VIEWER_PLUS` (:69, 8 roles incl VIEWER); `CAPTURE_ROLES` (:81) = TECH_LEAD, ARCH_LEAD, OPERATIONS_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN; `OWNER_ROLES` (:90) = TECH_LEAD, ARCH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN.

All lifecycle handlers wrap `IntakeError` → `OlympusHTTPException(404, ...)`; actor always = `user.sub`.

1. **POST ""** → `IntakeRecordView`, **status 201** (:104). auth CAPTURE_ROLES. Body `IntakeCreateRequest`. `create_intent(statement, actor, app_id, portfolio_id)` → persists record + one `derives_from` trace link per derived requirement (REQ-II-001/002). Born `draft`.
2. **GET /{intent_id}** → `IntakeRecordView` (:125). auth VIEWER_PLUS. 404 `INTENT_NOT_FOUND` if record None.
3. **POST /{intent_id}/present** → `IntakeRecordView` (:140). auth CAPTURE_ROLES. `present(intent_id)`; 404 `INTENT_NOT_FOUND` on IntakeError.
4. **POST /{intent_id}/confirm** → `IntakeRecordView` (:154). auth OWNER_ROLES. Body optional `ConfirmRequest`. `acknowledged = body.acknowledged_material_criteria if body else []`; `confirm(intent_id, actor, acknowledged_material_criteria=...)`. Only transition that opens the build-dispatch gate; audited. Material decision exempt from pause only if every touched criterion acknowledged here.
5. **POST /{intent_id}/requirements/edit** → `IntakeRecordView` (:178). auth OWNER_ROLES. Body `RequirementEditRequest`. `edit_requirement(intent_id, ref, new_statement, actor)`; 404 `INTENT_REQUIREMENT_NOT_FOUND`. Audited.
6. **POST /{intent_id}/requirements/reject** → `IntakeRecordView` (:195). auth OWNER_ROLES. Body `RequirementRejectRequest`. `reject_requirement(intent_id, ref, reason, actor)`; 404 `INTENT_REQUIREMENT_NOT_FOUND`. Audited.
7. **POST /{intent_id}/dispatch** → `DispatchAttemptResult` (:212). auth OWNER_ROLES. `attempt_build_dispatch(intent_id)`; returns `dispatched=False` for unconfirmed records; 404 `INTENT_NOT_FOUND`.
8. **POST /{intent_id}/material-check** → `MaterialDecisionVerdict` (:229). auth CAPTURE_ROLES. Body `MaterialDecisionCheckRequest`. `check_material_decision(intent_id, decision, criteria, actor)`; 404. Material decision not in a confirmed requirement PAUSES + audits.
9. **POST /{intent_id}/guided** → `dict` (:252). auth CAPTURE_ROLES. Query-style args `stage: str`, `message: str`. `guided_step(intent_id, stage, owner_message=message, actor)` → `{"intent_id","stage","next_prompt": prompt}`; 404. Reuses chat surface via `context_type="intent"`.

Table `intent_record` (migration 078); upsert `ON CONFLICT(intent_id)`.

---

## 5. decomp.py — feature/blueprint decomposition (NEW P8)

`router = APIRouter(prefix="/api/v1/decomp", tags=["decomposition"])` (:58).

Role sets: `CONTRIBUTOR_ROLES` (:64) = TECH_LEAD, ARCH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN; `REVIEWER_ROLES` (:70) = ARCH_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN; `READ_ROLES` (:76) = VIEWER, TECH_LEAD, ARCH_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN, COMPLIANCE_LEAD, OPERATIONS_LEAD.

1. **POST /hierarchies** → `PersistedHierarchyRow` (:88). auth CONTRIBUTOR. Body `PersistHierarchyRequest`. `DecompPersistService(db).persist_hierarchy(application_id, intent_ref, profile_id, payload, commit=True)`; `DecompPersistError` → 422 `DECOMP_HIERARCHY_INVALID`. Idempotent on `(application_id, intent_ref, content digest)`; lands in review state before any work-order gen.
2. **GET /hierarchies/{hierarchy_id}** (UUID) → `HierarchyDetail` (:112). auth READ_ROLES. `get_detail(hierarchy_id)`; `HierarchyNotFoundError` → 404 `DECOMP_HIERARCHY_NOT_FOUND`.
3. **POST /hierarchies/{hierarchy_id}/nodes/{node_id}/review** → `NodeReviewResult` (:130). auth `get_current_user` + REVIEWER_ROLES. Body `NodeReviewRequest`. `record_review(hierarchy_id, node_id, decision=body.decision, decided_by=user.sub, rationale=body.rationale, commit=True)`. `HierarchyNotFoundError` → 404 `DECOMP_NODE_NOT_FOUND`; `DecompPersistError` → 422 `DECOMP_REVIEW_INVALID` (a rejected decision MUST carry rationale).
4. **POST /hierarchies/{hierarchy_id}/nodes/{node_id}/revise** → `ImpactPropagationResult` (:171). auth CONTRIBUTOR. `DecompImpactService(db).revise_node(hierarchy_id, node_id)` — BIDIRECTIONAL impact: downstream work orders (node + descendants) AND upstream requirements (originating requirement + ancestors), REQ-DA-004.
5. **POST /hierarchies/{hierarchy_id}/work-orders** → `WorkOrderGenResult` (:190). auth CONTRIBUTOR. Body optional `WorkOrderGenRequest`. `generate_work_orders(hierarchy_id, commit=True)`. **GATED** (REQ-DA-005): `UnreviewedCriticalNodeError` → **409** with `code=exc.reason_code`, `details={"blocking_nodes": list(exc.decision.blocking_nodes), "criticality_review_floor": exc.decision.floor}`. `HierarchyNotFoundError` → 404. Refused while any node above the profile criticality floor is unreviewed.

---

## 6. evals.py — eval-harness read + gate (NEW P8, REQ-EH-008)

`router = APIRouter(prefix="/api/v1/evals", tags=["Evals"])` (:85). Reads = `LEDGER_READ_ROLES` (imported :71). `PROMOTION_GATE_ROLES` (:79) = TECH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN.

Inline model `PromotionGateRequest` (:88): `cases: list[EvalCase]` (min_length 1), `floor: float = run_svc.DEFAULT_PASS_RATE_FLOOR` (ge 0 le 1), `run_id: str|None` (idempotency key).

1. **GET /models** → dict (:112). auth READ. No DB. `{"models": list(run_svc.CANDIDATE_MODELS)}` (Fable 5 / Opus 4.8 / Sonnet 4.6 / Haiku 4.5).
2. **GET /models/{model_id}/summary** → `ModelEvalSummary` (:124). auth READ. `harness_svc.get_model_eval_summary(db, model_id)` (NULL-safe).
3. **GET /cases/{eval_case_id}/models/{model_id}/variance** → `RunVarianceReport` (:138). auth READ. `run_svc.compute_run_variance(db, eval_case_id, model_id)` — reads additive `eval_run` table; pass-rate stddev + κ across runs (REQ-EH-003).
4. **GET /variance** (`response_model=None`) → dict (:156). auth READ. Query `portfolio_id: UUID|None`. Logic:
```
report = harness_svc.compute_variance_report(db, portfolio_id=...)
stability = run_svc.evaluate_stability(kappa_gap=report.max_pairwise_kappa_gap)
return {"report": report.model_dump(mode="json"), "stability": stability.model_dump(mode="json")}
```
5. **GET /status** → `StabilityDecision` (:180). auth READ. Query `portfolio_id`, `kappa_gap_ceiling: float = DEFAULT_KAPPA_GAP_CEILING` (ge 0 le 2). Computes variance report then `evaluate_stability(kappa_gap, kappa_gap_ceiling)` → `unstable`/`withheld_from_gating` when gap>ceiling (REQ-EH-005).
6. **POST /cases/{eval_case_id}/run** (`response_model=None`) → dict (:204). auth READ. Body `case: EvalCase`, Query `run_id: str|None`. Logic:
```
if case.eval_case_id != eval_case_id: raise 422 "EVAL_CASE_ID_MISMATCH"
try: runs = await run_svc.run_eval_case(db, case, run_id=run_id)
except IllFormedEvalCaseError: raise 422 "EVAL_CASE_ILL_FORMED"    # self-grading rejected BEFORE run (REQ-EH-006)
await db.commit()
return {"eval_case_id": ..., "runs": [r.model_dump(mode="json") ...]}
```
7. **POST /promotion-gate** → `RegressionDecision` (:241). auth PROMOTION_GATE_ROLES. Body `PromotionGateRequest`. Logic (:260):
```
try: decision = await run_svc.evaluate_regression(db, body.cases, floor=body.floor, run_id=body.run_id)
except IllFormedEvalCaseError: raise 422 "EVAL_CASE_ILL_FORMED"
await db.commit()                      # persist re-run REGARDLESS of outcome (durable evidence)
logger.info("promotion_gate_evaluated", ...)
if decision.blocked: raise 409 "PROMOTION_BLOCKED_REGRESSION" (decision.reason)   # load-bearing
return decision                        # 200 blocked=False otherwise
```

---

## 7. drift_control.py — drift-as-control (NEW P8)

`router = APIRouter(prefix="/drift-control", tags=["drift-control"])` (:46). Reuses `LEDGER_RATIFY_ROLES` / `LEDGER_READ_ROLES` (:32).

1. **POST /{disposition_id}/risk-accept** → `RiskAcceptanceResult` (:49). auth `get_current_user` + `require_role(*LEDGER_RATIFY_ROLES)`. Body `RiskAcceptanceRequest`. Logic (:68):
```
svc = DriftControlRiskAcceptanceService(db)
try:
  return await svc.accept(disposition_id, app_id=body.app_id, actor=user.sub,
      reason=body.reason, portfolio_id=body.portfolio_id,
      profile_id=body.profile_id or str(body.portfolio_id),
      application_id=body.application_id, commit=True)
except DriftControlRiskAcceptanceError:
  raise OlympusHTTPException(422, error_code="DRIFT_CONTROL_RISK_ACCEPT_INVALID", ...)
```
GOTCHA (:76): `profile_id` falls back to `str(body.portfolio_id)` when body's profile_id empty. Acceptance written as `evidence_record` AND disposition unblocks in ONE transaction; empty reason → 422. (Note: `OlympusHTTPException` here is called with kwarg `error_code=` not the positional code used elsewhere.)
2. **GET /status** → `DriftControlStatusPage` (:88). auth `LEDGER_READ_ROLES`. Query `app_id`, `status` (blocked|risk_accepted|reconciled), `limit` (default 100, ge1 le500). `DriftControlStatusService(db).list_blocks(app_id, status, limit)`.

---

## 8. drift_reports.py — persisted drift-report read (NEW P8)

`router = APIRouter(prefix="/drift", tags=["drift"])` (:35). Reads = `LEDGER_READ_ROLES`.

`_row_to_model(row)` (:38): maps `drift_report` DB row → `DriftReportRow` (findings → list[`PersistedDriftFinding`], `proposed_diff` → `ProposedDiff` or None, plus verdict/blocking_count/coverage_pct/in_sync/content_digest/evidence_content_hash/recorded_at).

1. **GET /reports** → `DriftReportPage` (:61). auth `require_role(*LEDGER_READ_ROLES)`. Query `app_id`, `spec_artifact`, `limit` (default 50, ge1 le500). Builds dynamic WHERE with named binds (`app_id`, `spec`), `SELECT * FROM drift_report {where} ORDER BY recorded_at DESC, id DESC LIMIT :limit` (:88). Returns `DriftReportPage(reports=[...], total=len(reports))`. Read-only; persistence is service-internal.

---

## 9. evidence_runs.py — run-scoped evidence read (NEW P8)

`router = APIRouter(prefix="/api/v1/compliance", tags=["Compliance"])` (:46). Reuses `LEDGER_READ_ROLES` + `verify_portfolio_access`.

`_records_for_run(db, run_id)` (:49): `SELECT * FROM evidence_record WHERE evidence_payload->>'run_id' = :rid ORDER BY recorded_at ASC, id ASC` → `[_record_from_row(...)]`.

1. **GET /runs/{run_id}/oscal** → dict (:64). auth READ. Fetch run records; if empty → 404 `RUN_EVIDENCE_NOT_FOUND`. `return assemble_assessment_results(run_id, records)` (OSCAL assessment-results JSON, REQ-EV-007).
2. **GET /evidence/ledger** → `GroupedLedger` (:81). auth READ + `get_current_user`. Query `portfolio_id: UUID|None`, `run_id: str|None`. Logic:
```
if (portfolio_id is None) == (run_id is None): raise 400 "LEDGER_SCOPE_REQUIRED"   # exactly one
svc = ControlMappingService(db)
if portfolio_id is not None:
    await verify_portfolio_access(db, user, portfolio_id); return await svc.grouped_for_portfolio(portfolio_id)
return await svc.grouped_for_run(run_id)
```
Ratified-only, grouped by `(catalog_id, control_id)`; unratified mappings never count (REQ-EV-011).

---

## 10. analytics.py (13 endpoints)

`router = APIRouter(prefix="/api/v1/analytics", tags=["Analytics"])` (:66). `VIEWER_PLUS` (:50, 8 roles), `MANAGER_PLUS` (:61) = PORTFOLIO_MANAGER, PORTFOLIO_ADMIN. Membership scoping via `filter_portfolio_ids_by_membership`, `verify_portfolio_access`, `verify_application_portfolio_access`.

1. **GET /readiness-scores** → `ReadinessScoreResponse | list[dict]` (:69). auth VIEWER_PLUS. Query `app_id`, `portfolio_id`, `dimensions` (comma-sep). Logic:
```
if app_id is None:
    if portfolio_id: await verify_portfolio_access(...)
    member_ids = filter_portfolio_ids_by_membership(db, user)
    return get_all_readiness_scores(db, portfolio_id=..., portfolio_ids=member_ids)
await verify_application_portfolio_access(db, user, app_id)
dim_filter = dimensions.split(",") if dimensions else None
return calculate_readiness_score(db, app_id, dim_filter)
```
Fixes P5-AUDIT-003 cross-portfolio leakage; normalizes via `_normalize_score`.
2. **GET /overlap-matrix** → `OverlapMatrixResponse` (:109). VIEWER_PLUS. Optional portfolio access check + member_ids → `calculate_overlap_matrix(db, portfolio_id, member_ids)`.
3. **GET /portfolio-health** → `PortfolioHealthResponse` (:122). Same pattern → `calculate_portfolio_health`.
4. **GET /portfolio-scoring** → `PortfolioScoringHeatMapResponse` (:135). Same → `get_portfolio_scoring_heat_map` (6-dim readiness vector + risk/complexity/disposition).
5. **GET /disposition-confidence** → `DispositionConfidenceResponse` (:158). Query `app_id`; if app_id → `verify_application_portfolio_access`; → `calculate_disposition_confidence(db, app_id)`.
6. **GET /compound-growth** → `CompoundGrowthResponse` (:173). → `calculate_compound_growth`.
7. **GET /gate-pass-rate** → `GatePassRateResponse` (:186). → `calculate_gate_pass_rate` (per-gate-type + per-line breakdown).
8. **GET /score-history** → `ScoreHistoryResponse` (:199). Query `app_id` (required), `dimension`, `limit` (100, ge1 le1000). `verify_application_portfolio_access` then `get_score_history(db, app_id, dimension, limit)`.
9. **GET /dimension-registry** → `DimensionRegistryResponse` (:212). VIEWER_PLUS, no DB. `scoring_svc.get_dimension_registry()`.
10. **PUT /dimension-registry** → `DimensionRegistryResponse` (:222). auth **MANAGER_PLUS**. Body `weights: dict[str,float]`. `update_dimension_weights(weights)` (weights must sum to 1.0).
11. **GET /model-usage** → `ModelUsageResponse` (:238). VIEWER_PLUS + `get_current_user`. Optional portfolio check + member_ids → `model_usage_svc.get_model_usage(db, portfolio_id, member_ids)`. Replaces retired `GET /api/v1/agents`.
12. **POST /viewer-events** → `dict[str,int]` (:267). VIEWER_PLUS. Body `ViewerEventIngest | list[ViewerEventIngest]`. Normalizes to list; `record_events(db, events)` → `{"recorded": count}`.
13. **GET /viewer-events/summary** → `ViewerAnalyticsSummaryResponse` (:284). VIEWER_PLUS. Query `artifact_type`, `limit` (50, le500). `viewer_analytics_svc.summarize(db, artifact_type, limit)` — ordered by total dwell desc.

---

## 11. chat.py (8 endpoints; advisory Q&A + NL action console P10-W6)

`router = APIRouter(tags=["Chat"])` (:70) — **no prefix**; full paths per route. `VIEWER_PLUS` (:46, 8 roles). `CLEAR_HISTORY_ROLES` (:60) = all VIEWER_PLUS minus VIEWER (TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN). `CHAT_MODEL_ID = os.environ["CHAT_MODEL_ID"] or "us.anthropic.claude-sonnet-4-6"` (:72). `A2A_TIMEOUT_SECONDS = int(os.environ["A2A_CHAT_TIMEOUT"] or 60)` (:1070).

`SYSTEM_PROMPTS` (:80) keyed `gate`/`application`/`portfolio` (analyst personas; cite evidence, markdown).

### Request models
- `ChatRequest` (:108): `message`, `artifact_context: str|None` (legacy gate chat).
- `UnifiedChatRequest` (:115): `context_type: Literal["gate","application","portfolio"]`, `context_id`, `section: str|None`, `message`, `artifact_context`, `mode: Literal["advisory","action"]="advisory"`, `session_id: str|None`, `action_params: dict[str,dict]`.
- `ConfirmActionRequest` (:198): `session_id, intent_id, intent_text, action_seq:int, action_id, action_params:dict, confirmation_id`.
- Responses: `ChatResponse` (:160 `response, model_used, sources`), `ActionResponse` (:168 `mode="action", session_id, intent_id, intent_text, actions:list[dict], summary, reply, capabilities:list[dict]`), `ChatMessageOut` (:219), `ChatHistoryResponse` (:230).

### Citation parsing `parse_source_citations(text)` (:265)
Two regexes: `_ARTIFACT_CITATION_RE` (:243) `{artifact}:{section}:{finding-id}`; `_REPO_CITATION_RE` (:254) `{owner/name}:{file}:{line}`. Produces `ChatSource` list.

### Persistence helpers
- `_scoped_context_id(context_type, context_id, section)` (:308): gate/application → `context_id` (section ignored); portfolio → `f"{context_id}::{section or 'overview'}"`. GOTCHA (:322): separator `::` chosen because section values like `wave:<id>`/`assembly-line:<id>` already contain `:`; None/empty section maps to `overview` for legacy-row readability.
- `_persist_message(db, *, context_type, context_id, role, content, section=None, gate_id=None, app_id=None, sources=None, model_used=None, token_usage=None)` (:335): INSERT into `chat_message` with jsonb-cast sources/token_usage; commits; returns msg id (uuid4). Uses `_scoped_context_id`.
- `_get_chat_history(db, context_type, context_id, section=None)` (:382): `SELECT ... FROM chat_message WHERE context_type=:ct AND context_id=:scoped ORDER BY created_at ASC` → list[ChatMessageOut].
- `_load_nl_action_history` (:427): replays prior nl-action transcript, bounded by `_NL_HISTORY_CHAR_BUDGET = 48000` chars (~12k tokens), trimmed oldest-first.

### Context builders (:509–1073)
`_build_evidence_summary`, `_build_gate_context`, `_build_application_context`, `_build_portfolio_context` (section-aware), `_build_section_context`, `_build_entity_portfolio_resolver`, `_get_gate_agent_url(db, gate_id)` (:1073).

### A2A + Bedrock dispatch
- `_dispatch_a2a_chat(agent_url, message, context, history)` (:1091): POSTs `{task:"chat", context:{evidence_summary,conversation_history}, message, model_preference:"tier-2"}` to `{agent_url}/a2a/chat` with TCP-keepalive transport (`keepalive_socket_options()` — survives NLB ~350s idle) + `A2A_TIMEOUT_SECONDS`. Returns ChatResponse on `response` text, else None (fallback). Any exception → warn + None.
- `_get_bedrock_client()` (:1160): boto3 `bedrock-runtime`, `AWS_REGION` or `us-east-1`.
- `_invoke_bedrock(system_prompt, user_message)` (:1166): `invoke_model` (anthropic_version bedrock-2023-05-31, max_tokens 2048); concatenates text blocks; empty → canned message; parses citations. On any exception returns canned error ChatResponse (never raises).
- `_stream_bedrock_text(...)` (:1213): `invoke_model_with_response_stream`; yields `content_block_delta`/`text_delta` chunks; sync generator; on error yields nothing.

### NL action engine wiring (W6)
- `_extract_bearer(request)` (:1266): pulls `Bearer` token off Authorization.
- `_self_call_base_url(request)` (:1408): `OLYMPUS_SELF_CALL_BASE_URL` else `http://127.0.0.1:{API_PORT|8000}`. GOTCHA: MUST NOT use `request.base_url` (browser host not reachable in-container).
- `_build_http_executor(request)` (:1426): returns `(NLActionEngine, _executor)`. `_executor(spec, params, _user)` substitutes path params (`{key}` in path), remaining params → JSON body, self-calls the EXISTING endpoint via httpx with the user's own bearer (RBAC inherited, no bypass); returns `(status_code, dict body)`. 401/403 flows straight back (no retry).
- `_build_read_get(request)` (:1274): GET-only loopback for the agent read tools (REQ-NL-016), user's token, returns `(status, body)`.
- `_bedrock_tool_use_streamer` (:1350), `_parse_bedrock_tool_use_events` (:1300): agentic tool-use streaming.
- `_handle_action_turn(request, body, user, db)` (:1468): persist user intent (section `nl-action`); best-effort portfolio grounding (skipped under mock); `engine.understand(message, portfolio_context)`; if `is_capability_query` → return capability cards + reply (no action); else merge planner params with caller `action_params` (caller wins), `engine.plan(...)`, `engine.execute_plan(db, user, plan)`; persist summary; return ActionResponse.
- `_summarize_plan(plan)` (:1576): plain-language per-action status lines (executed/awaiting_confirmation/staged/denied/failed).
- `_safe_prose_len(text, sentinel)` (:2039): holds back trailing partial-sentinel so the machine-readable action tail never leaks to the user mid-stream.

### Endpoints (mount order)
1. **POST /api/v1/gates/{gate_id}/chat** → `ChatResponse` (:1605). auth VIEWER_PLUS. Body `ChatRequest`. Build gate context; persist reviewer msg; try A2A (if agent_url) then Bedrock fallback (`SYSTEM_PROMPTS["gate"]`, prompt = `f"{context}\n\n=== Question ===\n{message}"`); persist agent msg with sources.
2. **POST /api/v1/chat** → `ChatResponse | ActionResponse` (:1668). auth VIEWER_PLUS + `get_current_user`. Body `UnifiedChatRequest`, `request: Request`. **If `mode=="action"` → `_handle_action_turn` (returns before advisory path — advisory stays advisory, REQ-NL-009).** Else: portfolio-scope membership check per context_type (gate/application/portfolio!="default"; malformed UUID swallowed via `except ValueError: pass`); persist reviewer msg; build context (gate/application[+artifact_context]/portfolio[section]); gate → A2A first; else Bedrock (`SYSTEM_PROMPTS.get(context_type, "gate")`); persist agent msg.
3. **POST /api/v1/chat/action/confirm** → `ActionResponse` (:1796). auth VIEWER_PLUS + get_current_user. Body `ConfirmActionRequest`. `spec = nl_engine.ACTION_SPECS.get(action_id)`; None → 404 `ACTION_NOT_FOUND`. Tier **re-resolved from profile policy** (`engine.policy.tier_for(action_id)`) so a client can't forge a reversible tier onto a high-stakes action. Build one-action `ActionPlan`; `engine.confirm_and_execute(db, user, plan, action_seq, confirmation_id)`; `PermissionError` (gate decision attempted) → 403 `GATE_DECISION_NOT_AGENT_EXECUTABLE` (REQ-NL-004). Persist summary; return ActionResponse.
4. **POST /api/v1/chat/action/stream** → SSE `StreamingResponse` (:1888). auth VIEWER_PLUS + get_current_user. SSE events `token`/`plan`/`done`. Capability query → single deterministic reply. Live: stream Bedrock prose, stripping action-sentinel tail via `_safe_prose_len`; `parse_streamed_plan`; empty stream → deterministic `understand` fallback. Then plan + `execute_plan`; emit `plan` ActionResponse; `done`. Mock: reply emitted in one token.
5. **POST /api/v1/chat/action/agent** → SSE `StreamingResponse` (:2051). auth VIEWER_PLUS + get_current_user. Agentic tool-use loop (REQ-NL-016/017): `nl_agent.run_agent_loop` reads live data in-loop (skills/app-status/artifacts/gates/analytics via GET-only `_read_exec`, scoped to `active_portfolio_id`), navigates, then any proposed WRITE flows through the UNCHANGED gated engine. SSE events `token`/`tool_call`/`tool_result`/`artifact`/`navigate`/`plan`/`done`. Under mock OR capability query → delegates to `stream_action`. Loads prior nl-action history before persisting new msg. On loop exception → degrade to single-shot `understand`. If proposed write has no prose, backfills reply with plan summary.
6. **GET /api/v1/gates/{gate_id}/chat/history** → `ChatHistoryResponse` (:2235). auth VIEWER_PLUS + get_current_user. `verify_gate_portfolio_access`; `_get_chat_history(db,"gate",str(gate_id))`.
7. **GET /api/v1/chat/history** → `ChatHistoryResponse` (:2256). auth VIEWER_PLUS + get_current_user. Query `context_type`, `context_id`, `section`. Per-type membership check (ValueError swallowed); `_get_chat_history(..., section)`.
8. **DELETE /api/v1/chat/history** → 204 (:2297). auth **CLEAR_HISTORY_ROLES** (no VIEWER) + get_current_user. Query `context_type`, `context_id`, `section`. Membership check; `DELETE FROM chat_message WHERE context_type=:ct AND context_id=:scoped`; commit; returns 204 + header `X-Cleared-Count`. Idempotent (count 0 ok); no "clear all".

---

## 12. profiles.py (4 GET on /profiles + 3 on portfolio_profile_router; 1549 LOC)

`router = APIRouter(prefix="/api/v1/profiles", tags=["profiles"])` (:59). `portfolio_profile_router = APIRouter(prefix="/api/v1/portfolio", tags=["portfolio"])` (:1050).

### Directory/loader helpers
- `_profiles_dir()` (:67): search order — `OLYMPUS_PROFILES_DIR` env → walk up from `__file__` for `profiles/` → walk up from CWD → `/app/repo/profiles`, `/app/profiles`; None if none found (degrade gracefully).
- `_list_profile_ids()` (:127): subdirs containing `profile.yaml`; `[]` on missing dir / OSError.
- `_load_by_id(profile_id)` (:164): `load_profile(discover_profile_root(profile_id))`; `ProfileLoadError` → 404.
- `_lock_policy_summary(policy)` (:172): per-dimension `{policy, stricter_only, rationale}`.
- `resolve_portfolio_effective_profile(base_id, override_id, *, lock_policy=None)` (:184): THE shared resolution seam (REQ-LP-015). No override → base is effective (`resolve_effective_profile(base, None, policy)`). With override: load override; version-pin base off `override.metadata.inherits` (`resolve_base_ref`; `resolve_versioned_base(base_ref)` when `base_ref.base_id==base_id`, REQ-LP-009) else load base as-is; `resolve_effective_profile(base, override, policy)`.

### Diff helpers (:925–1042)
`_as_plain` (dataclass/list/dict → JSON scalar), `_diff_scalars` (unchanged/changed), `_diff_dicts` (added/removed/changed across key union, sorted), `_diff_profiles` (:960): metadata, scoring.weights (`{d.name:d.weight}`), risk_classification.tier_labels, compliance.domains, gates.default_provider + per-gate override presence, technology.infrastructure, skills.

### `/profiles` endpoints
1. **GET ""** → `list[ProfileSummary]` (:837). No auth dependency. Iterates `_list_profile_ids()`; per-id `_load_by_id` in try/except (HTTPException → skip+warn; other Exception → skip+warn) — never 500s (P5-AUDIT-005). Emits `{id,name,version,description}`.
2. **GET /active** → `ActiveProfileResponse` (:876). `active_profile()`; None → `ActiveProfileResponse(active=None)` else `_profile_detail`.
3. **GET /compare** → `ProfileComparisonResponse` (:885). Query `left`, `right` (required). Loads both; `_diff_profiles`; returns left/right summaries + diffs.
4. **GET /{profile_id}** → `ProfileDetail` (:913). `_profile_detail(_load_by_id(profile_id))`. GOTCHA: mounted AFTER `/active` and `/compare` so those static paths aren't captured by `{profile_id}`.

### portfolio_profile_router endpoints
Bundle helpers: `_portfolio_profile_id(portfolio_id)` (:1063, reads in-memory `_portfolios` store; default `""`); `_read_profile_bundle(profile_id)` (:1083): walks `discover_profile_root(profile_id).resolve()`, includes only `.yaml`/`.yml`, path-traversal/symlink-escape guard via `resolved.relative_to(root)` (skips out-of-tree + unreadable), returns `{rel_posix_path: yaml_text}`.

5. **GET /{portfolio_id}/profile-bundle** → `ProfileBundleResponse` (:1135, responses 404). auth `get_current_user`. Query `profile` override. Membership check when id parses as UUID (`verify_portfolio_access`). Verify portfolio exists (in-memory cache → DB fallback for UUID ids, lazy-hydrate). Profile pick order: query `?profile=` → portfolio assignment → `faa` default. Early traversal reject (`/`, `..`, leading `.`) → 404. `_read_profile_bundle`; `ProfileLoadError` → 404; empty files → 404 `has no YAML`. Returns `{profile_name, files}`.
6. **PUT /{portfolio_id}/profile** → `EffectiveProfileResponse` (:1273, responses 409/422). auth get_current_user. Body `ProfileSwitchRequest`. Logic:
```
membership check (UUID); resolve portfolio (cache→DB, lazy-hydrate, 404 if none)
in_flight = _workflows_in_flight(portfolio_id); if in_flight: 409 Conflict   # Temporal determinism guard
base_id = body.base.strip(); override_id = body.override.strip() or None; flat = body.profile.strip()
if not base_id and not flat: 422 "profile id cannot be empty"
if flat.lower()=="default" and not base_id:
    deactivate_profile(); persist_portfolio_profile_id(db, pid, ""); return effective=(no profile)
if not base_id: base_id=flat; override_id=None
policy = default_lock_policy()
try: effective = resolve_portfolio_effective_profile(base_id, override_id, lock_policy=policy)
except LockPolicyViolation as e: 422 e.to_dict()          # {dimension,policy,base_value,attempted_value,message}
except LayerResolutionError as e: 422 {dimension,policy:"invariant",...,message}
except HTTPException: raise                                # 404 unknown id
try: activate_profile(profile_id=effective.metadata.id)
except ProfileActivationError: log (composite not standalone — best-effort)
stored_id = override_id or base_id; persist_portfolio_profile_id(db, pid, stored_id)
return EffectiveProfileResponse(portfolio_id, base_id, override_id, effective=_profile_detail(effective), lock_policy=summary)
```
GOTCHA (:1369, `_workflows_in_flight` :1258): currently returns `[]` (permissive hook, patched in tests); 409 fires on explicit reservations. GOTCHA (:1429–1445): `activate_profile` best-effort — composite effective profile that isn't a standalone bundle logs and continues.
7. **GET /{portfolio_id}/profile** → `EffectiveProfileResponse` (:1491, responses 404). auth get_current_user. Membership check (UUID). `_portfolio_assigned_profile_id(db, portfolio_id)` (:1461: DB column authoritative, in-memory fallback; 404 if row None); empty → 404 `no profile assigned`. Load assigned; `resolve_base_ref(inherits)`; if base_ref → resolve `base⊕override` (base_id=base_ref.base_id, override_id=stored); else flat base is effective. `LockPolicyViolation`→422 to_dict; `LayerResolutionError`→422 message. Returns resolved effective view.

`ProfileSwitchRequest` (:350) supports layered `{base, override}` or flat `{profile}`.

---

## 13. traceability.py (6 endpoints)

`router = APIRouter(prefix="/api/v1", tags=["Traceability"])` (:47). `VIEWER_PLUS` (:36). First 6 endpoints add `dependencies=[Depends(require_application_member)]`.

1. **GET /applications/{app_id}/traceability** → `TraceabilityResponse` (:50). Query `source_artifact`, `target_artifact`. If source → `forward_trace().links`; if target → `backward_trace().links`; always `compute_coverage`. Returns combined.
2. **GET /applications/{app_id}/traceability/forward** → `ForwardTraceResult` (:84). Query `source_artifact` (required), `source_element`. `forward_trace(db, app_id, source_artifact, source_element)`.
3. **GET /applications/{app_id}/traceability/backward** → `BackwardTraceResult` (:100). Query `target_artifact` (required), `target_element`.
4. **GET /applications/{app_id}/traceability/coverage** → `CoverageResult` (:116). `compute_coverage`.
5. **GET /applications/{app_id}/traceability/validate** → `GateTraceabilityResult` (:130). Query `gate_type` (required), `risk_tier`. `validate_gate_traceability(db, app_id, gate_type, risk_tier)`.
6. **GET /applications/{app_id}/traceability/cross-validate** → `list[CrossValidationIssue]` (:146). `cross_validate(db, app_id)`.
7. **GET /artifacts/stale** → `StaleArtifactsResponse` (:160). auth VIEWER_PLUS (NO application-member dep). Query `app_id`. If app_id → `verify_application_portfolio_access`; `member_ids = filter_portfolio_ids_by_membership`; `detect_staleness(db, app_id, portfolio_ids=member_ids)`.

GOTCHA: `artifacts.py:103` notes `/api/v1/artifacts/stale` is served HERE (traceability), not in artifacts.py, to avoid double registration.

---

## 14. evidence_ledger.py (5 endpoints, P7-S16.16)

`router = APIRouter(prefix="/api/v1/compliance", tags=["Compliance"])` (:61). Defines `LEDGER_READ_ROLES` (:43, 8 roles incl VIEWER) and `LEDGER_RATIFY_ROLES` (:55) = COMPLIANCE_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN — **imported by autonomy/drift_control/evidence_runs/evals/capabilities**.

1. **GET /portfolios/{portfolio_id}/evidence-records** → `EvidenceLedgerPage` (:64). auth READ + get_current_user. Query `limit` (200, ge1 le1000), `offset` (ge0). `verify_portfolio_access`; `svc.list_for_portfolio(...)`; newest-first.
2. **GET /evidence-records/{record_id}** → `EvidenceRecord` (:85). READ. `svc.get(record_id)` then `verify_portfolio_access(record.portfolio_id)`.
3. **GET /evidence-records/{record_id}/verify** → dict (:102). READ. `verify_record(record)` recomputes content hash; `intact:false + reason` + `warning` log on mismatch (tamper detection).
4. **GET /portfolios/{portfolio_id}/evidence-chain/{control_id}** → `ChainVerification` (:131). READ. Query `application_id`. `chain_for_control(...)`; `verify_chain(chain)`; restore real portfolio_id/control_id/application_id on the synthesized empty case; warn on broken.
5. **POST /evidence-records/{record_id}/ratify** → `EvidenceRecord` (:170). auth **RATIFY**. Body `RatifyRequest`. `verify_portfolio_access`; `svc.ratify(record_id, user.sub, body.note)`; `EvidenceLedgerError` → 409 `EVIDENCE_ALREADY_RATIFIED` (append-once; original assessor+timestamp never overwritten).

---

## 15. delegations.py (3 endpoints, W10)

`router = APIRouter(prefix="/api/v1/delegations", tags=["Delegations"])` (:38).

1. **POST ""** → `DelegationGrant`, status 201 (:41). auth `get_current_user`. Body `IssueDelegationRequest`. `issue_grant(db, grantor=user, request=body)` — persisted scope narrowed to `grantor-rights ∩ requested-scope` (never broader than grantor, REQ-NS-006). Logs `delegation.issued`. Idempotency key `(grantor, agent, scope_hash)`.
2. **GET ""** → `list[DelegationGrant]` (:64). get_current_user. `list_active_grants(db, grantor=user.sub)`.
3. **DELETE /{grant_id}** (UUID) → 204 (:73). get_current_user. `revoke_grant(db, grant_id, revoker=user)` — grantor or portfolio_admin only. `DelegationError` → `HTTPException(exc.status_code, exc.detail)`; not revoked → 404. Logs `delegation.revoked`.

DO-NOT-REBUILD (:8): NO new action endpoint — delegated actions ride existing endpoints; these manage grant lifecycle only.

---

## 16. escalations.py (4 endpoints, P4-S1.9)

`router = APIRouter(prefix="/api/v1/escalations", tags=["Escalations"])` (:49). `VIEWER_PLUS` (:32), `RESOLVER_ROLES` (:43) = TECH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN. Table `escalation`. Inline models: `EscalationStatus`(open/investigating/resolved), `EscalationType`(Technical/Domain/Strategic/Safety/Infrastructure), `EscalationSeverity`(Critical/Standard/Low), `EscalationSummary`/`Detail`/`Resolution`/`ResolveRequest`/`Metrics`. `_row_to_detail(row)` (:110).

1. **GET ""** → dict (paginated) (:154). VIEWER_PLUS. Query `status`, `type`, `severity`, `app_id`, pagination. Dynamic WHERE; count + `SELECT ... ORDER BY created_at DESC LIMIT/OFFSET`; `paginated_response`.
2. **GET /metrics** → `EscalationMetrics` (:219). VIEWER_PLUS. Aggregates: total, open (`status != 'resolved'`), avg resolution hours (`AVG(EXTRACT(EPOCH FROM (updated_at-created_at))/3600)` for resolved), pattern-extraction rate, by_type, by_severity (GROUP BY).
3. **GET /{escalation_id}** (UUID) → `EscalationDetail` (:283). VIEWER_PLUS. `SELECT * WHERE id`; None → 404 `ESCALATION_NOT_FOUND`.
4. **POST /{escalation_id}/resolve** → `EscalationDetail` (:303). auth **RESOLVER_ROLES**. Body `EscalationResolveRequest` (`resolution_type` Literal[Re-Extract|Manual Augment|Re-Disposition], `details`). 404 if missing; **409 `ESCALATION_ALREADY_RESOLVED`** if already resolved; else `UPDATE ... status='resolved', resolver, resolution_type, resolution=jsonb, updated_at`; commit; re-read + return.

---

## 17. feedback.py (7 endpoints, P7-S16.13 + P8 delta)

`router = APIRouter(prefix="/api/v1/feedback", tags=["Feedback"])` (:98). Role sets: `VIEWER_PLUS` (:60); `CAPTURE_ROLES` (:73) = TECH_LEAD, OPERATIONS_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN; `APPROVER_ROLES` (:81) = TECH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN; `OPERATIONS_ROLES` (:91) = OPERATIONS_LEAD, TECH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN. Table `feedback_item` (071). Helpers `_row_to_detail` (:106), `_load` (:134), `_write_audit` (:144, INSERT audit_log actor_type='human').

1. **GET ""** → dict (paginated) (:169). VIEWER_PLUS. Query `status`, `source_type`, `severity`, `app_id`, pagination. **Defaults `status` to `pending_review` when omitted** (queue is the default surface, REQ-5). `ORDER BY occurrence_count DESC, updated_at DESC`.
2. **POST ""** → `FeedbackItemDetail`, status 201 (:246). auth **CAPTURE_ROLES**. Body `FeedbackCaptureRequest`. Recurrence-aware logic:
   - `source_id = None if source_type=="manual" else body.source_id` (manual NULLs stay distinct).
   - Existing OPEN item with same signature → increment `occurrence_count`, return it (no duplicate). 
   - Else prior CLOSED item (approved/dismissed/escalated) same signature → **escalate recurrence-after-fix** via `escalate_recurrence(...)` (REQ-FB-005) instead of silent re-file.
   - Else INSERT new `pending_review` row (occurrence_count 1). Never reaches `approved`.
3. **GET /{feedback_id}** (UUID) → `FeedbackItemDetail` (:383). VIEWER_PLUS. 404 `FEEDBACK_NOT_FOUND`.
4. **POST /{feedback_id}/approve** → `FeedbackItemDetail` (:398). auth **APPROVER_ROLES**. Body `FeedbackApproveRequest`. 404 if missing; **409 `FEEDBACK_NOT_PENDING`** if status != pending_review. Sets `approved` + reviewer/reviewed_at; **generates a work order** (`generate_work_order`, REQ-FB-003); `promotion_ref = f"work-order:{wo.id}"` (overrides caller placeholder); `_write_audit("feedback.approve")`; commit. ONLY path to `approved`/work-order.
5. **POST /{feedback_id}/dismiss** → `FeedbackItemDetail` (:497). APPROVER_ROLES. Body `FeedbackDismissRequest`. 404/409 same guards; sets `dismissed` + dismiss_reason; audit; commit.
6. **POST /ingest** → `FeedbackIngestResult` (:568). auth **OPERATIONS_ROLES**. Body `FeedbackIngestRequest`. `ingest_sources(db, sources, portfolio_id, actor)` — reads `escalation`/`incident_log`, normalizes NEW rows to classified `pending_review` (dedup `(source_type,source_id)`; bump recurrence; escalate recurrence-after-fix). NEVER reaches approved.
7. **POST /work-orders/{work_order_id}/complete** → `FeedbackWorkOrder` (:590). OPERATIONS_ROLES. Body `FeedbackWorkOrderCloseRequest`. `complete_work_order(...)`; `ValueError` → 404 `FEEDBACK_WORK_ORDER_NOT_FOUND`. Marks `completed` + stamps `closure_ref` on originating item (REQ-FB-004).

---

## 18. bundles.py (7 endpoints, P5 W20)

`router = APIRouter(prefix="/api/v1", tags=["Bundles"])` (:57). All auth `get_current_user`. Membership via `_load_bundle_with_portfolio_check` (:98: `get_bundle` then `verify_portfolio_access(detail.portfolio_id)`).

1. **GET /me/bundles** → `list[BundleSummary]` (:65). Query `status`, `scope_kind`, `application_id`, `wave_id`, `mine_only`(False), `limit`(100 ge1 le500), `offset`. `filter_portfolio_ids_by_membership` → `bundle_svc.list_bundles(...)`.
2. **GET /bundles/{bundle_id}** (UUID) → `BundleDetail` (:108). `_load_bundle_with_portfolio_check`.
3. **GET /bundles/{bundle_id}/audit** → `BundleAuditNarrative` (:117). membership pre-check then `get_audit_narrative`.
4. **POST /bundles/{bundle_id}/claim** → `BundleDetail` (:133). Body optional `BundleClaimRequest`. membership check first (avoid FOR UPDATE on unseen row); `bundle_svc.claim(...)` — 409 if already claimed by another; idempotent same-caller.
5. **POST /bundles/{bundle_id}/release** → `BundleDetail` (:153). Body optional `BundleReleaseRequest`. `release(..., is_admin=user.has_role(PORTFOLIO_ADMIN), reason=...)`. Owner-only (admin override).
6. **POST /bundles/{bundle_id}/validate** → `BundleValidationResult` (:171). Body `BundleSubmitRequest`. Dry-run `validate_payload` — no state change.
7. **POST /bundles/{bundle_id}/submit** → dict (:187). Body `BundleSubmitRequest`, `Response`. `submit(...)`; if `not result.valid` → **422 `BUNDLE_VALIDATION_FAILED`** with `details={violations, bundle}` (stays claimed); else `response.status_code=200`, return `{bundle, validation}`.

---

## 19. admin_bundles.py (2 endpoints, P5 W20)

`router = APIRouter(prefix="/api/v1/admin", tags=["Admin"])` (:36). Both `require_role(RBACRole.PORTFOLIO_ADMIN)`.

1. **POST /portfolios/{portfolio_id}/bundles** → `BundleDetail`, status 201 (:39). Body `BundleDispatchRequest`. `bundle_contract.resolve(...)`; if `contract.metadata.portfolio_id != portfolio_id` → **400 `BUNDLE_PORTFOLIO_MISMATCH`**; else `bundle_svc.dispatch(...)`; return `get_bundle`.
2. **POST /bundles/{bundle_id}/force-release** → `BundleDetail` (:87). Body optional `BundleReleaseRequest`. `release(..., is_admin=True, reason=body.reason or "admin force-release")`. Audited.

---

## 20. renditions.py (2 endpoints)

`router = APIRouter(prefix="/api/v1/applications", tags=["Renditions"])` (:37). **No RBAC dependency.** Inline enum `RenditionType` (:40 requirements_doc/architecture_deck/test_report), `TEMPLATE_MAP` (:48), models `GenerateRenditionRequest`/`RenditionRecord`/`GenerateRenditionResponse`/`ListRenditionsResponse`. `_load_app` (:104), `_row_to_record` (:91).

1. **POST /{app_id}/renditions/generate** → `GenerateRenditionResponse`, **status 202** (:119). Body `GenerateRenditionRequest`. Deps `get_db`, `get_temporal_client`, `get_config`. `_load_app`; None → 404. INSERT `pending` `rendition` row (id uuid4, `workflow_id=f"rendition-{id}"`); commit; `temporal.start_workflow("RenditionWorkflow", {rendition_id, app_id, rendition_type, template_name, artifact_repo, application_name}, id=workflow_id, task_queue=config.temporal_task_queue)`. Async+durable (worker renders + updates row to completed/failed). Returns pending record + poll message.
2. **GET /{app_id}/renditions** → `ListRenditionsResponse` (:200). `SELECT ... FROM rendition WHERE application_id ORDER BY created_at DESC` including `content`.

---

## 21. reusable_parts.py (6 endpoints, P7-S16.11)

`router = APIRouter(prefix="/api/v1/reusable-parts", tags=["Reusable Parts"])` (:67). Platform-global (not portfolio-scoped). `VIEWER_PLUS` (:45, incl SERVICE), `CURATOR_ROLES` (:59) = TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN. `_parse_entry_id` (:70, bad UUID → 404 `PART_NOT_FOUND`).

1. **GET ""** → `CatalogListResponse` (:79). VIEWER_PLUS. Query `kind`, `status`, `q`, `owner_scope`(tenant_private|firm_wide|contract_spec), `eval_status`(current|stale|absent), `control`, `limit`(50 ge1 le200), `offset`. `parts_svc.list_catalog(...)`.
2. **POST ""** → `CatalogEntry`, status 201 (:120). auth CURATOR. Body `RegisterPartRequest`. `register_part(db, body, user.sub)` (draft).
3. **GET /{entry_id}** → `CatalogEntryDetail` (:130). VIEWER_PLUS. `get_entry(db, uuid)` (entry + review history + live gate decision).
4. **POST /{entry_id}/security-review** → `RecordReviewResponse`, status 201 (:140). CURATOR. Body `RecordReviewRequest`. `role = user.roles[0].value if user.roles else None`; `record_review(db, id, body, user.sub, reviewer_role=role)`.
5. **POST /{entry_id}/publish** → `PublishResponse` (:162). CURATOR. `publish_part(db, id, user.sub)` — GATED: 409 `PUBLICATION_BLOCKED` unless latest review approving+finding-free+covers scanner classes AND evals current.
6. **POST /{entry_id}/consume** → `ConsumeResponse` (:177). VIEWER_PLUS. Body `ConsumeRequest`. `facets_svc.consume_part(...)` — GATED: 409 `SCOPE_FORBIDDEN` outside permitted scope/classification (REQ-AC-007); records consumer.

---

## 22. human_paired_agent.py (3 endpoints, PR#5 P5)

`router = APIRouter(prefix="/api/v1", tags=["Human-Paired Agent"])` (:37). All `get_current_user`.

1. **GET /me/tasks** → `MyTasksResponse` (:40). Query `include_claimable`(True), `portfolio_id`, `limit`(50 ge1 le200). `hpa_service.list_my_tasks(db, human_user_id=user.sub, ...)`.
2. **POST /agent-tasks/{task_id}/return** → `TaskReturnResponse` (:80). Body `TaskReturnRequest`. `return_task(db, task_id, payload, human_user_id=user.sub)`. Two-layer validation (structural always-on; strict output-spec via jsonschema when skill declares `output_schemas`). **On `validation_errors` → `db.rollback()` else `db.commit()`** (:122). Failures surface in `validation_errors` (soft rollback); strict violation → `OUTPUT_SPEC_VIOLATION` 400 (raised in service).
3. **GET /agent-tasks/{task_id}/audit-narrative** → `TaskAuditNarrative` (:129). `render_task_audit_narrative(db, task_id)` (actor-mode discriminator).

---

## 23. artifacts.py (4 mounted endpoints, P4-S1.5)

`router = APIRouter(prefix="/api/v1/artifacts", tags=["Artifacts"])` (:55). `VIEWER_PLUS` (:38), `TECH_PLUS` (:49) = TECH_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN. Inline models `ArtifactSummary`/`Content`/`Version`/`ValidateRequest`/`ValidateResponse`. Helpers: `_guess_type` (:126 by suffix), `_canonical_line` (:133), `_gate_evidence_artifacts` (:140, walks `gate.evidence_data` passes/steps → file/main artifact paths using `{line_prefix}/{scope}/files/{unit}/{file}` layout, imports `_STEP_BASED_LINE_CONFIG` from services.gate), `_load_app` (:234), `_git_service` (:249, None when repo/token missing → empty-state degrade).

1. **POST /validate** → `ArtifactValidateResponse` (:275). auth **TECH_PLUS**. Body `ArtifactValidateRequest`. Light structural check: `json.dumps(content)` serializable; required-by-type (`catalog`/`disposition`→`version`, `pattern`→`id,name`).
2. **GET /{app_id}** (dep `require_application_member`) → dict (:311). VIEWER_PLUS. Query `line`, `step`, `type`. `_load_app` 404 `APP_NOT_FOUND`. Sources: (1) `step_execution.output_artifacts` join agent_task for skill_id, dedup by content_hash|path; (2) `_gate_evidence_artifacts` (Discovery). Server-side filters. Empty → `{"data":[], "empty_state":True, "reason":"no_artifacts_yet"}`.
3. **GET /{app_id}/{artifact_path:path}/history** (dep member) → dict (:426). VIEWER_PLUS. `_load_app` 404; git svc None → `{"data":[]}`; else `svc._repo.get_commits(path=f"discovery/{app_id}/{artifact_path}")`, first 25 → `ArtifactVersion` list (tz-normalize naive to UTC); any exception → `{"data":[]}`.
4. **GET /{app_id}/{artifact_path:path}** (dep member) → `ArtifactContent` (:476). VIEWER_PLUS. `_load_app` 404; git svc None → 503 `ARTIFACT_REPO_UNAVAILABLE`. Path: use as-is if starts with known line prefix (`known_prefixes` :506), else `discovery/{app_id}/{path}`. `svc.read_file(full_path, branch="main")`; GitServiceError "not found" → 404 `ARTIFACT_NOT_FOUND`, else 502 `GIT_READ_FAILED`. `.json` parse heuristic → `schema_valid`.

GOTCHA (:426 before :476): history route mounted BEFORE the bare `{artifact_path:path}` so `/history` suffix isn't swallowed.

---

## 24. auth.py (multiple; P4-S1.11)

`router = APIRouter(prefix="/api/v1/auth", tags=["Auth"])` (:69). In-memory PKCE store `_OIDC_STATES` + `_OIDC_STATE_TTL` (`OIDC_STATE_TTL` env, default 300s) (:258). `_ROLE_DESCRIPTIONS` (:383).

1. **POST /service-token** → `ServiceTokenResponse` (:91). No auth dep. Body `ServiceTokenRequest`(service, provisioning_secret, ttl_seconds default `DEFAULT_TTL_SECONDS` gt0 le86400). Validates `SERVICE_TOKEN_PROVISIONING_SECRET` env (401 if missing/mismatch); unknown service → 400; `issue_service_token`.
2. **POST /login** → `TokenResponse` (:129). Body `LoginRequest`. `get_user_by_login`; None/inactive → 401 `INVALID_CREDENTIALS`; `identity_provider != "local"` → 401 `SSO_USER`; `verify_password` fail → 401. `record_login`; commit; `_profile_to_token`.
3. **POST /logout** → `{"success":True}` (:161). Stateless.
4. **GET /me** → `UserProfile` (:176). auth `get_current_user`. `get_user(uuid(sub))`; None → synthesized profile (zero-uuid, `{sub}@local`, roles from token) for service/dev-bypass.
5. **GET /config** → `AuthModeConfig` (:220). No auth. `get_identity_config()`; None → local-only; else local+oidc with provider id/label/login url. Never emits secrets.
6. **GET /oidc/login** → RedirectResponse 302 (:287). `_require_oidc_config` (404 `OIDC_DISABLED` when disabled); build PKCE + `state=secrets.token_urlsafe(32)`; store; redirect to IdP authorize url.
7. **GET /oidc/callback** → TokenResponse or 302 (:308). Query `code`, `state`, `error`. `error` → 400 `OIDC_PROVIDER_ERROR`; missing code/state → 400 `OIDC_MISSING_PARAMS`; unknown state → 400 `OIDC_UNKNOWN_STATE`; `exchange_code` + `validate_id_token` (`OIDCAuthError` → 401 `OIDC_AUTH_FAILED`); `upsert_oidc_user`; `record_login`; commit. If `entry.redirect_after` → 302 to `{url}#access_token=...&expires_in=...`; else JSON token.

Spec-alias endpoints (:405–450, all `require_role(PORTFOLIO_ADMIN)`):
8. **GET /roles** → `{data:[...]}` (:405).
9. **GET /users** → paginated (:417) — alias for `GET /users`.
10. **PUT /users/{user_id}/roles** → `UserProfile` (:437). Body `RoleAssignmentRequest`. `update_user(roles=...)`; None → 404 (with rollback).

---

## 25. users.py (6 endpoints, P4-S1.11)

`router = APIRouter(prefix="/api/v1/users", tags=["Users"])` (:45). `_is_self` (:48), `_require_admin_or_self` (:52, 403 `FORBIDDEN` otherwise).

1. **GET ""** → paginated (:67). auth `require_role(PORTFOLIO_ADMIN)`. Query `include_inactive`(False). `list_users`.
2. **GET /{user_id}** (UUID) → `UserProfile` (:88). auth `get_current_user` + `_require_admin_or_self`. 404 `USER_NOT_FOUND`.
3. **POST ""** → `UserProfile`, status 201 (:107). ADMIN. Body `UserCreateRequest`. `create_user`; `ValueError` → 400 `USER_INVALID` (rollback); `IntegrityError` → 409 `USER_CONFLICT` (rollback).
4. **PUT /{user_id}** → `UserProfile` (:140). get_current_user + admin_or_self. Body `UserUpdateRequest`. **Admin-only fields**: `roles`/`is_active` — non-admin setting either → 403 `ADMIN_ONLY`. `update_user`; None → 404; `IntegrityError` → 409.
5. **DELETE /{user_id}** → 204 (:180). ADMIN. Self → 400 `CANNOT_DELETE_SELF`; `deactivate_user` (soft is_active=false); not ok → 404; commit.
6. **POST /{user_id}/password** → 204 (:208). get_current_user + admin_or_self. Body `PasswordUpdateRequest`. Non-admin self-service must supply correct `current_password` (verify via `get_user_by_login(sub)` fallback to id lookup) else 401 `INVALID_CREDENTIALS`; admin resets without current. `set_password`; `LookupError`→404, `ValueError`→400 `PASSWORD_NOT_APPLICABLE`; commit.

---

## 26. me.py (1 endpoint, P5 W20)

`router = APIRouter(prefix="/api/v1/me", tags=["Me"])` (:27).

1. **GET /portfolios** → `list[MyPortfolioListItem]` (:30). auth `get_current_user`. If `user.has_role(PORTFOLIO_ADMIN)` → all portfolios (`SELECT id, name, :role, created_at FROM portfolio ORDER BY name`, role forced portfolio_admin). Else `portfolio_membership` join portfolio (`WHERE m.user_id=:uid`).

---

## 27. health.py (4 endpoints)

`router = APIRouter(tags=["health"])` (:25) — no prefix, no auth.

1. **GET /health** → dict (:33). status/service/version/timestamp.
2. **GET /health/detailed** → dict (:44). Checks DB (`SELECT 1` + latency_ms), Temporal (`check_health`), skills (`get_skill_count`). `overall="ok"` only if all deps ok else `degraded`.
3. **GET /health/temporal** → dict (:90). Temporal connectivity; error object on failure (never raises).
4. **GET /health/ready** → dict (:114). Temporal + skills; `status="ready"` only when both ok else `not_ready`.

---

## 28. system.py (4 endpoints, P4-S1.12)

`router = APIRouter(tags=["System"])` (:41) — no prefix, no auth. `_PROCESS_START = time.monotonic()` (:44).

1. **GET /health/live** → dict (:56). Liveness (no dep checks).
2. **GET /system/info** → dict (:76). `active_profile()` id, `OLYMPUS_ENVIRONMENT` deployment, temporal_namespace, version.
3. **GET /system/metrics** → `Response` text/plain Prometheus (:164). `_render_prometheus(collect_metrics(), config)` (:107): emits `olympus_api_info`, `_uptime_seconds`, `_skills_loaded`, `_requests_total{method,path,status}`, `_request_duration_seconds` summary sum/count, `_rate_limited_total`. Unauthenticated (restrict at ingress).
4. **GET /system/dependencies** → dict (:181). Richer Admin shape: DB latency, temporal (host/namespace/ui_url), skills count; overall ok/degraded. No auth.

---

## 29. activity.py (1 endpoint)

`router = APIRouter(prefix="/api/v1/activity", tags=["Activity"])` (:18).

1. **GET /recent** → `list[dict]` (:21). auth `get_current_user`. Query `limit`(20), `portfolio_id`. If portfolio_id → `verify_portfolio_access`; `member_ids = filter_portfolio_ids_by_membership`. If `member_ids == []` return `[]`. Builds app + gate WHERE with `ANY(:pf_ids)` and/or `:portfolio_id`. Query recent `application` updates + `gate` decisions; merges into reverse-chron timeline (`app_status_change` + `gate_activity` with per-status descriptions); sort by timestamp desc; slice `[:limit]`. `_format_status` (:122).

---

## 30. admin.py (1 endpoint)

`router = APIRouter(prefix="/api/v1/admin", tags=["Admin"])` (:38). `_SAMPLE_APPS` (:64) = 12 hand-curated apps (archetype/risk_tier/complexity/line/status/disposition). `_is_enabled` (:188), `_unique_portfolio_name` (:201, suffixes `(2)..(99)` then hex).

1. **POST /seed-sample-portfolio** → `SeedSamplePortfolioResponse`, status 201 (:223). auth `require_role(PORTFOLIO_ADMIN)`. Body `SeedSamplePortfolioRequest` (optional name). If `not _is_enabled()` (prod requires `ALLOW_SAMPLE_PORTFOLIO=true`) → 403 `SAMPLE_PORTFOLIO_DISABLED`. INSERT portfolio (`artifact_repo_url="olympus/sample-portfolio-demo"`, owner "demo"); per app: INSERT application + a `score_history` overall row (tier→score map {1:.38,2:.62,3:.78}); commit. Sync in-memory `_portfolios` cache. Returns portfolio + app_ids.

---

## 31. admin_audit.py (1 endpoint, P6-S6.6)

`router = APIRouter(prefix="/api/v1/admin", tags=["Admin"])` (:31).

1. **GET /audit-log** → dict (paginated) (:34). auth `require_role(PORTFOLIO_ADMIN, PORTFOLIO_MANAGER)`. Query `portfolio_id`, `event_type` (validated against `audit_svc.EVENT_TYPES` → 400 `AUDIT_EVENT_TYPE_INVALID`), `actor`, `from`(alias from_ts), `to`(alias to_ts), pagination. `audit_svc.query_audit_events(...)`; `paginated_response`. Event types: approval/rejection/escalation/force_advance/membership_grant.

---

## 32. events.py (WebSocket + SSE + outbox)

`router = APIRouter(prefix="/api/v1/events", tags=["Events"])` (:29). `ConnectionManager` (:36, in-memory ws list + sse queues, `broadcast(event_type, payload)` JSON with timestamp, drops dead ws). Module singleton `manager` (:86).

1. **WS /ws** (:94). `connect_ws`; loop `receive_text`; `ping`→`pong`; disconnect on `WebSocketDisconnect`.
2. **GET ""** → SSE `StreamingResponse` (:130). auth `get_current_user_sse` (401 before stream; token may be `access_token` query param since EventSource can't set headers). `event_stream` yields from queue with 15s keepalive; removes queue on finally.
- `outbox_event_sink(event_type, payload)` (:174): forwards to `manager.broadcast` (the EventSink for the drainer; raising → at-least-once retry).
- `drain_events_outbox(db, *, batch_size=100, owner_scope=None, profile_id=None)` (:185): `drain_outbox(db, outbox_event_sink, ...)` — single drain invocation (cron is ops concern). Scope filter avoids mismatched profile delivery (REQ-EO-009).

---

## 33. git.py (1 endpoint)

`router = APIRouter(prefix="/api/v1/git", tags=["Git"])` (:32). `MANAGER_ROLES` (:35) = PORTFOLIO_MANAGER, PORTFOLIO_ADMIN.

1. **GET /repo-available** → `RepoAvailableResponse` (:49). auth MANAGER_ROLES. Query `repo` (owner/name). Slug validation (`"/" not in repo or count!=1`) → 400 `INVALID_REPO_SLUG`. `config.github_token` missing → 503 `GIT_TOKEN_MISSING`. `GitService(config)`: `GitServiceError` with "not found"/"404"/"does not exist" → `available=True`; other → 500 `GIT_CHECK_FAILED`; generic Exception caught (PyGithub) similarly. **Construction success ⇒ repo exists ⇒ `available=False, reason="repo exists"`**. Semantics inverted: available=True means safe-to-create.

---

## 34. runs.py (1 endpoint, P10-W1 REQ-PS-010)

`router = APIRouter(prefix="/api/v1/runs", tags=["Runs"])` (:52). `VIEWER_PLUS` (:43) = VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, PORTFOLIO_ADMIN (note: **no SAFETY_BOARD/PORTFOLIO_MANAGER** here). Inline `OutputProvenance`/`InputProvenanceEntry`/`RunProvenanceResponse`. `_resolve_run_scope(db, run_id)` (:100): `(app_id, wave_id, exists)` from `agent_task WHERE workflow_id=:run_id` (with app/wave non-null) else `input_provenance WHERE run_id`; None → `(None,None,False)`.

1. **GET /{run_id}/provenance** → `RunProvenanceResponse` (:137). auth `get_current_user` + `require_role(*VIEWER_PLUS)`. `_resolve_run_scope`; not exists → 404 `RUN_NOT_FOUND`. Scope enforce (unless PORTFOLIO_ADMIN short-circuit): app_id → `verify_application_portfolio_access` elif wave_id → `verify_wave_portfolio_access`. `get_output_attributions` + `get_input_provenance`; map to models. `producing_skill` null when unrecorded (never fabricated, REQ-PS-006).

---

## 35. webhooks.py (1 endpoint)

`router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])` (:30). `_verify_signature(payload, signature, secret)` (:38, HMAC-SHA256 `sha256=<hex>`, `hmac.compare_digest`). `_workflow_id_from_branch` (:55, `olympus/{line}/{app_id}/{step}` → `{line}-{app_id}`), `_gate_id_from_branch` (:67, step segment).

1. **POST /github** → dict (:84). Headers `X-Hub-Signature-256`, `X-Github-Event`. No RBAC (signature-gated). Parse body JSON. Multi-repo: `find_portfolio_by_repo(repository.full_name)` → per-portfolio `webhook_secret` else global `config.github_webhook_secret`; if secret set and signature invalid → 401. Routes:
   - `pull_request_review` + `submitted`: state `approved` → signal `gate_approved`; `changes_requested` → `gate_rejected` (via `temporal.get_workflow_handle(wf).signal(...)`, RPCError → warn + `signal_error`).
   - `pull_request` + `closed` + merged → `gate_approved` (merge = approval).
Returns `{received, event, action, [signal, workflow_id, gate_id, signal_error]}`.

---

## 36. workflow_signals.py (1 endpoint, task #86)

`router = APIRouter(prefix="/api/v1/workflow-signals", tags=["Workflow Signals"])` (:35). `VIEWER_PLUS` (:23, 8 roles). Inline `PendingSignalEntry`/`PendingSignalsResponse`.

1. **GET /pending** → `PendingSignalsResponse` (:56). auth VIEWER_PLUS. Query `workflow_id`, `limit`(100 ge1 le500). `signal_inbox.list_pending(db, workflow_id, limit)` → entries. NO POST (only writer is the API's dispatch path).

---

## 37. workflows.py (4 endpoints)

`router = APIRouter(prefix="/api/v1/workflows", tags=["Workflows"])` (:30).

1. **GET ""** → `WorkflowListResponse` (:33). No auth dep. Query `limit`(50 ge1 le200). `workflow_health.list_workflows(db, temporal, config, limit)` (running + recently-failed, cap per group).
2. **GET /{workflow_id}** → `WorkflowDetail` (:44). No auth dep. `get_workflow_detail(db, workflow_id, temporal, config)` (failure drill-in if failed).
3. **POST /{workflow_id}/restart** → `WorkflowActionResponse`, status 202 (:55). auth `require_role(OPERATIONS_LEAD, PORTFOLIO_ADMIN)`. `restart_workflow(...)` (fresh run, same type+input, new workflow_id).
4. **POST /{workflow_id}/fail** → `WorkflowActionResponse` (:74). auth OPERATIONS_LEAD, PORTFOLIO_ADMIN. Body optional `WorkflowActionRequest` (reason). `fail_workflow(db, workflow_id, temporal, reason)` (terminate).

---

## Appendix — cross-router shared auth constants

- `evidence_ledger.LEDGER_READ_ROLES` (VIEWER-plus, 8 roles) and `LEDGER_RATIFY_ROLES` (COMPLIANCE_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN) are imported by: autonomy, autonomy_incidents, drift_control, evidence_runs, evals, capabilities. Rebuild them once in evidence_ledger.py and import.
- `agent_runs.py` GET `/api/v1/agent-runs/recent-errors` (agent-runs domain, likely Parts 1–2 scope) exists — 1 endpoint, `AgentRunErrorListResponse`, portfolio-scoped via `filter_portfolio_ids_by_membership` (:26).
