# 05 — Dashboard Components (Part 2): NL Console + Autonomy Ops + Shell + GateReview group

Continues Part 1. Paths relative to `dashboard/src`.

---

# NEW SUBSYSTEM: pages/nl-console/ (NL Action Console)

The conversational action engine surface (W6 / U1). Files: `NlActionConsole.tsx` (headline),
`CapabilityGallery.tsx`, `ActionPlanList.tsx`, `ConfirmActionModal.tsx`, `StagedGateCard.tsx`,
`InlineArtifact.tsx`, `ToolActivity.tsx`, `icons.tsx`, `streamMock.ts`, `index.ts`, `nl-console.css`.

Design axioms enforced everywhere: reversible actions run immediately; high-stakes actions block on a
confirmation modal; gate decisions are STAGED for a human (the agent NEVER decides — REQ-NL-004); tiers
are read straight off the SERVER plan (UI never hard-codes which are high-stakes, REQ-UNAC-001/003);
state conveyed by icon + text, not color (REQ-UNAC-007).

## nl-console/NlActionConsole.tsx (default export `NlActionConsole`)

The full conversational experience. Consumes `../../api/client`: `clearChatHistory, confirmChatAction,
getAuthToken, streamAgentAction` + types `NlActionResponse, NlArtifactEvent, NlCapability,
NlPlannedAction`. Hooks: `usePortfolioContext`, `useWebSocket`, `useNavigate`.

Module-level: `confirmCounter` + `newConfirmationId()` → `confirm-${Date.now()}-${n}` (`:53`).
`navLabel(page,route)` (`:81`): `"Open {Title Cased page}"` else `"Open {route}"`.

Thread persistence (`:94`): `THREAD_STORE_PREFIX="olympus:nlc:thread:"`. `currentUserKey()` (`:97`)
decodes the JWT `sub` claim (base64 middle segment) or "anon". `threadStoreKey(contextId)` =
`${prefix}${userKey}:${contextId}` — scoped per USER per portfolio (switching accounts in a tab never
leaks another user's conversation). `loadTurns` (`:112`): parse sessionStorage; **settles any persisted
`streaming:true` back to false** (`:118`). `saveTurns` swallows quota errors.

`Turn` interface (`:67`): `{id, userMessage, response:NlActionResponse|null, streamingReply:string,
streaming:bool, toolActivity:ToolActivityRow[], artifacts:NlArtifactEvent[], navOffers:NavOffer[]}`.
`NavOffer = {route,label}` — agent-suggested navigations rendered as click-to-go chips, NEVER
auto-followed (`:59`, `:281`) since the console is a route (auto-jump would unmount the thread).

State (`:133`): `contextId = activePortfolio?.id ?? "default"`, `message`, `turns` (init `loadTurns
(contextId)`), `pending:NlPlannedAction|null`, `busy`, `error`; refs `threadRef`, `textareaRef`.
Effects: reload turns on `contextId` change (`:148`); persist turns on change (`:152`); autoscroll to
bottom on `[turns,busy]` — uses `el.scrollTo({behavior:"smooth"})` with a jsdom `scrollTop` fallback
(`:179`).
`sessionId` memo (`:157`): first turn's `response.session_id` (threads conversational state).
`useWebSocket({eventTypes:["task.started","task.completed","task.failed","gate.ready",
"app.status_changed"], maxEvents:40})` → `{events, connected}` (live enrichment; non-fatal if down).

`runMessage(raw)` (`:192`): trims (no-op on empty); appends a new Turn (streaming:true); clears message;
sets busy. Calls `streamAgentAction({context_type:"portfolio", context_id, message, session_id},
callbacks)`. Callbacks mutate the matching turn: `onToken` appends to `streamingReply`; `onToolCall`
pushes a `running` ToolActivityRow; `onToolResult` marks the matching row `done` w/ ok+summary;
`onArtifact` appends artifact; `onNavigate` pushes a NavOffer (guarded `if(!n.route)return`); `onPlan`
sets `response`; `onDone` sets streaming:false, busy:false, refocuses textarea; `onError` sets a
user-facing "action engine unavailable — took no action" error, REMOVES the turn, unbusy, refocus.
`submit()` = `runMessage(message)`.
`confirmAction(turnId,action)` (`:336`): only reached from an explicit modal Confirm. Calls
`confirmChatAction({session_id, intent_id, intent_text, action_seq:action.seq, action_id, action_params:
action.params, confirmation_id:newConfirmationId()})`; replaces the matching action (by `seq`) with
`resp.actions[0]`; success/error toast; clears `pending`, unbusy.
`useExample(example)` sets message + focus. `clearConversation()` (`:391`): clears turns + error; fires
best-effort `clearChatHistory("portfolio", contextId, "nl-action")` (so the backend transcript the agent
replays is wiped too — else the model "remembers"); local reset always happens.

Render (`:403`): `<section className="nlc">`. Hero (AgentAvatar, title, subtitle, "New conversation"
button when `hasThread`, and a Live/Offline pill from `connected`). Error `role="alert"`. Thread
(`ref=threadRef`): if `!hasThread` ⇒ `<CapabilityGallery onPickExample={useExample}>`; else `<ol>` of
turns — each turn = user bubble + agent bubble containing (in order) `<ToolActivity>` (when rows>0),
reply block (`AgentMarkdown` of `response.reply||response.summary` OR `streamingReply`; a blinking cursor
while streaming pre-plan; else a "Thinking…" dots block), `<InlineArtifact>` per artifact, a nav-offers
`<ul>` (each button `navigate(route)`), inline `<CapabilityChips>` when `response.capabilities` present,
and `<ActionPlanList actions liveEvents={events} onRequestConfirm=(a)=>setPending(a)>`. Composer form:
a textarea (Enter submits, Shift+Enter newline, disabled while busy) + a submit button (spinner/label
flips on busy, disabled when busy or empty). When `pending`, renders `<ConfirmActionModal action=pending
onConfirm=... onCancel=()=>setPending(null)>` (onConfirm finds the owning turn by matching `seq` then
calls `confirmAction`).
`CapabilityChips({capabilities,onPick})` (`:620`): `<ul>` of `<button title=cap.description
onClick=onPick(cap.example)>` rendering `cap.label` + "Try it →".

## nl-console/CapabilityGallery.tsx (default `CapabilityGallery`)
Props: `{onPickExample:(example)=>void}`. Inviting empty state. Static `ITEMS` (`:32`): 6
`{title,blurb,example,kind:"reversible"|"high_stakes"|"gate"}`. `TierGlyph({kind})` → HighStakes/Gate/
Reversible icon. `tierLabel(kind)` → "Confirms first"/"You decide"/"Runs now". Render: intro + a grid of
cards; each card button `onClick=onPickExample(item.example)` shows glyph, tier label, title, blurb, and
the example phrasing. These are a discovery affordance; the AUTHORITATIVE list comes from the server on
"what can you do?".

## nl-console/ActionPlanList.tsx (default `ActionPlanList`)
Props: `{actions:NlPlannedAction[], onRequestConfirm:(action)=>void, liveEvents?:RealtimeEvent[]}`.
`tierMeta(tier)` (`:42`): `high_stakes`→{text:"High-stakes",HighStakesIcon,is-highstakes};
`gate_decision`→{"Gate · you decide",GateIcon,is-gate}; else {"Reversible",ReversibleIcon,is-reversible}.
`STATUS_TEXT` (`:62`) maps 7 statuses (planned→"Planned", executed→"Done", awaiting_confirmation→"Needs
confirmation", staged→"Staged for you", needs_input→"Needs details", denied→"Not authorised",
failed→"Failed"). `resultId(action)` (`:72`): `result.workflow_id ?? id ?? app_id ?? portfolio_id`.
`resultText` (`:79`): "Result: {id}" or (denied) "Denied (403): {detail}". `liveStatusFor(action,events)`
(`:95`): scans events for one whose payload contains `resultId`; maps task.completed→done "Completed",
task.failed→failed "Failed", task.started→running "Running…", gate.ready→done "Gate ready".
Render: empty ⇒ null. `<ol>` of `<li>` cards keyed `action.seq`, class carries tier + `status-{status}` +
`is-running`. Each: label + tier chip (`data-testid=nl-tier-{action_id}`), status row (CheckIcon when
executed, sr-only raw status + humanized `STATUS_TEXT`, plus a live pill when `liveStatusFor` returns),
result `<p>`, and per-status blocks: `awaiting_confirmation` ⇒ explanation + "Review & confirm" button
(→ `onRequestConfirm`); `needs_input` ⇒ explanation; `staged` ⇒ `<StagedGateCard action>`.

## nl-console/ConfirmActionModal.tsx (default `ConfirmActionModal`, LOAD-BEARING REQ-UNAC-003)
Props: `{action:NlPlannedAction, onConfirm, onCancel}`. Refs `dialogRef`, `confirmRef`. Effect focuses
`confirmRef` on mount (focus-trap entry). `onKeyDown` (`:40`): Escape ⇒ onCancel; Tab ⇒ wrap focus within
dialog's focusables (shift+Tab from first→last, Tab from last→first). Backdrop click (target===currentTarget)
⇒ onCancel. Renders `role="dialog" aria-modal` with title "⚠️ Confirm high-stakes action", a description
("{label} is a high-stakes action and will not run until you confirm." + optional explanation), a `<dl>` of
`action.params` (each `String(v)`), and Cancel (outline) + "Confirm & run" (`data-testid=nl-confirm-execute`)
buttons. NEVER executes itself — reports the decision up.

## nl-console/StagedGateCard.tsx (default `StagedGateCard`, LOAD-BEARING REQ-UNAC-004)
Props: `{action}`. `gateId = String(action.params?.gate_id ?? "")`. Renders a "Staged for your decision"
Tag (🔒), the action label, the agent's explanation (fallback text), and — the ONLY control — a `<Link to=
/gates/${gateId}/review>` "Review & decide (human)" when gateId present, else a "Open the gate queue" note.
Deliberately NO approve/reject button — the agent never decides a gate.

## nl-console/InlineArtifact.tsx (default `InlineArtifact`)
Props: `{artifact:NlArtifactEvent}`. Renders an agent-surfaced artifact inline via the SHARED
`<ArtifactViewer>` (from `../../components/viewers/ViewerRegistry`). `artifactType = artifact_type ??
"file_artifact"`, `data = artifact.content ?? {}`, `schemaVersion = data.schema_version ?? "1.0"`. Renders
a `<figure>` with an optional path figcaption (📄 + path) and `<ArtifactViewer artifactType data
metadata=null schemaVersion appId={artifact.app_id}>`. Unknown types degrade via the registry +
ViewerErrorBoundary — no new viewer code.

## nl-console/ToolActivity.tsx (default `ToolActivity`; exports `ToolActivityRow`)
`ToolActivityRow = {id, name, kind:"read"|"navigate", ok?, summary?, status:"running"|"done"}`.
`kindIcon` → navigate 🧭 / read 🔍. Props `{rows}`. Empty ⇒ null. `<ul aria-live="polite">` of rows; each
row shows kind icon + name + a state: running ⇒ spinner + "Working…"; done ⇒ mark (✕ when `ok===false`
else ✓) + `summary ?? (failed?"Couldn't complete":"Done")`. `data-status` reflects status. Icon+text,
never color alone.

## nl-console/icons.tsx
Inline SVGs (theme-aware via `currentColor`, all `aria-hidden`): `AgentAvatar({small})` hexagon spark
(28/44px), `SparkIcon`, `SendIcon`, `ReversibleIcon` (circular arrows), `HighStakesIcon` (shield-alert),
`GateIcon` (lock), `CheckIcon` (checkmark). All accept `{className}`.

## nl-console/streamMock.ts (TEST HELPER — not runtime)
`fakeStream(resp)` (`:24`): returns `(_body,cbs)=>{ cbs.onToken(reply||summary); cbs.onPlan(resp);
cbs.onDone?.(); return new AbortController(); }`. `failingStream()` (`:34`): calls `cbs.onError?.(new
Error("boom"))`. `fakeAgentStream(resp,opts)` (`:45`): replays toolCalls→toolResults→artifacts→
navigations→tokens (default `[reply||summary]`)→onPlan→onDone in that order. Compatible with both
`streamChatAction` and `streamAgentAction`.

## nl-console/index.ts
Barrel: `export { default } from "./NlActionConsole"`.

---

# NEW SUBSYSTEM: pages/autonomy-ops/AutonomyOps.tsx (default `AutonomyOps`)

Read-only operator + accrediting-official live view of autonomy posture (P9-S17.5). NO mutations.
Client-blind: tier labels/levels rendered from the API; framework-neutral tier ids `tier_1..tier_3`.
Consumes `../../api/autonomy`: `getAutonomyStatus, getAutonomyIncidents, autonomyLevelLabel,
triageDecisionLabel, captureSourceLabel` + types `AutonomyStatusPage, IncidentPage, LoopPatternStatus,
EscalationRecord, IncidentRecord`. Hooks: `usePortfolioContext`. Uses `EmptyState`.

`RISK_TIER_OPTIONS` (`:51`): `""`="All tiers (no cap resolution)", `tier_1`="Tier 1 (highest criticality)",
`tier_2`, `tier_3`. `formatWhen(iso)` (`:59`): "—" on falsy, raw on NaN, else `toLocaleString()`.

State (`:368`): `profileChoice:string|null` (null = default to active portfolio; "" = explicit all),
`riskTier:string` (init ""), `status:AutonomyStatusPage|null`, `incidents:IncidentPage|null`, `loading`
(true), `statusError`, `incidentsError`. `effectiveProfileId = profileChoice ?? activePortfolioId ?? ""`
resolved during render (no seeding effect — avoids cascading setState).

Effect (`:383`, deps `[effectiveProfileId, riskTier, portfolioLoading]`): early-return while
`portfolioLoading`. `Promise.allSettled([getAutonomyStatus({profileId, riskTier}), getAutonomyIncidents
({profileId})])` — each surface fetched independently so one failing doesn't blank the other; each
fulfilled ⇒ setState, each rejected ⇒ null + per-panel error message.

Derived: `loopPatterns = status?.loop_patterns ?? []`, `escalations = status?.open_escalations ?? []`,
`incidentRows = incidents?.incidents ?? []`, `ladder = status?.readiness_ladder ?? []`, `cappedCount` =
`loopPatterns.filter(p=>p.capped).length`.

Render: loading OR portfolioLoading ⇒ `<OpsSkeleton>`. Else `<section>`: h1, intro, filter row (Profile
`<select>` from `portfolios` + "All profiles", Risk-tier `<select>` from RISK_TIER_OPTIONS), a 3-card
summary grid (Loop patterns count + "{cappedCount} capped by tier"; Open escalations
`status?.open_escalation_count ?? escalations.length`; Open incidents `incidents?.open_incident_count ??
incidentRows.length`), then four `<section>`s each showing its own error Alert OR its panel:
- Loop patterns ⇒ `<LoopPatternsPanel>`
- Open escalations ⇒ `<EscalationsPanel>`
- Open incidents ⇒ `<IncidentsPanel>`
- Readiness ladder ⇒ `<ReadinessLadder>`

Sub-components:
`CapBadge({pattern})` (`:71`): `pattern.capped` ⇒ gold "⚠ Capped by tier" (`data-testid=loop-capped-
{name}`); else base "○ Not capped". Icon+text, not color.
`OpsSkeleton` (`:94`): skeleton bars with `aria-busy`.
`ReadinessLadder({rungs})` (`:117`): empty ⇒ EmptyState "No readiness ladder published"; else an ordered
`<ol>` of rungs (`data-testid=ladder-rung-{i}`).
`LoopPatternsPanel({patterns})` (`:146`): empty ⇒ EmptyState "No loop patterns registered". Else a
`usa-table` — columns Loop pattern (name + description), Cadence (`p.cadence || "—"`), Requested
(`autonomyLevelLabel(requested_level)`), Permitted (`autonomyLevelLabel(permitted_level)`), Tier cap
(`<CapBadge>`).
`EscalationsPanel({escalations})` (`:210`): empty ⇒ EmptyState "No open escalations". Else table: Loop
item (loop_item_id), Application, Tier, Requested → Permitted (with sr-only "to"), Reason, Forced by —
`denylisted` ⇒ red "Denylisted path" Tag, `attempt_capped` ⇒ gold "Attempt cap" Tag, neither ⇒ muted
"Operator".
`IncidentsPanel({incidents})` (`:296`): empty ⇒ EmptyState "No open incidents". Else table: Service, Error
class, Source (`captureSourceLabel`), Occurrences, First seen/Last seen (`formatWhen`), Tier, Triage
decision (`triageDecisionLabel`).

---

# Shared shell + top-level components

## components/RequireAuth.tsx (default `RequireAuth`)
Route guard (P6-S15.10). No props. Reads `getAuthToken()`; if absent ⇒ `<Navigate to="/login" replace
state={{from:location}}>` (deep-link preservation), else `<Outlet/>`.

## components/ThemeToggle.tsx (default `ThemeToggle`)
Props `{theme:"light"|"dark", onToggle}`. Pill button; `isDark` toggles glyph (☀ / ◑) + label
(Light/Dark) + `aria-label` "Switch to {other} mode".

## components/ScoreBar.tsx (default `ScoreBar`)
Props `{label, value:number|null}`. `pct = clamp(value,0,100)` (0 when null); `displayValue = value!=null ?
toFixed(0) : "N/A"`. Renders label + a `role="progressbar"` track (`aria-valuenow/min/max`) with a
`__fill` width `${pct}%` + value text.

## components/PortfolioPicker.tsx (default `PortfolioPicker`)
No props; reads `usePortfolioContext`. `loading` ⇒ reserved-space busy span. Zero portfolios ⇒ null.
Exactly one ⇒ static label span (`--single`). Else a native `<select id="portfolio-picker-select">`
(the id `GateQueueEmptyState.focusPortfolioPicker` targets) bound to `activePortfolio?.id`, onChange →
`setActivePortfolioId`.

## components/StatusBadge.tsx (default `StatusBadge`)
Props `{status:GateStatus|string, label?}`. `STATUS_CLASS` (`:11`) maps ~25 statuses (gate: pending/
approved/rejected/overridden→approved/escalated; workflow/app; wave lifecycle draft/ready/in_progress/
cancelled + dashed architecture-*/modernization-* forms) → `status-badge--*` classes. `STATUS_LABEL`
(`:46`) gives friendly labels for the dashed wave forms only. Renders `<Tag className="status-badge {cls}">`
with `label ?? STATUS_LABEL[status] ?? status`.

## components/ActiveProfileBadge.tsx (default `ActiveProfileBadge`)
No props. Effect fetches `fetchActiveProfile().catch(()=>null)`. loading ⇒ busy span; no active ⇒ null;
else a readonly badge "Profile {name}" with `title="Active profile: {name}"`. No picker (switching is admin-only).

## components/TabNav.tsx (default `TabNav`; also exports `TabPanel`, `TabDef`)
`TabNav({tabs:TabDef[], activeTab, onTabChange})`: `role="tablist"` of `role="tab"` buttons;
`handleKeyDown` (`:24`) ArrowRight/Left wrap, Home/End jump, then focus + `onTabChange`. Active tab
`tabIndex=0` else `-1`; `aria-selected`/`aria-controls`. `TabPanel({id,activeTab,children})` returns null
unless `activeTab===id`, else a `role="tabpanel"` `tabIndex=0`.

## components/ApplicationDispositionChips.tsx (default `ApplicationDispositionChips`)
Props: `{appId, fallbackDisposition?:Disposition|string|null, showTargetServices?=false, className?}`.
Reads `fetchApplicationDispositions(appId)`. `getDispositionColor(d)` (`:33`): per-disposition {bg,color}
palette (mirrors PortfolioOverview). GOTCHA (`:150`): resets state DURING render when `appId` changes
(`if(state.appId!==appId) setState(...)` — the documented derived-state-from-prop pattern to satisfy
`react-hooks/set-state-in-effect`). Effect fetches; error ⇒ treated as no data (defensive — no error chip
per row). Loading ⇒ quiet "—". No view rows ⇒ fallback single chip (`fallbackDisposition`) or "—". Else a
flex-wrap of `<Chip>` per disposition; when `showTargetServices`, pairs `disposition → target_service` by
parallel index.

## components/DataGrid.tsx (default `DataGrid<T>`)
Generic TanStack table. Props: `{data:T[], columns:ColumnDef<T,any>[], caption, filterable?=false,
filterPlaceholder?="Filter...", emptyMessage?="No data available.", headerRight?, pageSize?=20}`. State:
`sorting:SortingState`, `globalFilter`. `enablePagination = pageSize>0 && isFinite`. Builds the table with
core/sorted/filtered models + optional pagination model. `data.length===0` ⇒ empty-state block (+optional
headerRight). Renders an optional filter row (`TextInput` bound to globalFilter) + headerRight; a
`usa-table usa-table--striped` with sortable headers (`aria-sort` ascending/descending/none, click toggles
sort, ▲/▼/⇅ glyphs); rows via `flexRender`. Pagination nav (first/prev/next/last + "n–m of total" +
"Page x of y") shown only when `enablePagination && totalRows>pageSize`.

## components/DemoModeIndicator/DemoModeIndicator.tsx (default)
No props. Returns null unless `isDemoMode()` (`VITE_DEMO_MODE=true`). Else a bottom-right `role="status"`
pill (sr-only label + dot + "DEMO MODE"), opacity ~0.4 so it doesn't compete on the take.

## components/TraceId/TraceId.tsx (default `TraceId`)
Props `{traceId?:string|null, label?="Trace ID"}`. Falsy traceId ⇒ null. Renders `label: <code>{traceId}
</code>` + a Copy button (`navigator.clipboard.writeText`; shows "Copied" for 2s; clipboard failure is a
silent best-effort no-op — id still selectable).

## components/Layout/Layout.tsx (default `Layout`)
The app shell (dark header, multi-section top nav, context sidebar, main). Hooks: `useWebSocket()`→
`{connected}`, `useTheme`, `useChatContext`, `useArtifactContext`, `useBreadcrumbContext`.
State: `mobileNavOpen`, `sidebarCollapsed`. Inline SVGs `CollapseIcon`, `HomeIcon`, `BrandIcon`.
Exported pure fn `breadcrumbsForPath(pathname, context)` (`:89`): builds the crumb trail per route family
— `/applications/...` (optional wave→app→assemblyLine→leaf from context), `/portfolios/:id/applications`,
`/gates/:id/review`, `/gates`, `/me/tasks(+detail)`, `/me/bundles` + `/bundles/:id`, `/waves`,
`/assembly-lines(+slug titleized)`, `/skills(+evaluation|detail)`, `/analytics/:slug` (label map),
`/admin/:slug` (label map). Always starts with `{label:"Portfolio",href:"/",icon:true}`.
Render: skip-nav; USWDS `<Header basic>` with brand logo, `NavMenuButton`, and `PrimaryNav` whose items
are `NAV_SECTIONS` NavLinks (active when `section.id===activeSection.id` via `resolveActiveSection`) plus a
header-right group (PortfolioPicker, ActiveProfileBadge, connection indicator dot Live/Offline, ThemeToggle,
CurrentUserMenu). Body: a collapsible `<nav className="olympus-sidebar">` (`<SidebarNav collapsed>` + a
collapse-toggle button) and `<main id="main-content">` with a `BreadcrumbBar` (from `crumbs`) + `<Outlet/>`.
Finally a `<ChatDrawer>` keyed by chat context — HIDDEN on `/action-console` (the NL console is itself a
full chat surface).

## components/Layout/SidebarNav.tsx (default `SidebarNav`)
Props `{collapsed:boolean}`. `resolveActiveSection(pathname)` → section. When `section.id==="portfolio" &&
activePortfolio`, injects an "Applications" item (`/portfolios/{id}/applications`) after the first item.
`isActive(path)`: exact for "/", else `pathname===path || startsWith(path+"/")` (avoids `/gates` matching
`/gates-foo`). Collapsed ⇒ `SideNav` of icon-only `<Link>`s (title=label). Expanded ⇒ section title + icon+
text links. Uses `SidebarIcon`.

## components/Layout/SidebarIcon.tsx (default `SidebarIcon`)
Props `{name, size?=16}`. `ICONS` (`:6`): a map of ~25 named 16×16 SVG path strings (grid, layers, wave,
lock, search, filter, box, database, cpu, play, check-circle, upload, refresh, shield, bot, book, trending,
bar-chart, zap, dollar, package, user, activity, settings). Unknown name ⇒ first-letter fallback span. Else
a stroke `<svg><path d={ICONS[name]}></svg>`.

## components/Layout/CurrentUserMenu.tsx (default `CurrentUserMenu`)
No props. State: `user:UserProfile|null, loading, open`, ref `containerRef`. `initialsOf(label)` (`:36`):
up to two uppercased letters. `reload()` = `fetchCurrentUser()` (catch ⇒ null). Effect closes menu on
outside mousedown + Escape. `handleSignOut` (`:88`): `logoutSession()` (finally `clearAuthToken()` +
navigate `/login`). loading ⇒ "…"; no user && no token ⇒ "Sign in" Link. Else an avatar button
(`aria-haspopup/expanded`, initials) that toggles a dropdown showing name, email, role chips
(`data-testid=current-user-roles`), and a "Sign out" button (`data-testid=sign-out`).

## components/Glossary/Glossary.tsx (default `Glossary`)
Props `{term, children?, className?}`. `getGlossaryEntry(term)` from `config/glossary`. Unknown term ⇒
plain `children ?? term` (no affordance). Else a trigger `<button aria-describedby>` (hover/focus open,
blur/mouseleave close, Escape closes+blur) showing children + ⓘ, and a `role="tooltip"` (mounted only when
open) with the entry label + definition.

## components/ErrorBoundary/ErrorBoundary.tsx (default `ErrorBoundary`, class component)
Props `{children, sectionLabel?, fallbackHeading?, fallbackBody?, onCaught?}`. `getDerivedStateFromError`
sets `{hasError,error}`. `componentDidCatch` console.errors + calls `onCaught`. On error renders a USWDS
error `Alert` (heading = `fallbackHeading ?? "Something went wrong loading {sectionLabel ?? 'this section'}."`)
with `fallbackBody` (default "rest of the page is still usable…") plus a `<TraceId>` — traceId pulled from
`error.traceId` when the caught error is an `ApiError`, else "".

---

# GateReview group (components/GateReview/)

The banner/chip/modal building blocks composed by `pages/GateReview/GateReview.tsx`.

## AIRecommendationBanner.tsx (default)
Props `{recommendation:AIRecommendation, onViewDetails}`. `getRecommendationConfig(recommendation.
recommendation)` → `{type,emoji,label,tone}`. Renders a slim USWDS `Alert type={config.type}` showing
"{emoji} AI Review Recommendation: {label} ({confidence_score}/100)", the summary (`replaceEmojiShortcodes`),
and a "View Full Pre-Review" button → `onViewDetails`.

## AskAIButton.tsx (default)
Props `{artifactContext?:string|null, label?="Ask the AI about this artifact", variant?="panel"|"viewer",
className?}`. Uses `useArtifactContext`. `handleClick`: if `artifactContext!==undefined` ⇒
`setArtifactContext(artifactContext)`, then `requestOpenChat()` (nudges the global ChatDrawer). Renders a
💬 button; variant class `--viewer`/`--panel`.

## ConsequenceBanner.tsx (default)
Props `{gateType:GateType|string, gateName?}`. `getGateConsequence(gateType)` from `config/gateConsequences`.
No entry ⇒ null. Else a `role="region"` section with heading "What happens next[ for {gateName}]" and a
`<dl>` of two rows: "If approved" chip + `consequence.approved`, "If rejected" chip + `consequence.rejected`.

## ConfirmModal.tsx (default)
Props `{heading, body, confirmLabel, confirmVariant?="default"|"secondary", cancelLabel?="Cancel", onConfirm,
onCancel}`. Focuses Cancel on mount; Escape ⇒ onCancel; overlay click ⇒ onCancel. `role="dialog" aria-modal`
with heading, body, Cancel (outline) + Confirm (secondary when variant==="secondary") buttons.

## ValidationWarningsBanner.tsx (default)
Props `{warnings:Record<string,string[]>|null|undefined}`. `entries` = filtered to non-empty message lists;
empty ⇒ null. State `expanded`. Warning `Alert` "Schema validation warnings ({totalMessages})" (slim when
collapsed). Collapsed ⇒ "View N warnings" button; expanded ⇒ a `<ul>` of `<code>{filename}</code>` each
with its messages + "Hide details". Non-blocking (workflow never rejects on schema failure).

## AIRecommendationModal.tsx (default)
Props `{recommendation:AIRecommendation, onAccept, onClose}`. Focus close on mount; Escape/overlay-click ⇒
onClose. `role="dialog"` with heading (emoji + label + `confidence_score/100`, tone class), an
`<AgentMarkdown>` of `recommendation.full_markdown`, and Close (outline) + "Accept Recommendation" buttons.

## EvidenceSourcePanel.tsx (default; exports `BundleEvidenceSource`, `EvidenceSourcePanelProps`)
Props `{source:BundleEvidenceSource|null}`. `source` null ⇒ null. Renders a `role="note"` aside "Evidence
source" with `buildSentence(source)` (`:546`) — "This evidence was produced by {name||email||user_id}
[({email})][ using {tool} {version} on {model}]. [Transcript hash {12-char}…]." — and a `<Link to=
/bundles/{bundle_id}>` "View delegated bundle →". Reads a roadmap field defensively (Chunk F).

## DispositionConfidenceChip.tsx (default; P3.5-S.5)
Props `{appId:string|null, gateType, fetcher?=fetchDispositionConfidence}`. `isGDA = gateType==="G-DA"` —
returns null for any other gate. Effect (skips when `!isGDA||!appId`) fetches the list, picks
`find(app_id===appId) ?? list[0] ?? null`. `tone(score)` (`:607`): >=75 high, >=50 medium, else low; null/NaN
unknown. `toneColour`/`toneLabel` per tone ("Strong/Mixed/Weak evidence"/"Not computed"). loading ⇒ busy
chip; error/no-entry ⇒ "Not computed" chip. Else a chip: `<Glossary>` "Disposition Confidence", a meter bar
(`pct=round(clamp(score,0,100))`), "{pct}/100", tone label, and "· recommends {disposition}" when present.

## GateReviewerActions.tsx (default; P6-S6.5, exports `GateReviewerActionsProps`)
Props `{policy:GateReviewerRoles|null, approvalsReceived?=0, onApprove?, onReject?, onForceAdvance?,
disabled?=false}`. `ROLE_LABELS` (`:802`) maps role ids to labels. policy null ⇒ null. `canDecide =
can_approve || can_force_advance`; `showQuorum = minimum_approvals>1 || oversight_role`. Renders: quorum
line ("Requires N approvals — X of N recorded[; {oversight} co-sign required]") when showQuorum; Approve
button (only `can_approve`); Reject button (only `canDecide`); Force-advance button (only
`can_force_advance`); and — when `!can_approve` — an explanatory `role="note"` (caller_role can't approve,
required roles, non-overridable note). Not a silent hide.

## CapabilityLineageReviewPanel.tsx (default; exports Props)
Props `{waveId, onChange?:(decisions:CapabilityLineageRowDecision[])=>void, disabled?=false}`. Row-level
approve/reject on `capability_lineage` rows (G-DA/G-04). `RowDecisionState` union (`:943`):
pending|approve|{reject,feedback}|{reject-pending,feedback}. Helpers: `describeRow` (`source → target`,
dropped ⇒ "(retired, no successor)"), `relationshipLabel` (Absorbed/Partial (M:N split)/Transformed/
Dropped), `statusLabel` (Ratified by X / Pending review (agent-emitted) / Pending review),
`hasPriorReworkFeedback(row)` = `notes` contains `[REJECTED` (drives a "Reworked" badge).
State: `rows`, `loading`, `error`, `states:Record<id,RowDecisionState>`. Effect fetches
`fetchWaveCapabilityLineage(waveId)`. `decisions` memo (`:1048`): emits `{lineage_id,decision:"approve"}`
for approved rows, `{lineage_id,decision:"reject",feedback}` for committed rejects (with non-empty
feedback); pending/reject-pending emit nothing. Effect fires `onChange?(decisions)`.
Handlers: `onApprove`, `onStartReject` (→ reject-pending, preserving feedback), `onChangeFeedback`,
`onCommitReject` (requires non-empty feedback), `onClear` (→ pending). loading/error/empty states.
Progress line "{ratified} ratified · {rejected} rejected · {pending} pending review". Each row `<li>`
(bg tinted green/red on decision): header (mono describeRow + "Reworked" badge) + relationship/status;
notes; a button group Approve / "Reject for rework" (aria-pressed) / Clear; and, when rejecting, a required
rework-guidance `<textarea>` + "Commit rejection" button (disabled until non-empty feedback).

---

*(Continues in Part 3: GateReviewCards, Chat, Markdown, charts, Insights, and the mid-size feature components.)*
