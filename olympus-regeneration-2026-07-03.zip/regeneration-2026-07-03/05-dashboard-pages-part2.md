# 05 — Dashboard Pages (Part 2: Waves, Applications, PortfolioOverview)

Continues `05-dashboard-pages.md`. Same stack conventions.

---

## waveActions.ts — pure state→action matrix (shared by WaveManagement + WaveDetail)

`getWaveActions({status, appCount, discoveryReadyCount})` (:62-148) returns an
ordered `WaveActionSpec[]` where `actions[0].primary===true` when a primary CTA
exists. `WaveActionKind` (:16-32): markReady, rationalize, revertToDraft, delete,
cancel, cancelRationalization, retryRationalization, reset, resume, viewProgress,
viewOutcome, view. `WaveActionSpec` = `{kind, label, primary?, disabled?,
disabledReason?}`.

Matrix (exact):
- `draft`: appCount===0 → `[delete, cancel]`; discoveryReadyCount===0 →
  `[delete, cancel]`; `<appCount` → `[markReady(disabled, reason "N of M apps
  still in Discovery"), delete, cancel]`; all ready → `[markReady(primary),
  delete, cancel]`.
- `ready`: `[rationalize(primary), revertToDraft]`.
- `in_progress`: `[retryRationalization, cancelRationalization, viewProgress]`.
- `completed`: `[viewOutcome]`.
- `cancelled`: `[view, delete]`.
- `failed`: `[reset(primary "Reset to Ready"), viewProgress]`.
- `stuck-awaiting-recovery`: `[resume(primary "Resume Wave"),
  retryRationalization("Retry Rationalization"), reset("Reset to Ready"),
  viewProgress]`.
- default → `[]`.

`WAVE_FILTER_CHIPS` (:156-165): active("All active"), draft, ready, in_progress,
completed, failed, cancelled, all. `filterWavesByChip(waves, filter)` (:176-187):
`all`→copy; `active`→exclude cancelled; else equality on status.

---

## WaveManagement.tsx (1059 LOC) — route `/waves`

Create/view/manage migration waves with state-aware per-row actions.

### Hooks / state
- `usePortfolioContext()` → `{activePortfolio, loading: portfolioLoading}` (:65).
  `activePortfolioId = activePortfolio?.id` (:117). `useChartTheme()`→ct.
- `waves: WaveListItem[]`, `applications: ApplicationDetail[]`, `loading=true`,
  `error`, `actionLoading: string|null` (per-row wave id in-flight) (:67-71).
- URL filter via `useSearchParams` (:74-78): `activeFilter =
  isValidFilter(status param) ? param : "active"`. `selectFilter(next)` (:80-88):
  writes/deletes `status` query (default "active" deletes param), replace.
- Create-wave form: `showCreate`, `waveName`, `selectedApps: Set<string>`,
  `creating` (:91-94).
- Auto-assign form: `showAutoAssign`, `maxAppsPerWave=10`, `autoAssignNote`,
  `assigning` (:97-100).
- Bulk-onboard modal: `showBulkOnboard`, `bulkOnboardSelected: Set`,
  `bulkOnboarding`, `bulkTargetWave: TargetWavePickerValue|null`,
  `bulkWavePickerReloadKey`, `bulkOnboardError` (:103-115).

### Data load
`loadData(portfolioId?)` (:119-132): `Promise.all([fetchWaves, fetchApplications])`.
Effect (:134-138) reloads on `activePortfolioId`/`portfolioLoading`.
Memos: `filteredWaves = filterWavesByChip(waves, activeFilter)` (:140-143);
`filterCounts` (:145-153): `{total, active=total-cancelled, byStatus}`;
`timelineData` (:437-445) maps filteredWaves to `{name, apps, status}`;
`unassignedApps = applications.filter(!wave_id)` (:447).

### Action handlers (all emit `wave.action.clicked` + on success
`wave.state.transitioned` telemetry via `emitWaveEvent`, set `actionLoading`,
`loadData` on success):
- `handleMarkReady` (:155-179): `markWaveReady`→"ready".
- `handleRationalize` (:181-208): `startRationalization` toast with workflow_id
  →"in_progress".
- `handleRevert` (:210-235): `revertWaveToDraft`→"draft".
- `handleCancel` (:237-263): `confirm(...)` then `cancelWave`→"cancelled".
- `handleDelete` (:265-281): `confirm` then `deleteWave`.
- `handleCreateWave` (:449-468): `createWave({portfolio_id, name, application_ids:
  Array.from(selectedApps)})`.
- `handleAutoAssign` (:470-517): guard portfolio; `confirm`; `assignWaves(
  {portfolio_id, max_apps_per_wave})`. Reads `waves_created ?? waves?.length ?? 0`
  and `apps_assigned ?? sum(waves.application_ids.length)`. Toast "No changes" if
  both 0.
- `handleBulkOnboard` (:537-625): validates ≥1 app selected, target wave chosen;
  for `newDraft` requires name ≤60 chars, else requires `waveId`. GOTCHA: newDraft
  → `createWave` (single round-trip + server 409 on dup name); existing draft →
  `bulkOnboardApps` (enforces draft-only). Toast with "View wave →" action
  (`window.location.assign`). Error handling: `WAVE_NAME_EXISTS|409|already exists`
  → refresh picker; `WAVE_NOT_DRAFT` → refresh picker; else toast.
- `toggleApp`/`toggleBulkApp` mutate Sets immutably.

### Columns (DataGrid, `@tanstack/react-table` columnHelper) (:283-435)
`#` (wave_number), Name (Link to `/waves/{id}`), Status (StatusBadge), Apps
(app_count), Discovery ready (`{ready}/{app_count}`, "—" when 0 apps), Start/End
(planned dates localeDateString), Actions (display col, `enableSorting=false`).
Actions cell (:330-424): `getWaveActions(...)` then `renderAction`: GOTCHA — kinds
`viewProgress|viewOutcome|view|cancelRationalization|retryRationalization|reset`
render as a `Link` to `/waves/{id}` (routed to detail page; handlers live there);
other kinds render a Button with onClick mapped to the handler. Button variant:
`outline` when not primary/secondary; `secondary` for delete/cancel;
disabled while loading/action.disabled; label suffixed `…` when loading && primary.
GOTCHA (:434): deps `[actionLoading]` with eslint-disable — handlers are closures.

### Render (:635-1058)
Header + buttons: Bulk Onboard (secondary, disabled if no portfolio or
unassignedApps empty), Auto-Assign (secondary), + Create Wave (outline). Error
Alert. Filter chip nav (:675-719) — each chip shows count (active→filterCounts.active,
all→total, else byStatus[key]??0). Wave Composition BarChart (recharts) when
timelineData present. Bulk onboard `CreateModal` (checkbox list of unassignedApps +
`TargetWavePicker`). Auto-assign inline form (max apps number 1-100 + note). Create
`CreateModal` (name + checkbox list of unassignedApps with disposition note).
Empty state when `waves.length===0` else `DataGrid` (empty message differs for
active filter). Bottom 3-col stats (Planned=draft+ready, In Progress, Completed).

---

## WaveDetail.tsx (1757 LOC) — route `/waves/:waveId`

State-aware banner + 5-step lifecycle stepper + applications table + fan-out /
recovery surfaces + tabbed (Overview/Roadmap/Performance) layout. See
`05-dashboard-pages.md` header note for full detail; summary below.

### Params/state
`waveId` from params. State (:418-455): `wave: WaveDetailType|null`, `apps:
WaveAppRow[]`, `activityByApp: Record<appId, WaveAppActivityRowView>`, `loading=true`,
`error`, `actionLoading: WaveActionKind|null`, `reloadKey` (increment to reload),
`moveTargetAppId`, `removingAppId`, `confirmCancelRun`, `failureReason: string|null`,
`temporalUiUrl`, `activeTab: "overview"|"roadmap"|"performance"`.
`WaveAppRow` (:407-412) = `ApplicationDetail & {row_kind:"member"|"target",
source_app_id?, source_app_name?}`.

### Load effect (:457-596) keyed on `[waveId, reloadKey]`
1. `fetchWaveDetail(waveId)` → wave.
2. GOTCHA (F25): filter apps by `wave.application_ids` (junction table) not
   `a.wave_id` (null today). `fetchApplications({portfolio_id})` → memberRows
   (`row_kind:"member"`).
3. GOTCHA (D5/D6): hydrate target rows CLIENT-SIDE — for each member,
   `fetchApplicationLineage(id)` in parallel; each `lineage.targets` edge whose
   `related_app_id` is not a member, not already seen, and present in the same
   portfolio → target row with `source_app_id/name` back-ref. Per-member lineage
   failure skipped. (A native `/waves/{id}/applications?include=targets` would
   collapse this.)
4. `fetchWaveAppActivity(w.id)` → `activityByApp` indexed by application_id
   (best-effort).
5. For status `failed`|`stuck-awaiting-recovery`: `fetchWaveProgress(w.id)` →
   `failureReason = last_error ?? ""`, `temporalUiUrl`. Else both null.

### Derived (:598-612)
`discoveryReady = wave?.discovery_ready_count ?? 0`, `appCount = wave?.app_count
?? 0`, `actions = getWaveActions({status, appCount, discoveryReadyCount})`,
`banner = bannerFor(status, appCount, discoveryReady, failureReason)`.

`bannerFor` (:247-384): per-status banner `{variant, heading, body, actionable}`.
Notable: `draft` splits on discoveryReady (0 / partial / all-ready);
`failed`/`stuck-awaiting-recovery` include the failure reason text; the post-G-DA
statuses (`awaiting-architecture-dispatch`, `architecture-in-flight`,
`data-in-flight`) get their own primary/info banners.

### `LifecycleStepper` (:134-216)
`cancelled`→"Cancelled" badge; `failed`→"Failed" badge; else GOTCHA — normalizes
in-flight statuses (`awaiting-architecture-dispatch`, `architecture-dispatched`,
`architecture-in-flight`, `data-in-flight`, `modernization-in-flight`) →
`in_progress`; `modernization-complete`→`completed`. Renders 4-step ol (Draft,
Ready, In Progress, Completed) with completed/current classes.

### Action handlers
All via `runAction(kind, fn, {confirm?, successMessage?, errorMessage, navigateTo?,
toState?})` (:627-668): emits telemetry, optional `confirm()`, sets actionLoading,
awaits fn, toast + `wave.state.transitioned` telemetry, then navigate or
`setReloadKey(k=>k+1)`. Handlers: `handleMarkReady` (markWaveReady),
`handleRationalize` (startRationalization), `handleRevert` (revertWaveToDraft),
`handleCancel` (cancelWave w/ confirm), `handleDelete` (deleteWave w/ confirm →
navigate /waves), `handleCancelRationalization` (cancelWaveRationalization →ready),
`handleRetryRationalization` (retryWaveRationalization), `handleCancelAllChildren`
(:766-792 — own try/catch, confirm, `cancelAllWaveChildren`), `handleResumeWave`
(resumeWave — toast respawned/already-running counts), `handleResetWave` (resetWave
→ready), `handleRemoveFromWave(appId,appName)` (:843-869 — confirm,
`removeAppsFromWave`, telemetry `wave.app.moved`). `goToApps(filtered)` navigates to
portfolio applications with `?scope=incomplete` when filtered.

### Render (:875-1456)
loading; error/!wave → error + "← Back to Waves". Breadcrumb; header (Wave # + name +
StatusBadge + counts + LifecycleStepper). `TabNav` (overview/roadmap/performance).
Roadmap→`WaveRoadmap`; Performance→`WavePerformanceReport`. Overview panel renders,
in order: `WaveRecoveryBanner` (failed/stuck only), `ActionBanner` (suppressed for
failed/stuck), a `WorkflowActionsBar` region for stuck, `CancelAllChildrenButton`
(when `shouldShowCancelAll` = architecture/data-in-flight), `ConfirmModal`
(confirmCancelRun), `WaveWorkflowProgress` (status!==draft), `Tier1ApprovalPanel`
(not draft/ready), `PreDispatchPanel` (awaiting-architecture-dispatch),
`FanOutStatusTable` (architecture/data-in-flight/completed), Applications table,
`PendingGatesQueue` (`shouldShowFanoutQueue` = in-flight or completed),
`MoveToWaveDialog` (moveTargetAppId), `WaveGateDecisions` (not draft), Wave plan
(`WaveSynthesisCard` + `WavePlanEmbed` only when completed else placeholder),
`CapabilityClusterSummary` (not draft), Cross-App BR Overlap (in_progress|completed),
`ModelUsageChart` (not draft, portfolio+wave scoped). Most panels wrapped in
`ErrorBoundary`.

Applications table (:1117-1338): columns Application (Link with from-state
`{pathname:/waves/{id}, label:"Wave: {name}"}`; target rows show a "Target" tag +
"from {source}" link), Current line, Current status (StatusBadge), Disposition
(`ApplicationDispositionChips`), Capability/system (IIFE :1217-1267 — capability
external_id/name link to capability-lineage + target systems joined " + "), Latest
actor (`ActorKindBadge`), and an Actions column ONLY when `wave.status==="draft"`
(member rows get Move to wave / Remove buttons; target rows get "—").

`ActionBanner` subcomponent (:1506-1757): maps `actions` to Buttons per kind
(markReady/rationalize/revertToDraft/cancel/delete/retryRationalization/
cancelRationalization/reset/resume; viewProgress renders null on detail).
`goToAppsButton` added for warning/info variants when no workflow controls;
`cancelAllButton` when showCancelAll. Renders inside a USWDS `Alert` (variant→
info/warning/success/error) with role region (actionable) or status.

---

## Applications/ApplicationsPage.tsx (995 LOC) — route `/applications` or `/portfolios/:portfolioId/applications`

Portfolio-scoped applications listing: header + metric tiles + per-line stats +
search/filter bar + cards/list toggle.

### Hooks / state
- `routePortfolioId` from params; `usePortfolioContext()` →
  `{portfolios, activePortfolio, loading}` (:121-123). `portfolioId =
  routePortfolioId ?? activePortfolio?.id ?? null` (:125). `portfolio` resolved
  from portfolios list or activePortfolio (:126-127).
- `applications: ApplicationDetail[]`, `loading=true`, `loadError` (:129-131).
- `showOnboardModal` (:133). Filters: `search`, `lineFilter: AssemblyLineName|"all"`,
  `dispositionFilter: Disposition|"all"`, `riskFilter: RiskTier|"all"`, `viewMode:
  "cards"|"list"` (:135-139).

### Load
`load(pid)` (:141-190): GOTCHA (P5-AUDIT-008) — list endpoint returns apps WITHOUT
scores; `Promise.allSettled([fetchApplications({portfolio_id}),
fetchReadinessScores({portfolioId})])`; merges `.scores.overall` from readiness by
app_id when app.scores.overall is null. Sets loadError only when apps call rejected.
Effect (:192-201) loads when portfolioId present. Effect (:208-213): GOTCHA — when
on a route-parameterised page and the header dropdown picks a different portfolio,
`navigate(/portfolios/{active.id}/applications, replace)` to sync.

### Derived
`filtered` (:216-234): applies line/disposition/risk filters + case-insensitive
substring search over name+description. `lineCounts` (:237-246): per-assembly-line
count over ALL apps. `columns` (:248-335): DataGrid columns Name (Link),
Description (truncate 60), Line, Disposition (`ApplicationDispositionChips`), Risk
(`Tier {v}`), Modernization Readiness (target apps show pipeline position + tooltip;
others show `{pct}%` via `readinessForDisplay`), Last Activity (`relativeTime`).

### Helpers
`relativeTime(iso)` (:58-73): s/m/h/d/mo/y ago buckets. `truncate(text,n=80)`
(:75-78). `readinessPct(app)` = `round(scores.overall*100)` (:80-84).
`POST_RATIONALIZATION_LINES` = {Architecture, Data, Modernization, Validation,
Deployment} (:98-104). `isTargetApp(app)` (:106-109): true if `target_repo_url` OR
current_line in POST_RATIONALIZATION_LINES. `readinessForDisplay(app)` (:112-115):
null for targets else readinessPct. GOTCHA: readiness is a pre-modernization
source-quality score; hidden as N/A for target services.

### Constants
`ASSEMBLY_LINE_NAMES` (:33-44) 10 lines (incl. "Disposition Execution",
"Sustainment", "Governance"). `DISPOSITIONS` (:46-54) 7 (Retire..Consolidate — no
Build). `RISK_TIERS` = [1,2,3].

### Render (:337-748)
loading spinner; `!portfolioId` → "No portfolio selected" + link. Header (h1 +
portfolio name + "+ Onboard Application"). loadError `role=alert`. Metric tiles
(Total Apps + active count excluding consolidated; In Pipeline = current_line set &
not consolidated; Apps at Risk = tier 1; Avg Modernization Readiness over
non-target scored apps). Per-line stat chips. Filter bar (search/line/disposition/
risk selects + Cards/List toggle). Empty state when no apps. Cards grid
(`ApplicationCard`) or `DataGrid` list. Onboard `CreateModal` with
`ApplicationOnboardingForm`: onSuccess GOTCHA (Phase 6 W5) — `sourceType==="interview"`
routes to `/portfolios/{pid}/applications/{appId}/interview`; else toast with
"Start Discovery →" action (8s).

`ApplicationCard` (:750-995): kebab menu ("View in pipeline" link + disabled "Rerun
current line"), line chip + StatusBadge + `ApplicationDispositionChips` +
`ConsolidatedBanner compact` (consolidated) + risk tier chip. Target apps show
"Target service" + pipeline position; else Modernization Readiness label + progressbar
(gradient width `{pct}%`, aria-valuenow/text). Footer: "Last activity" + Open button.

---

## PortfolioOverview/PortfolioOverview.tsx (818 LOC) — route `/` (home)

Executive dashboard: hero (needs-attention), phase ribbon, 7 stat tiles, charts,
pipeline, applications + activity summary cards.

### Hooks / state
- `usePortfolioContext()` → `{portfolios, activePortfolio, loading:
  portfolioLoading, refresh: refreshPortfolios}` (:67).
- Data state (:68-79): `applications`, `pendingGates`, `escalatedGates`,
  `runningWorkflows`, `failedWorkflows` (WorkflowHealthSummary[]), `health:
  PortfolioHealthResponse|null`, `systemHealthy: bool|null`, `waves`,
  `recentActivity: ActivityEvent[]`, `loading=true`, `gatePassRate: number|null`.
- Portfolio create form (:82-87): showPortfolioForm, portfolioName/Owner/Repo,
  portfolioSubmitting, portfolioError. `showAppForm`, `showProfileBundle`,
  `carouselOpen`, `seedingSample` (:90-100).

### Load
`loadData(portfolioId?)` (:102-200): `Promise.all([fetchPendingGates,
fetchApplications, fetchRecentActivity(15), fetchReadinessScores.catch([])])`.
GOTCHA (P5-AUDIT-008): merges readiness `.overall` into apps by id. THEN sequential
best-effort fetches (each own try/catch → default): `fetchPortfolioHealth`,
`fetchDetailedHealth` (`systemHealthy = status==="ok"`), `fetchWaves`,
`fetchGatePassRate` (`overall_rate`), `fetchPendingGates(pid,"escalated")`,
`fetchWorkflowHealthList(100)` → running/failed. Outer catch resets everything.
Effect (:204-208): reloads on `activePortfolioId`/`portfolioLoading`.
Effect (:213-220): opens onboarding carousel when `portfolios.length===0 &&
!hasDismissedOnboarding()`.

### Handlers
`handleSeedSample` (:222-237): `seedSamplePortfolio()` → toast, refreshPortfolios.
`handleCreatePortfolio` (:239-263): `createPortfolio({name, owner,
artifact_repo_url})` → close form, refreshPortfolios.

### Derived (:266-315)
`dispositionData = computeDispositionData(applications)`; `pipelineData =
computePipelineData(applications)`; `pipelineCounts` (:276-284): per-line slug count
(`current_line.toLowerCase().replace(/\s+/g,"-")`); `activeWaves = waves.filter(
in_progress).length`; `tier1Count`; `avgReadiness` (mean of scores.overall);
`recentlyActiveApps` (top 5 by updated_at desc).

### Render (:317-818)
loading spinner. `hasPortfolio = portfolios.length>0`. Header (h1 + Export Profile
[when activePortfolioId] + New Portfolio buttons). `ProfileBundleModal`. When no
portfolio: `OnboardingCarousel` + `EmptyState` (primary "+ Create Portfolio",
secondary "Load sample portfolio"). `CreateModal` for portfolio create form
(name/owner/repo). When hasPortfolio: `NeedsMyAttention` hero (pendingGates,
escalatedGates, running/failedWorkflows, applications), `MyTasksSummaryCard`,
`PhaseRibbon counts=pipelineCounts showCounts`. 7 stat tiles: Applications (+ "in
pipeline" count excluding consolidated), Active Waves, Pending Gates (link /gates),
Gate Pass Rate (`round(rate*100)%`), Apps at Risk (tier1, red if >0), Avg Readiness
(`round(avg*100)%`), System Health (`HealthGauge` if health_index else OK/Degraded).
Charts: `DispositionDonut` + `PipelineProgress`. `StaleArtifactsCard`. Assembly Line
Pipeline: GOTCHA — `VITE_LEGACY_PIPELINE_VIZ==="true"` → `AssemblyLinePipeline`, else
`PipelineNodeGraph`; onLineClick navigates `/assembly-lines/{slug}`.
`TargetStateRollupBand` (activePortfolioId). Onboard `CreateModal` with
`ApplicationOnboardingForm` (onSuccess toast + Start Discovery action). Applications
summary card (recentlyActiveApps mini-list with StatusBadge + relativeTime + Onboard
button) + Recent Activity `ActivityTimeline`.
