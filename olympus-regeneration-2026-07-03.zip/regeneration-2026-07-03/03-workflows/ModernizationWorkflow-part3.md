# ModernizationWorkflow — Atomic Regeneration Spec (Part 3 of 3)

Continues from Parts 1-2. Covers commit helpers, `design-review.json` emission, BC parsing, pattern seeding, ready-for-review, RESILIENCE, GOTCHA index, and the Behavioral-parity checklist. Cites `temporal/olympus_workflows/workflows/modernization.py` unless noted.

---

## 16. `_commit_extract_artifacts(repo, branch, app_id)` (`:2392-2585`)
Returns `dedup_paths(committed_paths)`. `use_batch = workflow.patched("modernization-batch-writes-v1")` (`:2403`). `committed_paths = []`.

`step_to_artifact_filename` (`:2410-2417`): `extraction→business-rules.yaml`, `cross-validation→cross-validation-report.json`, `requirement-aggregation→modern-requirements.yaml`, `business-rule-reconciliation→rule-reconciliation-matrix.yaml`.

Loop over `["extraction","cross-validation","requirement-aggregation","business-rule-reconciliation"]` (`:2418`):
- `artifacts = _extract_results.get(step_name, []); if not artifacts: continue` (reconciliation steps absent on legacy path skip naturally) (`:2424-2426`).
- `filename = step_to_artifact_filename[step_name]; artifact_path = f"modernization/{app_id}/extract/{filename}"` (`:2428-2429`).
- `metadata = _agent_metadata.get(step_name,{}); output_files = metadata.get("output_files",[]); file_paths = [f.path for f in output_files] if output_files else []` (`:2431-2433`).
- `content = json.dumps({step, artifacts, file_artifacts=file_paths, model_used, duration_ms, token_usage={input,output}, cost_estimate_usd, timestamp=workflow.now().isoformat()}, indent=2)` (`:2435-2452`).
- `extract_commit_ctx = _execution_ctx(f"commit-extract-{step_name}", app_id=app_id)` (`:2454-2457`).
- **`if use_batch:`** (`:2458-2482`): `batch = [(artifact_path, content)]`; append `artifact_path` to committed; for each `file_artifact` in output_files: `file_path = f"modernization/{app_id}/extract/files/{step_name}/{file_artifact.path}"`; `batch.append((file_path, file_artifact.content))`; append committed. Then `execute_activity(write_artifacts_batch, WriteArtifactsBatchInput(repo, branch, files=batch, commit_message=f"modernization({app_id}): extract {step_name}", execution_context), timeout=120s, retry=transient, activity_id=f"commit-{step_name}")`.
- **`else:`** (`:2483-2527`): `execute_activity(write_artifact, WriteArtifactInput(repo, branch, path=artifact_path, content, commit_message, execution_context), timeout=60s, retry=transient, activity_id=f"commit-{step_name}")`; append `artifact_path`; then for each `file_artifact`: `file_path=...`; `write_artifact(... path=file_path, content=file_artifact.content, ... , activity_id=f"commit-file-{step_name}-{file_artifact.path.replace('/', '-')}")`; append.

Second: **test-scenarios.yaml** (`:2529-2583`): `extraction_artifacts = _extract_results.get("extraction",[]); if extraction_artifacts:` → `test_scenarios_path = f"modernization/{app_id}/extract/test-scenarios.yaml"`; `metadata = _agent_metadata.get("extraction",{})`; `content = json.dumps({step:"extraction-test-scenarios", artifacts, timestamp}, indent=2)`; commit via batch (120s) or write_artifact (60s), `activity_id="commit-test-scenarios"`; append path.

**GOTCHA:** batch path uses 120s timeout + single activity; non-batch path uses 60s per-file with derived activity_ids (path slashes → dashes). Both patch-gated by `modernization-batch-writes-v1` for replay determinism.

## 17. `_create_extract_pr(repo, branch, app_id, skill_id, reconciliation_ran=False)` (`:2587-2641`)
`rework = _rework_count("G-04a")`. Body header + Extraction Skill + artifacts (Business Rules, Test Scenarios, Cross-Validation Report). `if reconciliation_ran:` append 6 lines (Modern Requirements Catalog, Rule Reconciliation Matrix, Obsolete Rules Inventory, Modernization Gap Analysis, Vision Alignment Report, Conflict Resolution Log). `if rework>0: append rework note`. `create_pr(... title=f"Gate G-04a: Extracted Specifications Review — {app_id}", labels=["gate-review","modernization","extract","G-04a"], ...)`, 60s, transient.

---

## 18. `_commit_design_artifacts(repo, branch, app_id, audit_result=None)` (`:1385-1592`)
`use_batch = workflow.patched("modernization-batch-writes-v1")` (`:1411`). `committed_paths=[]`.

Loop `for step_name, skill_def in DESIGN_SKILLS.items()` (module-design, api-specification, data-modeling, batch-design) (`:1413`):
- `artifacts = _design_results.get(step_name,[]); if not artifacts: continue` (batch-design skipped if not batch archetype) (`:1414-1416`).
- `artifact_path = f"modernization/{app_id}/design/{skill_def['artifact']}"` (`:1418-1420`).
- `metadata`; `output_files`; `content = json.dumps({step, artifacts, model_used, duration_ms, timestamp}, indent=2)` (`:1421-1433`).
- `design_commit_ctx = _execution_ctx(f"commit-design-{step_name}", app_id=app_id)`.
- **`if use_batch:`** (`:1439-1469`): `batch=[(artifact_path,content)]`; append path; for each `file_artifact` in output_files: normalise dict-or-OutputFile → `(fa_path, fa_content)`; `file_path = f"modernization/{app_id}/design/files/{step_name}/{fa_path}"`; append to batch + committed; then `write_artifacts_batch(... commit_message=f"modernization({app_id}): design {step_name}", activity_id=f"commit-design-{step_name}")`, 120s, transient.
- **`else:`** (`:1470-1514`): `write_artifact(... path=artifact_path, activity_id=f"commit-design-{step_name}")`, 60s; append; then per-file `write_artifact(... path=file_path, activity_id=f"commit-design-file-{step_name}-{file_artifact.path.replace('/', '-')}")`, 60s; append.

**design-review.json emission** (`:1516-1571`): `review_path = f"modernization/{app_id}/design/design-review.json"`; `review_content_str = _build_design_review_content(app_id, audit_result, review_path)`; commit via `write_artifacts_batch` (120s) or `write_artifact` (60s), `activity_id="commit-design-review"`; append path.

Post-emission (`:1573-1590`): `_design_results["design-review"] = [review_path]`; and `_agent_metadata["design-review"] = {model_used:"", duration_ms:0, token_usage_input:0, token_usage_output:0, cost_estimate_usd:0.0, output_files:[OutputFile(path=review_path, content=review_content_str, encoding="utf-8")]}` — so `_build_evidence_data` carries the review content to the gate criteria check.

Return `dedup_paths(committed_paths)`.

## 19. `_build_design_review_content(app_id, audit_result, review_path)` (`:1594-1662`)
- **`if audit_result is not None:`** (`:1616-1632`): `for f in audit_result.output_files: if f.path.endswith("design-review.json"): return f.content`; else `if audit_result.output_files: return audit_result.output_files[0].content`; else (no files) `workflow.logger.warning(...)` and fall through to legacy default.
- **Legacy provisional default** (`:1634-1662`): `review_doc = {app_id, timestamp=workflow.now().isoformat(), forward_coverage:0.99, backward_coverage:0.99, critical_508_violations:0, journey_preservation_pct:1.0, bounded_contexts_defined:True, openapi_valid:True, ddd_elements_present:True, design_steps_evaluated=sorted(_design_results.keys()), provisional:True, provisional_note:"..."}`; `return json.dumps(review_doc, indent=2)`. **GOTCHA:** forward_coverage 0.99 emitted so BOTH Tier-1 (needs 0.99) and Tier-2/3 (needs 0.98) pass. These are the F3 G-04b threshold keys checked by `gate_operations.py`.

---

## 20. `_commit_generate_artifacts(repo, branch, app_id, bc_results)` (`:2176-2333`)
`committed_paths=[]`; `root_files: dict[str,str]={}` (first-writer-wins); `iac_manifest: tuple|None=None`.

**Summary artifact** (workflow metadata, always namespaced) (`:2211-2271`): `summary_path = f"modernization/{app_id}/generate/gate-review-package.json"`; `summary = {step:"generate", bounded_contexts:[{bc_name, status, iteration_count, escalation_id, test_results_count=len(r.test_results), output_artifacts_count=len(r.output_artifacts)} for r in bc_results], timestamp}`; `summary_content = json.dumps(summary, indent=2)`; commit via `write_artifacts_batch` (120s, if `modernization-batch-writes-v1`) or `write_artifact` (60s), `activity_id="commit-generate-summary"`; append.

**Per-source commit batches** (`:2273-2325`): `sources: list[(label, bc_name|None, output_files)]`. For each `bc_result` with `output_files`: append `(bc_result.bc_name, bc_result.bc_name, bc_result.output_files)`. Then for `step_name in ("synthesis","iac-scaffolding")`: `files = _agent_metadata.get(step_name,{}).get("output_files") or []; if files: sources.append((step_name, None, files))`.

For each `(label, bc_name, output_files)` (`:2291-2325`): `batch=[]`; for each `file_artifact`: `(fa_path, fa_content) = _output_file_fields(file_artifact)`; `dest = route_generate_file(app_id=app_id, bc_name=bc_name, path=fa_path)`:
- `if is_root_bound(fa_path):` → **first-writer-wins**: `if dest in root_files: continue`; else `root_files[dest] = fa_content` (`:2298-2302`).
- `elif fa_path.rsplit("/",1)[-1] == "iac-manifest.json":` → `iac_manifest = (dest, fa_content)` (`:2303-2304`).
- `batch.append((dest, fa_content)); committed_paths.append(dest)` (`:2305-2306`).
- `if batch: execute_activity(write_artifacts_batch, WriteArtifactsBatchInput(repo, branch, files=batch, commit_message=f"modernization({app_id}): generate {label}", execution_context=...), timeout=120s, retry=transient, activity_id=f"commit-generate-{label}")` (`:2307-2325`).

**GOTCHA (collision precedence, design §7 OQ-3):** `sources` order is BC code first, then `synthesis`, then `iac-scaffolding`. `root_files` first-writer-wins means a repo-root path written by an earlier source is NOT clobbered by a later one. The `continue` skips the duplicate from the batch entirely (not just from `root_files`).

**Stash for validator** (`:2327-2332`): `validator_files = list(root_files.items()); if iac_manifest is not None: validator_files.append(iac_manifest); self._committed_baseline_files = validator_files`. Return `dedup_paths(committed_paths)`.

`_output_file_fields(file_artifact)` staticmethod (`:2168-2174`): `if isinstance(file_artifact, dict): return file_artifact["path"], file_artifact["content"]; return file_artifact.path, file_artifact.content`.

---

## 21. `_parse_bounded_contexts(repo, app_id)` (`:2095-2166`)
- `module_map_artifacts = _design_results.get("module-design", []); if not module_map_artifacts: return ["default"]` (`:2113-2115`).
- `module_map_path = f"modernization/{app_id}/design/files/module-design/module-map.yaml"` (`:2120-2122`). **GOTCHA:** reads the real YAML under `files/` subdir, NOT the top-level `module-map.yaml` (which is a JSON metadata envelope).
- `try: read_result = execute_activity(read_artifact, ReadArtifactInput(repo, branch="main", path=module_map_path, execution_context=_execution_ctx("read-module-map", app_id, input_artifact_paths=[module_map_path])), timeout=60s, retry=transient, activity_id=f"read-module-map-{app_id}"); content = read_result.content` (`:2124-2141`). Reads from **main** (G-04b merged the design PR).
- `except Exception: workflow.logger.warning(...); return ["default"]` (`:2142-2147`).
- `bc_names = parse_bc_names_from_yaml(content); if not bc_names: return ["default"]` (`:2149-2151`).
- `if len(bc_names) > MAX_BC_CHILDREN_PER_APP (12): workflow.logger.warning("... truncating fan-out to cap of %d" ...)` (warn only; truncation happens at the fan-out slice in `_execute_generate`, NOT here) (`:2153-2165`).
- `return bc_names` (`:2166`).

## 22. `parse_bc_names_from_yaml(content)` — module function (`:2771-2813`)
Pure helper, no I/O. `if not content or not content.strip(): return []` (`:2787-2788`). `try: data = yaml.safe_load(content) except yaml.YAMLError: return []` (`:2790-2793`) — **`safe_load` only, never `load`**. `if not isinstance(data, dict): return []` (`:2795-2796`). `contexts = data.get("bounded_contexts") or data.get("contexts") or data.get("modules")` (fallback order) (`:2798-2802`). `if not isinstance(contexts, list) or not contexts: return []` (`:2803-2804`). For each `ctx` in contexts: `if not isinstance(ctx, dict): continue`; `name = ctx.get("name") or ctx.get("id"); if isinstance(name, str) and name.strip(): names.append(name.strip())` (`:2807-2812`). `return names`. Truncation to cap done at call site, not here.

---

## 23. `_seed_patterns_from_registry(portfolio_id)` (`:2650-2743`) — F5 cold-start
- `if not portfolio_id: return` (`:2670-2671`).
- `repo = f"olympus/{portfolio_id}-governance"; path = f"governance/{portfolio_id}/latest-patterns.json"` (`:2673-2674`).
- `try: read_result = execute_activity(read_artifact, ReadArtifactInput(repo, branch="main", path), timeout=30s, retry=transient, activity_id=f"read-governance-patterns-{portfolio_id}") except Exception as exc: workflow.logger.info("cold-start... not found..."); return` (`:2676-2696`).
- `try: payload = json.loads(read_result.content) except (JSONDecodeError, TypeError, ValueError) as exc: workflow.logger.warning("malformed..."); return` (`:2698-2709`).
- `if not isinstance(payload, dict): warning; return` (`:2711-2719`).
- `patterns = payload.get("patterns"); if not isinstance(patterns, list): return` (`:2721-2723`).
- `string_patterns = [p for p in patterns if isinstance(p, str)]; if not string_patterns: return` (`:2725-2727`).
- `source = payload.get("source") or {}; seed_wave_id = source.get("sweep_wave_id") if isinstance(source, dict) else None; if not isinstance(seed_wave_id, str) or not seed_wave_id: seed_wave_id = "governance-registry-cold-start"` (`:2729-2734`).
- `self._received_patterns.append({wave_id: seed_wave_id, patterns: string_patterns, received_at: _now_iso(), source: "cold-start-registry"})` (`:2736-2743`).

**GOTCHA:** best-effort, many early-returns; shares the same list as `wave_patterns_ready` signal (does not suppress live propagation). Docstring at `:2681-2683` says "skip retries" but the call uses `RETRY_POLICIES["transient"]` — the code does NOT actually skip retries (comment is stale/aspirational).

## 24. `_mark_ready_for_review(gate_id)` (`:2745-2768`)
`if workflow.patched("mark-gate-ready-for-review-v1"): execute_activity(mark_gate_ready_for_review, gate_id, timeout=30s, retry=transient)`. Fallback path (the `else` branch of the pre-review guard). Patch-guarded for replay determinism.

## 25. `_sum_weights(*steps)` (`:2647-2648`)
`return sum(STEP_WEIGHTS.get(s, 0.0) for s in steps)`.

---

## 26. Inherited helpers this workflow relies on (see `_base-workflow.md`)
- **`_wait_for_gate_decision(gate_type)`** (`base.py:1103-1157`): sets `_status=WAITING_FOR_SIGNAL`, `_pending_gate=gate_type`; `await wait_condition(lambda: len(_gate_decisions) > consumed or self.cancelled)`; on cancel → CANCELLED/"cancelled"; consumes entry (5-tuple or 3-tuple); on APPROVED clears `_rework_feedback[gate_key]` and returns "approved"; on rejection records feedback envelope `{gate, rejected_by, reason, reason_category, card_decisions, rejected_at}` and returns "rejected". **NOTE:** it does NOT increment `_rework_iterations` in this version — the subclass bumps via `_bump_rework` (docstring at base `:1107-1108` is inaccurate about incrementing).
- **`_reconcile_and_merge_with_retry_loop(repo, pr_number, gate_id, merge_method="merge")`** (`base.py:1159-1279`): `while True:` try `execute_activity(reconcile_and_merge_pr, MergePRInput(repo, pr_number, merge_method, execution_context), timeout=60s, retry=git_merge)`; success → return. On `(ActivityError, ApplicationError)`: unwrap `__cause__` chain to the `ApplicationError`; `failure_type = inner.type`; if not in `{MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected}` → re-raise; else build `detail`, log warn, `_merge_retry_signalled=False`, `execute_activity(set_gate_merge_blocked, args=[gate_id, detail], 30s, transient)`, `await wait_condition(lambda: _merge_retry_signalled or self.cancelled)`, `if self.cancelled: return`, loop.
  - `git_merge` retry policy (`retry_policies.py:95-105`): initial 5s, coeff 2.0, max 30s, max_attempts 3, `non_retryable_error_types=[MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected]`.
- **`_submit_gate_evidence`** (`base.py:922-1021`): builds slim evidence; enriches only threshold-artifact contents (G-04b `design-review.json` via `content_paths`); calls `check_gate_criteria` (with `evidence_data`+`risk_tier`) then `submit_gate_evidence` (60s each, transient).
- **`_run_gate_pre_review`** (`base.py:1023-1101`): dispatches `gate-pre-review` skill (best-effort, `AGENT_START_TO_CLOSE`, `AGENT_DISPATCH_HEARTBEAT_TIMEOUT`=2m, transient), stores output, and in `finally` flips ready-for-review under `mark-gate-ready-for-review-v1`.
- **`_set_step`** (`base.py:367-379`), **`_update_app_status`** (`base.py:380+`), **`_execution_ctx`** (`base.py:328-366`), **`_load_delegation_config`** (`base.py:514+`), **`_maybe_dispatch_bundle`** (`base.py:547-629`).

---

## 27. RESILIENCE

- **Timeouts:** agent dispatch = `AGENT_START_TO_CLOSE` = **3h** (`agent_timeouts.py:67`); gate/status/create-gate/persist/read = 30s or 60s; commits = 60s (single) / 120s (batch); merge = 60s; validator = 60s; pre-review heartbeat = 2m.
- **Retry policies:** `agent_failure` (3 attempts, 5→60s exp, coeff 2.0) for agent dispatch ONLY; `transient` (= HTTP_RETRY_POLICY, 3 retries, 1→15s exp) for every git/gate/status/persist/validator/read activity; `git_merge` (3 attempts, 5→30s, non-retryable merge errors) for merge.
- **Heartbeats:** none set on Modernization's own `_dispatch_agent` calls (only `_run_gate_pre_review` sets `heartbeat_timeout`).
- **Continue-as-new:** NONE. This workflow never calls `continue_as_new`. Long rework loops accumulate history — acceptable given 3-iteration caps per gate.
- **Idempotency / determinism:**
  - `run_suffix` derived deterministically from `workflow_id` (`:683`); child workflow ids + branch names are deterministic.
  - Every behavior change since first release is `workflow.patched(...)`-guarded: `br-reconciliation-v1`, `modernization-gate-pre-review-v1`, `mark-gate-ready-for-review-v1`, `modernization-batch-writes-v1`, `traceability-audit-v1`. Pre-patch in-flight runs replay their original path.
  - `workflow.now()` used for artifact timestamps (deterministic replay); `_now_iso()` for state timestamps.
  - `parse_bc_names_from_yaml` uses `yaml.safe_load` (no arbitrary object construction).
- **Compensation/rollback:** none — no explicit sagas. Failed steps set `_status=FAILED` + status projection and return "failed"; the top-level `run` catches any exception, sets FAILED, best-effort status update, and re-raises. Merge failures route to `merge_blocked` and wait for reviewer retry (no auto-rollback of committed artifacts).
- **Concurrency quirk:** BC children run in parallel via `asyncio.gather`; ANY child exception fails the whole Generate step (no partial-success handling at the parent level — partial results are surfaced only via each child's `GenerateBCResult.status`/`escalation_id` when the child itself completes with a non-completed status).

---

## 28. GOTCHA index (consolidated)
1. `MAX_BC_CHILDREN_PER_APP` = **12**, not 5 (docstring stale) (`types.py:135`).
2. Reconciliation steps have weight 0.0 to keep sum=100 and preserve legacy progress (`:184-199`).
3. G-04c rework counter is shared between reviewer-rejection AND deterministic baseline-validation failure; the baseline-fail path `continue`s without ever creating a gate PR (`:1948-1972`).
4. `_devsecops_params` resolved once, reused across Generate reworks (`:1729`).
5. `_committed_baseline_files` repopulated every Generate iteration → validator always sees the latest commit (`:2332`).
6. First-writer-wins for root-bound files; `sources` order (BC → synthesis → iac) decides precedence (`:2291-2306`).
7. `_parse_bounded_contexts` reads the `files/module-design/module-map.yaml` (real YAML), not the top-level envelope (`:2120`).
8. Tier-1 sub-waits: G-04a needs SME (`g-04a-sme`); G-04c needs BOTH `g-04c-ea` AND `g-04c-security`; G-04b has NONE (`:945-951`, `:2041-2050`).
9. Tier-1 flags reset in the respective rework branches so prior-cycle approvals don't leak (`:985`, `:2079-2080`, and baseline-fail `:1958-1959`).
10. `_dispatch_agent` `activity_id=f"agent-{step_name}"` — step_names must be unique per phase.
11. `_rework_gate_key_for_step` maps `synthesis`→G-04a (extract set) and `adversarial-review`/`gate-review-package`→G-04b (design set); Generate direct dispatches get no rework feedback (returns None) (`:311-333`).
12. `repo` = `target_repo_url` when set, else `artifact_repo` (`:679`) — commits land in the target app repo.
13. `security-scan-review` is the ONLY generate dispatch wrapped in try/except (best-effort) (`:1870-1883`).
14. `_seed_patterns_from_registry` docstring claims "skip retries" but uses `transient` policy — comment is stale (`:2681-2684`).
15. `_persist_side_effects` failures are swallowed (observability-only) — gate approval still completes (`:1059-1064`).
16. design-review.json provisional path emits forward_coverage=0.99 so both tiers pass (`:1642`).
17. Only `"approved"` from a step continues `_execute_modernization`; all other returns short-circuit (`:707-722`).
18. No base signal handler is overridden; overriding `gate_approved`/`gate_rejected`/`merge_retry`/`cancel_workflow`/`bundle_*` would break shared wiring.

---

## 29. Behavioral parity checklist
A rebuild MUST satisfy all of the following:

1. **Three gates in order:** Extract→G-04a, Design→G-04b, Generate→G-04c; each step returns "approved"/"failed"/"cancelled" and only "approved" advances. Final result "completed" with progress 100.0, status COMPLETED.
2. **Progress checkpoints (Tier-agnostic):** extract 0→15→20→22.5; design 30→45→47.5; generate 55→80→85→90→97.5→100. `_sum_weights` cumulative bases: design_base=30.0, generate_base=55.0.
3. **Extraction skill** chosen via `select_skill(EXTRACTION_COMPOSITION, extraction_selector_inputs(prior_artifacts)) or "extraction"`; `discovery/{app_id}/business-logic.json` prepended to extract inputs when absent.
4. **BR reconciliation** dispatches (`requirement-aggregation`, `business-rule-reconciliation`) fire ONLY under `br-reconciliation-v1`; reconcile input = extraction outputs + req-agg outputs; `reconciliation_ran` toggles the PR body's extra 6 artifact lines.
5. **G-04a Tier-1** waits for `g-04a-sme` (or cancel); Tier-2/3 skip. Post-approve: persist side effects (`extract` phase) then merge-with-retry (`merge_method="merge"`).
6. **Design** runs `_maybe_dispatch_bundle("modernization-design", line_step, expires_hours=168)`; dict result → fold outputs + null audit; else internal chain module-design→api-spec→data-modeling→(batch-design if any prior artifact contains "batch")→traceability-audit(always). data-modeling input = module output. design-review.json emitted (audit content if present & path endswith design-review.json, else first file, else provisional defaults).
7. **G-04b** has NO Tier-1 sub-wait. Post-approve: persist (`design` phase) + merge.
8. **Generate** resolves DevSecOps params once; parses BCs from `modernization/{app_id}/design/files/module-design/module-map.yaml` on main (fallback `["default"]`); fan-out ≤12 children on same task queue; frontend BC names {frontend,ui,web-app,spa} → target_frontend (or "react"), else target_framework (or "express"); `asyncio.gather`; dicts re-boxed to `GenerateBCResult`.
9. **Generate synthesis chain:** code-synthesis(union of BC artifacts)→adversarial-review→security-posture-review→[security-scan-review best-effort]→iac-scaffolding-generator→gate-review-package.
10. **Commit routing:** BC → synthesis → iac ordering with first-writer-wins on root-bound files; iac-manifest.json captured separately; `_committed_baseline_files` = root files + iac manifest.
11. **G-04c validator gate:** `validate_devsecops_baseline` with committed files + sast_tool; on `not passed` → reset EA+security flags, bump G-04c, fail at >3 else `continue` (no gate PR created).
12. **G-04c Tier-1** waits for `g-04c-ea AND g-04c-security` (or cancel); Tier-2/3 skip. Post-approve: persist (`generate` phase) + merge.
13. **Rework caps:** each gate fails the workflow when its counter exceeds 3 (4th rejection), with the exact `_current_step` sentinel and `_update_app_status(..., "modernization_failed", <sentinel>, ...)`.
14. **Merge retry loop:** structured merge errors (`MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected`) → `set_gate_merge_blocked` + wait for `merge_retry` signal (or cancel); other errors propagate.
15. **Signals:** `stakeholder_approved` routes 3 known scopes, warns+ignores unknown; `wave_patterns_ready` appends bundles additively; `get_received_patterns` returns shallow copies.
16. **Patch gates** honoured: `br-reconciliation-v1`, `modernization-gate-pre-review-v1`, `mark-gate-ready-for-review-v1`, `modernization-batch-writes-v1`, `traceability-audit-v1`.
17. **Retry/timeout parity:** agent dispatch 3h + agent_failure; commits 60s/120s + transient; merge 60s + git_merge; validator/gate/status 30-60s + transient.
18. **Failure containment:** `_persist_side_effects` and `security-scan-review` failures never abort; top-level `run` sets FAILED + best-effort status + re-raises on any uncaught exception.
