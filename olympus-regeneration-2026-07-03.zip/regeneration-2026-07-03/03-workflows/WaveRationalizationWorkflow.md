# WaveRationalizationWorkflow — Atomic Regeneration Spec (Part 1 of 3)

Source: `temporal/olympus_workflows/workflows/wave_rationalization.py` (6674 lines).
Class decl: `wave_rationalization.py:1162-1163` (`@workflow.defn class WaveRationalizationWorkflow(HILSignalsMixin)`).

**Parity bar:** a rebuild must reproduce the exact sequencing, every patch-guarded branch, every fan-out/synthesis parallelism decision, every rework loop, and every signal-buffering behavior. A summary is a failure.

This part covers: (0) module-level pure functions & constants, (1) STATE, (2) SIGNALS & QUERIES.
Part 2 (`WaveRationalizationWorkflow-part2.md`) covers `run()` / `_execute()` control flow, gate loops, and per-app fan-out.
Part 3 (`WaveRationalizationWorkflow-part3.md`) covers Architecture/Data fan-out, helpers, gate plumbing, and the behavioral-parity checklist.

Inherited behavior (constructor `super().__init__()`, `self.cancelled`, `cancel_workflow` signal, plan/document HIL fields) is in `HILSignalsMixin` (`temporal_base/signals.py:19-105`) — see `_base-workflow.md`. This class does NOT inherit from `LineWorkflowBase`; it inlines its own `_execution_ctx`, `_run_gate_pre_review`, `_reconcile_and_merge_with_retry_loop`, and `merge_retry` (docstrings say so explicitly: `wave_rationalization.py:1292-1293, 5371-5385, 6116-6119, 6228-6232`).

---

## 0. Module-level pure functions & constants (imported/used by the class)

### 0.1 `_now_iso()` — `:142-143`
Returns `workflow.now().isoformat()`. GOTCHA: uses `workflow.now()` (deterministic Temporal clock), never `datetime.now()`. Every timestamp in state uses this.

### 0.2 `_normalize_relationship(relationship: str | None) -> str` — `:146-163`
- `if not relationship: return ""` (`:161-162`) — covers None, empty, and (after strip) whitespace via truthiness of the arg only; whitespace-only non-empty still passes the guard then `.strip().lower()` → `""`.
- else `return relationship.strip().lower()` (`:163`).
- GOTCHA: This is the MANDATORY canonicalizer. The v2 plan spells `relationship` lowercase (`"replace"`, `"consolidate"`); the legacy v1 path threads it through `cfg.disposition` which is Title-cased ("Consolidate"). Every read of `relationship` from plan/v2-payload/v1-fallback/signal MUST go through this or the fan-out silently routes around the consolidate code paths (`:150-159`).

### 0.3 `_legacy_disposition_from_relationship(relationship: str | None) -> str` — `:166-180`
- `rel = _normalize_relationship(relationship)` (`:177`).
- `if not rel: return ""` (`:178-179`).
- `return rel[:1].upper() + rel[1:]` (`:180`) — Title-case first char only. So `"consolidate"` → `"Consolidate"`, `"CONSOLIDATE"` → `"Consolidate"`.

### 0.4 `_PORTFOLIO_SCORER_DIMENSIONS` — `:183-190`
Tuple (order matters for iteration): `technical_readiness`, `architectural_readiness`, `operational_readiness`, `security_readiness`, `user_experience_readiness`, `business_readiness`.

### 0.5 `_classification_is_tier_1(cls_json: str) -> bool` — `:193-219`
`import json` locally. Logic:
1. `if not cls_json: return False` (`:205-206`).
2. `try: parsed = json.loads(cls_json)` except `(JSONDecodeError, TypeError, ValueError): return False` (`:207-210`).
3. `if not isinstance(parsed, dict): return False` (`:211-212`).
4. `if parsed.get("tier_1_flag") is True: return True` (`:213-214`) — strict `is True`.
5. `risk = parsed.get("risk_tier")`; `try: return int(risk) == 1 if risk is not None else False` except `(TypeError, ValueError): return False` (`:215-219`).
- GOTCHA: safe default is False = "don't pause for stakeholder"; G-DA still runs regardless (`:198-201`). Accepts `risk_tier` as int OR string.

### 0.6 `_parse_classification_summary(cls_json, narrative="") -> dict` — `:222-276`
Builds the reviewer-facing tier-1 justification. Default `out` dict: `risk_tier=1, risk_rationale="", risk_confidence=0.0, archetype="", complexity_tier="", narrative=(narrative or "")` (`:238-245`). Defensive parse (empty/JSONError/non-dict → return default, `:246-253`). Then:
- `risk_tier`: `int(risk)` if not None, swallow `(TypeError, ValueError)` (`:255-260`).
- `risk_rationale`: only if `isinstance(rationale, str)`, `.strip()` (`:261-263`).
- `risk_confidence`: only if `isinstance(conf,(int,float)) and not isinstance(conf,bool)`, then `max(0.0, min(1.0, float(conf)))` — clamp to [0,1] (`:264-267`).
- `referenced_catalog` → `archetype`, `complexity_tier` (each str-guarded + stripped) (`:268-275`).
- GOTCHA: returns a plain dict (not the dataclass) so it stays unit-testable outside the sandbox; the query wraps it into `PendingTier1Classification` (`:233-234`).

### 0.7 `_compute_overall_readiness(score_json: str) -> tuple[float|None, list[str]]` — `:279-323`
Pure deterministic (no activity round-trip). `import json`. Returns `(overall_weighted, dimensions_present)`.
1. empty/parse-fail/non-dict → `(None, [])` (`:291-298`).
2. `scores = parsed.get("scores")`; if not dict → `(None, [])` (`:299-301`).
3. Iterate `_PORTFOLIO_SCORER_DIMENSIONS` in order; for each dim:
   - `entry = scores.get(dim)`; `if not isinstance(entry, dict): continue` (`:306-308`).
   - `value = entry.get("score")`; `if value is None: present.append(dim); continue` (`:309-312`) — null-scored dims are recorded as present but EXCLUDED from denominator.
   - `try: value_f = float(value)` except `(TypeError,ValueError): continue` (`:313-316`).
   - `value_f = max(0.0, min(100.0, value_f))` clamp; `total += value_f; count += 1; present.append(dim)` (`:317-320`).
4. `if count == 0: return None, sorted(present)` (`:321-322`).
5. `return round(total / count, 2), sorted(present)` (`:323`) — equal-weight mean, 2-dp round. GOTCHA: matches historical `persist_portfolio_score`; `present` is SORTED, not dispatch order.

### 0.8 Failure classification — `:345-442`
- `RECOVERABLE_FAILURE_ACTIVITIES: frozenset` = `{create_target_app_and_repo, update_wave_status, update_application_line_projection}` (`:345-359`) — activities that run AFTER all wave artifacts committed.
- `TERMINAL_FAILURE_ACTIVITIES: frozenset` = `{dispatch_agent_task, validate_artifact_against_schema, write_artifact, create_pr, reconcile_and_merge_pr, persist_rationalization_side_effects, create_gate_record, submit_gate_evidence, mark_gate_ready_for_review, set_gate_merge_blocked}` (`:367-389`).
- `classify_failure(exc) -> str` (`:392-442`): walks the exception cause chain (`__cause__` then `__context__`), guarding against cycles via `seen: set[int]` of `id()` (`:418-434`). For each exc probes attrs `("activity_type","activity_name","_activity_type")` for a non-empty str, appends first match (`:426-430`). Then iterates collected names: first name in RECOVERABLE → `"recoverable"`, first in TERMINAL → `"terminal"` (`:436-440`). Default (no match / bare exc) → `"terminal"` (`:442`) — safe default matching pre-task-#88 behavior.
- GOTCHA: order in the name-loop matters: a chain containing both a recoverable and terminal name returns whichever appears FIRST in `activity_names` (which is outermost-first from cause walk).

### 0.9 `SKILLS` dict — `:449-539`
Maps workflow-local skill keys → `{skill_id, artifact[, companion_artifact]}`. Critical entries (used to build dispatch payloads & artifact paths):
| key | skill_id | artifact | companion |
|---|---|---|---|
| `cross-app-redundancy` | `redundancy-analyzer` | `redundancy-matrix.json` | |
| `compare-ux-overlap` | `compare-ux-overlap` | `ux-overlap-matrix.json` | |
| `wave-outcome-synthesis` | `wave-outcome-synthesizer` | `wave-outcome-synthesis.json` | |
| `intra-app-redundancy` | `redundancy-analyzer` | `intra-app-redundancy.json` | |
| `portfolio-integration-mapping` | `portfolio-integration-mapper` | `integration-graph.json` | |
| `analyze-portfolio-redundancy` | `analyze-portfolio-redundancy` | `portfolio-redundancy-matrix.json` | `shared-identity-report.json` |
| `cross-app-business-rule-analysis` | `cross-app-business-rule-analyzer` | `business-rule-redundancy.json` | |
| `disposition-recommendation` | `disposition-recommender` | `disposition-recommendation.json` | |
| `capability-consolidation-advisory` | `capability-consolidation-advisor` | `capability-consolidation-plan.json` | |
| `disposition-governance` | `disposition-governance` | `disposition-governance.json` | |
| `user-impact` | `assess-user-impact` | `user-impact-analysis.json` | |
| `classification` | `classify-application` | `classification.json` | |
| `portfolio-score` | `portfolio-scorer` | `portfolio-score.json` | |
| `wave-plan` | `sequencer` | `wave-plan.json` | |
GOTCHA: `redundancy-analyzer` is reused for both cross-app and intra-app (agent branches on `context.scope`) (`:468-471`).

### 0.10 `RATIONALIZATION_STEPS` dict — `:586-709`
Contract-facing step registry keyed by contract step-ids, with `title, skill_id, artifact, kind="agent", depends_on[]` (+ optional `dispatch_pending: True`). Distinct from `SKILLS` because SKILLS keys conflate role vs step-id (`:555-560`). The `depends_on` graph drives the rework resolver. Insertion order == dispatch order (used for stable ordering). Dependency edges:
- `cross-app-redundancy`, `intra-app-redundancy`, `compare-ux-overlap`, `portfolio-integration-mapping`: `depends_on=[]`.
- `analyze-portfolio-redundancy`: `depends_on=[cross-app-redundancy, intra-app-redundancy, compare-ux-overlap, portfolio-integration-mapping]`.
- `disposition-recommendation`: `[analyze-portfolio-redundancy]`.
- `disposition-governance`, `user-impact-analysis`: each `[disposition-recommendation]`.
- `classification`: `[disposition-governance]`.
- `portfolio-scoring`: `[classification]`.
- `capability-consolidation-advisory`: `[analyze-portfolio-redundancy]`, `dispatch_pending: True`.
- `wave-planning`: `[portfolio-scoring, user-impact-analysis]`.
- `wave-outcome-synthesis`: `[wave-planning]`.
- `portfolio-manifest-generation`: `[wave-outcome-synthesis]`, `dispatch_pending: True`.
GOTCHA: `cross-app-business-rule-analysis` is intentionally NOT in this registry (lives only in SKILLS) — the contract-compliance CI guard enforces parity vs the contract YAML which doesn't list it (`:615-623`).

### 0.11 `rework_targets_for(rejected_step) -> list[str]` — `:712-742`
- `if rejected_step not in RATIONALIZATION_STEPS: return []` (`:728-729`).
- `affected = {rejected_step}`; fixed-point loop (`progressed` flag): for each `step_id, spec` not in affected, if any of its `depends_on` is in affected → add it, set `progressed=True` (`:730-740`).
- `return [s for s in RATIONALIZATION_STEPS if s in affected]` — stable insertion order (`:742`).
Returns the transitive downstream closure of the rejected step (the step + every consumer). `[rejected_step]` for a terminal step.

### 0.12 `_step_id_for_artifact(artifact_filename) -> str|None` — `:750-755`
Linear scan of `RATIONALIZATION_STEPS` for `spec["artifact"] == artifact_filename`.

### 0.13 `rework_targets_from_card_decisions(card_decisions: list[dict]) -> list[str]` — `:758-796`
Union of rework targets across rejected cards.
- `affected: set = set()`; for each `entry` in `card_decisions or []`:
  - `if not isinstance(entry, dict): continue` (`:777-778`).
  - `if entry.get("decision") != "reject": continue` (`:779-780`) — only rejects.
  - `artifact_type = entry.get("artifact_type") or ""` (`:781`).
  - `step_id = _step_id_for_artifact(artifact_type)` (`:786`).
  - fallback: `if step_id is None:` try `card_id = entry.get("card_id") or ""`; `if card_id in RATIONALIZATION_STEPS: step_id = card_id` (`:787-791`).
  - `if step_id is None: continue` (`:792-793`).
  - `for s in rework_targets_for(step_id): affected.add(s)` (`:794-795`).
- `return [s for s in RATIONALIZATION_STEPS if s in affected]` — insertion order (`:796`).
GOTCHA: gate-level cards (gate_summary, ai-pre-review) carry no mappable artifact_type → silently skipped; empty result → whole-gate rerun fallback later.

### 0.14 `STEP_WEIGHTS` dict + assert — `:803-832`
Progress weights summing to 100 (module-load `assert abs(sum - 100.0) < 0.01`, `:832`). Values: `cross-app-redundancy=8.0, intra-app-redundancy=5.0, compare-ux-overlap=5.0, portfolio-integration-mapping=4.0, analyze-portfolio-redundancy=5.0, cross-app-business-rule-analysis=3.0, commit-redundancy-artifacts=2.0, create-grr-pr=1.0, gate-review-rr=7.0, disposition-recommendation=8.0, disposition-governance=7.0, user-impact-analysis=4.0, classification=8.0, portfolio-scoring=7.0, wave-planning=8.0, factory-routing=1.0, commit-disposition-artifacts=2.0, create-gda-pr=1.0, gate-review-da=9.0, wave-outcome-synthesis=5.0`.
GOTCHA: progress `_set_step` calls sum a subset of these to compute the cumulative pct — see Part 2 for the exact accumulator expressions.

### 0.15 `MAX_REWORK_ITERATIONS = 3` — `:834`
Both G-RR and G-DA rework loops fail the workflow when their counter EXCEEDS 3 (i.e. the 4th rejection). See Part 2.

### 0.16 `_is_retire_or_replace_disposition(disp) -> bool` — `:837-840`
`if not disp: return False`; `return disp in ("Retire", "Replace")`. Gates whether user-impact runs.

### 0.17 Artifact-path helper functions — `:843-1035`
All pure. Path prefixes are load-bearing (downstream skills consume them):
- `_business_logic_artifact(app_id)` → `discovery/{app_id}/business-logic.json` (`:851`).
- `_business_logic_artifacts_for_wave(app_ids)` → list of the above (`:856`).
- `_ux_overlap_input_artifacts(app_ids)` → per app: `discovery/{app_id}/ux-accessibility.json`, `discovery/{app_id}/catalog.json` (`:874-878`). GOTCHA: docstring says `catalog-application.json` but code emits `catalog.json` (`:877`).
- `_DISCOVERY_PASSES` tuple = `(catalog, structural-analysis, business-logic, quality-risk, ux-accessibility, tco-baseline, synthesis)` (`:888-896`).
- `_discovery_passes_for_app(app_id)` → `discovery/{app_id}/{name}.json` for each pass (`:907`).
- `_requirements_capability_artifact(app_id)` → `build/{app_id}/requirements/requirements-capability.json` (`:917`) — greenfield Build input.
- `_wave_context_artifacts(wave_id, app_id)` → prefix `rationalization/wave-{wave_id}`: `[{p}/redundancy-matrix.json, {p}/ux-overlap-matrix.json, {p}/integration-graph.json, {p}/portfolio-redundancy-matrix.json, {p}/{app_id}/intra-app-redundancy.json]` (`:943-950`). REQUIRED per-app cross-app context.
- `_wave_context_optional_artifacts(wave_id)` → `[rationalization/wave-{wave_id}/shared-identity-report.json]` (`:971-974`). GOTCHA: MUST be optional — the rewritten PRA skill no longer always emits it; a required-missing 404 previously took down every per-app disposition (`:954-970`).
- `_portfolio_integration_input_artifacts(app_ids)` → per app `discovery/{app_id}/catalog.json`, `discovery/{app_id}/structural-analysis.json` (`:985-989`).
- `_portfolio_redundancy_input_artifacts(wave_id, app_ids)` → `[{p}/redundancy-matrix.json, {p}/integration-graph.json]` + per app `{p}/{app_id}/intra-app-redundancy.json`, `discovery/{app_id}/business-logic.json` (`:1001-1009`).
- `_cross_app_business_rule_input_artifacts(app_ids)` → each app's `business-logic.json` (`:1021`).
- `_disposition_input_artifacts(wave_id, app_id)` → `_discovery_passes_for_app(app_id) + _wave_context_artifacts(wave_id, app_id)` (`:1033-1035`).

### 0.18 `_with_context_priors(context, skill_id) -> dict` (async, module-level) — `:1038-1080`
Best-effort: executes `load_context_priors` activity with `LoadContextPriorsInput(skill_id=skill_id)`, `start_to_close_timeout=10s`, `retry_policy=transient` (`:1057-1062`). On ANY exception → log warning, `return context` unchanged (`:1063-1069`). `priors = getattr(result,"priors",None) or []`; if empty → return context (`:1070-1072`). Else `merged=dict(context); merged["context_priors"]=priors; return merged` (`:1073-1079`).
GOTCHA: This is an async free function that awaits an activity — callers must `await` it BEFORE building `AgentTaskInput.context`. Only PRA + disposition-recommendation dispatches use it.

### 0.19 `_with_fixture_scenario(context, skill_id, fixture_scenarios) -> dict` — `:1083-1103`
`scenario = fixture_scenarios.get(skill_id) if fixture_scenarios else None`; if falsy → return context unchanged (`:1097-1099`). Else shallow-copy context, set `merged["fixture_scenario"]=scenario`, return (`:1100-1103`). No-op in prod (empty map). DECISION-018 test hook. Threaded through EVERY `AgentTaskInput.context` the workflow builds.

### 0.20 `_build_rationalization_step_entry(title, skill_id, artifact_filename, result) -> dict` — `:1106-1159`
Builds one `evidence_data.steps` map entry for the gate UI. `primary_output = result.output_artifacts[0] if result.output_artifacts else ""` (`:1123-1125`). Iterates `result.output_files`, handling dict OR dataclass shape (`path/content/encoding`, default encoding `"utf-8"`) (`:1128-1144`), skipping empty-path files. Returns `{title, skill_id, artifact, output, file_artifacts, metadata:{model_used, duration_ms, token_usage_input, token_usage_output, cost_estimate_usd}}` (`:1146-1159`).

---

## 1. STATE (instance variables) — `__init__` at `:1172-1346`

`super().__init__()` first (`:1173`) → inherits `HILSignalsMixin` fields including **`self.cancelled: bool = False`** (`signals.py:45`), `self.approved`, plan/document HIL fields (unused by this workflow's own logic but present).

| Var | Type | Init | Mutated by / when |
|---|---|---|---|
| `_wave_id` | `str` | `""` | `run()` sets from `input.wave_id` (`:1355`). Read everywhere. |
| `_portfolio_id` | `str` | `""` | `run()` from `input.portfolio_id` (`:1356`). `_execution_ctx` returns None if empty (`:1386-1387`). |
| `_status` | `WorkflowStatus` | `PENDING` | `run()`→RUNNING (`:1354`); FAILED on outer exception (`:1371`); `_wait_for_gate`→WAITING_FOR_SIGNAL/CANCELLED/RUNNING (`:5945,5956,5971`); `_execute` terminal→COMPLETED/FAILED (`:3488,3503,3505,3513`); rework-exceeded→FAILED (`:2508,3280`); G-DA cancel→CANCELLED (`:3254`); `cancel_all_children`→CANCELLED (`:6445`). |
| `_current_step` | `str` | `""` | `_set_step` (`:5934`); many literals: `"failed"` (`:1372`), `"max-rework-exceeded-grr"/-gda"` (`:2509,3281`), `f"awaiting-tier1-approval-{app_id}"` (`:4307`), `"awaiting-architecture-dispatch"` (`:5112`), `"cancelled"` (`:6446`), terminal (`:3490,3507,3515`). |
| `_progress_pct` | `float` | `0.0` | `_set_step` clamps to [0,100] (`:5935`); terminal→100.0 (`:3489,3506,3514`). |
| `_pending_gate` | `GateType\|None` | `None` | `_wait_for_gate` sets to `GateType(gate_key)` if valid else None (`:5944`), clears to None after decision (`:5970`). |
| `_started_at` | `str` | `""` | `run()`→`_now_iso()` (`:1357`). |
| `_updated_at` | `str` | `""` | Touched on nearly every state change via `_now_iso()`. |
| `_pending_tier1_classification` | `PendingTier1Classification` | `PendingTier1Classification()` (empty) | Set in `_classify_app` at tier-1 pause (`:4316-4324`), cleared to empty after approval (`:4333`). Read by `pending_tier1_classification` query. |
| `_gate_decisions` | `dict[str, list[tuple]]` | `{}` | Per-gate decision queue keyed by gate_key str ("G-RR"/"G-DA"). Appended by `gate_approved`/`gate_rejected` handlers (`:6352,6376`), by `_register_gate_key` flush (`:6321-6322`). Consumed by `_wait_for_gate`. 5-tuple: `(status, actor, reason, reason_category, card_decisions)` (`:1197-1199`). |
| `_gate_decisions_consumed` | `dict[str,int]` | `{}` | Per-gate consume counter; `_wait_for_gate` increments (`:5969`). Lets G-RR & G-DA land independently. |
| `_gate_id_to_key` | `dict[str,str]` | `{}` | gate UUID → gate_key. Populated by `_register_gate_key` (`:6318`). GOTCHA: gate_ids are UUIDs, NOT prefixed — pre-0.2 code parsed prefixes and dropped every signal (`:1204-1210`). |
| `_pending_signals_by_gate_id` | `dict[str, list[tuple[GateStatus,str,str]]]` | `{}` | Buffer for signals arriving BEFORE `create_gate_record`. Flushed by `_register_gate_key` (`:6319-6322`). GOTCHA: without this, races drop signals and the workflow hangs in `_wait_for_gate` forever (reproduced under CI/xdist load) (`:1213-1224`). |
| `_stakeholder_approved` | `bool` | `False` | Set True by `stakeholder_approved` signal when scope != tier-1 (`:6478`). Consumed (reset False) after G-DA dual-signal wait (`:3257`); reset False on G-DA rejection (`:3277`). |
| `_stakeholder_info` | `str` | `""` | Set `f"{stakeholder} approved scope: {scope}"` (`:6479`). |
| `_tier1_approval_records` | `dict[str, dict[str,str]]` | `{}` | Full tier-1 approval record per app; set by `stakeholder_approved` tier-1 branch (`:6470-6476`). Surfaced sorted into G-DA evidence (`:3217-3220`) and pre-review context (`:6162-6165`). |
| `_tier1_approved_apps` | `set[str]` | `set()` | Derived view; `.add(app_id)` in tier-1 signal branch (`:6465`). `_classify_app` wait_condition checks membership (`:4326`); post-G-DA projection passes `tier_1_approved=app_id in set` (`:4507`). |
| `_rework_iterations_grr` | `int` | `0` | `+=1` on each G-RR rejection (`:2506`); `> MAX_REWORK_ITERATIONS`→fail (`:2507`). Read into G-RR PR body + rework commit messages. |
| `_rework_iterations_gda` | `int` | `0` | `+=1` on each G-DA rejection (`:3278`); `> 3`→fail (`:3279`). |
| `_rework_feedback` | `dict[str, dict]` | `{}` | Keyed by gate_key. Set on rejection in `_wait_for_gate` (`:6004-6012`) with `{gate, rejected_by, reason, reason_category, card_decisions, rework_targets, rejected_at}`. Popped on approval (`:5974`). Merged with row-rework in `_merge_capability_lineage_row_rework` (`:6093`). Read into disposition/PRA/cross-app rework dispatch contexts. |
| `_approval_feedback` | `dict[str, dict]` | `{}` | Approve-with-guidance. Set on approval when reviewer left non-empty justification (`:5982-5987`); popped on empty approval (`:5989`) and on rejection (`:5995`). `_per_app_pipeline` folds `_approval_feedback.get("G-RR")` into disposition context as `approval_guidance` (`:3892`). |
| `_validation_warnings` | `dict[str, list[str]]` | `{}` | Keyed by `app_id` or `f"wave-{wave_id}"`. Extended by `_validate_artifact_or_warn` (`:5470-5472`) and rat-cap zero-persist detection (`:5223-5225`). Surfaced (copied) into G-RR (`:2428`) & G-DA (`:3209`) evidence. Non-blocking. |
| `_build_app_ids` | `list[str]` | `[]` | P6-S15.2 greenfield partition. Set by `_partition_wave_by_intake` (`:3645`). Empty when no Build apps (determinism-preserving default) (`:1283`). |
| `_legacy_app_ids` | `list[str]` | `[]` | Complement; `run()`/`_execute` init to `list(input.app_ids)` (`:1475`), overwritten by partition (`:3646`). |
| `_build_recommendations` | `dict[str, dict]` | `{}` | Per build-app `build_recommendation`; set in `_build_app_pipeline` (`:3756`). |
| `_merge_retry_signalled` | `bool` | `False` | Set True by `merge_retry` signal (`:6304`); reset False before each merge_blocked wait (`:6284`); waited on (`:6292`). |
| `_architecture_child_handles` | `list[tuple[str, Any]]` | `[]` | `(child_workflow_id, handle)` tuples for cancel. GOTCHA: docstring describes population "as each ArchitectureWorkflow child is spawned" but in the current code `_spawn_children_for_target` does NOT append to it — it stays empty except conceptually; `cancel_all_children` iterates it (`:6417`) and clears it (`:6439`). Empty list makes the cancel loop a no-op. |
| `_cancel_all_children_requested` | `bool` | `False` | Set True by `cancel_all_children` (`:6414`). |
| `_dispatch_received` | `bool` | `False` | Set True by `dispatch_architecture`/`_v2` (`:6507,6533`). `wait_condition` in `_execute_architecture_data_fanout` (`:5132`). |
| `_dispatch_payload` | `DispatchArchitecturePayload\|None` | `None` | Normalized payload; set by both dispatch signals (`:6506,6532`). Read in fanout + retry drain. |
| `_dispatch_status` | `dict[str, DispatchTargetStatus]` | `{}` | Per-target status keyed by `target_app_id or source_app_id` (`_dispatch_key`). Seeded by `_init_dispatch_status` (`:4721`); mutated through provisioning/spawn/completion. Read by `dispatch_results` query. |
| `_pending_dispatch_entries` | `list[PendingDispatchEntry]` | `[]` | Pre-dispatch per-app preview; set in `_execute_architecture_data_fanout` (`:5113`). Read by `pending_dispatch_payload` query. |
| `_pending_target_dispatch_entries` | `list[PendingTargetDispatchEntry]` | `[]` | v2 per-target preview; set (`:5120-5124`). Read by `pending_target_dispatch_payload` query. |
| `_v2_dispatch_meta` | `dict[str, dict[str,str]]` | `{}` | Keyed by `target_app_id`; captures `target_service_id`+`relationship`. Set by `_extract_v2_metadata` via both dispatch signals (`:6504,6530`). GOTCHA: keyed by target_app_id NOT source (PR #495 fix — N targets share an anchor) (`:6542-6548`). |
| `_pending_retries` | `list[RetryTargetDispatchPayload]` | `[]` | Queue; appended by `retry_target_dispatch` signal (`:6605`); drained by `_drain_retry_queue` (`:5312`). |

---

## 2. SIGNALS & QUERIES

### 2.1 Inherited signals (`HILSignalsMixin`, `signals.py`)
`approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`, **`cancel_workflow`** (sets `self.cancelled = True`, `signals.py:84-86`). Only `cancel_workflow`/`self.cancelled` is load-bearing here — every `wait_condition` predicate ORs `self.cancelled` so cancellation unblocks each wait. The plan/document signals are inert for this workflow.

### 2.2 `merge_retry(signal: GateMergeRetrySignal)` — `@workflow.signal` — `:6301-6305`
Sets `_merge_retry_signalled = True`, touches `_updated_at`. Consumed by the merge_blocked wait in `_reconcile_and_merge_with_retry_loop` (`:6292`). No payload fields read.

### 2.3 `gate_approved(signal: GateApprovedSignal)` — `@workflow.signal` — `:6325-6353`
Builds 5-tuple entry `(GateStatus.APPROVED, signal.approved_by, signal.justification, None, [])` (`:6339-6345`). `gate_key = self._gate_id_to_key.get(signal.gate_id)`:
- if None (raced ahead of `create_gate_record`): `_pending_signals_by_gate_id.setdefault(gate_id, []).append(entry)` (`:6348-6350`).
- else: `_gate_decisions.setdefault(gate_key, []).append(entry)` (`:6352`).
Touches `_updated_at`. GOTCHA: routes by UUID lookup, buffers on miss. Predicate that consumes it: `_wait_for_gate`'s `len(self._gate_decisions[gate_key]) > consumed or self.cancelled` (`:5952-5953`).

### 2.4 `gate_rejected(signal: GateRejectedSignal)` — `@workflow.signal` — `:6355-6377`
`card_decisions = list(getattr(signal,"card_decisions",[]) or [])`; `reason_category = getattr(signal,"reason_category",None)` (`:6361-6362`) — defensive getattr so older signal shapes work. Entry `(GateStatus.REJECTED, signal.rejected_by, signal.reason, reason_category, card_decisions)` (`:6363-6369`). Same buffer-or-append routing as `gate_approved` (`:6370-6376`).

### 2.5 `cancel_all_children()` — `@workflow.signal` — `:6379-6446`
- Patch guard: `if not workflow.patched("wave-rationalization-architecture-dispatch-v1"): return` (`:6409-6412`) — inert no-op on pre-patch workflows.
- Sets `_cancel_all_children_requested=True`, touches `_updated_at` (`:6414-6415`).
- `for child_id, handle in self._architecture_child_handles:` → `try: await handle.cancel()` + log; `except Exception:` swallow + log warning (already-finished child raises RPCError; best-effort sweep) (`:6417-6435`).
- Clears `_architecture_child_handles = []` (`:6439`).
- Sets `_status = CANCELLED`, `_current_step = "cancelled"` (`:6445-6446`).
GOTCHA: does NOT tear down `run()` — full teardown is via `cancel_workflow`. GOTCHA: because `_architecture_child_handles` is never populated in current code, the cancel loop is effectively a no-op that only flips status.

### 2.6 `stakeholder_approved(signal: StakeholderApprovedSignal)` — `@workflow.signal` — `:6448-6480`
Dispatch by `signal.scope`:
- `if scope == "tier-1-classification"` (`:6459`):
  - `prefix="tier1-"`; `if signal.approval_id.startswith(prefix)` (`:6461-6462`): `remainder = approval_id[len(prefix):]`; `app_id = remainder.rsplit("-",1)[0] if "-" in remainder else remainder` (`:6463-6464`) — parses `tier1-{app_id}-{n}` convention. `_tier1_approved_apps.add(app_id)` (`:6465`). Set `_tier1_approval_records[app_id] = {app_id, approval_id, stakeholder, scope, approved_at}` (`:6470-6476`) — last write per app wins.
  - GOTCHA: if `approval_id` doesn't start with `tier1-`, NOTHING happens (no add) — the classify wait stays blocked.
- `else` (scope `"g-da"` or anything else): `_stakeholder_approved=True`; `_stakeholder_info=f"{stakeholder} approved scope: {scope}"` (`:6477-6479`).
- Touches `_updated_at` (`:6480`).
Consuming predicates: tier-1 → `_classify_app`'s `app_id in self._tier1_approved_apps or self.cancelled` (`:4326`); g-da → G-DA loop's `self._stakeholder_approved or self.cancelled` (`:3252`).

### 2.7 `dispatch_architecture(payload: DispatchArchitecturePayload)` — `@workflow.signal` — `:6486-6508`
Legacy v1 entry. `_v2_dispatch_meta = _extract_v2_metadata(payload)` (`:6504`), `_dispatch_payload = _normalize_dispatch_payload(payload)` (`:6505-6506`), `_dispatch_received=True` (`:6507`), touch `_updated_at`.

### 2.8 `dispatch_architecture_v2(payload: DispatchArchitecturePayloadV2)` — `@workflow.signal` — `:6510-6534`
Same as v1 but takes the v2 dataclass directly so the Temporal converter preserves `target_app_id`/`target_service_id`/`source_app_ids`. Same body: extract v2 meta, normalize, set received (`:6530-6534`).

### 2.9 `retry_target_dispatch(payload: RetryTargetDispatchPayload)` — `@workflow.signal` — `:6593-6606`
`if isinstance(payload, dict): payload = RetryTargetDispatchPayload(**payload)` (`:6603-6604`). `_pending_retries.append(payload)`; touch `_updated_at`. Drained after the initial provision gather by `_drain_retry_queue`.

### 2.10 Queries
- `pending_dispatch_payload() -> list[PendingDispatchEntry]` — `:6608-6615` — `list(self._pending_dispatch_entries)`.
- `pending_target_dispatch_payload() -> list[PendingTargetDispatchEntry]` — `:6617-6632` — `list(self._pending_target_dispatch_entries)`. Empty when patch `architecture-target-plan-v1` inactive.
- `dispatch_results() -> list[DispatchTargetStatus]` — `:6634-6638` — `list(self._dispatch_status.values())`.
- `get_status() -> WorkflowStatusResponse` — `:6644-6655` — `{workflow_id=info().workflow_id, status=_status, current_line=AssemblyLine.RATIONALIZATION, current_step=_current_step, progress_pct=_progress_pct, pending_gate=_pending_gate, started_at=_started_at, updated_at=_updated_at}`.
- `pending_tier1_classification() -> PendingTier1Classification` — `:6657-6667` — returns `self._pending_tier1_classification`; empty `app_id` means no active hold.

GOTCHA — subclass-override warning: `gate_approved`, `gate_rejected`, and `stakeholder_approved` implement the buffered-routing + scope-dispatch contract that `_wait_for_gate` / the tier-1 pause / the G-DA dual-signal depend on. Overriding any of them without preserving the `_gate_id_to_key` lookup + `_pending_signals_by_gate_id` buffering (approve/reject) or the `tier1-` prefix parsing + `_stakeholder_approved` flag (stakeholder) would silently drop decisions and hang the workflow forever. This workflow is `@workflow.defn`-decorated and not intended to be subclassed, but the signal handlers are the fragile contract surface.

### Module tail — `:6670-6674`
`_ = update_application_status` and `_ = UpdateAppStatusInput` keep the imports alive for worker registration even though this workflow never calls the activity directly. GOTCHA: don't drop these imports or worker registration loses the activity.

---

Continue to Part 2 for `run()`/`_execute()`, the redundancy passes, gate loops, and per-app fan-out.
