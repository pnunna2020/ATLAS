# WaveRationalizationWorkflow — Atomic Regeneration Spec (Part 2 of 3)

Source: `temporal/olympus_workflows/workflows/wave_rationalization.py`. Continues from Part 1.
Covers: (3) CONTROL FLOW `run()`/`_execute()`, redundancy passes, G-RR loop + rework, per-app fan-out orchestration, classification/scoring/wave-plan/factory-routing, G-DA loop + rework, wave-outcome-synthesis, terminal handoff. (4) ACTIVITY & CHILD CALLS inline. (5) GATE HANDLING inline. Part 3 covers Architecture/Data fan-out + helpers + parity checklist.

Retry policies referenced (from `retry_policies.py`):
- `transient` = 3 attempts, 1→15s exp backoff (delegates to HTTP policy).
- `agent_failure` = 3 attempts, initial 5s, ×2, cap 60s (`:38-43`).
- `git_merge` = 3 attempts, initial 5s, ×2, cap 30s, `non_retryable_error_types=[MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected]` (`:95-105`).
- Agent dispatch timeout constants: `AGENT_START_TO_CLOSE = timedelta(hours=3)`, `AGENT_HTTP_READ_TIMEOUT_SECONDS = 10800` (180 min) (`agent_timeouts.py:65-67`).

---

## 3. `run(input: WaveRationalizationInput) -> str` — `@workflow.run` — `:1348-1454`

```
run(input):
    if isinstance(input, dict): input = WaveRationalizationInput(**input)   # :1351-1352
    self._status = RUNNING                                                  # :1354
    self._wave_id = input.wave_id
    self._portfolio_id = input.portfolio_id
    self._started_at = _now_iso(); self._updated_at = _started_at           # :1355-1358
    if not input.app_ids:
        raise ValueError("WaveRationalizationWorkflow requires at least one app_id")  # :1360-1361
    wf_id = workflow.info().workflow_id
    run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]     # :1363-1364
    branch = f"olympus/rationalization/wave-{input.wave_id}/{run_suffix}"   # :1365
    workspace_key = f"wave-rationalization-{input.wave_id}-{run_suffix}"    # :1366
    try:
        return await self._execute(input, branch, workspace_key)            # :1368-1369
    except Exception as exc:                                                # :1370
        self._status = FAILED; self._current_step = "failed"; self._updated_at = _now_iso()  # :1371-1373
        classification = classify_failure(exc)                              # :1387
        reason = str(exc)[:500]                                             # :1388
        try:                                                                # :1397
            if classification == "recoverable":                            # :1398
                # (a) persist_wave_failure  -> writes status='failed', failure_reason, failed_at, workflow_id
                await execute_activity(persist_wave_failure,
                    PersistWaveFailureInput(wave_id, reason, workflow_id=info().workflow_id),
                    start_to_close=30s, retry=transient)                     # :1409-1418
                # (b) THEN flip status back to recoverable value
                await execute_activity(update_wave_status,
                    UpdateWaveStatusInput(wave_id, new_status="stuck-awaiting-recovery", reason),
                    start_to_close=30s, retry=transient)                     # :1422-1431
            else:                                                            # :1432
                await execute_activity(persist_wave_failure, PersistWaveFailureInput(...),
                    start_to_close=30s, retry=transient)                     # :1433-1442
        except Exception:                                                    # :1443
            workflow.logger.warning("persist_wave_failure swallowed secondary exception", ...)  # :1447-1453
        raise                                                                # :1454 — re-raise original exc so Temporal marks run FAILED
```
GOTCHA (`:1419-1421`): `persist_wave_failure` unconditionally writes `status='failed'`; the recoverable branch must run a SECOND `update_wave_status` to flip it to `stuck-awaiting-recovery` AFTER failure_reason/failed_at landed. Order matters. GOTCHA (`:1443-1453`): the secondary persist is best-effort; swallow so the original failure isn't masked. The `raise` at `:1454` always re-propagates `exc`.

---

## `_execute(input, branch, workspace_key) -> str` — `:1456-3517`

`repo = input.artifact_repo` (`:1462`).

### Sequence 0 — partition wave (greenfield Build) — `:1464-1499`
```
self._legacy_app_ids = list(input.app_ids); self._build_app_ids = []        # :1475-1476
if workflow.patched("wave-rationalization-greenfield-build-v1"):            # :1477
    await self._partition_wave_by_intake(input)                             # :1478
has_legacy = bool(self._legacy_app_ids)                                     # :1495
skip_legacy_synthesis = (
    workflow.patched("wave-rationalization-greenfield-only-skip-v1")
    and not has_legacy )                                                    # :1496-1499
```
`skip_legacy_synthesis` = pure-greenfield wave (patch on AND zero legacy apps). Threads through the ENTIRE rest of `_execute` to skip all legacy redundancy passes.

`_partition_wave_by_intake(input)` — `:3607-3655`:
```
try: result = await execute_activity(load_app_intake_modes,
        LoadAppIntakeModesInput(app_ids=list(input.app_ids)),
        start_to_close=30s, retry=transient, activity_id=f"load-app-intake-modes-{wave_id}")  # :3621-3627
except Exception:                                                           # :3628
    log.exception(...); self._legacy_app_ids=list(input.app_ids); self._build_app_ids=[]; return  # :3629-3635
build=[]; legacy=[]
for app_id in input.app_ids:
    mode = result.modes.get(app_id)
    if mode is not None and mode.is_build: build.append(app_id)             # :3641-3642
    else: legacy.append(app_id)                                             # :3643-3644
self._build_app_ids=build; self._legacy_app_ids=legacy                      # :3645-3646
if build: log.info("wave partitioned for greenfield Build", ...)            # :3647-3655
```
GOTCHA: best-effort — DB failure ⇒ whole wave treated as legacy (safe failure mode; a Build app then hard-fails cross-app passes loudly) (`:3612-3618, 3628-3635`).

### Sequence 1 — three parallel redundancy passes — `:1501-1735`
`await self._set_step("cross-app-redundancy", 0.0)` (`:1512`). Resolve `cross_skill`, `ux_skill`, `intra_skill` from SKILLS (`:1513-1515`).

**Build (but not yet await) three activity futures:**
1. `cross_future` = `execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-cross-app-redundancy", skill_id="redundancy-analyzer", app_id="", wave_id, workspace_key, artifact_repo=repo, artifact_ref=branch, context=_with_fixture_scenario({scope:"cross-app", wave_id, app_ids:self._legacy_app_ids}, ...), input_artifacts=_business_logic_artifacts_for_wave(legacy), timeout_seconds=AGENT_HTTP_READ_TIMEOUT_SECONDS, execution_context=...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)` (`:1517-1553`). Cross-app operates over LEGACY apps only.
2. `ux_future` = same shape, `task_type="wave-compare-ux-overlap"`, skill `compare-ux-overlap`, `input_artifacts=_ux_overlap_input_artifacts(legacy)` (`:1554-1594`).
3. `intra_tasks` = list-comp: ONE `execute_activity` per `app_id in self._legacy_app_ids`, `task_type="wave-intra-app-redundancy"`, skill `redundancy-analyzer`, `app_id=app_id`, `workspace_key=f"{workspace_key}-{app_id}"`, context `{scope:"intra-app", wave_id}`, `input_artifacts=[_business_logic_artifact(app_id)]` (`:1595-1624`).

**Await cross+ux:**
```
if skip_legacy_synthesis:                                                   # :1633
    cross_future.close(); ux_future.close()                                 # :1638-1639 — close unawaited coroutines
    cross_result = None; ux_result = None                                   # :1640-1641
else:
    cross_result, ux_result = await asyncio.gather(cross_future, ux_future) # :1643-1645
```
GOTCHA (`:1626-1632`): `asyncio.gather` is REQUIRED for parallelism — `execute_activity` returns a coroutine that only schedules on await; sequential awaits would serialize.

**Commit cross-app + UX (only when NOT skip_legacy_synthesis):** `matrix_path = f"rationalization/wave-{wave_id}/redundancy-matrix.json"` (`:1647`).
```
if not skip_legacy_synthesis:                                               # :1653
    matrix_raw = self._primary_output_content(cross_result, "redundancy-matrix.json")  # :1659-1661
    await self._validate_artifact_or_warn("redundancy-matrix.json", matrix_raw, wave_id)  # :1664-1668
    await self._commit_artifact(repo, branch, matrix_path, matrix_raw, "Wave {id}: cross-app redundancy matrix")  # :1669-1675
    await self._commit_output_files(repo, branch, cross_result, primary_path=matrix_path, wave_id, ...)  # :1676-1683
    ux_path = f"rationalization/wave-{wave_id}/ux-overlap-matrix.json"       # :1685
    await self._commit_artifact(repo, branch, ux_path, self._primary_output_content(ux_result, "ux-overlap-matrix.json"), "Wave {id}: UX overlap matrix")  # :1686-1692
    await self._commit_output_files(repo, branch, ux_result, primary_path=ux_path, wave_id, ...)  # :1693-1700
else:
    ux_path = f"rationalization/wave-{wave_id}/ux-overlap-matrix.json"       # :1701-1702  (path only, no commit)
```

**Intra-app fan-out:** `await self._set_step("intra-app-redundancy", STEP_WEIGHTS["cross-app-redundancy"])` (`:1704-1707`). `intra_results = await asyncio.gather(*intra_tasks)` (`:1713`). Then `for app_id, result in zip(self._legacy_app_ids, intra_results):` (`:1716`) → `path = f"rationalization/wave-{wave_id}/{app_id}/intra-app-redundancy.json"`, `_commit_artifact` + `_commit_output_files` (`:1717-1735`). GOTCHA: zip against `_legacy_app_ids` (not `input.app_ids`) since `intra_tasks` was built over legacy only.

### Sequence 2 — portfolio-scope synthesis trio (PIM / PRA / business-rule) — `:1737-2266`
Resolve `pim_skill`, `pra_skill`, `br_skill` and paths: `integration_graph_path`, `portfolio_redundancy_path`, `shared_identity_path` (= `{wave}/shared-identity-report.json`), `business_rule_redundancy_path` (`:1759-1774`). Init `pim_result=pra_result=br_result=None` (`:1775-1777`).

**Patch gates (`:1787-1807`):**
- `do_portfolio_synthesis = workflow.patched("wave-rationalization-portfolio-synthesis-v1") and not skip_legacy_synthesis`.
- `do_cross_app_br = workflow.patched("wave-rationalization-cross-app-br-analyzer-v1")`.
- `do_rat_cap_clustering = workflow.patched("wave-rationalization-rat-cap-clustering-v1")`.
- `pim_progress = STEP_WEIGHTS["cross-app-redundancy"] + STEP_WEIGHTS["intra-app-redundancy"]` (= 13.0) (`:1808-1811`).

```
if do_portfolio_synthesis:                                                  # :1812
    await self._set_step("portfolio-integration-mapping", pim_progress)     # :1813
    pim_input_artifacts = _portfolio_integration_input_artifacts(legacy)    # :1818
    pra_input_artifacts = _portfolio_redundancy_input_artifacts(wave_id, legacy)  # :1821
    br_input_artifacts  = _cross_app_business_rule_input_artifacts(legacy)  # :1824

    # rat-cap grain load (once) — best effort
    rat_cap_context = {prior_rat_caps:[], wave_capability_grain:[], wave_capability_count:0}  # :1836-1840
    if do_rat_cap_clustering:                                               # :1841
        try:
            grain_result = await execute_activity(load_wave_rationalization_capabilities,
                LoadWaveRationalizationCapabilitiesInput(portfolio_id, wave_id, execution_context=...),
                start_to_close=30s, retry=transient, activity_id=f"load-rat-cap-grain-{wave_id}")  # :1843-1855
            rat_cap_context.prior_rat_caps = grain_result.prior_rat_caps
            rat_cap_context.wave_capability_grain = grain_result.wave_capabilities
            rat_cap_context.wave_capability_count = len(grain_result.wave_capabilities)  # :1856-1864
        except Exception: log.exception(...)                                # :1865-1871  (continue with empty lists)

    sequential_pim = workflow.patched("wave-rationalization-pim-before-pra-v1")  # :1884-1886

    pim_future = execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-portfolio-integration-mapping",
        skill_id="portfolio-integration-mapper", app_id="", wave_id, workspace_key, repo, branch,
        context=_with_fixture_scenario({wave_id, app_ids:legacy}, ...), input_artifacts=pim_input_artifacts,
        timeout=HTTP_READ, execution_context=...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :1887-1914

    br_future = None
    if do_cross_app_br:                                                     # :1916
        br_future = execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-cross-app-business-rule-analysis",
            skill_id="cross-app-business-rule-analyzer", ..., input_artifacts=br_input_artifacts, ...),
            start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)        # :1917-1944

    pra_future_parallel = None
    if not sequential_pim:                                                  # :1950  (LEGACY replay path)
        _legacy_pra_context = {portfolio_id, wave_id, app_ids:legacy}       # :1951-1955
        if do_rat_cap_clustering: _legacy_pra_context.update(rat_cap_context)  # :1956-1957
        pra_future_parallel = execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-analyze-portfolio-redundancy",
            skill_id="analyze-portfolio-redundancy", ...,
            context=await _with_context_priors(_with_fixture_scenario(_legacy_pra_context, ...), pra_skill_id),
            input_artifacts=pra_input_artifacts, ...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :1958-1985

    if sequential_pim:                                                      # :1987  (NEW path)
        if br_future is not None:  pim_result, br_result = await asyncio.gather(pim_future, br_future)  # :1990-1993
        else:                       pim_result = await pim_future            # :1994-1995
    else:                                                                    # :1996 (legacy)
        if br_future is not None:  pim_result, pra_result, br_result = await asyncio.gather(pim_future, pra_future_parallel, br_future)  # :1998-2001
        else:                       pim_result, pra_result = await asyncio.gather(pim_future, pra_future_parallel)  # :2002-2005

    # commit PIM
    await self._commit_artifact(repo, branch, integration_graph_path, self._primary_output_content(pim_result, "integration-graph.json"), "Wave {id}: portfolio integration graph")  # :2007-2015
    await self._commit_output_files(repo, branch, pim_result, primary_path=integration_graph_path, ...)  # :2016-2025

    if sequential_pim:                                                      # :2027  Stage 2: dispatch PRA AFTER PIM committed
        await self._set_step("analyze-portfolio-redundancy", pim_progress + STEP_WEIGHTS["portfolio-integration-mapping"])  # :2031-2034
        _pra_context = {portfolio_id, wave_id, app_ids:legacy}              # :2035-2039
        if do_rat_cap_clustering: _pra_context.update(rat_cap_context)      # :2040-2041
        pra_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-analyze-portfolio-redundancy",
            skill_id="analyze-portfolio-redundancy", ...,
            context=await _with_context_priors(_with_fixture_scenario(_pra_context, ...), pra_skill_id),
            input_artifacts=pra_input_artifacts, ...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :2042-2069
    else:
        await self._set_step("analyze-portfolio-redundancy", pim_progress + STEP_WEIGHTS["portfolio-integration-mapping"])  # :2071-2074

    pra_raw = self._primary_output_content(pra_result, "portfolio-redundancy-matrix.json")  # :2082-2084
    # HARD FAIL on empty clustering plan (patch-guarded)
    if (do_portfolio_synthesis and workflow.patched("wave-rationalization-pra-nonempty-v1") and self._primary_output_is_empty(pra_raw)):  # :2101-2105
        raise ApplicationError("...empty clustering plan...", type="EmptyPortfolioRedundancyPlan", non_retryable=True)  # :2106-2114
    await self._validate_artifact_or_warn("portfolio-redundancy-matrix.json", pra_raw, wave_id)  # :2119-2123
    await self._commit_artifact(repo, branch, portfolio_redundancy_path, pra_raw, "Wave {id}: portfolio redundancy matrix")  # :2124-2130
    # advisory-validate companion shared-identity-report if present
    for f in getattr(pra_result,"output_files",[]) or []:                   # :2135
        if f.path endswith "shared-identity-report.json":
            await self._validate_artifact_or_warn("shared-identity-report.json", f.content, wave_id); break  # :2137-2143
    await self._commit_output_files(repo, branch, pra_result, primary_path=portfolio_redundancy_path, ...)  # :2144-2153

    # rat-cap persist (best effort)
    if do_rat_cap_clustering and pra_raw:                                   # :2163
        try:
            persist_out = await execute_activity(persist_rationalization_capabilities,
                PersistRationalizationCapabilitiesInput(portfolio_id, wave_id, clustering_plan_json=pra_raw,
                    clustering_plan_artifact_ref=portfolio_redundancy_path, execution_context=...),
                start_to_close=60s, retry=transient, activity_id=f"persist-rat-caps-{wave_id}")  # :2165-2183
            if workflow.patched("wave-rationalization-ratcap-persist-readback-v1"):  # :2197-2199
                errs = list(persist_out.validation_errors or [])
                inserted = persist_out.rat_caps_inserted or 0; updated = persist_out.rat_caps_updated or 0  # :2200-2208
                if errs or (inserted + updated) == 0:                        # :2209
                    warning_key = f"wave-{wave_id}"; header = "rat-cap clustering plan did NOT persist..."  # :2210-2217
                    msgs = [header] + [f"portfolio-redundancy-matrix.json: {e}" for e in errs[:8]]  # :2218-2222
                    self._validation_warnings.setdefault(warning_key, []).extend(msgs)  # :2223-2225
                    log.error("persist_rationalization_capabilities wrote 0 rat-cap rows...")  # :2226-2231
        except Exception: log.exception(...)                                # :2232-2238

    if br_result is not None:                                               # :2240
        await self._set_step("cross-app-business-rule-analysis", pim_progress + PIM_w + PRA_w)  # :2241-2246
        await self._commit_artifact(repo, branch, business_rule_redundancy_path, self._primary_output_content(br_result,"business-rule-redundancy.json"), ...)  # :2247-2255
        await self._commit_output_files(repo, branch, br_result, primary_path=business_rule_redundancy_path, ...)  # :2256-2266
```
GOTCHA (`:2085-2114`): empty-PRA is a HARD non-retryable failure only when `pra-nonempty-v1` patched — else pre-fix workflows replay through. This prevents downstream fabricated rat-caps.
GOTCHA (`:1873-1885, 1946-2005`): the sequential-vs-parallel PIM/PRA split is patch-gated; legacy path dispatched all three in ONE gather which 404'd when PRA read PIM's output before commit.

### G-RR loop — `:2268-2798`
`progress_after_redundancy` accumulator (`:2269-2281`): base = `cross-app-redundancy + intra-app-redundancy` (13.0); `if do_portfolio_synthesis:` add `portfolio-integration-mapping + analyze-portfolio-redundancy` (9.0); `if do_cross_app_br:` add `cross-app-business-rule-analysis` (3.0).

```
while True:                                                                 # :2282
    gr_pr = await self._open_gate_pr(repo, branch, input, "G-RR", "Gate G-RR: Wave {id} Redundancy Review", self._build_grr_body(input))  # :2283-2290
    gate_record = await execute_activity(create_gate_record,
        CreateGateRecordInput(gate_type="G-RR", wave_id, portfolio_id, workflow_id=info().workflow_id, evidence_package_url=gr_pr.pr_url),
        start_to_close=30s, retry=transient)                                # :2291-2302
    self._register_gate_key(gate_record.gate_id, "G-RR")                    # :2303  (flushes buffered signals)

    # Build intra_steps_entry rollup (per-app bulleted output + file_artifacts, summed duration/cost)  # :2310-2342
    grr_steps = {}                                                          # :2347
    if not skip_legacy_synthesis:                                           # :2348
        grr_steps["cross-app-redundancy"] = _build_rationalization_step_entry("Cross-App Redundancy", cross_skill_id, "redundancy-matrix.json", cross_result)  # :2349-2356
        grr_steps["compare-ux-overlap"]   = _build_rationalization_step_entry("UX Overlap Analysis", ux_skill_id, "ux-overlap-matrix.json", ux_result)  # :2357-2364
        grr_steps["intra-app-redundancy"] = intra_steps_entry               # :2365
    if do_portfolio_synthesis and pim_result is not None: grr_steps["portfolio-integration-mapping"] = _build_rationalization_step_entry(...)  # :2366-2374
    if do_portfolio_synthesis and pra_result is not None: grr_steps["analyze-portfolio-redundancy"] = _build_rationalization_step_entry(...)  # :2375-2383
    if do_portfolio_synthesis and br_result  is not None: grr_steps["cross-app-business-rule-analysis"] = _build_rationalization_step_entry(...)  # :2384-2392

    grr_artifact_paths = [] if skip_legacy_synthesis else [matrix_path, ux_path]  # :2397-2399
    if do_portfolio_synthesis:
        grr_artifact_paths.extend([integration_graph_path, portfolio_redundancy_path, shared_identity_path])  # :2400-2407
        if br_result is not None: grr_artifact_paths.append(business_rule_redundancy_path)  # :2408-2409

    await execute_activity(submit_gate_evidence, SubmitGateEvidenceInput(gate_id=gate_record.gate_id,
        gate_type=GateType.G_RR, app_id=f"wave-{wave_id}", artifact_paths=grr_artifact_paths, pr_url=gr_pr.pr_url,
        evidence_data={wave_id, app_ids:input.app_ids, assembly_line:"Rationalization", steps:grr_steps,
            validation_warnings:dict(self._validation_warnings)}),
        start_to_close=60s, retry=transient)                                # :2410-2433

    if workflow.patched("wave-rationalization-gate-pre-review-v1"):         # :2444  advisory AI pre-review
        grr_pre_review_paths = [] if skip_legacy_synthesis else [matrix_path, ux_path]  # :2446-2448
        grr_pre_review_optional = []                                        # :2459
        if do_portfolio_synthesis:
            grr_pre_review_paths.extend([integration_graph_path, portfolio_redundancy_path])  # :2461-2466
            grr_pre_review_optional.append(shared_identity_path)            # :2467  (MUST be optional)
            if br_result is not None: grr_pre_review_paths.append(business_rule_redundancy_path)  # :2468-2471
        for app_id in self._legacy_app_ids: grr_pre_review_paths.append(f"rationalization/wave-{wave_id}/{app_id}/intra-app-redundancy.json")  # :2474-2478
        await self._run_gate_pre_review(gate_record.gate_id, "G-RR", grr_pre_review_paths, artifact_repo=repo, artifact_ref=branch, optional_evidence_paths=grr_pre_review_optional)  # :2479-2486

    await execute_activity(mark_gate_ready_for_review, gate_record.gate_id, start_to_close=30s, retry=transient)  # :2487-2492
    await self._set_step("gate-review-rr", progress_after_redundancy)       # :2494
    decision = await self._wait_for_gate("G-RR")                            # :2495
    if decision == "cancelled": return "cancelled"                          # :2496-2497
    if decision == "approved":
        await self._reconcile_and_merge_with_retry_loop(repo, pr_number=gr_pr.pr_number, gate_id=gate_record.gate_id)  # :2500-2504
        break                                                               # :2505
    # --- rejection path ---
    self._rework_iterations_grr += 1                                        # :2506
    if self._rework_iterations_grr > MAX_REWORK_ITERATIONS:                 # :2507  (>3)
        self._status = FAILED; self._current_step = "max-rework-exceeded-grr"; return "failed"  # :2508-2510
    rework_targets = set((self._rework_feedback.get("G-RR") or {}).get("rework_targets", []))  # :2522-2526
    scope_to_targets = bool(rework_targets)                                 # :2527
```

**G-RR rework — cross-app re-dispatch** (`:2529-2602`):
```
skip_cross_app = skip_legacy_synthesis or (scope_to_targets and "cross-app-redundancy" not in rework_targets)  # :2536-2539
if skip_cross_app: log.info("skipping cross-app-redundancy rerun...")       # :2540-2545
else:                                                                        # :2546
    await self._set_step("cross-app-redundancy", 0.0)
    cross_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-cross-app-redundancy",
        skill_id="redundancy-analyzer", app_id="", wave_id, workspace_key, repo, branch,
        context=_with_fixture_scenario({scope:"cross-app", wave_id, app_ids:legacy, rework_feedback:self._rework_feedback.get("G-RR")}, ...),
        input_artifacts=_business_logic_artifacts_for_wave(legacy), ...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :2547-2581
    rework_msg = "Wave {id}: cross-app redundancy (rework {n})"
    await self._commit_artifact(repo, branch, matrix_path, self._primary_output_content(cross_result,"redundancy-matrix.json"), rework_msg)  # :2586-2594
    await self._commit_output_files(..., commit_message_prefix=rework_msg+" companion")  # :2595-2602
```
**G-RR rework — PRA re-dispatch** (`:2604-2798`):
```
skip_pra = scope_to_targets and "analyze-portfolio-redundancy" not in rework_targets and skip_cross_app  # :2619-2623
if (do_portfolio_synthesis and workflow.patched("wave-rationalization-grr-rework-pra-v1") and not skip_pra):  # :2624-2630
    await self._set_step("analyze-portfolio-redundancy", STEP_WEIGHTS["cross-app-redundancy"])  # :2631-2634
    rework_rat_cap_context = {prior_rat_caps:[], wave_capability_grain:[], wave_capability_count:0}  # :2643-2647
    if do_rat_cap_clustering:                                               # :2648
        try: _rework_grain = await execute_activity(load_wave_rationalization_capabilities, ...,
             activity_id=f"load-rat-cap-grain-rework-{wave_id}-{iter}") ; fill context  # :2649-2675
        except Exception: log.exception(...)                                # :2676-2682
    _rework_pra_context = {portfolio_id, wave_id, app_ids:input.app_ids, rework_feedback:self._rework_feedback.get("G-RR")}  # :2684-2689
    if do_rat_cap_clustering: _rework_pra_context.update(rework_rat_cap_context)  # :2690-2691
    pra_rework_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-analyze-portfolio-redundancy",
        ..., context=await _with_context_priors(_with_fixture_scenario(_rework_pra_context,...),...),
        input_artifacts=_portfolio_redundancy_input_artifacts(wave_id, input.app_ids), ...),
        start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)            # :2692-2723
    pra_rework_raw = self._primary_output_content(pra_rework_result, "portfolio-redundancy-matrix.json")  # :2726-2728
    await self._validate_artifact_or_warn("portfolio-redundancy-matrix.json", pra_rework_raw, wave_id)  # :2729-2733
    await self._commit_artifact(repo, branch, portfolio_redundancy_path, pra_rework_raw, pra_rework_msg)  # :2738-2744
    for f in pra_rework_result.output_files: if shared-identity-report.json: validate; break  # :2745-2753
    await self._commit_output_files(...)                                    # :2754-2761
    if do_rat_cap_clustering and pra_rework_raw:                            # :2769
        try: await execute_activity(persist_rationalization_capabilities, ..., activity_id=f"persist-rat-caps-rework-{wave_id}-{iter}")  # :2770-2791
        except Exception: log.exception(...)                                # :2792-2798
# loop back to while True (:2282) — re-open G-RR PR
```
GOTCHA (`:2614-2623`): PRA rerun triggers when cross-app was rerun (its output feeds PRA) OR PRA itself was the rejected card. `skip_pra` only when card-scoped boundary excludes BOTH.
GOTCHA (`:2635-2691`): rework rat-cap re-load carries `prior_rat_caps` so persist UPSERTs by `existing_id` (stable UUIDs across rework), else Discovery's fine-capability FKs rebind to dead rows.

### Per-app fan-out (disposition→governance→user-impact) — `:2800-2824`
```
await self._set_step("disposition-recommendation", progress_after_redundancy + STEP_WEIGHTS["gate-review-rr"])  # :2803-2806
per_app_pipelines = [
    self._build_app_pipeline(app_id, input, repo, branch, workspace_key) if app_id in self._build_app_ids
    else self._per_app_pipeline(app_id, input, repo, branch, workspace_key)
    for app_id in input.app_ids ]                                           # :2814-2819
per_app_pipeline_results = await asyncio.gather(*per_app_pipelines)         # :2820
per_app_results = {app_id: result for app_id, result in zip(input.app_ids, per_app_pipeline_results)}  # :2821-2824
```
Routes Build apps → `_build_app_pipeline` (Part 3), legacy → `_per_app_pipeline` (below). Both return the SAME dict shape.

#### `_per_app_pipeline(app_id, input, repo, branch, workspace_key, *, rework=False) -> dict` — `:3853-4205`
```
disp_skill = SKILLS["disposition-recommendation"]                           # :3868
disp_context = await _with_context_priors(_with_fixture_scenario(
    {wave_id,
     rework_feedback: self._rework_feedback.get("G-DA") if rework else None,   # :3878-3880
     approval_guidance: self._approval_feedback.get("G-RR")},                  # :3892
    disp_skill_id, fixture_scenarios), disp_skill_id)                       # :3874-3900
disp_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-per-app-disposition",
    skill_id="disposition-recommender", app_id, workspace_key=f"{ws}-{app_id}", repo, branch, context=disp_context,
    input_artifacts=_disposition_input_artifacts(wave_id, app_id),
    optional_input_artifacts=_wave_context_optional_artifacts(wave_id), timeout=HTTP_READ, execution_context=...),
    start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)               # :3901-3936
disp_raw = self._primary_output_content(disp_result, "disposition-recommendation.json")  # :3952-3954
await self._validate_artifact_or_warn("disposition-recommendation.json", disp_raw, wave_id, app_id)  # :3955-3960
disp_path = f"rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json"  # :3962
await self._commit_artifact(...); await self._commit_output_files(...)      # :3963-3980

if workflow.patched("wave-rationalization-rat-cap-clustering-v1") and disp_raw:  # :3995-4000
    try: await execute_activity(persist_rationalization_capability_dispositions,
        PersistRationalizationCapabilityDispositionsInput(portfolio_id, wave_id, disposition_recommendation_json=disp_raw,
            disposition_recommendation_artifact_ref=disp_path, execution_context=...),
        start_to_close=60s, retry=transient, activity_id=f"persist-rat-cap-disp-{wave_id}-{app_id}")  # :4002-4019
    except Exception: log.exception(...)                                    # :4020-4026

gov_skill = SKILLS["disposition-governance"]                                # :4028
gov_input_artifacts = [disp_path, *_wave_context_artifacts(wave_id, app_id)]  # :4035-4037
gov_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-per-app-governance",
    skill_id="disposition-governance", ..., input_artifacts=gov_input_artifacts,
    optional_input_artifacts=_wave_context_optional_artifacts(wave_id), ...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :4038-4065
gov_path = f"rationalization/wave-{wave_id}/{app_id}/disposition-governance.json"  # :4066-4068
gov_raw = self._primary_output_content(gov_result, "disposition-governance.json")  # :4069-4071
await self._commit_artifact(...); await self._commit_output_files(...)      # :4072-4089

# parse disposition
disposition = ""                                                            # :4096
if disp_raw:
    parsed = parse_agent_json(disp_raw)
    if isinstance(parsed, dict): disposition = str(parsed.get("recommended_disposition",""))  # :4097-4100

ui_result = None; ui_path = ""                                              # :4106-4107
if _is_retire_or_replace_disposition(disposition):                         # :4108  (only Retire/Replace)
    ui_skill = SKILLS["user-impact"]                                        # :4109
    ui_input_artifacts = [disp_path, f"discovery/{app_id}/ux-accessibility.json", *_wave_context_artifacts(wave_id, app_id)]  # :4115-4119
    ui_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-per-app-user-impact",
        skill_id="assess-user-impact", context={wave_id, disposition}, input_artifacts=ui_input_artifacts,
        optional_input_artifacts=_wave_context_optional_artifacts(wave_id), ...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :4120-4147
    ui_path = f"rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json"  # :4148-4150
    ui_raw = self._primary_output_content(ui_result, "user-impact-analysis.json")  # :4151-4153
    await self._commit_artifact(...); await self._commit_output_files(...)  # :4154-4171

return {app_id, disposition, disposition_path:disp_path, disposition_json:disp_raw,
        disposition_narrative:self._agent_narrative(disp_result),
        governance_path:gov_path, governance_json:gov_raw, governance_narrative:self._agent_narrative(gov_result),
        user_impact_path:ui_path,
        user_impact_json:(self._primary_output_content(ui_result,"user-impact-analysis.json") if ui_result is not None else ""),
        user_impact_narrative:self._agent_narrative(ui_result)}             # :4183-4205
```
GOTCHA (`:3982-3994`): rat-cap disposition persist is idempotent UPDATE-by-id (last write wins across overlapping rat-caps in the N-way fan-out). GOTCHA: user-impact ONLY runs for Retire/Replace; else `user_impact_path=""`, `user_impact_json=""`.

### Classification fan-out (with per-app Tier-1 pause) — `:2826-2847`
```
await self._set_step("classification", progress_after_redundancy + gate-review-rr + disposition-recommendation + disposition-governance + user-impact-analysis)  # :2831-2838
classify_tasks = [self._classify_app(app_id, input, repo, branch, workspace_key) for app_id in input.app_ids]  # :2839-2842
classify_results = await asyncio.gather(*classify_tasks)                    # :2843
classification_results = {app_id: result for app_id, result in zip(input.app_ids, classify_results)}  # :2844-2847
```

#### `_classify_app(...) -> dict` — `:4207-4342`
```
cls_skill = SKILLS["classification"]                                        # :4223
is_build = app_id in self._build_app_ids                                    # :4228
cls_input_artifacts = [_requirements_capability_artifact(app_id)] if is_build else _discovery_passes_for_app(app_id)  # :4229-4233
cls_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-per-app-classification",
    skill_id="classify-application", context={wave_id, intake:"build" if is_build else "legacy"},
    input_artifacts=cls_input_artifacts, ...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :4234-4262
cls_path = f"rationalization/wave-{wave_id}/{app_id}/classification.json"    # :4263
cls_json = self._primary_output_content(cls_result, "classification.json")  # :4269-4271
await self._validate_artifact_or_warn("classification.json", cls_json, wave_id, app_id)  # :4276-4281
await self._commit_artifact(...); await self._commit_output_files(...)      # :4282-4299

if _classification_is_tier_1(cls_json):                                     # :4306
    self._current_step = f"awaiting-tier1-approval-{app_id}"                # :4307
    if workflow.patched("tier1-classification-summary-v1"):                 # :4312
        summary = _parse_classification_summary(cls_json, self._agent_narrative(cls_result))  # :4313-4315
        self._pending_tier1_classification = PendingTier1Classification(app_id, risk_tier, risk_rationale, risk_confidence, archetype, complexity_tier, narrative)  # :4316-4324
    await workflow.wait_condition(lambda: app_id in self._tier1_approved_apps or self.cancelled)  # :4325-4327
    if self.cancelled: raise RuntimeError("cancelled waiting for tier-1 approval")  # :4328-4329
    if workflow.patched("tier1-classification-summary-v1"): self._pending_tier1_classification = PendingTier1Classification()  # :4332-4333  (clear)

return {app_id, cls_json, cls_path, cls_narrative:self._agent_narrative(cls_result)}  # :4335-4342
```
GOTCHA: multiple apps can be paused for Tier-1 concurrently (fan-out); each waits for its own `app_id` in `_tier1_approved_apps`. Cancellation during a tier-1 pause RAISES (not returns), propagating to the outer `run()` FAILED handler.

### Portfolio scoring fan-out — `:2849-2886`
```
await self._set_step("portfolio-scoring", progress_after_redundancy + gate-review-rr + disp-rec + disp-gov + user-impact + classification)  # :2855-2863
score_tasks = [self._score_app(app_id, ...) for app_id in input.app_ids]    # :2864-2867
score_results = await asyncio.gather(*score_tasks)                          # :2868
portfolio_scores = {app_id: result for ...}                                 # :2869-2872
methodology_path = f"rationalization/wave-{wave_id}/scoring-methodology.md"  # :2879
await self._commit_artifact(repo, branch, methodology_path, self._build_scoring_methodology(input, portfolio_scores), "Wave {id}: scoring methodology digest")  # :2880-2886
```

#### `_score_app(...) -> dict` — `:4348-4461`
```
score_skill = SKILLS["portfolio-score"]; is_build = app_id in self._build_app_ids  # :4370-4375
if is_build: score_required=[_requirements_capability_artifact(app_id)]; score_optional=[]  # :4376-4378
else: score_required=_disposition_input_artifacts(wave_id, app_id); score_optional=_wave_context_optional_artifacts(wave_id)  # :4379-4381
score_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-per-app-portfolio-score",
    skill_id="portfolio-scorer", context={wave_id, intake}, input_artifacts=score_required,
    optional_input_artifacts=score_optional, ...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :4382-4413
score_path = f"rationalization/wave-{wave_id}/{app_id}/portfolio-score.json"  # :4414
score_json = self._primary_output_content(score_result, "portfolio-score.json")  # :4420-4422
await self._validate_artifact_or_warn("portfolio-score.json", score_json, wave_id, app_id)  # :4426-4431
await self._commit_artifact(...); await self._commit_output_files(...)      # :4432-4449
overall, dimensions = _compute_overall_readiness(score_json)               # :4451
return {app_id, score_json, artifact_path:score_path, overall_weighted:overall, dimensions, score_narrative:self._agent_narrative(score_result)}  # :4452-4461
```

### Wave planning — `:2888-2958`
`await self._set_step("wave-planning", ...+portfolio-scoring)` (`:2889-2898`). Single dispatch:
```
wave_plan_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-plan", skill_id="sequencer",
    app_id="", wave_id, workspace_key, repo, branch,
    context=_with_fixture_scenario({wave_id, app_ids:input.app_ids,
        per_app_dispositions:{app_id: per_app_results[app_id].get("disposition","")},
        per_app_readiness:{app_id: portfolio_scores[app_id].get("overall_weighted")}}, ...),
    timeout=HTTP_READ, execution_context=...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :2900-2931
wave_plan_path = f"rationalization/wave-{wave_id}/wave-plan.json"           # :2939-2941
await self._commit_artifact(...); await self._commit_output_files(...)      # :2942-2958
```
GOTCHA (`:2932-2938`): path is `rationalization/wave-{id}/` NOT the legacy `planning/{id}/` — the read-through endpoint expects the rationalization prefix.

### Factory routing — `:2960-2976`
`factory_routing_path = f"rationalization/wave-{wave_id}/factory-routing.json"`; commit `self._build_factory_routing(input, per_app_results)` (`:2967-2976`). `_build_factory_routing` (`:5865-5927`): buckets each app's disposition into `modernization` (Refactor/Rearchitect/Replace/Replatform), `build` (Build), `disposition_execution` (Retire/Consolidate), `retain` (Retain), else `unknown`; returns JSON with `routes` + `summary` counts + `generated_at=_now_iso()`.

### G-DA loop — `:2978-3317`
`progress_before_gda` = `progress_after_redundancy + gate-review-rr + disp-rec + disp-gov + user-impact + classification + portfolio-scoring + wave-planning` (`:2979-2988`).
```
while True:                                                                 # :2989
    gda_pr = await self._open_gate_pr(repo, branch, input, "G-DA", "Gate G-DA: Wave {id} Disposition Approval", self._build_gda_body(input, per_app_results))  # :2990-2997
    gate_record = await execute_activity(create_gate_record, CreateGateRecordInput(gate_type="G-DA", ...), 30s, transient)  # :2998-3009
    self._register_gate_key(gate_record.gate_id, "G-DA")                    # :3010

    artifact_paths = [methodology_path, wave_plan_path, factory_routing_path]  # :3023-3027
    if not skip_legacy_synthesis: artifact_paths = [matrix_path, ux_path] + artifact_paths  # :3028-3029
    for app_id in input.app_ids:                                            # :3030
        per_app_paths = [ .../disposition-recommendation.json, .../classification.json, .../portfolio-score.json ]  # :3033-3037
        if app_id not in self._build_app_ids:                               # :3042  (governance+intra are legacy-only)
            per_app_paths.extend([ .../disposition-governance.json, .../intra-app-redundancy.json ])  # :3043-3048
        artifact_paths.extend(per_app_paths)                                # :3049

    # nested closure _per_app_rollup(...) builds per-step rollup card (:3066-3129)
    gda_steps = { disposition-recommendation, disposition-governance, user-impact-analysis, classification, portfolio-scoring (all via _per_app_rollup), wave-planning: wave_plan_entry }  # :3148-3192

    await execute_activity(submit_gate_evidence, SubmitGateEvidenceInput(gate_id, gate_type=GateType.G_DA, app_id=f"wave-{wave_id}",
        artifact_paths, pr_url=gda_pr.pr_url,
        evidence_data={wave_id, app_ids, assembly_line:"Rationalization", per_app:per_app_results, steps:gda_steps,
            validation_warnings:dict(self._validation_warnings),
            tier1_approvals:[self._tier1_approval_records[a] for a in sorted(self._tier1_approval_records)]}),
        60s, transient)                                                     # :3193-3225

    if workflow.patched("wave-rationalization-gate-pre-review-v1"):
        await self._run_gate_pre_review(gate_record.gate_id, "G-DA", artifact_paths, artifact_repo=repo, artifact_ref=branch)  # :3231-3238
    await execute_activity(mark_gate_ready_for_review, gate_record.gate_id, 30s, transient)  # :3239-3244
    await self._set_step("gate-review-da", progress_before_gda)             # :3246
    decision = await self._wait_for_gate("G-DA")                            # :3247
    if decision == "cancelled": return "cancelled"                          # :3248-3249
    if decision == "approved":
        await workflow.wait_condition(lambda: self._stakeholder_approved or self.cancelled)  # :3252  DUAL-SIGNAL
        if self.cancelled: self._status = CANCELLED; return "cancelled"     # :3253-3255
        self._stakeholder_approved = False                                  # :3257  (consume flag)
        await self._reconcile_and_merge_with_retry_loop(repo, pr_number=gda_pr.pr_number, gate_id=gate_record.gate_id)  # :3259-3263
        await self._project_per_app_side_effects(input, classification_results, per_app_results, portfolio_scores)  # :3269-3274
        break                                                               # :3275
    # --- G-DA rejection ---
    self._stakeholder_approved = False                                      # :3277
    self._rework_iterations_gda += 1                                        # :3278
    if self._rework_iterations_gda > MAX_REWORK_ITERATIONS: self._status=FAILED; self._current_step="max-rework-exceeded-gda"; return "failed"  # :3279-3282
    await self._merge_capability_lineage_row_rework(gate_record.gate_id)    # :3295-3297
    rework_pipelines = [self._per_app_pipeline(app_id, input, repo, branch, workspace_key, rework=True) for app_id in input.app_ids]  # :3304-3314
    rework_results = await asyncio.gather(*rework_pipelines)                # :3315
    for app_id, result in zip(input.app_ids, rework_results): per_app_results[app_id] = result  # :3316-3317
    # loop back to :2989
```
GATE HANDLING (G-DA):
- **approve** requires BOTH `gate_approved` signal (drives `_wait_for_gate`→"approved") AND `_stakeholder_approved` flag (dual-signal, `:3251-3252`). The stakeholder wait is a separate `wait_condition` AFTER the gate approval.
- Cancellation during the stakeholder wait → CANCELLED (`:3253-3255`).
- On approve: consume stakeholder flag, merge PR, project side-effects, break.
- **reject**: reset stakeholder flag, increment counter (fail if >3), read-back capability-lineage row rework, then re-run ONLY `_per_app_pipeline(rework=True)` for ALL apps in parallel (NOT the redundancy passes — those are frozen post-G-RR). GOTCHA: G-DA rework does NOT re-run classification/scoring/wave-plan; only disposition+governance+user-impact re-run.
GOTCHA (`:3298-3303`): rework pipelines run in parallel gather — a prior serial for-loop was a perf bug adding ~(N-1)/N wall-clock per iteration.

### Wave outcome synthesis — `:3319-3467`
`progress_before_synthesis = progress_before_gda + gate-review-da` (`:3325-3335`). `await self._set_step("wave-outcome-synthesis", progress_before_synthesis)` (`:3336`).
```
per_app_artifact_refs = {app_id: {disposition, governance, classification, portfolio_score, user_impact, disposition_output_bundle: f"dispositions/{portfolio_id}/{app_id}/disposition-output.json"} for app_id in input.app_ids}  # :3346-3374
candidate_bundle_paths = [refs["disposition_output_bundle"] for refs in per_app_artifact_refs.values()]  # :3381-3384
synthesis_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="rationalization-wave-outcome-synthesis",
    skill_id="wave-outcome-synthesizer", app_id="", wave_id, workspace_key, repo, branch,
    input_artifacts=[], optional_input_artifacts=candidate_bundle_paths,
    context=_with_fixture_scenario({wave_id, wave_name, portfolio_id, app_ids, per_app_artifact_refs,
        disposition_output_bundle_refs:{...}, wave_level_artifact_refs:{redundancy_matrix:("" if skip_legacy_synthesis else matrix_path), wave_plan:wave_plan_path}}, ...),
    timeout=HTTP_READ), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :3385-3434
synthesis_path = f"rationalization/wave-{wave_id}/wave-outcome-synthesis.json"  # :3435-3437
synthesis_raw = self._primary_output_content(synthesis_result, "wave-outcome-synthesis.json")  # :3442-3444
await self._validate_artifact_or_warn("wave-outcome-synthesis.json", synthesis_raw, wave_id)  # :3448-3452
await self._commit_artifact(...); await self._commit_output_files(...)      # :3453-3467
```
GOTCHA (`:3375-3384`): disposition-output bundles are `optional_input_artifacts` — Disposition Execution runs AFTER rationalization so they're genuinely absent on first synthesis; skill falls back gracefully.

### Terminal handoff — `:3469-3517`
```
if workflow.patched("wave-arch-coordinator-v1"):                           # :3486  (CURRENT path)
    terminal = await self._handoff_to_architecture_coordinator(input)      # :3487
    self._status = COMPLETED; self._progress_pct = 100.0; self._current_step = terminal; self._updated_at = _now_iso(); return terminal  # :3488-3492
if workflow.patched("wave-rationalization-architecture-dispatch-v1"):      # :3494  (LEGACY inline fan-out)
    terminal = await self._execute_architecture_data_fanout(input, per_app_results)  # :3495-3498
    if terminal in ("completed","dispatched"): self._status = COMPLETED     # :3502-3503
    else: self._status = FAILED                                             # :3504-3505
    self._progress_pct = 100.0
    self._current_step = "architecture-dispatched" if terminal=="dispatched" else terminal  # :3507-3509
    self._updated_at = _now_iso(); return terminal                         # :3510-3511
self._status = COMPLETED; self._progress_pct = 100.0; self._current_step = "completed"; self._updated_at = _now_iso(); return "completed"  # :3513-3517
```
GOTCHA: new runs always take the coordinator path (`wave-arch-coordinator-v1` returns True at branch head). The inline fan-out branch (`_execute_architecture_data_fanout`) is retained for pre-patch replay. GOTCHA: `stuck-awaiting-recovery` terminal from the inline fan-out maps to FAILED status (since it's not in `("completed","dispatched")`) — but `run()`'s exception handler is NOT triggered (no exception raised); the wave status DB row was already set by `_update_wave_status_safe`.

### `_handoff_to_architecture_coordinator(input) -> str` — `:3519-3601`
```
coordinator_workflow_id = f"wave-architecture-{input.wave_id}"             # :3538
coordinator_input = WaveArchitectureWorkflowInput(wave_id, wave_name, portfolio_id, app_ids=list(input.app_ids),
    artifact_repo, stakeholder, fixture_scenarios=dict(...), build_app_ids=list(self._build_app_ids))  # :3539-3551
try: await workflow.start_child_workflow("WaveArchitectureWorkflow", coordinator_input, id=coordinator_workflow_id, parent_close_policy=ABANDON)  # :3552-3558
except Exception as exc: log.error(...); return "architecture-coordinator-start-failed"  # :3559-3568
try: await execute_activity(update_wave_architecture_workflow_id, UpdateWaveArchitectureWorkflowIdInput(wave_id, architecture_workflow_id=coordinator_workflow_id), 30s, transient, activity_id=f"persist-arch-coordinator-id-{wave_id}")  # :3570-3580
except Exception as exc: log.warning(...)  # best-effort, doesn't fail      # :3581-3592
log.info("wave-arch-coordinator handed off", ...); return "architecture-coordinator-started"  # :3594-3601
```
GOTCHA: ABANDON close policy lets the coordinator outlive Rationalization. Start failure returns a sentinel string (does NOT roll back Rationalization success). The persist is best-effort.

---

Continue to Part 3 for the inline Architecture/Data fan-out, all `_provision_one_target`/`_spawn_children_for_target`/`_drain_retry_queue` logic, gate plumbing (`_wait_for_gate`, `_reconcile_and_merge_with_retry_loop`, `_run_gate_pre_review`, `_register_gate_key`, `_merge_capability_lineage_row_rework`), helpers, and the behavioral-parity checklist.
