# DiscoveryWorkflow — Atomic Regeneration Spec (Part 1 of 2)

**Source:** `temporal/olympus_workflows/workflows/discovery.py` (1945 lines).
**Base class:** `LineWorkflowBase` (`temporal/olympus_workflows/workflows/base.py`) — see `_base-workflow.md` for inherited signals/queries/gate machinery; this doc fully re-specifies every helper Discovery *actually calls* so a rebuild needs no cross-reference for behavioral parity.
**Gate:** single gate **G-DC** (Discovery Complete).
**Bar:** behavioral parity. Reproduce HOW, not what.

> **PART SPLIT.** Part 1 (this file): module-level constants & contract loading, class config, STATE, SIGNALS/QUERIES, `run()` + `_execute_discovery()` main control flow, gate/merge tail. Part 2 (`DiscoveryWorkflow-part2.md`): Build/requirements mode, all dispatch/commit/evidence/pass helpers, variant selection, resilience, GOTCHAs, behavioral-parity checklist.

---

## 0. IMPORTANT PREMISE CORRECTIONS (verified against live code)

The build request referenced three things that **DO NOT EXIST** in the current code. Verified by Read/Grep on the live file. A rebuild MUST NOT add them:

1. **"a 2nd `@workflow.defn` class in file"** — FALSE. `discovery.py` defines exactly **ONE** `@workflow.defn` class: `DiscoveryWorkflow` (`discovery.py:169-170`). `grep -n "@workflow.defn"` returns only line 169. There is no second workflow class.
2. **"the `discovery_patterns_router` runtime tech-stack specialist dispatch"** — the `discovery_patterns_router` was **RETIRED** and replaced by a registry-driven composition (`discovery.py:92-101`). Dispatch is now driven by `select_skill(DISCOVERY_PATTERNS_COMPOSITION, inputs)` (`discovery.py:97-101,1230`). The *behavior* (tech-stack specialist dispatched alongside the generic mapper at Pass 1) survives; the router does not. Fully specified in Part 2 §Variant-Selection.
3. **"the two-gate merge behavior"** — FALSE for Discovery. Discovery has a **single gate G-DC** (`discovery.py:190` `SINGLE_GATE_KEY = "G-DC"`). There is exactly one `_wait_for_gate_decision(GateType.G_DC)` and one `_reconcile_and_merge_with_retry_loop(...)` per gate cycle. The "merge retry loop" (merge_blocked → reviewer retries) is a single-gate retry loop, not a two-gate flow. Fully specified in §5.

---

## 1. MODULE-LEVEL CONSTANTS & CONTRACT-DRIVEN LOADING

All built at **import time** from the authoritative contract. A contract rename without a matching edit here raises `KeyError` at worker startup (`discovery.py:27-34` — the `allow-file` note documents this intentional fail-fast).

### 1.1 `DISCOVERY_PASSES` — `_build_discovery_passes()` (`discovery.py:117-147`)
- Calls `from olympus_contracts import get_line`; iterates `get_line("Discovery").evidence_steps()` (`discovery.py:128-131`).
- For each `step`:
  - `if not step.skills: continue` (`discovery.py:132-133`) — steps with no skills are skipped entirely.
  - `artifact = step.artifact_filename or (f"{step.outputs.artifacts[0]}.json" if step.outputs.artifacts else f"{step.id}.json")` (`discovery.py:134-138`) — three-level fallback.
  - `passes[step.id] = {"skill_id": step.skills[0], "artifact": artifact, "kind": "agent"}` (`discovery.py:139-143`). Only the **first** skill of the step is used as `skill_id`.
- `DISCOVERY_PASSES = _build_discovery_passes()` (`discovery.py:147`). Dict-iteration order == contract declaration order — load-bearing for `_collect_all_pass_artifacts`, `_commit_artifacts_*`, and PR-body listing.
- Structural note (`discovery.py:114-116`): `business-logic-extraction`, `quality-risk-assessment`, `ux-accessibility-assessment` are sequence-3 (parallel); `synthesis` + `tco-baseline` are sequence-4 (parallel).

**GOTCHA:** the workflow indexes `STEP_WEIGHTS[...]` and `DISCOVERY_PASSES[...]` by hard-coded step-id string literals throughout `run()`/helpers (e.g. `"catalog"`, `"structural-analysis"`, `"business-logic-extraction"`, `"quality-risk-assessment"`, `"ux-accessibility-assessment"`, `"synthesis"`, `"tco-baseline"`, `"commit-artifacts"`, `"create-pr"`, `"gate-readiness-check"`). If any of these ids is absent from the contract at import, `STEP_WEIGHTS[...]` raises `KeyError` at first `_set_step` progress computation. This is deliberate drift-detection (`discovery.py:27-34`).

### 1.2 `STEP_WEIGHTS` — `_build_step_weights()` (`discovery.py:150-163`)
- `from olympus_contracts import step_weights as _contract_weights`; `return _contract_weights("Discovery")` (`discovery.py:158-160`).
- Per-step float progress weights. Progress is emitted as **cumulative sums** of these weights as steps complete (see §3).

### 1.3 `DISCOVERY_PATTERNS_DEFAULT_SKILL` (`discovery.py:104-106`)
- `= DISCOVERY_PATTERNS_COMPOSITION.metadata["selection_table"].default` — the composition's fallback base skill. Value: `"discovery-patterns"` (`registered.py:116`). Used to decide whether a specialist variant dispatch is redundant (see §3 Pass 1 and Part 2).

### 1.4 `MAX_REWORK_ITERATIONS = 3` (`discovery.py:166`)
- Rework loop fails the workflow when `_rework_count("G-DC") > 3` (strictly greater — so up to 3 rework iterations are tolerated, the 4th rejection fails). See §5.

---

## 2. CLASS CONFIGURATION (`discovery.py:169-191`)

`@workflow.defn` `class DiscoveryWorkflow(LineWorkflowBase)`. ClassVars consumed by base helpers:

| ClassVar | Value | Consumed by |
|---|---|---|
| `ASSEMBLY_LINE` | `AssemblyLine.DISCOVERY` (`:184`) | `get_status` query (`base.py:1359`) |
| `ARTIFACT_ROOT` | `"discovery"` (`:185`) | `_task_type_prefix` default |
| `LINE_LABEL` | `"Discovery"` (`:186`) | `_set_step`/`_update_app_status`/`_execution_ctx` line_id (lowercased → `"discovery"`) |
| `STATUS_PREFIX` | `"discovery"` (`:187`) | `_set_step` status string `discovery_in_progress` |
| `STEPS` | `DISCOVERY_PASSES` (`:188`) | base helpers that reference STEPS |
| `STEP_WEIGHTS` | module `STEP_WEIGHTS` (`:189`) | progress math |
| `SINGLE_GATE_KEY` | `"G-DC"` (`:190`) | `_rework_gate_key_for_step` → returns `"G-DC"` for every step |

**GOTCHA:** Discovery keeps a **parallel** artifact-tracking dict `_pass_results` (keyed by *pass name*) separate from the base `_step_results` (keyed by step_name). Discovery **overrides** `_build_evidence_data` to read `_pass_results` with a `passes` key rather than `steps` (Part 2). Its `_dispatch_pass`/`_commit_*` write only `_pass_results`, NOT `_step_results`. So the base `_build_evidence_data` (which reads `_step_results`) would emit empty steps — but Discovery never calls the base version; it always calls its own override.

---

## 3. STATE — every instance variable

### 3.1 Discovery-own state (`__init__`, `discovery.py:192-220`)
Calls `super().__init__()` first (`:193`), then sets:

| Var | Type | Initial | Mutated by / when |
|---|---|---|---|
| `_complexity_tier` | `ComplexityTier \| None` | `None` (`:195`) | set to `input.complexity_tier` at `run()` start (`:236`); mutated by `reclassify_complexity` signal (`:1019`). **Read nowhere else** — reclassification is stored but does not currently alter control flow (see GOTCHA in Part 2). |
| `_pass_results` | `dict[str, list[str]]` | `{}` (`:200`) | keyed by pass name; written by `_dispatch_pass`? No — written by the *callers* (`run`, `_run_parallel_passes`, `_run_synthesis_and_tco`, `_dispatch_pass_requirements`). Read by `_collect_all_pass_artifacts`, `_commit_*`, `_extract_pass_content`, `_build_evidence_data`. |
| `_committed_pass_paths` | `dict[str, list[str]]` | `{}` (`:207`) | keyed by pass name; written by `_commit_one_pass` (`:1702`). Read by `_collect_all_pass_artifacts`, `_commit_artifacts_batched`, `_run_synthesis_and_tco` TCO inputs. Lets synthesis hydrate prior passes from the branch. |
| `_interview_completed` | `bool` | `False` (`:218`) | set `True` by `interview_completed` signal (`:1042`); reset to `False` on interview rework (`:808`). Consumed in `_wait_for_interview_completion` predicate (`:1069`). |
| `_interview_expired` | `bool` | `False` (`:219`) | set `True` by `interview_expired` signal (`:1054`). Consumed in wait predicate (`:1070`). |
| `_interview_artifact` | `dict[str, Any] \| None` | `None` (`:220`) | set by `interview_completed` signal iff payload artifact is a dict (`:1041`); reset to `None` on interview rework (`:809`). Read in `_intake_interview` (`:859`). |

### 3.2 Inherited state consumed by Discovery (`base.py:136-191`)
| Var | Initial | Discovery use |
|---|---|---|
| `_app_id` | `""` | set at `run()` (`:239`) |
| `_portfolio_id`, `_wave_id` | `""` | NOTE: Discovery **does NOT set** `_portfolio_id`/`_wave_id` in `run()` (only `_app_id`). `_execution_ctx` returns `None` whenever `_portfolio_id` is empty (`base.py:345-346`) → Discovery's execution-context envelopes are `None` in practice. GOTCHA. |
| `_status` | `WorkflowStatus.PENDING` | set RUNNING (`:233`), FAILED (`:258`,`705`,`798`), COMPLETED (`:641`,`784`), WAITING_FOR_SIGNAL (base gate wait, `:1066`) |
| `_current_step` | `""` | set on failure/terminal transitions (`:259`,`643`,`651`,`706`,`786`,`799`) |
| `_progress_pct` | `0.0` | set `100.0` on success (`:642`,`785`); otherwise via `_set_step` |
| `_pending_gate` | `None` | set/cleared by `_wait_for_gate_decision` (base) |
| `_started_at`,`_updated_at` | `""` | `run()` init (`:234-235`); refreshed everywhere |
| `_gate_decisions` / `_gate_decisions_consumed` | `[]` / `0` | gate-signal buffer; consumed by `_wait_for_gate_decision` (base §SIGNALS) |
| `_rework_feedback` | `{}` | keyed by gate string `"G-DC"`; set on rejection (`base.py:1149`), popped on approval (`:1146`); read by `_dispatch_pass`/`_dispatch_discovery_patterns_variant`/`_dispatch_pass_requirements` |
| `_rework_iterations` | `{}` | `_bump_rework("G-DC")` / `_rework_count("G-DC")` |
| `_step_results` / `_step_committed_paths` | `{}` / `{}` | **unused by Discovery** (uses `_pass_results`/`_committed_pass_paths` instead) |
| `_agent_metadata` | `{}` | keyed by pass name / skill id; written by every dispatch helper |
| `_risk_tier` | `None` | Discovery never sets it; `_submit_gate_evidence` called with `forward_risk_tier=False` so it's never forwarded |
| `_merge_retry_signalled` | `False` | set by `merge_retry` signal; consumed in merge-retry loop |
| `cancelled` | `False` | from `temporal_base/signals.py:45`; set True by cancel signal (`signals.py:86`); consumed in gate-wait / interview-wait / merge-retry predicates |

---

## 4. SIGNALS & QUERIES

### 4.1 Inherited signals (defined on base — **DO NOT redefine in Discovery**) (`base.py:194-257`)
The base header explicitly warns: *"Signal handlers — decorated here, DO NOT redefine in subclasses"* (`base.py:194`). Redefining would replace the base decorator and break the buffered-decision protocol.

- **`gate_approved(signal: GateApprovedSignal)`** (`base.py:198`): appends `(APPROVED, approved_by, justification, None, [])` (a 5-tuple) to `_gate_decisions`; refreshes `_updated_at`.
- **`gate_rejected(signal: GateRejectedSignal)`** (`base.py:212`): normalizes `card_decisions = list(getattr(signal,"card_decisions",[]) or [])`, `reason_category = getattr(signal,"reason_category",None)`; appends `(REJECTED, rejected_by, reason, reason_category, card_decisions)`.
- **`escalation_resolved(signal: EscalationResolvedSignal)`** (`base.py:235`): only refreshes `_updated_at` (no state).
- **`merge_retry(signal: GateMergeRetrySignal)`** (`base.py:242`): sets `_merge_retry_signalled = True` (idempotent); refreshes `_updated_at`. Consumed by the merge-retry loop.
- **Consuming predicate** (`_wait_for_gate_decision`, `base.py:1117-1119`): captures `consumed = self._gate_decisions_consumed`, then `wait_condition(lambda: len(self._gate_decisions) > consumed or self.cancelled)`. Decisions are consumed **in FIFO order** — early-arriving signals are buffered.

### 4.2 Discovery-specific signals

**`reclassify_complexity(new_tier: str)`** (`discovery.py:1011-1022`):
```
try: self._complexity_tier = ComplexityTier(new_tier)
except ValueError: pass          # invalid tier silently ignored (:1020-1021)
self._updated_at = _now_iso()
```
GOTCHA: buffers into `_complexity_tier` but **no code reads `_complexity_tier` for branching** — comment at `:353-354` says the signal "updates self._complexity_tier directly" during Pass 1, but the value never gates behavior. Effectively observability-only in the current code.

**`interview_completed(payload: dict[str, Any])`** (`discovery.py:1024-1043`):
```
artifact = payload.get("artifact") if isinstance(payload, dict) else None   (:1039)
if isinstance(artifact, dict): self._interview_artifact = artifact          (:1040-1041)
self._interview_completed = True                                            (:1042)
self._updated_at = _now_iso()
```
Defensive: a missing/malformed `artifact` still flips `_interview_completed` so the wait releases (commit falls back to empty envelope).

**`interview_expired(payload: dict[str, Any])`** (`discovery.py:1045-1055`):
```
self._interview_expired = True    (:1054)
self._updated_at = _now_iso()
```
Fired by the API 14-day-deadline sweep. Releases the interview wait so the workflow fails cleanly instead of hanging (there is NO workflow-side timer — see `_wait_for_interview_completion` §Part2).

### 4.3 Query
- **`get_status() -> WorkflowStatusResponse`** (inherited, `base.py:1353-1365`): returns `workflow_id, status=_status, current_line=DISCOVERY, current_step, progress_pct, pending_gate, started_at, updated_at`. Discovery does not override it.

---

## 5. CONTROL FLOW — `run()` and `_execute_discovery()`

### 5.1 `run(input: LineWorkflowInput) -> str` (`discovery.py:222-267`)
```
self._status = RUNNING                                    (:233)
self._started_at = _now_iso(); self._updated_at = same    (:234-235)
self._complexity_tier = input.complexity_tier             (:236)
app_id = input.app_id; self._app_id = app_id              (:238-239)
repo = input.artifact_repo                                (:240)
source_repo = input.source_repo                           (:241)
wf_id = workflow.info().workflow_id                       (:243)
run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]   (:244)
branch = f"olympus/discovery/{app_id}/{run_suffix}"       (:245)
workspace_key = f"discovery-{app_id}-{run_suffix}"        (:250)
try:
    return await self._execute_discovery(input, app_id, repo, source_repo, branch, workspace_key)   (:253-255)
except Exception:
    self._status = FAILED; self._current_step = "failed"; self._updated_at = _now_iso()   (:258-260)
    try: await self._update_app_status(app_id, "discovery_failed", "failed", "Discovery")  (:262-264)
    except Exception: pass    # best-effort, don't mask original                            (:265-266)
    raise                     # re-raise original                                          (:267)
```
GOTCHA (branch uniqueness): `run_suffix` is derived from the workflow id's last `-`-segment (or first 8 chars if none), so re-runs of the same app get distinct branches — collision-safe per run (`:242-245`).

### 5.2 `_execute_discovery(...)` — code-analysis path (`discovery.py:269-663`)

**Build-mode fork (early return)** (`:287-290`):
```
if input.source_type in ("requirements_doc", "interview"):
    return await self._execute_requirements_mode(input, app_id, repo, branch)   (:288-290)
```
→ requirements path (Part 2 §Build-mode). No code-analysis passes run. The rest of `_execute_discovery` is the code-analysis path.

**Step 1 — Catalog** (`:292-301`):
```
await self._set_step("catalog", 0.0)                                            (:293)
catalog_result = await self._dispatch_pass(
    app_id, pass_name="catalog",
    input_artifacts=list(input.prior_artifacts),                                (:297)
    source_repo, workspace_key)
self._pass_results["catalog"] = catalog_result.output_artifacts                 (:301)
```

**Step 2 — Structural Analysis (Pass 1) + tech-stack specialist fan-out** (`:303-351`):
```
await self._set_step("structural-analysis", STEP_WEIGHTS["catalog"])            (:317)
variant_skill = self._select_discovery_patterns_variant(catalog_result.output_artifacts)   (:318-320)
dispatches = [ self._dispatch_pass(app_id, pass_name="structural-analysis",
                    input_artifacts=catalog_result.output_artifacts,
                    source_repo, workspace_key) ]                               (:321-329)
if variant_skill and variant_skill != DISCOVERY_PATTERNS_DEFAULT_SKILL:         (:330)
    dispatches.append(self._dispatch_discovery_patterns_variant(
        app_id, skill_id=variant_skill,
        input_artifacts=catalog_result.output_artifacts, source_repo, workspace_key))   (:331-339)
fan_out = await asyncio.gather(*dispatches)                                     (:340)  # PARALLEL
structural_result = fan_out[0]                                                  (:341)
self._pass_results["structural-analysis"] = list(structural_result.output_artifacts)   (:342)
if len(fan_out) > 1:                                                            (:343)
    variant_result = fan_out[1]
    self._pass_results["structural-analysis"].extend(variant_result.output_artifacts)   (:349-351)
```
- BRANCH: specialist is dispatched **only** when `variant_skill` is truthy AND `!= "discovery-patterns"` (the generic base). If the router returns the base or `None`, only the generic mapper runs. Variant selection is pure/deterministic (Part 2 §Variant-Selection).
- Both dispatches run concurrently via `asyncio.gather`; specialist outputs are **merged into the same `structural-analysis` bucket** so downstream passes get both artifacts.

**Steps 3a-3c — parallel passes** (`:356-366`):
```
await self._run_parallel_passes(app_id,
    list(self._pass_results["structural-analysis"]), source_repo, workspace_key)   (:361-366)
```
See Part 2 §`_run_parallel_passes` — always fans out business-logic/quality-risk/ux; conditionally adds data-domain / shared-database / capability-extraction / compliance-citation-mapping passes under patch guards.

**Commit-before-synthesis patch decision** (`:379-381`):
```
commit_before_synthesis = workflow.patched("discovery-commit-before-synthesis-v1")   (:379-381)
```

**Synthesis + Gate loop** — `while True:` (`:383-663`). Each iteration:

1. If `commit_before_synthesis` (`:385-396`): for each `pass_name in DISCOVERY_PASSES`, `continue` if it is one of `("synthesis","tco-baseline","gate-readiness-check")`; else if `self._pass_results.get(pass_name)` truthy, `await self._commit_one_pass(pass_name, repo, branch, app_id)`. Re-committing on a rework loop is idempotent.

2. **Step 4 — Synthesis + TCO in parallel** (`:398-409`):
```
synthesis_input_artifacts = self._collect_all_pass_artifacts()                 (:399)
synthesis_result, tco_result = await self._run_synthesis_and_tco(
    app_id, synthesis_input_artifacts, source_repo, workspace_key,
    artifact_repo=(repo if commit_before_synthesis else ""),                   (:405)
    artifact_ref=(branch if commit_before_synthesis else ""))                  (:406)
self._pass_results["synthesis"] = synthesis_result.output_artifacts            (:408)
self._pass_results["tco-baseline"] = tco_result.output_artifacts               (:409)
```
GOTCHA: `artifact_repo`/`artifact_ref` are passed to synthesis/TCO **only** in commit-before-synthesis mode, so those dispatches hydrate inputs from the git branch; pre-patch they get `""` and rely on container-local workspace.

3. **Step 5 — Commit artifacts** (`:411-422`):
```
await self._set_step("commit-artifacts", <cumsum of 7 weights>)                (:412-421)
artifact_paths = await self._commit_artifacts(repo, branch, app_id)            (:422)
```
Cumulative weight = catalog + structural-analysis + business-logic-extraction + quality-risk-assessment + ux-accessibility-assessment + synthesis + tco-baseline.

4. **Step 5b — persist_decomposition_map** (best-effort) (`:424-447`):
```
try:
    catalog_json = self._extract_pass_content("catalog")                       (:430)
    synthesis_json = self._extract_pass_content("synthesis")                   (:431)
    if catalog_json or synthesis_json:                                         (:432)
        await workflow.execute_activity(persist_decomposition_map,
            PersistDecompositionMapInput(app_id, catalog_json, synthesis_json),
            start_to_close_timeout=30s, retry=RETRY_POLICIES["transient"],
            activity_id="persist-decomposition-map")                           (:433-443)
except Exception:  # noqa BLE001 — observability only
    workflow.logger.exception(...)                                             (:444-447)
```

5. **Step 5c — persist_discovery_side_effects** (best-effort) (`:449-488`):
```
try:
    side_effects_input = PersistDiscoverySideEffectsInput(
        app_id,
        catalog_json=_extract_pass_content("catalog"),
        structural_json=_extract_pass_content("structural-analysis"),
        business_logic_json=_extract_pass_content("business-logic-extraction"),
        quality_risk_json=_extract_pass_content("quality-risk-assessment"),
        ux_accessibility_json=_extract_pass_content("ux-accessibility-assessment"),
        synthesis_json=_extract_pass_content("synthesis"),
        tco_json=_extract_pass_content("tco-baseline"))                        (:459-476)
    await workflow.execute_activity(persist_discovery_side_effects,
        side_effects_input, start_to_close_timeout=30s,
        retry=transient, activity_id="persist-discovery-side-effects")         (:477-483)
except Exception: workflow.logger.exception(...)                               (:484-488)
```
GOTCHA: parses exactly **7** pass JSONs — this list is hard-coded and does NOT include data-domain/shared-database/capability/citation passes even when those patches are active.

6. **Step 5d — persist_capability_catalog** (best-effort, conditional) (`:490-518`):
```
try:
    cap_json = self._extract_pass_content("capability-extraction")            (:498)
    if cap_json:                                                              (:499)
        await workflow.execute_activity(persist_capability_catalog,
            PersistCapabilityCatalogInput(app_id, portfolio_id=input.portfolio_id,
                capability_catalog_json=cap_json,
                capability_catalog_artifact_ref=f"discovery/{app_id}/capability-catalog.json"),
            start_to_close_timeout=30s, retry=transient,
            activity_id="persist-capability-catalog")                         (:500-513)
except Exception: workflow.logger.exception(...)                              (:514-518)
```
Only fires when `capability-extraction` produced parseable content (i.e. the `discovery-capability-extraction-v1` patch was active and the pass ran).

7. **Step 6 — Create PR** (`:520-532`):
```
await self._set_step("create-pr", <cumsum of 8 weights incl commit-artifacts>)   (:521-531)
pr_result = await self._create_gate_pr_discovery(repo, branch, app_id)            (:532)
```

8. **Step 6b — create_gate_record** (`:534-547`):
```
wf_id = workflow.info().workflow_id                                              (:535)
gate_record = await workflow.execute_activity(create_gate_record,
    CreateGateRecordInput(gate_type="G-DC", app_id, portfolio_id=input.portfolio_id,
        workflow_id=wf_id, evidence_package_url=pr_result.pr_url),
    start_to_close_timeout=30s, retry=transient)                                 (:536-547)
gate_id = gate_record.gate_id                                                    (:552)
```

9. **Step 7 — submit gate evidence** (`:549-562`):
```
await self._submit_gate_evidence(gate_id, gate_type=GateType.G_DC, app_id,
    artifact_paths, pr_url=pr_result.pr_url, assembly_line="Discovery",
    step="gate-review", forward_risk_tier=False)                                 (:553-562)
```
`forward_risk_tier=False` — Discovery predates F3 risk plumbing (`:550-551`). See §6 for evidence assembly.

10. **Step 7b — gate readiness check (advisory)** (`:564-588`):
```
await self._set_step("gate-readiness-check", <cumsum of 9 weights incl create-pr>)   (:570-581)
await self._run_gate_pre_review(gate_id, "G-DC", artifact_paths,
    artifact_repo=repo, artifact_ref=branch)                                     (:582-588)
```
Fault-tolerant (base helper §6.2).

11. **Enter gate review** (`:590-608`):
```
await self._update_app_status(app_id, "gate_review", "gate-review", "Discovery")   (:591-593)
await self._set_step("gate-review", <cumsum of 10 weights incl gate-readiness-check>)   (:596-608)
```

12. **Step 8 — wait for gate decision** (`:609`):
```
decision = await self._wait_for_gate_decision(GateType.G_DC)                     (:609)
```
Returns `"approved"` / `"rejected"` / `"cancelled"` (base §6.1).

13. **Decision routing** (`:611-663`):
```
if decision == "cancelled":  return "cancelled"                                  (:611-612)

if decision == "approved":                                                       (:614)
    await self._reconcile_and_merge_with_retry_loop(
        repo, pr_number=pr_result.pr_number, gate_id=gate_id, merge_method="merge")   (:620-625)
    await self._calculate_and_record_score(app_id)                               (:627)
    await self._update_app_status(app_id, "discovery_complete", "completed", "Discovery")   (:628-630)
    # NOTE (:632-639): does NOT auto-start Rationalization (wave-scoped line).
    self._status = COMPLETED; self._progress_pct = 100.0
    self._current_step = "completed"; self._updated_at = _now_iso()              (:641-644)
    return "completed"                                                           (:645)

# Gate rejected — rework:                                                        (:647)
self._bump_rework("G-DC")                                                        (:648)
if self._rework_count("G-DC") > MAX_REWORK_ITERATIONS:                           (:649)
    self._status = FAILED; self._current_step = "max-rework-exceeded"
    self._updated_at = _now_iso()
    await self._update_app_status(app_id, "discovery_failed", "max-rework-exceeded", "Discovery")   (:650-655)
    return "failed"                                                              (:656)

# Re-run parallel passes with feedback, then loop to synthesis:                  (:658)
await self._run_parallel_passes(app_id,
    list(self._pass_results["structural-analysis"]), source_repo, workspace_key)   (:659-663)
# falls off the end → back to top of `while True:` (:384)
```

**GOTCHA (rework loop scope):** on rejection, ONLY the sequence-3 parallel passes are re-run (`_run_parallel_passes`, `:659`). Catalog (step 1) and structural-analysis (Pass 1) are **NOT** re-run on rework. Synthesis+TCO re-run because they are inside the `while True:` loop body. The rework feedback reaches re-dispatched agents via `_rework_feedback["G-DC"]` → `context["rework_feedback"]` (set by `gate_rejected`/`_wait_for_gate_decision`, read in `_dispatch_pass`).

**GOTCHA (rework counter timing):** `_bump_rework` runs BEFORE the `> MAX_REWORK_ITERATIONS` check, and the check is strict `>`. So counts 1,2,3 continue to rework; count 4 (`4 > 3`) fails. That means up to **3 rework attempts** after the first rejection, i.e. up to 4 total synthesis→gate cycles.

---

## 6. GATE HANDLING (inherited helpers, fully specified)

### 6.1 `_wait_for_gate_decision(gate_type)` (`base.py:1103-1157`)
```
self._status = WAITING_FOR_SIGNAL; self._pending_gate = gate_type; _updated_at        (:1113-1115)
consumed = self._gate_decisions_consumed                                              (:1117)
await workflow.wait_condition(lambda: len(self._gate_decisions) > consumed or self.cancelled)   (:1118-1120)
if self.cancelled: status=CANCELLED; return "cancelled"                               (:1122-1125)
entry = self._gate_decisions[consumed]                                                (:1127)
if len(entry) == 5: decision,actor,reason,reason_category,card_decisions = entry      (:1132-1133)
else: decision,actor,reason = entry[0:3]; reason_category=None; card_decisions=[]     (:1134-1137)
self._gate_decisions_consumed = consumed + 1                                          (:1138)
self._pending_gate = None; status=RUNNING; _updated_at                                (:1140-1142)
gate_key = gate_type.value                                                            (:1144)
if decision == APPROVED: self._rework_feedback.pop(gate_key, None); return "approved" (:1145-1147)
self._rework_feedback[gate_key] = {gate, rejected_by, reason, reason_category,
    card_decisions, rejected_at}; return "rejected"                                   (:1149-1157)
```
GOTCHA: FIFO consume-by-index; supports both 3-tuple (legacy) and 5-tuple entries. Discovery always sends 5-tuples (its base handlers append 5-tuples).

### 6.2 `_run_gate_pre_review(gate_id, gate_type_value, evidence_paths, *, artifact_repo, artifact_ref)` (`base.py:1023-1101`)
```
try:
    pre_review_result = execute_activity(dispatch_agent_task,
        AgentTaskInput(skill_id="gate-pre-review", app_id=self._app_id,
            task_type="gate-pre-review", input_artifacts=evidence_paths,
            artifact_repo, artifact_ref,
            context={"gate_id":gate_id,"gate_type":gate_type_value},
            execution_context=self._execution_ctx(f"ai-pre-review-{gate_type_value.lower()}",
                gate_id, input_artifact_paths=evidence_paths)),
        start_to_close_timeout=AGENT_START_TO_CLOSE (3h),
        heartbeat_timeout=AGENT_DISPATCH_HEARTBEAT_TIMEOUT (2m),
        retry=RETRY_POLICIES["transient"])                                            (:1049-1071)
    agent_markdown = pre_review_result.output_artifacts[0] if output_artifacts else ""(:1072-1076)
    if not agent_markdown: raise ValueError("Gate pre-review produced no output")     (:1077-1078)
    execute_activity(store_gate_pre_review, StoreGatePreReviewInput(gate_id, agent_output=agent_markdown),
        start_to_close=30s, retry=transient)                                          (:1079-1087)
except Exception:
    workflow.logger.warning("Gate pre-review failed ... continuing")                 (:1088-1093)
finally:
    if workflow.patched("mark-gate-ready-for-review-v1"):                             (:1095)
        execute_activity(mark_gate_ready_for_review, gate_id, start_to_close=30s, retry=transient)   (:1096-1101)
```
GOTCHA: entirely fault-tolerant — a pre-review failure logs a warning and continues; the `finally` still flips the gate "ready for review" under the patch guard even if the pre-review agent failed. Uses `transient` retry (NOT `agent_failure`) so a hard agent error isn't retried 3× with backoff.

### 6.3 `_submit_gate_evidence(...)` (`base.py:922-1021`) — as called by Discovery with `forward_risk_tier=False`
```
slim_evidence = self._build_evidence_data(app_id, assembly_line, step)                (:954-956)  # Discovery override
gate_type_str = gate_type.value                                                       (:962-964)
threshold_suffixes = { th["artifact"] for th in GATE_THRESHOLDS.get(gate_type_str, []) }   (:965-968)
if threshold_suffixes:  # NOT the case for G-DC (no thresholds)                        (:969)
    ... rebuild bundle with content_paths ...                                         (:970-981)
else: criteria_evidence = slim_evidence                                               (:982-983)
# forward_risk_tier is False for Discovery →
check_input = CheckGateCriteriaInput(gate_id, gate_type, app_id, evidence_paths=artifact_paths)   (:994-1000)
execute_activity(check_gate_criteria, check_input, start_to_close=60s, retry=transient)   (:1001-1006)
evidence_input = SubmitGateEvidenceInput(gate_id, gate_type, app_id, artifact_paths, pr_url,
    evidence_data=slim_evidence)                                                      (:1008-1015)
execute_activity(submit_gate_evidence, evidence_input, start_to_close=60s, retry=transient)   (:1016-1021)
```
GOTCHA: G-DC has no `GATE_THRESHOLDS` entry, so `threshold_suffixes` is empty → the branch that inlines file contents never fires; the bundle stays slim. And because `forward_risk_tier=False`, `CheckGateCriteriaInput` is built WITHOUT `evidence_data`/`risk_tier` (call-shape parity with pre-F3 workflows).

### 6.4 Merge routing — `_reconcile_and_merge_with_retry_loop(*, repo, pr_number, gate_id, merge_method="merge")` (`base.py:1159-1279`)
```
merge_failure_types = {"MergeConflict","MergeDivergenceUnresolved","MergeBranchProtectionRejected"}   (:1196-1200)
merge_ctx = self._execution_ctx(f"merge-pr-{pr_number}", gate_id=gate_id)   # None for Discovery (:1202-1205)
while True:
    try:
        execute_activity(reconcile_and_merge_pr,
            MergePRInput(repo, pr_number, merge_method, execution_context=merge_ctx),
            start_to_close_timeout=60s, retry=RETRY_POLICIES["git_merge"])            (:1208-1218)
        return   # success                                                            (:1219-1220)
    except (ActivityError, ApplicationError) as outer_exc:                            (:1221)
        inner = outer_exc
        while not isinstance(inner, ApplicationError) and inner.__cause__ is not None:
            inner = inner.__cause__                                                   (:1228-1233)
        if not isinstance(inner, ApplicationError): raise                             (:1234-1235)
        failure_type = inner.type or ""                                               (:1236)
        if failure_type not in merge_failure_types: raise   # unstructured → propagate(:1237-1240)
        detail = {failure_type, reason=str(exc), pr_number, detected_at}              (:1243-1248)
        workflow.logger.warning("merge_blocked", ...)                                 (:1249-1256)
        self._merge_retry_signalled = False   # reset BEFORE set_merge_blocked        (:1258-1261)
        execute_activity(set_gate_merge_blocked, args=[gate_id, detail],
            start_to_close=30s, retry=transient)                                      (:1263-1268)
        await workflow.wait_condition(lambda: self._merge_retry_signalled or self.cancelled)   (:1271-1273)
        if self.cancelled: return                                                     (:1274-1275)
        # loop back → retry merge                                                     (:1276-1279)
```
Routing summary for approve→merge:
- **merge success** → `return`, workflow continues to score + complete.
- **MergeDivergenceUnresolved** → `git_merge` policy retries up to 3× internally; if still failing → merge_blocked → wait for `merge_retry` signal → loop.
- **MergeConflict / MergeBranchProtectionRejected** → `git_merge` policy short-circuits (non_retryable) → merge_blocked → wait → loop.
- **any other error type** → re-raised → propagates up through `_execute_discovery` → caught by `run()`'s outer `except` → workflow FAILED.
GOTCHA: `_merge_retry_signalled` is reset to `False` immediately before `set_gate_merge_blocked` (`:1258-1261`) to avoid a stale prior-iteration signal short-circuiting the fresh wait.

---

**Continue in `DiscoveryWorkflow-part2.md`** for: Build/requirements mode (`_execute_requirements_mode`, `_intake_requirements_doc`, `_intake_interview`, `_commit_requirements_artifact`, `_dispatch_pass_requirements`, `_create_gate_pr_requirements`, `_wait_for_interview_completion`), variant selection (`_select_discovery_patterns_variant` + composition), `_dispatch_pass`, `_dispatch_discovery_patterns_variant`, `_run_parallel_passes`, `_run_synthesis_and_tco`, `_extract_pass_content`, `_collect_all_pass_artifacts`, `_commit_artifacts` (+ batched/legacy/one-pass), `_create_gate_pr_discovery`, `_build_evidence_data`, `_calculate_and_record_score`, RESILIENCE, and the Behavioral Parity Checklist.
