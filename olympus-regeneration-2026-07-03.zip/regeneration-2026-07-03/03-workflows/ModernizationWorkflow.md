# ModernizationWorkflow — Atomic Regeneration Spec (Part 1 of 3)

**Source:** `temporal/olympus_workflows/workflows/modernization.py` (2813 lines)
**Class:** `ModernizationWorkflow(BundleAwareMixin, LineWorkflowBase)` — decorated `@workflow.defn` (`modernization.py:204-205`)
**Parts:** this file (STATE, SIGNALS/QUERIES, module constants, `run`/`_execute_modernization`, Extract step); Part 2 = Design + Generate steps; Part 3 = commit helpers, `_parse_bounded_contexts`, `parse_bc_names_from_yaml`, seed/mark helpers, RESILIENCE, GOTCHAs, Behavioral-parity checklist.
**Shared machinery:** inherited from `LineWorkflowBase` (`workflows/base.py`) and `BundleAwareMixin` (`workflows/bundle_helpers.py`); see `_base-workflow.md`. This doc fully captures THIS class's overrides + `run()` body. Ralph-loop / per-BC internals are DEFERRED to `13-generation-engine.md` (child `GenerateBCWorkflow`).

---

## 0. MRO & inheritance (`modernization.py:204-227`)

- `@workflow.defn` at `modernization.py:204`.
- Class bases: `BundleAwareMixin, LineWorkflowBase` (`:205`).
- MRO: `ModernizationWorkflow → BundleAwareMixin → LineWorkflowBase → HILSignalsMixin → object` (`:215-218`).
- `BundleAwareMixin.__init__` calls `super().__init__()` (`bundle_helpers.py:90`), which chains through `LineWorkflowBase.__init__` (`base.py:136`, calls `super().__init__()` at `:137`) → `HILSignalsMixin.__init__` (`signals.py:29-45`, calls `super().__init__()` at `:30`). So the WHOLE chain initialises exactly once. **GOTCHA:** `ModernizationWorkflow.__init__` calls `super().__init__()` FIRST (`:241`) before setting its own attrs, so all inherited state exists before subclass fields are seeded.
- **No base-class signal handler is redefined** by this class. It ADDS `stakeholder_approved` and `wave_patterns_ready` signals + `get_received_patterns` query. Redefining an inherited `@workflow.signal` (e.g. `gate_approved`, `gate_rejected`, `merge_retry`, `cancel_workflow`, `bundle_completed`, `bundle_expired`) would break the shared gate/merge/cancel/bundle wiring — DO NOT override them.

### Class-level configuration (`modernization.py:230-238`)
- `ASSEMBLY_LINE = AssemblyLine.MODERNIZATION` (`:230`)
- `ARTIFACT_ROOT = "modernization"` (`:231`)
- `LINE_LABEL = "Modernization"` (`:232`)
- `STATUS_PREFIX = "modernization"` (`:233`)
- `SINGLE_GATE_KEY` intentionally UNSET (stays base default `None`) — three gates, routed via `_rework_gate_key_for_step` (`:234-235`).
- `STEPS` / `STEP_WEIGHTS` classvars are NOT set on the subclass; the module-level `STEP_WEIGHTS` dict (`:184-199`) is used instead, and `_build_evidence_data` is overridden because the base default iterates `STEPS` (`:236-238`).

---

## 1. Module-level constants & data

### `LANGUAGE_SKILL_MAP` (`modernization.py:130-136`)
Documentation-only dict; NOT used for selection anymore (registry-driven via `EXTRACTION_COMPOSITION`). Values: `cobol→extraction-cobol`, `java→extraction-java`, `coldfusion→extraction-coldfusion`, `python→extraction-python`, `default→extraction`. Exported in `__all__` (`:138-140`).

### `EXTRACT_SKILLS` (`:143-152`)
`extraction`: `{artifact: "business-rules.yaml", secondary_artifact: "test-scenarios.yaml"}`; `cross-validation`: `{skill_id: "cross-validation", artifact: "cross-validation-report.json"}`. (Reference data; the commit helper uses its own `step_to_artifact_filename` map.)

### `DESIGN_SKILLS` (`:155-172`) — iterated by `_commit_design_artifacts`
Ordered dict: `module-design→module-map.yaml`, `api-specification→openapi.yaml`, `data-modeling→data-model.yaml`, `batch-design→batch-design.yaml`. Each entry `{skill_id, artifact}`.

### `STEP_WEIGHTS` (`:184-199`) — MUST sum to 100
```
extract=15.0, cross-validation=5.0, requirement-aggregation=0.0,
business-rule-reconciliation=0.0, extract-commit=2.5, extract-gate=7.5,
design=15.0, design-commit=2.5, design-gate=7.5,
generate=25.0, generate-synthesis=5.0, generate-review=5.0,
generate-commit=2.5, generate-gate=7.5
```
**GOTCHA:** the two reconciliation steps carry weight **0.0** deliberately so the sum stays 100 and legacy replay paths (pre-`br-reconciliation-v1`) see unchanged progress percentages (`:176-183`). Progress on the new path stays monotonic because those dispatches sit between cross-validation and extract-commit.

### `MAX_REWORK_ITERATIONS = 3` (`:201`)
Per-gate cap. A gate FAILS the workflow when `_rework_count(gate) > 3` (i.e. the 4th rejection). See rework loops.

### `MAX_BC_CHILDREN_PER_APP` — imported from `types.py:135`, value **12**.
**GOTCHA:** the class docstring and file header say "max 5" (`:23`, `:226`); the live constant is **12**. Trust the constant, not the prose.

---

## 2. STATE — instance variables

All base+mixin state exists via the MRO. This section lists (a) inherited fields THIS workflow reads/writes, and (b) fields owned by this subclass.

### 2a. Inherited state THIS class mutates
From `HILSignalsMixin.__init__` (`signals.py:29-45`): `self.cancelled: bool=False` (read in every gate wait + Tier-1 sub-waits; set True by inherited `cancel_workflow` signal `signals.py:83-86`). Also `approved`, `plan_approved`, `document_approved`, etc. (unused by Modernization control flow).

From `LineWorkflowBase.__init__` (`base.py:136-191`):
| Field | Type | Init | Mutated by (Modernization) |
|---|---|---|---|
| `_app_id` | str | "" | `run` sets from `input.app_id` (`:643`) |
| `_portfolio_id` | str | "" | `run` (`:644`) |
| `_wave_id` | str | "" | `run` (`:645`) |
| `_status` | WorkflowStatus | PENDING | `run`→RUNNING (`:640`); FAILED on exception (`:656`) / max-rework / baseline-fail; CANCELLED in Tier-1 sub-waits; COMPLETED at end (`:727`); WAITING_FOR_SIGNAL inside `_wait_for_gate_decision` |
| `_current_step` | str | "" | `_set_step` (base) + explicit sets: "failed" (`:657`), "completed" (`:729`), "*-max-rework-exceeded", "generate-baseline-incomplete" |
| `_progress_pct` | float | 0.0 | `_set_step` (base); set 100.0 at completion (`:728`) |
| `_pending_gate` | GateType\|None | None | set/cleared inside base `_wait_for_gate_decision` |
| `_started_at` | str | "" | `run` (`:641`) |
| `_updated_at` | str | "" | many sites via `_now_iso()` |
| `_gate_decisions` | list[tuple] | [] | appended by base `gate_approved`/`gate_rejected` handlers; consumed by `_wait_for_gate_decision` |
| `_gate_decisions_consumed` | int | 0 | base `_wait_for_gate_decision` |
| `_rework_feedback` | dict[str,dict] | {} | base `_wait_for_gate_decision` records/clears; read in `_dispatch_agent` |
| `_rework_iterations` | dict[str,int] | {} | **seeded** to `{"G-04a":0,"G-04b":0,"G-04c":0}` in this `__init__` (`:254`); bumped via `_bump_rework`, read via `_rework_count` |
| `_step_results` / `_step_committed_paths` | dict | {} | inherited but Modernization uses its OWN per-phase dicts instead |
| `_agent_metadata` | dict[str,dict] | {} | written by `_dispatch_agent` (`:472-479`) + `_commit_design_artifacts` adds `"design-review"` entry (`:1577-1590`) |
| `_risk_tier` | int\|None | None | `run` (`:649-651`); gates Tier-1 sub-waits |
| `_merge_retry_signalled` | bool | False | base `merge_retry` handler + merge loop |
| `_profile_id` | str | "" | set by base `_load_delegation_config` |
| `_portfolio_fallback_policy` | str | "internal_fallback" | set by base `_load_delegation_config` |
| `_redispatch_guard` | set[str] | set() | base bundle fallback |

From `BundleAwareMixin.__init__` (`bundle_helpers.py:84-93`): `_bundle_outcomes: dict[str,str]={}`, `_bundle_outputs: dict[str,dict[str,str]]={}`, `_bundle_validation_summaries: dict[str,str]={}` — used by the Design step's `_maybe_dispatch_bundle`.

### 2b. Subclass-owned state (`modernization.py:240-289`)
| Field | Type | Init | Purpose / mutation |
|---|---|---|---|
| `_extract_results` | dict[str,list[str]] | {} (`:246`) | per-extract-step output artifacts (`extraction`, `cross-validation`, `requirement-aggregation`, `business-rule-reconciliation`). Written in `_execute_extract`; read by commit + evidence helpers |
| `_design_results` | dict[str,list[str]] | {} (`:247`) | per-design-step artifacts; also carries `"design-review"` key after commit (`:1576`) |
| `_generate_results` | list[GenerateBCResult] | [] (`:248`) | set to BC child results in `_execute_generate` (`:1815`) |
| `_rework_iterations` update | — | seeds G-04a/b/c=0 (`:254`) | avoids KeyError in PR-body builders on first iteration |
| `_received_patterns` | list[dict] | [] (`:262`) | governance patterns; appended by `wave_patterns_ready` signal + `_seed_patterns_from_registry`; read in `_dispatch_agent` + `get_received_patterns` query |
| `_g04c_stakeholder_ea_approved` | bool | False (`:270`) | Tier-1 G-04c EA flag; set by `stakeholder_approved(scope="g-04c-ea")`; reset in G-04c rework + baseline-fail branches |
| `_g04c_stakeholder_security_approved` | bool | False (`:271`) | Tier-1 G-04c security flag; set by `scope="g-04c-security"`; reset on G-04c rework + baseline-fail |
| `_g04a_stakeholder_sme_approved` | bool | False (`:274`) | Tier-1 G-04a SME flag; set by `scope="g-04a-sme"`; reset on G-04a rework (`:985`) |
| `_devsecops_params` | dict[str,Any] | {} (`:283`) | resolved ONCE at Generate start (`:1729-1748`); threaded into agent context; `sast_tool` passed to validator. Reused across Generate reworks (only resolved if empty) |
| `_committed_baseline_files` | list[tuple[str,str]] | [] (`:289`) | root-bound baseline `(repo_path,content)` pairs from most recent Generate commit; handed to G-04c validator; **repopulated each Generate iteration** by `_commit_generate_artifacts` (`:2332`) |
| `_input` | LineWorkflowInput | (set in run `:648`) | stored so base helpers can read `prior_artifacts` / `created_by` / delegation wiring |
| `_artifact_repo` | str | (set in `_execute_modernization` `:678`) | portfolio artifact repo (fallback for `repo`) |

---

## 3. SIGNALS & QUERIES

### 3.1 `stakeholder_approved` (`modernization.py:339-365`) — Modernization-specific
- Decorator: `@workflow.signal`, `async`.
- Payload: `StakeholderApprovedSignal` with field `.scope` (str).
- Behaviour (exact branch order):
  - `if signal.scope == "g-04c-ea"` → `self._g04c_stakeholder_ea_approved = True` (`:354-355`)
  - `elif signal.scope == "g-04c-security"` → `self._g04c_stakeholder_security_approved = True` (`:356-357`)
  - `elif signal.scope == "g-04a-sme"` → `self._g04a_stakeholder_sme_approved = True` (`:358-359`)
  - `else` → `workflow.logger.warning(... extra={"scope": signal.scope})`, IGNORED, not raised (`:360-364`). **GOTCHA:** unknown scopes are tolerated (older callers may send scopes irrelevant to Modernization).
  - Always: `self._updated_at = _now_iso()` (`:365`).
- **Consumed by** the Tier-1 gate sub-waits:
  - G-04a: `wait_condition(lambda: self._g04a_stakeholder_sme_approved or self.cancelled)` (`:946-951`).
  - G-04c: `wait_condition(lambda: (self._g04c_stakeholder_ea_approved and self._g04c_stakeholder_security_approved) or self.cancelled)` (`:2042-2050`). **Note the AND** — both EA and security flags required.

### 3.2 `wave_patterns_ready` (`:367-385`) — Modernization-specific
- `@workflow.signal`, `async`. Payload `WavePatternsReadySignal` with `.wave_id`, `.patterns` (iterable).
- Appends `{"wave_id": signal.wave_id, "patterns": list(signal.patterns), "received_at": _now_iso()}` to `_received_patterns` (`:378-384`); sets `_updated_at` (`:385`).
- Additive: multiple waves each append their own bundle; all retained (`:376-377`).
- No `wait_condition` consumes it directly; it is read opportunistically in `_dispatch_agent` (`:443-444`) to add `context["governance_patterns"]`.

### 3.3 `get_received_patterns` query (`:391-401`)
- `@workflow.query` (sync). Returns `[dict(entry) for entry in self._received_patterns]` — shallow copy so callers cannot alias internal state (`:401`).

### 3.4 Inherited signals/queries (DO NOT override)
- `gate_approved(GateApprovedSignal)` / `gate_rejected(GateRejectedSignal)` (`base.py:197-232`) — append to `_gate_decisions` (5-tuple). Consumed by `_wait_for_gate_decision`.
- `merge_retry(GateMergeRetrySignal)` (`base.py:241-257`) — sets `_merge_retry_signalled=True`; consumed by `_reconcile_and_merge_with_retry_loop`.
- `escalation_resolved` (`base.py:234-239`) — updates `_updated_at` only.
- `cancel_workflow()` (`signals.py:83-86`) — sets `self.cancelled=True`; observed by every gate wait predicate.
- `bundle_completed` / `bundle_expired` (`bundle_helpers.py:99-134`) — populate `_bundle_outcomes` / `_bundle_outputs`; consumed by `await_bundle_completion` inside the Design bundle path.
- `get_status` query (`base.py:1353-1365`); bundle queries `get_bundle_outcome` / `get_bundle_outputs` (`bundle_helpers.py:182-190`).

---

## 4. `_rework_gate_key_for_step` override (`modernization.py:295-333`)
Routes rework feedback by phase (used inside `_dispatch_agent` to fetch `_rework_feedback[gate]`):
- `extract_steps = {extraction, cross-validation, requirement-aggregation, business-rule-reconciliation, extract, synthesis}` → returns `"G-04a"` (`:311-330`).
- `design_steps = {module-design, api-specification, data-modeling, batch-design, traceability-audit, design, adversarial-review, gate-review-package}` → returns `"G-04b"` (`:319-332`).
- **else → returns `None`** (`:333`). **GOTCHA:** Generate-phase steps (synthesis is in the EXTRACT set here — quirk; `adversarial-review`/`gate-review-package` are in DESIGN set) do NOT map to G-04c. G-04c rework re-runs child `GenerateBCWorkflow`s, so no direct-dispatch feedback forwarding for Generate (`:305-309`).

---

## 5. `_dispatch_agent` override (`modernization.py:407-480`)
Signature: `async _dispatch_agent(app_id, step_name, skill_id, input_artifacts, source_repo="", workspace_key="") -> AgentTaskResult`. Differs from base: explicit `skill_id` (not resolved from `STEPS`), and `source_repo` (legacy tree read access) instead of `artifact_repo`/`artifact_ref`.

Control flow:
1. `context = {}` (`:433`).
2. `gate_key = _rework_gate_key_for_step(step_name)`; `if gate_key is not None: fb = _rework_feedback.get(gate_key); if fb is not None: context["rework_feedback"] = fb` (`:434-438`).
3. `if self._received_patterns: context["governance_patterns"] = list(self._received_patterns)` (`:443-444`).
4. `if self._devsecops_params: context["devsecops_baseline"] = dict(self._devsecops_params)` (`:449-450`).
5. Build `AgentTaskInput(task_type=f"modernization-{step_name}", app_id, skill_id, input_artifacts, source_repo, workspace_key, context, execution_context=self._execution_ctx(step_name, app_id=app_id, input_artifact_paths=input_artifacts))` (`:451-464`).
6. `result = await workflow.execute_activity(dispatch_agent_task, task_input, start_to_close_timeout=AGENT_START_TO_CLOSE (3h), retry_policy=RETRY_POLICIES["agent_failure"] (3 attempts, 5s→60s exp backoff, coeff 2.0), activity_id=f"agent-{step_name}")` (`:465-471`).
7. Records `_agent_metadata[step_name] = {model_used, duration_ms, token_usage_input, token_usage_output, cost_estimate_usd, output_files}` (`:472-479`).
8. `return result`.

**GOTCHA:** `activity_id=f"agent-{step_name}"` is derived from `step_name` alone — reworks re-dispatch the same `step_name` under the same activity_id in a new workflow-task attempt, which is fine because each iteration is a fresh command; but two different phases must never share a `step_name`.

---

## 6. `_build_evidence_data` override (`modernization.py:486-624`)
Overrides base (which iterates `STEPS`). Builds phase-keyed evidence. Arg `step` ∈ {`"extract"`,`"design"`,`"generate"`}.

Branch selection:
- **`step == "extract"`** (`:509-541`): `step_titles` maps extraction/cross-validation/requirement-aggregation/business-rule-reconciliation. `candidate_extract_steps = [extraction, cross-validation, requirement-aggregation, business-rule-reconciliation]`. `steps_iter` = those where `s in {extraction, cross-validation}` OR `s in self._extract_results` (so reconciliation steps only appear when the patch ran). `factory_step="Extract"`, `results_src=self._extract_results`.
- **`step == "design"`** (`:542-571`): titles for module-design/api-specification/data-modeling/batch-design/traceability-audit/design-review. `candidate_steps=[module-design, api-specification, data-modeling, batch-design, traceability-audit, design-review]`. `steps_iter` = those where `s in self._design_results OR s == "design-review"`. `factory_step="Design"`, `results_src=self._design_results`.
- **`else` (generate)** (`:572-584`): titles synthesis/adversarial-review/gate-review-package. `steps_iter=("synthesis","adversarial-review","gate-review-package")`. `factory_step="Generate"`, `results_src={}` (generate results not phase-step-keyed).

Then for each `step_name` in `steps_iter` (`:586-616`):
- `artifacts = results_src.get(step_name, [])`; `metadata = self._agent_metadata.get(step_name, {})`; `output_files = metadata.get("output_files", [])`.
- For each `f` in output_files: `if not isinstance(f, OutputFile): continue`; build entry `{path, encoding, size=len(content.encode utf-8) if str else 0}`; `if include_content OR (content_paths is not None AND f.path in content_paths): entry["content"]=f.content`; append.
- Dedup by path: `list({f["path"]: f for f in raw}.values())` (`:606-608`) — **last-writer-wins on duplicate paths**.
- `steps[step_name] = {title=step_titles.get(step_name, step_name), output=artifacts[0] if artifacts else "", metadata={k:v for k,v in metadata if k!="output_files"}, file_artifacts=deduped}`.

Return `{assembly_line, factory_step, app_id, current_step=step, steps}` (`:618-624`).

**GOTCHA:** slim-by-default (no `content`) unless `include_content` or path in `content_paths` — matches base contract; `_submit_gate_evidence` (base) passes the threshold-artifact paths for G-04b (`design-review.json`) via `content_paths`.

---

## 7. `run` entry point (`modernization.py:630-668`)
`@workflow.run async def run(self, input: LineWorkflowInput) -> str`.
```
self._status = RUNNING; self._started_at = _now_iso(); self._updated_at = started_at
self._app_id = input.app_id; self._portfolio_id = input.portfolio_id; self._wave_id = input.wave_id
self._input = input
self._risk_tier = int(input.risk_tier) if input.risk_tier is not None else None
try:
    return await self._execute_modernization(input)
except Exception:
    self._status = FAILED
    self._current_step = "failed"
    self._updated_at = _now_iso()
    try:
        await self._update_app_status(input.app_id, "modernization_failed", "failed", "Modernization")
    except Exception:
        pass          # swallow status-update failure
    raise             # re-raise original
```
**GOTCHA:** the inner `except Exception: pass` around `_update_app_status` (`:666-667`) ensures a failing status projection never masks the original error — the real exception is always re-raised (`:668`).

---

## 8. `_execute_modernization` (`modernization.py:670-731`)
```
app_id = input.app_id
self._artifact_repo = input.artifact_repo
repo = getattr(input, "target_repo_url", "") or input.artifact_repo   # commits land in target app repo; fallback to artifact_repo
source_repo = input.source_repo
wf_id = workflow.info().workflow_id
run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]
workspace_key = f"modernization-{app_id}-{run_suffix}"
await self._seed_patterns_from_registry(input.portfolio_id)      # F5 cold-start (Part 3)
await self._load_delegation_config(input.portfolio_id)           # base: sets _profile_id + _portfolio_fallback_policy
await self._update_app_status(app_id, "modernization_in_progress", "extract", "Modernization")

# Step 1 Extract
extract_result = await self._execute_extract(input, app_id, repo, source_repo, run_suffix, workspace_key)
if extract_result != "approved": return extract_result      # early-return "failed"/"cancelled"

# Step 2 Design
design_result = await self._execute_design(...)
if design_result != "approved": return design_result

# Step 3 Generate
generate_result = await self._execute_generate(...)
if generate_result != "approved": return generate_result

await self._update_app_status(app_id, "modernization_complete", "completed", "Modernization")
self._status = COMPLETED; self._progress_pct = 100.0; self._current_step = "completed"; self._updated_at = _now_iso()
return "completed"
```
**GOTCHA:** each step returns a string; only `"approved"` continues. Any other value (`"failed"`/`"cancelled"`) short-circuits `_execute_modernization` and is returned verbatim as the workflow result. `repo` = target-app repo (from `target_repo_url`), NOT the portfolio `artifact_repo`, when populated (`:679`).

---

## 9. Extract Step — `_execute_extract` (`modernization.py:737-1001`)
Returns `"approved"` / `"failed"` / `"cancelled"`. Branch: `f"olympus/modernization/extract/{app_id}/{run_suffix}"` (`:751`). Wrapped in `while True:` (rework loop) (`:753`).

### 9.1 Variant selection (`:761-767`)
`skill_id = select_skill(EXTRACTION_COMPOSITION, extraction_selector_inputs(input.prior_artifacts)) or "extraction"`. Registry-driven (W5); `None` defends to `"extraction"`.

### 9.2 Extraction dispatch (`:777-792`)
- `business_logic_path = f"discovery/{app_id}/business-logic.json"`; `extract_inputs = list(input.prior_artifacts)`; `if business_logic_path not in extract_inputs: extract_inputs.insert(0, business_logic_path)` (prepend, dedup-safe) (`:777-780`).
- `await self._set_step("extract", 0.0)` (`:781`).
- `extraction_result = await _dispatch_agent(app_id, step_name="extraction", skill_id=skill_id, input_artifacts=extract_inputs, source_repo, workspace_key)` (`:782-789`).
- `self._extract_results["extraction"] = extraction_result.output_artifacts` (`:790-792`).

### 9.3 Cross-validation dispatch (`:794-808`)
- `_set_step("cross-validation", STEP_WEIGHTS["extract"])` → progress 15.0 (`:795-797`).
- `cross_val_result = _dispatch_agent(step_name="cross-validation", skill_id="cross-validation", input_artifacts=extraction_result.output_artifacts, ...)` (`:798-805`).
- `self._extract_results["cross-validation"] = cross_val_result.output_artifacts` (`:806-808`).

### 9.4 Business Rule Reconciliation — patch-gated (`:810-861`)
`reconciliation_ran = False`; `if workflow.patched("br-reconciliation-v1"):` (`:824-825`):
- `req_agg_result = _dispatch_agent(step_name="requirement-aggregation", skill_id="requirement-aggregation", input_artifacts=extraction_result.output_artifacts, ...)`; store to `_extract_results["requirement-aggregation"]` (`:830-840`).
- `reconcile_inputs = list(extraction_result.output_artifacts) + list(req_agg_result.output_artifacts)` (`:847-849`).
- `reconcile_result = _dispatch_agent(step_name="business-rule-reconciliation", skill_id="business-rule-reconciliation", input_artifacts=reconcile_inputs, ...)`; store to `_extract_results["business-rule-reconciliation"]` (`:850-860`).
- `reconciliation_ran = True` (`:861`).
**GOTCHA:** these two dispatches run only under the `br-reconciliation-v1` patch; in-flight pre-patch runs skip them deterministically on replay. No `_set_step` between them — progress stays at 15.0 (their weights are 0.0).

### 9.5 Commit + PR (`:863-889`)
- `_set_step("extract-commit", STEP_WEIGHTS["extract"] + STEP_WEIGHTS["cross-validation"])` → 20.0 (`:864-867`).
- `artifact_paths = await _commit_extract_artifacts(repo, branch, app_id)` (Part 3) (`:868-870`).
- `pr_result = await _create_extract_pr(repo, branch, app_id, skill_id, reconciliation_ran)` (Part 3) (`:873-875`).
- `gate_record = await workflow.execute_activity(create_gate_record, CreateGateRecordInput(gate_type="G-04a", app_id, portfolio_id, workflow_id, evidence_package_url=pr_result.pr_url), start_to_close_timeout=30s, retry_policy=transient)` (`:878-889`).

### 9.6 Evidence + pre-review (`:891-925`)
- `await _submit_gate_evidence(gate_id=gate_record.gate_id, gate_type=GateType.G_04A, app_id, artifact_paths, pr_url=pr_result.pr_url, assembly_line="Modernization", step="extract")` (base helper: runs `check_gate_criteria` + `submit_gate_evidence`) (`:892-900`).
- `if workflow.patched("modernization-gate-pre-review-v1"): await _run_gate_pre_review(gate_record.gate_id, "G-04a", artifact_paths, artifact_repo=repo, artifact_ref=branch)` (`:909-916`) `else: await _mark_ready_for_review(gate_record.gate_id)` (`:917-918`). **GOTCHA:** patch-guarded so pre-patch runs stay deterministic. `_run_gate_pre_review` itself flips ready-for-review in its `finally` (base `:1094-1101`, under `mark-gate-ready-for-review-v1`).
- `await _update_app_status(app_id, "gate_review", "extract-gate-review", "Modernization")` (`:920-925`).

### 9.7 Gate wait + routing (`:927-1001`)
- `_set_step("extract-gate", 15.0+5.0+2.5=22.5)` (`:928-933`).
- `decision = await _wait_for_gate_decision(GateType.G_04A)` (base; returns approved/rejected/cancelled) (`:934`).
- **`if decision == "cancelled": return "cancelled"`** (`:936-937`).
- **`if decision == "approved":`** (`:939-981`):
  - **Tier-1 SME sub-wait:** `if self._risk_tier == 1:` → `await workflow.wait_condition(lambda: self._g04a_stakeholder_sme_approved or self.cancelled)` (`:945-951`); `if self.cancelled: self._status = CANCELLED; return "cancelled"` (`:952-954`). Tier-2/3 skip this (SME participation is review-level, non-blocking).
  - Post-G-04a projection: `cross_val_refs = self._extract_results.get("cross-validation", [])`; `extraction_ref = cross_val_refs[0] if cross_val_refs else ""`; `report_file = self._find_output_file_content("cross-validation")`; `await self._persist_side_effects(app_id, "extract", extraction_report_json=report_file, extraction_ref=extraction_ref)` (`:956-972`).
  - `await self._reconcile_and_merge_with_retry_loop(repo=repo, pr_number=pr_result.pr_number, gate_id=gate_record.gate_id, merge_method="merge")` (`:974-980`). **GOTCHA:** G-04a explicitly passes `merge_method="merge"`; Design/Generate use the default (`"merge"` too, but they omit the arg).
  - `return "approved"` (`:981`).
- **Rejected → rework** (`:983-998`):
  - `self._g04a_stakeholder_sme_approved = False` (reset so prior approval doesn't leak) (`:985`).
  - `self._bump_rework("G-04a")` (`:987`).
  - `if self._rework_count("G-04a") > MAX_REWORK_ITERATIONS (3):` → `_status=FAILED; _current_step="extract-max-rework-exceeded"; _updated_at; await _update_app_status(app_id, "modernization_failed", "extract-max-rework-exceeded", "Modernization"); return "failed"` (`:988-998`).
  - Otherwise falls off the bottom of the loop body → `while True` re-iterates (re-extract) (`:999-1000`).

---

*(Continued in ModernizationWorkflow-part2.md: Design step, Generate step, Tier-1 G-04c triple-signal, DevSecOps validator gating, BC fan-out.)*
