# DependencySweepWorkflow — Atomic Regeneration Spec

**Source:** `temporal/olympus_workflows/workflows/dependency_sweep.py` (192 lines)
**Class:** `DependencySweepWorkflow` (decorated `@workflow.defn` at `dependency_sweep.py:102`)
**Run entry:** `async def run(self, sweep_input: DependencySweepInput) -> dict[str, int]` (`dependency_sweep.py:112-173`)
**Feature:** P9-S17.2 — first autonomy-gated continuous-loop *executor*. Patch-only dependency-update proposals routed THROUGH the autonomy gate.

> BEHAVIORAL PARITY BAR: rebuild so run() produces byte-identical summary dicts for identical inputs, routes every proposal through the exact same gate call with the exact same argument mapping, and buckets outcomes with the identical three-way if/elif/else.

---

## 0. Architectural shape — read this first

Unlike most Olympus workflows, `DependencySweepWorkflow`:

- **Does NOT subclass `BaseWorkflow`.** It is decorated directly with `@workflow.defn` (`dependency_sweep.py:102`) and defines only `run`. There is NO inherited state, NO inherited signal/query handlers, NO gate-review scaffolding from `base.py`. Do NOT import inherited behavior from `_base-workflow.md` for this class — it has none. (Contrast: `BundleReaperWorkflow`, which the docstring says it "mirrors", is likewise a tiny cron body.)
- **Has NO instance state** — no `__init__`, no instance variables (see §1).
- **Has NO signals and NO queries** — "no inter-run state, no signal handlers" (`dependency_sweep.py:107`). See §2.
- **Has NO gate wait, NO rework loop, NO continue-as-new, NO heartbeats, NO compensation.** The "gate" here is the *autonomy* advisory gate, evaluated synchronously inside an activity per proposal — NOT a Temporal signal-based human-approval gate. See §5.
- **Performs no git mutation and creates no real PR** (`dependency_sweep.py:18-19`, `activities/dependency_sweep.py:16-19`). It is a **governance / proposal layer**. Its only output is a summary dict for operator visibility.
- Is designed to run on a **weekly Temporal cron** (`0 6 * * 1`, Monday 06:00) scheduled **out-of-band** via the Temporal Schedules API (`dependency_sweep.py:32-42`, `104-109`). The workflow itself contains NO scheduling logic.

GOTCHA (determinism): the workflow "reads no clock / env / DB" (`dependency_sweep.py:44-47`). ALL decision + clock logic lives in the two activities. `scan_outdated_dependencies` triages; `evaluate_autonomy` (via `gate_dependency_proposal`) captures the timestamp and resolves the tier cap. A rebuild that reads `os.environ`, `datetime.now`, or a DB inside `run()` breaks Temporal determinism and is WRONG.

---

## 1. STATE

**There are NO instance variables.** The class defines no `__init__` and no attributes; `run` is the only method (`dependency_sweep.py:102-173`). Each cron run is fully independent — "Each run is independent (no inter-run state...)" (`dependency_sweep.py:106-107`).

### Local variables inside `run()` (not persisted across runs)

| Name | Type | Initial | Mutated when | Cite |
|---|---|---|---|---|
| `requested_level` | `str` | `LOOP_PATTERN_REGISTRY.get("dependency-sweep").default_autonomy_level` → `"assisted"` | never (read once) | `dependency_sweep.py:124-127`; value from `loop_pattern.py:139-149` |
| `paths` | `tuple[str, ...]` | `tuple(sweep_input.manifest_paths or ())` | never after init | `dependency_sweep.py:128` |
| `entries` | `list[DependencyEntry]` | `_entries_from_dicts(sweep_input.manifest)` | never after init | `dependency_sweep.py:129` |
| `scan` | `ScanOutdatedResult` | result of `scan_outdated_dependencies` activity | never after init | `dependency_sweep.py:131-136` |
| `proposed` | `int` | `0` | `+= 1` in else-branch of the per-proposal loop | `dependency_sweep.py:138`, `166` |
| `gated_report_only` | `int` | `0` | `+= 1` when `permitted_level == "report_only"` | `dependency_sweep.py:139`, `163` |
| `escalated` | `int` | `0` | `+= 1` when `outcome.escalate` is True | `dependency_sweep.py:140`, `160` |

### Input dataclass `DependencySweepInput` (`dependency_sweep.py:77-99`)

Single positional payload (idiomatic Temporal shape). NOT a frozen `olympus_contracts` member (`dependency_sweep.py:88-89`).

| Field | Type | Default | Meaning | Cite |
|---|---|---|---|---|
| `loop_id` | `str` | (required) | loop identity, forwarded to the gate | `dependency_sweep.py:92` |
| `application_id` | `str` | (required) | touched app identity, forwarded to the gate | `dependency_sweep.py:93` |
| `risk_tier` | `str \| int \| None` | (required) | the tier the gate caps `assisted` down to | `dependency_sweep.py:94` |
| `manifest` | `list[dict[str, str]]` | `field(default_factory=list)` | synthetic dependency manifest of `{name,current,latest,kind}` dicts | `dependency_sweep.py:95` |
| `manifest_paths` | `tuple[str, ...]` | `()` | file(s) an upgrade would touch → gate's denylist-matched `paths` | `dependency_sweep.py:96` |
| `profile_id` | `str \| None` | `None` | selects profile autonomy-policy DATA | `dependency_sweep.py:97` |
| `portfolio_id` | `str \| None` | `None` | evidence scope (only used if evidence flag on) | `dependency_sweep.py:98` |
| `policy_override` | `AutonomyPolicy \| None` | `None` | inject a policy directly to pin tiers/denylist deterministically; else gate loads from DATA | `dependency_sweep.py:99`, `86-88` |

Module constant: `_PATTERN_NAME = "dependency-sweep"` (`dependency_sweep.py:74`).

---

## 2. SIGNALS & QUERIES

**NONE.** There are zero `@workflow.signal` and zero `@workflow.query` handlers in this file (confirmed: no such decorators appear; `dependency_sweep.py:106-107` states "no signal handlers"). There is therefore:

- no signal payload to buffer,
- no `workflow.wait_condition` call anywhere in `run()`,
- no query state to expose.

A rebuild MUST NOT add signal/query handlers — the parity contract is that this workflow is fire-and-return with a single `execute_activity` fan of sequential calls.

(There is no "handler that must not be overridden by subclasses" concern because the class is not designed to be subclassed and defines no handlers.)

---

## 3. CONTROL FLOW — `run()` as structured pseudocode

Preserves every statement, the single loop, and the three-way branch. Source `dependency_sweep.py:112-173`.

```
async def run(sweep_input: DependencySweepInput) -> dict[str, int]:

    # (A) Resolve the REQUESTED rung from the loop-pattern catalog.        [124-127]
    #     LOOP_PATTERN_REGISTRY.get("dependency-sweep").default_autonomy_level
    #     For the registered pattern this is exactly "assisted".            [loop_pattern.py:141-142]
    #     GOTCHA: .get() raises UnknownLoopPatternError (subclass of
    #     EntityNotFound) if the pattern name is absent. It never is at
    #     runtime (registered at import, loop_pattern.py:228-229), but a
    #     rebuild that drops the registry entry will raise here, NOT default.
    requested_level = LOOP_PATTERN_REGISTRY.get("dependency-sweep").default_autonomy_level

    # (B) Normalise inputs.                                                 [128-129]
    paths   = tuple(sweep_input.manifest_paths or ())   # () if falsy/empty
    entries = _entries_from_dicts(sweep_input.manifest) # dict -> DependencyEntry list

    # (C) ONE triage activity call (sequential; awaited).                   [131-136]
    scan = await execute_activity(
        scan_outdated_dependencies,
        ScanOutdatedInput(manifest=entries, manifest_paths=paths),
        start_to_close_timeout = 2 minutes,
        retry_policy           = RETRY_POLICIES["transient"],   # HTTP_RETRY_POLICY
    )
    # scan: ScanOutdatedResult(proposals: list[UpgradeProposal],
    #                          skipped_non_patch: int, up_to_date: int)

    # (D) Init tallies.                                                     [138-140]
    proposed = 0
    gated_report_only = 0
    escalated = 0

    # (E) Route EACH proposal through the autonomy gate, sequentially.      [142-166]
    #     GOTCHA: this is a serial for-loop of awaited activity calls — NOT
    #     asyncio.gather. Proposals are gated one at a time, in scan order.
    #     Determinism is preserved because iteration order == proposals list
    #     order == manifest order (triage appends in manifest order,
    #     activities/dependency_sweep.py:170-184).
    for proposal in scan.proposals:

        outcome = await execute_activity(                                 # [143-157]
            gate_dependency_proposal,
            GateProposalInput(
                loop_id         = sweep_input.loop_id,
                application_id  = sweep_input.application_id,
                requested_level = requested_level,          # "assisted"
                risk_tier       = sweep_input.risk_tier,
                paths           = tuple(proposal.paths),     # per-proposal paths
                profile_id      = sweep_input.profile_id,
                portfolio_id    = sweep_input.portfolio_id,
                policy_override = sweep_input.policy_override,
            ),
            start_to_close_timeout = 1 minute,
            retry_policy           = RETRY_POLICIES["transient"],
        )
        # outcome: GatedProposalOutcome(permitted_level, escalate, reason,
        #                               requested_level, risk_tier)

        # THREE-WAY BUCKETING — order matters; escalate wins.              [158-166]
        if outcome.escalate:                                              # [158-160]
            # Denylist hit / attempt cap -> human, regardless of tier.
            escalated += 1
        elif outcome.permitted_level == "report_only":                   # [161-163]
            # Tier cap forced propose-only (no PR).
            gated_report_only += 1
        else:                                                             # [164-166]
            # "assisted" / "unattended" permitted -> would open a PR-proposal.
            proposed += 1

    # (F) Return the operator-visibility summary.                          [168-173]
    return {
        "proposed":           proposed,
        "gated_report_only":  gated_report_only,
        "escalated":          escalated,
        "skipped_non_patch":  scan.skipped_non_patch,   # straight from triage
    }
```

### Branch-case table for the three-way bucket (`dependency_sweep.py:158-166`)

Every gate outcome lands in exactly one bucket. Precedence: **escalate first, then report_only, then else**.

| Condition (evaluated in order) | Bucket incremented | Meaning | Cite |
|---|---|---|---|
| `outcome.escalate is True` | `escalated` | denylist match OR attempt-cap blown; routes to human regardless of tier | `dependency_sweep.py:158-160` |
| not escalate AND `permitted_level == "report_only"` | `gated_report_only` | tier cap forced down to propose-only; no PR | `dependency_sweep.py:161-163` |
| not escalate AND `permitted_level` in {`"assisted"`,`"unattended"`} (anything not `report_only`) | `proposed` | gate permitted a PR-proposal | `dependency_sweep.py:164-166` |

GOTCHA (else is a catch-all): the `else` branch (`proposed`) fires for ANY non-empty `permitted_level` other than `"report_only"` when `escalate` is False. Given the gate's ladder that is `assisted` or `unattended`. But note: `evaluate_autonomy` never returns an escalating decision with a non-`report_only` level (escalation pins `permitted_level = "report_only"`, `autonomy.py:294-303`, `308-317`), so the `escalate` check and the `report_only` check never conflict destructively; escalate is checked first anyway.

GOTCHA (empty proposals): if `scan.proposals` is empty (e.g. all deps up-to-date, or all minor/major), the loop body never runs; `proposed=gated_report_only=escalated=0` and only `skipped_non_patch` may be non-zero. No gate activity is scheduled at all.

### Helper `_entries_from_dicts` (`dependency_sweep.py:176-192`)

Pure, workflow-safe (no IO). Coerces each manifest dict → `DependencyEntry`, tolerating missing keys:

```
_entries_from_dicts(manifest: list[dict[str,str]]) -> list[DependencyEntry]:
    return [
        DependencyEntry(
            name    = str(m.get("name",    "")),
            current = str(m.get("current", "")),
            latest  = str(m.get("latest",  "")),
            kind    = str(m.get("kind",    "")),
        )
        for m in manifest
    ]
```

GOTCHA: missing keys become empty strings. An entry with `current == latest == ""` is treated as up-to-date by the triage (no proposal); an empty/unknown `kind` on an outdated dep is treated conservatively as up-to-date (no proposal — never a silent non-patch bump). See §4 triage.

---

## 4. ACTIVITY CALLS (in order)

No child workflows. Two activity types, called sequentially (never `asyncio.gather`). Both decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))` — start/complete/fail logging + error wrapping (raw exceptions → `RetryableError`/`NonRetryableError` by type-name heuristic; `temporal_base/activities.py:79-150`).

### Call 1 — `scan_outdated_dependencies` (`dependency_sweep.py:131-136`)

| Property | Value | Cite |
|---|---|---|
| Argument | `ScanOutdatedInput(manifest=entries, manifest_paths=paths)` | `dependency_sweep.py:132-133` |
| `start_to_close_timeout` | `timedelta(minutes=2)` | `dependency_sweep.py:134` |
| `retry_policy` | `RETRY_POLICIES["transient"]` = `HTTP_RETRY_POLICY` = initial 1s, max 15s, backoff 2.0, **max_attempts 3** | `dependency_sweep.py:135`; `retry_policies.py:34`, `temporal_base/retry_policies.py:35-40` |
| `non_retryable_errors` | none declared on the call; transient policy sets none | `retry_policies.py:34` |
| heartbeat_timeout | none | — |
| Sequential/parallel | sequential (awaited before the loop) | `dependency_sweep.py:131` |
| Returns | `ScanOutdatedResult(proposals, skipped_non_patch, up_to_date)` | `activities/dependency_sweep.py:126-145` |

**Activity body** = thin wrapper over pure `triage_manifest(payload.manifest, tuple(payload.manifest_paths))` (`activities/dependency_sweep.py:200-212`). Triage logic (`activities/dependency_sweep.py:148-197`), per entry, in manifest order:

```
proposals = []; skipped_non_patch = 0; up_to_date = 0
for dep in manifest:
    if dep.current == dep.latest:            # up to date
        up_to_date += 1;  continue
    kind = (dep.kind or "").strip().lower()
    if kind == "patch":                       # PATCH_KIND
        proposals.append(UpgradeProposal(
            name=dep.name, current=dep.current, latest=dep.latest,
            kind="patch", paths=manifest_paths))   # paths echoed onto proposal
    elif kind in {"minor","major"}:           # NON_PATCH_KINDS
        skipped_non_patch += 1                # surfaced, NEVER proposed
    else:                                     # unknown kind on outdated dep
        up_to_date += 1                       # fail-conservative: NOT proposed
return ScanOutdatedResult(proposals, skipped_non_patch, up_to_date)
```

Cases (`activities/dependency_sweep.py:171-191`):

| Entry condition | Effect | Cite |
|---|---|---|
| `current == latest` | `up_to_date += 1`, no proposal | `:171-173` |
| outdated AND `kind.strip().lower() == "patch"` | one `UpgradeProposal` (with `paths = manifest_paths`) | `:175-184` |
| outdated AND kind ∈ {`minor`,`major`} | `skipped_non_patch += 1`, NO proposal | `:185-187` |
| outdated AND unknown/empty kind | `up_to_date += 1` (fail-conservative), NO proposal | `:188-191` |

GOTCHA (patch enforced in the ACTIVITY, not the workflow): "Patch is enforced HERE, in the triage logic — the workflow never re-derives it." (`activities/dependency_sweep.py:14`). The proposal set can NEVER contain a non-patch upgrade regardless of caller. A rebuild must NOT move this filter into `run()`.

GOTCHA (kind normalised): `kind` is `.strip().lower()`-ed (`:174`); `" PATCH "` counts as patch. Empty string routes to the conservative else (up_to_date), not skipped_non_patch.

GOTCHA (paths on proposal): every patch proposal carries `paths = manifest_paths` (the whole tuple passed to the scan), so per-proposal `proposal.paths` equals the sweep's `manifest_paths` for all proposals in a run (`:183`). The workflow re-tuples it (`tuple(proposal.paths)`) before feeding the gate (`dependency_sweep.py:151`).

### Call 2 (per proposal) — `gate_dependency_proposal` (`dependency_sweep.py:143-157`)

Called once **per element** of `scan.proposals`, sequentially.

| Property | Value | Cite |
|---|---|---|
| Argument | `GateProposalInput(loop_id, application_id, requested_level="assisted", risk_tier, paths=tuple(proposal.paths), profile_id, portfolio_id, policy_override)` | `dependency_sweep.py:144-154` |
| `start_to_close_timeout` | `timedelta(minutes=1)` | `dependency_sweep.py:155` |
| `retry_policy` | `RETRY_POLICIES["transient"]` (same HTTP policy, 3 attempts) | `dependency_sweep.py:156` |
| `non_retryable_errors` | none | — |
| Sequential/parallel | **sequential**, one per loop iteration (NOT gather) | `dependency_sweep.py:142-143` |
| Returns | `GatedProposalOutcome(permitted_level, escalate, reason, requested_level, risk_tier)` | `activities/dependency_sweep.py:244-262`, `298-304` |

**Activity body** (`activities/dependency_sweep.py:264-304`): lazily imports and calls the REAL `evaluate_autonomy` gate IN-PROCESS, then projects only the concrete scalar fields onto a boundary-serialisable `GatedProposalOutcome`:

```
async def gate_dependency_proposal(payload) -> GatedProposalOutcome:
    from olympus_workflows.activities.autonomy_eval import (
        EvaluateAutonomyInput, evaluate_autonomy)      # lazy import  [279-282]
    result = await evaluate_autonomy(EvaluateAutonomyInput(
        loop_id         = payload.loop_id,
        application_id  = payload.application_id,
        requested_level = payload.requested_level,     # "assisted"
        risk_tier       = payload.risk_tier,
        profile_id      = payload.profile_id,
        paths           = tuple(payload.paths),
        control_ids     = (),                          # ALWAYS empty here [292]
        policy_override = payload.policy_override,
        portfolio_id    = payload.portfolio_id,
    ))                                                              # [284-296]
    decision = result.decision
    return GatedProposalOutcome(
        permitted_level = decision.permitted_level,
        escalate        = decision.escalate,
        reason          = decision.reason,
        requested_level = decision.requested_level,
        risk_tier       = decision.risk_tier,
    )                                                               # [297-304]
```

GOTCHA (why the adapter exists — Temporal boundary): the workflow does NOT call `evaluate_autonomy` directly. `EvaluateAutonomyResult`'s nested `AutonomyDecision.metadata` is typed `dict[str, object]`, and Temporal's payload converter cannot round-trip a bare `object` value across the activity→workflow boundary (`activities/dependency_sweep.py:28-36`, `autonomy.py:254`). The adapter calls the gate in-process and returns only scalar fields so the verdict crosses cleanly while gate logic is unchanged/unduplicated. A rebuild that has `run()` call `evaluate_autonomy` directly and read `.decision.metadata` will FAIL to deserialize.

GOTCHA (`attempts` always 0): `gate_dependency_proposal` does NOT pass `attempts`; `EvaluateAutonomyInput.attempts` defaults to `0` (`autonomy_eval.py:188`). Therefore in this executor the **attempt-cap branch never fires** (`attempts >= cap` is `0 >= 3` → False; `autonomy.py:306-307`). Escalation from this workflow can only be a **denylist hit**, never an attempt cap. The docstring's "attempt cap" mention (`dependency_sweep.py:159`) is a general description of the gate; this executor never triggers it.

GOTCHA (`control_ids` empty): passed as `()` (`activities/dependency_sweep.py:292`). If the evidence flag is on, `_emit_evidence_for_decision` defaults them to `("CA-7",)` (`autonomy_eval.py:294`).

---

## 5. GATE HANDLING (autonomy advisory gate)

This workflow has **no Temporal signal-based human gate, no gate-review evidence assembly, no `wait_condition`, no approve/reject/merge-blocked/rework routing, and no rework counters.** The only "gate" is the **advisory `autonomy_level` gate** evaluated synchronously inside `gate_dependency_proposal` per proposal. There is no wait — the verdict returns immediately from the activity.

### How the verdict is produced (inside `evaluate_autonomy` → `resolve_autonomy_level`)

`evaluate_autonomy` (`autonomy_eval.py:213-262`):
1. `captured_at = datetime.now(timezone.utc)` — timestamp captured in the ACTIVITY (REQ-TEMP-001).
2. `policy = payload.policy_override or load_autonomy_policy(payload.profile_id)` — override wins; else layer `profiles/<id>/autonomy.yaml` over `registries/defaults/autonomy.yaml` (`autonomy_eval.py:141-157`, `227`). Missing/unparseable files → conservative default `AutonomyPolicy()` (fail-closed).
3. `decision = resolve_autonomy_level(requested_level, risk_tier, policy, paths, attempts)`.
4. Build a decision-log record (always) and, ONLY if `AUTONOMY_EVIDENCE_EMIT` truthy, lazily emit evidence.

`resolve_autonomy_level` decision order (`autonomy.py:264-330`) — **denylist beats tier beats attempt-cap ordering is: denylist (1) → attempt-cap (2) → per-tier cap (3)**:

```
tier_key = _normalise_tier_key(risk_tier) or "unknown"
tier_max = policy.tier_max(risk_tier)     # unknown tier -> policy.default_level (report_only)

# (1) DENYLIST — beats tier entirely (REQ-AG-003)                  [292-303]
if paths and policy.is_denylisted(paths):
    return AutonomyDecision(permitted_level="report_only",
        escalate=True, reason="denylist_match", denylisted=True, ...)

# (2) ATTEMPT CAP (REQ-AG-004)                                     [305-317]
cap = policy.attempt_cap if policy.attempt_cap > 0 else 3
if attempts >= cap:                       # attempts is ALWAYS 0 here -> never fires
    return AutonomyDecision(permitted_level="report_only",
        escalate=True, reason="attempt_cap_exceeded", attempt_capped=True, ...)

# (3) PER-TIER CAP (REQ-AG-002), fail-closed on unknown (REQ-AG-008) [319-330]
permitted = cap_level(requested_level, tier_max)   # min(requested, tier_max) on ladder
capped    = rank(permitted) < rank(requested_level)
return AutonomyDecision(permitted_level=permitted, escalate=False,
    reason="capped_to_tier" if capped else "within_tier_cap", ...)
```

`cap_level` (`autonomy.py:95-111`): ladder = `("report_only","assisted","unattended")`. Returns the LOWER rung. Bogus `tier_max` → `report_only` (fail-closed). Unknown `requested` → the cap.

### How each verdict routes back in `run()`'s bucketing

| Gate decision (from resolver) | `escalate` | `permitted_level` | run() bucket | Cite |
|---|---|---|---|---|
| denylist match | True | `report_only` | `escalated` (escalate checked first) | `autonomy.py:294-303`; `dependency_sweep.py:158-160` |
| tier caps `assisted`→`report_only` (e.g. tier_1 default) | False | `report_only` | `gated_report_only` | `autonomy.py:320-329`; `dependency_sweep.py:161-163` |
| within tier cap: `assisted` permitted | False | `assisted` | `proposed` | `dependency_sweep.py:164-166` |
| tier allows `unattended` (requested `assisted` ≤ cap) | False | `assisted` | `proposed` (never `unattended` — requested is only `assisted`) | `autonomy.py:111` |

GOTCHA (requested is always `assisted`): because `requested_level` comes from the pattern's `default_autonomy_level = "assisted"`, `cap_level("assisted", tier_max)` yields at most `assisted` — never `unattended` — so the `proposed` bucket here always corresponds to a permitted level of exactly `assisted`. The else-branch comment's "assisted / unattended" is the general gate contract; this executor only ever produces `assisted`.

### Evidence emission (only when `AUTONOMY_EVIDENCE_EMIT` on)

Default OFF → decision-log-only path imports NOTHING from the evidence layer (Task-8 independence). When on AND `portfolio_id` set, `_emit_evidence_for_decision` (`autonomy_eval.py:265-322`) lazily imports the P8.1 backbone and emits an `evidence_record`: `status = "non-compliant" if decision.escalate else "compliant"`, `control_ids or ("CA-7",)`, gate id `"autonomy_level"`. If `portfolio_id` absent OR backbone unimportable → clean skip `(False, None, True)`, gate never fails. NONE of this changes the `GatedProposalOutcome` scalars the workflow buckets on — the summary dict is identical whether or not evidence is emitted.

---

## 6. RESILIENCE

- **Timeouts:** scan `start_to_close=2min`; each gate `start_to_close=1min` (`dependency_sweep.py:134`,`155`). No schedule_to_close / schedule_to_start / heartbeat on either call.
- **Heartbeats:** NONE. Both activities are short synchronous computations.
- **Retries:** both calls use `RETRY_POLICIES["transient"]` = `HTTP_RETRY_POLICY` (max 3 attempts, 1s→15s exp backoff, coeff 2.0; `temporal_base/retry_policies.py:35-40`). No non-retryable error types.
- **Continue-as-new:** NONE. One run = one scan + N gate calls + return. Fresh workflow per cron fire (`dependency_sweep.py:104-109`). No unbounded history growth because manifest size bounds the loop.
- **Idempotency:** the workflow performs **no git mutation and creates no PR** (`dependency_sweep.py:18-19`) — a re-run for the same manifest simply recomputes the same summary. The gate records a decision-log entry per call (side effect inside the activity), but that is append-only telemetry, not mutation of the target. Re-running is safe.
- **Compensation / rollback:** NONE and not needed — nothing is mutated. This is why the executor is "a governance / proposal layer" (`dependency_sweep.py:18`).
- **Fail-closed (autonomy):** absent/unknown tier or missing/unparseable policy files resolve to `report_only`, never open (`autonomy.py:46-47`, `95-111`, `149-162`; `autonomy_eval.py:128-138`, `141-157`). A denylist hit forces escalation regardless of tier. The gate NEVER fails open.
- **Determinism:** `run()` touches no clock/env/DB; all nondeterministic work is inside activities (`dependency_sweep.py:44-47`). Imports are inside `workflow.unsafe.imports_passed_through()` (`dependency_sweep.py:58-68`) so the Temporal sandbox loads them unchanged.

GOTCHA (activity error wrapping affects retryability): if either activity raises a raw exception, `foundry_activity` wraps it: type-name matches (timeout/connection/network/…) → `RetryableError` (retried up to 3×); otherwise → `NonRetryableError` (fails immediately, propagates to fail the workflow) (`temporal_base/activities.py:56-76`, `133-144`). The triage is "pure + total — never raises" (`activities/dependency_sweep.py:164`), so in practice only the gate's policy-load/evidence path could raise, and even that is broadly caught (`autonomy_eval.py:124`, `291`).

---

## 7. GOTCHAs (consolidated)

1. **No base class / no inherited machinery** — `@workflow.defn` direct; do not attach `BaseWorkflow` state or gate scaffolding (`dependency_sweep.py:102`).
2. **No signals/queries/state** — nothing to buffer, no `wait_condition` (`dependency_sweep.py:106-107`).
3. **Patch-only filter lives in the ACTIVITY triage**, never re-derived by the workflow (`activities/dependency_sweep.py:14`, `175-191`).
4. **Sequential gate calls, not `asyncio.gather`** — one awaited `execute_activity` per proposal in manifest order (`dependency_sweep.py:142-157`).
5. **`attempts` always 0** → attempt-cap escalation branch is unreachable from this executor; escalation ⇒ denylist match only (`activities/dependency_sweep.py:284-296`; `autonomy.py:306-307`).
6. **Adapter-not-direct-call** — must go through `gate_dependency_proposal` because `AutonomyDecision.metadata: dict[str,object]` won't cross the Temporal boundary (`activities/dependency_sweep.py:28-36`).
7. **Bucketing precedence** — escalate → report_only → else; escalate always co-occurs with `permitted_level == report_only` but is checked first (`dependency_sweep.py:158-166`).
8. **`skipped_non_patch` bypasses the gate entirely** — it's a raw triage count copied straight into the summary; those deps never become proposals (`dependency_sweep.py:172`).
9. **`requested_level` from registry, not hardcoded** — reads `LOOP_PATTERN_REGISTRY.get("dependency-sweep").default_autonomy_level`; equals `"assisted"` only because the registered pattern says so (`dependency_sweep.py:124-127`; `loop_pattern.py:141-142`). Dropping the registry entry raises `UnknownLoopPatternError`.
10. **`policy_override` short-circuits DATA loading** in the gate (`autonomy_eval.py:227`); tests pin behavior deterministically via it.
11. **Empty manifest / all-up-to-date** → no gate calls, summary all zeros except possibly `skipped_non_patch`.
12. **Missing manifest dict keys → empty strings** (`_entries_from_dicts`), which triage treats as up-to-date/non-actionable (`dependency_sweep.py:184-191`).

---

## 8. Behavioral parity checklist

A rebuild MUST satisfy every assertion below.

1. **No state / no handlers.** The workflow class defines only `run`; it has no `__init__`, no instance attributes, no `@workflow.signal`, no `@workflow.query`, and no `workflow.wait_condition` call.
2. **Requested level source.** `run()` obtains `requested_level` from `LOOP_PATTERN_REGISTRY.get("dependency-sweep").default_autonomy_level` and passes it verbatim to every gate call; with the standard registry this is `"assisted"`.
3. **Scan call shape.** Exactly one `scan_outdated_dependencies` call, argument `ScanOutdatedInput(manifest=<coerced entries>, manifest_paths=<paths>)`, `start_to_close_timeout=2min`, `retry_policy=transient(3 attempts)`.
4. **Entry coercion.** `_entries_from_dicts` produces `DependencyEntry` with each field `str(m.get(key,""))`; missing keys → `""`.
5. **Triage patch-only.** Given manifest with kinds patch/minor/major/unknown and one up-to-date entry: `proposals` contains ONLY the outdated `patch` entries; `skipped_non_patch` counts minor+major; `up_to_date` counts equal-version entries + unknown-kind outdated entries; patch proposals carry `paths == manifest_paths`.
6. **Per-proposal gate call.** For each proposal, exactly one `gate_dependency_proposal` call with `requested_level="assisted"`, `paths=tuple(proposal.paths)`, and the sweep's `loop_id/application_id/risk_tier/profile_id/portfolio_id/policy_override`; `start_to_close_timeout=1min`, transient retry.
7. **Sequential, ordered.** Gate calls happen one at a time, in `scan.proposals` order — never concurrently.
8. **Escalate bucket.** A denylist-matching path (e.g. `manifest_paths` matches a policy `denylist` glob) yields `escalate=True, permitted_level="report_only"` → increments `escalated` (and NOT `gated_report_only`).
9. **Tier-cap bucket.** A tier whose cap is `report_only` (e.g. tier_1 under conservative defaults) with no denylist hit yields `escalate=False, permitted_level="report_only"` → increments `gated_report_only`.
10. **Proposed bucket.** A tier whose cap is `assisted`/`unattended` with no denylist hit yields `escalate=False, permitted_level="assisted"` → increments `proposed`.
11. **Fail-closed tier.** `risk_tier=None`/unknown with no override policy → `report_only` → `gated_report_only`.
12. **Summary dict.** Returns exactly `{"proposed", "gated_report_only", "escalated", "skipped_non_patch"}`; `skipped_non_patch` equals the triage count, unaffected by any gate outcome; `proposed+gated_report_only+escalated == len(scan.proposals)`.
13. **No mutation.** Running the workflow creates no branch/PR/commit and mutates no target repo; re-running with identical input yields an identical summary.
14. **Boundary safety.** The gate is invoked via `gate_dependency_proposal` returning scalar-only `GatedProposalOutcome`; the workflow never touches `AutonomyDecision.metadata`.
15. **attempts=0 invariant.** No path in this executor sets a non-zero `attempts`, so `reason=="attempt_cap_exceeded"` is never produced by a dependency-sweep run.
16. **Determinism.** `run()` reads no clock, env var, or DB; all such access is confined to the two activities.
17. **Empty proposals.** With no patch proposals, no `gate_dependency_proposal` call is scheduled and the three tally fields are 0.
