# ErrorTriageWorkflow — Atomic Regeneration Spec

Source of truth: `temporal/olympus_workflows/workflows/error_triage.py` (259 lines).
Supporting activity module (clustering + gate + digest live here, fully captured
below because a behavioral rebuild of the workflow is impossible without them):
`temporal/olympus_workflows/activities/error_triage.py` (917 lines).

**Feature:** P9-S17.6 — the `error-triage` nightly autonomy-gated sweep. One of
four autonomy executors (siblings: `ci_repair`, `cve_triage`, `dependency_sweep`).
Captures error signals from persistent structured sources, clusters them into
deduplicated incident candidates by deterministic fingerprint, and routes EACH
incident's remediation proposal through the existing `autonomy_level` gate. Records
only — opens no PR, mutates no code, runs no git.

---

## 0. Class shape & inheritance — CRITICAL, do not over-engineer

`ErrorTriageWorkflow` is a **plain** `@workflow.defn` class
(`error_triage.py:131-140`). It does **NOT** extend `LineWorkflowBase` /
`HILSignalsMixin` and inherits **none** of the base-workflow HIL/gate/signal
machinery. It has:

- **No `__init__`.** No instance state at all (`error_triage.py:132-140`).
- **No `@workflow.signal` handlers.** (grep the file: zero.)
- **No `@workflow.query` handlers.** (zero.)
- **No `wait_condition`, no `continue_as_new`, no heartbeats, no child workflows.**
- Exactly ONE method: `@workflow.run async def run(self, sweep) -> dict`
  (`error_triage.py:142-143`).

GOTCHA: Do NOT reference `_base-workflow.md` behavior for this class — it does not
inherit it. A rebuild that adds signal handlers or a gate-wait loop is WRONG. The
gate here is an *activity call per incident* (`gate_error_proposal`), not a
signal-driven HIL wait. Each cron run is fully independent: no inter-run state, no
durable timers, no signals (`error_triage.py:134-139`).

GOTCHA: Determinism. The workflow body reads no clock, no env, no DB
(`error_triage.py:46-50`). All clock/env/DB access is confined to the activities.
`cluster_signals` and `build_digest` are pure functions and are called directly in
workflow code — this is deterministic and intentional (`error_triage.py:185`,
`:241`). Activity imports are inside `workflow.unsafe.imports_passed_through()`
(`error_triage.py:65-81`).

Scheduling is **out-of-band** via the Temporal Schedules API (NOT in this code):
`workflow-type ErrorTriageWorkflow`, `task-queue olympus-main`, `cron "0 3 * * *"`
(`error_triage.py:37-44`). The cadence + requested rung come from
`LOOP_PATTERN_REGISTRY["error-triage"]` (`loop_pattern.py:205-219`):
`cadence="0 3 * * *"`, `default_autonomy_level="report_only"`.

---

## 1. STATE

**No instance variables.** The class holds zero mutable state
(`error_triage.py:132-140`). All working values are `run()`-local:

| Local (in `run`) | Type | Init | Mutated |
|---|---|---|---|
| `pattern_level` | `str` | `LOOP_PATTERN_REGISTRY.get("error-triage").default_autonomy_level` → `"report_only"` | never (`error_triage.py:155-157`) |
| `requested_level` | `str` | `sweep.fix_level if sweep.propose_fix_enabled else pattern_level` | never (`:166-168`) |
| `capture_result` | `CaptureResult` | awaited `capture_error_signals` activity result | never (`:170-183`) |
| `paths_for_service` | `dict[str, tuple[str,...]]` | comprehension over `sweep.paths_for_service or {}`, each value → `tuple(paths)` | never (`:186-188`) |
| `incidents` | `list[Incident]` | `cluster_signals(...)` | each `inc.triage_decision`/`inc.requested_level`/`inc.evidence_ref` folded from gate outcome in the loop (`:189-191`, `:220-222`) |
| `fix_proposals` | `list[FixProposal]` | `[]` | appended on `fix_proposal` decision (`:193`, `:229-237`) |
| `report_only` | `int` | `0` | `+= 1` on report-only (`:194`, `:239`) |
| `proposed` | `int` | `0` | `+= 1` on fix_proposal (`:195`, `:227`) |
| `escalated` | `int` | `0` | `+= 1` on escalate (`:196`, `:225`) |
| `outcome` | `GatedProposalOutcome` | awaited `gate_error_proposal` per incident | reassigned each loop iteration (`:199-217`) |
| `digest` | `TriageDigest` | `build_digest(...)` | never (`:241-245`) |

### Input dataclass — `ErrorTriageInput` (`error_triage.py:91-128`)

Single serialisable dataclass arg (idiomatic Temporal input). Fields:

| Field | Type | Default | Meaning |
|---|---|---|---|
| `loop_id` | `str` | required | loop identity → gate |
| `application_id` | `str` | required | touched app → gate |
| `risk_tier` | `str \| int \| None` | required | app tier the gate caps to (accepts `"tier_1"`/`1`/`"1"`, `autonomy_eval.py:171`) |
| `ai_work_log_rows` | `list[AiWorkLogRow]` | `[]` | source rows |
| `agent_run_rows` | `list[AgentRunErrorRow]` | `[]` | source rows |
| `event_outbox_rows` | `list[EventOutboxRow]` | `[]` | source rows |
| `prometheus_rows` | `list[PrometheusAlertRow]` | `[]` | OPTIONAL metrics rows |
| `watermarks` | `dict[str,str]` | `{}` | per-source cursor `{source: last_source_row_id}` |
| `metrics_endpoint` | `str \| None` | `None` | absent → Prometheus skipped |
| `paths_for_service` | `dict[str,list[str]]` | `{}` | service → touched paths (client-blind, gate denylist match) |
| `propose_fix_enabled` | `bool` | `False` | profile opt-in (default OFF / report-only) |
| `fix_level` | `str` | `"assisted"` | rung requested when opt-in ON |
| `known_fingerprints` | `tuple[str,...]` | `()` | incidents seen before this sweep (new-vs-recurring split) |
| `profile_id` | `str \| None` | `None` | stamps every signal + selects profile DATA at gate |
| `portfolio_id` | `str \| None` | `None` | → gate |
| `control_ids` | `tuple[str,...]` | `()` | continuous-monitoring controls → gate |
| `policy_override` | `AutonomyPolicy \| None` | `None` | test hook: pin tiers/denylist deterministically |

GOTCHA: source rows are concrete dataclasses (NOT `dict[str, object]`) precisely
because a row carries optional `None` fields Temporal's converter cannot decode as
bare `object` (`error_triage.py:96-99`). Same boundary reason the gate adapter
returns `GatedProposalOutcome` (scalars only) instead of `EvaluateAutonomyResult`
(`error_triage.py:96-101`, activities `:776-798`).

---

## 2. SIGNALS & QUERIES

**NONE.** This workflow defines no `@workflow.signal` and no `@workflow.query`
handlers (verified across `error_triage.py`). There is no HIL wait, no signal
buffer, no `wait_condition`. All routing is synchronous within `run()` via activity
calls. There is therefore no handler that "must not be overridden" — there are no
handlers and (being a plain class) no subclass contract.

---

## 3. CONTROL FLOW — `run()` (`error_triage.py:142-259`)

Structured pseudocode preserving every step; no branch collapsed.

```
async def run(sweep: ErrorTriageInput) -> dict:

    # (a) Resolve the pattern's requested rung — NO branch on the pattern itself.
    pattern_level = LOOP_PATTERN_REGISTRY.get("error-triage").default_autonomy_level
        # → "report_only" (loop_pattern.py:208)

    # (b) Decide the rung EACH incident requests at the gate.
    IF sweep.propose_fix_enabled:
        requested_level = sweep.fix_level        # e.g. "assisted"
    ELSE:
        requested_level = pattern_level          # "report_only" floor
    # NOTE: this only sets what is REQUESTED. Every incident still passes THROUGH
    # the gate; the tier cap / denylist governs the OUTCOME (error_triage.py:159-168).

    # (c) CAPTURE — single activity, sequential.
    capture_result = await execute_activity(
        capture_error_signals,
        CaptureInput(
            ai_work_log_rows = list(sweep.ai_work_log_rows),
            agent_run_rows   = list(sweep.agent_run_rows),
            event_outbox_rows= list(sweep.event_outbox_rows),
            prometheus_rows  = list(sweep.prometheus_rows),
            watermarks       = dict(sweep.watermarks or {}),
            metrics_endpoint = sweep.metrics_endpoint,
            profile_id       = sweep.profile_id,
        ),
        start_to_close_timeout = 2 minutes,
        retry_policy = RETRY_POLICIES["transient"],   # HTTP_RETRY: 1s→15s x2, 3 attempts
    )                                                  # error_triage.py:170-183

    # (d) CLUSTER — pure, in workflow code (deterministic).
    paths_for_service = { svc: tuple(paths)
                          for svc, paths in (sweep.paths_for_service or {}).items() }
    incidents = cluster_signals(capture_result.signals,
                                paths_for_service = paths_for_service)
        # sorted desc by occurrence_count, then fingerprint (error_triage.py:185-191)

    # (e) Init tallies.
    fix_proposals = []
    report_only = 0; proposed = 0; escalated = 0

    # (f) GATE EACH INCIDENT — sequential loop, one activity per incident.
    FOR inc IN incidents:                             # order = cluster_signals sort
        outcome = await execute_activity(
            gate_error_proposal,
            GateProposalInput(
                loop_id            = sweep.loop_id,
                application_id     = sweep.application_id,
                fingerprint        = inc.fingerprint,
                requested_level    = requested_level,   # from (b)
                risk_tier          = sweep.risk_tier,
                paths              = tuple(inc.paths),
                propose_fix_enabled= sweep.propose_fix_enabled,
                fix_level          = sweep.fix_level,
                profile_id         = sweep.profile_id,
                portfolio_id       = sweep.portfolio_id,
                control_ids        = tuple(sweep.control_ids),
                policy_override    = sweep.policy_override,
            ),
            start_to_close_timeout = 1 minute,
            retry_policy = RETRY_POLICIES["transient"],
        )                                             # error_triage.py:199-217

        # Fold verdict back onto the incident (what the digest/read surface record).
        inc.triage_decision = outcome.decision
        inc.requested_level = outcome.requested_level
        inc.evidence_ref    = outcome.evidence_ref     # error_triage.py:220-222

        # ROUTING — exactly three buckets, mutually exclusive:
        IF outcome.decision == "escalate":
            escalated += 1
        ELIF outcome.decision == "fix_proposal":
            proposed += 1
            fix_proposals.append(FixProposal(
                fingerprint      = inc.fingerprint,
                service          = inc.service,
                requested_level  = outcome.requested_level,
                permitted_level  = outcome.permitted_level,
                evidence_ref     = outcome.evidence_ref,
            ))                                          # RECORD-ONLY, no PR/mutation
        ELSE:                                           # "report_only" (or any other)
            report_only += 1
        # error_triage.py:224-239

    # (g) DIGEST — pure, in workflow code.
    digest = build_digest(incidents, fix_proposals,
                          known_fingerprints = tuple(sweep.known_fingerprints or ()))
        # error_triage.py:241-245

    # (h) RETURN summary dict.
    RETURN {
        "captured":            len(capture_result.signals),
        "deduped":             capture_result.skipped_duplicates,
        "incidents":           len(incidents),
        "report_only":         report_only,
        "proposed":            proposed,
        "escalated":           escalated,
        "new_incidents":       digest.new,
        "recurring_incidents": digest.recurring,
        "metrics_skipped":     capture_result.metrics_skipped,
        "new_watermarks":      dict(capture_result.new_watermarks),
        "digest":              digest.to_dict(),
    }                                                   # error_triage.py:247-259
```

Early returns: none. Try/except/finally: none. Loops: the single `for inc in
incidents` (no nested loops). If `incidents` is empty, the loop body never runs and
all tallies stay 0.

GOTCHA: the final `else` bucket (`:238-239`) catches `"report_only"` AND any
unrecognized decision string — it is the fail-safe report-only default. Only
`"escalate"` and `"fix_proposal"` are matched explicitly.

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS

No child workflows. Two activity types; all calls sequential (no `asyncio.gather`).

### 4.1 `capture_error_signals` — ONCE (`error_triage.py:170-183`)
- Arg: `CaptureInput(...)` (see pseudocode c).
- `start_to_close_timeout=timedelta(minutes=2)`.
- `retry_policy=RETRY_POLICIES["transient"]` = `TRANSIENT_RETRY_POLICY` =
  `HTTP_RETRY_POLICY` = `RetryPolicy(initial_interval=1s, maximum_interval=15s,
  maximum_attempts=3, backoff_coefficient=2.0)` (`retry_policies.py:34,111`;
  `temporal_base/retry_policies.py:35-40`).
- No `non_retryable_error_types`. No heartbeat.
- Decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`
  (`error_triage.py:727`).

### 4.2 `gate_error_proposal` — PER INCIDENT, sequential (`error_triage.py:199-217`)
- Arg: `GateProposalInput(...)` (see pseudocode f).
- `start_to_close_timeout=timedelta(minutes=1)`.
- Same `RETRY_POLICIES["transient"]` (3 attempts, 1s→15s backoff). No
  non_retryable_errors, no heartbeat.
- Decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`
  (`error_triage.py:829`).

GOTCHA: `@foundry_activity` (`temporal_base/activities.py:79-120`) wraps the body:
any raw exception is coerced to a Temporal `ApplicationError` with `non_retryable`
set by `_is_retryable_error` — a TYPE-NAME substring match against
`{timeout, connection, network, temporary, unavailable, overload, busy, throttle,
rate_limit}` (`activities.py:56-76`). A non-matching exception type wraps as
non-retryable and short-circuits the 3-attempt policy.

---

## 5. GATE HANDLING

There is no HIL signal gate. "Gate" = the per-incident `gate_error_proposal`
activity, which calls the real autonomy gate in-process.

### 5.1 `gate_error_proposal` internals (`error_triage.py:829-881`)
```
async def gate_error_proposal(payload) -> GatedProposalOutcome:
    # lazy import (keeps module import-light)
    from ...activities.autonomy_eval import EvaluateAutonomyInput, evaluate_autonomy
    result = await evaluate_autonomy(EvaluateAutonomyInput(
        loop_id, application_id, requested_level, risk_tier, profile_id,
        paths, control_ids, policy_override, portfolio_id))   # REAL gate, in-process
    decision = result.decision
    bucket = _bucket_decision(escalate=decision.escalate,
                              permitted_level=decision.permitted_level,
                              propose_fix_enabled=payload.propose_fix_enabled)
    evidence_ref = result.evidence_content_hash or f"decision-log:{result.recorded_at}"
    RETURN GatedProposalOutcome(
        fingerprint=payload.fingerprint, decision=bucket,
        permitted_level=decision.permitted_level,
        requested_level=decision.requested_level,
        escalate=decision.escalate, reason=decision.reason,
        risk_tier=decision.risk_tier, evidence_ref=evidence_ref)
```

GOTCHA: `evidence_ref` = the evidence content hash when
`AUTONOMY_EVIDENCE_EMIT` emitted one, ELSE the literal string
`f"decision-log:{result.recorded_at}"` (`error_triage.py:871`). Always non-empty.

GOTCHA: `gate_error_proposal` calls `evaluate_autonomy` *directly as a coroutine*
(not via `execute_activity`) — it runs in-process inside the activity. The proposal
still passes through the full gate (per-tier cap / denylist / attempt cap); only the
concrete scalar fields are surfaced across the activity→workflow boundary because
`EvaluateAutonomyResult.decision.metadata` is `dict[str, object]` and Temporal's
converter can't round-trip bare `object` (`error_triage.py:829-843`, activities
`:49-56`, `:776-798`).

### 5.2 `_bucket_decision` — the routing decision (`error_triage.py:800-826`)
```
def _bucket_decision(*, escalate, permitted_level, propose_fix_enabled) -> str:
    IF escalate:                       return "escalate"       # denylist hit / attempt cap; report-only remediation, tier-independent
    IF permitted_level == "report_only": return "report_only" # tier cap / low tier
    # gate permits assisted/unattended for this tier:
    IF propose_fix_enabled:            return "fix_proposal"   # RECORD-ONLY proposal
    return "report_only"                                       # fail-closed: opt-in OFF ⇒ no auto-propose (REQ-ET-011)
```
Case table:

| escalate | permitted_level | propose_fix_enabled | → decision |
|---|---|---|---|
| True | (any) | (any) | `escalate` |
| False | `report_only` | (any) | `report_only` |
| False | `assisted`/`unattended` | True | `fix_proposal` |
| False | `assisted`/`unattended` | False | `report_only` |

GOTCHA: a tier-capped OR denylist-path incident is report-only/escalate regardless
of `occurrence_count` — the gate decides, not frequency (`error_triage.py:16-23`,
activities `:33-38`). Occurrence count only affects sort order and the digest, never
the decision.

### 5.3 No rework loop / no counters
There is NO approve/reject/merge-blocked/rework routing and NO rework counter. Each
incident gets exactly one gate call, one decision, and is tallied once. The three
tallies (`report_only`, `proposed`, `escalated`) sum to `len(incidents)`.

---

## 6. RESILIENCE

- **Timeouts:** capture `start_to_close=2min`; gate `start_to_close=1min` per
  incident (`error_triage.py:181,215`). No schedule_to_close/start, no heartbeat.
- **Retries:** both use `transient` (3 attempts, exp backoff 1s→15s)
  (`retry_policies.py:34,111`).
- **Heartbeats:** none.
- **continue-as-new:** none. GOTCHA: an N-incident sweep issues N sequential gate
  activities plus 1 capture in a single workflow run — the history is bounded by the
  incident count. There is no continue-as-new guard, so a pathologically huge
  incident set would grow one workflow history unbounded. Nightly cadence + capture
  dedup keep this small in practice, but a rebuild must NOT add a spurious
  continue-as-new that would break the single-run summary contract.
- **Idempotency:** capture is idempotent on `(source, source_row_id)` — a row whose
  id `<= watermark` is skipped; the watermark advances to the MAX id seen
  (monotonic, lexicographic on the opaque id string) (activities `:471-500`). A
  re-run over the same rows yields ZERO new signals (activities `:729-737`). The
  workflow itself has no cross-run dedup (relies on capture).
- **Compensation/rollback:** NONE — the workflow performs no mutation (no git, no
  PR, no code change). A `fix_proposal` is a record-only INTENT for a downstream
  executor/human (`error_triage.py:26-33,228`; activities `:308-317`). Nothing to
  roll back.

---

## 7. CAPTURE + CLUSTER + DIGEST (activity internals the workflow depends on)

### 7.1 `capture` (`activities/error_triage.py:503-550`)
Runs three source normalizers inlined (NOT a loop over heterogeneous tuples — keeps
concrete row types, activities `:516-518`), each past its per-source watermark:
- `SOURCE_AI_WORK_LOG` = `"ai_work_log"`: keep iff
  `outcome.strip().lower() ∈ {"failed","timed_out"}`; else dropped. `error_class`
  falls back to `outcome`. (`:344-374`, `AI_WORK_LOG_ERROR_OUTCOMES` `:88`)
- `SOURCE_AGENT_RUN` = `"agent_run"`: keep all. (`:377-401`)
- `SOURCE_EVENT_OUTBOX` = `"event_outbox"`: keep iff `last_error.strip()` non-empty;
  `error_class = event_type or "delivery_error"`. (`:404-433`)
- `SOURCE_PROMETHEUS` = `"prometheus_alert"`: OPTIONAL. Captured ONLY when
  `payload.metrics_endpoint.strip()` is truthy; else `metrics_skipped=True` and
  Prometheus rows are ignored WITHOUT failing (`:533-543`). `source_row_id =
  row.fingerprint`; `error_class = alertname or "alert"`; `trace_id=None`.
  (`:436-465`)

`_normalize` shared core (`:471-500`): for each row, `rid = str(row_id(row))`; if
`watermark and rid <= watermark` → skip (`skipped += 1`); else advance
`advanced = max(advanced, rid)` (lexicographic); if `keep(row)` append signal. Never
raises. GOTCHA: watermark comparison is **lexicographic string** compare on the
opaque source id, not numeric — ids must be zero-padded/sortable for correct dedup.

`CaptureResult`: `signals`, `new_watermarks` (all four source keys set — Prometheus
only if not skipped), `skipped_duplicates` (sum across sources), `metrics_skipped`
(`:503-550`).

### 7.2 `normalize_message` + `fingerprint` + `cluster_signals`
- `normalize_message` (`:558-573`): applied before fingerprint. In order: sub uuid→
  `<uuid>`, hex `0x…`→`<hex>`, path `(?:/[\w.\-]+)+/?`→`<path>`, digits `\d+`→`<n>`,
  collapse whitespace, `.strip().lower()`. GOTCHA: ORDER matters — uuid before hex
  before path before number; e.g. a numeric run inside a path is consumed by
  `<path>` first.
- `fingerprint(service, error_class, message)` (`:580-594`):
  `sha256( "\x1f".join([service.strip().lower(), _normalize_class(error_class),
  normalize_message(message)]) ).hexdigest()[:32]`. Deterministic, no salt/clock —
  identical inputs → identical 32-char hex. `_normalize_class` = whitespace-collapse
  + strip + lower (`:576-577`).
- `cluster_signals(signals, paths_for_service)` (`:607-644`): group by fingerprint.
  First signal seeds `Incident(occurrence_count=1, first_seen=last_seen=occurred_at,
  paths=tuple(paths_for_service.get(sig.service, ())))`. Subsequent:
  `occurrence_count += 1`, `first_seen = min(...)`, `last_seen = max(...)` (ISO
  strings compare lexicographically; None-safe via `_min_ts`/`_max_ts` `:597-604`).
  Returns `sorted(by_fp.values(), key=lambda i: (-i.occurrence_count, i.fingerprint))`
  — descending count, then fingerprint ascending (stable, most-frequent first).
  GOTCHA: an unmapped service → empty `paths` → gate caps purely by tier.

### 7.3 `build_digest` (`:682-719`)
```
known = set(known_fingerprints)
digest = TriageDigest()
for inc in incidents:
    if inc.fingerprint in known: digest.recurring += 1
    else:                        digest.new += 1
    if   inc.triage_decision == "escalate":     digest.escalated += 1
    elif inc.triage_decision == "fix_proposal": digest.proposed  += 1
    else:                                        digest.report_only += 1
    digest.incidents.append({fingerprint, service, error_class, occurrence_count,
        "decision": inc.triage_decision, requested_level, evidence_ref,
        "new": inc.fingerprint not in known})
digest.fix_proposals = [p.to_dict() for p in fix_proposals]
```
GOTCHA: the digest's own decision tally (`escalated`/`proposed`/`report_only`) is
recomputed from `inc.triage_decision`, independent of the workflow's loop counters.
For a correct rebuild they must agree — the workflow returns BOTH its loop counters
(top-level `report_only`/`proposed`/`escalated`) and `digest.to_dict()`'s counters.

---

## 8. Behavioral parity checklist

A rebuild MUST satisfy every assertion:

1. Class is a plain `@workflow.defn` with a single `@workflow.run` method; NO
   `__init__`, NO signals, NO queries, NO instance state, NO child workflows.
2. `run` accepts one `ErrorTriageInput` dataclass and returns exactly the 11-key
   dict: `captured, deduped, incidents, report_only, proposed, escalated,
   new_incidents, recurring_incidents, metrics_skipped, new_watermarks, digest`.
3. `requested_level` = `sweep.fix_level` when `propose_fix_enabled` else the
   pattern's `report_only`. Every incident is gated with THIS requested rung.
4. Calls `capture_error_signals` exactly once (2-min STC, transient retry), then
   `cluster_signals` (pure, in workflow), then `gate_error_proposal` once per
   incident sequentially (1-min STC, transient retry), then `build_digest` (pure).
5. Gate routing buckets: `escalate` when `decision.escalate`; else `report_only`
   when `permitted_level=="report_only"`; else `fix_proposal` iff
   `propose_fix_enabled` True; else `report_only`. (Fail-closed on opt-in OFF.)
6. `report_only + proposed + escalated == len(incidents)`; a `FixProposal` is
   appended ONLY on `fix_proposal` decisions and carries fingerprint/service/
   requested_level/permitted_level/evidence_ref.
7. Per incident, `inc.triage_decision/requested_level/evidence_ref` are folded from
   the gate outcome before digest.
8. Capture is idempotent: a row with `id <= watermark` is skipped and counted in
   `deduped`; watermark advances to MAX id (lexicographic); a re-run over identical
   rows yields `captured==0`.
9. ai_work_log keeps only `failed`/`timed_out`; event_outbox keeps only non-empty
   `last_error`; agent_run + prometheus keep all; Prometheus captured ONLY when
   `metrics_endpoint` truthy, else `metrics_skipped==True` and no failure.
10. `fingerprint` = first 32 hex of `sha256` over `\x1f`-joined
    `[service.lower(), norm_class, norm_message]`; message normalization order is
    uuid→hex→path→number→whitespace→lower. Same inputs across runs → same
    fingerprint → same clustering.
11. Incidents sorted by `(-occurrence_count, fingerprint)`. Occurrence count NEVER
    changes the gate decision.
12. `evidence_ref` = evidence content hash, else `"decision-log:{recorded_at}"` —
    always non-empty.
13. Workflow performs NO git/PR/code mutation; `fix_proposal` is record-only. No
    continue-as-new, no compensation, no rework loop, no counters beyond the three
    tallies.
14. `digest.new/recurring` split incidents against `known_fingerprints`; digest's
    decision counters equal the workflow's loop counters.
