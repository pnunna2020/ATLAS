# ModernizationWorkflow — Atomic Regeneration Spec (Part 2 of 3)

Continues from `ModernizationWorkflow.md`. Covers **Design step** (G-04b, delegated-bundle path) and **Generate step** (G-04c, BC fan-out, DevSecOps validator gating, Tier-1 triple-signal). All cites `temporal/olympus_workflows/workflows/modernization.py`.

---

## 10. Design Step

### 10.1 `_dispatch_design_internal` (`:1070-1145`)
The internal agent chain — used as the `fallback_fn` for `_maybe_dispatch_bundle` AND the direct path when not delegated. Returns the traceability-audit `AgentTaskResult`.
Sequential dispatches (each `await _dispatch_agent(...)` then stores into `_design_results`):
1. `module-design` (skill `module-design`, input `self._collect_extract_artifacts()`) → `_design_results["module-design"]` (`:1089-1097`).
2. `api-specification` (skill `api-specification`, input `module_result.output_artifacts`) → `_design_results["api-specification"]` (`:1100-1108`).
3. `data-modeling` (skill `data-modeling`, input `module_result.output_artifacts`) → `_design_results["data-modeling"]` (`:1111-1119`). **GOTCHA:** data-modeling takes MODULE output as input, not api output.
4. `if self._is_batch_archetype(input):` → `batch-design` (skill `batch-design`, input `module_result.output_artifacts`) → `_design_results["batch-design"]` (`:1121-1131`).
5. `traceability-audit` — ALWAYS-ON (W19 PR C) (skill `traceability-audit`, input `self._collect_design_artifacts()`) → `_design_results["traceability-audit"]`; `return audit_result` (`:1133-1145`).

`_is_batch_archetype(input)` (`:1339-1344`): returns True if any `artifact` in `input.prior_artifacts` has `"batch" in artifact.lower()`, else False.

### 10.2 `_fold_bundle_design_outputs(outputs)` (`:1147-1176`)
Maps a delegated bundle's accepted `artifact_kind → ref` map onto `_design_results` keyed by design sub-step. `kind_to_step` (`:1160-1169`): `module-map`/`module_map→module-design`, `openapi`/`api-specification→api-specification`, `data-model`/`data_model→data-modeling`, `batch-design→batch-design`, `traceability-audit→traceability-audit`. For each `(kind, ref)`: `if not ref: continue`; `step_key = kind_to_step.get(kind, kind)` (unknown kinds stored under own key, nothing dropped); `_design_results.setdefault(step_key, [])`; `if ref not in list: append`.

### 10.3 `_execute_design` (`:1178-1337`)
Returns approved/failed/cancelled. Branch `f"olympus/modernization/design/{app_id}/{run_suffix}"` (`:1188`). `design_base = self._sum_weights("extract","cross-validation","extract-commit","extract-gate")` = 15+5+2.5+7.5 = **30.0** (`:1189-1194`). `while True:` (`:1196`).

Flow per iteration:
1. `await _set_step("design", design_base)` → 30.0 (`:1197`).
2. **Delegated-bundle or internal chain** (`:1208-1229`):
   ```
   audit_result = await self._maybe_dispatch_bundle(
       step_or_gate_id="modernization-design", scope_kind="line_step",
       app_id=app_id, wave_id=None, is_delegatable=True, expires_hours=7*24 (168),
       fallback_fn=lambda: self._dispatch_design_internal(input, app_id, source_repo, workspace_key))
   if isinstance(audit_result, dict):          # bundle path returned accepted outputs
       self._fold_bundle_design_outputs(audit_result)
       audit_result = None                     # no internal audit → design-review.json falls back to provisional default
   ```
   **GOTCHA:** the bundle path returns a `dict` (outputs map); the internal path returns an `AgentTaskResult`. When `dict`, `audit_result` is nulled so `_commit_design_artifacts` emits the provisional design-review (still gate-evaluable). See base `_maybe_dispatch_bundle` (`base.py:547-629`) — TTL timeout is `expires_hours*3600+3600`; fallback policy per `_portfolio_fallback_policy`.
3. `await _set_step("design-commit", design_base + STEP_WEIGHTS["design"])` → 30+15 = 45.0 (`:1233-1235`).
4. `artifact_paths = await _commit_design_artifacts(repo, branch, app_id, audit_result=audit_result)` (Part 3) (`:1236-1238`).
5. `pr_result = await _create_design_pr(repo, branch, app_id)` (`:1241`).
6. `gate_record = execute_activity(create_gate_record, CreateGateRecordInput(gate_type="G-04b", app_id, portfolio_id, workflow_id, evidence_package_url=pr_result.pr_url), timeout=30s, retry=transient)` (`:1243-1254`).
7. `await _submit_gate_evidence(gate_id, GateType.G_04B, app_id, artifact_paths, pr_url, "Modernization", step="design")` (`:1256-1264`).
8. `if workflow.patched("modernization-gate-pre-review-v1"): await _run_gate_pre_review(gate_id, "G-04b", artifact_paths, artifact_repo=repo, artifact_ref=branch) else: await _mark_ready_for_review(gate_id)` (`:1266-1275`).
9. `await _update_app_status(app_id, "gate_review", "design-gate-review", "Modernization")` (`:1277-1282`).
10. `await _set_step("design-gate", design_base + STEP_WEIGHTS["design"] + STEP_WEIGHTS["design-commit"])` → 30+15+2.5 = 47.5 (`:1284-1289`).
11. `decision = await _wait_for_gate_decision(GateType.G_04B)` (`:1290`).
    - **`if decision == "cancelled": return "cancelled"`** (`:1292-1293`).
    - **`if decision == "approved":`** (`:1295-1323`):
      - **No Tier-1 sub-wait for G-04b** (Design has none — Tier-1 signals apply to G-04a SME + G-04c EA/security only).
      - Post-G-04b projection: `module_map_content = _find_output_file_content("module-design")`; `design_review_content = _find_output_file_content("design-review")`; `design_refs = _design_results.get("design-review", [])`; `design_ref = design_refs[0] if design_refs else ""`; `await _persist_side_effects(app_id, "design", module_map_json=module_map_content, design_review_json=design_review_content, design_ref=design_ref)` (`:1296-1315`).
      - `await _reconcile_and_merge_with_retry_loop(repo=repo, pr_number=pr_result.pr_number, gate_id=gate_record.gate_id)` (default merge_method) (`:1317-1322`).
      - `return "approved"` (`:1323`).
    - **Rejected → rework** (`:1325-1337`): `_bump_rework("G-04b")`; `if _rework_count("G-04b") > 3:` → `_status=FAILED; _current_step="design-max-rework-exceeded"; _updated_at; await _update_app_status(app_id,"modernization_failed","design-max-rework-exceeded","Modernization"); return "failed"`. Else loop re-iterates. **GOTCHA:** no Tier-1 flag reset here (Design has no Tier-1 flags).

### 10.4 Design helpers
- `_collect_extract_artifacts` (`:1346-1367`): starts empty list; for each `prior` in `self._workflow_input_prior_artifacts()`, `if "architecture" in prior.lower() or "blueprint" in prior.lower(): append` (forwards Architecture blueprint refs); then `extend` with every `step_artifacts` in `_extract_results.values()`; return `dedup_paths(artifacts)`.
- `_workflow_input_prior_artifacts` (`:1369-1376`): `input_obj = getattr(self,"_input",None); if None: return []; return list(getattr(input_obj,"prior_artifacts",[]) or [])`.
- `_collect_design_artifacts` (`:1378-1383`): extend with all `_design_results.values()`; `dedup_paths`.

---

## 11. Generate Step — `_execute_generate` (`:1703-2093`)
Returns approved/failed/cancelled. Branch `f"olympus/modernization/generate/{app_id}/{run_suffix}"` (`:1713`). `generate_base = _sum_weights("extract","cross-validation","extract-commit","extract-gate","design","design-commit","design-gate")` = 15+5+2.5+7.5+15+2.5+7.5 = **55.0** (`:1714-1722`).

### 11.1 DevSecOps profile resolution — ONCE before loop (`:1724-1748`)
`if not self._devsecops_params:` → `ds_params = execute_activity(resolve_devsecops_profile, ResolveDevSecOpsProfileInput(profile_id=input.portfolio_id or ""), timeout=30s, retry=transient, activity_id=f"resolve-devsecops-{app_id}")`; store dict `{sast_tool, sbom_required, container_base, license, target_cloud, primary_ecosystem, iac, cicd}`. **GOTCHA:** resolved once and reused across Generate reworks (only when empty), so all iterations render the same baseline params.

### 11.2 `while True:` loop body (`:1750`)
1. `await _set_step("generate", generate_base)` → 55.0 (`:1751`).
2. **Parse bounded contexts:** `bc_names = await _parse_bounded_contexts(repo=repo, app_id=app_id)` (Part 3) (`:1758-1760`).
3. **Fan-out setup — per-BC framework routing** (`:1774-1806`):
   - `_FRONTEND_BC_NAMES = {"frontend","ui","web-app","spa"}`; `_DEFAULT_BACKEND_FRAMEWORK="express"`; `_DEFAULT_FRONTEND="react"`.
   - `bc_tasks = []`; `for bc_name in bc_names[:MAX_BC_CHILDREN_PER_APP (12)]:` (slice = truncation):
     - `bc_name_lower = bc_name.lower()`.
     - `if bc_name_lower in _FRONTEND_BC_NAMES:` → `bc_framework = None; bc_frontend = input.target_frontend or _DEFAULT_FRONTEND ("react")` (`:1781-1783`).
     - `else:` → `bc_framework = input.target_framework or _DEFAULT_BACKEND_FRAMEWORK ("express"); bc_frontend = None` (`:1784-1786`).
     - `bc_input = GenerateBCInput(app_id, bc_name, wave_id=input.wave_id, portfolio_id=input.portfolio_id, artifact_repo=repo, source_repo=source_repo, design_artifacts=self._collect_design_artifacts(), target_framework=bc_framework, target_frontend=bc_frontend, primary_language=input.primary_language)` (`:1788-1799`).
     - `task = workflow.execute_child_workflow("GenerateBCWorkflow", bc_input, id=f"generate-bc-{app_id}-{bc_name}-{run_suffix}", task_queue=workflow.info().task_queue)`; `bc_tasks.append(task)` (`:1800-1806`). Child runs on the SAME task queue.
4. **Parallel wait:** `raw_results = await asyncio.gather(*bc_tasks)` (`:1809`). **GOTCHA:** children run concurrently; a single child failure propagates through `gather` and fails the whole Generate step (no per-child try/except here). Ralph-loop / escalation internals are in the child — see `13-generation-engine.md`.
5. **Deserialize:** `bc_results = [GenerateBCResult(**r) if isinstance(r, dict) else r for r in raw_results]` (Temporal may return dicts); `self._generate_results = list(bc_results)` (`:1810-1815`).
6. **Synthesis dispatch** (`:1817-1831`): `_set_step("generate-synthesis", generate_base + STEP_WEIGHTS["generate"])` → 55+25 = 80.0; `synthesis_result = _dispatch_agent(step_name="synthesis", skill_id="code-synthesis", input_artifacts=[a for r in bc_results for a in r.output_artifacts], ...)`. **GOTCHA:** synthesis input = flattened union of ALL BC output artifacts.
7. **Adversarial review** (`:1833-1847`): `_set_step("generate-review", generate_base + STEP_WEIGHTS["generate"] + STEP_WEIGHTS["generate-synthesis"])` → 55+25+5 = 85.0; `_dispatch_agent(step_name="adversarial-review", skill_id="adversarial-review", input_artifacts=synthesis_result.output_artifacts, ...)` (result not stored).
8. **Security posture review** (`:1849-1861`): `_dispatch_agent(step_name="security-posture-review", skill_id="security-posture-review", input_artifacts=synthesis_result.output_artifacts, ...)` — reasons about design intent (distinct from Validation's security-scan-review). No `_set_step`.
9. **Security scan review — best-effort** (`:1863-1883`):
   ```
   try:
       await _dispatch_agent(step_name="security-scan-review", skill_id="security-scan-review", input_artifacts=synthesis_result.output_artifacts, ...)
   except Exception as exc:   # noqa BLE001 advisory
       workflow.logger.warning("security-scan-review dispatch failed (non-fatal): %s", exc)
   ```
   **GOTCHA:** a triage miss must NOT block the gate — this is the ONLY generate dispatch wrapped in try/except.
10. **IaC scaffolding** (`:1885-1903`): `_dispatch_agent(step_name="iac-scaffolding", skill_id="iac-scaffolding-generator", input_artifacts=synthesis_result.output_artifacts, ...)`. Produces rich cloud-resource IaC; does NOT emit `infra/terraform/main.tf` (synthesis owns that — no collision).
11. **Gate review package** (`:1905-1913`): `_dispatch_agent(step_name="gate-review-package", skill_id="gate-review-package", input_artifacts=synthesis_result.output_artifacts, ...)`.
12. **Commit** (`:1915-1925`): `_set_step("generate-commit", generate_base + generate + generate-synthesis + generate-review)` → 55+25+5+5 = 90.0; `artifact_paths = await _commit_generate_artifacts(repo, branch, app_id, bc_results)` (Part 3).
13. **DevSecOps baseline validator — GATES G-04c** (`:1927-1972`):
    ```
    baseline_validation = execute_activity(validate_devsecops_baseline,
        ValidateDevSecOpsBaselineInput(app_id, committed_files=list(self._committed_baseline_files),
            sast_tool=str(self._devsecops_params.get("sast_tool","codeql"))),
        timeout=60s, retry=transient, activity_id=f"validate-devsecops-{app_id}")
    if not baseline_validation.passed:
        workflow.logger.warning(..., extra={missing, errors})
        self._g04c_stakeholder_ea_approved = False
        self._g04c_stakeholder_security_approved = False
        self._bump_rework("G-04c")
        if self._rework_count("G-04c") > MAX_REWORK_ITERATIONS (3):
            _status=FAILED; _current_step="generate-baseline-incomplete"; _updated_at
            await _update_app_status(app_id,"modernization_failed","generate-baseline-incomplete","Modernization")
            return "failed"
        continue        # loop back to re-generate WITHOUT ever creating the gate PR
    ```
    **GOTCHA (critical):** a failed deterministic baseline validation triggers a rework that ALSO increments the `G-04c` counter and resets the Tier-1 flags — but this path never created a gate record. So the G-04c rework budget is shared between "reviewer rejected" and "baseline incomplete". `continue` re-runs the ENTIRE generate loop (re-fan-out + re-synthesis).
14. **Create PR + gate** (`:1974-1990`): `pr_result = await _create_generate_pr(repo, branch, app_id, bc_results)`; `gate_record = execute_activity(create_gate_record, CreateGateRecordInput(gate_type="G-04c", app_id, portfolio_id, workflow_id, evidence_package_url=pr_result.pr_url), timeout=30s, retry=transient)`.
15. **Evidence + pre-review** (`:1992-2011`): `await _submit_gate_evidence(gate_id, GateType.G_04C, app_id, artifact_paths, pr_url, "Modernization", step="generate")`; then `if workflow.patched("modernization-gate-pre-review-v1"): _run_gate_pre_review(gate_id, "G-04c", artifact_paths, artifact_repo=repo, artifact_ref=branch) else: _mark_ready_for_review(gate_id)`.
16. `await _update_app_status(app_id, "gate_review", "generate-gate-review", "Modernization")` (`:2013-2018`).
17. `await _set_step("generate-gate", generate_base + generate + generate-synthesis + generate-review + generate-commit)` → 55+25+5+5+2.5 = 97.5 (`:2020-2027`).
18. `decision = await _wait_for_gate_decision(GateType.G_04C)` (`:2028`).
    - **`if decision == "cancelled": return "cancelled"`** (`:2030-2031`).
    - **`if decision == "approved":`** (`:2033-2074`):
      - **Tier-1 triple-signal sub-wait:** `if self._risk_tier == 1:` → `await workflow.wait_condition(lambda: (self._g04c_stakeholder_ea_approved and self._g04c_stakeholder_security_approved) or self.cancelled)` (`:2041-2050`); `if self.cancelled: self._status = CANCELLED; return "cancelled"` (`:2051-2053`). Tier-2/3 skip (EA/security participate via PR review).
      - Post-G-04c projection: `package_content = _find_output_file_content("gate-review-package")`; `await _persist_side_effects(app_id, "generate", gate_review_package_json=package_content)` (`:2055-2066`).
      - `await _reconcile_and_merge_with_retry_loop(repo=repo, pr_number=pr_result.pr_number, gate_id=gate_record.gate_id)` (`:2068-2073`).
      - `return "approved"` (`:2074`).
    - **Rejected → rework** (`:2076-2093`): `self._g04c_stakeholder_ea_approved = False; self._g04c_stakeholder_security_approved = False` (reset both, `:2079-2080`); `_bump_rework("G-04c")`; `if _rework_count("G-04c") > 3:` → `_status=FAILED; _current_step="generate-max-rework-exceeded"; _updated_at; await _update_app_status(app_id,"modernization_failed","generate-max-rework-exceeded","Modernization"); return "failed"`. Else loop re-iterates (full re-generation).

---

## 12. `_create_design_pr` (`:1664-1697`)
`rework = _rework_count("G-04b")`. Builds `pr_body` header + artifact checklist (Module Map, API Specification, Data Model). `if "batch-design" in self._design_results: pr_body += "- [x] Batch Design (batch-design.yaml)\n"`. Always appends "Design Review Summary (design-review.json)". `if rework > 0: pr_body += f"\n**Rework iteration:** {rework}\n"`. `execute_activity(create_pr, CreatePRInput(repo, source_branch=branch, target_branch="main", title=f"Gate G-04b: Modernization Design Review — {app_id}", body, labels=["gate-review","modernization","design","G-04b"], execution_context=...), timeout=60s, retry=transient)`.

## 13. `_create_generate_pr` (`:2335-2386`)
`rework = _rework_count("G-04c")`. Header + per-BC lines: `for r in bc_results:` `status_icon = "x" if r.status == "completed" else " "`; append `f"- [{icon}] **{r.bc_name}**: {r.status} ({r.iteration_count} iterations)\n"`; `if r.escalation_id: append "  - Escalation: {id}\n"`. Then "Gate Review Package" artifact line; `if rework>0: append rework note`. `create_pr(... title=f"Gate G-04c: Generated Code Review — {app_id}", labels=["gate-review","modernization","generate","G-04c"], ...)`, timeout 60s, retry transient.

## 14. `_persist_side_effects` (`:1021-1064`)
Best-effort projection. `try: execute_activity(persist_modernization_side_effects, PersistModernizationSideEffectsInput(target_app_id=app_id, gate_phase, extraction_report_json, extraction_ref, module_map_json, design_review_json, design_ref, gate_review_package_json, decided_at=_now_iso()), timeout=60s, retry=transient, activity_id=f"persist-modernization-{gate_phase}") except Exception: workflow.logger.exception(...)`. **GOTCHA:** failure is swallowed — the gate approval still completes; the app row keeps stale modernization fields.

## 15. `_find_output_file_content(step_name)` (`:1002-1019`)
`metadata = _agent_metadata.get(step_name,{}); output_files = metadata.get("output_files",[]); if not output_files: return ""; first = output_files[0]; if isinstance(first, dict): return str(first.get("content","")); return first.content if hasattr(first,"content") else ""`. Tolerates dict OR OutputFile.

---

*(Continued in ModernizationWorkflow-part3.md: commit helpers, `_parse_bounded_contexts`, `parse_bc_names_from_yaml`, `_build_design_review_content`, `_seed_patterns_from_registry`, `_mark_ready_for_review`, RESILIENCE, GOTCHAs, Behavioral-parity checklist.)*
