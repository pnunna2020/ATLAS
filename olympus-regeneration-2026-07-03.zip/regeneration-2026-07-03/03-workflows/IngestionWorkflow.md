# IngestionWorkflow — Atomic Regeneration Spec

**Source:** `temporal/olympus_workflows/workflows/ingestion.py` (235 lines)
**Decorator:** `@workflow.defn` (`ingestion.py:90`)
**Class:** `IngestionWorkflow` (`ingestion.py:91`)
**Line:** The brownfield **reverse-engineering** (P8 legacy-ingestion) per-app line — the 12th assembly line.

---

## 0. Orientation & critical structural facts

`IngestionWorkflow` is the Temporal driver for the reverse-engineering assembly line. It ingests a legacy codebase **read-only**, reconstructs a typed spec of behavioral obligations, enrolls those obligations in the existing drift engine, and human-gates sub-floor-confidence obligations so they cannot gate a downstream build until a human confirms them.

**CRITICAL STRUCTURAL DIVERGENCE from the other line workflows — a rebuild MUST replicate this exactly:**

1. **`IngestionWorkflow` does NOT inherit `LineWorkflowBase`** (`ingestion.py:91` — bare `class IngestionWorkflow:` with only `@workflow.defn`). It does **not** import or reuse `_base-workflow.md` machinery at all. There is **no** `_set_step`, `_dispatch_agent`, `_commit_step_artifacts`, `_create_gate_pr`, `_submit_gate_evidence`, `_wait_for_gate_decision`, `_reconcile_and_merge_with_retry_loop`, `get_status` query, `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry` signals, `HILSignalsMixin`, or `BundleAwareMixin` here. Do **not** copy base behavior into a rebuild of this workflow — it has its own minimal, self-contained state machine.
2. **This workflow does NOT dispatch agents, does NOT commit artifacts to git, does NOT create gate PRs, does NOT call the gate-operations activities.** All of its side effects are exactly **two** `execute_activity` calls: `ingest_legacy_source` and `enroll_reconstructed_obligations`. Everything else (the "gate") is an in-workflow human-confirmation wait driven by a single signal + query.
3. **The G-RE-1 / G-RE-2 gates in the assembly-line contract (`reverse-engineering.yaml:48-60,148-181`) are NOT implemented as Temporal gate-PR flows in this workflow.** The workflow's "human gate" (REQ-LI-004) is the `confirm_obligation` signal + `obligation_gate_status` query + `wait_condition` on `_all_confirmed()`. The contract's `G-RE-1`/`G-RE-2` gates are declared for the gate service / step-progress mapping, but the workflow code does not run `check_gate_criteria` / `create_pr` / `submit_gate_evidence`. This is a genuine divergence between the YAML contract and the workflow implementation — capture BOTH.
4. **DRIFT ITEM (grep-provable):** the assembly-line contract `reverse-engineering.yaml` is registered **additively** at import time and is **NOT** an `AssemblyLine` StrEnum member (the enum stays exactly 10 members — `reverse-engineering.yaml:10-17`). `IngestionWorkflow` has **no** `ASSEMBLY_LINE` classvar (unlike every `LineWorkflowBase` subclass). Do not assume enum membership.
5. **Determinism invariant (`ingestion.py:10-14`):** ALL nondeterminism (filesystem reads, safety-classifier, provider routing, drift evaluation) lives in the two activities. The workflow body contains no clock read, no IO, no randomness, no `workflow.now()`, no `workflow.patched()`. It only schedules activities and waits on a signal.

---

## 1. STATE — every instance variable

Set in `__init__` (`ingestion.py:94-104`). There is **no** `super().__init__()` call (it does not inherit a base).

| Attr | Type | Initial value | Line | Mutated by / when |
|---|---|---|---|---|
| `_obligation_needs_confirmation` | `dict[str, bool]` | `{}` | `ingestion.py:97` | Assigned **once** in `run()` after the ingest activity returns (`ingestion.py:198-200`): `{o.ref: o.needs_confirmation for o in ingest_result.obligations}`. Maps each reconstructed obligation ref → whether it is sub-floor (needs human confirmation). Read by `obligation_gate_status`, `_gateable_refs`, `_all_confirmed`. **Never mutated after that single assignment.** |
| `_confirmed_refs` | `set[str]` | `set()` | `ingestion.py:101` | Added to by the `confirm_obligation` signal handler (`ingestion.py:111`), one ref per signal. Buffered as a set so a confirm signal that **races ahead** of the `wait_condition` is not lost. A confirmed ref removes the obligation from the gating blocklist. |
| `_cancelled` | `bool` | `False` | `ingestion.py:102` | Set to `True` by the `cancel` signal handler (`ingestion.py:116`). Consumed by the `wait_condition` predicate (`ingestion.py:222`) and the terminal status computation (`ingestion.py:225`). |
| `_classifier_domains` | `tuple[str, ...]` | `()` | `ingestion.py:103` | Assigned **once** in `run()` from the ingest result (`ingestion.py:197`): `tuple(ingest_result.classifier_domains)`. Read only by the `obligation_gate_status` query (`ingestion.py:137`). |
| `_status` | `str` | `"running"` | `ingestion.py:104` | String status; transitions: `"running"` → `"awaiting_confirmation"` (`ingestion.py:220`, only if there are unconfirmed sub-floor obligations) → `"cancelled"` or `"completed"` (`ingestion.py:225-226`). **GOTCHA:** there is no query that returns `_status`; it is purely internal bookkeeping (no `get_status` handler on this class). It is not part of any query surface — it is set but only observable via workflow history/introspection, never returned. A rebuild should still maintain it identically for fidelity, but note it has no external reader.

**GOTCHA (`ingestion.py:97-101`):** `_obligation_needs_confirmation` is populated *after* the first activity returns; before that (e.g. a query issued during the ingest activity) it is empty, so `obligation_gate_status` returns all-empty lists. `_confirmed_refs` can accumulate confirm signals *before* the map is populated (signal-before-state race) and those confirmations still apply once the map lands, because `_gateable_refs`/`_all_confirmed` intersect the map keys with `_confirmed_refs` lazily.

---

## 2. SIGNALS & QUERIES

### 2.1 Signal: `confirm_obligation(ref: str)` — `ingestion.py:108-111`
- **Decorator:** `@workflow.signal`
- **Payload:** a single positional `ref: str` (the obligation ref, e.g. `"path/to/File.cs:module"`).
- **Effect:** `self._confirmed_refs.add(ref)` (`ingestion.py:111`). Idempotent (set add). Never validates that `ref` is a known/sub-floor obligation — an unknown or above-floor ref is silently added to the set (harmless: `_gateable_refs`/`_all_confirmed` only iterate over `_obligation_needs_confirmation` keys, so a stray ref never changes gateability).
- **Consumed by:** the `wait_condition` predicate `lambda: self._all_confirmed() or self._cancelled` (`ingestion.py:222`). Each confirm signal wakes the condition; the run proceeds once every sub-floor obligation is confirmed.
- **REQ:** REQ-LI-004 (low-confidence human gate).

### 2.2 Signal: `cancel()` — `ingestion.py:113-116`
- **Decorator:** `@workflow.signal`
- **Payload:** none.
- **Effect:** `self._cancelled = True` (`ingestion.py:116`). Idempotent.
- **Consumed by:** the same `wait_condition` (`ingestion.py:222`). Also read in the terminal status computation (`ingestion.py:225`): `status = "cancelled" if self._cancelled else "completed"`.
- **GOTCHA:** cancel does **not** abort the two activities (they run before the wait) — it only short-circuits the human-confirmation wait. If `cancel` arrives while the ingest or enroll activity is running, it takes effect only when the workflow reaches (or is already at) the `wait_condition`. If all obligations are above-floor, the `wait_condition` block is skipped entirely (`ingestion.py:219`), so a `cancel` that arrives after both activities but the code never entered the `if` still yields `status="cancelled"` because line 225 reads `_cancelled` unconditionally.

### 2.3 Query: `obligation_gate_status() -> dict` — `ingestion.py:118-138`
- **Decorator:** `@workflow.query`
- **Returns:** a dict with exactly these keys (`ingestion.py:132-138`):
  - `"below_floor"`: `sorted([ref for ref, needs in self._obligation_needs_confirmation.items() if needs])` — the sub-floor refs (`ingestion.py:126-130`).
  - `"confirmed"`: `sorted(self._confirmed_refs)` (`ingestion.py:134`).
  - `"gateable"`: `sorted(self._gateable_refs())` (`ingestion.py:131,133`).
  - `"blocked"`: `sorted(set(below_floor) - self._confirmed_refs)` (`ingestion.py:136`) — sub-floor refs not yet confirmed.
  - `"classifier_domains"`: `list(self._classifier_domains)` (`ingestion.py:137`).
- **REQ:** REQ-LI-004 read surface.
- **GOTCHA — the `blocked` computation subtracts the RAW `_confirmed_refs` set, which may contain refs not in `below_floor`.** Because it's `set(below_floor) - _confirmed_refs`, stray confirmations do not corrupt the result (subtracting extra elements is a no-op). But note `blocked` and `_all_confirmed()`-driven completion are computed independently — `blocked` uses `below_floor` (which is `needs==True` refs) while `_all_confirmed` uses the same set membership; they agree. `blocked` is a query-only projection and is **not** the completion predicate.

### 2.4 Handlers that MUST NOT be overridden
Because this class does **not** inherit `LineWorkflowBase`/`HILSignalsMixin`, there are **no** inherited `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry` handlers to worry about. The base's rule ("subclasses MUST NOT redefine gate_approved/gate_rejected/escalation_resolved" — `base.py:11-13,117-118`) does **not** apply here because there is no subclass relationship. The three handlers defined here (`confirm_obligation`, `cancel`, `obligation_gate_status`) are the complete signal/query surface; a rebuild must register exactly these and no base-workflow handlers.

---

## 3. INTERNAL GATE LOGIC (pure, deterministic helpers)

### 3.1 `_gateable_refs() -> set[str]` — `ingestion.py:142-154`
Refs that may gate a build **now**: above-floor, OR sub-floor + confirmed.

```
def _gateable_refs() -> set[str]:
    gateable = set()
    for ref, needs in self._obligation_needs_confirmation.items():   # ingestion.py:151
        if not needs or ref in self._confirmed_refs:                  # ingestion.py:152
            gateable.add(ref)                                         # ingestion.py:153
    return gateable
```
- **Case `needs == False` (above-floor):** always gateable, regardless of confirmation.
- **Case `needs == True` (sub-floor) AND `ref in _confirmed_refs`:** gateable.
- **Case `needs == True` AND `ref not in _confirmed_refs`:** EXCLUDED (the load-bearing REQ-LI-004 guarantee — a low-confidence reverse-engineered obligation cannot gate a build before a human confirms it, `ingestion.py:143-148`).
- Used by: `obligation_gate_status` (`ingestion.py:131`) and the terminal `gateable_count` (`ingestion.py:233`).

### 3.2 `_all_confirmed() -> bool` — `ingestion.py:156-163`
True iff every sub-floor obligation has been human-confirmed.

```
def _all_confirmed() -> bool:
    blocked = {
        ref
        for ref, needs in self._obligation_needs_confirmation.items()   # ingestion.py:159-161
        if needs and ref not in self._confirmed_refs
    }
    return not blocked                                                  # ingestion.py:163
```
- Returns `True` when there are **zero** sub-floor-and-unconfirmed refs. **Vacuously True when `_obligation_needs_confirmation` is empty** (no obligations at all) or when every obligation is above-floor.
- Used by: the `run()` guard (`ingestion.py:219`) and the `wait_condition` predicate (`ingestion.py:222`).

---

## 4. CONTROL FLOW — `run()`

`@workflow.run async def run(self, input: IngestionWorkflowInput) -> IngestionWorkflowResult` (`ingestion.py:167-235`).

**Input dataclass `IngestionWorkflowInput` (`ingestion.py:53-67`):**
| Field | Type | Default | Line |
|---|---|---|---|
| `app_id` | `str` | (required) | `ingestion.py:63` |
| `source_root` | `str` | (required) — READ-ONLY unpacked legacy tree Discovery produced | `ingestion.py:64` |
| `confidence_floor` | `float` | `DEFAULT_CONFIDENCE_FLOOR` = `0.5` (`ingestion.py:65`, floor from `activities/ingestion.py:203`) | `ingestion.py:65` |
| `profile_id` | `str` | `""` — routes the safety-classifier fail-closed provider resolution | `ingestion.py:66` |
| `route_classifier_hits` | `bool` | `True` | `ingestion.py:67` |

**Output dataclass `IngestionWorkflowResult` (`ingestion.py:70-87`):**
| Field | Type | Default | Line |
|---|---|---|---|
| `status` | `str` | (required) — `"completed"` or `"cancelled"` | `ingestion.py:81` |
| `app_id` | `str` | (required) | `ingestion.py:82` |
| `obligations_total` | `int` | (required) | `ingestion.py:83` |
| `low_confidence_count` | `int` | (required) | `ingestion.py:84` |
| `drift_enrolled` | `int` | (required) | `ingestion.py:85` |
| `gateable_count` | `int` | (required) | `ingestion.py:86` |
| `classifier_domains` | `list[str]` | `field(default_factory=list)` | `ingestion.py:87` |

### run() structured pseudocode (preserving every step)

```
async def run(input: IngestionWorkflowInput) -> IngestionWorkflowResult:

    # ---- STEP 1: read-only ingest + reconstruct + classifier surface/route ----
    # ingestion.py:184-196
    ingest_result: IngestLegacySourceResult = await workflow.execute_activity(
        ingest_legacy_source,
        IngestLegacySourceInput(
            app_id             = input.app_id,
            source_root        = input.source_root,
            confidence_floor   = input.confidence_floor,
            profile_id         = input.profile_id,
            route_classifier_hits = input.route_classifier_hits,
            # NOTE: max_files is NOT passed → activity default 5000 (activities/ingestion.py:292)
        ),
        start_to_close_timeout = timedelta(seconds=120),          # ingestion.py:193
        retry_policy           = RETRY_POLICIES["transient"],     # ingestion.py:194  (HTTP_RETRY_POLICY: 3 attempts, 1s→15s, x2)
        activity_id            = f"ingest-{input.app_id}",        # ingestion.py:195
    )
    # (If ingest_legacy_source raises ReadOnlyViolationError or SafetyClassifierError,
    #  both are NonRetryableError subclasses → activity fails non-retryably → run() fails.
    #  No try/except here: the workflow run FAILS. Never a silent pass. See §5.)

    # Assign state from the ingest result — the ONLY writes to these two attrs.
    self._classifier_domains = tuple(ingest_result.classifier_domains)        # ingestion.py:197
    self._obligation_needs_confirmation = {                                    # ingestion.py:198-200
        o.ref: o.needs_confirmation for o in ingest_result.obligations
    }

    # ---- STEP 2: enroll reconstructed obligations in drift-tracking (REQ-LI-003) ----
    # ingestion.py:203-213
    drift_result: EnrollReconstructedResult = await workflow.execute_activity(
        enroll_reconstructed_obligations,
        EnrollReconstructedInput(
            app_id        = input.app_id,
            spec_artifact = f"reconstructed-spec:{input.app_id}",   # ingestion.py:207
            obligations   = list(ingest_result.obligations),        # ingestion.py:208
            # citations defaults to [] (enrollment-time; coverage accrues later)
        ),
        start_to_close_timeout = timedelta(seconds=60),            # ingestion.py:210
        retry_policy           = RETRY_POLICIES["transient"],      # ingestion.py:211
        activity_id            = f"drift-enroll-{input.app_id}",   # ingestion.py:212
    )

    # ---- STEP 3: human-gate sub-floor obligations (REQ-LI-004) ----
    # ingestion.py:219-223
    if not self._all_confirmed():                    # ingestion.py:219  (i.e. at least one sub-floor obligation unconfirmed)
        self._status = "awaiting_confirmation"       # ingestion.py:220
        await workflow.wait_condition(               # ingestion.py:221-223
            lambda: self._all_confirmed() or self._cancelled
        )
    # else: no sub-floor obligations (or already all confirmed) → skip the wait entirely.

    # ---- terminal ----
    status = "cancelled" if self._cancelled else "completed"   # ingestion.py:225
    self._status = status                                       # ingestion.py:226
    return IngestionWorkflowResult(                             # ingestion.py:227-235
        status              = status,
        app_id              = input.app_id,
        obligations_total   = ingest_result.obligations_total,      # from ingest activity
        low_confidence_count= ingest_result.low_confidence_count,   # from ingest activity
        drift_enrolled      = drift_result.obligations_total,       # from enroll activity — the enrolled count
        gateable_count      = len(self._gateable_refs()),           # computed NOW from confirmations
        classifier_domains  = list(ingest_result.classifier_domains),
    )
```

**Branch enumeration (every branch in run):**
1. `if not self._all_confirmed()` is **True** (`ingestion.py:219`): set `_status="awaiting_confirmation"`, then `await wait_condition`. The wait wakes when either every sub-floor obligation is confirmed (`_all_confirmed()` True) OR `_cancelled` True. Multiple confirm signals may be needed (one per sub-floor ref) before the predicate flips.
2. `if not self._all_confirmed()` is **False** (`ingestion.py:219`): no wait; fall straight through to terminal. This covers (a) zero obligations, (b) all obligations above-floor, (c) all sub-floor obligations already confirmed via confirm signals that arrived during the two activities.
3. Terminal `status` ternary (`ingestion.py:225`): `_cancelled` True → `"cancelled"`; else `"completed"`. Note this reads `_cancelled` even if the wait block was skipped (branch 2) — a cancel that landed anytime still yields `"cancelled"`.

**GOTCHA (ordering, `ingestion.py:219-223`):** The `_status = "awaiting_confirmation"` write happens **before** the `wait_condition`, and only inside the `if`. If all obligations are above-floor, `_status` never becomes `"awaiting_confirmation"` — it goes `"running"` → `"completed"` directly.

**GOTCHA (ternary vs wait, `ingestion.py:222,225`):** The wait predicate is `_all_confirmed() OR _cancelled`. If the wait wakes because of `_cancelled` (not full confirmation), the terminal ternary yields `"cancelled"`. If it wakes because `_all_confirmed()` became True AND `_cancelled` is still False, it yields `"completed"`. If BOTH become true (a confirm and a cancel), `_cancelled` wins the ternary → `"cancelled"`.

---

## 5. ACTIVITY CALLS — ordered, arguments, retry, timeouts, sequencing

Both activities are **sequential** (`await` one after the other; no `asyncio.gather`, no child workflows, no parallel fan-out). There are exactly **two** `execute_activity` calls in this workflow.

### Call 1 — `ingest_legacy_source` (`ingestion.py:184-196`)
- **Activity fn:** `olympus_workflows.activities.ingestion.ingest_legacy_source` (`activities/ingestion.py:620-661`), decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`.
- **Args:** single `IngestLegacySourceInput(app_id, source_root, confidence_floor, profile_id, route_classifier_hits)`. `max_files` omitted → activity default **5000** (`activities/ingestion.py:292`).
- **Retry policy:** `RETRY_POLICIES["transient"]` → `HTTP_RETRY_POLICY` = `initial_interval=1s, maximum_interval=15s, maximum_attempts=3, backoff_coefficient=2.0` (`retry_policies.py:34,111`; `temporal_base/retry_policies.py:35-40`). **No explicit `non_retryable_error_types`** on this call — non-retryability comes from the exception classes themselves via the `@foundry_activity` decorator's retryability heuristic (`ReadOnlyViolationError`/`SafetyClassifierError` are `NonRetryableError` subclasses — `activities/ingestion.py:57,67`).
- **Timeout:** `start_to_close_timeout=timedelta(seconds=120)`. No `heartbeat_timeout`, no `schedule_to_close`.
- **`activity_id`:** `f"ingest-{input.app_id}"` — deterministic per app (idempotency key across replays).
- **What the activity does (nondeterminism boundary — `activities/ingestion.py:620-661`):**
  1. `repo = ReadOnlyLegacyRepo(root=source_root)` — read-only handle; every write method RAISES `ReadOnlyViolationError` (`activities/ingestion.py:119-139`), REQ-LI-005.
  2. `walk_and_reconstruct(...)` (`activities/ingestion.py:362-400`): iterate sorted files, skip non-ingestible extensions (`_INGESTIBLE_EXT` = the `_EXT_CONFIDENCE` keys + `.cob .cbl .nsd .nsm .bas .frm .vb` — `activities/ingestion.py:353-355`), read each `"r"`, collect safety-classifier domain hits (`classify_safety_domains` keys on generic crypto tokens — `activities/ingestion.py:149-193`), build one `ReconstructedObligation` per file (ref = `f"{rel_path}:module"`, provenance `reverse_engineered`, deterministic `confidence` = extension band ± content-hash dither clamped [0,1] — `activities/ingestion.py:224-267`; `needs_confirmation = confidence < confidence_floor`). Stops after `max_files` (5000).
  3. `route_safety_classifier_hits(domains, profile_id, enabled=route_classifier_hits)` (`activities/ingestion.py:559-595`): for each domain hit, if `enabled` route through the **existing** agent-runtime FedRAMP fail-closed `resolve_provider_and_tier`/`select_fallback_provider` surface → `(domain, original_provider, fallback_or_'human')`; if `enabled=False`, surface-only `(domain, "", "human")`. **A routing failure re-raises as `SafetyClassifierError` (non-retryable) — never a silent pass** (`activities/ingestion.py:585-593`).
  4. Returns a flat `IngestLegacySourceResult` (`activities/ingestion.py:296-324,651-661`): `obligations` (tuple), `obligations_total`, `low_confidence_count` (= count of below-floor), `file_count`, `classifier_domains`, `write_attempts_refused` (=0 in the happy path), `classifier_routes`.
- **GOTCHA:** the frozen contract types (`ReconstructedSpec`/`IngestionReport`) are deliberately **not** returned across the activity boundary because they carry a `metadata: dict[str, object]` field Temporal's data converter cannot rehydrate into `object`; a flat projection is returned instead (`activities/ingestion.py:298-313,648-650`). The workflow only ever touches `ingest_result.obligations`, `.classifier_domains`, `.obligations_total`, `.low_confidence_count`.

### Call 2 — `enroll_reconstructed_obligations` (`ingestion.py:203-213`)
- **Activity fn:** `olympus_workflows.activities.ingestion_drift.enroll_reconstructed_obligations` (`activities/ingestion_drift.py:142-163`), decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`.
- **Args:** single `EnrollReconstructedInput(app_id, spec_artifact=f"reconstructed-spec:{app_id}", obligations=list(ingest_result.obligations))`. `citations` omitted → default `[]` (`activities/ingestion_drift.py:80`).
- **Retry policy:** `RETRY_POLICIES["transient"]` = `HTTP_RETRY_POLICY` (3 attempts, 1s→15s, x2). No explicit non-retryable list.
- **Timeout:** `start_to_close_timeout=timedelta(seconds=60)`. No heartbeat.
- **`activity_id`:** `f"drift-enroll-{input.app_id}"`.
- **What the activity does (`activities/ingestion_drift.py:113-163`):** maps each `ReconstructedObligation` → `DriftObligation(spec_artifact, element=obligation.ref, kind="reverse_engineered", optional=obligation.needs_confirmation)` (`activities/ingestion_drift.py:43-62`), builds `_Citation` rows from the (empty) citations, runs the **existing** pure `evaluate_drift(drift_obligations, citations, app_id=app_id)` engine (`olympus_workflows.drift.evaluate_drift`), and returns a flat `EnrollReconstructedResult`: `obligations_total` (= count enrolled — proves enrollment), `obligations_satisfied`, `coverage_gap_count`, `blocking_count`, `verdict`.
- **GOTCHA (REQ-LI-004 ↔ REQ-LI-003):** a sub-floor (`needs_confirmation=True`) obligation enrolls with `optional=True` → **ADVISORY** in drift; an unmet optional obligation never fails the drift verdict (`activities/ingestion_drift.py:54-62`; drift `blocking = not optional` — `drift.py:134-135,302`). So a low-confidence obligation cannot silently become a blocking build gate before human confirmation.
- **GOTCHA:** the workflow only reads `drift_result.obligations_total` (→ `drift_enrolled` in the result, `ingestion.py:232`); it ignores `verdict`/`blocking_count`/`obligations_satisfied`/`coverage_gap_count`. The enroll is enrollment-only at this stage (no citations yet → all obligations are coverage gaps, but only above-floor ones are blocking; the workflow does not act on the verdict).

### No child workflows
There are **zero** `execute_child_workflow` / `start_child_workflow` calls. This is a leaf per-app workflow; it is not a parent and (from this file) does not itself get launched by a parent — capture that a rebuild must not add fan-out.

---

## 6. GATE HANDLING

**There is no Temporal gate-PR flow in this workflow.** Contrast with `LineWorkflowBase` (`_base-workflow.md`): no `_create_gate_pr`, no `_submit_gate_evidence`, no `check_gate_criteria`, no `_wait_for_gate_decision`, no `gate_approved`/`gate_rejected` signals, no `_reconcile_and_merge_with_retry_loop`, no `_rework_iterations` counters. **A rebuild must NOT add any of these.**

The "gate" here is the **human-confirmation gate (REQ-LI-004)** implemented entirely in-workflow:

1. **Evidence assembly:** none via git/PR. The "evidence" is the reconstructed obligation set carried on `ingest_result`, and the live status is exposed via the `obligation_gate_status` query (§2.3). No PR is created; no `submit_gate_evidence` activity runs.
2. **The wait:** `run()` blocks on `workflow.wait_condition(lambda: self._all_confirmed() or self._cancelled)` (`ingestion.py:221-223`), only entered when `not self._all_confirmed()` (`ingestion.py:219`).
3. **Routing of outcomes:**
   - **Confirm path (approve-equivalent):** each `confirm_obligation(ref)` signal adds `ref` to `_confirmed_refs`. Once every sub-floor ref is confirmed, `_all_confirmed()` → True, the wait wakes, and the run completes with `status="completed"`. The now-confirmed refs are counted into `gateable_count` (`ingestion.py:233`) so downstream they may gate a build.
   - **Cancel path (reject/abort-equivalent):** `cancel()` sets `_cancelled=True`; the wait wakes; terminal `status="cancelled"` (`ingestion.py:225`). Sub-floor obligations that were never confirmed remain **non-gateable** (excluded from `_gateable_refs`), so a cancelled run cannot produce a fully-gateable obligation set.
   - **No merge-blocked / no rework loop:** there is no merge, no `merge_blocked` state, and **no rework counter loop**. The only loop is the implicit re-evaluation of the single `wait_condition` predicate as confirm signals arrive; there is no bounded rework-iteration counter (`_rework_iterations`/`_bump_rework` do not exist here).
4. **The G-RE-1 / G-RE-2 contract gates** (`reverse-engineering.yaml`): `G-RE-1` Reconstruction Review (`reverse-engineering.yaml:49-50,149-161`, `role: pre-review`) and `G-RE-2` Obligation Confirmation (`reverse-engineering.yaml:51-52,166-181`, `role: rollup`, `summary: true`). The workflow's confirm/cancel/query surface corresponds to the *intent* of G-RE-2 (obligation confirmation) but is **not wired to the gate service** in this workflow code — it's an in-memory signal gate. Capture this as the workflow↔contract divergence.

---

## 7. RESILIENCE

- **Timeouts:** Call 1 `start_to_close=120s`; Call 2 `start_to_close=60s` (`ingestion.py:193,210`). No `schedule_to_close`, no `schedule_to_start`, no `heartbeat_timeout` on either call — these are short, non-heartbeating activities.
- **Heartbeats:** none. Neither activity heartbeats; the read-only walk is expected to finish inside 120s (bounded by `max_files=5000`).
- **Retries:** both use `transient` = `HTTP_RETRY_POLICY` (3 attempts, exp backoff 1→15s ×2). **Non-retryable failures** (`ReadOnlyViolationError`, `SafetyClassifierError`) surface from the `@foundry_activity` decorator as non-retryable → the run fails immediately without exhausting the 3 attempts. **There is no `try/except` in `run()`** — a non-retryable activity failure propagates and fails the workflow run (the intended "never a silent pass" behavior, `ingestion.py:20,172-174`).
- **Continue-as-new:** **none.** No `workflow.continue_as_new`. The human-confirmation wait can block indefinitely (no timer, no timeout on `wait_condition`); the run stays open until all confirmations arrive or `cancel` fires. **GOTCHA:** an ingestion with many sub-floor obligations that are never confirmed and never cancelled will remain a live workflow forever (there is no auto-timeout on the gate) — this is deliberate (a human gate), but a rebuild must NOT add a timer that auto-completes it.
- **Idempotency:** deterministic `activity_id`s (`ingest-{app_id}`, `drift-enroll-{app_id}`) key each activity per app so replays reuse the same activity identity. The two state assignments (`_classifier_domains`, `_obligation_needs_confirmation`) derive purely from the (replay-stable) activity result, so replay is deterministic. `confirm_obligation`/`cancel` are idempotent (set-add / bool-set).
- **Compensation / rollback:** **none.** Ingestion is read-only (`ReadOnlyLegacyRepo` refuses all writes — `activities/ingestion.py:118-139`, REQ-LI-005), so there is nothing to roll back. Drift enrollment is additive; there is no undo path. A cancelled run simply returns `status="cancelled"` and leaves whatever the enroll activity already recorded.
- **Determinism (`ingestion.py:10-14`):** no `workflow.now()`, no `workflow.patched()`, no random, no direct IO in the workflow body — unlike `LineWorkflowBase` which uses `_now_iso()`/`workflow.patched(...)` extensively. A rebuild must keep the workflow body free of clock/patch/IO.

---

## 8. GOTCHA index (consolidated)

- **G1 — Not a `LineWorkflowBase` subclass** (`ingestion.py:91`). No inherited gate/dispatch/commit machinery, no `get_status` query, no HIL signals. Self-contained.
- **G2 — Only two activities, sequential** (`ingestion.py:184,203`). No agents, no git, no gate service, no child workflows, no `asyncio.gather`.
- **G3 — `_status` has no query reader** (`ingestion.py:104,220,226`). Set but externally unobservable via query; keep for fidelity.
- **G4 — Signal-before-state race is safe** (`ingestion.py:97-101,111`). Confirms buffered in a set apply once `_obligation_needs_confirmation` lands after Call 1.
- **G5 — Cancel does not abort activities** (§2.2). Only short-circuits the human wait; both activities always run first.
- **G6 — `_all_confirmed()` is vacuously True with zero/all-above-floor obligations** (`ingestion.py:156-163`) → the wait block is skipped and the run completes immediately.
- **G7 — Terminal ternary reads `_cancelled` even when the wait was skipped** (`ingestion.py:225`); a cancel landing anytime before the return yields `"cancelled"`.
- **G8 — `_cancelled` wins over confirmation in the terminal ternary** if both become true (`ingestion.py:222,225`).
- **G9 — `max_files=5000` default is NOT passed by the workflow** (`ingestion.py:186-192`); relies on the activity input default (`activities/ingestion.py:292`).
- **G10 — Sub-floor → `optional=True` in drift = advisory, never blocking** (`activities/ingestion_drift.py:54-62`) — the REQ-LI-004↔003 tie: low-confidence obligations can't silently gate a build.
- **G11 — Workflow ignores the drift `verdict`/`blocking_count`** (`ingestion.py:232`); only `obligations_total` is consumed as `drift_enrolled`.
- **G12 — Contract gates G-RE-1/G-RE-2 are NOT implemented as gate PRs here** (`reverse-engineering.yaml:48-52,149-181`); the workflow's gate is the confirm-signal wait — workflow↔contract divergence.
- **G13 — Reverse-Engineering line is additive, NOT an `AssemblyLine` enum member** (`reverse-engineering.yaml:10-17`); no `ASSEMBLY_LINE` classvar on the workflow.
- **G14 — Non-retryable activity errors fail the run with no try/except** (`ingestion.py:184-196`, no wrapper); intended "never a silent pass."
- **G15 — No continue-as-new / no gate auto-timeout** (§7); the human gate can block the run indefinitely.
- **G16 — Frozen contract types deliberately kept off the activity wire** (`activities/ingestion.py:298-313`; `activities/ingestion_drift.py:96-103`) because of the `dict[str, object]` metadata field; flat projections cross the boundary.

---

## 9. Behavioral parity checklist

A rebuild is behaviorally correct iff ALL of the following hold:

1. **Class shape:** `IngestionWorkflow` is a bare `@workflow.defn` class (no base-workflow inheritance); its complete signal/query surface is exactly `{confirm_obligation, cancel}` (signals) + `{obligation_gate_status}` (query). No `get_status`, no `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry`.
2. **State init:** `_obligation_needs_confirmation={}`, `_confirmed_refs=set()`, `_cancelled=False`, `_classifier_domains=()`, `_status="running"`; no `super().__init__()`.
3. **Two activities, in order, sequential:** `ingest_legacy_source` (120s, transient/3-attempt, `activity_id="ingest-{app_id}"`, `max_files` unset→5000) then `enroll_reconstructed_obligations` (60s, transient, `activity_id="drift-enroll-{app_id}"`, `spec_artifact="reconstructed-spec:{app_id}"`, `citations=[]`). No agents/git/gates/child-workflows.
4. **Post-ingest state:** `_classifier_domains == tuple(ingest_result.classifier_domains)`; `_obligation_needs_confirmation == {o.ref: o.needs_confirmation for o in ingest_result.obligations}`; assigned exactly once, only from the ingest result.
5. **Gate skip:** given all obligations above-floor (or zero obligations), `run()` never sets `_status="awaiting_confirmation"`, never awaits, and returns `status="completed"` (assuming no cancel).
6. **Gate wait:** given ≥1 sub-floor obligation, `_status` becomes `"awaiting_confirmation"` and the run blocks until each sub-floor ref receives a `confirm_obligation` signal (then completes) OR a `cancel` (then cancels).
7. **`_gateable_refs` semantics:** above-floor ref → always gateable; sub-floor ref → gateable iff in `_confirmed_refs`; else excluded. `gateable_count` in the result equals `len(_gateable_refs())` computed at return time.
8. **`obligation_gate_status` shape:** returns exactly `{below_floor, confirmed, gateable, blocked, classifier_domains}`, each list sorted (except `classifier_domains` which is `list(_classifier_domains)` in insertion/tuple order), with `blocked == sorted(set(below_floor) - _confirmed_refs)`.
9. **Terminal status:** `status = "cancelled" if _cancelled else "completed"`, computed unconditionally after the (possibly-skipped) wait; `_cancelled` beats confirmation when both are set.
10. **Result fields:** `obligations_total`/`low_confidence_count`/`classifier_domains` mirror the ingest result; `drift_enrolled == drift_result.obligations_total`; `gateable_count == len(_gateable_refs())`.
11. **Read-only + fail-closed:** a write attempt against the legacy tree raises `ReadOnlyViolationError`; an un-routable safety-classifier hit raises `SafetyClassifierError`; both are non-retryable and fail the workflow run (no `try/except` swallows them).
12. **Drift advisory:** a sub-floor obligation enrolls into drift as `optional=True` (advisory, non-blocking); an above-floor obligation enrolls as required (blocking).
13. **No clock/patch/IO/random in the workflow body; no continue-as-new; no auto-timeout on the confirmation gate; no compensation/rollback.**
14. **Confirm buffering:** a `confirm_obligation` signal delivered before `_obligation_needs_confirmation` is populated is retained and takes effect once the map lands (set-based buffering).
