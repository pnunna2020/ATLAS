# DataWorkflow — Atomic Regeneration Spec

**Source:** `temporal/olympus_workflows/workflows/data.py` (1–1727)
**Class:** `DataWorkflow(LineWorkflowBase)` decorated `@workflow.defn` (`data.py:271-272`)
**Gate:** G-DT (Data Architecture Review)
**Grain:** one workflow instance per *target* application. For Refactor/Rearchitect/Replatform/Retain target==source; for Replace target is net-new; for Consolidate target is anchor source + peers (`data.py:1-8`).
**Base machinery:** see `_base-workflow.md`. This doc fully captures DataWorkflow's own state, signal handlers, `run()`/`_execute_data()` body, overrides (`_dispatch_agent`, `_build_evidence_data`, `_run_agent_step`, `_wait_for_target_provisioned`, `_fire_data_ready_signal`, `_create_gate_pr_data`, `_collect_committed_paths`, helpers) and cites base behavior it inherits.

---

## 0. Module-level constants, helpers, and step tables

### 0.1 Handshake polling bounds (`data.py:138-145`)
- `_TARGET_PROVISIONED_WAIT_TIMEOUT_SECONDS = 24 * 60 * 60` = 86400 (`data.py:138`). Overall cap for step-0 wait.
- `_REGISTRY_POLL_INTERVAL_SECONDS = 15` (`data.py:139`). Poll cadence in the `arch-data-registry-v1` (pre-signal-first) branch.
- `_DB_BACKSTOP_INTERVAL_SECONDS = 5 * 60` = 300 (`data.py:145`). DB-backstop interval under `arch-data-signal-first-v1`. GOTCHA: these are **duplicated** from `architecture.py` deliberately (not cross-imported) so the data module has no cross-workflow dependency (`data.py:134-137`). A rebuild must keep them numerically in sync with the Architecture side.

### 0.2 `_encode_data_ready_payload(payload: DataReadyForTargetSignal) -> str` (`data.py:148-157`)
`json.dumps` of exactly these 4 keys in this order: `target_app_id`, `data_architecture_ref`, `data_migration_plan_ref`, `approved_at` (`data.py:151-156`). Used only by `_fire_data_ready_signal` when publishing to the registry.

### 0.3 `_decode_target_provisioned_payload(payload_json: str) -> dict` (`data.py:160-174`)
- If `payload_json` is falsy → return `{}` (`data.py:167`).
- `try: parsed = json.loads(payload_json)`; `except (ValueError, TypeError): return {}` (`data.py:168-171`).
- If `parsed` is not a `dict` → return `{}` (`data.py:172-173`).
- Else return `parsed`. GOTCHA: malformed/empty payload silently degrades to `{}`; caller then keeps whatever in-memory state the signal handler / LineWorkflowInput already set.

### 0.4 `DATA_STEPS: dict[str, dict]` (`data.py:184-246`)
Ordered step definition table (`step_id -> {title, skill_id, artifact, kind, [write_to_target], [dispatch_via]}`). GOTCHA: iteration order of this dict is load-bearing — `_collect_committed_paths` and `_build_evidence_data` iterate it (`data.py:1603,1648`), and the PR body lists steps in this order (`data.py:1661`).

| step_id | title | skill_id | artifact | kind | flags |
|---|---|---|---|---|---|
| `domain-discovery` | Data Domain Discovery | `data-domain-patterns` | `data-domains.json` | agent | — (`data.py:193-198`) |
| `shared-db-analysis` | Shared Database Analysis | `decomposition-patterns` | `shared-db-analysis.json` | agent | — (`data.py:199-204`) |
| `decomposition-strategy` | Decomposition Strategy | `decomposition-patterns` | `decomposition-strategy.json` | agent | — (`data.py:205-210`) |
| `migration-planning` | Migration Planning | `data-migration-planner` | `data-migration-plan.json` | agent | `write_to_target=True` (`data.py:211-217`) |
| `data-product-design` | Data Product Design | `data-product-specification` | `data-product-design.json` | agent | `write_to_target=True` (`data.py:218-224`) |
| `data-synthesis` | Data Architecture Synthesis | `data-modeling` | `data-architecture.json` | agent | `write_to_target=True` (`data.py:225-231`) |
| `ai-pre-review` | AI Pre-Review | `gate-pre-review` | `pre-review.json` | agent | `dispatch_via="base_gate_pre_review"` (`data.py:239-245`) |

GOTCHA (`data.py:232-245`): `ai-pre-review` is present **only** so the gate-card registry matches `LineContract.evidence_steps()` and the contract-compliance CI guard passes. It is dispatched via base `_run_gate_pre_review` (task_type `gate-pre-review`, skill_id `gate-pre-review`), **NOT** via the per-step `_run_agent_step` path, so it never lands in `self._step_results` and never gets an artifact committed under `data/{app}/pre-review.json`.

### 0.5 `STEP_WEIGHTS: dict[str, float]` (`data.py:249-266`)
Progress weights; **must sum to 100.0** (module-load `assert abs(sum - 100.0) < 0.01`, `data.py:264-266`). GOTCHA: `wait-for-target-provisioned`, `commit-data-artifacts`, `create-g-dt-pr`, `merge-data-pr`, `persist-data-side-effects` are progress-only step keys — they do **not** appear in `DATA_STEPS`.

| step | weight |
|---|---|
| wait-for-target-provisioned | 2.0 |
| domain-discovery | 10.0 |
| shared-db-analysis | 12.0 |
| decomposition-strategy | 12.0 |
| migration-planning | 14.0 |
| data-product-design | 10.0 |
| data-synthesis | 14.0 |
| commit-data-artifacts | 2.0 |
| create-g-dt-pr | 2.0 |
| ai-pre-review | 4.0 |
| gate-review-dt | 14.0 |
| persist-data-side-effects | 2.0 |
| merge-data-pr | 2.0 |

### 0.6 `MAX_REWORK_ITERATIONS = 3` (`data.py:268`)
Rework cap for G-DT; the loop fails when `_rework_count("G-DT") > 3` (`data.py:1019`), i.e. a 4th rejection fails the workflow.

### 0.7 Class configuration attrs (`data.py:283-289`)
`ASSEMBLY_LINE = AssemblyLine.DATA`, `ARTIFACT_ROOT = "data"`, `LINE_LABEL = "Data"`, `STATUS_PREFIX = "data"`, `STEPS = DATA_STEPS`, `STEP_WEIGHTS = STEP_WEIGHTS`, `SINGLE_GATE_KEY = "G-DT"`. These drive base helpers: `_set_step` writes status `data_in_progress` (`base.py:375`); `_rework_gate_key_for_step` returns `"G-DT"` for every step (`base.py:279`); `_execution_ctx` emits `line_id="data"` (`base.py:351`).

---

## 1. STATE (instance variables)

### 1.1 Inherited from `LineWorkflowBase.__init__` (`base.py:136-191`) — set via `super().__init__()` at `data.py:292`
| attr | type | initial | mutated by / when |
|---|---|---|---|
| `_app_id` | str | `""` | set to `target_app_id` at `run()` (`data.py:450`); read by `target_provisioned` handler, `_wait_for_target_provisioned`, `_fire_data_ready_signal` |
| `_portfolio_id` | str | `""` | set from `input.portfolio_id` at `run()` (`data.py:451`) |
| `_wave_id` | str | `""` | set from `input.wave_id` at `run()` (`data.py:452`) |
| `_status` | WorkflowStatus | `PENDING` | RUNNING at run entry (`data.py:442`); FAILED on except (`data.py:493`); COMPLETED on system/Retire skip & success (`data.py:740,756,1005`); CANCELLED on Tier-1 cancel (`data.py:923`) |
| `_current_step` | str | `""` | set by `_set_step` and terminal blocks (`"failed"`, `"completed"`, `"max-rework-exceeded"`) |
| `_progress_pct` | float | 0.0 | set by `_set_step`; forced 100.0 on completion (`data.py:741,757,1006`) |
| `_pending_gate` | GateType\|None | None | set/cleared by base `_wait_for_gate_decision` |
| `_started_at` | str | `""` | ISO set at run entry (`data.py:443`) |
| `_updated_at` | str | `""` | refreshed by `_now_iso()` at many mutation points |
| `_gate_decisions` | list[tuple] | `[]` | appended by base `gate_approved`/`gate_rejected` handlers (5-tuples) |
| `_gate_decisions_consumed` | int | 0 | incremented by base `_wait_for_gate_decision` |
| `_rework_feedback` | dict[str,dict] | `{}` | set on reject / popped on approve by base `_wait_for_gate_decision`; read by DataWorkflow `_dispatch_agent` under key `"G-DT"` (`data.py:1458`) |
| `_rework_iterations` | dict[str,int] | `{}` | via `_bump_rework`/`_rework_count` for `"G-DT"` |
| `_step_results` | dict[str,list[str]] | `{}` | set per step in `_run_agent_step` (`data.py:1080`); read for persist refs & evidence |
| `_step_committed_paths` | dict[str,list[str]] | `{}` | set by base `_commit_step_artifacts` (`base.py:872`); read by `_collect_committed_paths` |
| `_agent_metadata` | dict[str,dict] | `{}` | set in `_dispatch_agent` (`data.py:1571-1578`) |
| `_risk_tier` | int\|None | None | set from `input.risk_tier` at run (`data.py:453`); gates Tier-1 triple-signal & PR body |
| `_merge_retry_signalled` | bool | False | flipped by base `merge_retry` handler; consumed by `_reconcile_and_merge_with_retry_loop` |
| `_profile_id` | str | `""` | (base delegation; DataWorkflow does not call `_load_delegation_config`) |
| `_portfolio_fallback_policy` | str | `"internal_fallback"` | unused here |
| `_redispatch_guard` | set | `set()` | unused here |
| `cancelled` | bool | False | attribute from the base signals mixin, flipped True by `cancel_workflow` signal (`temporal_base/signals.py:84-86`); read by `_wait_for_target_provisioned`, `_wait_for_gate_decision`, Tier-1 wait, merge loop |

### 1.2 DataWorkflow-own state (`__init__`, `data.py:291-347`)
| attr | type | initial | mutated by / when | purpose |
|---|---|---|---|---|
| `_stakeholder_data_governance_approved` | bool | `False` (`data.py:296`) | True by `stakeholder_approved` when `scope=="g-dt-data-governance"` (`data.py:364`); reset False before each rework (`data.py:1015`) | Tier-1 triple-signal component |
| `_stakeholder_security_approved` | bool | `False` (`data.py:297`) | True by `stakeholder_approved` when `scope=="g-dt-security"` (`data.py:366`); reset False before each rework (`data.py:1016`) | Tier-1 triple-signal component |
| `_target_provisioned` | bool | `False` (`data.py:300`) | True by `target_provisioned` handler (`data.py:410`) or by registry hit in `_wait_for_target_provisioned` (`data.py:1195,1259`) | step-0 gate flag |
| `_architecture_workflow_id` | str | `""` (`data.py:301`) | set by signal handler (`data.py:411`) or registry payload (`data.py:1196,1260`) | reply-signal fast-path target + evidence field |
| `_provisioned_portfolio_id` | str | `""` (`data.py:302`) | signal (`data.py:412`) / registry (`data.py:1199,1263`) | observability only |
| `_provisioned_wave_id` | str | `""` (`data.py:303`) | signal (`data.py:413`) / registry (`data.py:1202,1266`) | observability only |
| `_provisioned_disposition` | str | `""` (`data.py:304`) | signal (`data.py:414`) / registry (`data.py:1203,1267`) | **Retire-skip branch driver** (`data.py:748`) |
| `_provisioned_target_repo_url` | str | `""` (`data.py:310`) | signal (`data.py:417-419`) / registry (`data.py:1206-1208`) | mirror-repo for `write_to_target` steps |
| `_target_service_id` | str | `""` (`data.py:321`) | input (`data.py:463`), signal if non-empty (`data.py:424-426`), registry if non-empty (`data.py:1212-1216`), plan if empty (`data.py:632-635`) | `"system"` umbrella-skip driver; forwarded to persist activity |
| `_relationship` | str | `""` (`data.py:324`) | input (`data.py:464`), signal (`data.py:427-429`), registry (`data.py:1217-1221`), plan lowered (`data.py:636-639`) | Build detection; threaded into agent context |
| `_is_build` | bool | `False` (`data.py:332`) | `str(_relationship).strip().lower()=="build"` at run (`data.py:471`) then refreshed from plan (`data.py:644-646`) | greenfield optional-priors path in `_dispatch_agent` |
| `_source_app_ids` | list[str] | `[]` (`data.py:337`) | input (`data.py:465-467`), signal (`data.py:430-432`), registry (`data.py:1222-1226`), plan if empty (`data.py:647-650`) | many-to-one consolidate context |
| `_target_plan_entry` | dict | `{}` (`data.py:342`) | set by `_load_target_plan_entry` (`data.py:628`) | plan lookup for umbrella-skip + dispatch context |
| `_tech_fingerprint` | dict\|None | `None` (`data.py:347`) | set from `input.tech_fingerprint` at run (`data.py:457`) | step-5 data-product-design skill router |

GOTCHA (`data.py:435-436`, from signal handler): the workflow also references `self._input` via `getattr(self, "_input", None)` in base `_dispatch_agent`, but DataWorkflow **overrides** `_dispatch_agent` and never sets `self._input`; the override does not consult fixture_scenarios (see §4.6).

---

## 2. SIGNALS & QUERIES

### 2.1 `stakeholder_approved(signal: StakeholderApprovedSignal)` — `@workflow.signal` (`data.py:353-372`)
- If `signal.scope == "g-dt-data-governance"` → `_stakeholder_data_governance_approved = True` (`data.py:363-364`).
- elif `signal.scope == "g-dt-security"` → `_stakeholder_security_approved = True` (`data.py:365-366`).
- else → `workflow.logger.warning("stakeholder_approved with unrecognized scope", extra={"scope": ...})` and ignore (`data.py:367-371`).
- Always: `_updated_at = _now_iso()` (`data.py:372`).
- **Consumed by** the Tier-1 `wait_condition` at `data.py:913-921`: `(_stakeholder_data_governance_approved and _stakeholder_security_approved) or self.cancelled`.
- GOTCHA: flags are reset to False on every rework (`data.py:1015-1016`) so a prior cycle's approvals never leak into a later attempt.

### 2.2 `target_provisioned(signal: TargetProvisionedSignal)` — `@workflow.signal` (`data.py:374-433`)
- **First** `await workflow.wait_condition(lambda: bool(self._app_id))` (`data.py:397`). GOTCHA: this exists to avoid a race where a signal arrives between `start_workflow` and `run()` setting `_app_id`; without it `_app_id==""` and the mismatch check drops the signal (Wave-1 bug, `data.py:394-396`).
- If `signal.target_app_id != self._app_id` → log info `"target_provisioned ignored — wrong target"` and **return** (do not mutate) (`data.py:398-409`).
- Else set: `_target_provisioned=True` (`data.py:410`), `_architecture_workflow_id=signal.architecture_workflow_id` (`data.py:411`), `_provisioned_portfolio_id=signal.portfolio_id`, `_provisioned_wave_id=signal.wave_id`, `_provisioned_disposition=signal.disposition` (`data.py:412-414`).
- `_provisioned_target_repo_url = getattr(signal,"target_repo_url","") or ""` (`data.py:417-419`) — empty means sender predates PR A3.
- `sig_service_id = getattr(signal,"target_service_id","") or ""`; if truthy → set `_target_service_id` (`data.py:424-426`). Same conditional-overwrite pattern for `relationship` (`data.py:427-429`) and `source_app_ids` (`data.py:430-432`). GOTCHA: empty signal fields do **not** clear values already set from LineWorkflowInput.
- `_updated_at=_now_iso()` (`data.py:433`).
- **Consumed by** `_wait_for_target_provisioned` via the `self._target_provisioned` predicate (all three branches, §4.4).
- GOTCHA (design, `data.py:378-391`): under `arch-data-registry-v1` this handler is a belt-and-braces fast path — Data normally polls the registry — but it is retained so pre-patch in-flight histories replay deterministically. **MUST NOT be dropped**: removing it would break replay of old histories that delivered via Temporal signal.

### 2.3 Inherited signal handlers (base — **DO NOT override**, `base.py:194-257`)
- `gate_approved(GateApprovedSignal)` → appends 5-tuple `(APPROVED, approved_by, justification, None, [])` (`base.py:197-209`).
- `gate_rejected(GateRejectedSignal)` → appends `(REJECTED, rejected_by, reason, reason_category, card_decisions)` (`base.py:211-232`).
- `escalation_resolved(EscalationResolvedSignal)` → refreshes `_updated_at` only (`base.py:234-239`).
- `merge_retry(GateMergeRetrySignal)` → `_merge_retry_signalled=True` (idempotent) (`base.py:241-257`).
- `cancel_workflow()` (base signals mixin) → `cancelled=True` (`temporal_base/signals.py:83-86`).
- GOTCHA: base comment `# Signal handlers — decorated here, DO NOT redefine in subclasses.` (`base.py:194-195`). DataWorkflow correctly adds only NEW signal names (`stakeholder_approved`, `target_provisioned`) and never redefines these.

### 2.4 Query — `get_status() -> WorkflowStatusResponse` (base, `@workflow.query`, `base.py:1353-1365`)
Returns workflow_id, `_status`, `current_line=AssemblyLine.DATA`, `_current_step`, `_progress_pct`, `_pending_gate`, `_started_at`, `_updated_at`. DataWorkflow does not override it.

---

## 3. CONTROL FLOW — `run()` (`data.py:439-502`)

```
@workflow.run
async def run(self, input: LineWorkflowInput) -> str:
    self._status = RUNNING                                   # data.py:442
    self._started_at = _now_iso(); self._updated_at = _started_at   # 443-444
    target_app_id = input.app_id                             # 449 (app_id IS the target)
    self._app_id = target_app_id                             # 450
    self._portfolio_id = input.portfolio_id                  # 451
    self._wave_id = input.wave_id                            # 452
    self._risk_tier = getattr(input, "risk_tier", None)      # 453
    self._tech_fingerprint = getattr(input, "tech_fingerprint", None)  # 457
    self._target_service_id = getattr(input,"target_service_id","") or ""   # 463
    self._relationship = getattr(input,"relationship","") or ""             # 464
    self._source_app_ids = list(getattr(input,"source_app_ids",[]) or [])   # 465-467
    self._is_build = str(self._relationship).strip().lower() == "build"     # 471
    self._artifact_repo = input.artifact_repo                # 480
    wf_id = workflow.info().workflow_id                      # 481
    run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]     # 482
    branch = f"olympus/data/{target_app_id}/{run_suffix}"    # 483
    workspace_key = f"data-{target_app_id}-{run_suffix}"     # 484
    try:
        return await self._execute_data(input, target_app_id, "", branch, workspace_key)  # 489-491
                                                              # repo passed as "" — resolved inside
    except Exception:                                         # 492
        self._status = FAILED                                 # 493
        self._current_step = "failed"                         # 494
        self._updated_at = _now_iso()                         # 495
        try:
            await self._update_app_status(target_app_id, "data_failed", "failed", "Data")  # 497-499
        except Exception:
            pass  # best-effort                               # 500-501
        raise                                                 # 502
```

GOTCHA (`data.py:481-483`): `_artifact_repo` is set directly here; `_resolve_commit_repo` is mentioned in comments but the actual repo used for commits is resolved inside `_execute_data` as `repo = self._artifact_repo` (`data.py:708`) — target-scoped deliverables are *mirrored* (not primary-committed) to the modernization repo. GOTCHA: the outer `except Exception` catches everything including a rework-exhaust that already returned `"failed"` (no exception) — the FAILED-status terminal blocks inside `_execute_data` return strings, they don't raise, so this handler only fires on genuine exceptions.

---

## 3b. CONTROL FLOW — `_execute_data()` (`data.py:666-1045`)

```
async def _execute_data(input, target_app_id, repo, branch, workspace_key) -> str:
    running_progress = 0.0                                    # 675
    prior_inputs = list(input.prior_artifacts)                # 676

    # --- source-artifacts-index merge (patch-gated) ---
    if workflow.patched("data-source-index-v1"):              # 683
        indexed_paths = await self._read_target_source_artifacts_index(input, target_app_id)  # 684
        if indexed_paths:                                     # 687
            seen = set(prior_inputs)
            for p in indexed_paths:
                if p not in seen:
                    prior_inputs.append(p); seen.add(p)       # 689-692  (dedup-append)

    # --- Step 0: wait-for-target-provisioned ---
    await self._set_step("wait-for-target-provisioned", running_progress)   # 698-700
    await self._wait_for_target_provisioned()                 # 701
    running_progress += 2.0                                   # 702

    repo = self._artifact_repo                                # 708  (portfolio artifact_repo)

    await self._load_target_plan_entry(input, target_app_id)  # 717  (STRICT-FAIL, see §4.2)

    # --- system-umbrella skip ---
    if (self._target_service_id == "system"
        or self._target_plan_entry.get("target_service_id") == "system"):   # 726-729
        await self._fire_data_ready_signal(data_architecture_ref="", data_migration_plan_ref="")  # 730-733
        await self._update_app_status(target_app_id, "data_skipped_system_umbrella", "completed", "Data")  # 734-739
        self._status = COMPLETED; self._progress_pct = 100.0
        self._current_step = "completed"; self._updated_at = _now_iso()     # 740-743
        return "completed"                                    # 744

    # --- Retire skip ---
    if self._provisioned_disposition == "Retire":            # 748
        await self._fire_data_ready_signal("", "")           # 749-752
        await self._update_app_status(target_app_id, "data_skipped_retire", "completed", "Data")  # 753-755
        self._status = COMPLETED; self._progress_pct = 100.0
        self._current_step = "completed"; self._updated_at = _now_iso()     # 756-759
        return "completed"                                    # 760

    # --- Steps 1+2: domain-discovery || shared-db-analysis ---
    if workflow.patched("data-parallel-fanout-v1"):           # 770
        await self._set_step("domain-discovery", running_progress)          # 771
        parallel_inputs = prior_inputs                        # 772
        dd_task  = self._run_agent_step_task("domain-discovery",  ...)      # 773-776
        sdb_task = self._run_agent_step_task("shared-db-analysis", ...)     # 777-780
        await asyncio.gather(dd_task, sdb_task)               # 781  (PARALLEL)
        running_progress += 10.0 + 12.0                       # 782-785
        prior_inputs = self._collect_committed_paths()        # 786
    else:  # legacy sequential
        await self._run_agent_step("domain-discovery", ...)   # 789-792
        running_progress += 10.0                              # 793
        prior_inputs = self._collect_committed_paths()        # 794
        await self._run_agent_step("shared-db-analysis", ...) # 796-799
        running_progress += 12.0                              # 800
        prior_inputs = self._collect_committed_paths()        # 801

    # --- Step 3: decomposition-strategy (consumes 1+2) ---
    await self._run_agent_step("decomposition-strategy", ...) # 804-807
    running_progress += 12.0                                  # 808
    prior_inputs = self._collect_committed_paths()            # 809

    # --- Steps 4+5: migration-planning || data-product-design ---
    await self._set_step("migration-planning", running_progress)   # 815
    mp_task  = self._run_agent_step_task("migration-planning",  ...)   # 816-819
    dpd_task = self._run_agent_step_task("data-product-design", ...)   # 820-823
    await asyncio.gather(mp_task, dpd_task)                   # 824  (PARALLEL, always — not patch-gated)
    running_progress += 14.0 + 10.0                           # 825-828
    prior_inputs = self._collect_committed_paths()            # 829

    # --- Step 6 + 7-12 gate loop ---
    while True:                                               # 832
        # Step 6: data-synthesis
        await self._run_agent_step("data-synthesis", ...)     # 834-837
        synthesis_progress = running_progress + 14.0          # 838-840

        # Step 7: commit-data-artifacts (logical marker only)
        await self._set_step("commit-data-artifacts", synthesis_progress)   # 845-847
        commit_progress = synthesis_progress + 2.0            # 848-850

        # Step 8: create-g-dt-pr
        artifact_paths = dedup_paths(self._collect_committed_paths())   # 853
        await self._set_step("create-g-dt-pr", commit_progress)         # 854
        pr_result = await self._create_gate_pr_data(repo, branch, target_app_id, input)  # 855-857
        pr_progress = commit_progress + 2.0                   # 858

        gate_record = await execute_activity(create_gate_record, CreateGateRecordInput(
                          gate_type="G-DT", app_id=target_app_id,
                          portfolio_id=input.portfolio_id,
                          workflow_id=workflow.info().workflow_id,
                          evidence_package_url=pr_result.pr_url),
                          start_to_close=30s, retry=transient)      # 860-871
        gate_id = gate_record.gate_id                         # 872

        await self._submit_gate_evidence(gate_id, GateType.G_DT, target_app_id,
                          artifact_paths, pr_result.pr_url, "Data",
                          "gate-review-dt", forward_risk_tier=True)  # 874-883

        # Step 9: ai-pre-review
        await self._set_step("ai-pre-review", pr_progress)    # 886
        await self._run_gate_pre_review(gate_id, "G-DT", artifact_paths,
                          artifact_repo=repo, artifact_ref=branch)  # 887-893
        pre_review_progress = pr_progress + 4.0               # 894-896

        # Step 10: gate-review-dt
        await self._set_step("gate-review-dt", pre_review_progress)  # 899
        await self._update_app_status(target_app_id, "gate_review", "gate-review-dt", "Data")  # 900-903

        decision = await self._wait_for_gate_decision(GateType.G_DT)   # 905
        if decision == "cancelled":                           # 906
            return "cancelled"                                # 907
        if decision == "approved":                            # 908
            if self._risk_tier == 1:                          # 912
                await workflow.wait_condition(lambda:
                    (self._stakeholder_data_governance_approved
                     and self._stakeholder_security_approved)
                    or self.cancelled)                        # 913-921
                if self.cancelled:                            # 922
                    self._status = CANCELLED                  # 923
                    return "cancelled"                        # 924

            # Step 11: persist-data-side-effects + fire ready signal
            gate_progress = pre_review_progress + 14.0        # 933-935
            await self._set_step("persist-data-side-effects", gate_progress)  # 936-938
            data_architecture_ref   = f"data/{target_app_id}/data-architecture.json"      # 940-943
            data_migration_plan_ref = f"data/{target_app_id}/data-migration-plan.json"    # 944-947
            architecture_json = ""; decomposition_json = ""   # 948-949
            if self._step_results.get("data-synthesis"):
                architecture_json = self._step_results["data-synthesis"][0]   # 950-953
            if self._step_results.get("decomposition-strategy"):
                decomposition_json = self._step_results["decomposition-strategy"][0]  # 954-957
            try:
                await execute_activity(persist_data_side_effects,
                    PersistDataSideEffectsInput(
                        target_app_id=target_app_id, target_name=input.app_name,
                        target_portfolio_id=input.portfolio_id,
                        data_architecture_json=architecture_json,
                        decomposition_strategy_json=decomposition_json,
                        data_architecture_ref=data_architecture_ref,
                        data_migration_plan_ref=data_migration_plan_ref,
                        decided_at=_now_iso(),
                        target_service_id=self._target_service_id),
                    start_to_close=60s, retry=transient,
                    activity_id="persist-data-side-effects")  # 958-975
            except Exception:  # BEST-EFFORT — log & continue
                workflow.logger.exception("persist_data_side_effects failed; ...")  # 976-980

            await self._fire_data_ready_signal(data_architecture_ref, data_migration_plan_ref)  # 982-985
            persist_progress = gate_progress + 2.0            # 986-989

            # Step 12: merge-data-pr
            await self._set_step("merge-data-pr", persist_progress)   # 992
            await self._reconcile_and_merge_with_retry_loop(
                repo=repo, pr_number=pr_result.pr_number,
                gate_id=gate_id, merge_method="merge")        # 995-1000
            await self._update_app_status(target_app_id, "data_complete", "completed", "Data")  # 1001-1004
            self._status = COMPLETED; self._progress_pct = 100.0
            self._current_step = "completed"; self._updated_at = _now_iso()   # 1005-1008
            return "completed"                                # 1009

        # --- decision == "rejected" → rework ---
        self._stakeholder_data_governance_approved = False    # 1015
        self._stakeholder_security_approved = False           # 1016
        self._bump_rework("G-DT")                             # 1018
        if self._rework_count("G-DT") > MAX_REWORK_ITERATIONS:  # 1019  (>3)
            self._status = FAILED
            self._current_step = "max-rework-exceeded"; self._updated_at = _now_iso()  # 1020-1022
            await self._update_app_status(target_app_id, "data_failed", "max-rework-exceeded", "Data")  # 1023-1026
            return "failed"                                   # 1027

        # rework re-runs steps 1-5 sequentially (NOT step 0)
        running_progress = STEP_WEIGHTS["wait-for-target-provisioned"]  # 1032  (= 2.0)
        for step_name in ("domain-discovery","shared-db-analysis",
                          "decomposition-strategy","migration-planning",
                          "data-product-design"):             # 1033-1039
            await self._run_agent_step(step_name, target_app_id, prior_inputs,
                                       input.source_repo, workspace_key, repo, branch)  # 1040-1043
            running_progress += STEP_WEIGHTS[step_name]        # 1044
            prior_inputs = self._collect_committed_paths()     # 1045
        # loop back to `while True` → re-run data-synthesis + gate
```

GOTCHA (rework re-run, `data.py:1029-1045`): rework re-runs steps 1→5 **sequentially and unconditionally** (ignores the `data-parallel-fanout-v1` patch — parallelism is only in the first pass). `data-synthesis` (step 6) is re-run at the top of the `while` loop, not in this for-loop. `decision == "rejected"` is the implicit `else` — `_wait_for_gate_decision` returns only `"approved"`, `"rejected"`, or `"cancelled"` (`base.py:1111`), so after handling cancelled/approved the fall-through is always rejected.

GOTCHA (`data.py:838-858`): `synthesis_progress`, `commit_progress`, `pr_progress`, `pre_review_progress`, `gate_progress`, `persist_progress` are **local** running totals recomputed each loop iteration from `running_progress`; they are not stored on `self`. On rework, `running_progress` is reset to 2.0 (step-0 weight only) and steps 1-5 re-add their weights, so progress restarts partway.

---

## 4. HELPER METHODS

### 4.1 `_read_target_source_artifacts_index(input, target_app_id) -> list[str]` (`data.py:504-554`)
- If `not input.wave_id or not input.artifact_repo` → return `[]` (`data.py:518-519`).
- `index_path = f"rationalization/wave-{wave_id}/targets/{target_app_id}/source-artifacts-index.json"` (`data.py:520-523`).
- `try: execute_activity(read_artifact, ReadArtifactInput(repo=artifact_repo, branch="main", path=index_path), start_to_close=30s, retry=transient, activity_id=f"read-target-source-index-{target_app_id}")`; `except Exception: return []` (index optional) (`data.py:524-537`).
- `try: payload = json.loads(result.content)`; `except Exception: return []` (`data.py:539-542`).
- Build `paths`: for each `source` in `payload.get("source_apps",[]) or []`, `artifacts = source.get("artifacts",{}) or {}`, for `key in ("discovery","rationalization")`, for each `p` in `artifacts.get(key,[]) or []`, append if `isinstance(p,str) and p` (`data.py:544-550`). Then append each string in `payload.get("shared_artifacts",[]) or []` (`data.py:551-553`). Return `paths` (`data.py:554`).
- GOTCHA: entirely best-effort; every failure path returns `[]` so pre-index runs fall back to `input.prior_artifacts`. Called only under patch `data-source-index-v1`.

### 4.2 `_load_target_plan_entry(input, target_app_id) -> None` — STRICT-FAIL (`data.py:556-664`)
- If `not input.wave_id or not input.artifact_repo` → raise `ApplicationError(..., non_retryable=True)` (`data.py:580-585`).
- `plan_path = f"architecture/wave-{wave_id}/architecture-target-plan.json"` (`data.py:586-589`).
- `try: read_result = execute_activity(read_artifact, ReadArtifactInput(repo, "main", plan_path), start_to_close=30s, retry=transient, activity_id=f"read-data-target-plan-{target_app_id}")`; `except Exception as exc: raise ApplicationError("architecture-target-plan.json not found ...", non_retryable=True) from exc` (`data.py:590-609`).
- `try: plan = json.loads(read_result.content)`; `except Exception as exc: raise ApplicationError("... malformed JSON ...", non_retryable=True) from exc` (`data.py:611-619`).
- `plan_key = input.plan_target_key or target_app_id` (`data.py:625`). GOTCHA: plan is keyed by target **slug**; `target_app_id` is the provisioned **UUID**; coordinator threads the slug as `plan_target_key`.
- for `t` in `plan.get("targets") or []`: if `isinstance(t,dict) and t.get("target_app_id")==plan_key` (`data.py:626-627`):
  - `self._target_plan_entry = dict(t)` (`data.py:628`).
  - if `not self._target_service_id`: `_target_service_id = t.get("target_service_id") or ""` (`data.py:632-635`).
  - if `not self._relationship`: `_relationship = (t.get("relationship") or "").lower()` (`data.py:636-639`).
  - `self._is_build = str(self._relationship).strip().lower()=="build"` (`data.py:644-646`) — refreshed unconditionally from plan.
  - if `not self._source_app_ids`: `_source_app_ids = list(t.get("source_app_ids") or [])` (`data.py:647-650`).
  - **return** (`data.py:651`).
- If no match: build `target_ids_in_plan` list and raise `ApplicationError("plan_target_key=... not present in architecture-target-plan ...", non_retryable=True)` (`data.py:653-664`).
- GOTCHA: unlike the best-effort index read, this raises NonRetryable on missing/malformed/uncovered plan (`data.py:576-579`). A rebuild must NOT silently fall back — a missing plan is a deployment bug.

### 4.3 `_run_agent_step(step_name, app_id, prior_inputs, source_repo, workspace_key, repo, branch) -> None` (`data.py:1051-1098`)
```
running = self._progress_pct                                 # 1069
await self._set_step(step_name, running)                     # 1070
result = await self._dispatch_agent(app_id=app_id, step_name=step_name,
             input_artifacts=prior_inputs, source_repo=source_repo,
             workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)  # 1071-1079
self._step_results[step_name] = result.output_artifacts      # 1080
step_def = DATA_STEPS[step_name]                             # 1081
if step_def.get("artifact"):                                 # 1082
    artifact_path = f"data/{app_id}/{step_def['artifact']}"  # 1083-1085
    mirror_repo = (self._provisioned_target_repo_url
                   if step_def.get("write_to_target") and self._provisioned_target_repo_url
                   else "")                                   # 1086-1091
    await self._commit_step_artifacts(repo, branch, app_id, step_name, result,
             artifact_path, mirror_repo=mirror_repo,
             mirror_path_prefix=(f"docs/data/{step_name}" if mirror_repo else ""))  # 1092-1098
```
GOTCHA: `_set_step` reads `self._progress_pct` as `running` (`data.py:1069`) rather than a passed-in weight — under parallel `asyncio.gather` (steps 1+2, 4+5) both tasks call `_set_step` and both overwrite `_current_step`/`_progress_pct` with whatever `_progress_pct` was; the caller pre-sets it via `await self._set_step("domain-discovery"/"migration-planning", running_progress)` before gathering (`data.py:771,815`). Net effect: current-step display during parallel steps is nondeterministic between the two, but progress accounting is corrected by the explicit `running_progress += ...` after `gather`. Mirror commit only happens for `write_to_target` steps when `_provisioned_target_repo_url` is non-empty.

### 4.4 `_run_agent_step_task(...)` (`data.py:1100-1114`)
Returns the coroutine `self._run_agent_step(...)` un-awaited — used to build the two coroutines passed to `asyncio.gather` for parallel dispatch. No logic of its own.

### 4.5 `_wait_for_target_provisioned() -> None` (`data.py:1116-1313`) — THREE patch branches
**Branch A — `arch-data-signal-first-v1`** (`data.py:1137-1234`):
```
elapsed = 0
while elapsed < 86400:                                       # 1139
    if self._target_provisioned: return                      # 1142-1143
    if self.cancelled: raise RuntimeError("cancelled ...")   # 1144-1147
    remaining = 86400 - elapsed                              # 1149-1151
    this_wait = min(300, remaining)                          # 1152-1154
    try:
        await workflow.wait_condition(
            lambda: self._target_provisioned or self.cancelled,
            timeout=timedelta(seconds=this_wait))            # 1158-1164
    except asyncio.TimeoutError: pass  # backstop            # 1165-1166
    if self.cancelled: raise RuntimeError("cancelled ...")   # 1168-1171
    if self._target_provisioned: return                      # 1172-1173
    # ONE DB backstop read
    result = await execute_activity(consume_arch_data_signal,
        ConsumeArchDataSignalInput(signal_type=SIGNAL_TARGET_PROVISIONED,
            wave_id=self._wave_id, target_app_id=self._app_id,
            workflow_id=workflow.info().workflow_id),
        start_to_close=30s, retry=transient,
        activity_id="consume-target-provisioned")            # 1176-1187
    if result.found:                                         # 1188
        payload = _decode_target_provisioned_payload(result.payload_json)   # 1189-1191
        self._target_provisioned = True                      # 1195
        self._architecture_workflow_id = payload.get("architecture_workflow_id","")  # 1196-1198
        self._provisioned_portfolio_id = payload.get("portfolio_id","")     # 1199-1201
        self._provisioned_wave_id = payload.get("wave_id","")               # 1202
        self._provisioned_disposition = payload.get("disposition","")       # 1203-1205
        self._provisioned_target_repo_url = payload.get("target_repo_url","") or ""  # 1206-1208
        if payload.get("target_service_id","") or "":  set _target_service_id  # 1212-1216
        if payload.get("relationship","") or "":        set _relationship      # 1217-1221
        if list(payload.get("source_app_ids",[]) or []): set _source_app_ids   # 1222-1226
        self._updated_at = _now_iso(); return                # 1227-1228
    elapsed += this_wait                                     # 1230
raise RuntimeError("timed out waiting for target-provisioned signal (wave=... target=...)")  # 1231-1234
```
GOTCHA: `~5` DB reads for a sub-30-min Architecture completion vs. ~120 under the old 15s cadence (ATLAS Challenge 3 saw 1200+ history events, `data.py:1119-1132`). The `wait_condition` timeout expiry is caught as `asyncio.TimeoutError` and treated as a backstop trigger — a rebuild must catch exactly `asyncio.TimeoutError`.

**Branch B — `arch-data-registry-v1`** (`data.py:1235-1305`): 15s poll loop.
```
elapsed = 0
while True:                                                  # 1237
    if self._target_provisioned: return                      # 1238-1239
    result = await execute_activity(consume_arch_data_signal, ...same args...,
             start_to_close=30s, retry=transient,
             activity_id="consume-target-provisioned")        # 1240-1251
    if result.found:  # hydrate same fields as Branch A       # 1252-1292 (identical hydration block)
        ...; return                                           # 1292
    if self.cancelled: raise RuntimeError("cancelled waiting for target-provisioned registry entry")  # 1293-1297
    if elapsed >= 86400: raise RuntimeError("timed out ... registry entry (...)")   # 1298-1303
    await workflow.sleep(15)                                  # 1304
    elapsed += 15                                             # 1305
```

**Branch C — legacy (neither patch)** (`data.py:1306-1313`):
```
await workflow.wait_condition(lambda: self._target_provisioned or self.cancelled)  # 1307-1309
if self.cancelled: raise RuntimeError("cancelled waiting for target-provisioned signal")  # 1310-1313
```
GOTCHA: all three branches retained for replay determinism (`data.py:1133-1135`). The registry hydration block is duplicated verbatim between Branch A and Branch B (`data.py:1189-1228` vs `1253-1292`) — a rebuild must reproduce both.

### 4.6 `_dispatch_agent(...) -> AgentTaskResult` — OVERRIDE (`data.py:1440-1579`)
GOTCHA: overrides base `_dispatch_agent` entirely; adds `source_repo` param and does **not** run base's context-priors / fixture-scenario logic. Flow:
```
step_def = DATA_STEPS[step_name]                             # 1456
context = {}                                                 # 1457
fb = self._rework_feedback.get("G-DT")                       # 1458
if fb is not None: context["rework_feedback"] = fb           # 1459-1460
context["target_plan_entry"] = {                             # 1468-1475
    "target_app_id": app_id, "target_service_id": self._target_service_id,
    "relationship": self._relationship,
    "source_app_ids": list(self._source_app_ids),
    "target_name": self._target_plan_entry.get("target_name",""),
    "rationale": self._target_plan_entry.get("rationale","")}
skill_id = step_def["skill_id"]                              # 1482
if step_name == "data-product-design":                       # 1483
    selected = select_skill(DATA_PRODUCT_COMPOSITION,
                            data_selector_inputs(self._tech_fingerprint))  # 1487-1490
    if selected: skill_id = selected                         # 1491-1492
sonnet_data_steps = {"migration-planning","data-product-design","data-synthesis"}  # 1502-1506
model_preference = "tier-2" if step_name in sonnet_data_steps else ""   # 1507-1509
if self._is_build:                                           # 1519
    req_artifact = f"build/{app_id}/requirements/requirements-capability.json"  # 1520-1522
    required_inputs = [req_artifact]                         # 1523
    optional_inputs = [p for p in input_artifacts if p != req_artifact]  # 1524-1526
else:
    required_inputs = input_artifacts; optional_inputs = []  # 1527-1529
task_input = AgentTaskInput(
    task_type=f"data-{step_name}", app_id=app_id, skill_id=skill_id,
    input_artifacts=required_inputs, optional_input_artifacts=optional_inputs,
    source_repo=source_repo, artifact_repo=artifact_repo, artifact_ref=artifact_ref,
    workspace_key=workspace_key, context=context,
    model_preference=model_preference,
    execution_context=self._execution_ctx(step_name, app_id=app_id,
                          input_artifact_paths=required_inputs))   # 1530-1547
synthesis_steps = {"data-synthesis"}                         # 1558
activity_timeout = timedelta(hours=3) if step_name in synthesis_steps else timedelta(hours=1)  # 1559-1562
result = await execute_activity(dispatch_agent_task, task_input,
    start_to_close_timeout=activity_timeout,
    heartbeat_timeout=timedelta(minutes=2),
    retry_policy=RETRY_POLICIES["agent_failure"],
    activity_id=f"agent-{step_name}")                        # 1563-1570
self._agent_metadata[step_name] = {model_used, duration_ms, token_usage_input,
    token_usage_output, cost_estimate_usd, output_files}     # 1571-1578
return result                                                # 1579
```
GOTCHAs: (a) `data-product-design` skill is registry-selected via `select_skill(DATA_PRODUCT_COMPOSITION, ...)`; empty/None tech_fingerprint → base `data-product-specification` (`data.py:1476-1492`). (b) migration-planning/data-product-design/data-synthesis forced to `model_preference="tier-2"` (Sonnet) due to the Bedrock Opus 4.7 1M `is_error=True,subtype=success` flake (43/52 failure on migration-planning) (`data.py:1493-1509`). (c) `_is_build` reroutes required→optional so 404s degrade gracefully; requirements-capability.json is the single REQUIRED input (`data.py:1510-1529`). (d) `data-synthesis` gets 3h start_to_close (Consolidate folding 2-6 schemas — Wave-1 UAEP hit the 1h ceiling) with 2m heartbeat; all other steps 1h/2m (`data.py:1548-1562`). (e) retry policy `agent_failure`.

### 4.7 `_fire_data_ready_signal(data_architecture_ref, data_migration_plan_ref) -> None` (`data.py:1315-1434`)
```
signal_payload = DataReadyForTargetSignal(target_app_id=self._app_id,
    data_architecture_ref=..., data_migration_plan_ref=..., approved_at=_now_iso())  # 1334-1339

if workflow.patched("arch-data-registry-v1"):               # 1341
    if not self._wave_id or not self._app_id:               # 1342
        log info "data-ready publish skipped — missing wave_id / app_id"; return  # 1347-1350
    try:
        await execute_activity(publish_arch_data_signal,
            PublishArchDataSignalInput(signal_type=SIGNAL_DATA_READY_FOR_TARGET,
                wave_id=self._wave_id, target_app_id=self._app_id,
                payload_json=_encode_data_ready_payload(signal_payload)),
            start_to_close=30s, retry=transient,
            activity_id="publish-data-ready-for-target")     # 1351-1363
        workflow.logger.info("arch_data_signal_fired", extra={...})   # 1368-1384
    except Exception as exc: log warning "data-ready registry publish failed: %s"  # 1385-1388
    # fast-path Temporal signal at peer Architecture wf
    if workflow.patched("arch-data-signal-first-v1") and self._architecture_workflow_id:  # 1398-1401
        try:
            handle = workflow.get_external_workflow_handle(self._architecture_workflow_id)  # 1403-1405
            await handle.signal("data_ready_for_target", signal_payload)  # 1406-1408
        except Exception as exc: log info "data-ready fast-path signal failed (DB backstop will catch it): %s"  # 1409-1414
    return                                                    # 1415

# Legacy signal path (neither registry patch)
if not self._architecture_workflow_id:                       # 1419
    log info "data-ready signal skipped — no architecture_workflow_id"; return   # 1420-1423
try:
    handle = workflow.get_external_workflow_handle(self._architecture_workflow_id)  # 1425-1427
    await handle.signal("data_ready_for_target", signal_payload)   # 1428
except Exception as exc: log warning "data-ready signal failed ...: %s"  # 1429-1434
```
GOTCHAs: registry publish is source of truth; the fast-path Temporal signal is best-effort so Architecture's `_wait_for_data_ready` exits its `wait_condition` immediately instead of waiting the 5-min DB backstop (`data.py:1389-1397`). Every publish/signal failure is swallowed (best-effort). Under registry patch with empty wave_id/app_id (unit tests) the publish is silently skipped (`data.py:1342-1350`).

### 4.8 `_build_evidence_data(...) -> dict[str,Any]` — OVERRIDE (`data.py:1581-1643`)
Differs from base (`base.py:1281-1347`): iterates `DATA_STEPS.items()` directly; **skips** steps whose `_step_results` is empty (defensive `if not artifacts: continue`, `data.py:1604-1606`); builds `file_artifacts` from `_agent_metadata[step].output_files` (only `OutputFile` instances), each with `path`/`encoding`/`size` (utf-8 byte length) and optional `content` when `include_content` or `path in content_paths` (`data.py:1609-1623`); dedups by path (`data.py:1624-1626`); per-step entry has `title`(fallback step_name)/`skill_id`/`artifact`/`output`(artifacts[0])/`metadata`(minus output_files)/`file_artifacts` (`data.py:1627-1636`). Returns `{assembly_line:"Data", app_id, step_count, steps, architecture_workflow_id}` (`data.py:1637-1643`). GOTCHA: unlike base, top-level dict includes `architecture_workflow_id` and omits base's `current_step`; `ai-pre-review` never appears because it's never in `_step_results`.

### 4.9 `_collect_committed_paths() -> list[str]` (`data.py:1645-1650`)
Iterates `DATA_STEPS` keys, extends with `self._step_committed_paths.get(step_name,[])`, returns `dedup_paths(paths)`. GOTCHA: order follows DATA_STEPS insertion order.

### 4.10 `_create_gate_pr_data(repo, branch, app_id, input)` (`data.py:1652-1727`)
- `steps_run = [name for name,def in DATA_STEPS.items() if def.get("kind")=="agent" and name in self._step_results]` (`data.py:1660-1664`). GOTCHA: filters to agent steps that actually ran → excludes `ai-pre-review` (never in `_step_results`).
- Builds `pr_body` header with target id; if `_risk_tier is not None` adds `Risk tier:` line, and if `==1` adds the Tier-1 triple-signal note (`data.py:1665-1678`).
- Lists completed steps as `- [x] {step} (\`{skill_id}\`)` and artifacts as `- \`data/{app}/{artifact}\`` (`data.py:1679-1691`).
- Appends fixed "Data Governance Board Checklist" (9 unchecked items, `data.py:1692-1705`).
- If `_rework_count("G-DT") > 0`: appends `**Rework iteration:** {n}` (`data.py:1706-1708`).
- `CreatePRInput(repo, source_branch=branch, target_branch="main", title=f"Gate G-DT: Data Architecture Review — {app_id}", body=pr_body, labels=["gate-review","data","G-DT"], execution_context=_execution_ctx("create-g-dt-pr", app_id=app_id))` (`data.py:1710-1721`).
- `return await execute_activity(create_pr, pr_input, start_to_close=60s, retry=transient)` (`data.py:1722-1727`).

---

## 5. ACTIVITY & CHILD-WORKFLOW CALLS (in `run`/`_execute_data` order)

DataWorkflow spawns **no child workflows**; all calls are `execute_activity`. Sequential unless noted.

| # | activity | args | timeout(s) | retry | activity_id | seq/par |
|---|---|---|---|---|---|---|
| 1 | `read_artifact` (index) | ReadArtifactInput(repo=artifact_repo, main, source-artifacts-index.json) | 30s | transient | `read-target-source-index-{app}` | seq (patch `data-source-index-v1`) |
| 2 | (step-0) `consume_arch_data_signal` | ConsumeArchDataSignalInput(SIGNAL_TARGET_PROVISIONED, wave_id, app_id, wf_id) | 30s | transient | `consume-target-provisioned` | seq, per backstop/poll iteration |
| 3 | `read_artifact` (plan) | ReadArtifactInput(repo, main, architecture-target-plan.json) | 30s | transient | `read-data-target-plan-{app}` | seq |
| 4 | `update_application_status` | via `_set_step`/`_update_app_status` | 30s | transient | (default) | seq, many call sites |
| 5 | `dispatch_agent_task` (domain-discovery, shared-db-analysis) | AgentTaskInput | 1h / hb 2m | agent_failure | `agent-{step}` | **PARALLEL** via gather (patch) |
| 6 | `dispatch_agent_task` (decomposition-strategy) | AgentTaskInput | 1h / hb 2m | agent_failure | `agent-decomposition-strategy` | seq |
| 7 | `dispatch_agent_task` (migration-planning, data-product-design) | AgentTaskInput (tier-2) | 1h / hb 2m | agent_failure | `agent-{step}` | **PARALLEL** via gather (always) |
| 8 | `write_artifacts_batch` (per step + optional mirror) | WriteArtifactsBatchInput | 120s each | transient | `commit-{step}` (primary) | seq (base `_commit_step_artifacts`) |
| 9 | `dispatch_agent_task` (data-synthesis, tier-2) | AgentTaskInput | **3h** / hb 2m | agent_failure | `agent-data-synthesis` | seq |
| 10 | `create_pr` | CreatePRInput (G-DT) | 60s | transient | (default) | seq |
| 11 | `create_gate_record` | CreateGateRecordInput(G-DT) | 30s | transient | (default) | seq |
| 12 | `check_gate_criteria` + `submit_gate_evidence` | via base `_submit_gate_evidence` | 60s each | transient | (default) | seq |
| 13 | pre-review activities | via base `_run_gate_pre_review` | (base) | (base) | (base) | seq, fault-tolerant |
| 14 | `persist_data_side_effects` | PersistDataSideEffectsInput | 60s | transient | `persist-data-side-effects` | seq, **best-effort try/except** |
| 15 | `publish_arch_data_signal` | PublishArchDataSignalInput(SIGNAL_DATA_READY_FOR_TARGET) | 30s | transient | `publish-data-ready-for-target` | seq, best-effort |
| 16 | `reconcile_and_merge_pr` (+ `set_gate_merge_blocked`) | via base merge loop | 60s / 30s | git_merge / transient | (base) | seq, retry loop |

GOTCHA: `create_pr` (step 8) runs **before** `create_gate_record` (step 11 in code order — `data.py:855` then `860`) so `create_gate_record` can pass `evidence_package_url=pr_result.pr_url`.

---

## 6. GATE HANDLING (G-DT)

1. **Evidence assembly** — `_create_gate_pr_data` opens the PR (`data.py:855`); `create_gate_record` mints `gate_id` with the PR URL (`data.py:860-872`); `_submit_gate_evidence(..., forward_risk_tier=True)` builds the slim evidence bundle (via overridden `_build_evidence_data`) and runs `check_gate_criteria` + `submit_gate_evidence` (`data.py:874-883`, base `base.py:922-1021`). GOTCHA: `forward_risk_tier=True` here (unlike legacy Data) so the criteria call carries `evidence_data` + `risk_tier`.
2. **Pre-review** — `_run_gate_pre_review(gate_id, "G-DT", artifact_paths, artifact_repo=repo, artifact_ref=branch)` (`data.py:887-893`) — advisory, fault-tolerant (base).
3. **Wait** — `_update_app_status(..., "gate_review", "gate-review-dt", ...)` then `decision = _wait_for_gate_decision(GateType.G_DT)` (`data.py:900-905`). Base predicate: `len(_gate_decisions) > consumed or self.cancelled` (`base.py:1118-1119`).
4. **Routing:**
   - `"cancelled"` → `return "cancelled"` (`data.py:906-907`).
   - `"approved"`:
     - **Tier-1 (`_risk_tier == 1`)**: additional `wait_condition` on `(gov AND security) or cancelled` (`data.py:912-921`). If cancelled mid-wait → status CANCELLED, `return "cancelled"` (`data.py:922-924`). Tier-2/3 skip this entirely.
     - Then step 11 persist (best-effort) + fire ready signal (`data.py:926-985`), step 12 merge loop, status `data_complete`/COMPLETED, `return "completed"` (`data.py:991-1009`).
   - `"rejected"` (fall-through) → **rework** (see §6.1).
5. **merge_blocked** — handled entirely inside base `_reconcile_and_merge_with_retry_loop` (`data.py:995-1000`, base `base.py:1159-1279`): merge via `git_merge` policy (3 attempts for `MergeDivergenceUnresolved`, immediate short-circuit for `MergeConflict`/`MergeBranchProtectionRejected`); on those 3 structured errors → `set_gate_merge_blocked` + wait on `_merge_retry_signalled or cancelled`; loop. Non-structured errors propagate (fail workflow → outer `run()` except → FAILED). Cancelled during merge-wait → `return` (merge loop returns, then run completes normally as COMPLETED).

### 6.1 Rework loop & counters (`data.py:1011-1045`)
- Reset both stakeholder flags to False (`data.py:1015-1016`).
- `_bump_rework("G-DT")` increments `_rework_iterations["G-DT"]` (`data.py:1018`, base `base.py:1376-1381`).
- **Exit condition:** if `_rework_count("G-DT") > 3` → FAILED, step `max-rework-exceeded`, status `data_failed`, `return "failed"` (`data.py:1019-1027`). GOTCHA: strict `>` — the 1st,2nd,3rd rejections rework; the **4th** rejection (count becomes 4 > 3) fails.
- Otherwise reset `running_progress = 2.0` and re-run steps `domain-discovery → shared-db-analysis → decomposition-strategy → migration-planning → data-product-design` sequentially, each followed by `_collect_committed_paths()` (`data.py:1029-1045`), then loop back to `while True` re-running `data-synthesis` + gate. Rework feedback for the agents flows via `_rework_feedback["G-DT"]` set by base `_wait_for_gate_decision` on reject and read in overridden `_dispatch_agent` (`data.py:1458-1460`).

---

## 7. RESILIENCE

- **Timeouts:** step-0 overall cap 86400s (`data.py:1139,1298`); agent steps 1h (3h for data-synthesis) start_to_close + 2m heartbeat (`data.py:1559-1567`); reads/status/gate-record/publish 30s; PR/criteria/evidence/persist 60s; commit batches 120s.
- **Heartbeats:** `dispatch_agent_task` has `heartbeat_timeout=2m`; `dispatch_agent_task` was given heartbeats in PR #495 so Temporal kills only on a true hang (`data.py:1548-1567`).
- **Continue-as-new:** NONE. GOTCHA: a Tier-1 target that never receives both stakeholder signals blocks indefinitely on the `wait_condition` (`data.py:913-921`) — bounded only by `cancel_workflow`; there is no time cap on that wait, unlike step-0. Long-running histories are mitigated by the signal-first backstop reducing step-0 event count, not by continue-as-new.
- **Idempotency:** step-0 hydration is idempotent (in-memory flag short-circuits); registry publish is an upsert keyed on `(wave_id, target_app_id, signal_type)` (`data.py:1322-1323`); `persist_data_side_effects` uses `activity_id="persist-data-side-effects"` for dedup; commit activities carry deterministic `activity_id`s.
- **Compensation/rollback:** NONE. Step-11 persist failure is swallowed (`data.py:976-980`) — application row keeps stale data fields but the gate approval and merge still complete. `_fire_data_ready_signal` failures are swallowed. On any unhandled exception the outer `run()` handler sets FAILED and best-effort marks `data_failed` (`data.py:492-502`) but does not undo committed artifacts or a merged PR.
- **Determinism/replay:** every behavioral change is patch-gated (`data-source-index-v1`, `data-parallel-fanout-v1`, `arch-data-registry-v1`, `arch-data-signal-first-v1`); the legacy signal handler and all three step-0 branches are retained precisely so pre-patch histories replay identically. A rebuild MUST preserve these patch IDs verbatim and all branch bodies.

---

## 8. Behavioral parity checklist

A rebuild MUST satisfy every assertion:

1. `STEP_WEIGHTS` sums to 100.0 (module-load assert) with the exact 13 keys/values in §0.5.
2. `MAX_REWORK_ITERATIONS == 3`; the 4th G-DT rejection (count 4) fails with `current_step="max-rework-exceeded"`, status `data_failed`, returns `"failed"`.
3. `run()` sets branch `olympus/data/{target}/{run_suffix}` where `run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]`, and `workspace_key = data-{target}-{run_suffix}`.
4. On any exception `run()` sets FAILED + `current_step="failed"` and best-effort marks `data_failed`, then re-raises.
5. `target_provisioned` handler first awaits `bool(self._app_id)`, drops signals whose `target_app_id != _app_id` (log + return), and only conditionally overwrites service_id/relationship/source_app_ids (empty signal fields don't clear input values).
6. `stakeholder_approved` routes `g-dt-data-governance` and `g-dt-security` to their flags, warns+ignores other scopes; both flags reset to False on every rework.
7. Tier-1 (`_risk_tier==1`) blocks post-PM-approval on `(gov AND security) or cancelled`; Tier-2/3 skip that wait entirely.
8. System-umbrella skip fires when `_target_service_id=="system"` OR `_target_plan_entry["target_service_id"]=="system"`: fires empty-ref ready signal, status `data_skipped_system_umbrella`, COMPLETED, returns `"completed"`.
9. Retire skip when `_provisioned_disposition=="Retire"`: empty-ref ready signal, status `data_skipped_retire`, COMPLETED, returns `"completed"`.
10. `_load_target_plan_entry` raises NonRetryable `ApplicationError` on missing wave_id/artifact_repo, unreadable plan, malformed JSON, or `plan_target_key` not covered — NO best-effort fallback.
11. First-pass steps 1+2 run parallel only under `data-parallel-fanout-v1` (sequential otherwise); steps 4+5 always run parallel via `asyncio.gather`.
12. Rework re-runs steps 1→5 sequentially regardless of the fanout patch, then re-runs data-synthesis at the loop top.
13. `_dispatch_agent`: `data-product-design` skill resolved via `select_skill(DATA_PRODUCT_COMPOSITION, data_selector_inputs(tech_fingerprint))` (fallback `data-product-specification`); `{migration-planning, data-product-design, data-synthesis}` forced `model_preference="tier-2"`; `data-synthesis` gets 3h start_to_close, all else 1h; heartbeat 2m; retry `agent_failure`.
14. `_is_build` (relationship=="build", refreshed from plan) makes `build/{app}/requirements/requirements-capability.json` the sole REQUIRED input, all other priors OPTIONAL.
15. `write_to_target` steps (migration-planning, data-product-design, data-synthesis) mirror agent files to `_provisioned_target_repo_url` under `docs/data/{step}` when the URL is non-empty; summary JSON always stays in artifact_repo.
16. Step-0 wait honors all three patch branches with an 86400s cap; signal-first uses 300s backstop iterations catching `asyncio.TimeoutError`, doing exactly one `consume_arch_data_signal` read per iteration; registry branch polls every 15s.
17. `_fire_data_ready_signal` under `arch-data-registry-v1` upserts via `publish_arch_data_signal` (skipped silently when wave_id/app_id empty) and, under `arch-data-signal-first-v1` with a known `_architecture_workflow_id`, additionally fires the best-effort `data_ready_for_target` external signal; legacy path uses `get_external_workflow_handle`.
18. Post-approval persist calls `persist_data_side_effects` with `data_architecture_ref=data/{target}/data-architecture.json`, `data_migration_plan_ref=data/{target}/data-migration-plan.json`, `architecture_json`/`decomposition_json` = first `_step_results` entry of data-synthesis/decomposition-strategy (else ""), and is best-effort (failure logged, workflow continues).
19. G-DT gate PR body includes the Tier-1 triple-signal note only when `_risk_tier==1`, lists only agent steps present in `_step_results` (never `ai-pre-review`), the fixed 9-item Data Governance Board Checklist, labels `["gate-review","data","G-DT"]`, target branch `main`.
20. `_build_evidence_data` returns `architecture_workflow_id` at top level, `assembly_line="Data"`, skips steps with no results, dedups file_artifacts by path.
21. Merge is delegated to base `_reconcile_and_merge_with_retry_loop(merge_method="merge")` with the merge_blocked→`merge_retry` signal loop.
22. `ai-pre-review` never lands in `_step_results` / never commits `data/{app}/pre-review.json`; it exists only for contract-compliance CI parity.
23. No child workflows; no continue-as-new; no compensation of committed/merged artifacts.
