# ArchitectureWorkflow — Atomic Regeneration Spec (Part 2 of 2)

Continues `ArchitectureWorkflow.md`. Source: `temporal/olympus_workflows/workflows/architecture.py`. Covers the gate loop (steps 10–16), the rework loop, all step helpers/overrides, resilience, and the behavioral-parity checklist.

---

## 1. The gate loop — `_execute_architecture` steps 10–16 (`architecture.py:1014-1279`)

The tail of `_execute_architecture` is a `while True:` loop (`:1015`) that runs blueprint synthesis, evidence, PR, gate, and either completes or reworks. Each iteration:

### 1.1 Step 10 — Blueprint Assembly (`architecture.py:1016-1024`)
```
await self._run_agent_step("blueprint-assembly", target_app_id, prior_inputs,
                           input.source_repo, workspace_key, repo, branch)
blueprint_progress = running_progress + STEP_WEIGHTS["blueprint-assembly"]   # +8.0
prior_inputs = self._collect_committed_paths()
```
> `blueprint-assembly` runs UNCONDITIONALLY (not behind `_should_run_step`) — it is required for both per-service and umbrella targets. Its `_dispatch_agent` resolves the skill via the composition evaluator (see §4 below).

### 1.2 Steps 11/12/13 — Stage 5/9 post-synthesis evidence (patch `architecture-stage5-evidence-v1`, `architecture.py:1038-1066`)
```
if workflow.patched("architecture-stage5-evidence-v1"):
    evidence_tasks = []
    if self._should_run_step("cloud-cost-estimate"):
        evidence_tasks.append(self._run_agent_step_task("cloud-cost-estimate", ...prior_inputs...))
        blueprint_progress += 2.0
    if self._should_run_step("well-architected-review"):
        evidence_tasks.append(self._run_agent_step_task("well-architected-review", ...prior_inputs...))
        blueprint_progress += 2.0
    if self._should_run_step("traceability-validation"):
        evidence_tasks.append(self._run_agent_step_task("traceability-validation", ...prior_inputs...))
        blueprint_progress += 2.0
    if evidence_tasks:
        await asyncio.gather(*evidence_tasks)                 # parallel (:1065)
        prior_inputs = self._collect_committed_paths()
```
> **GOTCHA (replay determinism):** Pre-patch histories never scheduled these three activities; on replay they take the skip branch (`:1034-1037`). For the umbrella, `cloud-cost-estimate` is skipped (not in umbrella set) but `well-architected-review` and `traceability-validation` run.

### 1.3 Step 14 (logical) — Commit Blueprint Artifacts marker (`architecture.py:1068-1077`)
Artifacts are committed per-step; this is only a stepper marker:
```
await self._set_step("commit-blueprint-artifacts", blueprint_progress)
commit_progress = blueprint_progress + STEP_WEIGHTS["commit-blueprint-artifacts"]   # +2.0
```

### 1.4 Step 12 — Create G-02 PR + gate record + evidence (`architecture.py:1079-1110`)
```
artifact_paths = dedup_paths(self._collect_committed_paths())            # (:1080)
await self._set_step("create-g-02-pr", commit_progress)
pr_result = await self._create_gate_pr_architecture(repo, branch, target_app_id, input)  # §5
pr_progress = commit_progress + STEP_WEIGHTS["create-g-02-pr"]           # +2.0

gate_record = await workflow.execute_activity(
    create_gate_record,
    CreateGateRecordInput(gate_type="G-02", app_id=target_app_id,
        portfolio_id=input.portfolio_id, workflow_id=workflow.info().workflow_id,
        evidence_package_url=pr_result.pr_url),
    start_to_close_timeout=timedelta(seconds=30),
    retry_policy=RETRY_POLICIES["transient"])                            # (:1087-1098)
gate_id = gate_record.gate_id

await self._submit_gate_evidence(                                        # (:1101-1110) base helper
    gate_id=gate_id, gate_type=GateType.G_02, app_id=target_app_id,
    artifact_paths=artifact_paths, pr_url=pr_result.pr_url,
    assembly_line="Architecture", step="gate-review-02",
    forward_risk_tier=True)
```
`_submit_gate_evidence` (base, `base.py:922-1021`): builds slim evidence via `_build_evidence_data` (architecture override, §6), enriches contents only for `GATE_THRESHOLDS["G-02"]` artifacts, calls `check_gate_criteria` (60s, transient) with `risk_tier` forwarded, then `submit_gate_evidence` (60s, transient) with the slim bundle.

### 1.5 Step 13 — AI Pre-Review (`architecture.py:1112-1123`)
```
await self._set_step("ai-pre-review", pr_progress)
await self._run_gate_pre_review(gate_id, "G-02", artifact_paths,
                                artifact_repo=repo, artifact_ref=branch)
pre_review_progress = pr_progress + STEP_WEIGHTS["ai-pre-review"]        # +4.0
```
Uses base `_run_gate_pre_review` (task_type `gate-pre-review`, skill `gate-pre-review`); result does NOT enter `self._step_results`.

### 1.6 Step 14 — Gate G-02 wait (`architecture.py:1125-1152`)
```
await self._set_step("gate-review-02", pre_review_progress)
await self._update_app_status(target_app_id, "gate_review", "gate-review-02", "Architecture")
decision = await self._wait_for_gate_decision(GateType.G_02)            # base (:1132)
if decision == "cancelled":
    return "cancelled"                                                  # (:1133-1134)
if decision == "approved":
    if self._risk_tier == 1:                                            # (:1140) Tier-1 triple-signal
        await workflow.wait_condition(lambda:
            (self._stakeholder_ea_approved and self._stakeholder_security_approved)
            or self.cancelled)
        if self.cancelled:
            self._status = WorkflowStatus.CANCELLED
            return "cancelled"                                          # (:1150-1152)
    ... (approval body — §1.7)
# else: fall through to rework (§2)
```
`_wait_for_gate_decision` (base, `base.py:1103-1157`): sets `_status=WAITING_FOR_SIGNAL`, `_pending_gate=GateType.G_02`; waits until `len(self._gate_decisions) > consumed or self.cancelled`. On cancel → returns `"cancelled"`. Consumes one decision entry (5-tuple or 3-tuple). On APPROVED → clears `_rework_feedback["G-02"]`, returns `"approved"`. Otherwise records `_rework_feedback["G-02"] = {gate, rejected_by, reason, reason_category, card_decisions, rejected_at}` and returns `"rejected"`.
> **GOTCHA (Tier-1 gating):** The dual-stakeholder wait ANDs EA+security with PM approval ONLY when `_risk_tier == 1`. Tier-2/3 short-circuit — EA/security participate in PR review but do not block (`:1136-1139`). A rebuild that omits the `_risk_tier==1` guard would deadlock Tier-2/3 forever.

### 1.7 Step 15 — Persist Architecture Side-Effects (`architecture.py:1154-1211`)
Runs only on approval (and after Tier-1 stakeholder wait passes):
```
gate_progress = pre_review_progress + STEP_WEIGHTS["gate-review-02"]     # +6.0
await self._set_step("persist-architecture-side-effects", gate_progress)
blueprint_json = ""; target_map_json = ""
if self._step_results.get("blueprint-assembly"):
    blueprint_json = self._step_results["blueprint-assembly"][0]         # (:1169-1172)
if self._step_results.get("target-state-mapping"):
    target_map_json = self._step_results["target-state-mapping"][0]      # (:1173-1176)
blueprint_ref = f"architecture/{target_app_id}/{ARCHITECTURE_STEPS['blueprint-assembly']['artifact']}"
try:
    await workflow.execute_activity(
        persist_architecture_side_effects,
        PersistArchitectureSideEffectsInput(
            target_app_id=target_app_id, target_name=input.app_name,
            target_portfolio_id=input.portfolio_id,
            target_application_map_json=target_map_json,
            blueprint_json=blueprint_json, blueprint_ref=blueprint_ref,
            decided_at=_now_iso(), target_repo_url=self._target_repo_url),
        start_to_close_timeout=timedelta(seconds=60),
        retry_policy=RETRY_POLICIES["transient"],
        activity_id="persist-architecture-side-effects")
except Exception:                                                       # (:1203-1207) BEST-EFFORT
    workflow.logger.exception("persist_architecture_side_effects failed; ...")
persist_progress = gate_progress + STEP_WEIGHTS["persist-architecture-side-effects"]  # +2.0
```
> **GOTCHA (best-effort projection):** Any failure of the projection activity is swallowed (logged, continue) so the gate approval still completes; the application row keeps stale architecture fields (`:1154-1160`, `:1203-1207`). `blueprint_json`/`target_map_json` use `[0]` of the step's `output_artifacts` list (which for target-state-mapping is the synthesized `"target-state-mapping derived from..."` string, NOT the file content — see §3.1).

### 1.8 Step 16 — Merge Blueprint PR + completion (`architecture.py:1213-1231`)
```
await self._set_step("merge-blueprint-pr", persist_progress)
await self._reconcile_and_merge_with_retry_loop(
    repo=repo, pr_number=pr_result.pr_number, gate_id=gate_id, merge_method="merge")  # base §7
await self._update_app_status(target_app_id, "architecture_complete", "completed", "Architecture")
self._status = WorkflowStatus.COMPLETED
self._progress_pct = 100.0
self._current_step = "completed"
self._updated_at = _now_iso()
return "completed"                                                      # (:1231)
```
`_reconcile_and_merge_with_retry_loop` (base, `base.py:1159-1279`): loops calling `reconcile_and_merge_pr` (60s, `git_merge` policy). On the three structured merge errors (`MergeConflict`, `MergeDivergenceUnresolved`, `MergeBranchProtectionRejected` — surfaced as `ApplicationError.type`, unwrapped through `__cause__`), fires `set_gate_merge_blocked(gate_id, detail)` (30s, transient), resets `_merge_retry_signalled=False` before, then `wait_condition(lambda: self._merge_retry_signalled or self.cancelled)`. On cancel → returns (no merge). Success → returns. Non-merge-structured errors propagate (`base.py:1234-1240`).

---

## 2. The rework loop (`architecture.py:1233-1279`)

Reached when `decision` is neither `"cancelled"` nor `"approved"` (i.e., `"rejected"`; the `if decision == "approved":` block ends with `return`, so a rejection falls through past it to here):
```
self._stakeholder_ea_approved = False                                   # (:1240)
self._stakeholder_security_approved = False                             # (:1241)

self._bump_rework("G-02")                                               # base: _rework_iterations["G-02"] += 1
if self._rework_count("G-02") > MAX_REWORK_ITERATIONS:                  # > 3  (:1244)
    self._status = WorkflowStatus.FAILED
    self._current_step = "max-rework-exceeded"
    self._updated_at = _now_iso()
    await self._update_app_status(target_app_id, "architecture_failed",
                                  "max-rework-exceeded", "Architecture")
    return "failed"                                                     # (:1252)

running_progress = STEP_WEIGHTS["target-state-mapping"] + STEP_WEIGHTS["data-architecture"]  # 6.0+6.0=12.0 (:1259-1262)
for step_name in ("cloud-pattern-selection", "ea-compliance", "integration-arch",
                  "security-arch", "design-system", "accessibility-review", "ai-ml-integration"):
    if not self._should_run_step(step_name):
        continue                                                        # (:1272-1273) umbrella skip
    await self._run_agent_step(step_name, target_app_id, prior_inputs,
                               input.source_repo, workspace_key, repo, branch)
    running_progress += STEP_WEIGHTS[step_name]
    prior_inputs = self._collect_committed_paths()
# loop back to top of `while True` → re-run blueprint-assembly + evidence + PR + gate
```
> **GOTCHA (which steps re-run):** Rework re-runs every AGENT step EXCEPT `target-state-mapping` and `data-architecture` — target identity is fixed and re-waiting for Data's signal is a no-op because `_data_ready` stays True once set (`:1254-1258`). The three Stage-5/9 evidence steps are NOT in the rework loop's explicit list, but they DO re-run because the `while True` loop re-enters step 11-13 after blueprint-assembly.
> **GOTCHA (rework steps are SEQUENTIAL):** The rework loop uses `_run_agent_step` (awaited one at a time), not the parallel `asyncio.gather` fan-out used on the first pass — a rebuild need not parallelize rework, but progress accounting differs.
> **GOTCHA (stakeholder flag reset placement):** Reset is at the TOP of the rejection path (`:1240-1241`), AFTER the approval-return, so early-arriving stakeholder signals before the first G-02 PR are preserved (see Part 1 §4.2). On rework cycle 2+, prior cycle's EA/security approvals are cleared.
> **GOTCHA (rework feedback plumbing):** `_wait_for_gate_decision` stored `_rework_feedback["G-02"]`; `_dispatch_agent` reads `self._rework_feedback.get("G-02")` and injects it as `context["rework_feedback"]` on every re-dispatched step (`:1969-1971`).

---

## 3. Step helpers

### 3.1 `_derive_target_state_mapping_from_plan(input, target_app_id, repo, branch)` (`architecture.py:1285-1443`)
Derives `target-application-map.json` from the wave-scoped `architecture-target-plan.json` — NO agent dispatch. Strict-fail by design (raises non-retryable `ApplicationError` on every failure mode):
```
if not input.wave_id or not input.artifact_repo:
    raise ApplicationError("... missing wave_id or artifact_repo ...", non_retryable=True)   # (:1321-1326)
plan_path = f"architecture/wave-{input.wave_id}/architecture-target-plan.json"
try:
    read_result = await workflow.execute_activity(read_artifact,
        ReadArtifactInput(repo=input.artifact_repo, branch="main", path=plan_path),
        start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"],
        activity_id=f"read-arch-target-plan-{target_app_id}")
except Exception as exc:
    raise ApplicationError("... plan not found ...", non_retryable=True) from exc   # (:1343-1350)
try:
    plan = json.loads(read_result.content)
except Exception as exc:
    raise ApplicationError("... malformed JSON ...", non_retryable=True) from exc   # (:1352-1360)

plan_key = input.plan_target_key or target_app_id                       # (:1368) slug vs uuid
target_ids_in_plan = [(t.get("target_app_id") or "") for t in (plan.get("targets") or []) if isinstance(t, dict)]
if plan_key not in target_ids_in_plan:
    raise ApplicationError("... plan_target_key not present ...", non_retryable=True)   # (:1374-1381)

try:
    derived = derive_target_application_map_from_plan(plan, plan_key,
        target_portfolio_id=input.portfolio_id or "", emit_target_app_id=target_app_id)
except ValueError as exc:
    raise ApplicationError("... derive ... failed ...", non_retryable=True) from exc   # (:1393-1398)

artifact_filename = ARCHITECTURE_STEPS["target-state-mapping"]["artifact"]  # target-application-map.json
derived_content = json.dumps(derived, indent=2)
synthesized_result = AgentTaskResult(
    task_id=f"derived-{target_app_id}",
    output_artifacts=["target-state-mapping derived from architecture-target-plan.json"],
    output_files=[OutputFile(path=artifact_filename, content=derived_content, encoding="utf-8")],
    model_used="derived-from-plan")
self._agent_metadata["target-state-mapping"] = {
    "model_used": "derived-from-plan", "duration_ms": 0,
    "token_usage_input": 0, "token_usage_output": 0, "cost_estimate_usd": 0.0,
    "output_files": list(synthesized_result.output_files)}                # (:1421-1428)
self._step_results["target-state-mapping"] = list(synthesized_result.output_artifacts)  # (:1429-1431)
artifact_path = f"architecture/{target_app_id}/{artifact_filename}"
await self._commit_step_artifacts(repo, branch, target_app_id, "target-state-mapping",
                                  synthesized_result, artifact_path)      # (:1436-1443)
```
> **GOTCHA (plan keyed by slug, workflow keyed by uuid):** The plan is keyed by target SLUG; `target_app_id` is the provisioned UUID. `plan_key = input.plan_target_key or target_app_id` locates the entry by slug, and `emit_target_app_id=target_app_id` emits the UUID as canonical id so downstream lines key off the same identity (`:1362-1391`).
> **GOTCHA (synthesized result vs. real agent output):** `_step_results["target-state-mapping"][0]` is the descriptive string, not JSON. The persist step (Part 2 §1.7) reads this into `target_map_json` — so the persisted `target_application_map_json` is NOT the derived map JSON; the derived JSON lives in `output_files[0].content` / the committed artifact.

### 3.2 `_wait_for_data_ready()` (`architecture.py:1510-1655`) — three-branch by patch
**Branch A — `arch-data-signal-first-v1` (`:1531-1602`), signal-first + DB backstop:**
```
elapsed = 0
while elapsed < _DATA_READY_WAIT_TIMEOUT_SECONDS:                        # 86400
    if self._data_ready: return                                          # (:1536)
    if self.cancelled: raise RuntimeError("cancelled ...")               # (:1538)
    remaining = _DATA_READY_WAIT_TIMEOUT_SECONDS - elapsed
    this_wait = min(_DB_BACKSTOP_INTERVAL_SECONDS, remaining)            # 300 or less
    try:
        await workflow.wait_condition(lambda: self._data_ready or self.cancelled,
                                      timeout=timedelta(seconds=this_wait))
    except asyncio.TimeoutError:
        pass                                                             # backstop → one DB read
    if self.cancelled: raise RuntimeError("cancelled ...")
    if self._data_ready: return
    result = await workflow.execute_activity(consume_arch_data_signal,
        ConsumeArchDataSignalInput(signal_type=SIGNAL_DATA_READY_FOR_TARGET,
            wave_id=self._wave_id, target_app_id=self._app_id,
            workflow_id=workflow.info().workflow_id),
        start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"],
        activity_id="consume-data-ready-for-target")
    if result.found:
        payload = _decode_data_ready_payload(result.payload_json)
        self._data_architecture_ref = payload.get("data_architecture_ref", "")
        self._data_migration_plan_ref = payload.get("data_migration_plan_ref", "")
        self._data_ready = True; self._updated_at = _now_iso(); return
    elapsed += this_wait
raise RuntimeError("timed out waiting for data-ready signal (wave=... target=...)")  # (:1599-1602)
```
**Branch B — `arch-data-registry-v1` only (`:1603-1647`), 15s poll:**
```
elapsed = 0
while True:
    if self._data_ready: return
    result = await workflow.execute_activity(consume_arch_data_signal, ...same args...)
    if result.found:
        payload = _decode_data_ready_payload(result.payload_json)
        self._data_architecture_ref = payload.get("data_architecture_ref", "")
        self._data_migration_plan_ref = payload.get("data_migration_plan_ref", "")
        self._data_ready = True; self._updated_at = _now_iso(); return
    if self.cancelled: raise RuntimeError("cancelled ... registry entry")
    if elapsed >= _DATA_READY_WAIT_TIMEOUT_SECONDS:
        raise RuntimeError("timed out ... registry entry ...")
    await workflow.sleep(_REGISTRY_POLL_INTERVAL_SECONDS)                # 15s
    elapsed += _REGISTRY_POLL_INTERVAL_SECONDS
```
**Branch C — legacy (no patch, `:1648-1655`), in-memory only:**
```
await workflow.wait_condition(lambda: self._data_ready or self.cancelled)
if self.cancelled: raise RuntimeError("cancelled waiting for data-ready signal")
```
> **GOTCHA (history-event reduction):** Branch A collapses ~5700 15s polls into ~288 backstop iterations over 24h; a typical sub-30-min Data completion is ~5 DB reads (`:140-147`, `:1521-1526`). ATLAS Challenge 3 saw 1200+ history events from a 25-min wait under the old cadence.
> **GOTCHA (cancel → RuntimeError, not clean return):** All three branches raise `RuntimeError` on cancel, which propagates out of `_execute_architecture`, is caught by `run()`'s bare `except Exception`, sets `_status=FAILED`, best-effort `architecture_failed`, and re-raises. A cancel during the data wait FAILS the workflow (does not return `"cancelled"`).

### 3.3 `_provision_target_repo_for_this_run(input, target_app_id)` (`architecture.py:1657-1766`)
```
passed_url = getattr(input, "target_repo_url", "") or ""
if passed_url:
    self._target_repo_url = passed_url; log info; return                 # (:1682-1689) reuse pre-provisioned
artifact_repo = getattr(input, "artifact_repo", "") or ""
owner = ""
if "/" in artifact_repo:
    owner = artifact_repo.split("/", 1)[0]
    for scheme in ("https:", "http:"):
        if owner.startswith(scheme):
            parts = artifact_repo.split("/")
            if len(parts) >= 4: owner = parts[3]
            break                                                        # (:1706-1715)
if not owner:
    log warning "provisioning skipped — cannot derive owner"; return     # (:1717-1726)
friendly_slug = slugify_target_name(getattr(input, "app_name", "") or "")
name = friendly_slug if friendly_slug else f"olympus-target-{target_app_id[:8]}"  # (:1728-1734)
slug = f"{owner}/{name}"
readme = self._render_target_repo_readme(input, target_app_id)
try:
    result = await workflow.execute_activity(provision_target_repo,
        ProvisionTargetRepoInput(target_app_id=target_app_id, repo_slug=slug,
            initial_readme=readme, private=True),
        start_to_close_timeout=timedelta(seconds=120), retry_policy=RETRY_POLICIES["transient"],
        activity_id="provision-target-repo")
    self._target_repo_url = result.target_repo_url; log info
except Exception as exc:
    log warning "provisioning failed; continuing without target_repo_url"  # (:1761-1766) BEST-EFFORT
```
> **GOTCHA (idempotent on slug):** Rework/rerun is safe — the activity reuses the existing repo (`:1666-1668`). Provisioning failure is non-fatal; commits still land in artifact_repo and the G-02 projection writes an empty `target_repo_url` (`:1676-1679`).

`_render_target_repo_readme(input, target_app_id)` (static, `:1768-1794`): builds a markdown README with app_name, target_app_id, portfolio_id, wave_id, and disposition (`getattr(disp, "value", str(disp))`, default `'unknown'`).

### 3.4 `_fire_target_provisioned_signal(input, target_app_id)` (`architecture.py:1796-1945`)
Builds `TargetProvisionedSignal(target_app_id, portfolio_id, architecture_workflow_id=workflow.info().workflow_id, wave_id, disposition=disposition_str, target_repo_url=self._target_repo_url, target_service_id, relationship, source_app_ids)` (`:1824-1842`).

**Branch A — `arch-data-registry-v1` (`:1844-1920`):**
```
if not input.wave_id: log info "skipped — no wave_id"; return           # (:1848-1852)
try:
    await workflow.execute_activity(publish_arch_data_signal,
        PublishArchDataSignalInput(signal_type=SIGNAL_TARGET_PROVISIONED,
            wave_id=input.wave_id, target_app_id=target_app_id,
            payload_json=_encode_target_provisioned_payload(payload)),
        start_to_close_timeout=timedelta(seconds=30), retry_policy=RETRY_POLICIES["transient"],
        activity_id="publish-target-provisioned")
    log info "arch_data_signal_fired" {signal_kind, wave_id, target_app_id, target_service_id, relationship, peer_workflow_id}
except Exception as exc: log warning "registry publish failed"           # (:1888-1891) BEST-EFFORT
# Fast-path accelerator signal:
if workflow.patched("arch-data-signal-first-v1"):                        # (:1902-1919)
    data_wf_id = ""
    try: data_wf_id = input.peer_workflow_ids.get("Data", "")
    except AttributeError: data_wf_id = ""
    if data_wf_id:
        try:
            handle = workflow.get_external_workflow_handle(data_wf_id)
            await handle.signal("target_provisioned", payload)
        except Exception as exc: log info "fast-path signal failed (DB backstop will catch it)"
return
```
**Branch B — legacy signal path (no patch, `:1922-1945`):**
```
data_wf_id = ""
try: data_wf_id = input.peer_workflow_ids.get("Data", "")
except AttributeError: data_wf_id = ""
if not data_wf_id: log info "skipped — no peer Data workflow id"; return
try:
    handle = workflow.get_external_workflow_handle(data_wf_id)
    await handle.signal("target_provisioned", payload)
except Exception as exc: log warning "signal failed — Data may not be started"
```
> **GOTCHA:** Under the registry patch, the reply signal `target_provisioned` fires at the Data workflow's `"target_provisioned"` handler (accelerator only); the registry publish is the source of truth. `architecture_workflow_id` is in the payload for observability but Data no longer routes replies via it (`:1814-1816`).

### 3.5 `_run_agent_step(step_name, app_id, prior_inputs, source_repo, workspace_key, repo, branch)` (`architecture.py:1445-1492`)
```
running = self._progress_pct
await self._set_step(step_name, running)
result = await self._dispatch_agent(app_id=app_id, step_name=step_name,
    input_artifacts=prior_inputs, source_repo=source_repo,
    workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)  # §4
self._step_results[step_name] = result.output_artifacts
step_def = ARCHITECTURE_STEPS[step_name]
if step_def.get("artifact"):
    artifact_path = f"architecture/{app_id}/{step_def['artifact']}"
    mirror_repo = self._target_repo_url if (step_def.get("write_to_target") and self._target_repo_url) else ""
    await self._commit_step_artifacts(repo, branch, app_id, step_name, result, artifact_path,
        mirror_repo=mirror_repo,
        mirror_path_prefix=(f"docs/architecture/{step_name}" if mirror_repo else ""))
```

### 3.6 `_run_agent_step_task(...)` (`architecture.py:1494-1508`)
Returns the coroutine `self._run_agent_step(...)` unawaited — used for `asyncio.gather` parallel dispatch.

### 3.7 `_collect_committed_paths()` (`architecture.py:2172-2177`)
Iterates `ARCHITECTURE_STEPS` in order, extends with `self._step_committed_paths.get(step_name, [])`, returns `dedup_paths(paths)`.

---

## 4. Override — `_dispatch_agent(...)` (`architecture.py:1951-2099`)

Threads `source_repo`, rework feedback, model preference, and (for Build) required/optional input split into `AgentTaskInput`.
```
step_def = ARCHITECTURE_STEPS[step_name]
context = {}
fb = self._rework_feedback.get("G-02")
if fb is not None: context["rework_feedback"] = fb                       # (:1969-1971)
if step_name == "security-arch": context["fixture_scenario"] = "security-arch"  # (:1977-1978)

skill_id = step_def["skill_id"]
if step_name == "blueprint-assembly":                                    # (:1988-2000) registry router
    routed = select_skill(ARCHITECTURE_BLUEPRINT_COMPOSITION,
                          architecture_selector_inputs(self._disposition))
    if routed is not None: skill_id = routed                             # None (Retire/Retain) → declared skill

synthesis_steps = {"target-state-mapping", "blueprint-assembly",
                   "cloud-pattern-selection", "ea-compliance"}           # (:2022-2027)
model_preference = "tier-2" if step_name in synthesis_steps else ""

if self._is_build:                                                       # (:2038-2048)
    req_artifact = f"build/{app_id}/requirements/requirements-capability.json"
    required_inputs = [req_artifact]
    optional_inputs = [p for p in input_artifacts if p != req_artifact]
else:
    required_inputs = input_artifacts
    optional_inputs = []

task_input = AgentTaskInput(task_type=f"architecture-{step_name}", app_id=app_id,
    skill_id=skill_id, input_artifacts=required_inputs,
    optional_input_artifacts=optional_inputs, source_repo=source_repo,
    artifact_repo=artifact_repo, artifact_ref=artifact_ref, workspace_key=workspace_key,
    context=context, model_preference=model_preference,
    execution_context=self._execution_ctx(step_name, app_id=app_id, input_artifact_paths=required_inputs))

activity_timeout = timedelta(hours=3) if step_name in synthesis_steps else timedelta(hours=1)  # (:2079-2082)
result = await workflow.execute_activity(dispatch_agent_task, task_input,
    start_to_close_timeout=activity_timeout,
    heartbeat_timeout=timedelta(minutes=2),
    retry_policy=RETRY_POLICIES["agent_failure"],
    activity_id=f"agent-{step_name}")                                    # (:2083-2090)
self._agent_metadata[step_name] = {model_used, duration_ms, token_usage_input,
    token_usage_output, cost_estimate_usd, output_files}                 # (:2091-2098)
return result
```
> **GOTCHA (tier-2 model pin):** `target-state-mapping`, `blueprint-assembly`, `cloud-pattern-selection`, `ea-compliance` are pinned to `model_preference="tier-2"` (Sonnet 1M) AND get a 3-hour timeout; every other step gets `""` and 1 hour (`:2001-2030`, `:2079-2082`). Reason: Opus 4.7 1M returns `is_error=True, subtype=success` on the largest synthesis prompts >50% of the time (`:2003-2021`). NOTE: `target-state-mapping` is in `synthesis_steps` but is NEVER dispatched (it's derived), so its tier-2/3h setting is dead code for the normal path.
> **GOTCHA (heartbeat):** `heartbeat_timeout=2m` relies on `dispatch_agent_task` heartbeating every 30s; `start_to_close` is the absolute upper bound (`:2073-2082`).
> **GOTCHA (blueprint router):** Skill selection for `blueprint-assembly` uses the registry composition `ARCHITECTURE_BLUEPRINT_COMPOSITION` + `architecture_selector_inputs(self._disposition)` (replaced the retired `architecture_patterns_router`). `None` (Retire/Retain) → falls back to declared `blueprint-assembly` skill (`:1979-2000`). `_disposition` was set to `"Build"` when `_is_build` so the net-new specialist is picked.
> **GOTCHA (Build input inversion):** For Build targets the ONLY required input is `build/{app_id}/requirements/requirements-capability.json`; all staged priors become optional (404-tolerant) because there is no legacy Discovery output (`:2031-2048`).

---

## 5. Override — `_create_gate_pr_architecture(repo, branch, app_id, input)` (`architecture.py:2179-2258`)
```
steps_run = [name for name, sd in ARCHITECTURE_STEPS.items()
             if sd.get("kind") == "agent" and name in self._step_results]   # (:2187-2191)
pr_body = "## Gate G-02 Review: Architecture Alignment — {app_id}\n\n**Target application:** `{app_id}`\n"
if self._risk_tier is not None:
    pr_body += f"**Risk tier:** {self._risk_tier}\n"
    if self._risk_tier == 1:
        pr_body += "\n> **Tier-1:** Approval requires PM merge AND scope=\"g-02-ea\" AND scope=\"g-02-security\" ...\n"
# "### Architecture Steps Completed" — one "- [x] {step} (`{skill_id}`)" per steps_run
# if _data_architecture_ref: "- [x] data-architecture (handshake from Data line)"
# "### Artifacts" — "- `architecture/{app_id}/{artifact}`" per steps_run
# if _data_architecture_ref: "- `{_data_architecture_ref}`" and "- `{_data_migration_plan_ref}`"
# "### EA Review Board Checklist" — 9 fixed "- [ ]" items (:2225-2236)
rework_iter = self._rework_count("G-02")
if rework_iter > 0: pr_body += f"\n**Rework iteration:** {rework_iter}\n"
pr_input = CreatePRInput(repo=repo, source_branch=branch, target_branch="main",
    title=f"Gate G-02: Architecture Alignment Review — {app_id}", body=pr_body,
    labels=["gate-review", "architecture", "G-02"],
    execution_context=self._execution_ctx("create-g-02-pr", app_id=app_id))
return await workflow.execute_activity(create_pr, pr_input,
    start_to_close_timeout=timedelta(seconds=60), retry_policy=RETRY_POLICIES["transient"])
```
> `steps_run` only includes agent-kind steps present in `_step_results`. `target-state-mapping` (kind=agent) IS included because `_derive_...` populated `_step_results`. `ai-pre-review` (agent-kind, but never in `_step_results`) is excluded. `data-architecture` (code-kind) is handled by the `_data_architecture_ref` block.

---

## 6. Override — `_build_evidence_data(...)` (`architecture.py:2101-2170`)
Architecture-specific G-02 evidence bundle (differs from base `_build_evidence_data`):
```
steps = {}
for step_name, step_def in ARCHITECTURE_STEPS.items():
    if step_def.get("kind") == "code": continue                          # skip data-architecture (:2124-2127)
    artifacts = self._step_results.get(step_name, [])
    if not artifacts: continue                                           # skip un-run steps (:2128-2130)
    metadata = self._agent_metadata.get(step_name, {})
    output_files = metadata.get("output_files", [])
    raw_file_artifacts = []
    for f in output_files:
        if not isinstance(f, OutputFile): continue
        content_str = f.content if isinstance(f.content, str) else ""
        entry = {"path": f.path, "encoding": f.encoding,
                 "size": len(content_str.encode("utf-8")) if content_str else 0}
        if include_content or (content_paths is not None and f.path in content_paths):
            entry["content"] = f.content
        raw_file_artifacts.append(entry)
    deduped = list({f["path"]: f for f in raw_file_artifacts}.values())
    steps[step_name] = {"title", "skill_id", "artifact", "output"=artifacts[0],
        "metadata" (minus output_files), "file_artifacts"=deduped}       # (:2151-2160)
return {"assembly_line": "Architecture", "app_id": app_id, "step_count": len(steps),
        "steps": steps,
        "data_architecture": {"architecture_ref": self._data_architecture_ref,
                              "migration_plan_ref": self._data_migration_plan_ref}}  # (:2161-2170)
```
> **GOTCHA (signature differs from base):** Architecture's override hardcodes `assembly_line="Architecture"` in the return regardless of the passed `assembly_line` arg (`:2162`), adds a top-level `data_architecture` block and `step_count`, and omits `current_step`. Base's shape has `current_step` and `**self._evidence_step_metadata(...)` per step (`base.py:1342-1347`). A rebuild MUST use the Architecture shape for G-02.

---

## 7. RESILIENCE summary
- **Timeouts:** read_artifact 30s; realize_target_state_grain 5min; provision_target_repo 120s; consume_arch_data_signal 30s; publish_arch_data_signal 30s; create_gate_record 30s; check/submit gate evidence 60s (base); persist_architecture_side_effects 60s; create_pr 60s; reconcile_and_merge_pr 60s (base); agent dispatch 1h (3h synthesis) + 2m heartbeat. Overall data-ready cap 24h.
- **Retry policies:** `transient` (HTTP: 3 attempts, 1s→15s, 2.0×); `agent_failure` (3 attempts, 5s→60s, 2.0×); `infrastructure` (10 attempts, 5s→300s) — used for `realize_target_state_grain`; `git_merge` (3 attempts, 5s→30s, non-retryable: MergeConflict/MergeDivergenceUnresolved/MergeBranchProtectionRejected).
- **Non-retryable errors:** `_derive_target_state_mapping_from_plan` raises `ApplicationError(non_retryable=True)` on missing/malformed/uncovered plan (§3.1). Merge structured errors route to `merge_blocked` escalation loop, not retry.
- **Continue-as-new:** NONE. The workflow does not call `continue_as_new`; the `_wait_for_data_ready` history-event reduction (backstop) is the mitigation for long waits.
- **Idempotency:** `provision_target_repo` idempotent on slug; `realize_target_state_grain` idempotent on natural keys; branch/workspace_key deterministic on workflow id; `derive_target_state_mapping` deterministic given the plan.
- **Compensation/rollback:** NONE. Failures set `_status=FAILED` + best-effort `_update_app_status("architecture_failed", ...)`; `persist_architecture_side_effects` failure is swallowed. Cancel during gate/merge returns `"cancelled"`; cancel during data-wait raises → FAILED.
- **Patch gates (`workflow.patched`)** for replay determinism: `architecture-source-index-v1`, `architecture-realize-grain-v1`, `arch-parallel-fanout-v1` (steps 2+3 and 6-9), `architecture-stage5-evidence-v1` (steps 11-13), `arch-data-registry-v1`, `arch-data-signal-first-v1`. A rebuild targeting fresh histories takes ALL "new" branches; pre-patch replay takes the legacy branches.

---

## 8. Behavioral parity checklist
A rebuild MUST satisfy every assertion:

1. **STEP_WEIGHTS sum == 100.0** (import-time assert, `:373-375`); the 19-key weight table matches Part 1 §1.5 exactly.
2. **Step 1 is DERIVED, not dispatched:** `target-state-mapping` reads `architecture/wave-{wave_id}/architecture-target-plan.json`, derives via `derive_target_application_map_from_plan(plan, plan_key, ..., emit_target_app_id=target_app_id)`, records `model_used="derived-from-plan"`, and raises non-retryable `ApplicationError` if the plan is missing/malformed or `plan_key` (=`plan_target_key or app_id`) is not in the plan's targets.
3. **Parallel fan-out under `arch-parallel-fanout-v1`:** steps 2+3 gather; steps 6-9 gather; input snapshot bound BEFORE each gather so siblings never see each other's commits. Legacy (unpatched) shape runs sequential 2→3, then 6 seq / 7||8 / 9 seq.
4. **Steps 4/5 ordering:** integration-arch is awaited to completion before the data-ready wait begins (not truly concurrent).
5. **Data handshake:** under `arch-data-signal-first-v1`, signal-first wait with 5-min DB backstop (`consume_arch_data_signal`), 24h cap → RuntimeError on timeout; under `arch-data-registry-v1`, 15s poll; legacy in-memory wait_condition. `_data_ready` stays True once set; refs hydrated into `_step_committed_paths["data-architecture"]` only when `_data_architecture_ref` non-empty.
6. **`data_ready_for_target` handler waits for `bool(self._app_id)` before comparing `signal.target_app_id`** and drops mismatched targets with an info log.
7. **System umbrella:** when `_target_service_id=="system"`, only `{target-state-mapping, design-system, ea-compliance, well-architected-review, traceability-validation, blueprint-assembly}` run as agent/derive steps; gate/commit/persist/merge always run; the data wait is skipped.
8. **Stage-5/9 evidence under `architecture-stage5-evidence-v1`:** cloud-cost-estimate, well-architected-review, traceability-validation gather after blueprint-assembly, before commit/PR.
9. **G-02 evidence:** slim bundle via the Architecture `_build_evidence_data` override (hardcodes `assembly_line="Architecture"`, adds `data_architecture` block + `step_count`, skips code-kind and un-run steps); `check_gate_criteria` forwards `risk_tier` and enriches only threshold-artifact contents.
10. **Gate decision routing:** `"cancelled"`→return `"cancelled"`; `"approved"`→(Tier-1 only) AND `_stakeholder_ea_approved` & `_stakeholder_security_approved` (or cancel→CANCELLED) → persist → merge → `"completed"`; anything else→rework.
11. **Tier-1 triple-signal:** only when `_risk_tier==1` does the workflow additionally wait on both stakeholder scopes; `stakeholder_approved` routes `g-02-ea`/`g-02-security`, warns+ignores unknown scopes.
12. **Rework loop:** reset both stakeholder flags AFTER the approval-return; `_bump_rework("G-02")`; if count > 3 → FAILED `"max-rework-exceeded"`; else reset `running_progress = 12.0` and sequentially re-run cloud-pattern-selection, ea-compliance, integration-arch, security-arch, design-system, accessibility-review, ai-ml-integration (respecting `_should_run_step`), then loop back through blueprint+evidence+PR+gate. `target-state-mapping` and `data-architecture` are NOT re-run.
13. **Merge:** `_reconcile_and_merge_with_retry_loop(merge_method="merge")` with `git_merge` policy; the three structured merge errors → `set_gate_merge_blocked` + wait for `merge_retry` signal; cancel → return without merging.
14. **`_dispatch_agent`:** injects `context["rework_feedback"]` from `_rework_feedback["G-02"]`; pins `security-arch` `fixture_scenario`; resolves blueprint skill via composition (None→declared); `model_preference="tier-2"` + 3h timeout for {target-state-mapping, blueprint-assembly, cloud-pattern-selection, ea-compliance}, else `""` + 1h; 2m heartbeat; `agent_failure` retry. Build targets: single required input `build/{app_id}/requirements/requirements-capability.json`, rest optional.
15. **Target repo provisioning:** reuse `input.target_repo_url` if set; else derive `{owner}/{slugify_target_name(app_name) or olympus-target-{app_id[:8]}}`, `provision_target_repo(private=True)`, best-effort; `write_to_target` steps mirror files to `docs/architecture/{step}/` in that repo. Step JSON always lands in `input.artifact_repo`.
16. **Target-provisioned publish:** under `arch-data-registry-v1`, `publish_arch_data_signal(SIGNAL_TARGET_PROVISIONED, ...)` (skipped if no wave_id), plus best-effort fast-path `target_provisioned` signal to the peer Data workflow under `arch-data-signal-first-v1`; legacy path signals the peer directly.
17. **Failure surface:** `run()` catches all exceptions from `_execute_architecture`, sets `_status=FAILED`, `_current_step="failed"`, best-effort `_update_app_status("architecture_failed", "failed")`, re-raises.
18. **Track-A grain:** under `architecture-realize-grain-v1`, best-effort `_realize_consolidation_grain_if_present` reads the wave consolidation plan and calls `realize_target_state_grain` (5-min, `infrastructure` retry) — missing plan skips, schema-invalid plan propagates.
19. **Signals `gate_approved`/`gate_rejected`/`merge_retry`/`escalation_resolved`/`cancel_workflow` and query `get_status` are inherited unchanged**; `stakeholder_approved` and `data_ready_for_target` are the only new handlers.
