# ArchitectureWorkflow — Atomic Regeneration Spec (Part 1 of 2)

Source: `temporal/olympus_workflows/workflows/architecture.py` (2259 lines).
Base class: `LineWorkflowBase(HILSignalsMixin)` in `temporal/olympus_workflows/workflows/base.py` — see `_base-workflow.md` for inherited machinery. This document fully captures THIS class's own state, signals, run() body, and every override.

> **Split:** Part 1 = purpose, module constants, class config, STATE, SIGNALS/QUERIES, and the `run()` entry + `_execute_architecture` fan-out (steps 1–9). Part 2 (`ArchitectureWorkflow-part2.md`) = the gate loop (steps 10–16), rework loop, and all step helpers/overrides (`_derive_target_state_mapping_from_plan`, `_run_agent_step`, `_wait_for_data_ready`, `_provision_target_repo_for_this_run`, `_fire_target_provisioned_signal`, `_dispatch_agent`, `_build_evidence_data`, `_create_gate_pr_architecture`), resilience, and the parity checklist.

---

## 0. What this workflow is

Per-**target**-app orchestration of the Architecture assembly line (W19 reshape). Executes the canonical 16-step shape from `specifications/phase-5/assembly-line-contracts/architecture.md` (`architecture.py:1-9`). Runs once per target application:
- Refactor / Rearchitect / Replatform / Retain → target == source (`architecture.py:5-6`).
- Replace → target is a net-new application (`architecture.py:6-7`).
- Consolidate → target anchored on one source plus its peers (`architecture.py:7-8`).
- Build (greenfield) → `relationship=="build"`; no legacy source/Discovery outputs (`architecture.py:416-418`, `544-549`).

Gate: **G-02** (Architecture Alignment Review). Tier-1 apps require triple-signal approval: PM merges the gate PR (`gate_approved`) **AND** `StakeholderApprovedSignal` with `scope="g-02-ea"` (EA board) **AND** `scope="g-02-security"` (security officer). Tier-2/3 keep single PM approval (`architecture.py:44-48`).

Arch↔Data handshake is registry-backed under `arch-data-registry-v1` (2026-05-08): Architecture publishes `TargetProvisionedSignal` to the arch_data registry at step 1 and polls for `DataReadyForTargetSignal` at step 5 (`architecture.py:10-16`). The old in-memory `data_ready_for_target` signal handler is retained as a replay-only path.

The nominal 16-step sequence (`architecture.py:18-37`):
```
 1. target-state-mapping          (code — derived from wave plan; NOT an agent dispatch)
 2. cloud-pattern-selection       (agent, parallel w/ 3)
 3. ea-compliance                 (agent, parallel w/ 2)
 4. integration-arch              (agent, parallel w/ 5)
 5. data-architecture             (code — signal wait, parallel w/ 4)
 6. security-arch                 (agent, parallel w/ 7-9)
 7. design-system                 (agent, parallel w/ 6,8,9)
 8. accessibility-review          (agent, parallel w/ 6,7,9)
 9. ai-ml-integration             (agent, parallel w/ 6-8)
10. blueprint-assembly            (agent, synthesis)
11. commit-blueprint-artifacts    (git marker)
12. create-g-02-pr                (git)
13. ai-pre-review                 (agent, via base helper)
14. gate-review-02                (gate — Tier-1 triple-signal)
15. persist-architecture-side-effects (code)
16. merge-blueprint-pr            (git)
```
> **GOTCHA (docstring vs. code drift):** The header docstring says step 1 `target-state-mapping` is `(agent)` (`architecture.py:21`), but the live code derives it from the wave plan with NO agent dispatch (`_derive_target_state_mapping_from_plan`, `architecture.py:836`). The `ARCHITECTURE_STEPS["target-state-mapping"]["kind"]` is `"agent"` (`architecture.py:218`) but the model is recorded as `"derived-from-plan"` (`architecture.py:1419`). Rebuild MUST derive, not dispatch.
> **GOTCHA (three extra evidence steps not in docstring's 16):** `cloud-cost-estimate`, `well-architected-review`, `traceability-validation` (Stage 5/9 ATLAS integration) run between blueprint-assembly and commit, gated by `architecture-stage5-evidence-v1` (`architecture.py:286-306`, `1038-1066`). The real executed step set is 13 agent/code steps + gate/commit/persist/merge markers.

---

## 1. Module-level constants & helpers

### 1.1 Timeout / interval constants (`architecture.py:130-147`)
| Name | Value | Purpose |
|---|---|---|
| `_DATA_READY_WAIT_TIMEOUT_SECONDS` | `24*60*60` = 86400 | Overall cap on the data-ready handshake wait before unwinding (`:133`). |
| `_REGISTRY_POLL_INTERVAL_SECONDS` | `15` | Legacy `arch-data-registry-v1` poll cadence (`:139`). |
| `_DB_BACKSTOP_INTERVAL_SECONDS` | `5*60` = 300 | Signal-first DB-backstop interval under `arch-data-signal-first-v1` (`:147`). |

### 1.2 `_encode_target_provisioned_payload(payload) -> str` (`architecture.py:150-174`)
Serializes a `TargetProvisionedSignal` to JSON via `json.dumps` over a dict literal with keys: `target_app_id`, `portfolio_id`, `architecture_workflow_id`, `wave_id`, `disposition`, `target_repo_url`, and the W19 wave-plan fields `target_service_id`, `relationship`, `source_app_ids` (all read via `getattr(...) or ""`/`or []` for pre-patch publishers) (`:160-173`).

### 1.3 `_decode_data_ready_payload(payload_json) -> dict` (`architecture.py:177-192`)
- If `payload_json` falsy → `{}` (`:184-185`).
- `try: json.loads`; on `(ValueError, TypeError)` → `{}` (`:186-189`).
- If parsed not a `dict` → `{}` (`:190-191`).
- Else return parsed dict.
> **GOTCHA:** Kept as a module fn so `workflow.run`-scoped code never calls `json.loads` directly (`:181-183`).

### 1.4 `ARCHITECTURE_STEPS: dict[str, dict]` (`architecture.py:202-321`)
step_id → `{title, skill_id, artifact, kind, [write_to_target], [dispatch_via]}`. Full table:

| step_id | title | skill_id | artifact | kind | write_to_target | dispatch_via |
|---|---|---|---|---|---|---|
| target-state-mapping | Target-State Mapping | target-state-mapper | target-application-map.json | agent | — | — |
| cloud-pattern-selection | Target Architecture Strategy | migration-strategy-advisor | cloud-pattern.json | agent | **True** | — |
| ea-compliance | EA Compliance Verification | ea-compliance | ea-compliance.json | agent | — | — |
| integration-arch | Integration Architecture | api-contract-validator | integration-arch.json | agent | **True** | — |
| data-architecture | Data Architecture Handshake | **None** | **None** | **code** | — | — |
| security-arch | Security Architecture | cato-compliance | security-arch.json | agent | — | — |
| design-system | Design System Mapping | design-system | design-system.json | agent | **True** | — |
| accessibility-review | Accessibility Review | accessibility-reviewer | accessibility-review.json | agent | — | — |
| ai-ml-integration | AI/ML Integration | ai-ml-integration | ai-ml-integration.json | agent | — | — |
| blueprint-assembly | Blueprint Assembly | blueprint-assembly | architecture-blueprint.json | agent | **True** | — |
| cloud-cost-estimate | Cloud Cost Estimate | cloud-cost-estimator | cost-estimate.yaml | agent | — | — |
| well-architected-review | Well-Architected Review | well-architected-reviewer | well-architected-review.json | agent | — | — |
| traceability-validation | Architecture Traceability Validation | architecture-traceability-validator | traceability-validation.md | agent | — | — |
| ai-pre-review | AI Pre-Review | gate-pre-review | pre-review.json | agent | — | **base_gate_pre_review** |

- `write_to_target=True` steps also mirror agent file artifacts to the target modernization repo under `docs/architecture/{step}/` (`:207-213`).
- `ai-pre-review` is dispatched via the base `_run_gate_pre_review` helper (task_type `gate-pre-review`), NOT the per-step path — so it never lands in `self._step_results`. It exists in the dict purely so the gate-card registry matches `LineContract.evidence_steps()` for the CI contract guard (`:307-320`).
- `data-architecture` has `skill_id=None`, `artifact=None`, `kind="code"` — signal wait, no dispatch (`:240-247`).

### 1.5 `STEP_WEIGHTS: dict[str, float]` (`architecture.py:330-353`) — MUST sum to 100
`target-state-mapping`:6.0, `cloud-pattern-selection`:10.0, `ea-compliance`:8.0, `integration-arch`:10.0, `data-architecture`:6.0, `security-arch`:10.0, `design-system`:8.0, `accessibility-review`:6.0, `ai-ml-integration`:4.0, `blueprint-assembly`:8.0, `cloud-cost-estimate`:2.0, `well-architected-review`:2.0, `traceability-validation`:2.0, `commit-blueprint-artifacts`:2.0, `create-g-02-pr`:2.0, `ai-pre-review`:4.0, `gate-review-02`:6.0, `persist-architecture-side-effects`:2.0, `merge-blueprint-pr`:2.0.
- Module-load assertion: `assert abs(sum(STEP_WEIGHTS.values()) - 100.0) < 0.01` (`:373-375`). A rebuild that changes a weight without rebalancing crashes at import.

### 1.6 `SYSTEM_UMBRELLA_ARCHITECTURE_STEPS: frozenset[str]` (`architecture.py:363-370`)
`{target-state-mapping, design-system, ea-compliance, well-architected-review, traceability-validation, blueprint-assembly}`. The abridged step set the cross-cutting `system` umbrella target runs. Commit/PR/gate/persist steps are NOT in the set — they always run unconditionally (`:361-362`).

### 1.7 `MAX_REWORK_ITERATIONS = 3` (`architecture.py:377`)
Gate rework cap for G-02. On the 4th rejection (`_rework_count("G-02") > 3`) the workflow fails.

---

## 2. Class configuration (`architecture.py:380-397`)
`@workflow.defn class ArchitectureWorkflow(LineWorkflowBase)`. ClassVar overrides:
- `ASSEMBLY_LINE = AssemblyLine.ARCHITECTURE`
- `ARTIFACT_ROOT = "architecture"`
- `LINE_LABEL = "Architecture"`
- `STATUS_PREFIX = "architecture"`
- `STEPS = ARCHITECTURE_STEPS`
- `STEP_WEIGHTS = STEP_WEIGHTS`
- `SINGLE_GATE_KEY = "G-02"` → base `_rework_gate_key_for_step` maps every step's rework to `"G-02"`.

---

## 3. STATE — every instance variable

Base state (from `LineWorkflowBase.__init__`, `base.py:136-191`) is inherited: `_app_id`, `_portfolio_id`, `_wave_id`, `_status` (init `WorkflowStatus.PENDING`), `_current_step` (""), `_progress_pct` (0.0), `_pending_gate` (None), `_started_at`/`_updated_at` (""), `_gate_decisions` (list of tuples), `_gate_decisions_consumed` (0), `_rework_feedback` (dict), `_rework_iterations` (dict), `_step_results` (dict), `_step_committed_paths` (dict), `_agent_metadata` (dict), `_risk_tier` (None), `_merge_retry_signalled` (False), `_profile_id` (""), `_portfolio_fallback_policy` ("internal_fallback"), `_redispatch_guard` (set). `self.cancelled` comes from `HILSignalsMixin` (set True by `cancel_workflow` signal, `temporal_base/signals.py:84-86`).

**Subclass-added state** (`__init__`, `architecture.py:399-438`):

| Var | Type | Initial | Mutated by / when |
|---|---|---|---|
| `_stakeholder_ea_approved` | bool | False | `stakeholder_approved` handler when `scope=="g-02-ea"` (`:454-455`); reset to False after each G-02 rejection (`:1240`). Consumed only when `_risk_tier==1` (`:1140-1149`). |
| `_stakeholder_security_approved` | bool | False | `stakeholder_approved` handler when `scope=="g-02-security"` (`:456-457`); reset after each rejection (`:1241`). |
| `_disposition` | str | "" | Set in `run()` from `input.disposition.value` (`:533-535`); overwritten to `"Build"` when `_is_build` (`:548-549`). Read by blueprint-assembly router in `_dispatch_agent` (`:1995-1998`). Stored as plain string for sandbox-safe serialization (`:410-413`). |
| `_is_build` | bool | False | Set in `run()` = (`relationship` lowercased == "build") (`:544-547`). Read in `_dispatch_agent` to switch required/optional inputs (`:2038-2048`). |
| `_data_ready` | bool | False | Set True by `data_ready_for_target` handler (`:502`) or by `_wait_for_data_ready` DB backstop (`:1594`, `:1634`). Consumed by wait loops (`:1536`, `:1556`, `:1609`, `:1652`). Stays True once set → rework re-wait is a no-op (`:1256-1258`). |
| `_data_architecture_ref` | str | "" | Set by handler (`:503`) or backstop payload (`:1588-1590`, `:1628-1630`). Read into `_step_committed_paths["data-architecture"]` (`:927-931`), evidence bundle (`:2167`), PR body (`:2212-2224`), persist input. |
| `_data_migration_plan_ref` | str | "" | Same as above (`:504`, `:1591-1593`, `:1631-1633`, `:928-931`). |
| `_target_repo_url` | str | "" | Set by `_provision_target_repo_for_this_run` (`:1684`, `:1751`). Read in `_run_agent_step` mirror logic (`:1482-1483`), `_fire_target_provisioned_signal` payload (`:1833`), persist input (`:1197`). |
| `_artifact_repo` | str | "" | Set in `run()` = `input.artifact_repo` (`:568`). Governance repo retained for cross-line reads. |
| `_target_service_id` | str | "" | Set in `run()` = `input.target_service_id` (`:554-556`). Drives `_is_system_umbrella` / `_should_run_step` (`:599`, `:612-613`). |

---

## 4. SIGNALS & QUERIES

### 4.1 Inherited (base) — DO NOT redefine in subclasses (`base.py:193-257`)
- `@workflow.signal gate_approved(GateApprovedSignal)` — appends 5-tuple `(APPROVED, approved_by, justification, None, [])` to `_gate_decisions`; refreshes `_updated_at`. Consumed by `_wait_for_gate_decision` (`base.py:197-209`).
- `@workflow.signal gate_rejected(GateRejectedSignal)` — appends `(REJECTED, rejected_by, reason, reason_category, card_decisions)`; `card_decisions`/`reason_category` normalized via getattr (`base.py:211-232`).
- `@workflow.signal escalation_resolved(EscalationResolvedSignal)` — refreshes `_updated_at` only (`base.py:234-239`).
- `@workflow.signal merge_retry(GateMergeRetrySignal)` — sets `_merge_retry_signalled=True`; idempotent (`base.py:241-257`).
- `@workflow.signal cancel_workflow()` (from `HILSignalsMixin`, `temporal_base/signals.py:83-86`) — sets `self.cancelled=True`.
- `@workflow.query get_status() -> WorkflowStatusResponse` (`base.py:1353-1365`) — returns workflow_id, `_status`, `ASSEMBLY_LINE`, `_current_step`, `_progress_pct`, `_pending_gate`, `_started_at`, `_updated_at`.
> **GOTCHA:** The base comment (`base.py:193-195`) flags these as DO-NOT-redefine. `ArchitectureWorkflow` adds NEW signals below; it does not override the base ones.

### 4.2 `@workflow.signal stakeholder_approved(StakeholderApprovedSignal)` (`architecture.py:444-463`)
Routes Tier-1 stakeholder approvals by `signal.scope`:
```
if signal.scope == "g-02-ea":       self._stakeholder_ea_approved = True
elif signal.scope == "g-02-security": self._stakeholder_security_approved = True
else: workflow.logger.warning("... unrecognized scope", extra={"scope": signal.scope})
self._updated_at = _now_iso()
```
**Consuming predicate** (Tier-1 only, after gate approval, `architecture.py:1140-1149`):
```
if self._risk_tier == 1:
    await workflow.wait_condition(lambda:
        (self._stakeholder_ea_approved and self._stakeholder_security_approved)
        or self.cancelled)
```
> **GOTCHA (ordering):** These flags are reset to False AFTER a rejection (`:1240-1241`), not at the top of the gate loop — so an EA/security signal that arrives *before* the G-02 PR is created on the first cycle is preserved (`:1234-1239`).

### 4.3 `@workflow.signal data_ready_for_target(DataReadyForTargetSignal)` (`architecture.py:465-505`)
Retained mainly for replay-determinism of pre-`arch-data-registry-v1` histories; under the registry patch it is an advisory write and the wait loop trusts the registry.
```
await workflow.wait_condition(lambda: bool(self._app_id))   # (:490) guard vs. early-signal drop
if signal.target_app_id != self._app_id:
    workflow.logger.info("data_ready_for_target ignored — wrong target", extra={...})
    return
self._data_ready = True
self._data_architecture_ref = signal.data_architecture_ref
self._data_migration_plan_ref = signal.data_migration_plan_ref
self._updated_at = _now_iso()
```
> **GOTCHA (async signal handler with wait_condition):** This is an `async` signal handler that itself blocks on `wait_condition(lambda: bool(self._app_id))` until `run()` assigns `self._app_id`. This prevents a Wave-1-style silent drop when the Data line signals before `run()` sets `_app_id` (still `""` from `__init__`) (`:487-490`). A rebuild MUST make the handler async and wait for app_id before comparing.
**Consumer:** `self._data_ready` is polled by `_wait_for_data_ready` (see Part 2 §3.2). Note the fast-path signal path from the peer under `arch-data-signal-first-v1` targets a signal named `"target_provisioned"` on the Data workflow, not this handler (`:1913`).

---

## 5. `run()` — entry point (`architecture.py:511-593`)

Signature: `@workflow.run async def run(self, input: LineWorkflowInput) -> str`. Returns a status string (`"completed"`, `"cancelled"`, `"failed"`).

```
self._status = WorkflowStatus.RUNNING
self._started_at = _now_iso(); self._updated_at = self._started_at

target_app_id = input.app_id            # app_id IS the target app (:518-524)
self._app_id = target_app_id
self._portfolio_id = input.portfolio_id
self._wave_id = input.wave_id
self._risk_tier = getattr(input, "risk_tier", None)

disp = getattr(input, "disposition", None)          # (:533-535)
if disp is not None:
    self._disposition = getattr(disp, "value", str(disp))

self._is_build = (str(getattr(input,"relationship","") or "").strip().lower() == "build")  # (:544-547)
if self._is_build:
    self._disposition = "Build"                     # (:548-549) forces net-new specialist

self._target_service_id = getattr(input, "target_service_id", "") or ""   # (:554-556)

self._artifact_repo = input.artifact_repo           # (:568)
await self._provision_target_repo_for_this_run(input, target_app_id)   # (:569-571) — see Part 2 §3.3

repo = input.artifact_repo                          # (:572) — canonical write target for step JSONs
wf_id = workflow.info().workflow_id
run_suffix = wf_id.rsplit("-", 1)[-1] if "-" in wf_id else wf_id[:8]     # (:574)
branch = f"olympus/architecture/{target_app_id}/{run_suffix}"           # (:575)
workspace_key = f"architecture-{target_app_id}-{run_suffix}"           # (:576)

try:
    return await self._execute_architecture(input, target_app_id, repo, branch, workspace_key)  # (:578-581)
except Exception:
    self._status = WorkflowStatus.FAILED
    self._current_step = "failed"
    self._updated_at = _now_iso()
    try:
        await self._update_app_status(target_app_id, "architecture_failed", "failed", "Architecture")
    except Exception:
        pass                                        # (:591-592) best-effort
    raise                                           # (:593) re-raise original
```
> **GOTCHA (repo routing):** `repo` passed to all downstream steps is ALWAYS `input.artifact_repo` (portfolio governance repo). Step-contract JSON artifacts always land there; only `write_to_target` steps additionally mirror files to `self._target_repo_url` (`:558-567`).
> **GOTCHA (branch determinism):** `run_suffix` is derived from the workflow id, so `branch` and `workspace_key` are stable across replays and across rework iterations of the same run (`:574-576`).

### 5.1 `_is_system_umbrella() -> bool` (`architecture.py:595-599`)
Returns `self._target_service_id == "system"`.

### 5.2 `_should_run_step(step_name) -> bool` (`architecture.py:601-614`)
```
if self._is_system_umbrella():
    return step_name in SYSTEM_UMBRELLA_ARCHITECTURE_STEPS
return True
```
Per-service targets and legacy waves (empty `_target_service_id`) always run all steps. Gate/commit/persist steps bypass this predicate entirely (they are called unconditionally).

---

## 6. `_execute_architecture()` — core orchestration steps 1–9 (`architecture.py:769-1013`)

Signature: `async def _execute_architecture(self, input, target_app_id, repo, branch, workspace_key) -> str`.

```
running_progress = 0.0
prior_inputs = list(input.prior_artifacts)                              # (:778-779)
```

### 6.1 Source-artifacts-index merge (patch `architecture-source-index-v1`, `architecture.py:788-796`)
```
if workflow.patched("architecture-source-index-v1"):
    indexed_paths = await self._read_target_source_artifacts_index(input, target_app_id)
    if indexed_paths:
        seen = set(prior_inputs)
        for p in indexed_paths:
            if p not in seen:
                prior_inputs.append(p); seen.add(p)
```
`_read_target_source_artifacts_index` (`:616-669`): reads `rationalization/wave-{wave_id}/targets/{target_app_id}/source-artifacts-index.json` from `artifact_repo@main`. Returns `[]` if `wave_id`/`artifact_repo` missing (`:631-632`); reads via `read_artifact` (30s timeout, `transient` retry, activity_id `read-target-source-index-{target_app_id}`) — any exception → `[]` (`:637-650`); malformed JSON → `[]` (`:652-657`); then flattens, for each `source_apps[*].artifacts["discovery"]` and `["rationalization"]` string paths plus `shared_artifacts[*]` (`:659-669`).

### 6.2 Track-A capability-extraction (patch `architecture-realize-grain-v1`, `architecture.py:809-810`)
```
if workflow.patched("architecture-realize-grain-v1"):
    await self._realize_consolidation_grain_if_present(input)
```
`_realize_consolidation_grain_if_present` (`:671-767`):
- If no `wave_id`/`artifact_repo` → log info, return (`:695-700`).
- Reads `rationalization/wave-{wave_id}/capability-consolidation-plan.json` via `read_artifact` (30s, `transient`, activity_id `read-consolidation-plan-{wave_id}`). On any exception → log info, return (best-effort skip; older waves have no plan) (`:705-726`).
- Calls `realize_target_state_grain` with `RealizeTargetStateGrainInput(wave_id, portfolio_id, consolidation_plan_artifact_ref=plan_path, consolidation_plan_json=read_result.content)`, **5-min** timeout, `infrastructure` retry policy, activity_id `realize-target-state-grain-{wave_id}-{app_id}` (`:729-743`). Logs the returned counts.
- The trailing `except: raise` re-raises schema-validation NonRetryable errors so the workflow surfaces them (`:764-767`).
> **GOTCHA (idempotency):** The activity is idempotent on natural keys, so concurrent Architecture workflows for the same wave can both invoke it (`:686-688`). A malformed plan fails LOUD (activity-side schema validation → NonRetryable) and propagates (`:690-693`).

### 6.3 Step 1 — Target-State Mapping (`architecture.py:835-850`)
```
await self._set_step("target-state-mapping", running_progress)          # (:835)
await self._derive_target_state_mapping_from_plan(input, target_app_id, repo, branch)  # (:836) — Part 2 §3.1
running_progress += STEP_WEIGHTS["target-state-mapping"]                 # (+6.0)
prior_inputs = self._collect_committed_paths()                          # (:840)
await self._fire_target_provisioned_signal(input, target_app_id)        # (:848) — Part 2 §3.4
```
> Step 1 is NOT gated by `_should_run_step` — it always runs, including for the system umbrella (it is in the umbrella set anyway).

### 6.4 Steps 2 + 3 — Cloud Pattern Selection || EA Compliance (`architecture.py:860-898`)
Patch-gated by `arch-parallel-fanout-v1`:
```
if workflow.patched("arch-parallel-fanout-v1"):
    parallel_inputs = prior_inputs                          # snapshot BEFORE gather (:861)
    tasks = []
    if self._should_run_step("cloud-pattern-selection"):
        await self._set_step("cloud-pattern-selection", running_progress)
        tasks.append(self._run_agent_step_task("cloud-pattern-selection", ...parallel_inputs...))
        running_progress += STEP_WEIGHTS["cloud-pattern-selection"]     # (+10.0)
    if self._should_run_step("ea-compliance"):
        tasks.append(self._run_agent_step_task("ea-compliance", ...parallel_inputs...))
        running_progress += STEP_WEIGHTS["ea-compliance"]              # (+8.0)
    if tasks:
        await asyncio.gather(*tasks)                        # (:880) parallel
        prior_inputs = self._collect_committed_paths()
else:
    # Legacy sequential 2 → 3
    if self._should_run_step("cloud-pattern-selection"):
        await self._run_agent_step("cloud-pattern-selection", ...prior_inputs...)
        running_progress += 10.0; prior_inputs = self._collect_committed_paths()
    if self._should_run_step("ea-compliance"):
        await self._run_agent_step("ea-compliance", ...prior_inputs...)
        running_progress += 8.0; prior_inputs = self._collect_committed_paths()
```
> **GOTCHA (input snapshot):** In the parallel branch, `parallel_inputs` is bound to `prior_inputs` BEFORE the gather so the two dispatches never observe each other's commits (`:855-857`, `:861`). For the umbrella, `cloud-pattern-selection` is skipped (`_should_run_step` False) but `ea-compliance` runs.
> **GOTCHA (`_set_step` only on first task):** `_set_step` is called for `cloud-pattern-selection` only; `ea-compliance` relies on `_run_agent_step`'s own internal `_set_step` (`:864`, and `_run_agent_step` calls `_set_step` at `:1465`). In the umbrella case where cloud-pattern is skipped, ea-compliance's `_run_agent_step_task` still sets its own step.

### 6.5 Steps 4 + 5 — Integration Arch || Data Handshake (`architecture.py:904-933`)
Integration-arch (agent) and data-architecture (signal wait) are launched but the code awaits integration-arch first, then does the data wait:
```
if self._should_run_step("integration-arch"):
    await self._set_step("integration-arch", running_progress)
    integration_task = self._run_agent_step_task("integration-arch", ...prior_inputs...)
    await integration_task                              # (:913) awaited
    running_progress += STEP_WEIGHTS["integration-arch"]  # (+10.0)
    prior_inputs = self._collect_committed_paths()

if self._should_run_step("data-architecture"):
    await self._set_step("data-architecture", running_progress)
    await self._wait_for_data_ready()                   # (:924) — Part 2 §3.2
    if self._data_architecture_ref:
        self._step_committed_paths["data-architecture"] = [
            self._data_architecture_ref, self._data_migration_plan_ref]   # (:927-931)
    running_progress += STEP_WEIGHTS["data-architecture"]  # (+6.0)
    prior_inputs = self._collect_committed_paths()
```
> **GOTCHA (not actually parallel):** Despite the "|| Data Handshake (parallel)" comment, `await integration_task` (`:913`) fully completes integration-arch before the data wait begins. The "parallel" intent is only realized because the peer Data line may finish and set `_data_ready=True` before this point (`:910-912`).
> **GOTCHA (umbrella skips the data wait):** The umbrella has no per-service Data counterpart; Data fires `DataReadyForTarget` with empty refs synchronously for the umbrella. Gating `data-architecture` via `_should_run_step` avoids a 30-min timeout on the umbrella (`:917-921`). But note: `data-architecture` is NOT in `SYSTEM_UMBRELLA_ARCHITECTURE_STEPS`, so the umbrella skips it (predicate returns False). Data-ref committed-paths only set when `_data_architecture_ref` non-empty (`:927`).

### 6.6 Steps 6–9 — Security / Design / Accessibility / AI-ML (`architecture.py:944-1012`)
Patch-gated by `arch-parallel-fanout-v1`:
```
if workflow.patched("arch-parallel-fanout-v1"):
    parallel_inputs = prior_inputs                          # snapshot before gather (:945)
    tasks = []
    if self._should_run_step("security-arch"):
        await self._set_step("security-arch", running_progress)
        tasks.append(self._run_agent_step_task("security-arch", ...parallel_inputs...))
        running_progress += 10.0
    if self._should_run_step("design-system"):
        tasks.append(self._run_agent_step_task("design-system", ...parallel_inputs...))
        running_progress += 8.0
    if self._should_run_step("accessibility-review"):
        tasks.append(self._run_agent_step_task("accessibility-review", ...parallel_inputs...))
        running_progress += 6.0
    if self._should_run_step("ai-ml-integration"):
        tasks.append(self._run_agent_step_task("ai-ml-integration", ...parallel_inputs...))
        running_progress += 4.0
    if tasks:
        await asyncio.gather(*tasks)                        # (:973) parallel
        prior_inputs = self._collect_committed_paths()
else:
    # Legacy shape (:975-1012):
    #   Step 6 security-arch sequential (_run_agent_step), +10.0, recollect
    #   Steps 7+8 design-system || accessibility-review via gather of _run_agent_step_task, +8.0/+6.0, recollect
    #   Step 9 ai-ml-integration sequential (_run_agent_step), +4.0, recollect
```
> **GOTCHA (umbrella):** For the umbrella, only `design-system` is in the umbrella set among these four; `security-arch`, `accessibility-review`, `ai-ml-integration` are skipped. `_set_step("security-arch")` at `:948` executes only inside the `if self._should_run_step("security-arch")` guard.

**→ Continue in `ArchitectureWorkflow-part2.md` for the gate loop (steps 10–16), rework loop, step helpers, overrides, resilience, and the parity checklist.**
