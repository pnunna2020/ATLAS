# GovernanceWorkflow — Atomic Regeneration Spec

**Source:** `temporal/olympus_workflows/workflows/governance.py` (799 lines, single file, no `-part2`)
**Class decorator:** `@workflow.defn` (`governance.py:164`)
**Base classes:** NONE. `class GovernanceWorkflow:` (`governance.py:165`) — a plain object. It does **NOT** inherit `LineWorkflowBase` / `HILSignalsMixin` (unlike the per-app line workflows). Do not import base machinery when rebuilding. See `_base-workflow.md` only to understand what this class deliberately does NOT get (no gate handling, no rework loop, no merge-retry loop, no `_dispatch_agent`/`_commit_step_artifacts`/`_submit_gate_evidence` helpers). Every method used here is defined in this one file.

**Purpose (from docstring `governance.py:1-37`):** continuous portfolio-wide learning-loop sweep. One class serves two cadences (weekly / quarterly), selected by inspecting `input.schedule_id` at `run()` time. Emits `wave_patterns_ready` signals out to active Modernization workflows (compound-growth flywheel). Dashboard observes via `get_status` query only. **No human gates exist in this workflow.**

---

## 0. MODULE-LEVEL CONSTANTS & PURE FUNCTIONS (must be reproduced verbatim)

### 0.1 `GOVERNANCE_ACTIVITIES` — per-activity registry (`governance.py:83-108`)
`dict[str, dict[str, str]]`. Each entry maps activity name → `{skill_id, artifact}`:

| activity | skill_id | artifact |
|---|---|---|
| `drift-detection` | `drift-detection` | `drift-detection.json` |
| `pattern-extraction` | `skill-builder` | `pattern-extraction.json` |
| `health-report` | `portfolio-health-check` | `health-report.json` |
| `skill-evolution` | `skill-builder` | `skill-evolution.json` |
| `factory-capacity` | `factory-capacity-manager` | `factory-capacity.json` |
| `model-evaluation` | `model-benchmark` | `model-evaluation.json` |

GOTCHA (`governance.py:88-99`): `pattern-extraction` and `skill-evolution` BOTH dispatch skill_id `skill-builder` (same skill, different task_type + artifact). A rebuild must NOT dedupe by skill_id.

### 0.2 `ACTIVITY_INPUT_ARTIFACTS` — declared input artifact globs (`governance.py:115-137`)
`dict[str, list[str]]`. Populated onto `AgentTaskInput.input_artifacts`. Exact lists (order-preserving):
- `drift-detection`: `["architecture/*/architecture-blueprint.json", "data/*/data-architecture.json", "deployment/*/cost-savings-certification.json"]`
- `pattern-extraction`: `["modernization/*/generate/*/", "modernization/*/ralph-loop-metrics.json", "modernization/*/escalation-record.json"]`
- `health-report`: `[]` (DB-first skill; no artifact reads — comment `governance.py:126`)
- `skill-evolution`: `["governance/*/pattern-extraction.json", "modernization/*/ralph-loop-metrics.json"]`
- `factory-capacity`: `["rationalization/wave-*/wave-plan.json"]`
- `model-evaluation`: `["governance/*/pattern-extraction.json"]`

`*` is the all-apps glob; the skill iterates the portfolio inventory at dispatch time (comment `governance.py:112-114`).

### 0.3 Activity-set lists
- `WEEKLY_ACTIVITIES = ["drift-detection", "pattern-extraction", "health-report", "skill-evolution", "factory-capacity"]` (`governance.py:140-146`) — 5 activities, order fixed.
- `QUARTERLY_ACTIVITIES = WEEKLY_ACTIVITIES + ["model-evaluation"]` (`governance.py:149`) — 6 activities, `model-evaluation` LAST.

### 0.4 Step-name constants (`governance.py:154-161`)
- `INTAKE_STEP = "intake"`
- `PROPAGATE_PATTERNS_STEP = "propagate-patterns"`
- `PERSIST_SWEEP_SIDE_EFFECTS_STEP = "persist-governance-sweep-side-effects"`
- `COMMIT_SWEEP_SUMMARY_STEP = "commit-sweep-summary"`
- `QUARTERLY_SCHEDULE_PREFIX = "gov-quarterly"` — prefix in `schedule_id` selecting the quarterly set. Default (unrecognized) is weekly.

### 0.5 Module functions

`_activities_for_schedule(schedule_id: str) -> list[str]` (`governance.py:764-776`):
```
if schedule_id.startswith("gov-quarterly"):
    return list(QUARTERLY_ACTIVITIES)   # fresh copy — 6 activities
return list(WEEKLY_ACTIVITIES)          # fresh copy — 5 activities
```
GOTCHA: returns a `list(...)` copy each call — callers may mutate freely without aliasing the module constant.

`_cadence_for_schedule(schedule_id: str) -> str` (`governance.py:779-783`):
```
if schedule_id.startswith("gov-quarterly"): return "quarterly"
return "weekly"
```
GOTCHA: both `_activities_for_schedule` and `_cadence_for_schedule` key off `.startswith("gov-quarterly")` INDEPENDENTLY. They must stay consistent; a rebuild must use the exact same prefix `"gov-quarterly"` (note: hyphen, not underscore).

`_governance_repo(portfolio_id: str) -> str` (`governance.py:786-794`):
```
return f"olympus/{portfolio_id}-governance"
```
Governance artifacts are portfolio-scoped (not per-app); they live in a dedicated `{portfolio_id}-governance` repo under the `olympus` org. Tests rely on this default; production overrides via deployment config (comment `governance.py:791-793`).

`_now_iso() -> str` (`governance.py:797-799`):
```
return workflow.now().isoformat()
```
GOTCHA: DETERMINISTIC — uses `workflow.now()`, NOT `datetime.now()`. Every timestamp in this workflow (state, artifacts, signals) flows through this. A rebuild MUST use the Temporal deterministic clock or replay breaks.

---

## 1. STATE (instance variables) — `__init__` (`governance.py:174-194`)

`__init__` takes no args beyond `self`; no `super().__init__()` (no base). All state is attribute-based, no module mutation.

| Attribute | Type | Initial | Mutated by / when |
|---|---|---|---|
| `_portfolio_id` | `str` | `""` | `run()` sets `= input.portfolio_id` (`:206`) |
| `_schedule_id` | `str` | `""` | `run()` sets `= input.schedule_id or "adhoc"` (`:207`) — GOTCHA: empty/None schedule_id becomes literal `"adhoc"`, which does NOT start with `gov-quarterly`, so runs weekly |
| `_status` | `WorkflowStatus` | `WorkflowStatus.PENDING` | `run()`→`RUNNING` (`:203`); `_wait_for_gate_decision` N/A; `_execute_sweep` end→`COMPLETED` (`:264`); `run()` except→`FAILED` (`:212`) |
| `_current_step` | `str` | `""` | Set at every step boundary: `intake` (`:279`), each activity name (`:232`), `propagate-patterns` (`:496`), `persist-...` (`:647`), `commit-sweep-summary` (`:704`), `"completed"` (`:265`), `"failed"` (`:213`) |
| `_progress_pct` | `float` | `0.0` | `5.0` intake (`:280`), `75.0` after gather (`:251`), `90.0` persist (`:648`), `100.0` end (`:263`). GOTCHA: propagate + commit-summary steps do NOT set progress (stays 75.0 through 90.0 jump) |
| `_started_at` | `str` | `""` | `run()` sets once (`:204`) |
| `_updated_at` | `str` | `""` | Refreshed on nearly every state mutation (many `_now_iso()` calls) |
| `_findings` | `dict[str, list[str]]` | `{}` | `_run_activity` sets `_findings[activity] = result.output_artifacts` (`:235`) |
| `_activity_metadata` | `dict[str, dict]` | `{}` | `_dispatch_activity` sets per-activity metadata dict (`:378-384`) |
| `_activity_output_json` | `dict[str, str]` | `{}` | `_dispatch_activity` sets `[activity] = text` ONLY IF `text` truthy (`:392-393`). See §4 GOTCHA — with the current `AgentTaskResult` shape this stays empty |
| `_wave_patterns_ready` | `list[dict]` | `[]` | Appended in `_run_activity` for `pattern-extraction` (`:245-248`); appended in `wave_patterns_ready` SIGNAL handler (`:309-313`). GOTCHA: two DIFFERENT dict shapes accumulate here (see §2) |
| `_pattern_reuse_acks` | `list[dict]` | `[]` | Appended ONLY in `wave_patterns_ready` signal handler (`:317-319`), one entry per pattern name |

---

## 2. SIGNALS & QUERIES

### 2.1 SIGNAL `wave_patterns_ready` (`governance.py:298-320`)
- Decorator: `@workflow.signal` (name defaults to method name `wave_patterns_ready`).
- Payload: `WavePatternsReadySignal` (`types.py:185-189`): `wave_id: str`, `patterns: list[str] = field(default_factory=list)`.
- Body (exact):
  ```
  self._wave_patterns_ready.append({
      "wave_id": signal.wave_id,
      "patterns": list(signal.patterns),
      "acknowledged_at": _now_iso(),
  })
  for pattern_name in (signal.patterns or []):
      if isinstance(pattern_name, str) and pattern_name:   # non-empty str only
          self._pattern_reuse_acks.append({"pattern_name": pattern_name, "delta": 1})
  self._updated_at = _now_iso()
  ```
- What it buffers: one dict onto `_wave_patterns_ready` (shape A: `wave_id`/`patterns`/`acknowledged_at`), plus one `{"pattern_name", "delta": 1}` onto `_pattern_reuse_acks` per non-empty string pattern.
- **Consumed by:** NO `wait_condition` blocks on this workflow. This signal is NOT awaited anywhere in `run()`; it purely accumulates side-effect state that the tail steps (`_persist_governance_sweep_side_effects`, `_commit_sweep_summary`) read. A signal that arrives after those steps run within a single sweep is effectively lost for that sweep. GOTCHA: this is a fire-and-record inbound signal, not a gate.
- GOTCHA (self-signal name collision): the workflow SENDS a signal literally named `"wave_patterns_ready"` to OTHER workflows in `_propagate_patterns` (`:539-542`) — the same name as this inbound handler. It targets `ModernizationWorkflow` instances, not itself, but the string is identical.

### 2.2 GOTCHA — two dict shapes in `_wave_patterns_ready`
- `_run_activity` appends shape B: `{"extracted_at": _now_iso(), "patterns": result.output_artifacts}` (NO `wave_id`, NO `acknowledged_at`) (`:245-248`).
- Signal handler appends shape A: `{"wave_id", "patterns", "acknowledged_at"}` (`:309-313`).
- `_collect_pattern_bundle` (`:461-479`) tolerates both because it reads only `entry.get("patterns")`. A rebuild MUST keep both shapes flowing into the same list AND the summary artifact serializes the raw list (mixed shapes) verbatim (`:727`).

### 2.3 QUERY `get_status` (`governance.py:326-338`)
- Decorator: `@workflow.query`.
- Returns `WorkflowStatusResponse` (`types.py:396-406`):
  ```
  WorkflowStatusResponse(
      workflow_id = workflow.info().workflow_id,
      status      = self._status,
      current_line = AssemblyLine.GOVERNANCE,   # == "Governance" (olympus-contracts/enums.py:325)
      current_step = self._current_step,
      progress_pct = self._progress_pct,
      pending_gate = None,                       # HARD-CODED None — Governance has no gates
      started_at   = self._started_at,
      updated_at   = self._updated_at,
  )
  ```
- GOTCHA: `pending_gate` is literally `None` always (`:334`). This is NOT the base-class `get_status` which returns `self._pending_gate`. This class defines its own `get_status` because it has no `_pending_gate` attribute.

### 2.4 Handlers that MUST NOT be overridden
Not applicable in the inheritance sense — this class has no subclasses and no base signal handlers. But NOTE: the class deliberately does NOT define `gate_approved` / `gate_rejected` / `escalation_resolved` / `merge_retry` (those live in `LineWorkflowBase`/`HILSignalsMixin` and are irrelevant here). A rebuild must NOT add gate signals.

---

## 3. CONTROL FLOW

### 3.1 `run(self, input: CronWorkflowInput) -> str` (`governance.py:196-215`)
`CronWorkflowInput` (`types.py:2728-2741`): `portfolio_id: str`, `schedule_id: str = ""`, `triggered_at: str = ""`, `activities: list[str] = []` (the `activities` field is Sustainment-only and IGNORED by Governance).

```
self._status = WorkflowStatus.RUNNING
self._started_at = _now_iso()
self._updated_at = self._started_at
self._portfolio_id = input.portfolio_id
self._schedule_id = input.schedule_id or "adhoc"     # GOTCHA falsy→"adhoc"→weekly

try:
    return await self._execute_sweep(input)          # returns "completed"
except Exception:                                     # bare Exception, no type filter
    self._status = WorkflowStatus.FAILED
    self._current_step = "failed"
    self._updated_at = _now_iso()
    raise                                             # re-raises → workflow fails in Temporal
```
Return value: the string `"completed"` (only success path) — `"failed"` is documented in the docstring (`:201`) but is NEVER returned; on failure the exception re-raises. GOTCHA: docstring says returns `"completed" or "failed"` but code never returns `"failed"`; it raises. A rebuild must RE-RAISE, not return, on error.

### 3.2 `_execute_sweep(self, input) -> str` (`governance.py:217-267`)
```
# Step 1 — intake
activities = await self._intake(input)               # 5 (weekly) or 6 (quarterly)

# Steps 2-7 — parallel fan-out
async def _run_activity(activity: str) -> None:
    self._current_step = activity
    self._updated_at = _now_iso()
    result = await self._dispatch_activity(activity, input)
    self._findings[activity] = result.output_artifacts
    await self._commit_activity_artifact(activity, result, input)
    if activity == "pattern-extraction":
        self._wave_patterns_ready.append({
            "extracted_at": _now_iso(),
            "patterns": result.output_artifacts,
        })

await asyncio.gather(*[_run_activity(a) for a in activities])   # PARALLEL
self._progress_pct = 75.0

# Step 8
await self._propagate_patterns(input)
await self._commit_latest_patterns_registry(input)

# Step 9
await self._persist_governance_sweep_side_effects(input, activities)

# Step 10
await self._commit_sweep_summary(input, activities)

self._progress_pct = 100.0
self._status = WorkflowStatus.COMPLETED
self._current_step = "completed"
self._updated_at = _now_iso()
return "completed"
```

GOTCHA — CONCURRENCY (`:250`): all 5/6 activities run concurrently via `asyncio.gather`. `_run_activity` sets `self._current_step` and `self._updated_at` at its start (`:232-233`), so with concurrent tasks the observable `_current_step` is nondeterministic-in-appearance (last-writer-wins among the racing coroutines) — but each coroutine internally does dispatch→findings→commit→(maybe append) in order. The `get_status` step value during fan-out reflects whichever activity coroutine most recently ran a step-boundary; this is expected and NOT a bug. `asyncio.gather` preserves per-coroutine ordering; Temporal serializes the activity commands deterministically.

GOTCHA — `_run_activity` mutates shared dicts (`_findings`, and via `_dispatch_activity` also `_activity_metadata`/`_activity_output_json`, and the `_wave_patterns_ready` list). These are keyed by distinct activity names (no key collision) except `_wave_patterns_ready.append` which is only executed by the single `pattern-extraction` coroutine. Safe under Temporal's single-threaded async cooperative scheduling.

GOTCHA — `_run_activity` is a CLOSURE defined INSIDE `_execute_sweep` (`:231`); it captures `input`. A rebuild must keep it nested or pass `input` explicitly.

### 3.3 `_intake(self, input) -> list[str]` (`governance.py:273-292`)
```
self._current_step = "intake"      # INTAKE_STEP
self._progress_pct = 5.0
self._updated_at = _now_iso()
activities = _activities_for_schedule(self._schedule_id)   # copy of WEEKLY or QUARTERLY
workflow.logger.info("governance intake: cadence=%s activities=%s",
                     _cadence_for_schedule(self._schedule_id), activities,
                     extra={"portfolio_id": input.portfolio_id, "schedule_id": self._schedule_id})
return activities
```
Pure determinism, NO activity call. Hoisted to a named step for dashboard rendering (comment `:275-277`).

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS

**No child workflows.** All calls are `workflow.execute_activity`. External-workflow SIGNAL dispatch (not activity) in `_propagate_patterns`.

### 4.1 `_dispatch_activity(self, activity, input) -> AgentTaskResult` (`governance.py:344-394`)
Called once per activity from `_run_activity`. Sequential inside each coroutine but parallel across activities (via gather).
```
act_def = GOVERNANCE_ACTIVITIES[activity]
task_input = AgentTaskInput(
    task_type = f"governance-{activity}",
    app_id = "",                               # portfolio-scoped
    skill_id = act_def["skill_id"],
    input_artifacts = list(ACTIVITY_INPUT_ARTIFACTS.get(activity, [])),
    artifact_repo = "",
    artifact_ref = "",
    workspace_key = f"governance-{input.portfolio_id}-{self._schedule_id}",
    context = {
        "portfolio_id": input.portfolio_id,
        "schedule_id": self._schedule_id,
        "triggered_at": input.triggered_at,
        "cadence": _cadence_for_schedule(self._schedule_id),
    },
)
result = await workflow.execute_activity(
    dispatch_agent_task,
    task_input,
    start_to_close_timeout = AGENT_START_TO_CLOSE,       # timedelta(hours=3) — agent_timeouts.py:67
    retry_policy = RETRY_POLICIES["agent_failure"],       # 3 attempts, 5s→60s exp backoff 2.0
    activity_id = f"governance-{activity}",
)
self._activity_metadata[activity] = {
    "model_used": result.model_used,
    "duration_ms": result.duration_ms,
    "token_usage_input": result.token_usage_input,
    "token_usage_output": result.token_usage_output,
    "cost_estimate_usd": result.cost_estimate_usd,
}
text = getattr(result, "output_text", "") or getattr(result, "output", "")
if isinstance(text, str) and text:
    self._activity_output_json[activity] = text
return result
```
- Retry: `agent_failure` = `RetryPolicy(initial_interval=5s, backoff_coefficient=2.0, maximum_interval=60s, maximum_attempts=3)` (`retry_policies.py:38-43`). No `non_retryable_error_types`.
- Timeout: `AGENT_START_TO_CLOSE = timedelta(hours=3)` (`agent_timeouts.py:67`). NO heartbeat_timeout is set here (unlike base `_run_gate_pre_review`).
- `activity_id` is deterministic per activity (`governance-{activity}`) — enables replay-stable command identity.
- GOTCHA (`:389-393`): `AgentTaskResult` (`types.py:519-531`) has NO `output_text` and NO `output` attribute. Both `getattr` calls return the `""` default, so `text` is always `""` and `_activity_output_json[activity]` is NEVER set from this path. Consequence: every JSON field passed to `persist_governance_sweep_side_effects` in §4.4 is `""`. A faithful rebuild must reproduce this: `_activity_output_json` stays empty with the current result contract. (This is defensive `getattr` for a field that doesn't exist on the dataclass.)

### 4.2 `_commit_activity_artifact(self, activity, result, input)` (`governance.py:396-459`)
Called once per activity inside `_run_activity` after `_dispatch_activity`.
```
act_def = GOVERNANCE_ACTIVITIES[activity]
repo   = _governance_repo(input.portfolio_id)               # olympus/{pid}-governance
branch = f"governance/{input.portfolio_id}/{self._schedule_id}"
path   = f"governance/{input.portfolio_id}/{self._schedule_id}/{act_def['artifact']}"
metadata = self._activity_metadata.get(activity, {})
content = json.dumps({
    "activity": activity,
    "skill_id": act_def["skill_id"],
    "portfolio_id": input.portfolio_id,
    "schedule_id": self._schedule_id,
    "triggered_at": input.triggered_at,
    "findings": result.output_artifacts,
    "model_used": metadata.get("model_used", ""),
    "duration_ms": metadata.get("duration_ms", 0),
    "token_usage": {"input": metadata.get("token_usage_input", 0),
                    "output": metadata.get("token_usage_output", 0)},
    "cost_estimate_usd": metadata.get("cost_estimate_usd", 0.0),
    "timestamp": workflow.now().isoformat(),          # deterministic
}, indent=2)

if workflow.patched("governance-batch-writes-v1"):
    await workflow.execute_activity(
        write_artifacts_batch,
        WriteArtifactsBatchInput(repo=repo, branch=branch,
            files=[(path, content)],
            commit_message=f"governance({input.portfolio_id}): {activity} sweep"),
        start_to_close_timeout = timedelta(seconds=120),
        retry_policy = RETRY_POLICIES["transient"],
        activity_id = f"commit-governance-{activity}",
    )
else:
    await workflow.execute_activity(
        write_artifact,
        WriteArtifactInput(repo=repo, branch=branch, path=path, content=content,
            commit_message=f"governance({input.portfolio_id}): {activity} sweep"),
        start_to_close_timeout = timedelta(seconds=60),
        retry_policy = RETRY_POLICIES["transient"],
        activity_id = f"commit-governance-{activity}",
    )
```
- **PATCH BRANCH** `workflow.patched("governance-batch-writes-v1")` (`:429`): patched path uses `write_artifacts_batch` (120s timeout); unpatched uses `write_artifact` (60s timeout). Both use `RETRY_POLICIES["transient"]` (= HTTP_RETRY_POLICY: 3 attempts, 1s→15s, backoff 2.0). Same `activity_id` in both branches. GOTCHA: the patch ID string `"governance-batch-writes-v1"` MUST be preserved verbatim for replay determinism.
- `transient` = `HTTP_RETRY_POLICY` (`retry_policies.py:34`, `temporal_base/retry_policies.py:35-40`): `initial=1s, max=15s, attempts=3, backoff=2.0`.

### 4.3 `_propagate_patterns(self, input)` — Step 8a (`governance.py:481-552`)
```
self._current_step = "propagate-patterns"
self._updated_at = _now_iso()
bundle = self._collect_pattern_bundle()
if not bundle:
    return                                       # EARLY RETURN — nothing to propagate

try:
    result = await workflow.execute_activity(
        list_active_modernization_workflows,
        ListActiveModernizationWorkflowsInput(portfolio_id=input.portfolio_id),
        start_to_close_timeout = timedelta(seconds=60),
        retry_policy = RETRY_POLICIES["transient"],
        activity_id = f"governance-list-modernization-{input.portfolio_id}-{self._schedule_id}",
    )
except Exception as exc:                          # noqa BLE001 — best-effort
    workflow.logger.warning("governance pattern propagation: enumeration failed: %s", exc,
                            extra={"portfolio_id": input.portfolio_id})
    return                                        # EARLY RETURN on enumeration failure

workflow_ids = list(result.workflow_ids or [])
if not workflow_ids:
    return                                        # EARLY RETURN — no active consumers

wave_id = f"governance-sweep-{self._schedule_id}"
signal_payload = WavePatternsReadySignal(wave_id=wave_id, patterns=bundle)

for wf_id in workflow_ids:
    try:
        handle = workflow.get_external_workflow_handle(wf_id)
        await handle.signal("wave_patterns_ready", signal_payload)
    except Exception as exc:                      # noqa BLE001 — best-effort
        workflow.logger.warning("governance pattern propagation: signal to %s failed: %s",
                                wf_id, exc, extra={"portfolio_id": input.portfolio_id})
        # SWALLOWED — loop continues to next wf_id
```
- The only activity call: `list_active_modernization_workflows` — timeout 60s, `transient` retry, deterministic `activity_id`. `ListActiveModernizationWorkflowsInput` = `{portfolio_id}` (`types.py:2891-2901`).
- Signal dispatch (NOT an activity): `workflow.get_external_workflow_handle(wf_id).signal("wave_patterns_ready", payload)` per workflow id.
- GOTCHA (resilience, comment `:491-494`): three-way best-effort. (1) empty bundle → return; (2) enumeration exception → log + return (no raise); (3) each per-handle signal failure is caught and swallowed so one dead workflow can't block the rest. A rebuild must NOT let any of these fail the sweep.
- GOTCHA: I/O (enumeration) stays in an activity; signal dispatch stays in the workflow — this split preserves determinism (comment `:487-489`).

### 4.4 `_commit_latest_patterns_registry(self, input)` — Step 8b (`governance.py:554-636`)
Cold-start registry write for Modernization workflows that START AFTER this sweep (they miss the live signal).
```
bundle = self._collect_pattern_bundle()
if not bundle:
    return                                       # EARLY RETURN

repo   = _governance_repo(input.portfolio_id)
branch = "main"                                  # NOTE: main, not the sweep branch
path   = f"governance/{input.portfolio_id}/latest-patterns.json"
content = json.dumps({
    "portfolio_id": input.portfolio_id,
    "schedule_id": self._schedule_id,
    "updated_at": _now_iso(),
    "patterns": bundle,
    "source": {"sweep_wave_id": f"governance-sweep-{self._schedule_id}",
               "triggered_at": input.triggered_at},
}, indent=2)

try:
    if workflow.patched("governance-batch-writes-v1"):
        await workflow.execute_activity(write_artifacts_batch,
            WriteArtifactsBatchInput(repo=repo, branch="main", files=[(path, content)],
                commit_message=f"governance({input.portfolio_id}): update latest-patterns registry"),
            start_to_close_timeout=timedelta(seconds=120),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"commit-governance-latest-patterns-{input.portfolio_id}-{self._schedule_id}")
    else:
        await workflow.execute_activity(write_artifact,
            WriteArtifactInput(repo=repo, branch="main", path=path, content=content,
                commit_message=f"governance({input.portfolio_id}): update latest-patterns registry"),
            start_to_close_timeout=timedelta(seconds=60),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"commit-governance-latest-patterns-{input.portfolio_id}-{self._schedule_id}")
except Exception as exc:                          # noqa BLE001 — best-effort
    workflow.logger.warning("governance latest-patterns commit failed (portfolio=%s): %s",
                            input.portfolio_id, exc)
    # SWALLOWED
```
- Same `governance-batch-writes-v1` patch branch (batch 120s / single 60s), same `transient` retry, same deterministic `activity_id` across branches.
- GOTCHA: writes to `branch="main"` (`:572`), unlike the per-activity artifact and sweep-summary which write to the sweep branch `governance/{pid}/{schedule_id}`. Modernization's `run()` reads `governance/{pid}/latest-patterns.json` at startup; missing file is a no-op (comment `:564-565`).
- GOTCHA: whole body wrapped in try/except — a commit failure here is best-effort and does NOT fail the sweep.

### 4.5 `_persist_governance_sweep_side_effects(self, input, activities)` — Step 9 (`governance.py:638-693`)
```
self._current_step = "persist-governance-sweep-side-effects"
self._progress_pct = 90.0
self._updated_at = _now_iso()
cadence = _cadence_for_schedule(self._schedule_id)
payload = PersistGovernanceSweepSideEffectsInput(
    portfolio_id = input.portfolio_id,
    schedule_id  = self._schedule_id,
    cadence      = cadence,
    drift_detection_json    = self._activity_output_json.get("drift-detection", ""),
    pattern_extraction_json = self._activity_output_json.get("pattern-extraction", ""),
    health_report_json      = self._activity_output_json.get("health-report", ""),
    factory_capacity_json   = self._activity_output_json.get("factory-capacity", ""),
    model_evaluation_json   = (self._activity_output_json.get("model-evaluation", "")
                               if cadence == "quarterly" else ""),   # branch
    pattern_reuse_acks = list(self._pattern_reuse_acks),
)
try:
    await workflow.execute_activity(
        persist_governance_sweep_side_effects,
        payload,
        start_to_close_timeout = timedelta(seconds=120),
        retry_policy = RETRY_POLICIES["transient"],
        activity_id = f"persist-governance-sweep-{input.portfolio_id}-{self._schedule_id}",
    )
except Exception as exc:                          # noqa BLE001 — best-effort
    workflow.logger.warning("persist_governance_sweep_side_effects failed: %s", exc,
        extra={"portfolio_id": input.portfolio_id, "schedule_id": self._schedule_id})
    # SWALLOWED
```
- `PersistGovernanceSweepSideEffectsInput` (`types.py:2585-2614`): fields as above; `cadence` default `"weekly"`, `pattern_reuse_acks: list[dict] = []`.
- Timeout 120s, `transient` retry, deterministic `activity_id`. NO patch branch here.
- BRANCH (`:667-671`): `model_evaluation_json` is populated only when `cadence == "quarterly"`, else `""`. (Since `_activity_output_json` is always empty per §4.1 GOTCHA, both branches currently yield `""`; the branch is still load-bearing for the intended contract.)
- GOTCHA: `pattern_reuse_acks` is passed as `list(self._pattern_reuse_acks)` — a copy snapshot; each element is `{"pattern_name": str, "delta": 1}`. NOTE the field docstring (`types.py:2611-2612`) describes `{pattern_name, ack_count}` but the actual dicts use key `"delta"`, not `"ack_count"` — the activity must read `"delta"`.
- Whole body try/except — best-effort; DB failure does NOT block Step 10.

### 4.6 `_commit_sweep_summary(self, input, activities)` — Step 10 (`governance.py:695-761`)
```
self._current_step = "commit-sweep-summary"
self._updated_at = _now_iso()                     # NOTE: does NOT set progress_pct here
repo   = _governance_repo(input.portfolio_id)
branch = f"governance/{input.portfolio_id}/{self._schedule_id}"
path   = f"governance/{input.portfolio_id}/{self._schedule_id}/sweep-summary.json"
cadence = _cadence_for_schedule(self._schedule_id)
summary = {
    "portfolio_id": input.portfolio_id,
    "schedule_id": self._schedule_id,
    "cadence": cadence,
    "triggered_at": input.triggered_at,
    "completed_at": _now_iso(),
    "activities": {
        activity: {
            "artifact": GOVERNANCE_ACTIVITIES[activity]["artifact"],
            "skill_id": GOVERNANCE_ACTIVITIES[activity]["skill_id"],
            "findings_count": len(self._findings.get(activity, [])),
        }
        for activity in activities        # ONLY the activities that ran this cadence
    },
    "wave_patterns_ready": self._wave_patterns_ready,   # raw mixed-shape list
    "pattern_reuse_acks": self._pattern_reuse_acks,
}
summary_content = json.dumps(summary, indent=2)
if workflow.patched("governance-batch-writes-v1"):
    await workflow.execute_activity(write_artifacts_batch,
        WriteArtifactsBatchInput(repo=repo, branch=branch, files=[(path, summary_content)],
            commit_message=f"governance({input.portfolio_id}): {self._schedule_id} sweep summary"),
        start_to_close_timeout=timedelta(seconds=120),
        retry_policy=RETRY_POLICIES["transient"])
        # NOTE: no explicit activity_id here (Temporal auto-assigns) — unlike other commits
else:
    await workflow.execute_activity(write_artifact,
        WriteArtifactInput(repo=repo, branch=branch, path=path, content=summary_content,
            commit_message=f"governance({input.portfolio_id}): {self._schedule_id} sweep summary"),
        start_to_close_timeout=timedelta(seconds=60),
        retry_policy=RETRY_POLICIES["transient"])
```
- BRANCH: same `governance-batch-writes-v1` patch (batch 120s / single 60s).
- GOTCHA (`:745`,`:761`): unlike every other commit in this file, the sweep-summary calls DO NOT pass an explicit `activity_id`. Temporal auto-assigns a sequence-based id. A rebuild must match this (omit `activity_id`) — adding one would change event history.
- GOTCHA: NOT wrapped in try/except — a sweep-summary commit failure DOES propagate up through `_execute_sweep`→`run()`→FAILED. This is the one tail step that can fail the sweep (per-activity commits also can, since §4.2 is not wrapped either).
- GOTCHA: `activities` dict comprehension iterates only the cadence's activity list, so a weekly summary has 5 entries, quarterly has 6 (includes `model-evaluation`). `findings_count` uses `len(self._findings.get(activity, []))` — 0 if the activity produced no artifacts.

### 4.7 `_collect_pattern_bundle(self) -> list[str]` (helper, `governance.py:461-479`)
Pure, no I/O. Flattens `_wave_patterns_ready` entries' `patterns` into a de-duplicated, order-preserving `list[str]`.
```
seen: set = set()
bundle: list = []
for entry in self._wave_patterns_ready:
    patterns = entry.get("patterns") or []
    if not isinstance(patterns, list):
        continue
    for p in patterns:
        if isinstance(p, str) and p and p not in seen:
            seen.add(p); bundle.append(p)
return bundle
```
- GOTCHA: only `str` truthy non-duplicate entries survive. Non-list `patterns` values are skipped. Preserves first-seen order across all entries (both shape A and shape B).

---

## 5. GATE HANDLING

**NONE.** GovernanceWorkflow has no gates, no gate PRs, no evidence assembly, no approve/reject/rework loop, no merge-blocked handling, no rework counters (class docstring `:166-172`; `get_status.pending_gate=None` `:334`). The `wave_patterns_ready` inbound signal is recorded, never awaited (§2.1). Do NOT add any of the base-class gate machinery when rebuilding. This is the defining structural difference from the per-app line workflows in `_base-workflow.md`.

---

## 6. RESILIENCE

- **Timeouts:** agent dispatch `AGENT_START_TO_CLOSE = 3h` (`:374`); every git commit / list / persist activity 120s (patched batch) or 60s/... as itemized in §4. No heartbeat timeouts set anywhere in this workflow.
- **Retries:** `agent_failure` (3 attempts, 5→60s) for `dispatch_agent_task`; `transient` (=HTTP: 3 attempts, 1→15s) for all git + governance-ops + persist activities. No `non_retryable_error_types` used by this workflow.
- **Continue-as-new:** NONE. Each scheduled run is a fresh short-lived workflow execution (driven by Temporal Schedules; comment `:1-15`). State does not persist across sweeps in-workflow; cross-sweep continuity is via committed artifacts (`latest-patterns.json`) and DB projection (persist step). GOTCHA: `reuse_count` durability across sweeps comes from the persist activity projecting `pattern_reuse_acks` onto the `pattern` DB row, NOT from workflow state (comment `:191-194`).
- **Idempotency:** deterministic `activity_id`s on all commits except the two sweep-summary commits; deterministic paths/branches derived from `portfolio_id` + `schedule_id`. Re-running the same schedule id overwrites the same artifact paths.
- **Compensation / rollback:** NONE. Failures in Steps 8/9 and the latest-patterns commit are best-effort (logged + swallowed). Only per-activity commits (§4.2) and the sweep-summary commit (§4.6) can fail the whole sweep by propagating.
- **Determinism:** all timestamps via `workflow.now()` (`_now_iso`, `:797-799`, and inline `workflow.now().isoformat()` at `:426`,`:795`-equiv); no random, no wall-clock, no direct I/O in workflow code (all I/O in activities). Imports are guarded by `workflow.unsafe.imports_passed_through()` (`:51`). Two patch IDs — `governance-batch-writes-v1` — must be preserved verbatim.
- **Failure path:** `run()` catches bare `Exception`, sets `_status=FAILED`, `_current_step="failed"`, refreshes `_updated_at`, and RE-RAISES (`:211-215`).

---

## 7. Behavioral parity checklist

A rebuild MUST satisfy all of these:

1. Class is standalone `@workflow.defn` with no base; defines its own `run`, `get_status`, and one signal `wave_patterns_ready`. No gate signals.
2. `run()` input is `CronWorkflowInput`; sets `_schedule_id = input.schedule_id or "adhoc"`. Empty/None → `"adhoc"` → weekly cadence.
3. Cadence selection: `schedule_id.startswith("gov-quarterly")` → quarterly (6 activities incl. `model-evaluation` last) else weekly (5 activities). Both `_activities_for_schedule` and `_cadence_for_schedule` use the identical prefix.
4. Activity registry maps exactly: drift-detection→drift-detection, pattern-extraction→skill-builder, health-report→portfolio-health-check, skill-evolution→skill-builder, factory-capacity→factory-capacity-manager, model-evaluation→model-benchmark. (pattern-extraction and skill-evolution share skill-builder.)
5. `input_artifacts` per activity match `ACTIVITY_INPUT_ARTIFACTS` exactly (health-report is empty).
6. Steps 2–7 run via a SINGLE `asyncio.gather` of `_run_activity(a)` closures — parallel, not sequential.
7. Each `_run_activity`: sets current_step=activity, dispatches agent (3h timeout, agent_failure retry, activity_id=`governance-{activity}`), records `_findings[activity]=output_artifacts`, commits the per-activity artifact, and for `pattern-extraction` ONLY appends `{extracted_at, patterns}` to `_wave_patterns_ready`.
8. `_activity_output_json` remains EMPTY because `AgentTaskResult` exposes neither `output_text` nor `output`; consequently all `*_json` fields to the persist activity are `""`.
9. `_progress_pct` sequence observable: 5.0 (intake) → 75.0 (post-gather) → 90.0 (persist) → 100.0 (end). Propagate and commit-summary steps do not change progress.
10. Per-activity artifact write: repo `olympus/{pid}-governance`, branch `governance/{pid}/{schedule_id}`, path `.../{activity-artifact}.json`, commit `governance({pid}): {activity} sweep`, activity_id `commit-governance-{activity}`, gated by `governance-batch-writes-v1` (batch 120s / single 60s), transient retry.
11. `_propagate_patterns`: early-return on empty bundle; call `list_active_modernization_workflows` (60s, transient, deterministic id) in try/except (return on failure); early-return on empty workflow_ids; build `WavePatternsReadySignal(wave_id="governance-sweep-{schedule_id}", patterns=bundle)`; loop signalling each external handle with per-handle try/except swallow.
12. `_commit_latest_patterns_registry`: early-return on empty bundle; write to `governance/{pid}/latest-patterns.json` on branch `main` (NOT the sweep branch); whole body best-effort try/except; same patch branch + activity_id `commit-governance-latest-patterns-{pid}-{schedule_id}`.
13. `_persist_governance_sweep_side_effects`: current_step + progress 90.0; build `PersistGovernanceSweepSideEffectsInput` with `model_evaluation_json` populated only when quarterly; `pattern_reuse_acks` snapshot copy; call persist activity (120s, transient, activity_id `persist-governance-sweep-{pid}-{schedule_id}`) in best-effort try/except.
14. `_commit_sweep_summary`: writes `sweep-summary.json` on the sweep branch; `activities` map has one entry per cadence activity with `{artifact, skill_id, findings_count}`; includes raw `_wave_patterns_ready` (mixed shapes) and `_pattern_reuse_acks`; NO explicit `activity_id`; NOT wrapped in try/except (can fail the sweep).
15. `_collect_pattern_bundle` de-dupes + order-preserves only non-empty `str` patterns across all `_wave_patterns_ready` entries.
16. Signal `wave_patterns_ready` appends `{wave_id, patterns(list copy), acknowledged_at}` to `_wave_patterns_ready` and one `{pattern_name, delta:1}` per non-empty str to `_pattern_reuse_acks`; it is never awaited by any wait_condition.
17. `get_status` returns `WorkflowStatusResponse` with `current_line=AssemblyLine.GOVERNANCE` ("Governance") and `pending_gate=None` always.
18. On any exception in the sweep, `run()` sets FAILED + current_step "failed" + updated_at, then re-raises (never returns "failed").
19. Success returns the literal string `"completed"`.
20. All timestamps use `workflow.now()`; patch IDs `governance-batch-writes-v1` preserved verbatim; no continue-as-new; no child workflows; no heartbeats.
