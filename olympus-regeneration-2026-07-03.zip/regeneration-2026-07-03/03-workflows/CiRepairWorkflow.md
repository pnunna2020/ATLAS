# CiRepairWorkflow — Atomic Regeneration Spec

**Source:** `temporal/olympus_workflows/workflows/ci_repair.py` (192 lines)
**Class:** `CiRepairWorkflow` (decorated `@workflow.defn` at `ci_repair.py:116`)
**Run entry:** `async def run(self, repair_input: CiRepairInput) -> dict[str, int]` (`ci_repair.py:128-192`)
**Feature:** P9-S17.4 — THIRD autonomy-gated continuous-loop *executor* (`ci_repair.py:1`). Sibling of `DependencySweepWorkflow` (P9-S17.2) and `CveTriageWorkflow` (P9-S17.3). Triages synthetic CI run status into flake-quarantine vs genuine-fix proposals, then routes EACH proposal through the existing autonomy gate.

> BEHAVIORAL PARITY BAR: rebuild so `run()` produces byte-identical summary dicts for identical inputs; triages every job with the identical flake/genuine classification (including the load-bearing "a flake is NEVER code-fixed" invariant); routes every proposal through the exact same gate call with the exact same argument mapping; and buckets outcomes with the identical three-way `if/elif/else`.

---

## 0. Architectural shape — read this first

Unlike most Olympus workflows, `CiRepairWorkflow`:

- **Does NOT subclass `BaseWorkflow`.** It is decorated directly with `@workflow.defn` (`ci_repair.py:116`) and defines only `run` (`ci_repair.py:128-129`). There is NO inherited state, NO inherited signal/query handlers, NO gate-review scaffolding from `base.py`. Do NOT import inherited behavior from `_base-workflow.md` for this class — it has none. (Docstring: it "mirrors `DependencySweepWorkflow` / `CveTriageWorkflow`", `ci_repair.py:5-7`.)
- **Has NO instance state** — no `__init__`, no instance variables (see §1).
- **Has NO signals and NO queries** — "Each run is independent (no inter-run state, no signal handlers)" (`ci_repair.py:120-121`). See §2.
- **Has NO gate wait, NO rework loop, NO continue-as-new, NO heartbeats, NO compensation.** The "gate" here is the *autonomy* advisory gate, evaluated synchronously inside an activity per proposal — NOT a Temporal signal-based human-approval gate. See §5.
- **Performs no git mutation, opens no real PR, and writes no real quarantine** (`ci_repair.py:20-22`; `activities/ci_repair.py:28-33`). It is a **governance / proposal layer**. Its only output is a summary dict for operator visibility.
- Is designed to run on a **15-minute Temporal cron** (`*/15 * * * *`, `ci_repair.py:2-4`, `118`) scheduled **out-of-band** via the Temporal Schedules API (`ci_repair.py:36-47`). The workflow itself contains NO scheduling logic.

**GOTCHA (determinism):** the workflow "reads no clock / env / DB. All decision + clock logic lives in the activities" (`ci_repair.py:49-52`). `triage_ci_failures` triages; `evaluate_autonomy` (via `gate_ci_proposal`) captures the timestamp and resolves the cap. A rebuild that reads `os.environ`, `datetime.now`, or a DB inside `run()` breaks Temporal determinism and is WRONG. Activity imports are wrapped in `with workflow.unsafe.imports_passed_through():` (`ci_repair.py:63-73`).

**GOTCHA (the load-bearing safety invariant):** a flaky failure is ONLY ever quarantined, NEVER code-fixed. This is enforced in the **triage activity** (`activities/ci_repair.py:237-247`), NOT in the workflow. The workflow "never re-derives the classification" (`activities/ci_repair.py:16-17`). A rebuild that lets a flake produce a `kind="fix"` proposal violates the #1 invariant of this executor.

---

## 1. STATE

**There are NO instance variables.** The class defines no `__init__` and no attributes; `run` is the only method (`ci_repair.py:116-192`). Each cron run is fully independent — "no inter-run state, no signal handlers" (`ci_repair.py:120-121`).

### Local variables inside `run()` (not persisted across runs)

| Name | Type | Initial | Mutated when | Cite |
|---|---|---|---|---|
| `requested_level` | `str` | `LOOP_PATTERN_REGISTRY.get("ci-repair").default_autonomy_level` → `"assisted"` | never (read once) | `ci_repair.py:141-143`; value from `loop_pattern.py:161-171` |
| `fix_paths` | `tuple[str, ...]` | `tuple(repair_input.fix_paths or ())` | never after init | `ci_repair.py:145` |
| `quarantine_paths` | `tuple[str, ...]` | `tuple(repair_input.quarantine_paths or ())` | never after init | `ci_repair.py:146` |
| `triage` | `TriageCiResult` | result of `triage_ci_failures` activity | never after init | `ci_repair.py:148-157` |
| `gated_report_only` | `int` | `0` | `+= 1` when `outcome.permitted_level == "report_only"` (elif) | `ci_repair.py:159`, `183` |
| `escalated` | `int` | `0` | `+= 1` when `outcome.escalate` is True (if) | `ci_repair.py:160`, `180` |
| `proposal` | `RepairProposal` | loop variable over `triage.proposals` | reassigned each iteration | `ci_repair.py:162` |
| `outcome` | `GatedProposalOutcome` | result of `gate_ci_proposal` activity | reassigned each iteration | `ci_repair.py:163-177` |

> NOTE there is NO local `proposed`/`permitted` counter for the third bucket (assisted/unattended-permitted). The summary dict reports `quarantine_proposals` and `fix_proposals` straight from the triage result (§4), not a per-outcome tally of PR-eligible proposals. The `# else:` branch (`ci_repair.py:184`) is a NO-OP — it increments nothing. Contrast `DependencySweepWorkflow`, which has a `proposed` counter.

### Input dataclass `CiRepairInput` (`ci_repair.py:83-113`)

Single positional payload (idiomatic Temporal shape, `ci_repair.py:86-88`). NOT a frozen `olympus_contracts` member (`ci_repair.py:101-102`).

| Field | Type | Default | Meaning | Cite |
|---|---|---|---|---|
| `loop_id` | `str` | (required) | loop identity, forwarded to the gate | `ci_repair.py:105` |
| `application_id` | `str` | (required) | touched app identity, forwarded to the gate | `ci_repair.py:106` |
| `risk_tier` | `str \| int \| None` | (required) | the tier the gate caps `assisted` down to | `ci_repair.py:107` |
| `runs` | `list[CiJobStatus]` | `field(default_factory=list)` | synthetic CI run status; list of the concrete `CiJobStatus` dataclass (NOT `dict`) so it round-trips across the Temporal payload converter | `ci_repair.py:108`, `89-97` |
| `fix_paths` | `tuple[str, ...]` | `()` | file(s) a genuine-failure fix would touch → gate's denylist-matched `paths` on every `fix` proposal | `ci_repair.py:109`, `97-100` |
| `quarantine_paths` | `tuple[str, ...]` | `()` | path(s) a quarantine action is associated with → gate's `paths` on every `quarantine` proposal | `ci_repair.py:110`, `100-101` |
| `profile_id` | `str \| None` | `None` | selects profile autonomy-policy DATA | `ci_repair.py:111` |
| `portfolio_id` | `str \| None` | `None` | evidence scope (only used if the evidence flag is on) | `ci_repair.py:112` |
| `policy_override` | `AutonomyPolicy \| None` | `None` | inject a policy directly to pin tiers/denylist deterministically; else gate loads from DATA | `ci_repair.py:113`, `98-102` |

**GOTCHA (payload shape):** `runs` MUST be a list of the concrete `CiJobStatus` dataclass, not `list[dict]`. `CiJobStatus` carries a `bool` (`is_flaky`) and a `list` (`occurrences`) alongside strings; a `dict[str, object]` value type would NOT round-trip across Temporal's payload converter (the same `object`-can't-decode boundary the gate adapter exists to sidestep) (`ci_repair.py:89-97`).

Module constant: `_PATTERN_NAME = "ci-repair"` (`ci_repair.py:80`).

### `CiJobStatus` (`activities/ci_repair.py:83-102`) — one job in the run status

| Field | Type | Default | Meaning | Cite |
|---|---|---|---|---|
| `job` | `str` | (required) | job identifier, echoed onto the proposal | `activities/ci_repair.py:98` |
| `status` | `str` | (required) | `"passed"` / `"failed"`; unknown → non-actionable | `activities/ci_repair.py:99`, `87-89` |
| `failure_signature` | `str` | `""` | WHAT failed (test node id / error fingerprint); used both to describe the proposal and by the flaky heuristic | `activities/ci_repair.py:100`, `89-92` |
| `is_flaky` | `bool` | `False` | explicit known-flake marker (trusted directly) | `activities/ci_repair.py:101`, `92-94` |
| `occurrences` | `list[str]` | `field(default_factory=list)` | recent per-run history of this signature (`["passed","failed",...]`); mixed pass+fail → flaky | `activities/ci_repair.py:102`, `94-96` |

---

## 2. SIGNALS & QUERIES

**NONE.** `CiRepairWorkflow` defines no `@workflow.signal` and no `@workflow.query` handler (`ci_repair.py:116-192`; docstring "no signal handlers", `ci_repair.py:120-121`). There is no signal buffer, no `wait_condition`, no query state. A rebuild MUST NOT add any — the workflow completes synchronously in a single pass with no external waits.

There is therefore no handler that "MUST NOT be overridden by subclasses" — the class is `@workflow.defn` directly with no subclass surface and no base-class handlers to override.

---

## 3. CONTROL FLOW

### `run(self, repair_input: CiRepairInput) -> dict[str, int]` (`ci_repair.py:128-192`)

```
run(repair_input):
    # ---- (A) resolve the requested rung from the loop-pattern catalog ----
    requested_level = LOOP_PATTERN_REGISTRY.get("ci-repair").default_autonomy_level
        # → "assisted"  (loop_pattern.py:161-171)
        # GOTCHA: LOOP_PATTERN_REGISTRY is a module-global built at import
        #   (loop_pattern.py:228-229), populated deterministically for the
        #   Temporal sandbox. .get() raises UnknownLoopPatternError (subclass of
        #   EntityNotFound) if "ci-repair" is missing — but it is a default
        #   pattern so this never fires in practice (loop_pattern.py:102-109).

    # ---- (B) normalise path tuples (None-safe) ----
    fix_paths        = tuple(repair_input.fix_paths or ())          # ci_repair.py:145
    quarantine_paths = tuple(repair_input.quarantine_paths or ())    # ci_repair.py:146

    # ---- (C) triage: ONE activity call, sequential, blocks run() ----
    triage = await execute_activity(
        triage_ci_failures,
        TriageCiInput(
            runs=list(repair_input.runs),      # copy into a fresh list
            fix_paths=fix_paths,
            quarantine_paths=quarantine_paths,
        ),
        start_to_close_timeout = 2 minutes,
        retry_policy = RETRY_POLICIES["transient"],   # = HTTP_RETRY_POLICY
    )
    # triage : TriageCiResult(proposals, quarantine_proposals, fix_proposals, passed)

    # ---- (D) init the two per-outcome buckets ----
    gated_report_only = 0    # ci_repair.py:159
    escalated         = 0    # ci_repair.py:160

    # ---- (E) route EACH proposal through the autonomy gate (SEQUENTIAL loop) ----
    for proposal in triage.proposals:            # ci_repair.py:162
        outcome = await execute_activity(
            gate_ci_proposal,
            GateProposalInput(
                loop_id         = repair_input.loop_id,
                application_id  = repair_input.application_id,
                requested_level = requested_level,          # "assisted"
                risk_tier       = repair_input.risk_tier,
                paths           = tuple(proposal.paths),     # fix_paths OR quarantine_paths
                profile_id      = repair_input.profile_id,
                portfolio_id    = repair_input.portfolio_id,
                policy_override = repair_input.policy_override,
            ),
            start_to_close_timeout = 1 minute,
            retry_policy = RETRY_POLICIES["transient"],   # = HTTP_RETRY_POLICY
        )
        # outcome : GatedProposalOutcome(permitted_level, escalate, reason, ...)

        # ---- three-way bucketing — PRESERVE EXACTLY ----
        if outcome.escalate:                              # ci_repair.py:178
            # denylist hit / attempt cap → routes to a human regardless of tier
            escalated += 1                                # ci_repair.py:180
        elif outcome.permitted_level == "report_only":    # ci_repair.py:181
            # tier cap forced the proposal down to propose-only (no PR)
            gated_report_only += 1                        # ci_repair.py:183
        # else:                                            # ci_repair.py:184
            # assisted / unattended permitted → would open a PR-proposal.
            # NO-OP: increments nothing; not separately tallied.

    # ---- (F) return the summary dict ----
    return {
        "triaged":              triage.passed,                 # ci_repair.py:187
        "quarantine_proposals": triage.quarantine_proposals,   # ci_repair.py:188
        "fix_proposals":        triage.fix_proposals,          # ci_repair.py:189
        "gated_report_only":    gated_report_only,             # ci_repair.py:190
        "escalated":            escalated,                     # ci_repair.py:191
    }
```

**GOTCHA (bucket order matters):** the `if outcome.escalate` is checked BEFORE the `elif permitted_level == "report_only"` (`ci_repair.py:178-183`). An escalating decision ALSO pins `permitted_level = "report_only"` (see §5 / `autonomy.py:294-296, 308-310`), so if the order were reversed every escalation would be miscounted as `gated_report_only`. The escalate-first order is load-bearing. Rebuild MUST keep it.

**GOTCHA (empty triage):** if `triage.proposals` is empty (all jobs passed / unknown), the loop body never runs, no gate activity is scheduled, and the summary returns `gated_report_only=0, escalated=0` with `triaged` = count of passing jobs. Valid, not an error.

**No early returns, no try/except/finally, no while loops.** `run()` is a linear pass: one triage activity, then a bounded `for` over its proposals, then a single `return`.

### `triage_ci_failures` activity → `triage_runs` (pure core) (`activities/ci_repair.py:203-284`)

The workflow calls `triage_ci_failures` (`activities/ci_repair.py:268-284`), a thin wrapper over the pure `triage_runs` (`activities/ci_repair.py:203-265`). This is where the flake-vs-fix decision lives. Reproduce exactly:

```
triage_runs(runs, fix_paths, quarantine_paths) -> TriageCiResult:
    proposals = []
    quarantine_proposals = 0
    fix_proposals = 0
    passed = 0

    for run in runs:                                          # activities/ci_repair.py:228
        status = (run.status or "").strip().lower()           # normalise
        if status != "failed":                                # activities/ci_repair.py:230
            # passing OR unknown → non-actionable, NO proposal
            if status == "passed":                            # activities/ci_repair.py:233
                passed += 1        # count ONLY an explicit "passed", not malformed rows
            continue                                          # activities/ci_repair.py:235

        # status == "failed" from here
        if _is_flaky(run):                                    # activities/ci_repair.py:237
            # FLAKE → quarantine ONLY (never a code fix — the safety invariant)
            proposals.append(RepairProposal(
                job=run.job,
                kind="quarantine",                            # QUARANTINE_KIND
                failure_signature=run.failure_signature,
                paths=quarantine_paths,      # <-- quarantine_paths, not fix_paths
            ))
            quarantine_proposals += 1                         # activities/ci_repair.py:247
        else:
            # GENUINE, reproducible failure → propose a fix PR
            proposals.append(RepairProposal(
                job=run.job,
                kind="fix",                                   # FIX_KIND
                failure_signature=run.failure_signature,
                paths=fix_paths,             # <-- fix_paths, not quarantine_paths
            ))
            fix_proposals += 1                                # activities/ci_repair.py:258

    return TriageCiResult(proposals, quarantine_proposals, fix_proposals, passed)
```

**GOTCHA (status normalization):** `status` is lowercased+stripped (`activities/ci_repair.py:229`). `"FAILED"`, `" failed "` are actionable; only exactly-`"passed"` (after normalize) bumps `passed`. Any other status (`"error"`, `"skipped"`, `""`) is silently ignored — no proposal, no `passed` bump. `TriageCiResult.passed` therefore reflects *green* jobs, not the total row count.

**GOTCHA (invariant location):** `quarantine_proposals + fix_proposals == len(proposals)` always holds (`activities/ci_repair.py:160-162`). `passed` is independent and may be 0 even with proposals.

#### `_is_flaky(run: CiJobStatus) -> bool` (`activities/ci_repair.py:179-200`)

Pure + total; classifies a FAILED job. **Show both cases:**

```
_is_flaky(run):
    if run.is_flaky:                       # explicit known-flake marker → trust directly
        return True                        # activities/ci_repair.py:196-197
    statuses = { (s or "").strip().lower() for s in run.occurrences }
    # heuristic: intermittent iff the SAME signature both passed AND failed recently
    return ("passed" in statuses) and ("failed" in statuses)   # activities/ci_repair.py:200
```

- **`is_flaky=True`** → flaky (branch 1). Quarantine, never fix.
- **`is_flaky=False`, occurrences contain BOTH `"passed"` and `"failed"`** → flaky (intermittent flapping). Quarantine.
- **`is_flaky=False`, occurrences all-fail (or empty, or only-pass)** → NOT flaky → genuine → fix PR.

**GOTCHA (conservative-on-heuristic):** the heuristic only calls flaky when it actually sees pass/fail flapping (`activities/ci_repair.py:191-194`). A signature that only ever fails is treated as a genuine regression → fix. This is deliberate: wrongly quarantining a genuine failure would silently mask a real regression. Rebuild MUST NOT flip this to "quarantine on any repeated failure."

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS

No child workflows. Two distinct activity types, both `await execute_activity`, both SEQUENTIAL (no `asyncio.gather`, no parallel fan-out). The per-proposal gate calls run one-at-a-time in a `for` loop (`ci_repair.py:162-177`) — GOTCHA: this is intentionally serial, not gathered.

| # | Order | Activity | Args (dataclass) | `start_to_close_timeout` | `retry_policy` | non_retryable | Seq/Par | Cite |
|---|---|---|---|---|---|---|---|---|
| 1 | once, first | `triage_ci_failures` | `TriageCiInput(runs=list(repair_input.runs), fix_paths, quarantine_paths)` | **2 minutes** | `RETRY_POLICIES["transient"]` | (none set on policy) | sequential | `ci_repair.py:148-157` |
| 2 | per proposal, in loop | `gate_ci_proposal` | `GateProposalInput(loop_id, application_id, requested_level="assisted", risk_tier, paths=tuple(proposal.paths), profile_id, portfolio_id, policy_override)` | **1 minute** | `RETRY_POLICIES["transient"]` | (none set on policy) | sequential (N calls, one per proposal) | `ci_repair.py:163-177` |

### `RETRY_POLICIES["transient"]` = `HTTP_RETRY_POLICY` (`retry_policies.py:34, 111`; `temporal_base/retry_policies.py:35-40`)

| Field | Value |
|---|---|
| `initial_interval` | 1 s |
| `maximum_interval` | 15 s |
| `maximum_attempts` | 3 |
| `backoff_coefficient` | 2.0 |
| `non_retryable_error_types` | (unset — none) |

**GOTCHA (retry semantics):** `transient` has NO `non_retryable_error_types`. Any exception escaping either activity is retried up to 3 attempts (1s → 2s → capped at 15s backoff). BUT `@foundry_activity` wraps a raw exception into an `ApplicationError` whose `non_retryable` flag is set by `_is_retryable_error` — a type-name substring match against `timeout/connection/network/temporary/unavailable/overload/busy/throttle/rate_limit` (`temporal_base/activities.py:56-76`). A non-matching error type is wrapped `non_retryable=True` and will NOT be retried despite the policy allowing 3 attempts. Both `triage_runs` and the gate path are documented pure/total and "never raise" (`activities/ci_repair.py:221`, `autonomy.py:287-288`), so in practice these activities complete first-attempt.

**GOTCHA (arg mapping — paths):** the gate receives `tuple(proposal.paths)` (`ci_repair.py:170`), i.e. the *per-proposal* paths — `quarantine_paths` for a quarantine proposal, `fix_paths` for a fix proposal (set in `triage_runs`, `activities/ci_repair.py:244, 256`). NOT the raw input `fix_paths`/`quarantine_paths`. A rebuild that always passes `fix_paths` to the gate would misclassify denylist matches for quarantine proposals.

### `gate_ci_proposal` — the boundary adapter (`activities/ci_repair.py:336-374`)

This activity is the reason there are two activities and not one direct `evaluate_autonomy` call:

```
gate_ci_proposal(payload: GateProposalInput) -> GatedProposalOutcome:
    # LAZY import inside the body (keeps module import-light)
    from olympus_workflows.activities.autonomy_eval import EvaluateAutonomyInput, evaluate_autonomy

    result = await evaluate_autonomy(EvaluateAutonomyInput(
        loop_id         = payload.loop_id,
        application_id  = payload.application_id,
        requested_level = payload.requested_level,     # "assisted"
        risk_tier       = payload.risk_tier,
        profile_id      = payload.profile_id,
        paths           = tuple(payload.paths),
        control_ids     = (),                          # <-- ALWAYS empty here
        policy_override = payload.policy_override,
        portfolio_id    = payload.portfolio_id,
    ))
    decision = result.decision
    return GatedProposalOutcome(
        permitted_level = decision.permitted_level,
        escalate        = decision.escalate,
        reason          = decision.reason,
        requested_level = decision.requested_level,
        risk_tier       = decision.risk_tier,
    )
```

**GOTCHA (why the adapter exists):** `evaluate_autonomy` returns `EvaluateAutonomyResult` whose nested `AutonomyDecision.metadata` is typed `dict[str, object]`, and Temporal's payload converter cannot round-trip a bare `object` value across the activity→workflow boundary (`activities/ci_repair.py:38-46`, `activities/autonomy_eval.py:254`, `autonomy.py:254`). `gate_ci_proposal` calls the real gate IN-PROCESS (the proposal still passes through `evaluate_autonomy` — same tier cap / denylist / attempt-cap logic, unduplicated) and returns ONLY the concrete scalar fields (`GatedProposalOutcome`, `activities/ci_repair.py:316-333`) so the verdict crosses the boundary cleanly. A rebuild MUST NOT call `evaluate_autonomy` directly from the workflow.

**GOTCHA (`control_ids` always empty, `attempts` defaults 0):** `gate_ci_proposal` passes `control_ids=()` (`activities/ci_repair.py:362`) and never sets `attempts`, so `EvaluateAutonomyInput.attempts` defaults to `0` (`activities/autonomy_eval.py:188`). Therefore **the attempt-cap escalation branch is UNREACHABLE from this workflow** (`0 >= cap` is false for any cap ≥ 1; see §5). Escalation from ci-repair can only come from a **denylist hit**, never the attempt cap.

**GOTCHA (evidence side-effect):** `gate_ci_proposal` "records the decision exactly as `evaluate_autonomy` does — decision log by default; evidence when the flag is on" (`activities/ci_repair.py:346-347`). With `AUTONOMY_EVIDENCE_EMIT` on AND `portfolio_id` set, each gate call lazily emits an evidence record (`activities/autonomy_eval.py:251-262, 265-322`). The workflow does not read this back; it only consumes the scalar outcome. This is a real DB side-effect of the activity, not the workflow.

---

## 5. GATE HANDLING

There is **no Temporal signal-based human-approval gate** in this workflow — no evidence assembly by the workflow, no `wait_condition`, no approve/reject/merge-blocked/rework signals, no rework loop, no rework counters. The only "gate" is the **advisory autonomy gate** evaluated synchronously per proposal inside `gate_ci_proposal` → `evaluate_autonomy` → `resolve_autonomy_level`. The workflow acts purely on the returned `GatedProposalOutcome` scalars.

### The gate verdict computation — `resolve_autonomy_level` (`autonomy.py:264-330`)

Applied in this exact order (reproduce; the ordering is a security control):

```
resolve_autonomy_level(requested_level="assisted", risk_tier, policy, paths, attempts=0):
    tier_key = _normalise_tier_key(risk_tier) or "unknown"
    tier_max = policy.tier_max(risk_tier)   # unknown/absent tier → policy.default_level (report_only)

    # (1) DENYLIST beats tier (REQ-AG-003) — checked FIRST
    if paths and policy.is_denylisted(paths):        # autonomy.py:293
        return AutonomyDecision(
            permitted_level = "report_only",         # pinned, even on Tier-3
            escalate        = True,
            reason          = "denylist_match",
            denylisted      = True, ...)

    # (2) ATTEMPT CAP (REQ-AG-004)
    cap = policy.attempt_cap if policy.attempt_cap > 0 else 3
    if attempts >= cap:                              # autonomy.py:307
        # UNREACHABLE from ci-repair: attempts is always 0 (see §4 gotcha)
        return AutonomyDecision(
            permitted_level = "report_only",
            escalate        = True,
            reason          = "attempt_cap_exceeded",
            attempt_capped  = True, ...)

    # (3) PER-TIER CAP (REQ-AG-002), fail-closed on unknown tier (REQ-AG-008)
    permitted = cap_level("assisted", tier_max)      # min(requested, tier_max) on the ladder
    capped = ladder_rank(permitted) < ladder_rank("assisted")
    return AutonomyDecision(
        permitted_level = permitted,
        escalate        = False,
        reason          = "capped_to_tier" if capped else "within_tier_cap", ...)
```

`cap_level` = the LOWER of `{requested, tier_max}` on the ladder `("report_only", "assisted", "unattended")` (`autonomy.py:72, 95-111`). Unknown `tier_max` → `report_only` (fail closed, `autonomy.py:103-106`).

### How each verdict routes in `run()` (§3 step E)

Requested level is ALWAYS `"assisted"` (rung 1). Given `attempts=0`, only three verdicts are reachable:

| Gate verdict (for `requested="assisted"`) | `escalate` | `permitted_level` | `run()` bucket | Cite |
|---|---|---|---|---|
| Denylist hit on `proposal.paths` | `True` | `"report_only"` | `escalated += 1` (if-branch, checked first) | `autonomy.py:293-303`; `ci_repair.py:178-180` |
| Tier caps `assisted` down to `report_only` (e.g. Tier-1 mapped to `report_only`, or unknown/absent tier → fail-closed default) | `False` | `"report_only"` | `gated_report_only += 1` (elif) | `autonomy.py:320-329`; `ci_repair.py:181-183` |
| Tier permits `assisted` or `unattended` (cap ≥ `assisted`, no denylist) | `False` | `"assisted"` (never higher — requested is `assisted`) | `# else:` NO-OP (would open a PR-proposal) | `autonomy.py:320-329`; `ci_repair.py:184` |

**GOTCHA:** `permitted_level` can never exceed `"assisted"` from this workflow because `cap_level` returns the *min* of requested and tier_max, and requested is `assisted`. So the `else` bucket is always `permitted_level == "assisted"`. `unattended` never appears.

**No rework loop, no counters.** A "rejected"/escalated proposal is simply tallied into `escalated`; the workflow does not retry it, re-triage it, or wait for a human — the gate's verdict is terminal for that proposal within this run. Re-evaluation happens on the NEXT cron tick (a fresh workflow run), not inside this one.

---

## 6. RESILIENCE

- **Timeouts:** `triage_ci_failures` `start_to_close=2 min` (`ci_repair.py:155`); `gate_ci_proposal` `start_to_close=1 min` (`ci_repair.py:175`). No `schedule_to_close`, `schedule_to_start`, or `heartbeat_timeout` set at the call sites. `@foundry_activity` `ActivityConfig` defaults leave all timeouts `None` (`temporal_base/activities.py:45-49`); the call-site `start_to_close_timeout` is the only bound.
- **Heartbeats:** NONE. These activities are short synchronous computations (triage is pure; gate is a fast in-process resolve + optional record). No `activity.heartbeat()` calls.
- **Continue-as-new:** NONE. The workflow is a single bounded pass and completes; cron re-invocation is external (Temporal Schedules), NOT `workflow.continue_as_new` (`ci_repair.py:36-47`, `120-124`).
- **Idempotency:** each run is independent, reads no durable inter-run state (`ci_repair.py:120-121`). Re-running with identical `runs`/paths/policy produces an identical triage (pure `triage_runs`) and identical gate verdicts (pure `resolve_autonomy_level`), hence an identical summary dict — modulo the evidence-emit side-effect (which appends a record when the flag is on). The `acting_on` lock (`autonomy.py:413-443`) that would dedupe concurrent loops on the same target is NOT invoked by this workflow.
- **Compensation / rollback:** NONE, and none needed — the executor performs no git mutation, opens no PR, writes no quarantine (`ci_repair.py:20-22`). There is nothing to undo. The only externally-visible effect is the decision-log / evidence record written inside `evaluate_autonomy` (append-only, not rolled back).
- **Failure propagation:** if an activity exhausts its 3 retries (or is wrapped non-retryable), the exception propagates out of `run()` and the workflow FAILS — no `try/except`, no partial-result return. A partial summary is never emitted. Given the activities are pure/total, this path is not expected in normal operation.

---

## 7. GOTCHAs (consolidated)

1. **No BaseWorkflow.** No inherited state/signals/queries/gate scaffolding (`ci_repair.py:116`). (§0)
2. **Determinism.** No clock/env/DB in `run()`; all such logic is in activities (`ci_repair.py:49-52`). (§0)
3. **Flake-never-fixed invariant lives in the triage activity, not the workflow** (`activities/ci_repair.py:237-247`). The workflow never re-derives classification. (§0, §3)
4. **`runs` must be `list[CiJobStatus]`, not `list[dict]`** — payload round-trip constraint (`ci_repair.py:89-97`). (§1)
5. **Bucket order: `escalate` checked before `report_only`** — escalation pins `permitted_level="report_only"`, so reversing the order miscounts every escalation (`ci_repair.py:178-183`). (§3, §5)
6. **`# else:` is a NO-OP** — assisted/unattended-permitted proposals are not separately tallied (`ci_repair.py:184`). (§1, §5)
7. **Gate receives per-proposal `proposal.paths`** (quarantine_paths vs fix_paths), not the raw input tuples (`ci_repair.py:170`; `activities/ci_repair.py:244, 256`). (§4)
8. **Two activities, not one** — `gate_ci_proposal` adapter exists solely to strip the un-serialisable `metadata: dict[str,object]` from the boundary; never call `evaluate_autonomy` from the workflow (`activities/ci_repair.py:38-46, 336-374`). (§4)
9. **`attempts` always 0** → attempt-cap escalation is unreachable; only a denylist hit escalates from ci-repair (`activities/ci_repair.py:362`; `activities/autonomy_eval.py:188`; `autonomy.py:305-317`). (§4, §5)
10. **`status` normalized (strip+lower); only exact `"passed"` bumps `triaged`**; unknown statuses are silently non-actionable (`activities/ci_repair.py:229-235`). (§3)
11. **Heuristic flake detection is conservative** — flaky only on observed pass/fail flapping; all-fail is genuine (`activities/ci_repair.py:191-200`). (§3)
12. **Sequential gate loop** — proposals gated one-at-a-time, NOT `asyncio.gather` (`ci_repair.py:162-177`). (§4)
13. **`requested_level` sourced from the module-global `LOOP_PATTERN_REGISTRY`** built at import (`loop_pattern.py:228-229`); value is `"assisted"` (`loop_pattern.py:161-171`). (§1, §3)
14. **`permitted_level` never exceeds `assisted`** from this workflow (cap = min(requested, tier_max), requested=assisted). (§5)
15. **Evidence emission is a per-gate-call side-effect** when `AUTONOMY_EVIDENCE_EMIT` on + `portfolio_id` set (`activities/autonomy_eval.py:251-262`). (§4)

---

## 8. Behavioral parity checklist

A rebuild MUST satisfy every assertion below:

1. **Class shape:** `CiRepairWorkflow` decorated `@workflow.defn`, single `@workflow.run async def run(self, repair_input: CiRepairInput) -> dict[str, int]`; no `__init__`, no instance attributes, no `@workflow.signal`, no `@workflow.query`.
2. **Requested level:** `run()` reads `default_autonomy_level` for pattern `"ci-repair"` from the loop-pattern registry and it equals `"assisted"`.
3. **Triage call:** exactly one `triage_ci_failures` activity, args `TriageCiInput(runs=list(input.runs), fix_paths=tuple(input.fix_paths or ()), quarantine_paths=tuple(input.quarantine_paths or ()))`, `start_to_close_timeout=timedelta(minutes=2)`, `retry_policy=HTTP_RETRY_POLICY` (1s/15s/3/2.0).
4. **Flake classification:** a FAILED job with `is_flaky=True` OR `occurrences` containing BOTH `"passed"` and `"failed"` → `kind="quarantine"`, `paths=quarantine_paths`; any other FAILED job → `kind="fix"`, `paths=fix_paths`. A flake NEVER yields `kind="fix"`.
5. **Passing count:** `triaged` in the output equals the count of jobs whose normalized status is exactly `"passed"`; unknown/other statuses count toward neither `triaged` nor any proposal.
6. **Proposal counts:** `quarantine_proposals + fix_proposals == len(proposals)`, and both equal the counts returned verbatim in the summary dict.
7. **Gate call:** exactly one `gate_ci_proposal` activity per proposal, in a sequential `for` loop (not gathered), args `GateProposalInput(loop_id, application_id, requested_level="assisted", risk_tier, paths=tuple(proposal.paths), profile_id, portfolio_id, policy_override)`, `start_to_close_timeout=timedelta(minutes=1)`, `retry_policy=HTTP_RETRY_POLICY`.
8. **Gate routes through real engine:** `gate_ci_proposal` calls `evaluate_autonomy` in-process with `control_ids=()` and `attempts` unset (0), and returns only `GatedProposalOutcome(permitted_level, escalate, reason, requested_level, risk_tier)`.
9. **Bucketing:** `if outcome.escalate: escalated += 1` `elif outcome.permitted_level == "report_only": gated_report_only += 1` `else: (no-op)` — in that exact order.
10. **Summary dict:** returns exactly `{"triaged": triage.passed, "quarantine_proposals": triage.quarantine_proposals, "fix_proposals": triage.fix_proposals, "gated_report_only": gated_report_only, "escalated": escalated}` — these five keys, these values, no more.
11. **Denylist → escalate:** given a `proposal.paths` matching the profile denylist, the outcome has `escalate=True` and is counted in `escalated` (not `gated_report_only`).
12. **Tier cap → report_only:** given a tier that caps `assisted` to `report_only` (or an unknown/absent tier under fail-closed defaults) and NO denylist hit, the outcome has `escalate=False, permitted_level="report_only"` and is counted in `gated_report_only`.
13. **Tier permits → no-op bucket:** given a tier permitting `assisted`+ and no denylist hit, `escalate=False, permitted_level="assisted"`, counted in NEITHER counter.
14. **Empty proposals:** with all-passing input, no gate activity is scheduled and the summary is `{triaged=N, quarantine_proposals=0, fix_proposals=0, gated_report_only=0, escalated=0}`.
15. **Determinism:** `run()` reads no clock, env, or DB; identical inputs (and identical policy) yield an identical summary dict.
16. **No mutation:** the workflow performs no git mutation, opens no PR, writes no quarantine; no continue-as-new, no signals, no rework loop, no compensation.
17. **Attempt-cap unreachable:** no input to `run()` can produce an `attempt_cap_exceeded` escalation (attempts is always 0).
