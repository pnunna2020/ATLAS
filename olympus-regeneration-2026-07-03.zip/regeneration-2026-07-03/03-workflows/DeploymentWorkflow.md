# DeploymentWorkflow — atomic regeneration spec

**Source:** `temporal/olympus_workflows/workflows/deployment.py` (1305 lines)
**Base class:** `LineWorkflowBase` (`temporal/olympus_workflows/workflows/base.py`), which extends `HILSignalsMixin` (`temporal/olympus_workflows/temporal_base/signals.py`). See `_base-workflow.md` for shared machinery; this doc fully captures the overrides + `run()` body and re-states the inherited helpers Deployment actually calls (with exact call-shape).

**Decorator / registration:** `@workflow.defn` (`deployment.py:265`). Class `DeploymentWorkflow(LineWorkflowBase)` (`deployment.py:266`).

**Purpose:** Per-app workflow that runs after Validation (modernization path) or after Disposition Execution (non-modernization path). Reconciled 18 canonical steps with per-disposition-path branching at intake (`deployment.py:1-68`).

---

## 0. Module-level constants (all in `deployment.py`)

These drive behavior; a rebuild MUST reproduce them exactly.

- `DEPLOYMENT_STEPS: dict[str, dict[str,str]]` (`:116-150`) — 6 agent steps, each `{title, skill_id, artifact}`:
  - `orchestration` → skill `deploy-modernized-app`, artifact `deployment-manifest.json`
  - `traffic-shifting` → skill `traffic-shift`, artifact `traffic-shift-log.json`
  - `parallel-run` → skill `parallel-run-monitor`, artifact `parallel-run-report.json`
  - `adoption-verification` → skill `adoption-analytics`, artifact `adoption-verification.json`
  - `legacy-decommission` → skill `legacy-decommission`, artifact `decommission-certificate.json`
  - `cost-certification` → skill `tco-analyzer`, artifact `cost-savings-certification.json`
- `PRIMARY_STEP_ORDER: list[str]` (`:155-162`) — `[orchestration, traffic-shifting, parallel-run, adoption-verification, legacy-decommission, cost-certification]`. Used by `_inputs_for_step` (prefix accumulation) and as `evidence_steps` for G-DP-2.
- `CANONICAL_STEP_ORDER: list[str]` (`:170-189`) — the 18-step UI ordering (see docstring table `:8-27`). Used for path defaults and for `_progress_for_gate`.
- `PATH_ACTIVE_STEPS: dict[str,list[str]]` (`:195-215`):
  - `Refactor`, `Rearchitect`, `Replace`, `Replatform`, `Consolidate` → full `CANONICAL_STEP_ORDER` (all 18).
  - `Retire` → `[intake, legacy-decommission, cost-certification, bundle-g-dp2-evidence, create-g-dp2-pr, ai-pre-review-dp2, gate-review-dp2, persist-deployment-side-effects, merge-final-gate-pr]` (steps 1, 11–18; **skips 2–10**).
  - **GOTCHA:** `Retain` is intentionally absent — Retain exits at Disposition's G-DE-1 and hands to Sustainment directly (`:191-194`, `:499-502`). If `_disposition_label == "Retain"`, `PATH_ACTIVE_STEPS.get(...)` returns the `list(CANONICAL_STEP_ORDER)` default (`:446-448`) — i.e. Retain would run the full sequence here. In practice Deployment is never entered with Retain.
- `STEP_WEIGHTS: dict[str,float]` (`:221-240`) — progress-bar weights summing to 100. Exact values: intake 2, orchestration 10, traffic-shifting 10, parallel-run 14, adoption-verification 12, bundle-g-dp1-evidence 2, create-g-dp1-pr 2, ai-pre-review-dp1 2, gate-review-dp1 6, merge-g-dp1-pr 2, legacy-decommission 12, cost-certification 10, bundle-g-dp2-evidence 2, create-g-dp2-pr 2, ai-pre-review-dp2 2, gate-review-dp2 6, persist-deployment-side-effects 2, merge-final-gate-pr 2. **Assigned to class attr `STEP_WEIGHTS = STEP_WEIGHTS` (`:282`).**
- `PARALLEL_RUN_DAYS: dict[int,int]` (`:247-251`) — `{1:90, 2:30, 3:14}` (Tier→calendar days).
- `DEFAULT_PARALLEL_RUN_DAYS = 30` (`:252`).
- `MAX_REWORK_ITERATIONS = 3` (`:254`).
- `ENTRY_SIGNAL_WAIT_SECONDS = 30 * 60` (`:262`) — 1800s = 30 minutes.

### Class attributes (LineWorkflowBase config) (`:277-282`)
- `ASSEMBLY_LINE = AssemblyLine.DEPLOYMENT`
- `ARTIFACT_ROOT = "deployment"`
- `LINE_LABEL = "Deployment"`
- `STATUS_PREFIX = "deployment"`
- `STEPS = DEPLOYMENT_STEPS`
- `STEP_WEIGHTS = STEP_WEIGHTS`
- **NOTE:** `SINGLE_GATE_KEY` is NOT set (inherits `None`), because Deployment has two gates and overrides `_rework_gate_key_for_step`.

---

## 1. STATE — every instance variable

Set in `__init__` (`:284-321`), which calls `super().__init__()` first (initializes all base + `HILSignalsMixin` state).

### Deployment-specific state (declared in this class)
| Var | Type | Initial | Mutated by / when |
|---|---|---|---|
| `_bundle_approvals` | `list[dict[str,str]]` | `[]` | Appended in `_run_gate` on approval+merge (`:1093-1100`), each `{gate, approved_at, approved_by, record_ref}`. Read by `_emit_output_bundle` (`:962`). |
| `_validation_signal` | `ValidationApprovedSignal \| None` | `None` | Set by `validation_approved` signal handler (`:332`). Read in `_resolve_entry_path` (`:571,576`) and `_resolve_prior_artifacts` (`:591`). |
| `_disposition_signal` | `DispositionExecutedSignal \| None` | `None` | Set by `disposition_executed` handler (`:340`). Read in `_resolve_entry_path` (`:563-564`) and `_resolve_prior_artifacts` (`:595`). |
| `_stakeholder_ops_approved` | `bool` | `False` | Set `True` by `stakeholder_approved` handler when scope in `("g-dp1-ops","g-dp2-ops")` (`:364-365`). Consumed by `_tier_1_stakeholders_ready` (`:1140,1145`). |
| `_stakeholder_safety_approved` | `bool` | `False` | Set `True` on scope `g-dp1-safety` (`:366-367`). Consumed for G-DP-1 tier-1 (`:1141`). |
| `_stakeholder_cert_approved` | `bool` | `False` | Set `True` on scope `g-dp2-cert` (`:368-369`). Consumed for G-DP-2 tier-1 (`:1146`). |
| `_manifest_json` | `str` | `""` | Set from `orchestration` step's `result.output_artifacts[0]` (`:645-650`). Read in `_persist_side_effects` (`:828`) and `_fail` (`:1177`). |
| `_decommission_certificate_json` | `str` | `""` | Set from `legacy-decommission` `output_artifacts[0]` (`:777-782`). Read in persist / fail. |
| `_license_reclamation_json` | `str` | `""` | Set from `legacy-decommission` `output_artifacts[1]` if `len>1` else `""` (`:785-789`). |
| `_cost_certification_json` | `str` | `""` | Set from `cost-certification` `output_artifacts[0]` (`:790-795`). |
| `_parallel_run_duration_days` | `int` | `0` | Set from `_parallel_run_days(...)` in `_run_deploy_and_shift` (`:653-656`). Read in `_persist_side_effects` to inject into manifest (`:829-848`). |
| `_disposition_label` | `str` | `""` | Set in `_resolve_entry_path` (`:542,560,564,581,584`). Drives path branching (`:446`, `:456`, `:503`). |

### Inherited state used by this class (from `LineWorkflowBase.__init__`, `base.py:136-191`)
- `_app_id: str = ""` — set in `run` (`:402`).
- `_risk_tier: int|None = None` — set in `run` from `input.risk_tier` (`:403-405`); may be filled in `_resolve_entry_path` (`:569,576-580`). Drives Tier-1 triple-signal and parallel-run duration.
- `_status: WorkflowStatus = PENDING` — set to RUNNING (`:397`), COMPLETED (`:515`), FAILED (`:418,1169`), CANCELLED (`:1131` and base `_wait_for_gate_decision`), WAITING_FOR_SIGNAL (base wait).
- `_current_step: str = ""` — set by `_set_step`, and directly at terminal states (`:419,517,1170`).
- `_progress_pct: float = 0.0` — set by `_set_step`; set `100.0` at completion (`:516`).
- `_pending_gate: GateType|None = None` — set/cleared inside base `_wait_for_gate_decision`.
- `_started_at`, `_updated_at: str` — `_started_at` set in `run` (`:398`); `_updated_at` refreshed on nearly every state change and every signal handler.
- `_gate_decisions: list[tuple]` + `_gate_decisions_consumed: int = 0` — the gate-decision FIFO queue; appended by base `gate_approved`/`gate_rejected` handlers, consumed by `_wait_for_gate_decision`.
- `_rework_feedback: dict[str,dict] = {}` — set by base `_wait_for_gate_decision` on rejection; forwarded into agent context by `_dispatch_agent`.
- `_rework_iterations: dict[str,int] = {}` — per-gate rework counter; `_bump_rework`/`_rework_count`.
- `_step_results: dict[str,list[str]] = {}` — Deployment sets `_step_results[step]=result.output_artifacts` after each dispatch (`:633,703,765`).
- `_step_committed_paths: dict[str,list[str]] = {}` — set by base `_commit_step_artifacts`; read by `_inputs_for_step`, `_run_gate` evidence assembly, `_emit_output_bundle.step_path`.
- `_agent_metadata: dict[str,dict] = {}` — set by base `_dispatch_agent`.
- `_merge_retry_signalled: bool = False` — set by base `merge_retry` handler; consumed by `_reconcile_and_merge_with_retry_loop`.
- `_portfolio_id`, `_wave_id`, `_profile_id`, `_portfolio_fallback_policy`, `_redispatch_guard` — used by `_execution_ctx`; **GOTCHA: Deployment never sets `_portfolio_id` in `run()`**, so `_execution_ctx` returns `None` for every dispatch/commit (`base.py:345-346`) and no `step_execution` timeline rows are emitted. (Portfolio scoping is passed only via activity inputs like `CreateGateRecordInput.portfolio_id` from `input.portfolio_id`.)

### Inherited from `HILSignalsMixin.__init__` (`signals.py:29-45`)
- `approved`, `plan_approved`, `plan_feedback_received`, `plan_feedback_comments`, `document_approved`, `document_feedback_received`, `document_feedback_comments` — present but unused by Deployment.
- `cancelled: bool = False` — the cancellation flag; checked in every long `wait_condition` predicate (`:552`, `:1129-1130`, and base gate/merge waits). Set `True` by the `cancel_workflow` signal (`signals.py:83-86`).

---

## 2. SIGNALS & QUERIES

### Deployment-defined signals

**`validation_approved(signal: ValidationApprovedSignal)`** (`@workflow.signal`, `:327-333`)
- Payload `ValidationApprovedSignal` (`types.py:288-307`): `target_app_id, portfolio_id, validation_output_refs: list[str], approved_at: str, risk_tier: str`.
- Buffers: `self._validation_signal = signal`; refreshes `_updated_at`.
- Consumed by predicate in `_resolve_entry_path` (`:548-555`): `self._validation_signal is not None or self._disposition_signal is not None or self.cancelled`.

**`disposition_executed(signal: DispositionExecutedSignal)`** (`@workflow.signal`, `:335-341`)
- Payload `DispositionExecutedSignal` (`types.py:265-284`): `app_id, disposition: str, disposition_output_ref: str, portfolio_id, executed_at`.
- Buffers: `self._disposition_signal = signal`; refreshes `_updated_at`.
- Consumed by same predicate (`:548-555`).

**`stakeholder_approved(signal: StakeholderApprovedSignal)`** (`@workflow.signal`, `:347-370`)
- Payload `StakeholderApprovedSignal` (`types.py:167-172`): `approval_id, stakeholder, scope`.
- Branch on `signal.scope` (`:363-369`):
  - `scope in ("g-dp1-ops","g-dp2-ops")` → `_stakeholder_ops_approved = True`.
  - `elif scope == "g-dp1-safety"` → `_stakeholder_safety_approved = True`.
  - `elif scope == "g-dp2-cert"` → `_stakeholder_cert_approved = True`.
  - else (any other scope) → no state change.
  - Always refreshes `_updated_at`.
- **GOTCHA:** `g-dp1-ops` and `g-dp2-ops` share the SAME flag `_stakeholder_ops_approved`. Because the flag is never reset between gates, an ops signal delivered during G-DP-1 stays set into G-DP-2 (and vice-versa). For Tier-1 G-DP-2, only the `g-dp2-cert` signal must newly arrive if `g-dp1-ops` already flipped `_stakeholder_ops_approved`. A rebuild MUST use a single shared ops flag to match. Consumed by `_tier_1_stakeholders_ready` (`:1136-1148`).

### Inherited signals (from `LineWorkflowBase`, `base.py:197-257`) — DO NOT override in subclasses (`base.py:194` comment)
- **`gate_approved(GateApprovedSignal)`** (`:197-209`) — appends `(APPROVED, approved_by, justification, None, [])` to `_gate_decisions`. **MUST NOT be overridden**: `_wait_for_gate_decision` depends on the exact 5-tuple/3-tuple envelope shape it enqueues.
- **`gate_rejected(GateRejectedSignal)`** (`:211-232`) — appends `(REJECTED, rejected_by, reason, reason_category, card_decisions)`. `card_decisions`/`reason_category` are `getattr`-normalized for older senders.
- **`escalation_resolved(EscalationResolvedSignal)`** (`:234-239`) — refreshes `_updated_at` only.
- **`merge_retry(GateMergeRetrySignal)`** (`:241-257`) — sets `_merge_retry_signalled = True`; idempotent. Consumed by `_reconcile_and_merge_with_retry_loop`.

### Inherited from `HILSignalsMixin` (`signals.py:48-86`)
- `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve` — present, unused by Deployment logic.
- **`cancel_workflow()`** (`:83-86`) — sets `cancelled = True`. This is the cancellation entry point.

### Queries
- **`status()`** (`@workflow.query`, base `base.py:1353-1365`) — returns `WorkflowStatusResponse(workflow_id, status, current_line=ASSEMBLY_LINE, current_step, progress_pct, pending_gate, started_at, updated_at)`. Deployment does not override.
- No Deployment-specific queries.

---

## 3. CONTROL FLOW

### `run(input: LineWorkflowInput) -> str` (`@workflow.run`, `:390-431`)
Returns `"completed"`, `"cancelled"`, or `"failed"`.

```
run(input):
    self._status = RUNNING                              # :397
    self._started_at = _now_iso()                       # :398
    self._updated_at = self._started_at                 # :399
    app_id = input.app_id; self._app_id = app_id        # :401-402
    self._risk_tier = int(input.risk_tier) if input.risk_tier is not None else None   # :403-405
    repo = input.artifact_repo                           # :406
    wf_id = workflow.info().workflow_id                  # :408
    run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]   # :409
    branch = f"olympus/deployment/{app_id}/{run_suffix}" # :410
    workspace_key = f"deployment-{app_id}-{run_suffix}"  # :411
    try:
        return await self._execute_deployment(input, app_id, repo, branch, workspace_key)   # :414-416
    except Exception:                                    # :417
        self._status = FAILED                            # :418
        self._current_step = "failed"                    # :419
        self._updated_at = _now_iso()                    # :420
        try:
            await self._update_app_status(app_id, "deployment_in_progress", "failed", "Deployment")   # :426-428
        except Exception:
            pass    # best-effort                        # :429-430
        raise                                            # :431
```
**GOTCHA (`:426-428`):** on top-level exception the app-status projection writes `current_step="failed"` but keeps status `deployment_in_progress` (lifecycle marker NOT advanced). Then the exception RE-RAISES → Temporal marks the workflow run failed (this path does NOT return `"failed"`; only `_fail()` returns the string).

### `_execute_deployment(input, app_id, repo, branch, workspace_key) -> str` (`:433-519`)

```
# ---- Step 1: intake ----
await self._set_step("intake", 0.0)                          # :443
await self._resolve_entry_path(input)                        # :444  (may block up to 30 min on entry signal)
prior_artifacts = self._resolve_prior_artifacts(input)       # :445
active_steps = PATH_ACTIVE_STEPS.get(self._disposition_label, list(CANONICAL_STEP_ORDER))  # :446-448
cumulative = STEP_WEIGHTS["intake"]   # = 2.0                # :450

# ---- Steps 2-5 + G-DP-1: only if "orchestration" in active_steps ----
if "orchestration" in active_steps:                          # :456  (True for all paths EXCEPT Retire)
    cumulative = await self._run_deploy_and_shift(app_id, repo, branch, workspace_key,
                                                  prior_artifacts, cumulative, input)   # :457-460
    gdp1_outcome = await self._run_gdp1_with_rework(input, app_id, repo, branch,
                                                    workspace_key, prior_artifacts, cumulative)  # :463-466
    if gdp1_outcome == "cancelled":                          # :467
        return "cancelled"
    if gdp1_outcome == "failed":                             # :469
        return await self._fail("max-rework-exceeded-gdp1", app_id)   # :470
    cumulative += sum(STEP_WEIGHTS[s] for s in (adoption-verification, bundle-g-dp1-evidence,
        create-g-dp1-pr, ai-pre-review-dp1, gate-review-dp1, merge-g-dp1-pr))  # :471-480  (+26.0)

# ---- Steps 11-16: G-DP-2 rework loop (ALWAYS runs, incl. Retire) ----
gdp2_outcome = await self._run_gdp2_with_rework(input, app_id, repo, branch,
                                                workspace_key, prior_artifacts, cumulative)  # :483-486
if gdp2_outcome == "cancelled":                              # :487
    return "cancelled"
if gdp2_outcome == "failed":                                 # :489
    return await self._fail("max-rework-exceeded-gdp2", app_id)   # :490

# ---- Step 17: persist side effects ----
await self._set_step("persist-deployment-side-effects", 96.0)   # :493
await self._persist_side_effects(app_id)                     # :494

# ---- Step 18: merge final gate PR → Sustainment handoff ----
await self._set_step("merge-final-gate-pr", 98.0)            # :497
if self._disposition_label in ("Refactor", "Rearchitect"):   # :503
    await self._emit_output_bundle(input=input, app_id=app_id, repo=repo, branch=branch,
                                   disposition_label=self._disposition_label)  # :504-510
await self._update_app_status(app_id, "sustainment_active", "registered", "Sustainment")  # :512-514
self._status = COMPLETED                                     # :515
self._progress_pct = 100.0                                   # :516
self._current_step = "completed"                             # :517
self._updated_at = _now_iso()                                # :518
return "completed"                                           # :519
```
**GOTCHA (`:456`):** the Steps-2-5 + G-DP-1 block is gated on `"orchestration" in active_steps`. For `Retire`, orchestration is absent → the entire deploy/shift/parallel-run/adoption-verify + G-DP-1 block is skipped; execution jumps straight to G-DP-2 with `cumulative` still `= 2.0` (only intake weight). No compensation for the skipped weight — progress bar jumps.
**GOTCHA (`:503`):** the disposition-output bundle (Step 18) is emitted ONLY for `Refactor`/`Rearchitect`. Replace/Replatform/Consolidate run the full 18 steps but do NOT emit here (their bundle is owned by Disposition, `:499-502`).

### `_resolve_entry_path(input)` (`:525-585`)
```
if input.disposition is not None:                            # :541
    self._disposition_label = input.disposition.value        # :542
    return
# else: wait for an entry signal
try:                                                         # :547
    await workflow.wait_condition(
        lambda: (self._validation_signal is not None
                 or self._disposition_signal is not None
                 or self.cancelled),
        timeout=timedelta(seconds=ENTRY_SIGNAL_WAIT_SECONDS)) # :548-555  (1800s)
except Exception:                                            # :556  (timeout / wait failure)
    self._disposition_label = "Refactor"                     # :560
    return
if self._disposition_signal is not None:                     # :563
    self._disposition_label = self._disposition_signal.disposition   # :564
    if self._risk_tier is None:                              # :569
        self._risk_tier = 2                                  # :570  (default Tier-2)
elif self._validation_signal is not None:                    # :571
    if self._risk_tier is None and self._validation_signal.risk_tier:   # :576
        try:
            self._risk_tier = int(self._validation_signal.risk_tier)    # :578
        except (TypeError, ValueError):
            self._risk_tier = 2                              # :580
    self._disposition_label = "Refactor"                     # :581
else:                                                        # :582  (woke via cancelled)
    self._disposition_label = "Refactor"                     # :584
```
**GOTCHA (`:556-561`):** a timeout after 30 minutes does NOT fail — it silently defaults to `Refactor` (full modernization path, empty bundle). A misconfigured start "fails loudly" only relative to hanging forever.
**GOTCHA (`:563` precedence):** if BOTH signals arrive, `_disposition_signal` wins (checked first). `_validation_signal` only applies when disposition-signal is absent.
**GOTCHA:** on the disposition-signal path, `_disposition_label` is set to the RAW `signal.disposition` string (e.g. `"Retire"`, `"Replace"`) — path branching keys off exact string match against `PATH_ACTIVE_STEPS`.

### `_resolve_prior_artifacts(input) -> list[str]` (`:586-599`)
```
prior = list(input.prior_artifacts)                          # :590
if self._validation_signal is not None:                      # :591
    for ref in self._validation_signal.validation_output_refs:   # :592
        if ref and ref not in prior: prior.append(ref)       # :593-594
if self._disposition_signal is not None:                     # :595
    ref = self._disposition_signal.disposition_output_ref    # :596
    if ref and ref not in prior: prior.append(ref)           # :597-598
return prior
```

### `_run_deploy_and_shift(...) -> float` (Steps 2-4) (`:605-672`)
```
for step_name in ("orchestration", "traffic-shifting", "parallel-run"):   # :622
    await self._set_step(step_name, cumulative)              # :623
    step_inputs = self._inputs_for_step(step_name, prior_artifacts)   # :624
    result = await self._dispatch_agent(app_id, step_name, step_inputs, workspace_key, repo, branch)  # :625-632
    self._step_results[step_name] = result.output_artifacts  # :633
    artifact_path = f"deployment/{app_id}/{DEPLOYMENT_STEPS[step_name]['artifact']}"   # :634-637
    await self._commit_step_artifacts(repo, branch, app_id, step_name, result, artifact_path)  # :638-640
    cumulative += STEP_WEIGHTS[step_name]                    # :641
    if step_name == "orchestration":                         # :645
        self._manifest_json = result.output_artifacts[0] if result.output_artifacts else ""  # :646-650
    if step_name == "parallel-run":                          # :652
        duration_days = _parallel_run_days(input.risk_tier, self._risk_tier)   # :653-655
        self._parallel_run_duration_days = duration_days     # :656
        soak_seconds = await workflow.execute_activity(resolve_parallel_run_seconds, duration_days,
                          start_to_close_timeout=30s, retry_policy=transient)  # :664-669
        await workflow.sleep(timedelta(seconds=soak_seconds))   # :670
return cumulative
```
**GOTCHA (`:664-670`):** the parallel-run "soak" is a **durable `workflow.sleep`**. Production sleeps `duration_days*86400` seconds (14/30/90 days). `resolve_parallel_run_seconds` reads env `OLYMPUS_PARALLEL_RUN_OVERRIDE_SECONDS` (in the ACTIVITY, so the workflow stays deterministic — workflow code must not read `os.environ`); dev/integration sets it to collapse the timer. Under Temporal time-skipping tests the sleep is near-zero real time.

### `_run_gdp1_with_rework(...) -> str` (Steps 5 + 6-10) (`:674-734`)
Returns `"approved" | "cancelled" | "failed"`.
```
while True:                                                  # :689
    # Step 5: adoption-verification
    await self._set_step("adoption-verification", cumulative)   # :691
    step_inputs = self._inputs_for_step("adoption-verification", prior_artifacts)  # :692-694
    result = await self._dispatch_agent(app_id, "adoption-verification", step_inputs, workspace_key, repo, branch)  # :695-702
    self._step_results["adoption-verification"] = result.output_artifacts   # :703
    artifact_path = f"deployment/{app_id}/adoption-verification.json"   # :704-707
    await self._commit_step_artifacts(repo, branch, app_id, "adoption-verification", result, artifact_path)  # :708-711
    # Steps 6-10: G-DP-1 gate
    gdp1_decision = await self._run_gate(input, repo, branch, app_id,
        gate_type=GateType.G_DP_1, gate_step="gate-review-dp1",
        evidence_steps=[orchestration, traffic-shifting, parallel-run, adoption-verification],
        title=f"Gate G-DP-1: Cutover Go — {app_id}", body_builder=self._build_gdp1_pr_body)  # :714-726
    if gdp1_decision == "cancelled": return "cancelled"      # :727-728
    if gdp1_decision == "rejected":                          # :729
        self._bump_rework("G-DP-1")                          # :730
        if self._rework_count("G-DP-1") > MAX_REWORK_ITERATIONS: return "failed"   # :731-732  (>3)
        continue                                             # :733  (re-run adoption-verification only)
    return "approved"                                        # :734
```
**GOTCHA (rework scope):** on G-DP-1 rejection ONLY adoption-verification re-runs (deploy/shift/parallel-run are NOT re-run). Counter `G-DP-1`; failure when count `> 3` (i.e. the 4th rejection). `cumulative` is NOT advanced on retry — each retry re-sets step at the same progress value.

### `_run_gdp2_with_rework(...) -> str` (Steps 11-16) (`:736-815`)
Returns `"approved" | "cancelled" | "failed"`.
```
while True:                                                  # :750
    step_cumulative = cumulative                             # :751  (reset each retry)
    for step_name in ("legacy-decommission", "cost-certification"):   # :752
        await self._set_step(step_name, step_cumulative)     # :753
        step_inputs = self._inputs_for_step(step_name, prior_artifacts)   # :754-756
        result = await self._dispatch_agent(app_id, step_name, step_inputs, workspace_key, repo, branch)  # :757-764
        self._step_results[step_name] = result.output_artifacts   # :765
        artifact_path = f"deployment/{app_id}/{DEPLOYMENT_STEPS[step_name]['artifact']}"  # :766-769
        await self._commit_step_artifacts(repo, branch, app_id, step_name, result, artifact_path)  # :770-773
        step_cumulative += STEP_WEIGHTS[step_name]           # :774
        if step_name == "legacy-decommission":               # :777
            self._decommission_certificate_json = result.output_artifacts[0] if result.output_artifacts else ""  # :778-782
            self._license_reclamation_json = result.output_artifacts[1] if len(result.output_artifacts) > 1 else ""  # :785-789
        elif step_name == "cost-certification":              # :790
            self._cost_certification_json = result.output_artifacts[0] if result.output_artifacts else ""  # :791-795
    # Steps 13-16: G-DP-2 gate
    gdp2_decision = await self._run_gate(input, repo, branch, app_id,
        gate_type=GateType.G_DP_2, gate_step="gate-review-dp2",
        evidence_steps=PRIMARY_STEP_ORDER,
        title=f"Gate G-DP-2: Deployment Complete — {app_id}", body_builder=self._build_gdp2_pr_body)  # :798-807
    if gdp2_decision == "cancelled": return "cancelled"      # :808-809
    if gdp2_decision == "rejected":                          # :810
        self._bump_rework("G-DP-2")                          # :811
        if self._rework_count("G-DP-2") > MAX_REWORK_ITERATIONS: return "failed"   # :812-813
        continue                                             # :814
    return "approved"                                        # :815
```
**GOTCHA (rework scope):** on G-DP-2 rejection BOTH legacy-decommission AND cost-certification re-run (the whole inner `for`). Counter `G-DP-2`.
**GOTCHA (`:751`):** `step_cumulative = cumulative` re-initializes at the top of each retry so weights don't compound across retries.
**GOTCHA (`:802`):** G-DP-2 evidence steps = `PRIMARY_STEP_ORDER` (all 6 agent steps). For a `Retire` run, `_step_committed_paths` for orchestration/traffic-shifting/parallel-run/adoption-verification are empty (never ran), so `_run_gate`'s `evidence_paths` collects only legacy-decommission + cost-certification paths (empty entries contribute nothing via `.get(step, [])`).

### `_persist_side_effects(app_id)` (Step 17) (`:817-877`)
```
manifest_with_duration = self._manifest_json                 # :828
if (self._parallel_run_duration_days and manifest_with_duration
        and '"parallel_run"' not in manifest_with_duration):  # :829-833
    import json as _json                                     # :838
    try:
        parsed = _json.loads(manifest_with_duration)         # :841
        if isinstance(parsed, dict):                         # :842
            parsed.setdefault("parallel_run", {})            # :843
            if isinstance(parsed["parallel_run"], dict):     # :844
                parsed["parallel_run"]["observed_duration_days"] = self._parallel_run_duration_days  # :845-847
                manifest_with_duration = _json.dumps(parsed) # :848
    except (TypeError, ValueError):
        pass                                                 # :849-852  (leave manifest as-is)
try:                                                         # :854
    await workflow.execute_activity(persist_deployment_side_effects,
        PersistDeploymentSideEffectsInput(target_app_id=app_id,
            deployment_manifest_json=manifest_with_duration,
            decommission_certificate_json=self._decommission_certificate_json,
            license_reclamation_json=self._license_reclamation_json,
            cost_savings_certification_json=self._cost_certification_json,
            deployment_current_status="completed"),
        start_to_close_timeout=60s, retry_policy=transient)  # :855-871
except Exception:                                            # :872
    workflow.logger.warning("persist_deployment_side_effects failed; continuing ...", extra={"app_id":app_id})  # :873-877
```
**GOTCHA (`:829-833`):** the manifest injection only fires when a duration was observed AND the manifest is non-empty AND doesn't already contain the substring `"parallel_run"`. If the manifest isn't valid JSON, the injection is silently skipped (`except: pass`) — the extractor is expected to tolerate this and read the top-level fallback key.
**GOTCHA:** best-effort — any activity failure is swallowed so the Sustainment handoff isn't blocked (`:872-877`). `deployment_current_status="completed"`.

### `_emit_output_bundle(...)` (part of Step 18) (`:883-985`)
Only called for `Refactor`/`Rearchitect`.
```
def step_path(step_name): paths=self._step_committed_paths.get(step_name,[]); return paths[0] if paths else ""  # :894-896
wave_id = getattr(input,"wave_id","") or ""                  # :898
disposition_decision_ref = f"rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json" if wave_id else ""  # :899-904
baseline_ref = f"rationalization/wave-{wave_id}/{app_id}/tco-analysis.json" if wave_id else None   # :905-909
user_impact_ref = f"rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json" if wave_id else None  # :910-914
payload = { disposition, modernized_repo_url=(getattr(input,"source_repo","") or f"https://github.com/org/{app_id}-modernized"),
            blueprint_ref, generation_run_ref, parity_report_ref,
            test_coverage={before_pct:0.0, after_pct:0.0, coverage_report_ref},
            deployment={environment:"aws:us-east-1:prod", endpoint:None,
                        deployment_ref: step_path("adoption-verification") or f"deployment/{app_id}/deployment-evidence.json"} }  # :916-946
if disposition_label == "Rearchitect":                       # :947
    payload["bounded_context_map_ref"] = f"architecture/{app_id}/bounded-context-map.json"  # :948-950
bundle = { application_id, application_name=(input.app_name or app_id), portfolio_id, wave_id,
           disposition, status:"completed", started_at=self._started_at, completed_at=_now_iso(),
           disposition_decision_ref, approvals=list(self._bundle_approvals),
           realized_net_impact={tco_delta:{annual_savings_usd:None, one_time_cost_usd:None, baseline_ref},
                                users_affected_actual:None, users_affected_estimate_ref:user_impact_ref},
           payload }  # :952-973
await workflow.execute_activity(emit_disposition_output_bundle,
    EmitDispositionOutputBundleInput(repo, branch, portfolio_id=input.portfolio_id, app_id, bundle),
    start_to_close_timeout=60s, retry_policy=transient)      # :974-985
```
**GOTCHA (`:947-950`):** `bounded_context_map_ref` is added to the payload ONLY for `Rearchitect`, not `Refactor`.

### `_inputs_for_step(step_name, prior_artifacts) -> list[str]` (`:987-1001`)
```
inputs = list(prior_artifacts)                               # :996
for prev in PRIMARY_STEP_ORDER:                              # :997
    if prev == step_name: break                              # :998-999
    inputs.extend(self._step_committed_paths.get(prev, []))  # :1000
return dedup_paths(inputs)                                   # :1001
```
Each step sees prior_artifacts + every earlier PRIMARY step's committed paths (in canonical order), deduped. **GOTCHA:** iterates `PRIMARY_STEP_ORDER`; for a step not in that list it would accumulate ALL primary steps (never `break`) — but every dispatched step here is in the list.

### `_run_gate(...) -> str` (`:1008-1102`)
Returns `"approved" | "rejected" | "cancelled"`. See §5.

### `_wait_for_gate_decision_with_tier_1(gate_type) -> str` (`:1104-1134`)
```
if self._risk_tier != 1:                                     # :1115
    return await self._wait_for_gate_decision(gate_type)     # :1116  (base single-signal wait)
decision = await self._wait_for_gate_decision(gate_type)     # :1120  (PM signal first)
if decision != "approved": return decision                   # :1121-1122  (rejected/cancelled short-circuit)
await workflow.wait_condition(lambda: self._tier_1_stakeholders_ready(gate_type) or self.cancelled)  # :1126-1129
if self.cancelled:                                           # :1130
    self._status = CANCELLED; self._updated_at = _now_iso(); return "cancelled"   # :1131-1133
return "approved"                                            # :1134
```
**GOTCHA (`:1115`):** Tier gating uses `self._risk_tier != 1`. Only `_risk_tier == 1` (int) triggers triple-signal. If tier is `None` (never resolved) it takes the non-Tier-1 path. Tier-2/3 approve on the PM `gate_approved` signal alone.

### `_tier_1_stakeholders_ready(gate_type) -> bool` (`:1136-1148`)
```
if gate_type == GateType.G_DP_1: return _stakeholder_ops_approved and _stakeholder_safety_approved   # :1138-1142
if gate_type == GateType.G_DP_2: return _stakeholder_ops_approved and _stakeholder_cert_approved      # :1143-1147
return True                                                  # :1148
```

### `_rework_gate_key_for_step(step_name) -> str|None` (OVERRIDE) (`:376-384`)
```
if step_name in ("legacy-decommission", "cost-certification"): return "G-DP-2"   # :382-383
return "G-DP-1"                                              # :384
```
**GOTCHA:** every step NOT in the G-DP-2 pair maps to `G-DP-1` (including orchestration/traffic/parallel/adoption). Used by base `_dispatch_agent` to forward the right rework feedback into the agent context.

### `_progress_for_gate(gate_step) -> float` (`:1150-1157`)
```
total = 0.0
for step in CANONICAL_STEP_ORDER:                            # :1153
    total += STEP_WEIGHTS.get(step, 0.0)                     # :1154
    if step == gate_step: break                              # :1155-1156
return total
```
Cumulative weight up to and including the gate step. `gate-review-dp1` → 2+10+10+14+12+2+2+2+6 = 60.0; `gate-review-dp2` → 60+2+2(merge-dp1)+12+10+2+2+2+6 = 96.0.

### `_fail(reason_step, app_id) -> str` (`:1159-1195`)
```
self._status = FAILED                                        # :1169
self._current_step = reason_step                             # :1170
self._updated_at = _now_iso()                                # :1171
try:
    await workflow.execute_activity(persist_deployment_side_effects,
        PersistDeploymentSideEffectsInput(target_app_id, manifest, decommission, license, cost,
            deployment_current_status="failed"),
        start_to_close_timeout=60s, retry_policy=transient)  # :1173-1189
except Exception: pass                                       # :1190-1191
await self._update_app_status(app_id, "deployment_in_progress", reason_step, "Deployment")  # :1192-1194
return "failed"                                              # :1195
```
**GOTCHA (`:1192`):** `_update_app_status` here is NOT best-effort-wrapped — a failure would propagate out of `_fail`. Lifecycle marker stays `deployment_in_progress` (NOT advanced to `sustainment_active`) on max-rework failure; only Governance retriage can advance it (`:1159-1167`).

### `_build_gdp1_pr_body(app_id) -> str` (`:1201-1236`) / `_build_gdp2_pr_body(app_id) -> str` (`:1238-1275`)
- `rework_iter = self._rework_count("G-DP-1")` / `("G-DP-2")`.
- If `self._risk_tier == 1`, prepend a Tier-1 triple-signal checklist block (`tier_note`) listing the required `stakeholder_approved` scopes (G-DP-1: g-dp1-ops, g-dp1-safety; G-DP-2: g-dp2-ops, g-dp2-cert).
- If `rework_iter > 0`, append `\n**Rework iteration:** {rework_iter}\n`.
- Bodies are deterministic markdown with app_id interpolation (exact text at `:1213-1233` / `:1250-1272`).

### Module function `_parallel_run_days(input_tier, resolved_tier=None) -> int` (`:1278-1304`)
```
candidates = [resolved_tier, input_tier]                     # :1295  (resolved preferred)
for candidate in candidates:
    if candidate is None: continue                           # :1297-1298
    try: tier = int(candidate)                               # :1300
    except (TypeError, ValueError): continue                 # :1301-1302
    return PARALLEL_RUN_DAYS.get(tier, DEFAULT_PARALLEL_RUN_DAYS)   # :1303
return DEFAULT_PARALLEL_RUN_DAYS                             # :1304  (both missing/invalid → 30)
```
**GOTCHA:** `resolved_tier` (workflow's `_risk_tier`) is tried FIRST, then `input.risk_tier`. Unknown int tier → 30 (default).

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS

No child workflows. All calls are `workflow.execute_activity`, sequential (never `asyncio.gather`). Order over a full modernization run:

Per PRIMARY agent step (via base `_dispatch_agent`, `base.py:403-502`) — for each of orchestration, traffic-shifting, parallel-run, adoption-verification, legacy-decommission, cost-certification:
1. (patch-gated `context-priors-v1`) `load_context_priors` — `start_to_close_timeout=10s`, retry `transient`, best-effort (`base.py:453-469`).
2. `dispatch_agent_task` — `start_to_close_timeout=AGENT_START_TO_CLOSE (3 hours)`, retry `agent_failure` (max 3, exp 5-60s), `activity_id=f"agent-{step}"` (`base.py:486-492`).

Per step commit (via base `_commit_step_artifacts`, `base.py:752-891`):
3. `write_artifacts_batch` — `start_to_close_timeout=120s`, retry `transient`, `activity_id=f"commit-{step}"` (`base.py:822-836`).
4. (patch-gated `patch-output-artifact-ref-v1`) `update_agent_task_output_ref` — `start_to_close_timeout=30s`, retry `transient`, best-effort (`base.py:877-891`).

Parallel-run only (`_run_deploy_and_shift`):
5. `resolve_parallel_run_seconds(duration_days)` — positional arg, `start_to_close_timeout=30s`, retry `transient` (`deployment.py:664-669`). Then `workflow.sleep(soak_seconds)` (durable timer, not an activity).

Each gate (via `_run_gate` → base helpers), G-DP-1 then G-DP-2:
6. `create_pr` (base `_create_gate_pr`) — `CreatePRInput(repo, source_branch=branch, target_branch="main", title, body, labels=["gate-review","deployment",gate_type], execution_context)`, `start_to_close_timeout=60s`, retry `transient` (`base.py:915-920`).
7. `create_gate_record` — `CreateGateRecordInput(gate_type=gate_type.value, app_id, portfolio_id=input.portfolio_id, workflow_id, evidence_package_url=pr_result.pr_url)`, `start_to_close_timeout=30s`, retry `transient` (`deployment.py:1041-1052`).
8. `check_gate_criteria` (base `_submit_gate_evidence`) — `start_to_close_timeout=60s`, retry `transient` (`base.py:1001-1006`).
9. `submit_gate_evidence` — `start_to_close_timeout=60s`, retry `transient` (`base.py:1016-1021`).
10. `dispatch_agent_task` for skill `gate-pre-review` (base `_run_gate_pre_review`) — `start_to_close_timeout=AGENT_START_TO_CLOSE (3h)`, `heartbeat_timeout=AGENT_DISPATCH_HEARTBEAT_TIMEOUT (2 min)`, retry `transient`, best-effort (`base.py:1049-1071`).
11. `store_gate_pre_review` — `start_to_close_timeout=30s`, retry `transient`, only if pre-review produced output (`base.py:1079-1087`).
12. (patch-gated `mark-gate-ready-for-review-v1`, in `finally`) `mark_gate_ready_for_review(gate_id)` — `start_to_close_timeout=30s`, retry `transient` (`base.py:1095-1101`).
    - **then the gate wait** (§5), and on approval:
13. `reconcile_and_merge_pr` (base `_reconcile_and_merge_with_retry_loop`) — `MergePRInput(repo, pr_number, merge_method="merge", execution_context)`, `start_to_close_timeout=60s`, retry `git_merge` (max 3, exp 5-30s, `non_retryable_error_types=[MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected]`) (`base.py:1208-1218`).
14. (on structured merge error) `set_gate_merge_blocked(gate_id, detail)` — args list, `start_to_close_timeout=30s`, retry `transient` (`base.py:1263-1268`), then await `merge_retry` signal and loop.

Terminal (Step 17/18):
15. `persist_deployment_side_effects` — `PersistDeploymentSideEffectsInput(target_app_id, deployment_manifest_json, decommission_certificate_json, license_reclamation_json, cost_savings_certification_json, deployment_current_status="completed")`, `start_to_close_timeout=60s`, retry `transient`, best-effort (`deployment.py:855-871`).
16. (Refactor/Rearchitect only) `emit_disposition_output_bundle` — `EmitDispositionOutputBundleInput(repo, branch, portfolio_id, app_id, bundle)`, `start_to_close_timeout=60s`, retry `transient` (`deployment.py:974-985`).

`update_application_status` (base `_update_app_status`, `base.py:391-401`) — `start_to_close_timeout=30s`, retry `transient` — fires on EVERY `_set_step` (via `_update_app_status`, `base.py:372-378`), at completion (`sustainment_active/registered/Sustainment`), and on failure paths.

**Retire path** skips activities 1-5, 6-14 for G-DP-1 (steps 2-10). It runs legacy-decommission + cost-certification dispatch/commit, then the G-DP-2 gate chain, then persist (16 not run — Retire is not Refactor/Rearchitect).

### Retry policies (exact, from `retry_policies.py`)
- `transient` = `HTTP_RETRY_POLICY`: initial 1s, max 15s, max_attempts 3, backoff 2.0 (`temporal_base/retry_policies.py:35-40`).
- `agent_failure`: initial 5s, max 60s, max_attempts 3, backoff 2.0 (`retry_policies.py:40-45`).
- `git_merge`: initial 5s, max 30s, max_attempts 3, backoff 2.0, `non_retryable_error_types=[MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected]` (`retry_policies.py:95-108`).

---

## 5. GATE HANDLING — `_run_gate` (`:1008-1102`)

```
_run_gate(input, repo, branch, app_id, gate_type, gate_step, evidence_steps, title, body_builder):
    evidence_paths = []                                      # :1027
    for step_name in evidence_steps:
        evidence_paths.extend(self._step_committed_paths.get(step_name, []))   # :1028-1031
    evidence_paths = dedup_paths(evidence_paths)             # :1032
    pr_result = await self._create_gate_pr(repo, branch, app_id, gate_type=gate_type.value,
                    title=title, body=body_builder(app_id))  # :1034-1039
    gate_record = await execute_activity(create_gate_record, CreateGateRecordInput(...pr_result.pr_url))  # :1041-1052
    await self._submit_gate_evidence(gate_id=gate_record.gate_id, gate_type, app_id,
        artifact_paths=evidence_paths, pr_url=pr_result.pr_url, assembly_line="Deployment", step=gate_step)  # :1054-1062
    await self._run_gate_pre_review(gate_record.gate_id, gate_type.value, evidence_paths,
        artifact_repo=repo, artifact_ref=branch)             # :1064-1070
    gate_progress = self._progress_for_gate(gate_step)       # :1072
    await self._set_step(gate_step, gate_progress)           # :1073
    decision = await self._wait_for_gate_decision_with_tier_1(gate_type)   # :1075
    if decision == "cancelled": return "cancelled"           # :1076-1077
    if decision == "approved":                               # :1079
        await self._reconcile_and_merge_with_retry_loop(repo=repo, pr_number=pr_result.pr_number,
            gate_id=gate_record.gate_id, merge_method="merge")   # :1082-1087
        approver = self._gate_decisions[-1][1] if self._gate_decisions else "unknown"   # :1088-1092
        self._bundle_approvals.append({gate: gate_type.value, approved_at:_now_iso(),
            approved_by: approver, record_ref: f"gates/{gate_record.gate_id}/decision.json"})   # :1093-1100
        return "approved"                                    # :1101
    return "rejected"                                        # :1102
```

**Evidence assembly:** G-DP-1 evidence = orchestration+traffic-shifting+parallel-run+adoption-verification committed paths; G-DP-2 = all 6 PRIMARY steps' paths. Deduped.

**Approve/reject/cancel routing:**
- `cancelled` → returns `"cancelled"` up through `_run_gdp*_with_rework` → `run` returns `"cancelled"`.
- `approved` → merge loop (with merge_blocked retry sub-loop), record approval, return `"approved"`.
- `rejected` → return `"rejected"` → caller bumps rework counter, loops (rerun scope per gate), or returns `"failed"` after >3 rejections.

**merge-blocked routing (base `_reconcile_and_merge_with_retry_loop`, `base.py:1159-1279`):** on `MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected` (surfaced via `ApplicationError.type`, unwrapping `__cause__`), fires `set_gate_merge_blocked`, resets `_merge_retry_signalled=False` BEFORE the block-write (avoids racing a stale signal), waits on `_merge_retry_signalled or self.cancelled`, then re-attempts. Non-merge errors re-raise. Cancel during wait returns (merge abandoned).

**Rework loop counters:** `_rework_iterations["G-DP-1"]` / `["G-DP-2"]` via `_bump_rework`/`_rework_count`. Fail when `> MAX_REWORK_ITERATIONS (3)` — the 4th rejection fails. G-DP-1 rework reruns adoption-verification only; G-DP-2 rework reruns legacy-decommission + cost-certification.

**Approver capture (`:1088-1092`):** `approver = self._gate_decisions[-1][1]` — the LAST decision's actor field. **GOTCHA:** reads the tail of the whole decision queue, not the specific consumed entry; if a later decision landed it would attribute the wrong actor. Falls back to `"unknown"` if queue empty.

**Tier-1 gate (`_wait_for_gate_decision_with_tier_1`):** PM `gate_approved` first (base wait pops from FIFO + records rework), then blocks on the required stakeholder flags. Rejection short-circuits before stakeholder wait.

---

## 6. RESILIENCE

- **Entry-signal timeout:** 30-min `wait_condition` timeout → defaults to `Refactor` rather than hanging (`:548-561`).
- **Parallel-run durable timer:** `workflow.sleep` of 14/30/90 days (tier), overridable to seconds via activity-read env for dev/test (`:664-670`); collapses under time-skipping.
- **Agent timeouts:** `AGENT_START_TO_CLOSE = 3 hours` (`agent_timeouts.py:67`); pre-review adds `heartbeat_timeout = 2 minutes` (`agent_timeouts.py:72`).
- **Heartbeats:** only the `gate-pre-review` dispatch sets `heartbeat_timeout`; primary `dispatch_agent_task` sets none.
- **Continue-as-new:** NONE. Deployment never calls `workflow.continue_as_new`. History grows unbounded across long parallel-run sleeps + rework loops (bounded by MAX_REWORK_ITERATIONS=3 per gate).
- **Idempotency:** branch/workspace derived deterministically from `workflow_id` suffix (`:409-411`). `merge_retry` handler idempotent. Gate-decision consumption uses a monotonically-incrementing `_gate_decisions_consumed` cursor so buffered signals are consumed in order exactly once (base).
- **Compensation / rollback:** none in-workflow. On top-level exception (`run` except) and on max-rework (`_fail`), the DB projection writes `deployment_current_status="failed"` best-effort; the app lifecycle marker stays `deployment_in_progress`. `_persist_side_effects` and `emit_disposition_output_bundle` failures during the happy path: persist is best-effort (swallowed); the bundle emit is NOT swallowed (would propagate → run except → FAILED + re-raise).
- **Determinism guards:** env reads pushed into activities (`resolve_parallel_run_seconds`); patch guards on `context-priors-v1`, `patch-output-artifact-ref-v1`, `mark-gate-ready-for-review-v1` preserve replay determinism for in-flight runs.

---

## 7. Behavioral parity checklist

A rebuild MUST satisfy all of:

1. **Path table exact.** `Retire` runs steps {1, 11-18} and skips 2-10; `Refactor/Rearchitect/Replace/Replatform/Consolidate` run all 18; `Retain`/unknown falls through to the full canonical order via `.get` default. Branch gate is `"orchestration" in active_steps` (`:456`).
2. **Entry resolution precedence:** `input.disposition` → its `.value` (no wait); else wait ≤ 1800s; disposition-signal wins over validation-signal; timeout/cancel → `"Refactor"`; disposition-signal with no tier → Tier-2; validation-signal → `"Refactor"` and parse `risk_tier` string (bad → Tier-2).
3. **Branch/workspace:** `olympus/deployment/{app_id}/{run_suffix}` and `deployment-{app_id}-{run_suffix}`, `run_suffix = wf_id after last '-' (or first 8 chars if no '-')`.
4. **Parallel-run soak** = `_parallel_run_days(input.risk_tier, self._risk_tier)` days → `resolve_parallel_run_seconds` (env override `OLYMPUS_PARALLEL_RUN_OVERRIDE_SECONDS` honored in-activity only) → durable `workflow.sleep`. Days map {1:90,2:30,3:14}, default 30; resolved_tier preferred over input_tier.
5. **G-DP-1 rework** reruns adoption-verification ONLY; **G-DP-2 rework** reruns legacy-decommission + cost-certification. Both fail when `_rework_count(gate) > 3`. `_fail` returns `"failed"` with reason `max-rework-exceeded-gdp1`/`-gdp2`.
6. **Tier-1 triple-signal:** only when `_risk_tier == 1`. G-DP-1 needs PM `gate_approved` + ops + safety; G-DP-2 needs PM + ops + cert. Ops flag is SHARED across both gates and never reset. Tier-2/3 approve on PM signal alone.
7. **Evidence sets:** G-DP-1 = [orchestration, traffic-shifting, parallel-run, adoption-verification]; G-DP-2 = PRIMARY_STEP_ORDER (all 6). Deduped via `dedup_paths`.
8. **Progress:** `gate-review-dp1` → 60.0, `gate-review-dp2` → 96.0; persist step set at 96.0, merge-final at 98.0, completion 100.0. `STEP_WEIGHTS` values exact.
9. **Manifest injection:** into `parallel_run.observed_duration_days` only when duration observed, manifest non-empty, `"parallel_run"` substring absent, and manifest parses as a dict; else skipped silently.
10. **Terminal:** `persist_deployment_side_effects(...,"completed")` best-effort; Refactor/Rearchitect emit disposition-output bundle (Rearchitect adds `bounded_context_map_ref`); `_update_app_status(app_id,"sustainment_active","registered","Sustainment")`; status COMPLETED, progress 100, step "completed"; return `"completed"`.
11. **Failure paths:** top-level exception → FAILED, step "failed", best-effort status projection, re-raise (does not return). `_fail` → FAILED, projection `deployment_current_status="failed"` best-effort, `_update_app_status(...,"deployment_in_progress",reason_step,...)` NOT wrapped, return `"failed"`. Lifecycle marker never advanced to `sustainment_active` on failure.
12. **Merge:** approved gate → `reconcile_and_merge_pr` under `git_merge` policy; structured merge errors → `set_gate_merge_blocked` + await `merge_retry` + retry; reset `_merge_retry_signalled=False` before block-write; cancel exits loop; non-merge errors propagate.
13. **Approval record:** appended to `_bundle_approvals` with `{gate, approved_at, approved_by=last-decision-actor-or-"unknown", record_ref="gates/{gate_id}/decision.json"}`.
14. **Signal handlers:** three Deployment signals (`validation_approved`, `disposition_executed`, `stakeholder_approved`) plus all inherited base/HIL signals; base `gate_approved`/`gate_rejected`/`merge_retry` MUST NOT be overridden (5-tuple envelope contract). `stakeholder_approved` scope→flag mapping exact.
15. **No child workflows; no continue-as-new; all activities sequential.** Retry policies and timeouts per §4 exactly.
16. **`_rework_gate_key_for_step`** maps legacy-decommission/cost-certification → "G-DP-2", everything else → "G-DP-1".
