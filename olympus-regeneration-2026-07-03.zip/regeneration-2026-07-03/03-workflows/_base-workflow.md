# `LineWorkflowBase` — shared assembly-line workflow machinery

**Source:** `temporal/olympus_workflows/workflows/base.py` (1–1381)
**Class:** `class LineWorkflowBase(HILSignalsMixin)` — `base.py:111`
**Mixin base:** `HILSignalsMixin` — `temporal/olympus_workflows/temporal_base/signals.py:19`

This is the base every per-application / per-portfolio assembly-line workflow subclasses
(Data, Deployment, Disposition, Architecture, Rationalization, Validation, Modernization,
etc.). It provides shared state, signal handlers, activity helpers, the gate-decision
wait, the rework-feedback loop, the merge-blocked retry loop, evidence assembly, and the
`get_status` query. Per-workflow docs reference THIS file for all inherited behavior.

> **CRITICAL STRUCTURAL NOTE:** `LineWorkflowBase` has **NO `run()` method and NO
> `@workflow.defn` decorator** (verified: `grep -n "def run|@workflow.run|@workflow.defn"
> base.py` returns nothing). It is an un-decorated mixin/ABC-style base. Each concrete
> subclass supplies its own `@workflow.defn` class decorator and its own `@workflow.run`
> `async def run(...)`. Therefore this doc has no `run()` control-flow section of its own —
> it documents the shared helpers that subclass `run()` bodies call. `HILSignalsMixin` is
> also un-decorated; its signals become live only when a decorated subclass inherits it.

---

## 0. Imports & determinism boundary

- `base.py:46` — the entire block of `temporalio.exceptions` + Olympus activity/type
  imports is inside `with workflow.unsafe.imports_passed_through():` so those modules load
  natively (not sandbox-reimported) during workflow replay. **GOTCHA:** anything imported
  outside that block (`json`, `timedelta`, `HILSignalsMixin`, `workflow`) is
  sandbox-imported; keep new heavy imports inside the `imports_passed_through` block or
  Temporal's determinism sandbox will re-import them each replay.
- `base.py:106` — `_now_iso()` returns `workflow.now().isoformat()`. This is the ONLY time
  source used anywhere in this class; **never** `datetime.now()`/`time.time()`. Module
  docstring invariant `base.py:29-32`: no wall-clock, random, or external I/O in workflow
  code; all state is attribute-based; `workflow.patched(...)` IDs pass through verbatim.

---

## 1. STATE — every instance variable

State is split across two `__init__`s. `LineWorkflowBase.__init__` (`base.py:136`) calls
`super().__init__()` first (→ `HILSignalsMixin.__init__`), then sets its own attributes.

### 1a. Inherited from `HILSignalsMixin.__init__` (`signals.py:29`)

| Attr | Type | Initial | Mutated by |
|---|---|---|---|
| `approved` | `bool` | `False` | `approve()` signal → `True` (`signals.py:79`) |
| `plan_approved` | `bool` | `False` | `approve_plan()`→True (`signals.py:49`); `provide_plan_feedback()`→False (`signals.py:60`) |
| `plan_feedback_received` | `bool` | `False` | `provide_plan_feedback()`→True; `approve_plan()`/`reset_plan_feedback()`→False |
| `plan_feedback_comments` | `str` | `""` | `provide_plan_feedback(comments)` sets; `approve_plan()`/reset clears |
| `document_approved` | `bool` | `False` | `approve_research()`→True; `provide_feedback()`→False |
| `document_feedback_received` | `bool` | `False` | `provide_feedback()`→True; `approve_research()`/reset→False |
| `document_feedback_comments` | `str` | `""` | `provide_feedback(comments)`; cleared on approve/reset |
| `cancelled` | `bool` | `False` | `cancel_workflow()`→`True` (`signals.py:85`). **Consumed by every `wait_condition` in this class.** |

### 1b. Defined by `LineWorkflowBase.__init__` (`base.py:136–191`)

| Attr | Type | Initial | Mutated by / when |
|---|---|---|---|
| `_app_id` | `str` | `""` | subclass `run()` sets from input; read by `_set_step`, `_execution_ctx`, `_run_gate_pre_review` |
| `_portfolio_id` | `str` | `""` | subclass sets at run start; gates `_execution_ctx` (returns `None` if empty) — `base.py:345` |
| `_wave_id` | `str` | `""` | subclass sets; default `wave_id` for `_execution_ctx` — `base.py:358` |
| `_status` | `WorkflowStatus` | `WorkflowStatus.PENDING` | `_wait_for_gate_decision` → `WAITING_FOR_SIGNAL`/`RUNNING`/`CANCELLED`; subclasses set RUNNING/COMPLETED/FAILED. Read by `get_status` query |
| `_current_step` | `str` | `""` | `_set_step(step, …)` — `base.py:368`. Read by `get_status` |
| `_progress_pct` | `float` | `0.0` | `_set_step(_, progress)` — `base.py:369`. Read by `get_status` |
| `_pending_gate` | `GateType \| None` | `None` | set in `_wait_for_gate_decision` (→gate_type, then `None`) — `base.py:1114,1140`. Read by `get_status` |
| `_started_at` | `str` | `""` | subclass sets at run start. Read by `get_status` |
| `_updated_at` | `str` | `""` | refreshed via `_now_iso()` by EVERY signal handler + `_set_step` + gate wait. Read by `get_status` |
| `_gate_decisions` | `list[tuple[GateStatus,str,str]]` (declared) | `[]` | **appended as 5-TUPLES** by `gate_approved`/`gate_rejected` (see GOTCHA-1). Drained by `_wait_for_gate_decision` |
| `_gate_decisions_consumed` | `int` | `0` | incremented by `_wait_for_gate_decision` after draining one entry — `base.py:1138` |
| `_rework_feedback` | `dict[str,dict]` | `{}` | key=gate_key: set on rejection (`base.py:1149`), popped on approval (`base.py:1146`); read by `_dispatch_agent` (`base.py:443`) |
| `_rework_iterations` | `dict[str,int]` | `{}` | `_bump_rework(key)` increments (`base.py:1378`); `_rework_count(key)` reads. **Not touched by `_wait_for_gate_decision` — subclasses must call `_bump_rework` themselves** (see GOTCHA-2) |
| `_step_results` | `dict[str,list[str]]` | `{}` | subclasses populate with `result.output_artifacts`; read by `_build_evidence_data` (`base.py:1310`) |
| `_step_committed_paths` | `dict[str,list[str]]` | `{}` | `_commit_step_artifacts` sets `[step_name]` to committed paths (`base.py:872`) |
| `_agent_metadata` | `dict[str,dict]` | `{}` | `_dispatch_agent` writes per-step metadata dict (`base.py:494`); read by `_commit_step_artifacts` + `_build_evidence_data` |
| `_risk_tier` | `int \| None` | `None` | subclass `__init__` sets from input; forwarded by `_submit_gate_evidence` (`base.py:992`) |
| `_merge_retry_signalled` | `bool` | `False` | `merge_retry()` signal→True (`base.py:256`); reset to False in merge loop (`base.py:1261`); consumed by merge-retry `wait_condition` (`base.py:1272`) |
| `_profile_id` | `str` | `""` | `_load_delegation_config` sets (`base.py:525`); read by dispatch-mode resolution + bundle dispatch |
| `_portfolio_fallback_policy` | `str` | `"internal_fallback"` | `_load_delegation_config` may overwrite (`base.py:545`); read by `_apply_bundle_fallback` |
| `_redispatch_guard` | `set[str]` | `set()` | `_apply_bundle_fallback` adds `step_or_gate_id` before a `redispatch` retry (`base.py:710`) — bounds redispatch to one extra cycle per scope |

**Referenced-but-not-declared-here attributes (subclass or sibling-mixin owned):**
- `self._input` — accessed defensively via `getattr(self, "_input", None)` in
  `_dispatch_agent` (`base.py:435`) and `_workflow_created_by` (`base.py:745`). Subclass
  stores the `LineWorkflowInput`. Never assume it exists.
- `self.await_bundle_completion` / `self._bundle_outputs` — provided by `BundleAwareMixin`
  (`workflows/bundle_helpers.py:68`). `_maybe_dispatch_bundle` gates on
  `hasattr(self, "await_bundle_completion")` (`base.py:591`); lines that don't inherit the
  mixin never delegate.

> **GOTCHA-1 (type/shape mismatch):** `_gate_decisions` is *declared* `list[tuple[GateStatus,
> str, str]]` (`base.py:154`) but BOTH signal handlers append **5-tuples** `(status, actor,
> reason, reason_category, card_decisions)` (`base.py:200-208`, `223-231`). `_wait_for_gate_decision`
> defends against both arities (`base.py:1132`: `if len(entry) == 5: … else: 3-tuple`), so a
> rebuild MUST tolerate reading either a 3-tuple (legacy senders) or 5-tuple. The 3-tuple path
> sets `reason_category=None`, `card_decisions=[]`.
> **GOTCHA-2:** `_wait_for_gate_decision` does NOT increment `_rework_iterations`. The rework
> COUNTER (`_bump_rework`) and its bound are the subclass's responsibility. The base only
> records feedback text.

---

## 2. SIGNALS & QUERIES

### 2a. Signals decorated ON THIS CLASS — subclasses MUST NOT redefine

Module docstring (`base.py:10-13`) + class docstring (`base.py:117-119`): re-decorating
these in a subclass duplicate-registers with Temporal (error). All four use `@workflow.signal`.

| Signal | Line | Payload | Effect |
|---|---|---|---|
| `gate_approved` | `base.py:197` | `GateApprovedSignal` | Appends 5-tuple `(GateStatus.APPROVED, signal.approved_by, signal.justification, None, [])` to `_gate_decisions`; sets `_updated_at=_now_iso()`. `async`. |
| `gate_rejected` | `base.py:211` | `GateRejectedSignal` | `card_decisions = list(getattr(signal,"card_decisions",[]) or [])`; `reason_category = getattr(signal,"reason_category",None)`; appends `(GateStatus.REJECTED, signal.rejected_by, signal.reason, reason_category, card_decisions)`; `_updated_at=_now_iso()`. `async`. **GOTCHA:** uses `getattr` defaults so older signal senders lacking `card_decisions`/`reason_category` don't crash. |
| `escalation_resolved` | `base.py:234` | `EscalationResolvedSignal` | Body is ONLY `self._updated_at = _now_iso()` — no other state mutation. It's a liveness ping. `async`. |
| `merge_retry` | `base.py:241` | `GateMergeRetrySignal` | Sets `_merge_retry_signalled=True`; `_updated_at=_now_iso()`. Idempotent — re-firing when already True is a no-op except refreshing `_updated_at` (`base.py:256`). `async`. |

**The exact `wait_condition` predicates that consume each signal:**
- `gate_approved`/`gate_rejected` → consumed by `_wait_for_gate_decision`:
  `lambda: len(self._gate_decisions) > consumed or self.cancelled` (`base.py:1118-1120`)
  where `consumed = self._gate_decisions_consumed` captured *before* the wait.
- `merge_retry` → consumed by `_reconcile_and_merge_with_retry_loop`:
  `lambda: self._merge_retry_signalled or self.cancelled` (`base.py:1271-1273`).
- `cancel_workflow` (from mixin) → `self.cancelled` appears in BOTH predicates above and
  short-circuits either wait.

### 2b. Signals inherited from `HILSignalsMixin` (live on decorated subclasses)

All `@workflow.signal`, synchronous. `base.py`'s own gate loop does NOT read these — they
support plan/document-review patterns used by other (non-line) workflows, but a
line-workflow subclass inheriting `LineWorkflowBase` inherits them too:
`approve_plan`, `provide_plan_feedback` (`signals.py:48,56`), `approve_research`,
`provide_feedback` (`signals.py:64,70`), `approve` (`signals.py:79`), `cancel_workflow`
(`signals.py:84`). Plus non-signal helpers `reset_plan_feedback`, `reset_document_feedback`,
`is_plan_decision_received`, `is_document_decision_received` (`signals.py:89-105`).

### 2c. Query

| Query | Line | Returns |
|---|---|---|
| `get_status` | `base.py:1353` (`@workflow.query`, sync) | `WorkflowStatusResponse(workflow_id=workflow.info().workflow_id, status=self._status, current_line=self.ASSEMBLY_LINE, current_step=self._current_step, progress_pct=self._progress_pct, pending_gate=self._pending_gate, started_at=self._started_at, updated_at=self._updated_at)` |

**GOTCHA:** `get_status` reads `self.ASSEMBLY_LINE` — a ClassVar with **no default**
(`base.py:126`). A subclass that never sets `ASSEMBLY_LINE` raises `AttributeError` when
queried. Query handlers must be pure/deterministic (no activity calls) — this one is.

---

## 3. CLASSVARS (subclass configuration surface) — `base.py:125-134`

| ClassVar | Type | Default | Purpose |
|---|---|---|---|
| `ASSEMBLY_LINE` | `AssemblyLine` | *(none)* | returned by `get_status` |
| `ARTIFACT_ROOT` | `str` | `""` | path prefix for commits + default task-type prefix + PR label |
| `LINE_LABEL` | `str` | `""` | human line name; `_execution_ctx` derives `line_id = LINE_LABEL.lower().replace(" ","-")` (`base.py:351`) |
| `STATUS_PREFIX` | `str` | `""` | `_set_step` pushes `f"{STATUS_PREFIX}_in_progress"` (`base.py:374`) |
| `STEPS` | `dict[str,dict]` | `{}` | per-step `skill_id`/`skills` + `artifact` + optional `title` |
| `STEP_WEIGHTS` | `dict[str,float]` | `{}` | progress weights (sum 100); used by subclass `run()` |
| `SINGLE_GATE_KEY` | `str \| None` | `None` | default `_rework_gate_key_for_step` returns this |

---

## 4. HOOK METHODS (subclasses override) — `base.py:263-318`

Non-async, pure helpers:
- `_task_type_prefix()` → returns `self.ARTIFACT_ROOT` (`base.py:269`). Override when
  task_type stub differs from artifact root.
- `_rework_gate_key_for_step(step_name)` → returns `self.SINGLE_GATE_KEY` (`base.py:279`).
  Multi-gate lines override with a step→gate map.
- `_primary_skill_for_step(step_name)` → `self.STEPS[step_name]["skill_id"]` (`base.py:287`).
  **GOTCHA:** KeyErrors if the step def uses a `skills` list instead of `skill_id`
  (Validation) — Validation MUST override this.
- `_evidence_step_metadata(step_name, step_def)` → dict
  `{"title": step_def.get("title", step_name), "skill_id": step_def.get("skill_id",""),
  "artifact": step_def.get("artifact","")}` (`base.py:305`). Validation overrides for its
  `skills` list. `title` wins over step-id for reviewer card labels.
- `_evidence_steps_iter()` → `self.STEPS.items()` (`base.py:318`). Rationalization/Modernization
  override to filter/extend.

---

## 5. CORE ACTIVITY HELPERS — control flow, args, retry, timeout

All activity calls are SEQUENTIAL (`await workflow.execute_activity(...)`); there is NO
`asyncio.gather` and NO child-workflow start anywhere in `base.py`. Parallelism/fan-out is
entirely a subclass concern.

### 5.1 `_set_step(step, progress)` — `base.py:367`
```
_current_step = step
_progress_pct = progress
_updated_at = _now_iso()
if _app_id:                       # skip the DB push when app scope unknown
    await _update_app_status(_app_id, f"{STATUS_PREFIX}_in_progress", step, LINE_LABEL)
```

### 5.2 `_update_app_status(app_id, status, step, line)` — `base.py:380`
- Activity: `update_application_status`
- Arg: `UpdateAppStatusInput(app_id, status, current_step=step, current_line=line)`
- `start_to_close_timeout=30s`; `retry_policy=RETRY_POLICIES["transient"]` (HTTP policy:
  1s init, 15s max, 3 attempts, backoff 2.0 — `temporal_base/retry_policies.py:35`).
- **GOTCHA (`base.py:384-390`):** deliberately uses `transient` (3 retries) NOT
  `validation_failure` (max_attempts=1). A prior version used `validation_failure`; a single
  CPDSS status-update 30s timeout then failed the whole workflow. Do not revert.

### 5.3 `_dispatch_agent(...)` — `base.py:403`
Signature: `(app_id, step_name, input_artifacts, workspace_key="", artifact_repo="",
artifact_ref="", optional_input_artifacts=None) -> AgentTaskResult`.

Control flow:
```
skill_id = _primary_skill_for_step(step_name)
context = {}
# --- fixture-scenario hook (DECISION-018, test-only) ---
fixture_scenarios = getattr(getattr(self,"_input",None), "fixture_scenarios", None)
if fixture_scenarios:
    scenario = fixture_scenarios.get(skill_id)
    if scenario:
        context["fixture_scenario"] = scenario
# --- rework feedback forwarding ---
gate_for_step = _rework_gate_key_for_step(step_name)
if gate_for_step is not None:
    fb = _rework_feedback.get(gate_for_step)
    if fb is not None:
        context["rework_feedback"] = fb
# --- context priors (PATCH-GATED) ---
if workflow.patched("context-priors-v1"):
    try:
        priors_result = await execute_activity(
            load_context_priors, LoadContextPriorsInput(skill_id=skill_id),
            start_to_close_timeout=10s, retry_policy=transient)
        priors = getattr(priors_result,"priors",None) or []
        if priors:
            context["context_priors"] = priors
    except Exception as exc:            # best-effort; log + continue
        workflow.logger.warning("context_priors load failed (continuing): %s", exc, ...)
# --- build input + dispatch ---
task_input = AgentTaskInput(
    task_type=f"{_task_type_prefix()}-{step_name}", app_id, skill_id,
    input_artifacts, optional_input_artifacts=list(optional_input_artifacts or []),
    artifact_repo, artifact_ref, workspace_key, context,
    execution_context=_execution_ctx(step_name, app_id=app_id,
                                     input_artifact_paths=input_artifacts))
result = await execute_activity(
    dispatch_agent_task, task_input,
    start_to_close_timeout=AGENT_START_TO_CLOSE (3h),
    retry_policy=RETRY_POLICIES["agent_failure"] (5s init, 60s max, 3 attempts, backoff 2.0),
    activity_id=f"agent-{step_name}")
_agent_metadata[step_name] = {model_used, duration_ms, token_usage_input,
                              token_usage_output, cost_estimate_usd, output_files}
return result
```
- **GOTCHA:** `dispatch_agent_task` here uses `start_to_close=3h` and NO explicit
  `heartbeat_timeout` (unlike `_run_gate_pre_review`, which passes
  `AGENT_DISPATCH_HEARTBEAT_TIMEOUT=2min`). `activity_id=f"agent-{step_name}"` makes the
  activity deterministically addressable/idempotent per step in event history.
- **GOTCHA (patch):** `context-priors-v1` patch (`base.py:453`) — pre-patch in-flight runs
  replay WITHOUT the `load_context_priors` activity. Keep this patch ID byte-for-byte.

### 5.4 `_commit_step_artifacts(...)` — `base.py:752`
Signature: `(repo, branch, app_id, step_name, result, artifact_path, mirror_repo="",
mirror_path_prefix="") -> None`.
```
metadata = _agent_metadata.get(step_name, {})
output_files = metadata.get("output_files", [])            # list[OutputFile]
file_paths = [f.path for f in output_files] if output_files else []
step_def = STEPS[step_name]
summary = {step, artifacts=result.output_artifacts, file_artifacts=file_paths,
           model_used, duration_ms, token_usage:{input,output}, cost_estimate_usd,
           timestamp=workflow.now().isoformat()}
if "skill_id" in step_def: summary["skill_id"] = step_def["skill_id"]
if "skills"   in step_def: summary["skills"]   = step_def["skills"]
summary_content = json.dumps(summary, indent=2)

# ONE batch: summary JSON first, then each output file.
primary_batch = [(artifact_path, summary_content)]
committed = [artifact_path]
for file_artifact in output_files:
    file_path = f"{ARTIFACT_ROOT}/{app_id}/files/{step_name}/{file_artifact.path}"
    primary_batch.append((file_path, file_artifact.content)); committed.append(file_path)

commit_ctx = _execution_ctx(f"commit-{step_name}", app_id=app_id)
await execute_activity(write_artifacts_batch,
    WriteArtifactsBatchInput(repo, branch, files=primary_batch,
        commit_message=f"{ARTIFACT_ROOT}({app_id}): {step_name} artifacts",
        execution_context=commit_ctx),
    start_to_close_timeout=120s, retry_policy=transient, activity_id=f"commit-{step_name}")

# MIRROR write (best-effort) — only if mirror_repo set AND output_files nonempty
if mirror_repo and output_files:
    prefix = mirror_path_prefix.rstrip("/") or f"docs/{ARTIFACT_ROOT}/{step_name}"
    mirror_files = [(f"{prefix}/{f.path}", f.content) for f in output_files]
    try:
        await execute_activity(write_artifacts_batch,
            WriteArtifactsBatchInput(repo=mirror_repo, branch="main", files=mirror_files,
                commit_message=f"{ARTIFACT_ROOT}({app_id}): {step_name} design artifacts",
                execution_context=commit_ctx),
            start_to_close_timeout=120s, retry_policy=transient)
    except Exception as exc:            # mirror failure NON-FATAL
        workflow.logger.warning("mirror batch write to target repo failed (non-fatal): %s", exc)

_step_committed_paths[step_name] = committed

# output_ref correction (PATCH-GATED)
if workflow.patched("patch-output-artifact-ref-v1"):
    try:
        await execute_activity(update_agent_task_output_ref,
            args=[app_id, f"{_task_type_prefix()}-{step_name}", artifact_path],
            start_to_close_timeout=30s, retry_policy=transient,
            activity_id=f"patch-output-ref-{step_name}")
    except Exception:                   # observability only; swallow
        pass
```
- **GOTCHAs:** (1) Summary JSON + all files go in ONE `write_artifacts_batch` commit —
  one commit/step, not per-file. (2) Mirror path default only used when `mirror_path_prefix`
  is empty after `.rstrip("/")`. (3) Both the mirror write and the `update_agent_task_output_ref`
  are best-effort (`except` swallows). (4) Patch ID `patch-output-artifact-ref-v1` MUST be
  verbatim — in-flight pre-patch runs must not emit the extra activity on replay.

### 5.5 `_create_gate_pr(...)` — `base.py:893`
`(repo, branch, app_id, gate_type, title, body)`:
- Activity `create_pr` with `CreatePRInput(repo, source_branch=branch, target_branch="main",
  title, body, labels=["gate-review", ARTIFACT_ROOT, gate_type],
  execution_context=_execution_ctx(f"create-{gate_type.lower()}-pr", app_id=app_id))`.
- `start_to_close_timeout=60s`; `retry_policy=transient`. Returns the activity result (PR obj).

### 5.6 `_submit_gate_evidence(...)` — `base.py:922`
Signature: `(gate_id, gate_type, app_id, artifact_paths, pr_url, assembly_line, step, *,
forward_risk_tier=True) -> None`.
```
slim_evidence = _build_evidence_data(app_id, assembly_line, step)   # no inline content
gate_type_str = gate_type.value if isinstance(gate_type, GateType) else str(gate_type)
threshold_suffixes = { th["artifact"] for th in GATE_THRESHOLDS.get(gate_type_str, []) }
if threshold_suffixes:
    needed_paths = set()
    for step_def in slim_evidence.get("steps", {}).values():
        for art in step_def.get("file_artifacts") or []:
            path = art.get("path") or ""
            if any(path.endswith(s) for s in threshold_suffixes):
                needed_paths.add(path)
    criteria_evidence = _build_evidence_data(app_id, assembly_line, step,
                                             content_paths=needed_paths)   # enrich only targets
else:
    criteria_evidence = slim_evidence

if forward_risk_tier:
    check_input = CheckGateCriteriaInput(gate_id, gate_type, app_id,
        evidence_paths=artifact_paths, evidence_data=criteria_evidence, risk_tier=_risk_tier)
else:                                   # legacy Data / pre-F3 call-shape parity
    check_input = CheckGateCriteriaInput(gate_id, gate_type, app_id,
        evidence_paths=artifact_paths)  # NO evidence_data / risk_tier
await execute_activity(check_gate_criteria, check_input,
    start_to_close_timeout=60s, retry_policy=transient)

evidence_input = SubmitGateEvidenceInput(gate_id, gate_type, app_id,
    artifact_paths, pr_url, evidence_data=slim_evidence)   # persistence gets SLIM always
await execute_activity(submit_gate_evidence, evidence_input,
    start_to_close_timeout=60s, retry_policy=transient)
```
- `GATE_THRESHOLDS` (`activities/gate_operations.py`): only `G-V1`, `G-V2`, `G-V3` declare
  thresholds (parity/security/accessibility/safety-case files). Gates without thresholds
  (G-DC, G-RR, etc.) keep the slim bundle for the criteria call too.
- **GOTCHA:** two activities, both sequential; `check_gate_criteria` runs BEFORE
  `submit_gate_evidence`. Persistence always gets `slim_evidence` (no inline content) to stay
  under Temporal `limit.blobSize`; only the criteria call gets targeted `content` for threshold
  files. `forward_risk_tier=False` changes the CALL SHAPE (drops two fields) — preserve exactly
  for parity.

### 5.7 `_run_gate_pre_review(...)` — `base.py:1023`
Signature: `(gate_id, gate_type_value, evidence_paths, *, artifact_repo="", artifact_ref="")
-> None`. try/except/finally structure:
```
try:
    pre_review_result = await execute_activity(dispatch_agent_task,
        AgentTaskInput(skill_id="gate-pre-review", app_id=_app_id, task_type="gate-pre-review",
            input_artifacts=evidence_paths, artifact_repo, artifact_ref,
            context={"gate_id":gate_id, "gate_type":gate_type_value},
            execution_context=_execution_ctx(f"ai-pre-review-{gate_type_value.lower()}",
                gate_id=gate_id, input_artifact_paths=evidence_paths)),
        start_to_close_timeout=AGENT_START_TO_CLOSE (3h),
        heartbeat_timeout=AGENT_DISPATCH_HEARTBEAT_TIMEOUT (2min),
        retry_policy=transient)
    agent_markdown = pre_review_result.output_artifacts[0] if pre_review_result.output_artifacts else ""
    if not agent_markdown:
        raise ValueError("Gate pre-review produced no output")
    await execute_activity(store_gate_pre_review,
        StoreGatePreReviewInput(gate_id, agent_output=agent_markdown),
        start_to_close_timeout=30s, retry_policy=transient)
except Exception:                        # ANY failure — non-fatal
    workflow.logger.warning(f"Gate pre-review failed for {gate_type_value}; continuing without AI recommendation", extra={"gate_id":gate_id})
finally:
    if workflow.patched("mark-gate-ready-for-review-v1"):
        await execute_activity(mark_gate_ready_for_review, gate_id,
            start_to_close_timeout=30s, retry_policy=transient)
```
- **GOTCHA:** the `mark_gate_ready_for_review` flip lives in `finally` and is
  PATCH-GATED (`mark-gate-ready-for-review-v1`) — so the gate flips ready-for-review even when
  the AI pre-review failed, but only for post-patch runs. Preserve the patch ID.
- **GOTCHA:** `artifact_repo`/`artifact_ref` default `""` but if empty the agent-side
  `_fetch_input_artifacts` no-ops (requires non-empty repo) → skill runs with empty inputs and
  the pre-review complains about missing context (`base.py:1041-1046`). Real dispatchers MUST
  pass the active wave/app branch.

---

## 6. GATE HANDLING — the wait & rework routing

### 6.1 `_wait_for_gate_decision(gate_type) -> str` — `base.py:1103`
Returns `"approved"`, `"rejected"`, or `"cancelled"`.
```
_status = WAITING_FOR_SIGNAL
_pending_gate = gate_type
_updated_at = _now_iso()
consumed = _gate_decisions_consumed                     # snapshot BEFORE waiting
await workflow.wait_condition(lambda: len(_gate_decisions) > consumed or self.cancelled)

if self.cancelled:                                       # EARLY RETURN
    _status = CANCELLED; _updated_at = _now_iso(); return "cancelled"

entry = _gate_decisions[consumed]                        # drain by INDEX, not pop
if len(entry) == 5:
    decision, actor, reason, reason_category, card_decisions = entry
else:                                                    # 3-tuple legacy
    decision, actor, reason = entry[0], entry[1], entry[2]
    reason_category = None; card_decisions = []
_gate_decisions_consumed = consumed + 1

_pending_gate = None
_status = RUNNING
_updated_at = _now_iso()

gate_key = gate_type.value
if decision == GateStatus.APPROVED:
    _rework_feedback.pop(gate_key, None)                 # clear stale rejection feedback
    return "approved"

# else (REJECTED) — record structured feedback for the next dispatch
_rework_feedback[gate_key] = {
    "gate": gate_key, "rejected_by": actor, "reason": reason,
    "reason_category": reason_category, "card_decisions": card_decisions,
    "rejected_at": _now_iso()}
return "rejected"
```
- **GOTCHA:** decisions are drained by an *index counter* (`consumed`), never `pop`ped, so
  ordered replay-safe consumption is preserved and out-of-order signal arrival before the wait
  is buffered. `consumed` is captured *before* the `wait_condition` so a signal that arrives
  during a prior step still wakes this wait.
- **GOTCHA:** only `APPROVED` vs "anything else" is branched. There is no explicit REJECTED
  check — any non-APPROVED `GateStatus` (there are only APPROVED/REJECTED in the appended
  tuples) falls into the rework path.
- Evidence assembly for the gate is done by `_build_evidence_data` / `_submit_gate_evidence`
  (§5.6, §7) BEFORE the subclass calls this wait.

### 6.2 The rework loop (base-provided pieces; subclass owns the loop body)
The base gives: `_rework_feedback` recording (§6.1), `_dispatch_agent` forwarding of that
feedback into `context["rework_feedback"]` (§5.3), and the counter accessors:
- `_rework_count(gate_key)` → `_rework_iterations.get(gate_key, 0)` (`base.py:1372`)
- `_bump_rework(gate_key)` → increments and returns (`base.py:1376`)

**GOTCHA-2 (restated):** the base does NOT bump or bound the rework counter — subclass `run()`
must call `_bump_rework` and enforce any max-rework cap. A rebuild that increments the counter
inside `_wait_for_gate_decision` would double-count vs. every existing subclass.

Rework routing per decision:
- `"approved"` → subclass proceeds (typically to merge — §6.3).
- `"rejected"` → `_rework_feedback[gate_key]` now populated; subclass re-dispatches the
  affected step(s); `_dispatch_agent` auto-forwards the feedback for the gate returned by
  `_rework_gate_key_for_step(step_name)`.
- `"cancelled"` → subclass short-circuits to terminal CANCELLED.

### 6.3 Merge (approve path): `_reconcile_and_merge_with_retry_loop(...)` — `base.py:1159`
Signature: `(*, repo, pr_number, gate_id, merge_method="merge") -> None`.
```
merge_failure_types = {"MergeConflict","MergeDivergenceUnresolved","MergeBranchProtectionRejected"}
merge_ctx = _execution_ctx(f"merge-pr-{pr_number}", gate_id=gate_id)
while True:
    try:
        await execute_activity(reconcile_and_merge_pr,
            MergePRInput(repo, pr_number, merge_method, execution_context=merge_ctx),
            start_to_close_timeout=60s, retry_policy=RETRY_POLICIES["git_merge"])
        return                                           # SUCCESS — exit loop
    except (ActivityError, ApplicationError) as outer_exc:
        # unwrap to the ApplicationError carrying structured .type
        inner = outer_exc
        while not isinstance(inner, ApplicationError) and getattr(inner,"__cause__",None) is not None:
            inner = inner.__cause__
        if not isinstance(inner, ApplicationError):
            raise                                        # not structured — propagate
        failure_type = inner.type or ""
        if failure_type not in merge_failure_types:
            raise                                        # unrecognised — propagate
        exc = inner
        detail = {failure_type, reason=str(exc), pr_number, detected_at=_now_iso()}
        workflow.logger.warning("merge_blocked", extra={gate_id, pr_number, failure_type})
        _merge_retry_signalled = False                   # reset BEFORE blocking (avoid stale signal race)
        await execute_activity(set_gate_merge_blocked, args=[gate_id, detail],
            start_to_close_timeout=30s, retry_policy=transient)
        await workflow.wait_condition(lambda: _merge_retry_signalled or self.cancelled)
        if self.cancelled:
            return                                       # EARLY RETURN on cancel
        # loop back to top; flag stays True until a fresh failure resets it
```
- Retry policy `git_merge` (`retry_policies.py:95`): 5s init, 30s max, 3 attempts, backoff 2.0,
  `non_retryable_error_types=["MergeConflict","MergeDivergenceUnresolved",
  "MergeBranchProtectionRejected"]`. So `MergeConflict`/`MergeBranchProtectionRejected`
  short-circuit immediately; `MergeDivergenceUnresolved` also non-retryable at the Temporal
  layer (comment says "exhausts up to 3" but it's in the non-retryable list → 1 attempt).
- **GOTCHA:** the exception unwrap walks `__cause__` because Temporal wraps activity failures in
  `ActivityError` with the real `ApplicationError` in `__cause__`; the custom `@foundry_activity`
  decorator sometimes re-raises `ApplicationError` directly, so BOTH shapes are handled.
- **GOTCHA:** `_merge_retry_signalled` is reset to False *before* calling `set_gate_merge_blocked`
  so a stale retry signal from a previous iteration can't short-circuit the fresh wait
  (`base.py:1258-1261`). After a successful retry it stays True through the attempt.
- Non-merge errors and non-structured exceptions PROPAGATE (fail the workflow normally).

---

## 7. EVIDENCE ASSEMBLY — `_build_evidence_data(...)` — `base.py:1281`
Signature: `(app_id, assembly_line, step, *, include_content=False, content_paths=None) -> dict`.
```
steps = {}
for step_name, step_def in _evidence_steps_iter():
    artifacts = _step_results.get(step_name, [])
    metadata  = _agent_metadata.get(step_name, {})
    output_files = metadata.get("output_files", [])
    raw_file_artifacts = []
    for f in output_files:
        if not isinstance(f, OutputFile): continue        # skip non-OutputFile entries
        entry = {"path": f.path, "encoding": f.encoding}
        content_str = f.content if isinstance(f.content, str) else ""
        entry["size"] = len(content_str.encode("utf-8")) if content_str else 0
        if include_content or (content_paths is not None and f.path in content_paths):
            entry["content"] = f.content                  # inline ONLY when asked
        raw_file_artifacts.append(entry)
    deduped_file_artifacts = list({f["path"]: f for f in raw_file_artifacts}.values())  # last-wins by path
    steps[step_name] = {
        **_evidence_step_metadata(step_name, step_def),   # title/skill_id/artifact (or subclass shape)
        "output": artifacts[0] if artifacts else "",
        "metadata": {k:v for k,v in metadata.items() if k != "output_files"},
        "file_artifacts": deduped_file_artifacts}
return {"assembly_line": assembly_line, "app_id": app_id, "current_step": step, "steps": steps}
```
- Default = SLIM: `path`/`encoding`/`size` only, NO `content`. `include_content=True` inlines
  everything; `content_paths` inlines only the named paths (used by `_submit_gate_evidence`'s
  threshold targeting). Rationale: slim ~2 KiB vs fat ~1.5 MiB for a 13-step Discovery gate.
- **GOTCHA:** dedup keeps the LAST entry per `path` (dict-comprehension last-wins). `size` is
  UTF-8 byte length of str content, 0 for non-str/empty. `output_files` is stripped from the
  echoed `metadata` sub-dict (it's expanded into `file_artifacts` instead).

---

## 8. PAIRED-WORK / DELEGATED-BUNDLE DISPATCH (Phase 6 W1) — `base.py:514-750`

### 8.1 `_load_delegation_config(profile_id)` — `base.py:514`
```
_profile_id = str(profile_id or "")
if not _profile_id: return
try:
    config = await execute_activity(load_portfolio_delegation_activity,
        args=[_profile_id], start_to_close_timeout=15s, retry_policy=transient)
except Exception as exc:                 # best-effort → keep internal_fallback default
    workflow.logger.warning("delegation config load failed ...", extra={profile_id}); return
policy = (config or {}).get("fallback_policy")
if isinstance(policy, str) and policy:
    _portfolio_fallback_policy = policy
```

### 8.2 `_maybe_dispatch_bundle(*, step_or_gate_id, scope_kind, app_id, wave_id, fallback_fn,
is_delegatable=True, expires_hours=168)` — `base.py:547`
```
if not hasattr(self, "await_bundle_completion"):        # line didn't adopt BundleAwareMixin
    return await fallback_fn()
mode = await execute_activity(resolve_dispatch_mode,
    args=[scope_kind, step_or_gate_id, app_id, wave_id, _profile_id or None, is_delegatable],
    start_to_close_timeout=30s, retry_policy=transient)
if mode != DISPATCH_MODE_DELEGATED_BUNDLE ("delegated_bundle"):
    return await fallback_fn()
outcome = await _dispatch_bundle_and_wait(step_or_gate_id, scope_kind, app_id, wave_id, expires_hours)
if outcome["outcome"] == "accepted":
    return outcome["outputs"]
return await _apply_bundle_fallback(step_or_gate_id, scope_kind, app_id, wave_id,
    fallback_fn, expires_hours, outcome=outcome["outcome"], bundle_id=outcome["bundle_id"])
```

### 8.3 `_dispatch_bundle_and_wait(...)` — `base.py:631`
```
bundle_id = await execute_activity(dispatch_delegated_bundle,
    args=[scope_kind, step_or_gate_id, app_id, wave_id, expires_hours,
          _portfolio_fallback_policy, _workflow_created_by()],
    start_to_close_timeout=30s, retry_policy=transient)
outcome = await self.await_bundle_completion(bundle_id, timeout_seconds=expires_hours*3600 + 3600)
outputs = {}
if outcome == "accepted":
    outputs = dict(getattr(self,"_bundle_outputs",{}).get(bundle_id, {}))
return {"bundle_id": bundle_id, "outcome": outcome, "outputs": outputs}
```
- `await_bundle_completion` (`bundle_helpers.py:140`): `wait_condition(lambda: bundle_id in
  self._bundle_outcomes, timeout=timeout_seconds)`; catches `TimeoutError`→`"timeout"`;
  normalises unknown outcomes to `"timeout"`; else returns the outcome. **GOTCHA:** workflow
  timeout = `expires_hours*3600 + 3600` (bundle TTL + 1h safety) so the reaper's expiry signal
  always beats this timer.

### 8.4 `_apply_bundle_fallback(...)` — `base.py:677`
```
policy = _portfolio_fallback_policy
workflow.logger.warning("delegated-bundle.fallback.triggered", extra={bundle_id, outcome, scope, policy})
if policy == "redispatch" and step_or_gate_id not in _redispatch_guard:
    _redispatch_guard.add(step_or_gate_id)               # bound to ONE extra cycle per scope
    retry = await _dispatch_bundle_and_wait(step_or_gate_id, scope_kind, app_id, wave_id, expires_hours)
    if retry["outcome"] == "accepted": return retry["outputs"]
    return await fallback_fn()                            # redispatch failed → internal
if policy in ("escalate","fail"):
    raise ApplicationError(f"Delegated bundle for {scope_kind}:{step_or_gate_id} reached terminal "
        f"outcome {outcome!r}; fallback_policy={policy!r} stops the line.",
        type="DELEGATED_BUNDLE_FALLBACK", non_retryable=True)
return await fallback_fn()                                # internal_fallback (default)
```
- **GOTCHA:** `redispatch` is guarded by `_redispatch_guard` — a second non-accepted bundle for
  the same scope skips the redispatch branch and degrades to `fallback_fn()`. `escalate`/`fail`
  raise a `non_retryable=True` `ApplicationError` (type `DELEGATED_BUNDLE_FALLBACK`).

### 8.5 `_workflow_created_by()` — `base.py:736`
```
input_obj = getattr(self, "_input", None)
if input_obj is not None:
    created_by = getattr(input_obj, "created_by", "")
    if created_by: return str(created_by)
return "olympus-line-workflow"                            # stable non-NULL fallback
```

---

## 9. `_execution_ctx(...)` — Layer B step-execution context — `base.py:328`
Signature: `(step_id, *, app_id=None, gate_id="", wave_id=None, input_artifact_paths=None)
-> StepExecutionContext | None`.
```
if not _portfolio_id: return None                        # legacy/test callers no-op
line_id = LINE_LABEL.lower().replace(" ", "-")           # canonical lowercase-kebab
return StepExecutionContext(portfolio_id=_portfolio_id, line_id, step_id,
    app_id=(_app_id if app_id is None else app_id),
    wave_id=(_wave_id if wave_id is None else wave_id),
    gate_id, input_artifact_paths=list(input_artifact_paths or []))
```
- **GOTCHA:** returns `None` when `_portfolio_id` is empty → every activity that receives
  `execution_context=None` treats step-execution emission as best-effort/no-op. Threaded into
  dispatch, commit, PR, merge, and pre-review activity inputs.

---

## 10. RESILIENCE SUMMARY
- **Timeouts:** status-update 30s; agent dispatch 3h (`AGENT_START_TO_CLOSE`); pre-review agent
  3h + 2min heartbeat; commit/mirror 120s; PR create 60s; gate criteria/evidence 60s; merge 60s;
  priors load 10s; delegation load 15s; dispatch-mode 30s; bundle dispatch 30s; store pre-review
  30s; mark-ready 30s; set-merge-blocked 30s; update-output-ref 30s.
- **Heartbeats:** only `_run_gate_pre_review`'s dispatch passes `heartbeat_timeout=2min`.
  `_dispatch_agent` does NOT (relies on the 3h ceiling; dead-worker detection is weaker there).
- **Continue-as-new:** NONE in `base.py`. No `workflow.continue_as_new` call exists in this
  class — any CAN logic is subclass-owned.
- **Idempotency:** deterministic `activity_id`s (`agent-{step}`, `commit-{step}`,
  `patch-output-ref-{step}`) make retries/replays address the same activity. `merge_retry` handler
  is explicitly idempotent (`base.py:256`). Gate decisions consumed by index counter, not pop.
- **Compensation/rollback:** NONE. Mirror writes, output-ref updates, context-priors load, and
  the entire pre-review block are best-effort (swallow exceptions); the authoritative artifact
  commit and gate-criteria/evidence calls are NOT swallowed (they propagate on failure).
- **Patch IDs (must be verbatim):** `context-priors-v1` (`base.py:453`),
  `patch-output-artifact-ref-v1` (`base.py:877`), `mark-gate-ready-for-review-v1` (`base.py:1095`).

---

## 11. Behavioral parity checklist
A rebuild of `LineWorkflowBase` MUST satisfy:

1. Class has NO `@workflow.defn` and NO `run()`; it is a bare `HILSignalsMixin` subclass usable
   only as a base.
2. `__init__` calls `super().__init__()` FIRST, then initializes all 20 own attributes with the
   exact initial values in §1b (including `_portfolio_fallback_policy="internal_fallback"`).
3. `gate_approved` appends 5-tuple `(APPROVED, approved_by, justification, None, [])`;
   `gate_rejected` appends `(REJECTED, rejected_by, reason, getattr reason_category|None,
   list(getattr card_decisions|[]))`. Both set `_updated_at`. Neither may be re-decorated by a
   subclass.
4. `escalation_resolved` mutates ONLY `_updated_at`. `merge_retry` sets `_merge_retry_signalled=True`
   and `_updated_at`, idempotently.
5. `_wait_for_gate_decision` snapshots `consumed` before waiting; predicate is
   `len(_gate_decisions) > consumed or self.cancelled`; on cancel returns `"cancelled"` with
   `_status=CANCELLED`; drains by index (no pop); handles 3- and 5-tuple entries; on APPROVED pops
   `_rework_feedback[gate_key]` and returns `"approved"`; else stores the structured feedback dict
   (keys: gate, rejected_by, reason, reason_category, card_decisions, rejected_at) and returns
   `"rejected"`. It does NOT touch `_rework_iterations`.
6. `_dispatch_agent` forwards `fixture_scenario` (when `_input.fixture_scenarios[skill_id]`),
   `rework_feedback` (when `_rework_feedback[gate_key]` set), and `context_priors`
   (patch-gated, best-effort); dispatches with 3h timeout, `agent_failure` retry,
   `activity_id="agent-{step}"`; records `_agent_metadata[step]`.
7. `_commit_step_artifacts` builds one summary JSON + per-file batch into a SINGLE
   `write_artifacts_batch` commit (120s, transient, `activity_id="commit-{step}"`); mirror write
   and output-ref patch are best-effort; sets `_step_committed_paths[step]`.
8. `_submit_gate_evidence` calls `check_gate_criteria` (with threshold-targeted content only when
   `GATE_THRESHOLDS[gate_type]` is non-empty; omits `evidence_data`+`risk_tier` when
   `forward_risk_tier=False`) THEN `submit_gate_evidence` with always-slim evidence; both 60s
   transient, sequential.
9. `_reconcile_and_merge_with_retry_loop` uses `git_merge` retry; on the three structured merge
   errors (unwrapped via `__cause__`) fires `set_gate_merge_blocked`, resets
   `_merge_retry_signalled=False` first, waits on `_merge_retry_signalled or self.cancelled`,
   returns on cancel, loops otherwise; propagates non-merge/non-structured errors.
10. `_build_evidence_data` produces slim bundles by default (path/encoding/size), inlines content
    only under `include_content` or matching `content_paths`, dedups by path (last-wins), strips
    `output_files` from echoed metadata.
11. `_maybe_dispatch_bundle` no-ops to `fallback_fn` without `await_bundle_completion` or when
    `resolve_dispatch_mode != "delegated_bundle"`; returns bundle outputs on `accepted`; else
    `_apply_bundle_fallback` (redispatch guarded once → internal; escalate/fail → non-retryable
    `ApplicationError` type `DELEGATED_BUNDLE_FALLBACK`; else internal).
12. `_execution_ctx` returns `None` iff `_portfolio_id` empty; `line_id = LINE_LABEL.lower().replace(" ","-")`.
13. `get_status` returns `WorkflowStatusResponse` with `workflow.info().workflow_id` and the seven
    live state fields; reads `ASSEMBLY_LINE`.
14. `_bump_rework`/`_rework_count` maintain `_rework_iterations` per gate_key; base never
    auto-increments.
15. All time via `workflow.now()`; no wall-clock/random/IO; patch IDs `context-priors-v1`,
    `patch-output-artifact-ref-v1`, `mark-gate-ready-for-review-v1` preserved verbatim.
