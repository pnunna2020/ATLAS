# WaveArchitectureWorkflow — Atomic Regeneration Spec

Source: `temporal/olympus_workflows/workflows/wave_architecture.py` (967 lines).
Types: `temporal/olympus_workflows/types.py`. Retry policies: `temporal/olympus_workflows/retry_policies.py` and `temporal/olympus_workflows/temporal_base/retry_policies.py`.

Decorator: `@workflow.defn` (`wave_architecture.py:239`). Run method: `@workflow.run async def run(...)` (`wave_architecture.py:282-283`). This class does **NOT** subclass any base workflow — it is a bare `@workflow.defn` class (`wave_architecture.py:240`), so no gate machinery from `base.py` is inherited. All behavior is defined in-file. (Contrast: line workflows extend the base; this coordinator does not run gates itself — `wave_architecture.py:246-249`.)

Purpose (verbatim intent, `wave_architecture.py:1-46`): runs once per wave AFTER `WaveRationalizationWorkflow` clears G-DA. Produces the canonical wave plan `architecture/wave-{wave_id}/architecture-target-plan.json` once (committed to `main`), holds for operator pre-dispatch review, re-reads the (possibly edited) plan from git, provisions per-target apps+repos in parallel, then spawns `ArchitectureWorkflow` + `DataWorkflow` children per successfully-provisioned target with `ParentClosePolicy.ABANDON`.

---

## 1. STATE (every instance variable)

Defined in `__init__` (`wave_architecture.py:251-276`). No `super().__init__()` call.

| Var | Type | Initial | Mutated by / when |
|---|---|---|---|
| `_wave_id` | `str` | `""` | `run()` at `:297` from `input.wave_id`. Read everywhere; empty guards `_update_wave_status_safe` (`:864`). |
| `_portfolio_id` | `str` | `""` | `run()` at `:298`. |
| `_artifact_repo` | `str` | `""` | `run()` at `:299`. Used by `_read_plan_from_git` (`:604`). |
| `_status` | `WorkflowStatus` | `WorkflowStatus.PENDING` (`:255`) | `RUNNING` at `:300`; terminal set at `:330-334` (COMPLETED if outcome=="completed" else FAILED), CANCELLED at `:322`, FAILED in both except blocks (`:339`,`:348`); also set CANCELLED inside `cancel_all_children` signal (`:938`). Enum values: pending/running/completed/failed/cancelled (`types.py:118-126`). |
| `_current_step` | `str` | `""` | Set at each phase: `"wave-target-state-mapping"` (`:377`), `"awaiting-architecture-dispatch"` (`:484`), `"architecture-in-flight"` (`:504`), `"cancelled"` (`:323`,`:939`), `outcome` string (`:335`), `"failed"` (`:340`,`:349`). |
| `_progress_pct` | `float` | `0.0` | `5.0` (`:378`), `30.0` (`:475`), `50.0` (`:505`,`:589`), `100.0` (`:595`). |
| `_started_at` | `str` | `""` | `run()` `:301` = `_now_iso()`. |
| `_updated_at` | `str` | `""` | `_now_iso()` at nearly every state transition (`:302`,`:324`,`:336`,`:341`,`:350`,`:379`,`:476`,`:485`,`:506`,`:590`,`:596`) and in both signal handlers (`:905`,`:917`). |
| `_pre_dispatch_confirmed` | `bool` | `False` (`:262`) | Set `True` by `pre_dispatch_confirmed` signal (`:903`). Consumed by wait_condition (`:489`). |
| `_pre_dispatch_confirmed_by` | `str` | `""` (`:263`) | Set to `signal.confirmed_by` in signal (`:904`). Audit only; not read elsewhere. |
| `_dispatch_status` | `dict[str, DispatchTargetStatus]` | `{}` (`:269`) | Seeded by `_init_dispatch_status` (`:635`), mutated in place throughout provision/spawn. Returned by `dispatch_results` query (`:949`). Keyed by `target_app_id` (plan slug). |
| `_cancel_all_children_requested` | `bool` | `False` (`:275`) | Set `True` by `cancel_all_children` signal (`:916`). Consumed by wait_condition (`:490`) and checked at `:321`. |
| `_child_handles` | `list[tuple[str, Any]]` | `[]` (`:276`) | Appended (arch_handle.id, arch_handle) and (data_handle.id, data_handle) after each successful spawn (`:553-558`). Iterated + cancelled + cleared to `[]` by `cancel_all_children` (`:918-937`). |

`DispatchTargetStatus` fields (`types.py:2260-2292`): `source_app_id`, `target_app_id=""`, `target_app_name=""`, `target_repo=""`, `disposition=""`, `status="pending"`, `error=""`, `architecture_workflow_id=""`, `data_workflow_id=""`, `source_app_ids=[]`, `target_service_id=""`. Documented `status` values (`types.py:2266-2273`): pending / provisioning / provisioned / architecture_in_flight / data_in_flight / completed / failed. (`data_in_flight` and `completed` are documented but never set by this workflow — the coordinator only sets pending/provisioning/provisioned/architecture_in_flight/failed.) **GOTCHA:** the "all failed" test at `:570` checks specifically for `status == "architecture_in_flight"`; a target that only reached `provisioned` (spawn failed → flipped to `failed`) does NOT count as in-flight.

---

## 2. SIGNALS & QUERIES

### Signal `pre_dispatch_confirmed(signal: PreDispatchConfirmedSignal)` — `:891-905`
- Payload `PreDispatchConfirmedSignal` (`types.py:2434-2450`): single field `confirmed_by: str = ""`.
- Coerces dict→dataclass (`:901-902`).
- Mutates: `_pre_dispatch_confirmed = True` (`:903`), `_pre_dispatch_confirmed_by = signal.confirmed_by` (`:904`), `_updated_at` (`:905`).
- **Consumed by** wait_condition in `_await_pre_dispatch_confirmation` (`:487-492`): predicate `lambda: self._pre_dispatch_confirmed or self._cancel_all_children_requested`.
- Contract (docstring `:895-900`): the API has ALREADY overwritten the plan on `main` before sending this signal. The workflow re-reads git on the next step; the signal payload carries NO plan data. **GOTCHA:** operator edits flow only through git, never the signal.

### Signal `cancel_all_children()` — `:907-939`
- No payload.
- Mutates: `_cancel_all_children_requested = True` (`:916`), `_updated_at` (`:917`).
- Loop over `_child_handles` (`:918-936`): for each `(child_id, handle)` `await handle.cancel()`; on success log info (`:921`); on any `Exception` log warning and continue (`:928-936`) — a completed child raises on cancel; swallowed.
- Then `_child_handles = []` (`:937`), `_status = CANCELLED` (`:938`), `_current_step = "cancelled"` (`:939`).
- **GOTCHA:** children are `ABANDON` (`:816`,`:822`), so cancelling here is best-effort. If cancel arrives during the hold (before any spawn), `_child_handles` is empty and the loop is a no-op — the wait_condition then unblocks `run()` which returns `"cancelled"` at `:325`.
- **GOTCHA (subclass note):** neither signal is marked non-overridable in code (no decorator/annotation exists), but both mutate flags that gate the run loop's wait_condition — `pre_dispatch_confirmed` MUST keep setting `_pre_dispatch_confirmed`, and `cancel_all_children` MUST keep setting `_cancel_all_children_requested`, or the run() wait at `:487` deadlocks or never cancels. This class is not designed to be subclassed (`@workflow.defn` concrete).

### Query `dispatch_results() -> list[DispatchTargetStatus]` — `:945-949`
- Returns `list(self._dispatch_status.values())`. Stable shape once `_init_dispatch_status` runs; empty before that. Powers the wave-page progress table + partial-failure retry affordance.

### Query `get_status() -> WorkflowStatusResponse` — `:951-962`
- Returns `WorkflowStatusResponse(workflow_id=workflow.info().workflow_id, status=self._status, current_line=AssemblyLine.ARCHITECTURE, current_step=self._current_step, progress_pct=self._progress_pct, pending_gate=None, started_at=self._started_at, updated_at=self._updated_at)`.
- **GOTCHA:** `pending_gate` is hardcoded `None` — this coordinator never exposes a pending gate (it runs no gates).

---

## 3. CONTROL FLOW

### Module-level helpers

`_now_iso()` (`:171-172`): `workflow.now().isoformat()`.

`_plan_path(wave_id)` (`:175-176`): `f"architecture/wave-{wave_id}/architecture-target-plan.json"` (filename const `_TARGET_PLAN_FILENAME` = `"architecture-target-plan.json"`, `:149`).

`_build_input_artifacts(app_ids, wave_id, build_app_ids=None)` (`:179-215`):
```
build_set = set(build_app_ids or [])
out = []
for app_id in app_ids:
    if app_id in build_set:                      # greenfield BUILD app
        out.append(f"build/{app_id}/requirements/requirements-capability.json")
        out.append(f"rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json")
        continue                                 # NO discovery code outputs staged
    for name in _SOURCE_DISCOVERY_ARTIFACT_NAMES:      # 9 names, :110-120
        out.append(f"discovery/{app_id}/{name}")
    for name in _SOURCE_RATIONALIZATION_ARTIFACT_NAMES: # 5 names, :133-139
        out.append(f"rationalization/wave-{wave_id}/{app_id}/{name}")
for name in _WAVE_SHARED_RATIONALIZATION_ARTIFACT_NAMES:  # 2 names, :144-147
    out.append(f"rationalization/wave-{wave_id}/{name}")
return out
```
Const tuples:
- `_SOURCE_DISCOVERY_ARTIFACT_NAMES` (`:110-120`): catalog.json, structural-analysis.json, business-logic.json, quality-risk.json, ux-accessibility.json, data-domains.json, shared-db-analysis.json, synthesis.json, tco-baseline.json.
- `_SOURCE_RATIONALIZATION_ARTIFACT_NAMES` (`:133-139`): disposition-recommendation.json, classification.json, portfolio-score.json, intra-app-redundancy.json, disposition-governance.json.
- `_WAVE_SHARED_RATIONALIZATION_ARTIFACT_NAMES` (`:144-147`): redundancy-matrix.json, ux-overlap-matrix.json.
- **GOTCHA (`:100-132`):** these tuples are REPLICATED from `activities/line_transitions` (not imported, to avoid dragging DB/HTTP deps into the workflow sandbox). Both must be updated together. **GOTCHA (`:121-132`):** `disposition-recommendation.md` was DELIBERATELY removed — requiring the `.md` narrative sidecar hard-failed live waves; only the `.json` is required.

`_disposition_from_relationship(relationship)` (`:218-231`):
```
rel = (relationship or "").strip().lower()
if rel not in _RELATIONSHIP_TO_DISPOSITION:      # dict :156-168
    raise ApplicationError(f"unknown relationship {relationship!r} in plan target", non_retryable=True)
return _RELATIONSHIP_TO_DISPOSITION[rel]
```
`_RELATIONSHIP_TO_DISPOSITION` (`:156-168`): replace→Replace, consolidate→Consolidate, refactor→Refactor, rearchitect→Rearchitect, replatform→Replatform, retain→Retain, build→Build. **GOTCHA:** the plan schema already enforces the vocabulary; a missing key means schema drift → non-retryable raise.

### `run(input)` — `:282-359`
```
if isinstance(input, dict):
    input = WaveArchitectureWorkflowInput(**input)     # :294-295 dict coercion
self._wave_id = input.wave_id
self._portfolio_id = input.portfolio_id
self._artifact_repo = input.artifact_repo
self._status = RUNNING
self._started_at = _now_iso(); self._updated_at = self._started_at   # :297-302

if not input.app_ids:                                   # :304
    raise ApplicationError("WaveArchitectureWorkflow requires at least one app_id", non_retryable=True)
if not input.artifact_repo:                             # :309
    raise ApplicationError("WaveArchitectureWorkflow requires artifact_repo", non_retryable=True)
```
**GOTCHA:** these two guards raise BEFORE the `try`, so they are NOT caught by the except blocks — they do NOT flip the wave to `stuck-awaiting-recovery`; the workflow just fails.

```
try:
    await self._dispatch_wave_target_state_mapper(input)   # Step 1, :317
    await self._await_pre_dispatch_confirmation()          # Step 2, :320
    if self._cancel_all_children_requested:                # :321
        self._status = CANCELLED
        self._current_step = "cancelled"
        self._updated_at = _now_iso()
        return "cancelled"
    outcome = await self._provision_and_spawn(input)       # Step 3+4, :328
    self._status = COMPLETED if outcome == "completed" else FAILED   # :330-334
    self._current_step = outcome
    self._updated_at = _now_iso()
    return outcome                                          # :337
except ApplicationError:                                    # :338
    self._status = FAILED; self._current_step = "failed"; self._updated_at = _now_iso()
    await self._update_wave_status_safe("stuck-awaiting-recovery",
                                        reason="wave_architecture coordinator failed")
    raise                                                   # :346 re-raise
except Exception as exc:                                    # :347 (BLE001)
    self._status = FAILED; self._current_step = "failed"; self._updated_at = _now_iso()
    workflow.logger.error("wave_architecture.run failed", extra={...})
    await self._update_wave_status_safe("stuck-awaiting-recovery",
                                        reason=f"wave_architecture: {exc!r}"[:500])
    raise                                                   # :359 re-raise
```
Outcome→status mapping: `outcome` can be `"completed"` → COMPLETED, or `"stuck-awaiting-recovery"` (from `_provision_and_spawn` `:591`) → FAILED. **GOTCHA:** when `_provision_and_spawn` returns `"stuck-awaiting-recovery"`, `run()` sets `_status=FAILED` and returns that string — it did NOT raise, so the except blocks don't fire; the wave status flip to `stuck-awaiting-recovery` happened inside `_provision_and_spawn` at `:585`. Both except paths BOTH re-raise after flipping wave status. Return-string contract (docstring `:286-292`): completed / failed / stuck-awaiting-recovery / cancelled.

### Step 1 — `_dispatch_wave_target_state_mapper(input)` — `:365-476`
```
self._current_step = "wave-target-state-mapping"; self._progress_pct = 5.0; self._updated_at = _now_iso()
input_artifacts = _build_input_artifacts(input.app_ids, input.wave_id, input.build_app_ids)
execution_ctx = StepExecutionContext(portfolio_id, line_id="Architecture",
    step_id="wave-target-state-mapping", wave_id, input_artifact_paths=list(input_artifacts))   # :384-390
mapper_context = {"wave_name": input.wave_name}                   # :393
if input.build_app_ids:                                          # :394
    mapper_context["build_app_ids"] = list(input.build_app_ids)
task_input = AgentTaskInput(task_type="wave-target-state-mapping", app_id="", wave_id=input.wave_id,
    skill_id="target-state-mapper", input_artifacts=input_artifacts, artifact_repo=input.artifact_repo,
    model_preference="tier-2", workspace_key=f"wave-architecture-{input.wave_id}",
    context=mapper_context, execution_context=execution_ctx)     # :400-411
```
- **GOTCHA (`:391-392`):** `app_id=""` + `wave_id=<uuid>` — exactly-one-scope rule enforced by DB check `agent_task_application_or_wave_ck`.
- **GOTCHA (`:373-376`):** `model_preference="tier-2"` (Sonnet 1M) deliberately — Opus 4.7 1M soft-fails >50% on the largest synthesis prompts.

**Activity call 1 — `dispatch_agent_task`** (`:412-419`): args `task_input`; `start_to_close_timeout=30min`; `heartbeat_timeout=2min`; `retry_policy=RETRY_POLICIES["agent_failure"]` (3 attempts, exp backoff 5s→60s, coeff 2.0, `retry_policies.py:38-43`); `activity_id=f"agent-wave-target-state-mapping-{wave_id}"`.

```
plan_file = first f in (result.output_files or []) where f.path.endswith("architecture-target-plan.json")  # :424-430
if plan_file is None:                                            # :431
    raise ApplicationError("target-state-mapper did not emit architecture-target-plan.json", non_retryable=True)
```

**Activity call 2 — `validate_artifact_against_schema`** (`:438-446`): args `ValidateArtifactInput(artifact_filename="architecture-target-plan.json", raw_content=plan_file.content)`; `start_to_close_timeout=30s`; `retry_policy=RETRY_POLICIES["validation_failure"]` (maximum_attempts=1, NO retry, `retry_policies.py:51-53`).
```
if not validation.validated or validation.errors:               # :447
    errors_preview = "; ".join(validation.errors[:4])
    raise ApplicationError(f"wave plan failed schema validation: {errors_preview}", non_retryable=True)
```

**Activity call 3 — `write_artifact`** (`:457-474`): args `WriteArtifactInput(repo=input.artifact_repo, branch="main", path=_plan_path(wave_id), content=plan_file.content, commit_message=f"Wave {wave_id}: architecture target plan ({N} targets)", execution_context=execution_ctx)` where `N = len(validation.parsed_payload.get('targets', []) if validation.parsed_payload else [])` (`:466`); `start_to_close_timeout=60s`; `retry_policy=RETRY_POLICIES["transient"]` (HTTP: 3 attempts, 1s→15s, coeff 2.0, `temporal_base/retry_policies.py:35-40`); `activity_id=f"commit-target-plan-{wave_id}"`.
```
self._progress_pct = 30.0; self._updated_at = _now_iso()          # :475-476
```
All three activities are SEQUENTIAL (awaited one after another). Committed to `main` BEFORE the operator hold (docstring `:14-15`).

### Step 2 — `_await_pre_dispatch_confirmation()` — `:482-492`
```
self._current_step = "awaiting-architecture-dispatch"; self._updated_at = _now_iso()
await self._update_wave_status_safe("awaiting-architecture-dispatch")     # :486
await workflow.wait_condition(lambda: self._pre_dispatch_confirmed or self._cancel_all_children_requested)  # :487-492
```
Blocks indefinitely (no timeout) until a signal flips either flag. **GOTCHA:** no deadline on the hold — the coordinator can park forever awaiting operator input.

### Step 3+4 — `_provision_and_spawn(input)` — `:498-597`
```
self._current_step = "architecture-in-flight"; self._progress_pct = 50.0; self._updated_at = _now_iso()
await self._update_wave_status_safe("architecture-in-flight")             # :507
plan = await self._read_plan_from_git()                                   # :509
targets = plan.get("targets") or []
if not isinstance(targets, list) or not targets:                          # :511
    raise ApplicationError("architecture-target-plan.json on main has no targets", non_retryable=True)
self._init_dispatch_status(targets)                                       # :519
run_ts = int(workflow.now().timestamp())                                  # :521 — shared child-id suffix

provision_futures = [self._provision_one_target(t, input) for t in targets]   # :525
provisioned = await asyncio.gather(*provision_futures, return_exceptions=True)  # :528 PARALLEL

for plan_target, result in zip(targets, provisioned):                     # :532
    target_app_id = plan_target.get("target_app_id") or ""
    status = self._dispatch_status.get(target_app_id)
    if status is None:                                                    # :535
        continue                                                          # target with empty/missing id was never seeded
    if isinstance(result, BaseException):                                 # :537 provision failed
        status.status = "failed"; status.error = repr(result)
        workflow.logger.warning("create_target_app_and_repo failed", extra={...})
        continue
    status.status = "provisioned"                                         # :548
    try:
        arch_handle, data_handle = await self._spawn_children_for_target(plan_target, result, input, run_ts)  # :550
        self._child_handles.append((arch_handle.id, arch_handle))         # :553
        self._child_handles.append((data_handle.id, data_handle))         # :556
    except Exception as exc:                                              # :559 spawn failed
        status.status = "failed"; status.error = f"spawn_children: {exc!r}"
        workflow.logger.warning("start_child_workflow failed", extra={...})

any_in_flight = any(s.status == "architecture_in_flight" for s in self._dispatch_status.values())  # :570
if not any_in_flight:                                                     # :574 EVERY target failed
    error_reasons = [s.error for s in self._dispatch_status.values() if s.error]
    reason_summary = "; ".join(error_reasons)[:500] if error_reasons else "every target failed to provision"
    await self._update_wave_status_safe("stuck-awaiting-recovery", reason=f"wave_architecture: {reason_summary}")
    self._progress_pct = 50.0; self._updated_at = _now_iso()
    return "stuck-awaiting-recovery"                                      # :591

await self._update_wave_status_safe("architecture-dispatched")            # :594 at least one in flight
self._progress_pct = 100.0; self._updated_at = _now_iso()
return "completed"                                                        # :597
```
**GOTCHA:** the spawn loop is SEQUENTIAL over targets (each `_spawn_children_for_target` is awaited in-loop), even though provisioning was parallel via gather. **GOTCHA:** the loop `zip`s `targets` with `provisioned` positionally — order preserved by `asyncio.gather` semantics. **GOTCHA:** partial failure is tolerated — as long as ANY target reaches `architecture_in_flight`, outcome is `"completed"`.

### `_read_plan_from_git()` — `:599-618`
**Activity call — `read_artifact`** (`:601-611`): args `ReadArtifactInput(repo=self._artifact_repo, branch="main", path=_plan_path(self._wave_id))`; `start_to_close_timeout=30s`; `retry_policy=RETRY_POLICIES["transient"]`; `activity_id=f"read-target-plan-{self._wave_id}"`.
```
try:
    return json.loads(read_result.content)                                # :613
except (json.JSONDecodeError, TypeError, ValueError) as exc:              # :614
    raise ApplicationError(f"architecture-target-plan.json on main is malformed: {exc}", non_retryable=True) from exc
```
**GOTCHA:** re-reads from `main` (post-operator-edit) — the in-memory plan from Step 1 is discarded; git is the single source of truth (`:36-38`).

### `_init_dispatch_status(targets)` — `:620-646`
```
for t in targets:
    target_app_id = str(t.get("target_app_id") or "")
    if not target_app_id:                                                 # :628
        continue                                                          # skip targets with no id (never seeded)
    source_app_ids = [str(s) for s in (t.get("source_app_ids") or []) if isinstance(s, str) and s]  # :630
    anchor = source_app_ids[0] if source_app_ids else ""                  # :634
    self._dispatch_status[target_app_id] = DispatchTargetStatus(
        source_app_id=anchor, target_app_id=target_app_id,
        target_app_name=str(t.get("target_name") or ""),
        target_repo=str(t.get("target_repo_slug") or ""),
        disposition=_disposition_from_relationship(str(t.get("relationship") or "")),   # :640 may raise
        status="pending", source_app_ids=list(source_app_ids),
        target_service_id=str(t.get("target_service_id") or ""))
```
**GOTCHA:** keyed by `target_app_id` (plan slug), unique by schema so decomposition targets sharing sources get distinct rows (`:622-625`).

### `_provision_one_target(plan_target, input)` — `:648-697`
```
target_app_id = str(plan_target.get("target_app_id") or "")
status = self._dispatch_status[target_app_id]                             # :661 KeyError if id absent — but gather catches it
status.status = "provisioning"
source_app_ids = list(status.source_app_ids)
anchor = source_app_ids[0] if source_app_ids else ""
peers = source_app_ids[1:]
if status.disposition == "Build":                                         # :670 greenfield
    anchor = target_app_id; peers = []; source_app_ids = []
```
**Activity call — `create_target_app_and_repo`** (`:674-697`): args `CreateTargetAppAndRepoInput(source_app_id=anchor, target_app_name=status.target_app_name or target_app_id, target_repo=status.target_repo, default_branch="main", wave_id=input.wave_id, portfolio_id=input.portfolio_id, disposition=status.disposition, peer_source_app_ids=list(peers), source_app_ids=list(source_app_ids), target_service_id=status.target_service_id, target_app_slug=target_app_id)`; `start_to_close_timeout=5min`; `retry_policy=RETRY_POLICIES["transient"]`; `activity_id=f"provision-target-{target_app_id}"`. Returns `CreateTargetAppAndRepoResult(target_app_id, target_repo_url, created_new_app_row, lineage_rows_inserted)` (`types.py:2040-2055`).
- **GOTCHA (`:687-692`):** `target_app_slug=target_app_id` lets provisioning distinguish 1→N decomposition (distinct slug per target) from 1:1 in-place transition. **GOTCHA (`:666-673`):** Build target uses its own id as `source_app_id`, empty peers/sources — it's its own target row.
- Disposition case behavior: for target==source dispositions (Refactor/Rearchitect/Replatform/Retain) the activity returns `target_app_id == source_app_id`; for new-target (Replace/Consolidate/Build) it mints a new UUID and sets `created_new_app_row=True` (`types.py:2043-2047`).

### `_spawn_children_for_target(plan_target, provisioned, input, run_ts)` — `:699-852`
```
target_app_id = provisioned.target_app_id                                 # PROVISIONED UUID
plan_target_app_id = str(plan_target.get("target_app_id") or "")          # PLAN SLUG
child_key = plan_target_app_id or target_app_id                           # :725 slug preferred
arch_workflow_id = f"architecture-{child_key}-{run_ts}"                    # :726
data_workflow_id = f"data-{child_key}-{run_ts}"                           # :727
status = self._dispatch_status[plan_target_app_id]                        # :728
relationship = str(plan_target.get("relationship") or "").strip().lower()
source_app_ids = list(status.source_app_ids)
target_service_id = status.target_service_id
is_build = relationship == "build" or status.disposition == "Build"       # :732
```
**GOTCHA (`:716-724`):** child workflow ids keyed on the unique plan SLUG, NOT the provisioned UUID. Keying on the UUID collapsed every 1→N decomposition target onto one id and tripped `WORKFLOW_ALREADY_EXISTS` for all but the first — the bug that stranded 18/19 targets. Slug is collision-free; UUID fallback only if slug absent.

**Activity call — `fetch_application_source_repos`** (`:738-744`): args `FetchSourceReposInput(source_app_ids=list(source_app_ids))`; `start_to_close_timeout=30s`; `retry_policy=RETRY_POLICIES["transient"]`; `activity_id=f"fetch-source-repos-{target_app_id}"`. Returns `FetchSourceReposResult(anchor_source_repo, source_repos)` (`types.py:925-939`).
```
anchor_source_repo = source_repos_result.anchor_source_repo               # :745
source_repos_map = dict(source_repos_result.source_repos)
if not anchor_source_repo and not is_build:                               # :747
    workflow.logger.warning("no source_repo resolved for anchor source app", extra={...})
target_app_name = status.target_app_name or target_app_id                 # :759
```
Build `arch_input = LineWorkflowInput(...)` (`:761-778`): app_id=target_app_id, app_name=target_app_name, wave_id, portfolio_id, artifact_repo, source_repo=anchor_source_repo, source_repos=source_repos_map, target_repo_url=provisioned.target_repo_url, `disposition=None` (Architecture resolves from DB — `:770`), `peer_workflow_ids={"Data": data_workflow_id}`, target_service_id, relationship, source_app_ids, `plan_target_key=plan_target_app_id`.
```
data_prior = []                                                           # :784
if not is_build:                                                          # :785
    for src in source_app_ids:
        if not src: continue
        data_prior.append(f"discovery/{src}/data-domains.json")
        data_prior.append(f"discovery/{src}/shared-db-analysis.json")
```
`data_input = LineWorkflowInput(...)` (`:791-807`): same fields but `peer_workflow_ids={"Architecture": arch_workflow_id}` and `prior_artifacts=data_prior`.

**Child-workflow start — `ArchitectureWorkflow`** (`:812-817`): `workflow.start_child_workflow("ArchitectureWorkflow", arch_input, id=arch_workflow_id, parent_close_policy=ABANDON)`. SEQUENTIAL await.
**Child-workflow start — `DataWorkflow`** (`:818-823`): `workflow.start_child_workflow("DataWorkflow", data_input, id=data_workflow_id, parent_close_policy=ABANDON)`. SEQUENTIAL await.
- **GOTCHA (`:809-811`):** ABANDON so children outlive coordinator; cross-line Arch↔Data signalling goes through DB-backed `arch_data_signal_registry`, so sibling lifecycle is fine after coordinator closes.

**Activity call — `update_application_line_projection`** (`:827-846`): wrapped in `try/except Exception` (best-effort, `:839`). args `UpdateApplicationLineProjectionInput(app_id=target_app_id, line="Architecture", workflow_id=arch_workflow_id, status="in_progress")`; `start_to_close_timeout=30s`; `retry_policy=RETRY_POLICIES["transient"]` (no activity_id). On failure: log warning, continue — does NOT fail the spawn. **GOTCHA:** projection only for Architecture, not Data.
```
status.target_app_id = target_app_id                                      # :848
status.architecture_workflow_id = arch_workflow_id
status.data_workflow_id = data_workflow_id
status.status = "architecture_in_flight"
return arch_handle, data_handle                                           # :852
```

### `_update_wave_status_safe(new_status, reason="")` — `:858-885`
```
if not self._wave_id: return                                              # :864
try:
    await workflow.execute_activity(update_wave_status,
        UpdateWaveStatusInput(wave_id=self._wave_id, new_status=new_status, reason=reason),
        start_to_close_timeout=30s, retry_policy=RETRY_POLICIES["transient"])   # :867-876
except Exception as exc:                                                  # :877
    workflow.logger.warning("update_wave_status failed", extra={...})
```
**Activity call — `update_wave_status`**: best-effort, never raises. Called with: `awaiting-architecture-dispatch` (`:486`), `architecture-in-flight` (`:507`), `stuck-awaiting-recovery` (`:342`,`:355`,`:585`), `architecture-dispatched` (`:594`).

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS (ordered summary)

| # | Call | Args | Timeout(s) | Retry policy | Parallel? | Line |
|---|---|---|---|---|---|---|
| 1 | `dispatch_agent_task` | AgentTaskInput (mapper) | s2c 30min, heartbeat 2min | agent_failure (3, 5→60s) | seq | :412 |
| 2 | `validate_artifact_against_schema` | ValidateArtifactInput | s2c 30s | validation_failure (1, no retry) | seq | :438 |
| 3 | `write_artifact` | WriteArtifactInput (commit plan→main) | s2c 60s | transient (3, 1→15s) | seq | :457 |
| 4 | `read_artifact` | ReadArtifactInput (re-read plan) | s2c 30s | transient | seq | :601 |
| 5 | `create_target_app_and_repo` × N | CreateTargetAppAndRepoInput | s2c 5min | transient | **PARALLEL** (`asyncio.gather`, `:528`) | :674 |
| 6 | `fetch_application_source_repos` | FetchSourceReposInput | s2c 30s | transient | seq (in spawn loop) | :738 |
| 7 | child `ArchitectureWorkflow` | LineWorkflowInput arch | — | — (ABANDON) | seq | :812 |
| 8 | child `DataWorkflow` | LineWorkflowInput data | — | — (ABANDON) | seq | :818 |
| 9 | `update_application_line_projection` | UpdateApplicationLineProjectionInput | s2c 30s | transient | seq, best-effort try/except | :828 |
| 10 | `update_wave_status` | UpdateWaveStatusInput | s2c 30s | transient | best-effort try/except | :867 |

No `non_retryable_error_types` are set on any activity's retry policy here (the policies used — transient/agent_failure/validation_failure — carry none; only `git_merge`, unused here, defines a non-retryable list). Non-retryable behavior is instead enforced by raising `ApplicationError(..., non_retryable=True)` in workflow code.

---

## 5. GATE HANDLING

This coordinator runs **NO gates** (`:246-249`, `get_status` returns `pending_gate=None`). The only human-in-the-loop pause is the **pre-dispatch hold** (Step 2), which is a plain signal wait, not a gate:
- Evidence assembly: none — the plan itself, committed to `main` at `:457`, IS the review artifact; the operator reads/edits it via the pre-dispatch UI.
- The wait: `_await_pre_dispatch_confirmation` (`:487`) blocks on `_pre_dispatch_confirmed or _cancel_all_children_requested`, indefinite.
- Routing:
  - `pre_dispatch_confirmed` signal → `_pre_dispatch_confirmed=True` → wait unblocks → `run()` checks `_cancel_all_children_requested` at `:321` (False) → proceeds to `_provision_and_spawn`.
  - `cancel_all_children` signal → `_cancel_all_children_requested=True` → wait unblocks → `run()` at `:321` returns `"cancelled"` (status CANCELLED).
- There is **NO rework loop and NO rework counter** — approve/reject/merge-blocked/rework routing does not exist in this workflow. The equivalent of "reject" is the operator overwriting the plan on `main` then confirming (the edit flows through the git re-read at `:509`) or cancelling. There is no automated retry queue; recovery is an external `/resume` endpoint re-spawning on the same workflow_id (`:247-248`, `:591` `stuck-awaiting-recovery`).

---

## 6. RESILIENCE

- **Timeouts:** per-activity `start_to_close` only (table §4). Mapper additionally heartbeats every 2min (`:416`). No workflow-level execution timeout in-file. Pre-dispatch hold is unbounded.
- **Heartbeats:** only `dispatch_agent_task` (heartbeat_timeout 2min, `:416`).
- **Continue-as-new:** NONE. This workflow never calls `continue_as_new`; it completes once children are spawned (children are ABANDON so the coordinator's history stays bounded — one mapper dispatch + N provisions + 2N child starts).
- **Idempotency:** activity_ids are deterministic per wave/target (`agent-wave-target-state-mapping-{wave_id}`, `commit-target-plan-{wave_id}`, `read-target-plan-{wave_id}`, `provision-target-{target_app_id}`, `fetch-source-repos-{target_app_id}`) — replays reuse cached results. Child workflow ids keyed on plan slug + shared `run_ts` (`:521`,`:726-727`) — collision-free across targets, stable across replay (run_ts from `workflow.now()` is deterministic under replay).
- **Compensation/rollback:** NONE explicit. Partial failures are tolerated and recorded per-target in `_dispatch_status`; a fully-failed wave flips to `stuck-awaiting-recovery` for external `/resume`. `cancel_all_children` is best-effort cleanup (children ABANDON, so cancellation is not guaranteed).
- **GOTCHA:** the plan is committed to `main` BEFORE the hold; if the workflow fails after commit but before spawn, the plan persists and an operator can `/resume`.
- **GOTCHA:** because children are ABANDON, "completed" does NOT mean the Architecture/Data lines finished — only that they were spawned (`:288-289`).

---

## 7. GOTCHAs (consolidated)

1. Not a base-workflow subclass — no inherited gate/signal machinery (`:240`).
2. Input validation guards (`:304`,`:309`) raise *outside* the try — no wave-status flip on that failure path.
3. `_provision_and_spawn` returning `"stuck-awaiting-recovery"` sets `_status=FAILED` but does NOT raise; wave-status flip happened inside at `:585`.
4. "All failed" detection keys strictly on `status == "architecture_in_flight"` (`:570`) — `provisioned`-then-spawn-failed targets do not count.
5. Child ids MUST use plan slug not provisioned UUID (`:716-724`) — else `WORKFLOW_ALREADY_EXISTS` on decomposition.
6. `run_ts` shared across all children in one run (`:521`) — deterministic under replay; do not recompute per target.
7. Plan re-read from git after confirmation (`:509`) — in-memory Step-1 plan discarded; operator edits honored.
8. Artifact-name tuples replicated (not imported) and must stay in sync with `line_transitions` (`:100-132`); `.md` sidecar deliberately excluded.
9. `tier-2` model forced for mapper (`:373-376`).
10. Build targets: empty source sets, own id as anchor, no discovery/data prior artifacts, `is_build` suppresses the missing-source-repo warning (`:747`) and prior-artifact staging (`:785`).
11. `update_application_line_projection` and `update_wave_status` are best-effort (swallow exceptions) — never fail the run.
12. Spawn loop is sequential though provisioning is parallel.
13. `dispatch_results`/`get_status` queries must never mutate state; `get_status.pending_gate` always None.

---

## 8. Behavioral parity checklist

A rebuild MUST satisfy:

1. **Input coercion:** dict input is converted to `WaveArchitectureWorkflowInput` (`:294`).
2. **Empty `app_ids`** raises non-retryable `ApplicationError` "requires at least one app_id" and does NOT flip wave status.
3. **Empty `artifact_repo`** raises non-retryable "requires artifact_repo".
4. **Mapper dispatch:** `AgentTaskInput` has `task_type="wave-target-state-mapping"`, `app_id=""`, `skill_id="target-state-mapper"`, `model_preference="tier-2"`, `workspace_key="wave-architecture-{wave_id}"`; input bundle = per-app Discovery(9)+Rationalization(5) for legacy apps, requirements-capability+disposition-recommendation.json for build apps, plus 2 wave-shared; timeout 30min/heartbeat 2min; agent_failure retry (3 attempts).
5. **Missing plan file** in mapper output → non-retryable "did not emit architecture-target-plan.json".
6. **Schema validation** runs with validation_failure policy (no retry); `not validated or errors` → non-retryable "wave plan failed schema validation: <first 4 errors>".
7. **Plan committed** to `main` at `_plan_path` before the hold; commit message includes target count.
8. **Wave status sequence** (best-effort): awaiting-architecture-dispatch → architecture-in-flight → (architecture-dispatched | stuck-awaiting-recovery).
9. **Hold** blocks on `_pre_dispatch_confirmed or _cancel_all_children_requested`, indefinitely; cancel during hold returns `"cancelled"` and status CANCELLED.
10. **Plan re-read** from `main` after confirmation; malformed JSON → non-retryable "malformed"; empty/non-list `targets` → non-retryable "has no targets".
11. **Provisioning parallel** via `asyncio.gather(return_exceptions=True)`; per-target exception → status `failed` + `error=repr`, does not abort others.
12. **Build target** provisioning uses `source_app_id=target_app_id`, empty peers/sources, disposition "Build".
13. **relationship→disposition** map exactly (replace/consolidate/refactor/rearchitect/replatform/retain/build → Title-case); unknown → non-retryable raise.
14. **Child ids** = `architecture-{slug}-{run_ts}` / `data-{slug}-{run_ts}` using plan slug; unique per target; single shared `run_ts`.
15. **Children ABANDON**; Arch gets `peer_workflow_ids={"Data":...}`, Data gets `{"Architecture":...}` + `prior_artifacts` of data-domains.json/shared-db-analysis.json per source (empty for build); both `disposition=None`, `plan_target_key=slug`.
16. **Projection** `update_application_line_projection(Architecture,in_progress)` is best-effort try/except.
17. **Outcome:** ANY target reaching `architecture_in_flight` → `"completed"` (status COMPLETED, progress 100); zero → `"stuck-awaiting-recovery"` (status FAILED, progress 50) after wave flip.
18. **Exceptions** in run() flip wave to stuck-awaiting-recovery (both ApplicationError and generic paths) then re-raise; status FAILED, step "failed".
19. **Queries:** `dispatch_results` returns list of DispatchTargetStatus; `get_status` returns WorkflowStatusResponse with `current_line=ARCHITECTURE`, `pending_gate=None`.
20. **Signals:** `pre_dispatch_confirmed` sets flag + confirmed_by; `cancel_all_children` cancels all buffered handles (swallowing per-handle errors), clears handles, sets CANCELLED.
21. **Idempotent activity_ids** exactly as listed; no continue-as-new; no gate execution.
