# RationalizationWorkflow — Atomic Regeneration Spec

**Source:** `temporal/olympus_workflows/workflows/rationalization.py` (1–789)
**Base class:** `LineWorkflowBase` (`temporal/olympus_workflows/workflows/base.py`) — see `_base-workflow.md` for inherited helpers. This doc fully captures THIS class's own state, signal, `run()`, and PR-builder overrides, and cites the base helpers it calls.
**Decorator:** `@workflow.defn` (rationalization.py:102). `run` is `@workflow.run` (rationalization.py:153).
**MRO:** `RationalizationWorkflow → LineWorkflowBase → HILSignalsMixin` (base.py:111, signals.py:19).

> Scope note (from module docstring, rationalization.py:1–15): cross-portfolio workflow that runs after Discovery is complete for a wave; conceptually operates on ALL wave apps, but the concrete `run()` is **per-app** (keyed on `input.app_id`). Steps: Redundancy Analysis → Gate G-RR → Disposition Recommendation → Disposition Governance → User Impact (Retire/Replace only) → Classification & Risk Tiering → Gate G-DA.

---

## 0. Module-level constants (MUST reproduce exactly)

### `RATIONALIZATION_SKILLS` (rationalization.py:56–77) — bound to `STEPS` classvar (line 126)
Ordered dict; step-name → `{skill_id, artifact}`:

| step_name (key) | `skill_id` | `artifact` |
|---|---|---|
| `redundancy-analysis` | `redundancy-analyzer` | `redundancy-matrix.json` |
| `disposition-recommendation` | `disposition-recommender` | `disposition-recommendation.json` |
| `disposition-governance` | `disposition-governance` | `disposition-governance.json` |
| `user-impact` | `assess-user-impact` | `user-impact-analysis.json` |
| `classification` | `classify-application` | `classification.json` |

GOTCHA (rationalization.py:51–55): Step 1 uses `redundancy-analyzer` (three-perspective: entity/operation/persona overlap). The prior duplicate `analyze-portfolio-redundancy` skill was removed in P3.5-R1.7 — do NOT reintroduce it.

GOTCHA: `STEPS` keys (`redundancy-analysis`, …) are the keys used for `_step_results` / `_step_committed_paths` / `_dispatch_agent(step_name=…)`. These are DISTINCT from the `STEP_WEIGHTS` keys and the `_set_step` current-step strings (see below). Do not conflate.

### `STEP_WEIGHTS` (rationalization.py:88–96) — bound to `STEP_WEIGHTS` classvar (line 127)
Must sum to 100. Keys match the frontend step-registry IDs (`dashboard/src/components/WorkflowStepper/stepRegistry.ts`), NOT the `STEPS` keys:

| key | weight |
|---|---|
| `detect-redundancy` | 20.0 |
| `gate-review-rr` | 15.0 |
| `recommend-disposition` | 18.0 |
| `disposition-governance` | 8.0 |
| `assess-user-impact` | 12.0 |
| `classification` | 10.0 |
| `gate-review-da` | 17.0 |

Sum = 20+15+18+8+12+10+17 = **100** ✓.

GOTCHA (rationalization.py:83–87): `disposition-governance` is a silent sub-phase that stays visible in the UI as `recommend-disposition` — the two share a `task_type` in the backend step registry. `_set_step("recommend-disposition", …)` is deliberately called twice (once for the recommendation dispatch, once for the governance dispatch) so the stepper never jumps to a non-existent UI node.

### `MAX_REWORK_ITERATIONS = 3` (rationalization.py:99)
Applies to BOTH gates independently, via `_rework_count(key) > MAX_REWORK_ITERATIONS` (strict `>`, so the 4th rejection fails). Counter is per-gate-key.

### Classvars (rationalization.py:122–127)
- `ASSEMBLY_LINE = AssemblyLine.RATIONALIZATION` (`"Rationalization"`)
- `ARTIFACT_ROOT = "rationalization"`
- `LINE_LABEL = "Rationalization"`
- `STATUS_PREFIX = "rationalization"` → `_set_step` writes status `rationalization_in_progress`
- `STEPS = RATIONALIZATION_SKILLS`
- `STEP_WEIGHTS = STEP_WEIGHTS`
- `SINGLE_GATE_KEY` — NOT set (inherited default `None`); this class overrides `_rework_gate_key_for_step` instead (see §7).
- `_task_type_prefix()` — NOT overridden ⇒ returns `ARTIFACT_ROOT = "rationalization"`, so agent `task_type` = `rationalization-{step_name}` (base.py:471).

---

## 1. STATE (instance variables)

### 1a. Inherited from `HILSignalsMixin.__init__` (signals.py:29–45) — set via `super().__init__()` chain
| Attr | Type | Initial | Mutated by |
|---|---|---|---|
| `approved` | bool | `False` | `approve()` signal (unused by this line) |
| `plan_approved` | bool | `False` | `approve_plan` / `provide_plan_feedback` (unused here) |
| `plan_feedback_received` | bool | `False` | plan signals (unused) |
| `plan_feedback_comments` | str | `""` | plan signals (unused) |
| `document_approved` | bool | `False` | doc signals (unused) |
| `document_feedback_received` | bool | `False` | doc signals (unused) |
| `document_feedback_comments` | str | `""` | doc signals (unused) |
| **`cancelled`** | bool | `False` | **`cancel_workflow()` signal** (signals.py:83–85) — consumed by every `wait_condition` in this workflow |

### 1b. Inherited from `LineWorkflowBase.__init__` (base.py:136–191)
| Attr | Type | Initial | Mutated where |
|---|---|---|---|
| `_app_id` | str | `""` | `run()`:168 = `input.app_id` |
| `_portfolio_id` | str | `""` | `run()`:169 = `input.portfolio_id` |
| `_wave_id` | str | `""` | `run()`:170 = `input.wave_id` |
| `_status` | `WorkflowStatus` | `PENDING` | `run()`:163 → RUNNING; many mutations (see §3) → WAITING_FOR_SIGNAL / FAILED / CANCELLED / COMPLETED |
| `_current_step` | str | `""` | `_set_step`, and direct writes (`"failed"`, `"classification-awaiting-tier1-approval"`, `"max-rework-exceeded-grr/gda"`, `"completed"`) |
| `_progress_pct` | float | `0.0` | `_set_step`; set to `100.0` at completion (line 661) |
| `_pending_gate` | `GateType\|None` | `None` | set in `_wait_for_gate_decision` (base.py:1114), cleared to `None` on consume (base.py:1140) |
| `_started_at` | str | `""` | `run()`:164 = `_now_iso()` |
| `_updated_at` | str | `""` | refreshed on nearly every state change via `_now_iso()` |
| `_gate_decisions` | `list[tuple]` | `[]` | appended by `gate_approved` (5-tuple, base.py:200) / `gate_rejected` (5-tuple, base.py:223) |
| `_gate_decisions_consumed` | int | `0` | incremented in `_wait_for_gate_decision` (base.py:1138) |
| `_rework_feedback` | `dict[str,dict]` | `{}` | set on reject / popped on approve in `_wait_for_gate_decision` (base.py:1146,1149); read by `_dispatch_agent` (base.py:443) |
| `_rework_iterations` | `dict[str,int]` | `{}` | `_bump_rework` (base.py:1378); read by `_rework_count` (base.py:1374) |
| `_step_results` | `dict[str,list[str]]` | `{}` | `run()` writes each step's `output_artifacts`; read by `_build_evidence_data` |
| `_step_committed_paths` | `dict[str,list[str]]` | `{}` | set in `_commit_step_artifacts` (base.py:872); read to assemble evidence/inputs |
| `_agent_metadata` | `dict[str,dict]` | `{}` | set in `_dispatch_agent` (base.py:494) |
| `_risk_tier` | `int\|None` | `None` | **Never set by this class** (see GOTCHA below) |
| `_merge_retry_signalled` | bool | `False` | `merge_retry()` signal → True (base.py:256); reset/consumed in `_reconcile_and_merge_with_retry_loop` |
| `_profile_id` | str | `""` | only via `_load_delegation_config` — **not called by this workflow** |
| `_portfolio_fallback_policy` | str | `"internal_fallback"` | via `_load_delegation_config` (not called) |
| `_redispatch_guard` | `set[str]` | `set()` | bundle fallback (not exercised here) |

GOTCHA (`_risk_tier`): This workflow NEVER sets `_risk_tier` and NEVER stores `self._input`. Both gate-evidence submissions pass `forward_risk_tier=False` (rationalization.py:271,530), so `_submit_gate_evidence` omits `evidence_data`+`risk_tier` from `check_gate_criteria` (base.py:994–1000). Rationalization predates F3 risk_tier plumbing (rationalization.py:259–261). Because `self._input` is never set, `_dispatch_agent`'s `fixture_scenarios` hook (base.py:434–440) always sees `None` and no-ops here — fixture scenarios are inert for this workflow.

GOTCHA (delegation): This workflow does NOT inherit `BundleAwareMixin` and never calls `_load_delegation_config` / `_maybe_dispatch_bundle`. All steps run internally; bundle machinery is dead code for this class.

### 1c. THIS class's own state (`__init__`, rationalization.py:137–151)
`super().__init__()` first (line 138), then:

| Attr | Type | Initial | Meaning / mutated where |
|---|---|---|---|
| `_stakeholder_approved` | bool | `False` (line 140) | Set True by `stakeholder_approved` signal when `scope != "tier-1-classification"` (line 690). Consumed (reset to False) after G-DA dual-signal wait (line 569) and on G-DA reject (line 583). Predicate in G-DA approval branch (line 561). |
| `_stakeholder_info` | str | `""` (line 141) | Set to `"{stakeholder} approved scope: {scope}"` on non-tier1 stakeholder signal (line 691). Observability only — never read by control flow. |
| `_tier1_approved_by` | `str\|None` | `None` (line 148) | Set to `signal.stakeholder` when stakeholder signal has `scope == "tier-1-classification"` (line 688). Predicate for the Tier-1 wait (line 471) and passed to `confirm_classification_tier_1` (line 483). |
| `_dispositions` | `dict[str,str]` | `{}` (line 151) | Declared "populated during recommendation step" but **NEVER written or read anywhere in this file** — dead state. Reproduce for fidelity but it has no effect. |

---

## 2. SIGNALS & QUERIES

### 2a. Inherited signal handlers — subclasses MUST NOT redefine (base.py:117 / 194)
Re-decorating would duplicate-register in Temporal. These are all live for this workflow:

- **`gate_approved(GateApprovedSignal)`** (base.py:197–209): appends 5-tuple `(GateStatus.APPROVED, signal.approved_by, signal.justification, None, [])` to `_gate_decisions`; refresh `_updated_at`. `reason_category=None`, `card_decisions=[]` for approvals.
- **`gate_rejected(GateRejectedSignal)`** (base.py:211–232): normalizes `card_decisions = list(getattr(signal,"card_decisions",[]) or [])`, `reason_category = getattr(signal,"reason_category",None)`; appends `(GateStatus.REJECTED, signal.rejected_by, signal.reason, reason_category, card_decisions)`.
- **`escalation_resolved(EscalationResolvedSignal)`** (base.py:234–239): only refreshes `_updated_at` (no state).
- **`merge_retry(GateMergeRetrySignal)`** (base.py:241–257): sets `_merge_retry_signalled=True`; idempotent. Fired by `POST /api/v1/gates/{id}/retry-merge`.
- **HILSignalsMixin signals** (signals.py:48–85): `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`, **`cancel_workflow`** — of these only `cancel_workflow()` (sets `cancelled=True`) is load-bearing for this line.

**Consuming predicates** (which `wait_condition` drains each buffer):
- `_gate_decisions` → `_wait_for_gate_decision` (base.py:1118): `lambda: len(self._gate_decisions) > consumed or self.cancelled`, where `consumed = self._gate_decisions_consumed` captured at entry.
- `_merge_retry_signalled` → `_reconcile_and_merge_with_retry_loop` (base.py:1271): `lambda: self._merge_retry_signalled or self.cancelled`.
- `cancelled` → participates in every `wait_condition` (Tier-1 wait line 471, G-DA dual-signal wait line 561, gate-decision wait, merge-retry wait).

### 2b. THIS class's own signal — `stakeholder_approved` (rationalization.py:670–692)
`@workflow.signal async def stakeholder_approved(self, signal: StakeholderApprovedSignal)`.

`StakeholderApprovedSignal` (types.py:166–172): fields `approval_id: str`, `stakeholder: str`, `scope: str`.

Handler body:
```
if signal.scope == "tier-1-classification":
    self._tier1_approved_by = signal.stakeholder          # unblocks Tier-1 wait (line 471)
else:                                                      # typically scope == "g-da"
    self._stakeholder_approved = True                      # prerequisite for G-DA approval (line 561)
    self._stakeholder_info = f"{signal.stakeholder} approved scope: {signal.scope}"
self._updated_at = _now_iso()
```
GOTCHA: One signal method, TWO wait sites disambiguated by `scope`. `scope == "tier-1-classification"` → Tier-1 classification confirmation only. ANY other scope → sets `_stakeholder_approved` (G-DA path). The `_tier1_approved_by` branch does NOT set `_stakeholder_approved`, and vice-versa. G-DA still ALSO requires the PM `gate_approved` signal — neither role can unilaterally close G-DA (rationalization.py:550–555, 683–685).

### 2c. Query — inherited `get_status()` (base.py:1353–1365)
`@workflow.query` returning `WorkflowStatusResponse(workflow_id=workflow.info().workflow_id, status=self._status, current_line=AssemblyLine.RATIONALIZATION, current_step=self._current_step, progress_pct=self._progress_pct, pending_gate=self._pending_gate, started_at=self._started_at, updated_at=self._updated_at)`. No own query overrides in this class.

---

## 3. CONTROL FLOW

### 3a. `run(self, input: LineWorkflowInput) -> str` (rationalization.py:153–190)
```
self._status = WorkflowStatus.RUNNING          # 163
self._started_at = _now_iso()                  # 164
self._updated_at = self._started_at            # 165

app_id = input.app_id
self._app_id = app_id                          # 167-168
self._portfolio_id = input.portfolio_id        # 169
self._wave_id = input.wave_id                  # 170
repo = input.artifact_repo                     # 171

wf_id = workflow.info().workflow_id            # 173
run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]   # 174
branch = f"olympus/rationalization/{app_id}/{run_suffix}"             # 175
workspace_key = f"rationalization-{app_id}-{run_suffix}"             # 176

try:
    return await self._execute_rationalization(input, app_id, repo, branch, workspace_key)   # 179
except Exception:                              # 180 — catches ANY exception incl. cancellation-derived
    self._status = WorkflowStatus.FAILED       # 181
    self._current_step = "failed"              # 182
    self._updated_at = _now_iso()              # 183
    try:
        await self._update_app_status(app_id, "rationalization_failed", "failed", "Rationalization")  # 185-187
    except Exception:
        pass                                   # 189 — best-effort DB update
    raise                                      # 190 — re-raise original
```
GOTCHA (branch/workspace derivation): `run_suffix` is the last `-`-delimited segment of the workflow id (falls back to first 8 chars if no `-`). Branch and workspace_key are DERIVED, not passed in — a rebuild must reproduce this exact string form or artifacts land on the wrong branch.

GOTCHA (idempotency): No continue-as-new anywhere. No explicit heartbeat config in this workflow (agent dispatch heartbeat lives in `_run_gate_pre_review` only, base.py:1069). All error handling routes through the single top-level `except Exception` which best-effort marks the app `rationalization_failed` then re-raises. `_execute_rationalization` itself returns `"failed"`/`"cancelled"` strings for HANDLED terminal states (no exception) — those bypass the `except` block.

### 3b. `_execute_rationalization(input, app_id, repo, branch, workspace_key) -> str` (rationalization.py:192–664)

#### STEP 1 — Redundancy Analysis (202–227)
```
await self._set_step("detect-redundancy", 0.0)                       # 207
redundancy_result = await self._dispatch_agent(
    app_id, step_name="redundancy-analysis",
    input_artifacts=list(input.prior_artifacts),                     # 211
    workspace_key, artifact_repo=repo, artifact_ref=branch)          # 208-215
self._step_results["redundancy-analysis"] = redundancy_result.output_artifacts   # 216
artifact_path = f"rationalization/{app_id}/redundancy-matrix.json"   # 219
await self._commit_step_artifacts(repo, branch, app_id,
    "redundancy-analysis", redundancy_result, artifact_path)         # 220-227
```
Note (rationalization.py:203–206): UI splits this into detect/generate/compare sub-steps but only the first is emitted; by gate-review-rr the stepper marks all three complete.

#### GATE G-RR LOOP (`while True:`, 230–332)
```
while True:
    grr_artifact_paths = dedup_paths(list(self._step_committed_paths.get("redundancy-analysis", [])))  # 231-233

    pr_result = await self._create_gate_pr(repo, branch, app_id,
        gate_type="G-RR",
        title=f"Gate G-RR: Rationalization Review — {app_id}",
        body=self._build_grr_pr_body(app_id))                        # 236-243

    gate_record = await workflow.execute_activity(
        create_gate_record,
        CreateGateRecordInput(gate_type="G-RR", app_id=app_id,
            portfolio_id=input.portfolio_id,
            workflow_id=workflow.info().workflow_id,
            evidence_package_url=pr_result.pr_url),
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"])                    # 246-257

    await self._submit_gate_evidence(
        gate_id=gate_record.gate_id, gate_type=GateType.G_RR,
        app_id=app_id, artifact_paths=grr_artifact_paths,
        pr_url=pr_result.pr_url, assembly_line="Rationalization",
        step="redundancy-analysis", forward_risk_tier=False)         # 262-271

    await self._run_gate_pre_review(gate_record.gate_id, "G-RR",
        grr_artifact_paths, artifact_repo=repo, artifact_ref=branch) # 274-280 (advisory, fault-tolerant)

    await self._set_step("gate-review-rr", STEP_WEIGHTS["detect-redundancy"])   # 283 → progress 20.0
    decision = await self._wait_for_gate_decision(GateType.G_RR)     # 284

    if decision == "cancelled":                                      # 286
        return "cancelled"                                           # 287

    if decision == "approved":                                       # 289
        await self._reconcile_and_merge_with_retry_loop(
            repo=repo, pr_number=pr_result.pr_number,
            gate_id=gate_record.gate_id, merge_method="merge")       # 292-297
        break                                                        # 298 — exit G-RR loop

    # --- decision == "rejected" → rework ---
    self._bump_rework("G-RR")                                        # 301
    if self._rework_count("G-RR") > MAX_REWORK_ITERATIONS:           # 302 (> 3, i.e. 4th reject)
        self._status = WorkflowStatus.FAILED                         # 303
        self._current_step = "max-rework-exceeded-grr"               # 304
        self._updated_at = _now_iso()                                # 305
        await self._update_app_status(app_id, "rationalization_failed",
            "max-rework-exceeded-grr", "Rationalization")            # 306-311
        return "failed"                                              # 312

    # re-run redundancy with feedback (rework_feedback["G-RR"] now set)
    await self._set_step("detect-redundancy", 0.0)                   # 315
    redundancy_result = await self._dispatch_agent(app_id,
        "redundancy-analysis", list(input.prior_artifacts),
        workspace_key, repo, branch)                                 # 316-323
    self._step_results["redundancy-analysis"] = redundancy_result.output_artifacts  # 324
    await self._commit_step_artifacts(repo, branch, app_id,
        "redundancy-analysis", redundancy_result, artifact_path)     # 325-332
    # loop back to top of while: builds a NEW PR + NEW gate_record
```
GOTCHA (G-RR rework): each rework iteration creates a BRAND-NEW gate PR + gate record (loop re-enters at line 231). `_wait_for_gate_decision` returns `"rejected"` only after `_bump_rework` and the feedback-store happened inside itself (base.py:1149). Ordering: `_bump_rework` at line 301 is a SECOND increment source — but note `_wait_for_gate_decision` does NOT bump `_rework_iterations`; it only stores `_rework_feedback`. So the counter is incremented ONLY here at 301 (and 584 for G-DA). Verify: `_bump_rework` (base.py:1376) is the sole counter mutator; `_wait_for_gate_decision` mutates only `_rework_feedback`. Correct.

GOTCHA (`redundancy-analyzer` gate mapping): `_rework_gate_key_for_step("redundancy-analysis")` returns `"G-RR"` (rationalization.py:135), so on rework `_dispatch_agent` forwards `_rework_feedback["G-RR"]` into `context["rework_feedback"]` (base.py:441–445).

#### STEP 3 — Disposition Recommendation (fan-out) (334–356)
```
progress_after_grr = STEP_WEIGHTS["detect-redundancy"] + STEP_WEIGHTS["gate-review-rr"]  # 335 = 35.0
await self._set_step("recommend-disposition", progress_after_grr)    # 336 → 35.0
disposition_result = await self._dispatch_agent(app_id,
    "disposition-recommendation",
    input_artifacts=self._step_committed_paths.get("redundancy-analysis", []),  # 341
    workspace_key, repo, branch)                                     # 338-345
self._step_results["disposition-recommendation"] = disposition_result.output_artifacts  # 346
disp_artifact_path = f"rationalization/{app_id}/disposition-recommendation.json"  # 348
await self._commit_step_artifacts(repo, branch, app_id,
    "disposition-recommendation", disposition_result, disp_artifact_path)  # 349-356
```

#### STEP 4 — Disposition Governance (silent sub-phase) (358–385)
```
progress_after_disp = progress_after_grr + STEP_WEIGHTS["recommend-disposition"]  # 364 = 53.0
await self._set_step("recommend-disposition", progress_after_disp)   # 365 → 53.0 (SAME step string, higher progress)
governance_result = await self._dispatch_agent(app_id,
    "disposition-governance",
    input_artifacts=self._step_committed_paths.get("disposition-recommendation", []),  # 370
    workspace_key, repo, branch)                                     # 367-374
self._step_results["disposition-governance"] = governance_result.output_artifacts  # 375
gov_artifact_path = f"rationalization/{app_id}/disposition-governance.json"  # 377
await self._commit_step_artifacts(repo, branch, app_id,
    "disposition-governance", governance_result, gov_artifact_path)  # 378-385
```
GOTCHA: `_rework_gate_key_for_step` returns `"G-DA"` for both `disposition-recommendation` and `disposition-governance` (anything ≠ `redundancy-analysis`, rationalization.py:135). So on G-DA rework these steps get `_rework_feedback["G-DA"]`.

#### STEP 5 — User Impact Analysis (Retire/Replace ONLY) (387–410)
```
progress_after_gov = progress_after_disp + STEP_WEIGHTS["disposition-governance"]  # 388 = 61.0
await self._set_step("assess-user-impact", progress_after_gov)       # 389 → 61.0
if _is_retire_or_replace(input.disposition):                         # 391
    impact_result = await self._dispatch_agent(app_id, "user-impact",
        input_artifacts=self._step_committed_paths.get("disposition-recommendation", []),  # 395
        workspace_key, repo, branch)                                 # 392-399
    self._step_results["user-impact"] = impact_result.output_artifacts  # 400
    impact_artifact_path = f"rationalization/{app_id}/user-impact-analysis.json"  # 402
    await self._commit_step_artifacts(repo, branch, app_id,
        "user-impact", impact_result, impact_artifact_path)          # 403-410
# else: user-impact step is SKIPPED entirely; no _step_results["user-impact"] entry
```
`_is_retire_or_replace` (rationalization.py:779–782): returns True iff `_normalize_disposition(disposition) in ("Retire","Replace")`. `_set_step("assess-user-impact", 61.0)` runs UNCONDITIONALLY (line 389), even when the impact dispatch is skipped.

#### STEP 6 — Classification & Risk Tiering (412–487)
```
await self._set_step("classification",
    progress_after_gov + STEP_WEIGHTS.get("assess-user-impact", 15.0))  # 419-422 → 61.0+12.0 = 73.0
classification_inputs = self._step_committed_paths.get("disposition-recommendation", [])  # 424
classification_result = await self._dispatch_agent(app_id, "classification",
    input_artifacts=classification_inputs, workspace_key, repo, branch)  # 425-432
self._step_results["classification"] = classification_result.output_artifacts  # 433
classification_artifact_path = f"rationalization/{app_id}/classification.json"  # 434
await self._commit_step_artifacts(repo, branch, app_id,
    "classification", classification_result, classification_artifact_path)  # 435-442

persist_result = await workflow.execute_activity(
    persist_classification,
    PersistClassificationInput(app_id=app_id,
        classification_artifact_path=classification_artifact_path,
        classification_json=(classification_result.output_artifacts[0]
            if classification_result.output_artifacts else "")),      # 452-458
    start_to_close_timeout=timedelta(seconds=60),
    retry_policy=RETRY_POLICIES["transient"])                         # 448-461

if persist_result.tier_1_flag:                                        # 467
    self._current_step = "classification-awaiting-tier1-approval"     # 468
    self._updated_at = _now_iso()                                     # 469
    await workflow.wait_condition(
        lambda: self._tier1_approved_by is not None or self.cancelled) # 470-472
    if self.cancelled:                                                # 473
        self._status = WorkflowStatus.CANCELLED                       # 474
        self._updated_at = _now_iso()                                 # 475
        return "cancelled"                                            # 476
    await workflow.execute_activity(
        confirm_classification_tier_1,
        ConfirmClassificationInput(app_id=app_id,
            approved_by=self._tier1_approved_by),                     # 481-484
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"])                     # 479-487
```
GOTCHA (Tier-1 gate): When `persist_result.tier_1_flag` is True, the workflow BLOCKS indefinitely until a `stakeholder_approved` signal with `scope=="tier-1-classification"` arrives (sets `_tier1_approved_by`) OR `cancelled`. `confirm_classification_tier_1` flips `risk_tier_source` "auto"→"confirmed" (types.py:1428–1437). This is a HARD gate: Tier 1 is a trust decision that always requires human confirmation (rationalization.py:412–418, 463–466). `_progress_pct` stays at 73.0 through the wait (`_set_step` not re-called; only `_current_step` is set to the awaiting string).

GOTCHA (`persist_classification` json arg): passes `output_artifacts[0]` (the agent-summary text ref) as `classification_json`, or `""` if no artifacts. The activity parses it and writes risk/complexity/archetype with `source="auto"` (types.py:1393–1408).

#### GATE G-DA LOOP (`while True:`, 489–654)
```
while True:
    gda_artifact_paths = []
    for step_name in ["disposition-recommendation","disposition-governance","user-impact"]:  # 492-496
        gda_artifact_paths.extend(self._step_committed_paths.get(step_name, []))  # 497
    gda_artifact_paths = dedup_paths(gda_artifact_paths)             # 498

    pr_result = await self._create_gate_pr(repo, branch, app_id,
        gate_type="G-DA",
        title=f"Gate G-DA: Disposition Approval — {app_id}",
        body=self._build_gda_pr_body(app_id, input.disposition))     # 500-507

    gate_record = await workflow.execute_activity(create_gate_record,
        CreateGateRecordInput(gate_type="G-DA", app_id=app_id,
            portfolio_id=input.portfolio_id,
            workflow_id=workflow.info().workflow_id,
            evidence_package_url=pr_result.pr_url),
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"])                    # 509-520

    await self._submit_gate_evidence(gate_id=gate_record.gate_id,
        gate_type=GateType.G_DA, app_id=app_id,
        artifact_paths=gda_artifact_paths, pr_url=pr_result.pr_url,
        assembly_line="Rationalization", step="disposition-approval",
        forward_risk_tier=False)                                     # 522-531

    await self._run_gate_pre_review(gate_record.gate_id, "G-DA",
        gda_artifact_paths, artifact_repo=repo, artifact_ref=branch) # 534-540

    progress_after_impact = progress_after_gov + STEP_WEIGHTS["assess-user-impact"]  # 542 = 73.0
    await self._set_step("gate-review-da", progress_after_impact)    # 543 → 73.0
    decision = await self._wait_for_gate_decision(GateType.G_DA)     # 544

    if decision == "cancelled":                                      # 546
        return "cancelled"                                           # 547

    if decision == "approved":                                       # 549
        if workflow.patched("gda-dual-signal-v1"):                   # 559
            await workflow.wait_condition(
                lambda: self._stakeholder_approved or self.cancelled) # 560-562
            if self.cancelled:                                       # 563
                self._status = WorkflowStatus.CANCELLED              # 564
                self._updated_at = _now_iso()                        # 565
                return "cancelled"                                   # 566
            self._stakeholder_approved = False                       # 569 — consume flag
        await self._reconcile_and_merge_with_retry_loop(
            repo=repo, pr_number=pr_result.pr_number,
            gate_id=gate_record.gate_id, merge_method="merge")       # 571-576
        break                                                        # 577

    # --- decision == "rejected" → rework ---
    if workflow.patched("gda-dual-signal-v1"):                       # 582
        self._stakeholder_approved = False                           # 583 — drop stale flag
    self._bump_rework("G-DA")                                        # 584
    if self._rework_count("G-DA") > MAX_REWORK_ITERATIONS:           # 585 (> 3)
        self._status = WorkflowStatus.FAILED                         # 586
        self._current_step = "max-rework-exceeded-gda"               # 587
        self._updated_at = _now_iso()                                # 588
        await self._update_app_status(app_id, "rationalization_failed",
            "max-rework-exceeded-gda", "Rationalization")            # 589-594
        return "failed"                                              # 595

    # re-run disposition + governance + (impact if retire/replace)
    await self._set_step("recommend-disposition", progress_after_grr)  # 598 → 35.0
    disposition_result = await self._dispatch_agent(app_id,
        "disposition-recommendation",
        self._step_committed_paths.get("redundancy-analysis", []),
        workspace_key, repo, branch)                                 # 599-606
    self._step_results["disposition-recommendation"] = disposition_result.output_artifacts  # 607
    await self._commit_step_artifacts(repo, branch, app_id,
        "disposition-recommendation", disposition_result, disp_artifact_path)  # 608-615

    governance_result = await self._dispatch_agent(app_id,
        "disposition-governance",
        self._step_committed_paths.get("disposition-recommendation", []),
        workspace_key, repo, branch)                                 # 617-624
    self._step_results["disposition-governance"] = governance_result.output_artifacts  # 625
    await self._commit_step_artifacts(repo, branch, app_id,
        "disposition-governance", governance_result, gov_artifact_path)  # 626-633

    if _is_retire_or_replace(input.disposition):                     # 635
        impact_result = await self._dispatch_agent(app_id, "user-impact",
            self._step_committed_paths.get("disposition-recommendation", []),
            workspace_key, repo, branch)                             # 636-645
        self._step_results["user-impact"] = impact_result.output_artifacts  # 646
        await self._commit_step_artifacts(repo, branch, app_id,
            "user-impact", impact_result,
            f"rationalization/{app_id}/user-impact-analysis.json")   # 647-654
    # loop back to top of while: new G-DA PR + gate_record
```

#### COMPLETION (656–664)
```
await self._update_app_status(app_id, "rationalization_complete", "completed", "Rationalization")  # 657-659
self._status = WorkflowStatus.COMPLETED          # 660
self._progress_pct = 100.0                        # 661
self._current_step = "completed"                  # 662
self._updated_at = _now_iso()                     # 663
return "completed"                                # 664
```

GOTCHA (progress values): `gate-review-da` is set to progress **73.0** (`progress_after_gov + assess-user-impact` = 61.0+12.0), NOT 83.0 — the `classification` (10.0) and `gate-review-da` (17.0) weights are NEVER reflected as intermediate progress. Progress jumps 73.0 → 100.0 on completion. `_set_step("classification", 73.0)` (line 419) and `_set_step("gate-review-da", 73.0)` (line 543) both land at 73.0. This is intentional/quirky and must be reproduced.

### 3c. Helper: `_rework_gate_key_for_step` (rationalization.py:133–135)
```
def _rework_gate_key_for_step(self, step_name: str) -> str | None:
    return "G-RR" if step_name == "redundancy-analysis" else "G-DA"
```
Overrides base default (which returns `SINGLE_GATE_KEY=None`). Consumed by `_dispatch_agent` to select which `_rework_feedback` entry to forward.

### 3d. Module helpers (rationalization.py:765–788)
- `_normalize_disposition(disposition)` (765–776): `None`→`None`; `Disposition` instance→`.value`; `list`→`"".join(str(x) for x in disposition)` (handles Temporal deserializing enum as a list of chars); else `str(disposition)`.
- `_is_retire_or_replace(disposition)` (779–782): `_normalize_disposition(...) in ("Retire","Replace")`.
- `_disposition_label(disposition)` (785–788): normalized value, or `"TBD"` if falsy.

GOTCHA: `_normalize_disposition` handles the list case because Temporal's payload converter may deserialize a `StrEnum` as a list of characters across the workflow boundary. A rebuild MUST tolerate `disposition` arriving as a list and join it — otherwise Retire/Replace detection silently fails and the user-impact step is wrongly skipped.

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS (in order)

No child workflows. All calls are `execute_activity` (sequential; NO `asyncio.gather` anywhere — every step awaits the prior). Order per happy path:

| # | Activity | Args (type) | start_to_close | retry_policy | heartbeat | non_retryable |
|---|---|---|---|---|---|---|
| 1 | `_set_step`→`update_application_status` | `UpdateAppStatusInput` | 30s | `transient` (HTTP: 3 attempts, 1–15s) | — | — |
| 2 | `dispatch_agent_task` (redundancy) | `AgentTaskInput` | `AGENT_START_TO_CLOSE`=3h | `agent_failure` (3 attempts, 5–60s exp) | — | — |
| 3 | `write_artifacts_batch` (commit redundancy) | `WriteArtifactsBatchInput` | 120s | `transient` | — | — |
| 3b| (patch) `update_agent_task_output_ref` | args list | 30s | `transient` | — | — (best-effort, gated `patch-output-artifact-ref-v1`) |
| 4 | `create_pr` (G-RR) | `CreatePRInput` | 60s | `transient` | — | — |
| 5 | `create_gate_record` (G-RR) | `CreateGateRecordInput` | 30s | `transient` | — | — |
| 6 | `check_gate_criteria` (G-RR, no risk_tier) | `CheckGateCriteriaInput` | 60s | `transient` | — | — |
| 7 | `submit_gate_evidence` (G-RR) | `SubmitGateEvidenceInput` | 60s | `transient` | — | — |
| 8 | `dispatch_agent_task` (gate-pre-review G-RR) | `AgentTaskInput` | 3h | `transient` | `AGENT_DISPATCH_HEARTBEAT_TIMEOUT`=2min | — (fault-tolerant) |
| 9 | `store_gate_pre_review` (if output) | `StoreGatePreReviewInput` | 30s | `transient` | — | — |
| 10| (patch) `mark_gate_ready_for_review` | `gate_id` | 30s | `transient` | — | — (gated `mark-gate-ready-for-review-v1`, in `finally`) |
| 11| `_wait_for_gate_decision` — NO activity, `wait_condition` | — | — | — | — | — |
| 12| on approve: `reconcile_and_merge_pr` | `MergePRInput` | 60s | `git_merge` (3 attempts, 5–30s) | — | **MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected** |
| 12b| on merge_blocked: `set_gate_merge_blocked` | `[gate_id, detail]` | 30s | `transient` | — | — |
| 13| `dispatch_agent_task` (disposition-recommendation) | `AgentTaskInput` | 3h | `agent_failure` | — | — |
| 14| `write_artifacts_batch` (commit disposition) | … | 120s | `transient` | — | — |
| 15| `dispatch_agent_task` (disposition-governance) | … | 3h | `agent_failure` | — | — |
| 16| `write_artifacts_batch` (commit governance) | … | 120s | `transient` | — | — |
| 17| *(Retire/Replace only)* `dispatch_agent_task` (user-impact) | … | 3h | `agent_failure` | — | — |
| 18| *(Retire/Replace only)* `write_artifacts_batch` (commit user-impact) | … | 120s | `transient` | — | — |
| 19| `dispatch_agent_task` (classification) | … | 3h | `agent_failure` | — | — |
| 20| `write_artifacts_batch` (commit classification) | … | 120s | `transient` | — | — |
| 21| `persist_classification` | `PersistClassificationInput` | 60s | `transient` | — | — |
| 22| *(if tier_1_flag)* `wait_condition` for Tier-1, then `confirm_classification_tier_1` | `ConfirmClassificationInput` | 30s | `transient` | — | — |
| 23| `create_pr` (G-DA) | `CreatePRInput` | 60s | `transient` | — | — |
| 24| `create_gate_record` (G-DA) | `CreateGateRecordInput` | 30s | `transient` | — | — |
| 25| `check_gate_criteria` (G-DA, no risk_tier) | `CheckGateCriteriaInput` | 60s | `transient` | — | — |
| 26| `submit_gate_evidence` (G-DA) | `SubmitGateEvidenceInput` | 60s | `transient` | — | — |
| 27| `dispatch_agent_task` (gate-pre-review G-DA) | `AgentTaskInput` | 3h | `transient` | 2min | — |
| 28| `store_gate_pre_review` (if output) / `mark_gate_ready_for_review` (patch) | … | 30s | `transient` | — | — |
| 29| `_wait_for_gate_decision(G-DA)` — `wait_condition` | — | — | — | — | — |
| 30| *(if patched)* `wait_condition` for `_stakeholder_approved` | — | — | — | — | — |
| 31| on approve: `reconcile_and_merge_pr` (+`set_gate_merge_blocked` loop) | `MergePRInput` | 60s | `git_merge` | — | 3 merge types |
| 32| completion: `update_application_status` | `UpdateAppStatusInput` | 30s | `transient` | — | — |

Notes on `_dispatch_agent` inner activities (base.py):
- `activity_id=f"agent-{step_name}"` (base.py:491) — deterministic per step.
- Patch-gated `load_context_priors` (base.py:453–469): if `workflow.patched("context-priors-v1")`, dispatches `load_context_priors(LoadContextPriorsInput(skill_id))`, 10s, `transient`, best-effort (exception → warn + continue).
- `_commit_step_artifacts` uses `activity_id=f"commit-{step_name}"` (base.py:835). No mirror repo used by this line (mirror args default empty).

---

## 5. GATE HANDLING

### 5a. Evidence assembly
- **G-RR** (rationalization.py:231–271): `grr_artifact_paths = dedup_paths(_step_committed_paths["redundancy-analysis"])`. `_submit_gate_evidence` builds a slim evidence bundle via `_build_evidence_data("Rationalization","redundancy-analysis")` (base.py:1281). G-RR has NO `GATE_THRESHOLDS` entry → bundle stays slim, `check_gate_criteria` gets no inline content. `forward_risk_tier=False` → no `evidence_data`/`risk_tier` on the criteria call (base.py:994–1000).
- **G-DA** (rationalization.py:491–531): `gda_artifact_paths` = concat of committed paths for `disposition-recommendation` + `disposition-governance` + `user-impact` (user-impact only present if it ran), then `dedup_paths`. Same slim/`forward_risk_tier=False` handling.

GOTCHA (evidence bundle content): `_build_evidence_data` iterates `_evidence_steps_iter()` = `STEPS.items()` (base.py:311–318, NOT overridden here — the docstring at base.py:316 says "Rationalization excludes governance" but this class does NOT override `_evidence_steps_iter`, so the bundle DOES include ALL 5 STEPS including governance). Reproduce the base default — do not exclude governance.

### 5b. The wait
`_wait_for_gate_decision(gate_type)` (base.py:1103–1157):
- sets `_status=WAITING_FOR_SIGNAL`, `_pending_gate=gate_type`.
- `consumed = _gate_decisions_consumed` (captured); waits `len(_gate_decisions) > consumed or cancelled`.
- if `cancelled` → `_status=CANCELLED`, return `"cancelled"`.
- reads `entry = _gate_decisions[consumed]`; unpacks 5-tuple (or legacy 3-tuple → reason_category=None, card_decisions=[]); `_gate_decisions_consumed = consumed+1`; clears `_pending_gate`; `_status=RUNNING`.
- APPROVED → `_rework_feedback.pop(gate_key)`, return `"approved"`.
- else → store `_rework_feedback[gate_key] = {gate, rejected_by, reason, reason_category, card_decisions, rejected_at}`, return `"rejected"`.

### 5c. Routing
- **cancelled** → `run`/`_execute_rationalization` returns `"cancelled"` (lines 287, 476, 547, 566); status CANCELLED where set explicitly.
- **approved (G-RR)** → `_reconcile_and_merge_with_retry_loop`, `break`, proceed to Step 3.
- **approved (G-DA)** → if `workflow.patched("gda-dual-signal-v1")`: wait for `_stakeholder_approved` (dual-signal), consume it (set False), then merge, `break` → completion. If patch is OFF (in-flight legacy runs): skip the stakeholder wait entirely and merge directly.
- **merge-blocked** (inside `_reconcile_and_merge_with_retry_loop`, base.py:1159–1279): on `MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected` (unwrapped from `ActivityError.__cause__` to the `ApplicationError.type`) → reset `_merge_retry_signalled=False`, call `set_gate_merge_blocked(gate_id, detail)`, wait `_merge_retry_signalled or cancelled`; on cancel → return (silently); else loop and retry merge. Non-merge `ApplicationError`/non-`ApplicationError` → re-raise (propagates to `run`'s top-level `except` → FAILED).
- **rejected** → rework (see §5d).

### 5d. Rework loops & counters
- Counter: `_rework_iterations[gate_key]` via `_bump_rework` (base.py:1376). Read via `_rework_count`.
- **G-RR rework**: bump `_rework_count("G-RR")`; if `> 3` → FAILED, status `max-rework-exceeded-grr`, return `"failed"`. Else re-dispatch `redundancy-analysis` (with `_rework_feedback["G-RR"]` forwarded), commit, loop → new PR+gate.
- **G-DA rework**: if patched, `_stakeholder_approved=False` (drop stale flag, line 583); bump `_rework_count("G-DA")`; if `> 3` → FAILED, status `max-rework-exceeded-gda`, return `"failed"`. Else re-dispatch `disposition-recommendation` + `disposition-governance` + (`user-impact` if Retire/Replace), commit each, loop → new PR+gate.

GOTCHA (max-rework threshold): condition is `> MAX_REWORK_ITERATIONS` (strict `>`, value 3). So allowed rejections before failure: reject #1,#2,#3 rework; reject #4 → bump makes count 4, `4 > 3` True → fail. i.e. up to 3 reworks tolerated, 4th rejection fails.

GOTCHA (fresh sign-off per G-DA cycle): after a rejection the stakeholder flag is dropped (line 583) so the NEXT approval requires a FRESH `StakeholderApprovedSignal(scope="g-da")` alongside the PM `gate_approved`. Approval also consumes the flag (line 569).

---

## 6. RESILIENCE

- **Timeouts**: agent dispatch 3h (`AGENT_START_TO_CLOSE`, agent_timeouts.py:67); commits 120s; gate-record/status/confirm/store/mark 30s; PR/criteria/evidence 60s; merge 60s; context-priors 10s.
- **Heartbeat**: only the gate-pre-review agent dispatch sets `heartbeat_timeout=AGENT_DISPATCH_HEARTBEAT_TIMEOUT` (2 min, base.py:1069). The main step `dispatch_agent_task` calls set NO heartbeat.
- **Continue-as-new**: NONE. This workflow does not continue-as-new; unbounded gate waits + up to 3 reworks per gate + up to (agents×history) events could grow event history — but no CAN guard exists. Reproduce as-is.
- **Idempotency**: deterministic `activity_id`s (`agent-{step}`, `commit-{step}`, `patch-output-ref-{step}`). Branch/workspace derived deterministically from workflow id. `merge_retry` handler idempotent.
- **Compensation/rollback**: none beyond best-effort `_update_app_status(..., "rationalization_failed", ...)` in `run`'s `except` (line 185, itself wrapped in try/except pass). No artifact rollback; committed artifacts remain on the branch.
- **Determinism**: all time via `_now_iso()`=`workflow.now()`; no random/wall-clock/external I/O in workflow code. Patch IDs used verbatim: `context-priors-v1`, `patch-output-artifact-ref-v1`, `mark-gate-ready-for-review-v1` (base), `gda-dual-signal-v1` (this class, lines 559 & 582).

GOTCHA (patch symmetry): `gda-dual-signal-v1` is checked at BOTH the approve branch (559) and the reject branch (582). A rebuild must gate BOTH with the same patch id — if only one is gated, in-flight pre-patch runs will nondeterministically diverge on replay.

---

## 7. PR BODY BUILDERS (rationalization.py:698–762)

### `_build_grr_pr_body(app_id)` (698–717)
Fixed markdown: `## Gate G-RR Review: Rationalization Review`, app id, "Rationalization Steps Completed" with `- [x] Redundancy Analysis (redundancy-analyzer)`, artifacts `rationalization/{app_id}/redundancy-matrix.json`, review checklist (3 unchecked items). If `_rework_count("G-RR") > 0`: append `\n**Rework iteration:** {n}\n`.

### `_build_gda_pr_body(app_id, disposition)` (719–762)
- `disp_label = _disposition_label(disposition)` (→ value or "TBD").
- Header + `**Recommended Disposition:** {disp_label}`; steps completed list: redundancy, disposition recommendation, governance always `[x]`.
- If `_is_retire_or_replace(disposition)`: `- [x] User Impact Analysis`; ELSE `- [ ] User Impact Analysis (N/A — not Retire/Replace)`.
- Artifacts: disposition-recommendation.json, disposition-governance.json; PLUS user-impact-analysis.json only if Retire/Replace.
- Stakeholder Sign-Off Checklist (4 unchecked) + explicit note: **"Approval requires BOTH: PM merges this PR (`gate_approved` signal) AND stakeholder fires a `StakeholderApprovedSignal` with `scope="g-da"`."**
- If `_rework_count("G-DA") > 0`: append `\n**Rework iteration:** {n}\n`.

---

## 8. Behavioral parity checklist

A rebuild MUST satisfy every assertion:

1. `STEPS`, `STEP_WEIGHTS` (sum 100), `MAX_REWORK_ITERATIONS=3`, and all skill_id/artifact mappings reproduce §0 exactly.
2. Branch = `olympus/rationalization/{app_id}/{run_suffix}` and workspace_key = `rationalization-{app_id}-{run_suffix}`, where `run_suffix` = last `-`-segment of workflow id (else first 8 chars).
3. Happy-path activity order matches §4 (all sequential; no gather; no child workflows).
4. G-RR: exactly one redundancy dispatch + commit before the gate loop; each loop iteration creates a NEW PR + NEW gate_record; evidence uses only redundancy committed paths (deduped); `forward_risk_tier=False`.
5. On G-RR approval: `reconcile_and_merge_with_retry_loop` runs, then Step 3 proceeds. On G-RR rejection: bump G-RR counter, fail with `max-rework-exceeded-grr` + return `"failed"` when count `>3`; else re-dispatch redundancy WITH `rework_feedback["G-RR"]` forwarded and loop.
6. Step 4 governance dispatch keeps `_current_step="recommend-disposition"` (never emits a `disposition-governance` UI step); progress ticks 35.0→53.0 across recommendation→governance.
7. User-impact step (Step 5 and its G-DA rework re-dispatch) runs IFF `_is_retire_or_replace(input.disposition)` (Retire or Replace, tolerant of list-serialized enum). `_set_step("assess-user-impact",61.0)` still fires even when skipped.
8. Classification always dispatched+committed+persisted. `_set_step("classification",73.0)`.
9. Tier-1: if `persist_result.tier_1_flag` True, block on `stakeholder_approved(scope="tier-1-classification")` (→`_tier1_approved_by`) or cancel; on approval call `confirm_classification_tier_1(approved_by=_tier1_approved_by)`. `_current_step="classification-awaiting-tier1-approval"` during wait; progress stays 73.0.
10. G-DA evidence = deduped concat of disposition-recommendation + disposition-governance + user-impact committed paths; `forward_risk_tier=False`.
11. G-DA approval requires BOTH `gate_approved` (PM) AND (when `gda-dual-signal-v1` patched) a `stakeholder_approved` with non-tier-1 scope setting `_stakeholder_approved`; the flag is consumed (set False) after the dual wait, and dropped on rejection. Merge only after both.
12. `gda-dual-signal-v1` gates BOTH the approve-branch stakeholder wait AND the reject-branch flag drop.
13. G-DA rework re-dispatches disposition-recommendation + governance + (user-impact if Retire/Replace) with `rework_feedback["G-DA"]`; fails with `max-rework-exceeded-gda` when G-DA count `>3`.
14. `_rework_gate_key_for_step`: `"redundancy-analysis"`→`"G-RR"`, everything else→`"G-DA"`.
15. Merge-blocked handling: on `MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected`, call `set_gate_merge_blocked` and wait for `merge_retry` signal (`_merge_retry_signalled`) or cancel; retry on signal; `git_merge` policy = 3 attempts, non_retryable for those 3 types.
16. Completion sets status COMPLETED, progress 100.0, current_step "completed", app status `rationalization_complete`, returns `"completed"`.
17. Any unhandled exception → top-level `except`: status FAILED, current_step "failed", best-effort `rationalization_failed` app status, re-raise.
18. `stakeholder_approved` is the ONLY own signal; `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry`/`cancel_workflow`/`get_status` are inherited and MUST NOT be redefined.
19. `_dispositions` dict exists but is never read/written (no behavioral effect).
20. Progress never reflects the `classification`(10) or `gate-review-da`(17) weights as intermediate values; it jumps 73.0→100.0.
