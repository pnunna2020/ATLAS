# WaveRationalizationWorkflow — Atomic Regeneration Spec (Part 3 of 3)

Source: `temporal/olympus_workflows/workflows/wave_rationalization.py`. Continues from Parts 1 & 2.
Covers: the legacy inline Architecture/Data fan-out, gate plumbing helpers, `_project_per_app_side_effects`, the Build pipeline, dispatch payload normalization, remaining helpers, (6) RESILIENCE, (7) GOTCHAs, (8) Behavioral-parity checklist.

---

## Greenfield Build pipeline

### `_build_app_pipeline(app_id, input, repo, branch, workspace_key) -> dict` — `:3657-3799`
Returns the SAME dict shape as `_per_app_pipeline` so downstream merges treat Build apps uniformly.
```
import json                                                                 # :3686
adv_skill = SKILLS["capability-consolidation-advisory"]                     # :3688
req_artifact = _requirements_capability_artifact(app_id)                    # :3689
prefix = f"rationalization/wave-{wave_id}"                                  # :3694
adv_optional = [f"{prefix}/integration-graph.json", f"{prefix}/portfolio-redundancy-matrix.json"]  # :3695-3698 (optional: build-only wave lacks them)
adv_context = _with_fixture_scenario({wave_id, mode:"build", build_app_id:app_id, requirements_capability_artifact:req_artifact}, adv_skill_id, fixture_scenarios)  # :3699-3708
adv_result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type="wave-build-capability-consolidation",
    skill_id="capability-consolidation-advisor", app_id, workspace_key=f"{ws}-{app_id}", repo, branch, context=adv_context,
    input_artifacts=[req_artifact], optional_input_artifacts=adv_optional, ...), start_to_close=AGENT_START_TO_CLOSE, retry=agent_failure)  # :3709-3730
adv_raw = self._primary_output_content(adv_result, "capability-consolidation-plan.json")  # :3731
adv_path = f"{prefix}/{app_id}/capability-consolidation-plan.json"          # :3732
await self._commit_artifact(...); await self._commit_output_files(...)      # :3733-3750
build_rec = self._extract_build_recommendation(adv_raw)                     # :3754
disposition = self._disposition_from_build_recommendation(build_rec)        # :3755
self._build_recommendations[app_id] = build_rec                             # :3756
disp_skill = SKILLS["disposition-recommendation"]                           # :3762
disp_path = f"{prefix}/{app_id}/disposition-recommendation.json"            # :3763
disp_payload = {recommended_disposition:disposition, produced_by:"capability-consolidation-advisor", intake:"build",
    build_recommendation:build_rec, rationale_ref:req_artifact, requirements_capability_artifact:req_artifact}  # :3764-3771
disp_raw = json.dumps(disp_payload, indent=2)                               # :3772
await self._commit_artifact(repo, branch, disp_path, disp_raw, "Wave {id} / {app}: disposition (build → {disposition})")  # :3773-3779
return {app_id, disposition, disposition_path:disp_path, disposition_json:disp_raw, disposition_narrative:self._agent_narrative(adv_result),
    governance_path:"", governance_json:"", governance_narrative:"",
    user_impact_path:"", user_impact_json:"", user_impact_narrative:"",
    build_recommendation:build_rec}                                         # :3781-3799
```
GOTCHA: Build apps run NO governance/user-impact step — those rollup cards render empty. The synthesized `disposition-recommendation.json` is committed at the SAME per-app path as legacy so G-DA evidence / factory routing / post-G-DA projection consume it identically.

### `_extract_build_recommendation(adv_raw) -> dict` (static) — `:3801-3830`
Default `{status:"proceed", confidence:"low", rationale:"", implicated_applications:[], recommended_action:"", alternative_disposition:None}`. Empty/non-dict/no-`build_recommendation` → default. Else `out=dict(default); out.update({k:v for k,v in rec.items() if v is not None})`. Then guard: if `out["status"] not in ("proceed","extend-existing","build-and-consolidate"): out["status"]="proceed"`.

### `_disposition_from_build_recommendation(build_rec) -> str` (static) — `:3832-3847`
```
status = build_rec.get("status","proceed")
if status == "extend-existing":
    alt = build_rec.get("alternative_disposition")
    if alt in ("Refactor","Consolidate"): return alt
    return "Build"
return "Build"
```
So `proceed`/`build-and-consolidate` → `Build`; `extend-existing` → alt (Refactor/Consolidate) or fallback `Build`.

---

## Post-G-DA projection

### `_project_per_app_side_effects(input, classification_results, per_app_results, portfolio_scores) -> None` — `:4467-4524`
Fan-out ONE `persist_rationalization_side_effects` activity per app in parallel:
```
projection_tasks = []
for app_id in input.app_ids:                                               # :4490
    cls = classification_results.get(app_id, {}); disp = per_app_results.get(app_id, {}); score = portfolio_scores.get(app_id, {})  # :4491-4493
    projection_tasks.append(execute_activity(persist_rationalization_side_effects,
        PersistRationalizationSideEffectsInput(app_id,
            classification_json=cls.get("cls_json","") or "",
            portfolio_score_json=score.get("score_json","") or "",
            disposition_recommendation_json=disp.get("disposition_json","") or "",
            disposition_rationale_ref=disp.get("disposition_path","") or "",
            tier_1_approved=app_id in self._tier1_approved_apps),
        start_to_close=60s, retry=transient))                               # :4494-4512
results = await asyncio.gather(*projection_tasks, return_exceptions=True)   # :4514
for app_id, result in zip(input.app_ids, results):
    if isinstance(result, BaseException): log.warning("persist_rationalization_side_effects failed for app", ...)  # :4515-4524
```
GOTCHA: best-effort per app (`return_exceptions=True`) — one malformed artifact can't block the wave. G-DA is the transactional boundary: ALL DB writes happen here, after approval, so rework never leaves half-projected rows (`:4478-4483`). Mid-workflow `persist_classification`/`persist_portfolio_score` writes were retired (W19 PR 3).

---

## Legacy inline Architecture/Data fan-out (patch `wave-rationalization-architecture-dispatch-v1`)

### `_compute_pending_target_dispatch_entries(per_app_results, legacy_entries) -> list[PendingTargetDispatchEntry]` — `:4530-4606`
- `if not workflow.patched("architecture-target-plan-v1"): return []` (`:4555-4556`).
- inner `_resolve_name(app_id)`: reads `per_app_results[app_id].get("app_name") or .get("name") or ""` (str-guarded) (`:4558-4564`).
- For each `entry` in `legacy_entries`: `disposition = entry.disposition or ""`; `relationship_lower = _normalize_relationship(disposition)`.
  - `if disposition == "Retire": continue` (Retire targets never dispatched) (`:4570-4573`).
  - `source_ids = [entry.source_app_id]`; if `disposition == "Consolidate" and entry.peer_source_app_ids:` fold in each peer not already present (`:4574-4582`).
  - `target_repo_slug = f"target/{slug_seed}-{relationship_lower}"` if relationship else `f"target/{slug_seed}"` (`:4589-4593`); `slug_seed = entry.source_app_id`.
  - append `PendingTargetDispatchEntry(target_app_id=f"target-{slug_seed}", target_service_id="", target_name_seed="", target_repo_slug, relationship=relationship_lower, source_app_ids=source_ids, source_app_names, rationale="")` (`:4594-4605`).

### `_compute_pending_dispatch_entries(per_app_results) -> list[PendingDispatchEntry]` — `:4608-4688`
- Pass 1 (`:4633-4648`): find Consolidate anchors. For each `(app_id, result)`, parse `disposition_json` via `parse_agent_json`; if `target_hint.kind == "consolidate-target"`, record `anchor_for_peer[app_id]=(app_id, peers)` and add each peer to `consumed_as_peer` set. Peers = str-filtered `target_hint.peer_app_ids`.
- Pass 2 (`:4650-4687`): for each app, re-parse disposition (`recommended_disposition` or `disposition`), target_hint kind + peers. Then:
  - `if disposition == "Consolidate":` (`:4673`) — `if target_hint_kind == "consolidate-source" or app_id in consumed_as_peer: continue` (skip peer rows) (`:4674-4675`); if kind != "consolidate-target": fall through (emit anyway with empty peers) (`:4676-4679`).
  - append `PendingDispatchEntry(source_app_id=app_id, disposition, target_hint_kind, peer_source_app_ids=peers)` (`:4680-4687`).
GOTCHA: uses `parse_agent_json` (defensive) not `json.loads` — markdown-fenced/preamble agent output still yields a target_hint (Wave-1 failure: strict json.loads dropped ```json-wrapped output and consolidation degraded to per-app rearchitect).

### `_dispatch_key(cfg)` (static) — `:4690-4700`
`return cfg.target_app_id or cfg.source_app_id`. v2 keys by target_app_id (N targets share anchor); v1 by source_app_id.

### `_init_dispatch_status(payload) -> None` — `:4702-4731`
For each `cfg in payload.targets`: `key = cfg.target_app_id or cfg.source_app_id`; `v2_meta = self._v2_dispatch_meta.get(cfg.target_app_id, {})`; `self._dispatch_status[key] = DispatchTargetStatus(source_app_id, target_app_name, target_repo, disposition, status="pending", source_app_ids=[cfg.source_app_id]+list(cfg.peer_source_app_ids or []), target_service_id=v2_meta.get("target_service_id",""))`. GOTCHA (PR #495): keyed by target_app_id when present — pre-fix keyed always by source_app_id, silently overwriting N-1 rows for capability-grain waves.

### `_normalize_dispatch_payload(payload) -> DispatchArchitecturePayload` (static) — `:4733-4836`
- `isinstance(payload, DispatchArchitecturePayload)` → return as-is (`:4756-4757`).
- `isinstance(payload, DispatchArchitecturePayloadV2)` → map each target: `source_app_id=source_app_ids[0] if source_app_ids else ""`, `disposition=_legacy_disposition_from_relationship(t.relationship)`, `default_branch=t.default_branch or "main"`, `peer_source_app_ids=list(source_app_ids[1:])`, `target_app_id=t.target_app_id` (`:4758-4783`).
- `isinstance(payload, dict)`: `raw_targets = payload.get("targets",[])`; if not list → empty (`:4785-4788`). `v2_shape = any(isinstance(t,dict) and "target_app_id" in t for t in raw_targets)` (`:4789-4792`). If v2: build each `DispatchArchitectureTargetConfig` from dict fields (source from `source_app_ids[0]`, disposition via `_legacy_disposition_from_relationship`, default_branch or "main", peers `src_ids[1:]`) (`:4793-4822`). Else v1 wire shape: `DispatchArchitectureTargetConfig(**t)` if dict else t (`:4823-4833`).
- Unknown → `DispatchArchitecturePayload(targets=[])` (short-circuits fanout to "completed") (`:4834-4836`).

### `_provision_one_target(cfg, input) -> CreateTargetAppAndRepoResult` — `:4838-4879`
Sets status[key].status="provisioning" (`:4854`). `full_source_ids = [cfg.source_app_id] + list(cfg.peer_source_app_ids or [])`. Resolve `target_service_id` from dispatch status (v2) else "". Execute `create_target_app_and_repo` with `CreateTargetAppAndRepoInput(source_app_id, target_app_name, target_repo, default_branch, wave_id, portfolio_id, disposition, peer_source_app_ids, source_app_ids=full_source_ids, target_service_id)`, `start_to_close=5min`, `retry=transient` (`:4863-4879`). GOTCHA: raising bubbles to caller's `asyncio.gather(return_exceptions=True)` for per-entry failure recording.

### `_spawn_children_for_target(cfg, provisioned, input, run_ts) -> (arch_handle, data_handle)` — `:4881-5068`
```
target_app_id = provisioned.target_app_id
arch_workflow_id = f"architecture-{target_app_id}-{run_ts}"; data_workflow_id = f"data-{target_app_id}-{run_ts}"  # :4893-4895
v2_meta = self._v2_dispatch_meta.get(cfg.target_app_id, {})
relationship = _normalize_relationship(v2_meta.get("relationship")) or _normalize_relationship(cfg.disposition)  # :4907-4911
target_service_id = (status.target_service_id if status else "") or v2_meta.get("target_service_id","")  # :4912-4916
full_source_ids = list(status.source_app_ids) if status and status.source_app_ids else [cfg.source_app_id]+list(cfg.peer_source_app_ids or [])  # :4917-4920
source_repos_result = await execute_activity(fetch_application_source_repos, FetchSourceReposInput(source_app_ids=list(full_source_ids)), 30s, transient, activity_id=f"fetch-source-repos-{target_app_id}")  # :4934-4940
anchor_source_repo = source_repos_result.anchor_source_repo; source_repos_map = dict(source_repos_result.source_repos)  # :4941-4942
if not anchor_source_repo: log.warning("no source_repo resolved for anchor source app", ...)  # :4943-4953
peer_ids = {"Data": data_workflow_id}                                       # :4955
arch_input = LineWorkflowInput(app_id=target_app_id, app_name=cfg.target_app_name or target_app_id, wave_id, portfolio_id,
    artifact_repo, source_repo=anchor_source_repo, source_repos=source_repos_map, target_repo_url=provisioned.target_repo_url,
    disposition=None, peer_workflow_ids=peer_ids, target_service_id, relationship, source_app_ids=list(full_source_ids))  # :4956-4970
data_prior = []
if workflow.patched("discovery-data-steps-v1"):                            # :4980
    for src in [cfg.source_app_id]+list(cfg.peer_source_app_ids or []):
        if not src: continue
        data_prior += [f"discovery/{src}/data-domains.json", f"discovery/{src}/shared-db-analysis.json"]  # :4981-4986
data_input = LineWorkflowInput(app_id=target_app_id, ..., disposition=None, peer_workflow_ids={"Architecture":arch_workflow_id}, prior_artifacts=data_prior, ...)  # :4987-5002
if workflow.patched("arch-data-sibling-lifecycle-v1"):                     # :5014
    arch_handle = await start_child_workflow("ArchitectureWorkflow", arch_input, id=arch_workflow_id, parent_close_policy=ABANDON)  # :5015-5020
    data_handle = await start_child_workflow("DataWorkflow", data_input, id=data_workflow_id, parent_close_policy=ABANDON)  # :5021-5026
else:
    arch_handle = await start_child_workflow("ArchitectureWorkflow", arch_input, id=arch_workflow_id)  # :5028-5032
    data_handle = await start_child_workflow("DataWorkflow", data_input, id=data_workflow_id)  # :5033-5037
try: await execute_activity(update_application_line_projection, UpdateApplicationLineProjectionInput(app_id=target_app_id, line="Architecture", workflow_id=arch_workflow_id, status="in_progress"), 30s, transient)  # :5042-5053
except Exception as exc: log.warning("update_application_line_projection failed (Architecture)", ...)  # :5054-5061
status = self._dispatch_status[self._dispatch_key(cfg)]
status.target_app_id = target_app_id; status.architecture_workflow_id = arch_workflow_id; status.data_workflow_id = data_workflow_id; status.status = "architecture_in_flight"  # :5063-5067
return arch_handle, data_handle                                            # :5068
```
GOTCHA: `disposition=None` on both LineWorkflowInputs — Architecture resolves it from the DB on start (`:4965, 4996`). `relationship` always canonicalized. `run_ts` is deterministic (`workflow.now().timestamp()`).

### `_update_wave_status_safe(new_status, reason="") -> None` — `:5070-5097`
`if not self._wave_id: return`. Execute `update_wave_status` (30s, transient); on Exception log warning (best-effort, never raises).

### `_execute_architecture_data_fanout(input, per_app_results) -> str` — `:5099-5294`
```
self._current_step = "awaiting-architecture-dispatch"                       # :5112
self._pending_dispatch_entries = self._compute_pending_dispatch_entries(per_app_results)  # :5113-5115
self._pending_target_dispatch_entries = self._compute_pending_target_dispatch_entries(per_app_results, self._pending_dispatch_entries)  # :5120-5124
await self._update_wave_status_safe("awaiting-architecture-dispatch")      # :5125-5127
await workflow.wait_condition(lambda: self._dispatch_received or self.cancelled)  # :5131-5133
if self.cancelled: return "cancelled"                                      # :5134-5135
payload = self._dispatch_payload
if payload is None or not payload.targets: await self._update_wave_status_safe("completed"); return "completed"  # :5136-5141  (empty = 100% Retire)
self._init_dispatch_status(payload)                                        # :5143
run_ts = int(workflow.now().timestamp())                                   # :5147

# Phase 1 — provision in parallel
provision_futures = [self._provision_one_target(cfg, input) for cfg in payload.targets]  # :5152-5154
provisioned_results = await asyncio.gather(*provision_futures, return_exceptions=True)  # :5155-5157
child_handles = []
for cfg, result in zip(payload.targets, provisioned_results):              # :5160
    status = self._dispatch_status[self._dispatch_key(cfg)]
    if isinstance(result, BaseException): status.status="failed"; status.error=repr(result); log.warning(...); continue  # :5162-5172
    status.status = "provisioned"                                          # :5174
    try: arch_handle, data_handle = await self._spawn_children_for_target(cfg, result, input, run_ts); child_handles += [arch_handle, data_handle]  # :5175-5179
    except Exception as exc: status.status="failed"; status.error=f"spawn_children: {exc!r}"; log.warning(...)  # :5180-5189

await self._drain_retry_queue(input, run_ts, child_handles)                # :5195

if any(s.status == "architecture_in_flight" for s in self._dispatch_status.values()): await self._update_wave_status_safe("architecture-in-flight")  # :5197-5200
elif not child_handles:                                                     # :5201  every target failed to provision
    error_reasons = [s.error for s in self._dispatch_status.values() if s.error]
    reason_summary = "; ".join(error_reasons)[:500] if error_reasons else "every target failed to provision in create_target_app_and_repo"  # :5212-5220
    await self._update_wave_status_safe("stuck-awaiting-recovery", reason=f"dispatch_architecture: {reason_summary}")  # :5221-5224
    return "stuck-awaiting-recovery"                                       # :5225

if workflow.patched("arch-data-sibling-lifecycle-v1"):                     # :5233  siblings outlive parent
    await self._update_wave_status_safe("architecture-dispatched"); return "dispatched"  # :5234-5235

# Phase 2 — wait for every child (only reached when NOT sibling-lifecycle)
child_results = await asyncio.gather(*[h.result() for h in child_handles], return_exceptions=True)  # :5240-5242
idx = 0
for cfg in payload.targets:                                                # :5248
    status = self._dispatch_status[self._dispatch_key(cfg)]
    if status.status == "failed": continue                                 # :5250-5251
    if idx + 1 >= len(child_results): break                                # :5252-5253
    arch_result = child_results[idx]; data_result = child_results[idx+1]; idx += 2  # :5254-5256
    arch_ok = not isinstance(arch_result, BaseException); data_ok = not isinstance(data_result, BaseException)  # :5257-5258
    if arch_ok and data_ok: status.status = "completed"                    # :5259-5260
    else: status.status = "failed"; status.error = "; ".join([f"arch: {arch_result!r}" if not arch_ok, f"data: {data_result!r}" if not data_ok])  # :5261-5268
any_failed = any(s.status == "failed" for s in self._dispatch_status.values())  # :5270-5272
if any_failed:                                                             # :5273
    failed_targets = [s.target_app_id or s.target_app_name or "<unknown>" for s in ... if s.status=="failed"]  # :5278-5282
    reason = (f"one or more target workflows failed: {', '.join(...)}" )[:500]  # :5283-5286
    await self._update_wave_status_safe("stuck-awaiting-recovery", reason); return "stuck-awaiting-recovery"  # :5287-5291
await self._update_wave_status_safe("completed"); return "completed"       # :5293-5294
```
GOTCHA (`:5244-5256`): child_handles is `[arch, data, arch, data, ...]` in target-append order; attribution walks it in pairs, skipping already-failed targets. GOTCHA: partial failures do NOT cascade — successful children run to completion; failed ones surface in `dispatch_results` for UI retry.

### `_drain_retry_queue(input, run_ts, child_handles) -> None` — `:5296-5365`
```
while self._pending_retries:                                               # :5311
    retry = self._pending_retries.pop(0)                                   # :5312  (FIFO, sequential)
    status = self._dispatch_status.get(retry.source_app_id)                # :5319  (v1-keyed only)
    if status is None: log.warning("retry_target_dispatch for unknown source_app_id", ...); continue  # :5320-5325
    orig_cfg = None
    if self._dispatch_payload is not None:
        for cfg in self._dispatch_payload.targets:
            if cfg.source_app_id == retry.source_app_id: orig_cfg = cfg; break  # :5329-5334
    if orig_cfg is None: status.status="failed"; status.error="retry: original dispatch entry missing"; continue  # :5335-5338
    retried_cfg = DispatchArchitectureTargetConfig(source_app_id=retry.source_app_id, target_app_name=retry.target_app_name,
        target_repo=retry.target_repo, disposition=orig_cfg.disposition,
        default_branch=retry.default_branch or orig_cfg.default_branch, peer_source_app_ids=list(orig_cfg.peer_source_app_ids))  # :5339-5346
    status.target_app_name = retry.target_app_name; status.target_repo = retry.target_repo; status.status="provisioning"; status.error=""  # :5347-5350
    try: provisioned = await self._provision_one_target(retried_cfg, input)  # :5351-5352
    except Exception as exc: status.status="failed"; status.error=repr(exc); continue  # :5353-5356
    status.status = "provisioned"
    try: arch_handle, data_handle = await self._spawn_children_for_target(retried_cfg, provisioned, input, run_ts); child_handles += [arch_handle, data_handle]  # :5358-5362
    except Exception as exc: status.status="failed"; status.error=f"spawn_children: {exc!r}"  # :5363-5365
```
GOTCHA: retries are v1-only (keyed by source_app_id) — a known v2 gap (`:5313-5318`). Reuses disposition + peer set from original dispatch row; only name/repo/branch are user-editable.

---

## Gate plumbing & remaining helpers

### `_execution_ctx(step_id, *, app_id="", gate_id="", input_artifact_paths=None) -> StepExecutionContext|None` — `:5371-5396`
`if not self._portfolio_id: return None`. Else `StepExecutionContext(portfolio_id, line_id="rationalization", step_id, app_id, wave_id=self._wave_id, gate_id, input_artifact_paths=list(...or []))`. Inlined (not inherited from base).

### `_validate_artifact_or_warn(*, artifact_filename, raw_content, wave_id, app_id="") -> None` — `:5398-5472`
```
if not raw_content: return                                                 # :5423-5424
try: result = await execute_activity(validate_artifact_against_schema, ValidateArtifactInput(artifact_filename, raw_content), 30s, transient)  # :5425-5434
except ActivityError as exc: log.warning("... schema validation skipped ...", reason="validator-unavailable"); return  # :5435-5449  (advisory MUST never take down workflow)
if not result.errors: return                                               # :5450-5451
warning_key = app_id or f"wave-{wave_id}"                                   # :5452
if result.validated: log.warning("... schema validation failed")           # :5460-5464
else: log.warning("... could not be parsed")                               # :5465-5469
self._validation_warnings.setdefault(warning_key, []).extend(result.errors)  # :5470-5472
```
Advisory only — never blocks. Unregistered artifacts return `validated=False, errors=[]` (no-op).

### `_agent_narrative(result) -> str` (static) — `:5474-5496`
`result is None → ""`; `artifacts = getattr(result,"output_artifacts",None) or []`; empty → ""; else `artifacts[0] or ""`.

### `_primary_output_content(result, primary_filename) -> str` (static) — `:5498-5552`
`result is None → ""`. Iterate `result.output_files` (dict OR dataclass); match `raw_path.rsplit("/",1)[-1] == primary_filename` → return that file's content (`:5531-5544`). Fallback: `output_artifacts[0] or ""` when workspace file absent; else "" (`:5549-5552`). GOTCHA (`:5518-5527`): the CORE fix — commit the workspace JSON (output_files), NOT the agent's prose narrative (output_artifacts[0]). Every per-app commit reads this; committing prose broke downstream schema-consumers and the tier-1 detection.

### `_primary_output_is_empty(raw) -> bool` (static) — `:5554-5588`
`import json`. `if not raw or not raw.strip(): return True`. `try: parsed = json.loads(raw)` except `(ValueError,TypeError): return True` (prose = empty for a contractually-JSON artifact). `parsed is None → True`. `isinstance(parsed,(dict,list)) and len==0 → True`. Else False. Backs the PRA non-empty hard-fail guard.

### `_commit_artifact(repo, branch, path, content, message, *, step_id="commit-redundancy-artifacts", app_id="") -> None` — `:5590-5633`
```
if workflow.patched("wave-rationalization-batch-writes-v1"):               # :5601
    await execute_activity(write_artifacts_batch, WriteArtifactsBatchInput(repo, branch, files=[(path, content or "{}")], commit_message=message, execution_context=...), start_to_close=120s, retry=transient)  # :5602-5616
else:
    await execute_activity(write_artifact, WriteArtifactInput(repo, branch, path, content or "{}", commit_message=message, execution_context=...), start_to_close=60s, retry=transient)  # :5618-5633
```
GOTCHA: `content or "{}"` — empty content defaults to `{}`.

### `_commit_output_files(repo, branch, result, *, primary_path, wave_id, app_id="", step_id=..., commit_message_prefix) -> None` — `:5635-5709`
`if not result or not result.output_files: return`. `wave_prefix = f"rationalization/wave-{wave_id}"`. For each output_file (dict or dataclass): skip if no path or no content. Path normalization: startswith wave_prefix → as-is; no "/" (bare filename) → `{wave_prefix}/{app_id}/{name}` if app_id else `{wave_prefix}/{name}`; else as-is (`:5681-5690`). Skip if `final_path == primary_path` (caller handled it). `try: _commit_artifact(...)` except → log warning, swallow (non-fatal companion) (`:5694-5709`).

### `_open_gate_pr(repo, branch, input, gate, title, body)` — `:5711-5734`
Execute `create_pr` with `CreatePRInput(repo, source_branch=branch, target_branch="main", title, body, execution_context=_execution_ctx(f"create-{gate.lower()}-pr"))`, 60s, transient.

### `_build_grr_body(input) -> str` — `:5736-5771`
Markdown listing wave-scoped artifacts + per-app intra-app-redundancy paths + a review checklist; appends `**Rework iteration:** {n}` if `_rework_iterations_grr`.

### `_build_gda_body(input, per_app) -> str` — `:5773-5811`
Markdown listing per-app dispositions (`- \`{app_id}\` → **{disp or "(pending)"}**`), wave-scoped artifacts, stakeholder sign-off checklist, and the dual-signal requirement note; appends rework iteration if `_rework_iterations_gda`.

### `_build_scoring_methodology(input, portfolio_scores) -> str` — `:5813-5863`
Markdown digest: per-app overall readiness table (`overall_str = f"{overall:.1f}"` if numeric else "—"; `dims_str = len(dims)` else "—") + interpretation anchors.

### `_build_factory_routing(input, per_app) -> str` — `:5865-5927`
See Part 2. `import json`. Buckets: modernization (Refactor/Rearchitect/Replace/Replatform), build (Build), disposition_execution (Retire/Consolidate), retain (Retain), else unknown. Returns `json.dumps(payload, indent=2)` with routes + summary counts + `generated_at`.

### `_set_step(step, progress) -> None` — `:5933-5936`
`self._current_step = step`; `self._progress_pct = max(0.0, min(100.0, progress))`; touch `_updated_at`.

### `_wait_for_gate(gate_key) -> str` — `:5938-6013`  (GATE CORE)
```
self._pending_gate = GateType(gate_key) if gate_key in GateType._value2member_map_ else None  # :5944
self._status = WAITING_FOR_SIGNAL; touch _updated_at                       # :5945-5946
self._gate_decisions.setdefault(gate_key, []); self._gate_decisions_consumed.setdefault(gate_key, 0)  # :5948-5949
consumed = self._gate_decisions_consumed[gate_key]                         # :5950
await workflow.wait_condition(lambda: len(self._gate_decisions[gate_key]) > consumed or self.cancelled)  # :5952-5954
if self.cancelled: self._status = CANCELLED; return "cancelled"            # :5955-5958
entry = self._gate_decisions[gate_key][consumed]                           # :5959
if len(entry) == 5: decision, actor, reason, reason_category, card_decisions = entry  # :5963-5964
else: decision, actor, reason = entry[0..2]; reason_category=None; card_decisions=[]  # :5965-5968  (legacy 3-tuple)
self._gate_decisions_consumed[gate_key] = consumed + 1                     # :5969
self._pending_gate = None; self._status = RUNNING; touch _updated_at       # :5970-5972
if decision == GateStatus.APPROVED:                                        # :5973
    self._rework_feedback.pop(gate_key, None)                              # :5974
    stripped_reason = (reason or "").strip()
    if stripped_reason: self._approval_feedback[gate_key] = {gate, approved_by:actor, guidance:stripped_reason, approved_at}  # :5981-5987
    else: self._approval_feedback.pop(gate_key, None)                      # :5988-5989
    return "approved"                                                      # :5990
# rejection
self._approval_feedback.pop(gate_key, None)                                # :5995
rework_targets = rework_targets_from_card_decisions(card_decisions)        # :6003
self._rework_feedback[gate_key] = {gate, rejected_by:actor, reason, reason_category, card_decisions, rework_targets, rejected_at}  # :6004-6012
return "rejected"                                                          # :6013
```
GOTCHA: per-gate consume counters (`_gate_decisions_consumed`) let G-RR & G-DA land independently. Approve-with-guidance stashes non-empty justification; rejection clears any prior approval-guidance (walked-back steer).

### `_merge_capability_lineage_row_rework(gate_id) -> None` — `:6015-6102`
```
if not gate_id: return                                                     # :6044-6045
try: result = await execute_activity(fetch_gate_capability_lineage_rework, FetchGateCapabilityLineageReworkInput(gate_id), 30s, transient, activity_id=f"fetch-capability-lineage-rework-{gate_id}-iter-{self._rework_iterations_gda}")  # :6046-6056
except Exception as exc: log.warning(...); return                          # :6057-6063  (best-effort)
if not result.rejected_rows: return                                        # :6064-6068  (fall back to free-text feedback)
existing = self._rework_feedback.get("G-DA") or {}; merged = dict(existing)  # :6075-6076
merged["row_rework"] = [{lineage_id, feedback, source_capability, target_capability, source_system, target_system, relationship} for r in result.rejected_rows]  # :6077-6088
merged["row_rework_summary"] = {ratified_count, rejected_count}            # :6089-6092
self._rework_feedback["G-DA"] = merged                                     # :6093
log.info("capability_lineage_row_rework_merged", ...)                      # :6094-6102
```
Idempotent (read-only + replaces `row_rework` slot). Merges structured row-level rejections alongside the free-text feedback (doesn't overwrite existing keys).

### `_run_gate_pre_review(gate_id, gate_type_value, evidence_paths, *, artifact_repo="", artifact_ref="", optional_evidence_paths=None) -> None` — `:6104-6218`
```
pre_review_context = {gate_id, gate_type: gate_type_value}                  # :6157-6160
if gate_type_value == "G-DA":                                              # :6161
    pre_review_context["tier1_approvals"] = [self._tier1_approval_records[a] for a in sorted(self._tier1_approval_records)]  # :6162-6165
    pre_review_context["downstream_artifact_kinds"] = [disposition-recommendation, disposition-governance, user-impact-analysis, classification, portfolio-score]  # :6168-6174
try:
    pre_review_result = await execute_activity(dispatch_agent_task, AgentTaskInput(skill_id="gate-pre-review", app_id="", wave_id=self._wave_id,
        task_type="gate-pre-review", input_artifacts=evidence_paths, optional_input_artifacts=list(optional_evidence_paths or []),
        artifact_repo, artifact_ref, context=pre_review_context, execution_context=_execution_ctx(f"ai-pre-review-{gate_type_value.lower()}", gate_id, ...)),
        start_to_close=10min, retry=transient)                             # :6176-6196
    agent_markdown = pre_review_result.output_artifacts[0] if pre_review_result.output_artifacts else ""  # :6197-6201
    if not agent_markdown: raise ValueError("Gate pre-review produced no output")  # :6202-6203
    await execute_activity(store_gate_pre_review, StoreGatePreReviewInput(gate_id, agent_output=agent_markdown), 30s, transient)  # :6204-6212
except Exception: log.warning(f"Gate pre-review failed for {gate_type_value}; continuing without AI recommendation", ...)  # :6213-6218
```
Best-effort — any exception logged & swallowed; caller still flips gate to ready_for_review. GOTCHA: `optional_evidence_paths` prevents `shared-identity-report.json` from raising FileNotFoundError and leaving an empty AI panel.

### `_reconcile_and_merge_with_retry_loop(*, repo, pr_number, gate_id, merge_method="merge") -> None` — `:6220-6295`  (GATE MERGE)
```
merge_failure_types = {MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected}  # :6234-6238
merge_ctx = self._execution_ctx(f"merge-pr-{pr_number}", gate_id=gate_id)  # :6240-6243
while True:                                                                 # :6244
    try:
        await execute_activity(reconcile_and_merge_pr, MergePRInput(repo, pr_number, merge_method, execution_context=merge_ctx), start_to_close=60s, retry=git_merge)  # :6246-6256
        return                                                              # :6257
    except (ActivityError, ApplicationError) as outer_exc:                 # :6258
        inner = outer_exc
        while not isinstance(inner, ApplicationError) and inner.__cause__ is not None: inner = inner.__cause__  # :6260-6264
        if not isinstance(inner, ApplicationError): raise                  # :6265-6266
        failure_type = inner.type or ""                                     # :6267
        if failure_type not in merge_failure_types: raise                  # :6268-6269
        detail = {failure_type, reason:str(inner), pr_number, detected_at:_now_iso()}  # :6270-6275
        log.warning("merge_blocked", ...)                                  # :6276-6283
        self._merge_retry_signalled = False                                # :6284
        await execute_activity(set_gate_merge_blocked, args=[gate_id, detail], 30s, transient)  # :6285-6290
        await workflow.wait_condition(lambda: self._merge_retry_signalled or self.cancelled)  # :6291-6293
        if self.cancelled: return                                          # :6294-6295
        # loop: retry the merge after reviewer's merge_retry signal
```
GOTCHA: only the 3 structured merge-failure types route into merge_blocked (they're `non_retryable_error_types` on `git_merge` policy so Temporal doesn't retry them). Any other error re-raises (propagates to `run()` FAILED handler). The reviewer's `merge_retry` signal re-enters the merge activity.

### `_register_gate_key(gate_id, gate_key) -> None` — `:6307-6323`
`self._gate_id_to_key[gate_id] = gate_key`; `pending = self._pending_signals_by_gate_id.pop(gate_id, [])`; if pending: `self._gate_decisions.setdefault(gate_key, []).extend(pending)`; touch `_updated_at`. Flushes buffered signals into the decision queue in arrival order.

---

## 6. RESILIENCE

- **Timeouts:** agent dispatches use `start_to_close=AGENT_START_TO_CLOSE (3h)` + `timeout_seconds=AGENT_HTTP_READ_TIMEOUT_SECONDS (180min)` inside the AgentTaskInput. Gate/DB activities: 30s or 60s. `create_target_app_and_repo`: 5min. batch commit: 120s. pre-review: 10min. No heartbeats declared in the workflow (heartbeating, if any, lives in the activities).
- **Continue-as-new:** NONE. This workflow never calls `continue_as_new` despite its length — a single run holds all gate loops and fan-outs. GOTCHA: the human-in-the-loop waits (G-RR, G-DA, tier-1 pauses, merge_blocked, architecture dispatch) can hold the run open indefinitely; there is no history-size mitigation via continue-as-new.
- **Idempotency:** deterministic child IDs (`architecture-{target}-{run_ts}`, `data-{target}-{run_ts}`, `wave-architecture-{wave_id}`) and deterministic `activity_id`s on the rat-cap/grain/fetch-repos/coordinator persists make retries idempotent. `run_ts = int(workflow.now().timestamp())` is replay-deterministic. rat-cap persist is UPSERT-by-uuid (stable across rework via `existing_id`).
- **Patch guards (determinism):** `wave-rationalization-greenfield-build-v1`, `-greenfield-only-skip-v1`, `-portfolio-synthesis-v1`, `-cross-app-br-analyzer-v1`, `-rat-cap-clustering-v1`, `-pim-before-pra-v1`, `-pra-nonempty-v1`, `-ratcap-persist-readback-v1`, `-grr-rework-pra-v1`, `-gate-pre-review-v1`, `-batch-writes-v1`, `-architecture-dispatch-v1`, `wave-arch-coordinator-v1`, `arch-data-sibling-lifecycle-v1`, `architecture-target-plan-v1`, `discovery-data-steps-v1`, `tier1-classification-summary-v1`. Every one must be honored EXACTLY so in-flight pre-patch replays take the historical branch.
- **Compensation/rollback:** NONE mid-flow. G-DA is the transactional boundary — all `application`-row projections happen post-approval in `_project_per_app_side_effects` so rework never leaves half-projected DB state. On outer exception, `run()` classifies failure and flips the wave to `stuck-awaiting-recovery` (recoverable activities, artifacts intact) or `failed` (terminal, artifacts may be invalid) — no automatic undo of committed artifacts.
- **Cancellation:** every blocking `wait_condition` ORs `self.cancelled`; returns "cancelled" (or, in tier-1 pause, RAISES). `cancel_all_children` flips status + best-effort cancels child handles (currently no-op since the handle list is unpopulated).

## 7. Additional GOTCHAs (cross-cutting)
- **Legacy-vs-input app scope:** cross-app/UX/intra/PIM/PRA/business-rule passes operate over `self._legacy_app_ids`; per-app fan-out, classification, scoring, wave-plan, factory-routing, G-DA evidence iterate `input.app_ids` (legacy + build). Mixing these lists silently drops or double-counts apps.
- **`skip_legacy_synthesis` threading:** pure-greenfield waves skip ALL legacy passes, don't commit matrix/ux, and omit them from every gate-evidence path list (else the gate service 404s on missing artifacts). The build-advisory evidence carries the gate instead.
- **G-DA rework re-runs ONLY `_per_app_pipeline`** — not classification/scoring/wave-plan/redundancy. Downstream `classification_results`/`portfolio_scores` used at synthesis are the pre-rework versions.
- **Tier-1 pause is per-app inside the classify fan-out** — the whole classify gather can't complete until every tier-1 app is signed off (or cancelled). Each waits on its own `app_id`.
- **`_extract_v2_metadata` keyed by target_app_id** (PR #495) — keying by source anchor broke capability-grain (N targets share an anchor); last write wins with wrong target_service_id.
- **`content or "{}"` default in `_commit_artifact`** — an empty primary output commits `{}`, which is why the PRA non-empty guard exists upstream (to fail loud instead of poisoning the fan-out).

## 8. Behavioral parity checklist
A rebuild MUST satisfy all of:
1. Empty `input.app_ids` → `run()` raises `ValueError` before any activity.
2. `branch` = `olympus/rationalization/wave-{wave_id}/{run_suffix}`; `workspace_key` = `wave-rationalization-{wave_id}-{run_suffix}`; suffix = last `-`-segment of workflow_id else first 8 chars.
3. On any `_execute` exception: FAILED status; `classify_failure` walks the cause chain (RECOVERABLE set → `stuck-awaiting-recovery` via persist_wave_failure THEN update_wave_status; else `failed` via persist_wave_failure alone); original exc always re-raised; secondary persist failure swallowed.
4. Sequence 1: cross-app + UX awaited via one `asyncio.gather`; intra-app fanned out over legacy apps via a second `asyncio.gather`. On `skip_legacy_synthesis`: both cross/ux coroutines `.close()`d, results None, no matrix/ux commit.
5. Sequence 2 gated on `do_portfolio_synthesis`; PIM before PRA when `pim-before-pra-v1` (PRA reads PIM's committed integration-graph); business-rule only when `cross-app-br-analyzer-v1`; empty PRA raises `EmptyPortfolioRedundancyPlan` (non-retryable) only when `pra-nonempty-v1`.
6. rat-cap: load grain once, thread into PRA context, persist after commit; zero-persist detection adds a validation warning (when `ratcap-persist-readback-v1`); disposition persist is idempotent UPDATE-by-id.
7. G-RR loop: open PR → create_gate_record → register key (flush buffered signals) → submit evidence (steps + validation_warnings) → optional pre-review → mark ready → wait. Approve → merge-retry-loop → break. Reject → increment counter, fail if >3, scope rework to `rework_targets` (skip cross-app/PRA when card boundary excludes them), re-dispatch, loop.
8. Per-app routing: Build apps → `_build_app_pipeline` (advisor → build_recommendation → disposition Build/Refactor/Consolidate); legacy → `_per_app_pipeline` (disposition → governance → user-impact ONLY on Retire/Replace). Both return identical dict keys.
9. Classification fan-out pauses per Tier-1 app (`_classification_is_tier_1`) on `wait_condition(app_id in _tier1_approved_apps or cancelled)`; cancellation RAISES; `pending_tier1_classification` query populated/cleared under `tier1-classification-summary-v1`.
10. `_compute_overall_readiness`: equal-weight mean over the 6 dims, null-scored dims present-but-excluded from denom, values clamped [0,100], 2-dp; None when count 0. `dimensions` sorted.
11. G-DA loop: dual-signal — `gate_approved` drives `_wait_for_gate`→approved, THEN separate `wait_condition(_stakeholder_approved or cancelled)`; flag consumed on success; merge-retry-loop; post-G-DA `_project_per_app_side_effects` (parallel, best-effort). Reject → reset flag, increment (fail if >3), merge row-rework, re-run `_per_app_pipeline(rework=True)` for ALL apps in parallel, loop.
12. `_wait_for_gate` uses per-gate consume counters; 5-tuple entries (fallback 3-tuple); approve stashes non-empty justification into `_approval_feedback`; reject computes `rework_targets_from_card_decisions` into `_rework_feedback`.
13. Signal buffering: `gate_approved`/`gate_rejected` route by `_gate_id_to_key` UUID lookup, buffer into `_pending_signals_by_gate_id` on miss; `_register_gate_key` flushes in arrival order.
14. `stakeholder_approved`: scope `tier-1-classification` parses `tier1-{app_id}-{n}` and adds to `_tier1_approved_apps` + records; else sets `_stakeholder_approved`.
15. `_primary_output_content` commits the workspace file (output_files by basename) not the narrative; falls back to output_artifacts[0]; `_commit_artifact` defaults empty→`{}`.
16. `_reconcile_and_merge_with_retry_loop`: only the 3 structured merge failures route to `set_gate_merge_blocked` + wait for `merge_retry`; all other errors re-raise.
17. Terminal: `wave-arch-coordinator-v1` → start ABANDON `WaveArchitectureWorkflow` (`wave-architecture-{wave_id}`), persist id (best-effort), COMPLETED, return `architecture-coordinator-started`/`-start-failed`. Else `architecture-dispatch-v1` → inline fanout (completed/dispatched→COMPLETED, stuck-awaiting-recovery→FAILED). Else COMPLETED "completed".
18. Inline fanout: normalize v1/v2 payload; init status keyed by `target_app_id or source_app_id`; provision in parallel (return_exceptions); spawn arch+data children (ABANDON under sibling-lifecycle); drain retries sequentially; all-provision-fail → stuck-awaiting-recovery; sibling-lifecycle → return "dispatched"; else await children, attribute pair-wise, any failure → stuck-awaiting-recovery.
19. `factory-routing.json` bucketing: Refactor/Rearchitect/Replace/Replatform→modernization, Build→build, Retire/Consolidate→disposition_execution, Retain→retain, else unknown.
20. `STEP_WEIGHTS` sum to 100 (module assert); progress accumulators at each `_set_step` match the documented sums exactly.
21. Every agent dispatch context passes through `_with_fixture_scenario`; PRA + disposition contexts additionally `await _with_context_priors`.
22. All patch guards honored so pre-patch histories replay on their original branches.
