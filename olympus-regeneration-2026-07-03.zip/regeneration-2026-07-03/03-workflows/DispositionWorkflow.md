# DispositionWorkflow — Atomic Regeneration Spec

**Source:** `temporal/olympus_workflows/workflows/disposition.py` (1–1814)
**Base class:** `LineWorkflowBase` (`temporal/olympus_workflows/workflows/base.py`) — see `_base-workflow.md` for inherited helpers. This doc fully captures every override and the `run()`/`_execute()` body.
**Decorator:** `@workflow.defn` (`disposition.py:221`).
**Purpose:** Per-application workflow for the Disposition Execution assembly line. Executes the five *non-modernization* dispositions — **Retire, Retain, Replace, Replatform, Consolidate** — through gates **G-DE-1** (plan approval) and, for all but Retain, **G-DE-2** (decommission readiness). Refactor/Rearchitect are rejected (they run through `ModernizationWorkflow`). (`disposition.py:1-14`, `221-233`)

The workflow's shape is the canonical **12 named steps** codified in `specifications/phase-5/assembly-line-contracts/disposition.md` (`disposition.py:172-205`): per-disposition agent steps + `bundle-pre-gate-evidence` → `create-g-de1-pr` → `ai-pre-review-de1` → `gate-review-de1` → `merge-g-de1-pr` → `bundle-post-gate-evidence` → `create-g-de2-pr` → `ai-pre-review-de2` → `gate-review-de2` → `merge-g-de2-pr` → `persist-disposition-side-effects`.

---

## Module-level constants (import-time)

| Constant | Value | Cite |
|---|---|---|
| `DispositionSpec` | alias of `DispositionStrategy` | `disposition.py:151` |
| `RETIRE_SPEC` / `RETAIN_SPEC` / `REPLACE_SPEC` / `REPLATFORM_SPEC` / `CONSOLIDATE_SPEC` | `DISPOSITION_REGISTRY.get(<label>)` | `152-156` |
| `DISPOSITION_SPECS` | `{s.label: s for s in DISPOSITION_REGISTRY.list_all()}` | `157-159` |
| `MODERNIZATION_DISPOSITIONS` | `{"Refactor", "Rearchitect"}` | `163` |
| `MAX_REWORK_ITERATIONS` | `3` (module back-compat only; runtime uses `spec.max_rework_iterations`, default 3) | `170`, registry `disposition.py:97` |
| step-id constants `_BUNDLE_PRE_GATE_STEP` … `_PERSIST_SIDE_EFFECTS_STEP` | the 11 canonical string ids | `195-205` |
| `_DISPOSITION_OUTPUT_ARTIFACT` | `"disposition-output.json"` | `210` |
| `_DISPOSITION_PLAN_STEP` | `= _BUNDLE_PRE_GATE_STEP` (dead alias) | `217` |
| `_DISPOSITION_PLAN_ARTIFACT` | `= _DISPOSITION_OUTPUT_ARTIFACT` (dead alias) | `218` |

**Classvars** (LineWorkflowBase config): `ASSEMBLY_LINE = AssemblyLine.DISPOSITION_EXECUTION`, `ARTIFACT_ROOT = "disposition"`, `LINE_LABEL = "Disposition Execution"`, `STATUS_PREFIX = "disposition"` (`236-239`). NOTE: `STEPS`, `STEP_WEIGHTS`, `SINGLE_GATE_KEY` are **not** set — this workflow does NOT use the base `STEPS`-driven dispatch/commit; it overrides `_dispatch_agent_step`, `_commit_step_artifacts_spec`, `_build_evidence_data`, `_create_gate_pr`, and computes weights inline (see §Control Flow).

**Registry (`registries/disposition.py`)** — the five strategies are frozen dataclasses populated at import (`disposition.py:465-491`). Per-strategy step lists:

- **Retire**: pre `[user-transition-plan, data-archival-plan]`; post `[consumer-migration, infrastructure-decommission, security-decommission, license-reclamation, cost-savings-certification]`; `has_gate2=True` (`registries/disposition.py:261-303`).
- **Retain**: pre `[security-remediation, documentation-update, test-coverage, monitoring-setup, sustainment-handoff]`; post `()`; `has_gate2=False` (`306-337`).
- **Replace**: pre `[requirements-derivation, vendor-evaluation, integration-specification]`; post `[data-migration, user-transition, legacy-decommission]`; `has_gate2=True` (`340-377`).
- **Replatform**: pre `[platform-selection, workflow-mapping]`; post `[component-configuration, data-migration, user-training, validation-cutover, legacy-decommission]`; `has_gate2=True` (`380-422`).
- **Consolidate**: pre `[target-selection, feature-gap-analysis, enhancement-planning]`; post `[data-reconciliation, user-migration, absorbed-decommission]`; `has_gate2=True` (`425-462`).

Each `StepSpec` carries `(step, skill_id, artifact)` (`registries/disposition.py:52-63`). Skill ids per step are in the registry (e.g. `infrastructure-decommission → legacy-decommission`, `cost-savings-certification → tco-analyzer`).

---

## 1. STATE (instance variables)

`__init__` calls `super().__init__()` then adds disposition-specific fields (`disposition.py:241-266`). Inherited base fields (see `_base-workflow.md`) are listed after.

### Own fields (`disposition.py:244-266`)
| Var | Type | Initial | Mutated by / when |
|---|---|---|---|
| `_spec` | `DispositionSpec \| None` | `None` | set to registry strategy in `run()` (`297`); **replaced** with a drift-gate-attached copy in `_enforce_drift_control` (`569`) |
| `_disposition_label` | `str` | `""` | set to the resolved disposition string in `run()` (`298`) |
| `_bundle_approvals` | `list[dict[str,str]]` | `[]` | appended in `_run_gate` after each successful gate merge (`1371-1378`); read into output bundle + evidence bundles |
| `_disposition_output_ref` | `str` | `""` | set to the committed `disposition-output.json` path in `_bundle_pre_gate_evidence` (`1025`) and `_bundle_post_gate_evidence` (`1115`); read by persist + signal |
| `_disposition_output_json` | `str` | `""` | set to serialized envelope only in `_bundle_post_gate_evidence` (`1120`); read by persist |
| `_drift_control_resolutions` | `list[tuple[str,str,str]]` `(resolution, actor, reason)` | `[]` | appended by `drift_control_resolved` signal (`1433`); consumed by `_enforce_drift_control` wait loop (`615, 626`) |
| `_drift_control_consumed` | `int` | `0` | incremented after each consumed resolution (`629`) |
| `_drift_control_verdict` | `dict[str,object]` | `{}` | overwritten each drift eval loop (`575-588`); returned by `drift_control_status` query |

### Inherited base fields relevant here (`base.py:136-191`)
`_app_id` (set in `run` `280`), `_portfolio_id`/`_wave_id`/`_risk_tier`/`_profile_id`/`_input` — **NEVER set by this workflow** (see GOTCHA-A), `_status`, `_current_step`, `_progress_pct`, `_pending_gate`, `_started_at`, `_updated_at`, `_gate_decisions` (list of 5-tuples), `_gate_decisions_consumed`, `_rework_feedback` (dict keyed by gate-value), `_rework_iterations` (dict keyed by gate-value), `_step_results`, `_step_committed_paths`, `_agent_metadata`, `_merge_retry_signalled`, `_portfolio_fallback_policy`, `_redispatch_guard`. `cancelled` bool comes from `HILSignalsMixin` (`temporal_base/signals.py:45`, set True by `cancel_workflow` signal `85-86`).

> **GOTCHA-A (determinism/behavioral):** `run()`/`_execute()` never set `_portfolio_id`, `_wave_id`, `_risk_tier`, `_profile_id`, `_input`. Consequences a rebuild MUST reproduce: (1) `_execution_ctx` always returns `None` (base `_execution_ctx` early-returns when `_portfolio_id` is empty, `base.py:345`) — but this workflow's overridden `_dispatch_agent_step`/`_commit_step_artifacts_spec`/`_create_gate_pr` never pass `execution_context` anyway; (2) drift eval passes `profile_id = self._profile_id or input.portfolio_id` = `input.portfolio_id` (`662`); (3) gate evidence submitted with `forward_risk_tier=False` (`1329`) so `_risk_tier` never forwarded; (4) `_dispatch_agent` fixture-scenario hook (`base.py:434`) is never exercised because this workflow uses its own `_dispatch_agent_step` which has no fixture hook.

---

## 2. SIGNALS & QUERIES

### Signals decorated on THIS class
- **`stakeholder_approved(signal: StakeholderApprovedSignal)`** (`disposition.py:1397-1417`). Appends a 5-tuple `(GateStatus.APPROVED, signal.approved_by, signal.justification, None, [])` to `_gate_decisions`, refreshes `_updated_at`. Treated identically to a `gate_approved`; lets the dashboard route stakeholder sign-off through a distinct path while progressing G-DE-1.
  > **GOTCHA-B (latent AttributeError):** the handler reads `signal.approved_by` and `signal.justification`, but `StakeholderApprovedSignal` is defined with fields `approval_id, stakeholder, scope` only (`types.py:167-172`) — no `approved_by`/`justification`. Invoking this signal with the declared payload raises `AttributeError` inside the handler. A rebuild must reproduce the field names *as coded here* (the handler references those attributes) and be aware the on-disk dataclass mismatch means this path is effectively unused/broken in practice. Do not "fix" silently — preserve exact attribute access.

- **`drift_control_resolved(resolution: str, actor: str = "", reason: str = "")`** (`1419-1434`). Appends `(resolution, actor, reason)` to `_drift_control_resolutions`; refreshes `_updated_at`. `resolution` is `"reconciled"` (drift fixed → re-evaluate) or `"risk_accepted"` (authorized human accepted; evidence already recorded API-side by `POST /drift-control/{disposition_id}/risk-accept` before signal fires). Buffered so a signal racing ahead of the wait is not lost.

### Signals inherited from base (DO NOT redefine — Temporal duplicate-registers) (`base.py:117, 197-257`)
- `gate_approved(GateApprovedSignal)` → appends `(APPROVED, approved_by, justification, None, [])` (`base.py:198-209`).
- `gate_rejected(GateRejectedSignal)` → appends `(REJECTED, rejected_by, reason, reason_category, card_decisions)` (normalizes missing card_decisions/reason_category) (`base.py:212-232`).
- `escalation_resolved(EscalationResolvedSignal)` → only refreshes `_updated_at` (`234-239`).
- `merge_retry(GateMergeRetrySignal)` → sets `_merge_retry_signalled = True` (idempotent) (`242-257`).
- Plus all `HILSignalsMixin` signals incl. `cancel_workflow()` → sets `self.cancelled = True` (`signals.py:83-86`).

### wait_condition predicates that consume signals
1. Gate decision (in base `_wait_for_gate_decision`, `base.py:1118-1120`): `lambda: len(self._gate_decisions) > consumed or self.cancelled` where `consumed = self._gate_decisions_consumed` captured before wait. Consumes `gate_approved` / `gate_rejected` / `stakeholder_approved`.
2. Drift-control resolution (`disposition.py:614-617`): `lambda: len(self._drift_control_resolutions) > consumed or self.cancelled` where `consumed = self._drift_control_consumed`. Consumes `drift_control_resolved`.
3. Merge-blocked retry (base `_reconcile_and_merge_with_retry_loop`, `base.py:1271-1272`): `lambda: self._merge_retry_signalled or self.cancelled`. Consumes `merge_retry`.

### Queries
- **`get_status() -> WorkflowStatusResponse`** (inherited, `base.py:1353-1365`): returns `workflow_id, status, current_line=DISPOSITION_EXECUTION, current_step, progress_pct, pending_gate, started_at, updated_at`.
- **`drift_control_status() -> dict`** (own, `disposition.py:672-680`): returns `dict(self._drift_control_verdict)` — empty `{}` until `_enforce_drift_control` runs its first eval. REQ-DC-007 AO continuous-monitoring read surface.

---

## 3. CONTROL FLOW

### `run(input: LineWorkflowInput) -> str` (`disposition.py:268-326`)
Returns one of `"completed"`, `"cancelled"`, `"failed"`.

```
_status = RUNNING
_started_at = _now_iso();  _updated_at = _started_at        # workflow.now().isoformat()
app_id = input.app_id;  _app_id = app_id

disposition_str = _disposition_str(input.disposition)       # enum→.value | str(x) | "" if None  (1803-1813)
IF disposition_str in {"Refactor","Rearchitect"}:
    RETURN await _fail("unsupported-disposition-{lower}", app_id)   # early return, status=FAILED

TRY:
    spec = DISPOSITION_REGISTRY.get(disposition_str)         # case-insensitive registry lookup
EXCEPT UnknownDispositionError:
    RETURN await _fail("missing-disposition", app_id)        # early return, status=FAILED
_spec = spec;  _disposition_label = disposition_str

repo = input.artifact_repo
wf_id = workflow.info().workflow_id
run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]
branch = f"olympus/disposition/{disposition_str.lower()}/{app_id}/{run_suffix}"
workspace_key = f"disposition-{disposition_str.lower()}-{app_id}-{run_suffix}"

TRY:
    RETURN await _execute(input, spec, app_id, repo, branch, workspace_key)
EXCEPT Exception:
    _status = FAILED;  _current_step = "failed";  _updated_at = _now_iso()
    TRY: await _update_app_status(app_id,"disposition_failed","failed","Disposition Execution")
    EXCEPT Exception: pass          # best-effort
    RAISE                            # re-raise → workflow task fails/retries
```

> **GOTCHA-C:** the top-level `except Exception` re-raises after best-effort status update, so any activity exception that escapes `_execute` (e.g. a non-retryable schema failure in `emit_disposition_output_bundle`) fails the workflow rather than returning a string. `_fail` (the graceful path) is only reached for the two disposition-validation early returns.

### `_execute(input, spec, app_id, repo, branch, workspace_key) -> str` (`328-513`)

```
prior_artifacts = list(input.prior_artifacts)
total_steps = len(spec.pre_gate1_steps) + len(spec.post_gate1_steps)
gate_count  = 2 if spec.has_gate2 else 1
per_step_weight = (100.0 - 10.0*gate_count) / max(total_steps, 1)   # gates worth 10% each
```

**Phase 1 — pre-G-DE-1 steps + G-DE-1 (rework loop)** (`351-397`):
```
WHILE True:
    cumulative = 0.0
    FOR step_spec IN spec.pre_gate1_steps:
        await _set_step(step_spec.step, cumulative)            # base: status→in_progress, DB update
        await _run_step(step_spec, app_id, repo, branch, workspace_key, prior_artifacts)
        cumulative += per_step_weight

    await _set_step(_BUNDLE_PRE_GATE_STEP, cumulative)         # "bundle-pre-gate-evidence"
    await _bundle_pre_gate_evidence(repo, branch, app_id, input, spec)

    gate1_evidence_steps = [s.step for s in spec.pre_gate1_steps] + [_BUNDLE_PRE_GATE_STEP]

    gate1_decision = await _run_gate(input, repo, branch, app_id,
        gate_type=GateType.G_DE_1, gate_step="gate-review-de1",
        evidence_steps=gate1_evidence_steps,
        title=f"Gate G-DE-1: {spec.title_label} Execution Plan Approval — {app_id}",
        body_builder=_build_gde1_pr_body,
        create_pr_step="create-g-de1-pr", pre_review_step="ai-pre-review-de1",
        merge_pr_step="merge-g-de1-pr")

    IF gate1_decision == "cancelled":  RETURN "cancelled"
    IF gate1_decision == "rejected":
        _bump_rework("G-DE-1")                                 # base: _rework_iterations["G-DE-1"] += 1
        IF _rework_count("G-DE-1") > spec.max_rework_iterations:   # default 3
            RETURN await _fail("max-rework-exceeded-gde1", app_id)
        CONTINUE                                                # re-run ALL pre-gate1 steps
    BREAK   # approved
```

**Phase 2 branch on `spec.has_gate2`** (`399-425`):
```
IF NOT spec.has_gate2:            # RETAIN ONLY
    await _emit_output_bundle(input, spec, app_id, repo, branch)   # P5-S13 legacy bundle + schema validate
    await _enforce_drift_control(input, app_id, spec)             # BLOCK on failing drift before terminal
    await _set_step(_PERSIST_SIDE_EFFECTS_STEP, 99.0)
    await _persist_disposition_side_effects(app_id, spec, terminal_status="disposition_complete")
    RETURN await _complete(app_id)   # Retain does NOT fire DispositionExecutedSignal (state-based handoff)
```

**Phase 2 — post-G-DE-1 steps + G-DE-2 (rework loop)** for all `has_gate2` dispositions (`427-473`):
```
WHILE True:
    cumulative = len(spec.pre_gate1_steps)*per_step_weight + 10.0     # +10 for G-DE-1 weight
    FOR step_spec IN spec.post_gate1_steps:
        await _set_step(step_spec.step, cumulative)
        await _run_step(step_spec, app_id, repo, branch, workspace_key, prior_artifacts)
        cumulative += per_step_weight

    await _set_step(_BUNDLE_POST_GATE_STEP, cumulative)             # "bundle-post-gate-evidence"
    await _bundle_post_gate_evidence(repo, branch, app_id, input, spec)

    gate2_decision = await _run_gate(input, repo, branch, app_id,
        gate_type=GateType.G_DE_2, gate_step="gate-review-de2",
        evidence_steps=[s.step for s in spec.pre_gate1_steps]
                       + [s.step for s in spec.post_gate1_steps]
                       + [_BUNDLE_POST_GATE_STEP],
        title=f"Gate G-DE-2: {spec.title_label} Decommission Readiness Sign-off — {app_id}",
        body_builder=_build_gde2_pr_body,
        create_pr_step="create-g-de2-pr", pre_review_step="ai-pre-review-de2",
        merge_pr_step="merge-g-de2-pr")

    IF gate2_decision == "cancelled":  RETURN "cancelled"
    IF gate2_decision == "rejected":
        _bump_rework("G-DE-2")
        IF _rework_count("G-DE-2") > spec.max_rework_iterations:
            RETURN await _fail("max-rework-exceeded-gde2", app_id)
        CONTINUE                                                    # re-run ALL post-gate1 steps
    BREAK   # approved
```

**Terminal (post-G-DE-2, non-Retain)** (`475-513`):
```
await _emit_output_bundle(input, spec, app_id, repo, branch)       # legacy P5-S13 bundle + schema validate
await _enforce_drift_control(input, app_id, spec)                  # BLOCK before terminal transition
await _set_step(_PERSIST_SIDE_EFFECTS_STEP, 99.0)
await _persist_disposition_side_effects(app_id, spec, terminal_status="disposition_complete")
await _fire_disposition_executed_signal(input, app_id, spec)       # to Deployment (non-Retain)
RETURN await _complete(app_id)
```

> **GOTCHA-D (rework re-runs EVERYTHING):** on gate rejection the whole `WHILE` loop body re-executes — every pre-gate1 (or post-gate1) agent step is dispatched again AND the bundle is rebuilt/recommitted. `_step_committed_paths` and `_agent_metadata` for those steps are overwritten. The rework counter is keyed by gate value string (`"G-DE-1"` / `"G-DE-2"`) via base `_bump_rework`/`_rework_count`; the cap check is strictly-greater-than `spec.max_rework_iterations` (so up to 3 rejections tolerated → the 4th trips fail).

> **GOTCHA-E (rework feedback routing):** base `_wait_for_gate_decision` stores rejection feedback under `_rework_feedback[gate_type.value]` (`base.py:1149`). The overridden `_dispatch_agent_step` reads it: for steps in `spec.pre_gate1_steps` it reads `_rework_feedback["G-DE-1"]`; else `_rework_feedback["G-DE-2"]` (`disposition.py:1459-1462`). `GateType.G_DE_1.value` must equal `"G-DE-1"` and `G_DE_2.value == "G-DE-2"` for this to line up.

### `_complete(app_id) -> str` (`515-525`)
```
await _update_app_status(app_id, "disposition_complete", "completed", "Disposition Execution")
_status = COMPLETED;  _progress_pct = 100.0;  _current_step = "completed";  _updated_at = _now_iso()
RETURN "completed"
```

### `_fail(reason_step, app_id) -> str` (`1382-1391`)
```
_status = FAILED;  _current_step = reason_step;  _updated_at = _now_iso()
await _update_app_status(app_id, "disposition_failed", reason_step, "Disposition Execution")
RETURN "failed"
```

### `_run_step(step_spec, app_id, repo, branch, workspace_key, prior_artifacts)` (`1221-1247`)
```
step_inputs = _inputs_for_step(step_spec.step, prior_artifacts)
result = await _dispatch_agent_step(app_id, step_spec, step_inputs, workspace_key, repo, branch)
_step_results[step_spec.step] = result.output_artifacts
artifact_path = f"disposition/{label.lower()}/{app_id}/{step_spec.artifact}"
await _commit_step_artifacts_spec(repo, branch, app_id, step_spec, result, artifact_path)
```

### `_inputs_for_step(step_name, prior_artifacts) -> list[str]` (`1249-1263`)
```
assert _spec is not None
ordered = [s.step for s in _spec.pre_gate1_steps] + [s.step for s in _spec.post_gate1_steps]
inputs = list(prior_artifacts)
FOR prev IN ordered:
    IF prev == step_name: BREAK          # stop at current step (exclusive)
    inputs.extend(_step_committed_paths.get(prev, []))
RETURN dedup_paths(inputs)               # order-preserving dedup (utils.dedup_paths)
```
> Each step gets `prior_artifacts` + every earlier step's committed paths, deduped. On rework, earlier same-phase steps have fresh committed paths (they were re-run).

### `_run_gate(...) -> "approved"|"rejected"|"cancelled"` (`1265-1380`)
```
evidence_paths = []
FOR step_name IN evidence_steps: evidence_paths.extend(_step_committed_paths.get(step_name, []))
evidence_paths = dedup_paths(evidence_paths)

IF create_pr_step: await _set_step(create_pr_step, _progress_pct)      # e.g. "create-g-de1-pr"
pr_result = await _create_gate_pr(repo, branch, app_id, gate_type=gate_type.value,
                                  title=title, body=body_builder(app_id))

gate_record = await execute_activity(create_gate_record, CreateGateRecordInput(
        gate_type=gate_type.value, app_id, portfolio_id=input.portfolio_id,
        workflow_id=workflow.info().workflow_id, evidence_package_url=pr_result.pr_url),
    start_to_close=30s, retry=transient)

await _submit_gate_evidence(gate_id=gate_record.gate_id, gate_type, app_id,
        artifact_paths=evidence_paths, pr_url=pr_result.pr_url,
        assembly_line="Disposition Execution", step=gate_step, forward_risk_tier=False)  # base helper

IF pre_review_step: await _set_step(pre_review_step, _progress_pct)   # e.g. "ai-pre-review-de1"
await _run_gate_pre_review(gate_record.gate_id, gate_type.value, evidence_paths,
                           artifact_repo=repo, artifact_ref=branch)   # base: advisory, fault-tolerant

await _set_step(gate_step, _progress_pct)                            # "gate-review-de1"/"-de2"
decision = await _wait_for_gate_decision(gate_type)                  # base: WAITING_FOR_SIGNAL
IF decision == "cancelled":  RETURN "cancelled"

IF decision == "approved":
    IF merge_pr_step: await _set_step(merge_pr_step, _progress_pct)   # "merge-g-de1-pr"/"-de2"
    await _reconcile_and_merge_with_retry_loop(repo, pr_number=pr_result.pr_number,
                                               gate_id=gate_record.gate_id, merge_method="merge")
    approver = _gate_decisions[-1][1] if _gate_decisions else "unknown"
    _bundle_approvals.append({"gate": gate_type.value, "approved_at": _now_iso(),
                              "approved_by": approver,
                              "record_ref": f"gates/{gate_record.gate_id}/decision.json"})
    RETURN "approved"
RETURN "rejected"
```
> **GOTCHA-F:** `approver` is `_gate_decisions[-1][1]` — index `[1]` = `approved_by`/`rejected_by` position of the most-recent decision tuple. Since the just-consumed approval is the last appended entry, this is correct for the normal case, but if a rejection for a *later* gate somehow appended after (impossible in this single-threaded flow) it would misattribute. Fine as coded.
> **GOTCHA-G:** the whole gate is announced via `_set_step` at the current `_progress_pct` (no weight bump for the sub-steps) — the 4 sub-step ids (`create-*`, `ai-pre-review-*`, `gate-review-*`, `merge-*`) all report the SAME progress value; only the step *name* changes so the frontend stepper advances.

### `_enforce_drift_control(input, app_id, spec)` (`531-644`) — REQ-DC-004 promotion block
```
_spec = attach_drift_gate(spec)                        # dataclasses.replace → new strategy w/ G-DRIFT appended (idempotent)
attached_gates = _spec.effective_required_gates()      # e.g. ("G-DE-1","G-DE-2","G-DRIFT")
risk_accepted = False
WHILE True:
    verdict = await _evaluate_drift_control(input, app_id)          # ACTIVITY
    _drift_control_verdict = {disposition_id, app_id, action, blocking, at_risk,
        coverage_regressed, gate_state, gate_id=DRIFT_GATE_ID("G-DRIFT"),
        effective_gates=list(attached_gates), risk_accepted, reasons=list(verdict.reasons),
        evaluated_at=verdict.evaluated_at}

    requires_resolution = verdict.blocking OR verdict.at_risk       # block(high) OR at_risk(medium)
    IF (NOT requires_resolution) OR risk_accepted:   RETURN         # advisory(low) OR already-accepted → proceed

    # HALT — park for human resolution
    _status = WAITING_FOR_SIGNAL;  _current_step = "drift-control-blocked";  _updated_at = _now_iso()
    consumed = _drift_control_consumed
    await workflow.wait_condition(
        lambda: len(_drift_control_resolutions) > consumed or self.cancelled)
    IF self.cancelled:
        _status = CANCELLED;  _updated_at = _now_iso()
        RAISE workflow.ApplicationError("disposition cancelled while drift-control blocked", non_retryable=True)

    resolution, _actor, _reason = _drift_control_resolutions[consumed]
    _drift_control_consumed = consumed + 1
    _status = RUNNING;  _updated_at = _now_iso()

    IF resolution == "risk_accepted":
        risk_accepted = True;  CONTINUE       # unblock next loop (no re-eval needed to clear)
    # "reconciled" or ANY other value → loop and RE-EVALUATE; clears only if next verdict is advisory
```
> **GOTCHA-H (cancel raises, not returns):** unlike gate/merge cancels which return a status string, a cancel while drift-blocked RAISES a non-retryable `ApplicationError` (`621-624`) — this propagates out of `_execute` → caught by `run`'s outer `except` → status FAILED, `_update_app_status("disposition_failed",...)`, then re-raised. So a drift-blocked cancel ends the workflow as FAILED/raised, NOT `"cancelled"`.
> **GOTCHA-I (risk_accepted latches):** once a `risk_accepted` resolution arrives, `risk_accepted=True` persists across loop iterations, so a subsequent re-eval that is still blocking will `RETURN` immediately (the `or risk_accepted` short-circuit at `604`). A `reconciled` resolution does NOT latch — it forces a fresh activity eval and only an `advisory` verdict clears the hold. A `reconciled` that does not actually remove the drift keeps parking.
> **GOTCHA-J:** `at_risk` (medium) parks EXACTLY like `block` (high) — both set `requires_resolution=True`; medium is not a silent pass (`590-603`).

### `_evaluate_drift_control(input, app_id) -> DriftControlEvalResult` (`646-670`)
```
payload = DriftControlEvalInput(app_id=app_id, disposition_id=workflow.info().workflow_id,
                                portfolio_id=input.portfolio_id,
                                profile_id=(self._profile_id or input.portfolio_id))
RETURN await execute_activity(drift_control_eval, payload,
    start_to_close=60s, retry=transient, activity_id=f"drift-control-eval-{app_id}")
```
> **GOTCHA-K:** the payload's `findings`, `severity_order`, `kind_severity`, `action_by_severity`, `coverage_pct`, `evidence_controls` all default empty/None (`drift_control_eval.py:283-294`). With **no findings** the reconstructed `DriftReport` has zero findings → `evaluate_drift_control` returns `action="advisory"`, `blocking=False`, `at_risk=False` (`drift_control_eval.py:339-364, 162-227`). So as wired here (workflow supplies only identity/routing) the drift-control verdict is CLEAR unless the activity itself loads persisted findings/DATA internally (the activity imports the API/service layer lazily to hydrate — `disposition.py:646-657` says the activity reads persisted drift state + profile DATA). A rebuild MUST place all DATA resolution in the activity, never in workflow code.

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS

No child workflows. All calls are `workflow.execute_activity`, sequential (no `asyncio.gather` anywhere). One cross-workflow signal via external handle. Retry policies from `RETRY_POLICIES` (`retry_policies.py:110-117`).

| # | Activity | Args (type) | start_to_close | retry_policy | activity_id | Where |
|---|---|---|---|---|---|---|
| 1 | `dispatch_agent_task` | `AgentTaskInput` (task_type=`disposition-{label}-{step}`, app_id, skill_id=`step_spec.skill_id`, input_artifacts, artifact_repo, artifact_ref, workspace_key, context) | `AGENT_START_TO_CLOSE` | `agent_failure` (3 attempts, exp 5-60s) | `agent-{step_spec.step}` | `1478-1484` |
| 2 | `write_artifacts_batch` (if patched `disposition-batch-writes-v1`) OR `write_artifact` (else) — pre-gate bundle | `WriteArtifactsBatchInput` / `WriteArtifactInput` | 120s / 60s | `transient` | `commit-bundle-pre-gate-evidence` | `992-1024` |
| 3 | `write_artifacts_batch`/`write_artifact` — post-gate bundle | same | 120s / 60s | `transient` | `commit-bundle-post-gate-evidence` | `1082-1114` |
| 4 | `write_artifacts_batch`/`write_artifact` — step artifacts | batch = summary JSON + per output file | 120s / 60s | `transient` | `commit-{step_spec.step}` | `1533-1573` |
| 5 | `write_artifact` — per output-file (non-batch path only, loop) | `WriteArtifactInput` | 60s | `transient` | (none) | `1575-1596` |
| 6 | `update_agent_task_output_ref` (if patched `patch-output-artifact-ref-v1`) | args `[app_id, "disposition-{label}-{step}", artifact_path]` | 30s | `transient` | `patch-output-ref-{step}` | `1600-1617` (wrapped in try/except pass) |
| 7 | `create_pr` (via `_create_gate_pr`) | `CreatePRInput` (repo, source_branch=branch, target_branch="main", title, body, labels=["gate-review","disposition",label.lower(),gate_type]) | 60s | `transient` | (none) | `1642-1647` |
| 8 | `create_gate_record` | `CreateGateRecordInput` | 30s | `transient` | (none) | `1308-1319` |
| 9 | `check_gate_criteria` (base `_submit_gate_evidence`, forward_risk_tier=False → slim input, no evidence_data/risk_tier) | `CheckGateCriteriaInput` | 60s | `transient` | (none) | `base.py:994-1006` |
| 10 | `submit_gate_evidence` (base) | `SubmitGateEvidenceInput` (slim evidence_data) | 60s | `transient` | (none) | `base.py:1016-1021` |
| 11 | `dispatch_agent_task` (gate pre-review, base) skill_id=`gate-pre-review` | `AgentTaskInput` | `AGENT_START_TO_CLOSE`, `heartbeat_timeout=AGENT_DISPATCH_HEARTBEAT_TIMEOUT` | `transient` | (none) | `base.py:1049-1071` |
| 12 | `store_gate_pre_review` (base, best-effort in try) | `StoreGatePreReviewInput` | 30s | `transient` | (none) | `base.py:1079-1087` |
| 13 | `mark_gate_ready_for_review` (base, in `finally`, if patched `mark-gate-ready-for-review-v1`) | `gate_id` | 30s | `transient` | (none) | `base.py:1096-1101` |
| 14 | `reconcile_and_merge_pr` (base retry loop) | `MergePRInput` (repo, pr_number, merge_method="merge", execution_context=None) | 60s | `git_merge` (3 attempts, non_retryable: MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected) | (none) | `base.py:1208-1218` |
| 15 | `set_gate_merge_blocked` (base, on structured merge failure) | args `[gate_id, detail]` | 30s | `transient` | (none) | `base.py:1263-1268` |
| 16 | `update_application_status` (base `_update_app_status`) | `UpdateAppStatusInput` | 30s | `transient` | (none) | `base.py:391-401` |
| 17 | `drift_control_eval` | `DriftControlEvalInput` | 60s | `transient` | `drift-control-eval-{app_id}` | `664-670` |
| 18 | `emit_disposition_output_bundle` | `EmitDispositionOutputBundleInput` (repo, branch, portfolio_id, app_id, bundle) | 60s | `transient` | (none) | `699-710` |
| 19 | `persist_disposition_side_effects` | `PersistDispositionSideEffectsInput` (app_id, disposition, disposition_output_ref, disposition_output_json, disposition_current_status, completed_at) | 60s | `transient` | `persist-disposition-side-effects` | `1153-1166` |

**Cross-workflow signal (not an activity)** — `_fire_disposition_executed_signal` (`1168-1219`): `handle = workflow.get_external_workflow_handle(deployment_wf_id); await handle.signal("disposition_executed", DispositionExecutedSignal(app_id, disposition=label, disposition_output_ref, portfolio_id, executed_at))`. Wrapped in try/except that only logs a warning on failure.

> **GOTCHA-L (patch gates — replay determinism):** three `workflow.patched(...)` ids gate activity shape: `disposition-batch-writes-v1` (batch vs per-file commits, appears in `_bundle_pre_gate_evidence`, `_bundle_post_gate_evidence`, `_commit_step_artifacts_spec`), `patch-output-artifact-ref-v1` (`update_agent_task_output_ref`), `mark-gate-ready-for-review-v1` (base). Inherited base `_dispatch_agent` also has `context-priors-v1`, but this workflow's own `_dispatch_agent_step` does NOT (no context-priors load). Preserve these ids VERBATIM.

---

## 5. GATE HANDLING

**Evidence assembly (`_run_gate` `1292-1297`):** flatten `_step_committed_paths[step]` for each id in `evidence_steps`, then `dedup_paths`. G-DE-1 evidence = all pre-gate1 step paths + pre-gate bundle path. G-DE-2 evidence = all pre-gate1 + post-gate1 step paths + post-gate bundle path.

**Bundle synthesis before each gate:**
- `_bundle_pre_gate_evidence` (`904-1045`): calls `bundle_pre_gate_evidence(app_id, app_name, portfolio_id, wave_id, disposition, step_committed_paths, started_at, approvals, now_iso=workflow.now().isoformat())`, then attaches an `envelope["g_de1_readiness"]` block with computed booleans:
  - `stakeholder_sign_off = True` (hardcoded)
  - `user_transition_addressed = is_retain or _any_hint(_USER_TRANSITION_HINTS)` where hints = `("user-transition","user-training","user-migration","change-mgmt","workflow-mapping")` matched as substrings against pre-gate1 step names
  - `data_archival_defined = is_retain or _any_hint(_DATA_ARCHIVAL_HINTS)` hints = `("data-archival","data-migration","data-reconciliation")`
  - `rollback_documented = is_retain or spec.has_gate2`
  - `pre_gate1_steps = sorted(step names)`, `has_gate2`, `timestamp`
  - `is_retain = (self._disposition_label == "Retain")`
  Serialized `json.dumps(envelope, indent=2, sort_keys=True)`, committed to `disposition/{label.lower()}/{app_id}/disposition-output.json`. Sets `_disposition_output_ref`, registers `_step_committed_paths["bundle-pre-gate-evidence"]=[path]` and `_agent_metadata[...]` with a deterministic `OutputFile(path="disposition-output.json", content, "utf-8")` (`1031-1045`).
- `_bundle_post_gate_evidence` (`1047-1136`): calls `bundle_post_gate_evidence(...)` with `completed_at = workflow.now().isoformat()` (passed as both `completed_at` and `now_iso`). Serialized (sort_keys=True), committed to same path. Sets `_disposition_output_ref` AND `_disposition_output_json = content` (only the post-gate path sets the json snapshot). Registers `_step_committed_paths["bundle-post-gate-evidence"]` + `_agent_metadata`.

> **GOTCHA-M (Retain never sets `_disposition_output_json`):** only `_bundle_post_gate_evidence` sets `_disposition_output_json` (`1120`). Retain skips post-gate entirely, so `persist_disposition_side_effects` for Retain gets `disposition_output_json=""` (falls back via `getattr(..., "")` `1151-1152`) but `disposition_output_ref` = the pre-gate bundle path.

**The wait (base `_wait_for_gate_decision`, `base.py:1103-1157`):** sets `_status=WAITING_FOR_SIGNAL`, `_pending_gate=gate_type`; waits on `len(_gate_decisions) > consumed or self.cancelled`. On cancel → `_status=CANCELLED`, returns `"cancelled"`. Consumes one decision tuple (handles both 3- and 5-tuple shapes; entries here are always 5-tuples), increments `_gate_decisions_consumed`, clears `_pending_gate`, `_status=RUNNING`. On APPROVED: `_rework_feedback.pop(gate_key)` and returns `"approved"`. On REJECTED: stores `_rework_feedback[gate_key] = {gate, rejected_by, reason, reason_category, card_decisions, rejected_at}` and returns `"rejected"`.

**Routing after decision (`_run_gate`):**
- `"cancelled"` → `_run_gate` returns `"cancelled"` → `_execute` returns `"cancelled"`.
- `"approved"` → merge via `_reconcile_and_merge_with_retry_loop`, append `_bundle_approvals`, return `"approved"` → `_execute` breaks the phase loop.
- `"rejected"` → return `"rejected"` → `_execute` bumps counter and either fails (cap exceeded) or `continue`s the phase loop (rework).

**Merge-blocked handling (base `_reconcile_and_merge_with_retry_loop`, `base.py:1159-1280`):**
```
merge_failure_types = {MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected}
WHILE True:
    TRY: execute_activity(reconcile_and_merge_pr, MergePRInput, 60s, git_merge); RETURN   # success
    EXCEPT (ActivityError, ApplicationError) as outer:
        unwrap __cause__ chain to the underlying ApplicationError
        IF not ApplicationError: RAISE
        failure_type = inner.type or ""
        IF failure_type NOT IN merge_failure_types: RAISE      # non-merge error propagates → workflow fails
        detail = {failure_type, reason, pr_number, detected_at}
        _merge_retry_signalled = False                          # reset before blocking
        execute_activity(set_gate_merge_blocked, [gate_id, detail], 30s, transient)
        await wait_condition(lambda: _merge_retry_signalled or self.cancelled)
        IF self.cancelled: RETURN                               # cancel during merge-block returns silently
        # loop → retry merge (merge_retry signal woke us)
```
> **GOTCHA-N:** the `git_merge` retry policy short-circuits (non_retryable) on all three structured merge errors, so they surface immediately to this loop; `MergeDivergenceUnresolved` is retried up to 3× at Temporal level only if it were retryable — but it's in the non-retryable list, so it too short-circuits. The reviewer must fire `merge_retry` (via `POST /api/v1/gates/{id}/retry-merge`) to re-attempt. A cancel during merge-block returns the loop silently (merge treated as done); control returns to `_run_gate` which then still appends `_bundle_approvals` and returns `"approved"` — the workflow proceeds as if merged.

**Rework loop + counters:** see §3 Phase 1/2 and GOTCHA-D/E. Counter key = gate value; cap = `spec.max_rework_iterations` (3); strictly `> cap` fails.

**PR body builders** (`_build_gde1_pr_body` `1740-1769`, `_build_gde2_pr_body` `1771-1800`): build markdown listing pre-gate1 (resp. post-gate1) steps as `- [x] {step} ({skill_id})` and artifacts as backtick-wrapped `disposition/{label.lower()}/{app_id}/{artifact}`, a fixed reviewer checklist (G-DE-1: Stakeholder+PM; G-DE-2: Ops Lead+Security), and appends `**Rework iteration:** {n}` when `_rework_count(gate) > 0`.

---

## 6. RESILIENCE

- **Timeouts:** every activity has an explicit `start_to_close_timeout` (see §4 table). Agent dispatch uses `AGENT_START_TO_CLOSE` (`agent_timeouts.py`). Gate pre-review adds `heartbeat_timeout=AGENT_DISPATCH_HEARTBEAT_TIMEOUT` (base). No workflow-level `execution_timeout` set in this class.
- **Heartbeats:** only the base gate-pre-review dispatch declares a heartbeat timeout.
- **Continue-as-new:** NONE. This workflow never calls `workflow.continue_as_new`. Long-running rework loops and drift-blocks accrue history without CAN. (No occurrence in `disposition.py`.)
- **Idempotency:** stable `activity_id`s for agent/commit/patch/persist/drift-eval calls (`agent-{step}`, `commit-{step}`, `commit-bundle-*`, `patch-output-ref-{step}`, `persist-disposition-side-effects`, `drift-control-eval-{app_id}`) → dedup on replay. `attach_drift_gate` is idempotent/non-mutating (`drift.py:374-390`). `merge_retry` handler idempotent.
- **Compensation / rollback:** NONE. There is no compensating activity for a partially-decommissioned app. On failure the workflow best-effort-updates app status to `disposition_failed` and re-raises (`319-326`). `persist_disposition_side_effects` is best-effort (activity swallows DB blips; wrapper adds no extra retry — `1138-1150`). `_fire_disposition_executed_signal` and gate-pre-review are best-effort (failures logged, not fatal).
- **Best-effort blocks (never fatal):** step output-ref patch (`try/except pass` `1616-1617`), gate pre-review (base try/except), external Deployment signal (try/except warning `1214-1219`), the outer status update in `run` (`try/except pass` `324-325`).
- **Determinism boundary:** `_now_iso()` and `workflow.now().isoformat()` are the ONLY time sources (both deterministic via `workflow.now()`, `base.py:106-108`). All DATA resolution + verdict + verdict-timestamp for drift-control live in the `drift_control_eval` ACTIVITY, never in workflow code (`646-657`, GOTCHA-K).

---

## 7. Per-disposition routing (explicit cases)

Routing is fully data-driven off the registry strategy — the only hard-coded disposition branches are (a) Refactor/Rearchitect rejection in `run`, (b) `has_gate2` in `_execute`, (c) Retain-skip in `_fire_disposition_executed_signal`, and (d) the label switch in `_build_payload`.

| Disposition | `has_gate2` | Gates run | Terminal path | Fires `DispositionExecutedSignal`? |
|---|---|---|---|---|
| **Retire** | True | G-DE-1, G-DE-2, +G-DRIFT (advisory) | emit bundle → enforce drift → persist → fire signal → complete | Yes |
| **Retain** | False | G-DE-1, +G-DRIFT | emit bundle → enforce drift → persist → complete (`400-425`) | **No** (state-based Sustainment handoff, `1186-1187`) |
| **Replace** | True | G-DE-1, G-DE-2, +G-DRIFT | full terminal + signal | Yes |
| **Replatform** | True | G-DE-1, G-DE-2, +G-DRIFT | full terminal + signal | Yes |
| **Consolidate** | True | G-DE-1, G-DE-2, +G-DRIFT | full terminal + signal | Yes |
| **Refactor / Rearchitect** | — | — | `run` returns `_fail("unsupported-disposition-*")` before registry lookup (`283-288`) | — |

**`_build_payload(spec, app_id, step_path) -> dict` (`773-902`)** — dispatch on `spec.label`, each returns a typed payload wired to committed step paths via `step_path(name)` (= `_step_committed_paths[name][0]` or `""`, `728-730`). Each case verbatim:
- `"Retire"` (`781-799`): `decommission_certificate_ref = step_path("infrastructure-decommission") or f"disposition/{app_id}/decommission-certificate.json"`; `archival.reconstruction_plan_ref`/`data_archival_plan_ref = step_path("data-archival-plan")`; `consumer_migration.migration_report_ref = step_path("consumer-migration")` with counts 0; `license_reclamation_ref = step_path("license-reclamation")`; `infrastructure_torn_down=[]`.
- `"Retain"` (`800-824`): `retain_reason` fixed string; `remediation_outcome` refs to security-remediation/documentation-update/monitoring-setup, counts 0, `test_coverage_baseline_pct=0.0`; `sustainment_handoff.owner_team="sustainment"`, `handoff_confirmed_at=_now_iso()`, `handoff_ref=step_path("sustainment-handoff")`; `re_evaluation_triggers=["annual review"]`.
- `"Replace"` (`825-845`): `selected_vendor` name/version "TBD" + `vendor_evaluation_ref`; `integration.integration_spec_ref`/`cutover_plan_ref = step_path("integration-specification")`; `data_migration` refs `data-migration`, `records_migrated=0`, `reconciliation_pass=False`; `legacy_decommission_ref = step_path("legacy-decommission")`.
- `"Replatform"` (`846-873`): `target_platform` name "TBD"; refs to platform-selection/workflow-mapping/component-configuration/validation-cutover/legacy-decommission; `data_migration` block; `perf_delta`/`cost_delta` with None numerics.
- `"Consolidate"` (`874-897`): `target_application.id="00000000-0000-0000-0000-000000000000"`, name "TBD", refs to target-selection/feature-gap-analysis/enhancement-planning/data-reconciliation/user-migration/absorbed-decommission; counts 0.
- else (`898-902`): `raise ValueError("Unsupported disposition label for DispositionWorkflow bundle: {label!r}")` — Refactor/Rearchitect would raise here (but they never reach it, rejected in `run`).

**`_build_output_bundle(input, spec, app_id) -> dict` (`712-771`):** uniform envelope: `application_id, application_name (input.app_name or app_id), portfolio_id, wave_id (getattr(input,"wave_id","") or ""), disposition=spec.label, status="completed", started_at=self._started_at, completed_at=_now_iso(), disposition_decision_ref, approvals=list(_bundle_approvals), realized_net_impact (tco_delta with None numerics + baseline_ref, users_affected_actual=None + user_impact_ref), payload=_build_payload(...)`. `baseline_ref`/`disposition_decision_ref`/`user_impact_ref` are `f"rationalization/wave-{wave_id}/{app_id}/*.json"` when `wave_id` truthy else `""`.

**Overridden StepSpec-aware helpers:**
- `_dispatch_agent_step` (`1442-1495`): builds `task_type=f"disposition-{label.lower()}-{step}"`, `skill_id=step_spec.skill_id`; adds `context["rework_feedback"]` from `_rework_feedback["G-DE-1"]` (pre-gate1 steps) or `["G-DE-2"]` (post-gate1 steps) when present; dispatches `dispatch_agent_task` and records `_agent_metadata[step]`.
- `_commit_step_artifacts_spec` (`1497-1617`): writes a per-step summary JSON `{disposition, step, skill_id, artifacts, file_artifacts, model_used, duration_ms, token_usage, cost_estimate_usd, timestamp}` to `disposition/{label.lower()}/{app_id}/{artifact}`; also commits each `OutputFile` to `disposition/{label.lower()}/{app_id}/files/{step}/{file.path}` (batched or per-file per patch); sets `_step_committed_paths[step]=committed`; optional output-ref patch.
- `_create_gate_pr` (`1619-1647`): labels `["gate-review","disposition",label.lower(),gate_type]` (NOTE: differs from base which uses `["gate-review", ARTIFACT_ROOT, gate_type]` — adds the disposition-specific labels; does NOT pass `execution_context`).
- `_build_evidence_data` (`1649-1734`): adds a top-level `"disposition"` key and iterates `_spec.pre_gate1_steps + post_gate1_steps` (not base `STEPS`), plus injects the two code-kind bundle steps (`bundle-pre-gate-evidence`, `bundle-post-gate-evidence`) into `steps{}` so G-DE-1 threshold predicates find the `g_de1_readiness` flags.

---

## 8. Behavioral parity checklist

A rebuild MUST satisfy every assertion:

1. **Rejection routing:** Refactor/Rearchitect → `run` returns `"failed"` with `_current_step` = `"unsupported-disposition-refactor"`/`"-rearchitect"` and app status `disposition_failed`, WITHOUT touching the registry.
2. **Unknown disposition:** any label not in `{Retire,Retain,Replace,Replatform,Consolidate}` (and not modernization) → `_fail("missing-disposition")` → `"failed"`.
3. **Branch/workspace naming:** `branch == f"olympus/disposition/{label.lower()}/{app_id}/{run_suffix}"`, `workspace_key == f"disposition-{label.lower()}-{app_id}-{run_suffix}"`, `run_suffix` = last `-`-segment of workflow_id (or first 8 chars if no `-`).
4. **Weights:** `per_step_weight == (100 - 10*gate_count)/max(total_steps,1)`; gate_count=1 for Retain else 2. Phase-2 cumulative starts at `len(pre)*per_step_weight + 10`. Persist step announced at 99.0; complete sets 100.0.
5. **Step ordering:** each disposition runs its exact registry `pre_gate1_steps` then G-DE-1 then (unless Retain) `post_gate1_steps` then G-DE-2. Retain runs only pre_gate1 + G-DE-1.
6. **`_inputs_for_step`:** returns `dedup_paths(prior_artifacts + committed paths of all earlier steps in pre+post order, stopping before the current step)`.
7. **Rework:** rejection re-runs the ENTIRE phase's steps + bundle; counter keyed by gate value; the 4th rejection (`count > 3`) → `_fail("max-rework-exceeded-gde1"/"-gde2")`.
8. **Gate evidence sets:** G-DE-1 = pre_gate1 step paths + `bundle-pre-gate-evidence`; G-DE-2 = pre_gate1 + post_gate1 + `bundle-post-gate-evidence`; deduped.
9. **Gate PR labels:** exactly `["gate-review","disposition",<label lower>,<gate value>]`.
10. **`forward_risk_tier=False`** on `_submit_gate_evidence` (no evidence_data/risk_tier on `check_gate_criteria`).
11. **Approvals array:** after each successful gate merge, one `_bundle_approvals` entry `{gate, approved_at, approved_by=<last decision actor or "unknown">, record_ref="gates/{gate_id}/decision.json"}`.
12. **Merge-blocked loop:** the three structured merge errors → `set_gate_merge_blocked` + wait for `merge_retry`; other errors propagate (fail workflow); cancel during block returns silently (proceeds as merged).
13. **Drift enforcement runs before terminal persist for ALL dispositions** (incl. Retain, before its persist). Verdict + timestamp computed only in the `drift_control_eval` activity.
14. **Drift block semantics:** `block` OR `at_risk` (and not yet `risk_accepted`) → park on `drift_control_resolved`. `risk_accepted` latches and unblocks permanently; `reconciled` (or any other value) re-evaluates and clears only on `advisory`. Cancel while drift-blocked RAISES non-retryable `ApplicationError` (→ workflow FAILED), not `"cancelled"`.
15. **`drift_control_status` query** returns the last verdict dict (with `gate_id="G-DRIFT"`, `effective_gates` including `G-DRIFT`, `risk_accepted`, `reasons`, `evaluated_at`), `{}` before first eval.
16. **`attach_drift_gate`** replaces `self._spec` with a copy whose `effective_required_gates()` appends `G-DRIFT` (idempotent, non-mutating; does not touch the global registry).
17. **Retain does NOT fire `DispositionExecutedSignal`**; Retire/Replace/Replatform/Consolidate fire it to `input.peer_workflow_ids["Deployment"]` (skip silently if absent). Failure to signal logs a warning only.
18. **`persist_disposition_side_effects`** gets `disposition_output_ref` (always set), `disposition_output_json` (only set post-gate; empty for Retain), `disposition_current_status="disposition_complete"`.
19. **Bundle path** is always `disposition/{label.lower()}/{app_id}/disposition-output.json`; JSON serialized with `indent=2, sort_keys=True`.
20. **`g_de1_readiness`** booleans computed exactly per §5 (substring hint matching; `is_retain` short-circuits three of them; `rollback_documented = is_retain or has_gate2`).
21. **`_build_payload`** dispatch produces the exact per-label dict shapes in §7; an unmapped label raises `ValueError`.
22. **Patch ids** preserved verbatim: `disposition-batch-writes-v1`, `patch-output-artifact-ref-v1`, `mark-gate-ready-for-review-v1`. This workflow's own dispatch has NO `context-priors-v1` load (unlike base `_dispatch_agent`).
23. **Signal handlers `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry` are NOT redefined** on the subclass (inherited from base). Only `stakeholder_approved` and `drift_control_resolved` are added here.
24. **Time only via `workflow.now()`**; no wall-clock, random, or workflow-side DATA resolution.
25. **No continue-as-new, no child workflows, no `asyncio.gather`** — all activities sequential.
