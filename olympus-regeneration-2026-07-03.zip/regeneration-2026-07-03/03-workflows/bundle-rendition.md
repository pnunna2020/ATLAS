# Workflow Rendition: BundleReaperWorkflow, BundleAwareMixin, RenditionWorkflow

Atomic regeneration spec — Phase 5 W20 (delegated bundles) + rendition async generation.
Sources (all repo-root-relative, canonical primary tree only):
- `temporal/olympus_workflows/workflows/bundle_reaper.py` (BundleReaperWorkflow, ~118 lines)
- `temporal/olympus_workflows/workflows/bundle_helpers.py` (BundleAwareMixin, ~190 lines)
- `temporal/olympus_workflows/workflows/rendition.py` (RenditionWorkflow, ~49 lines)
- Supporting: `temporal/olympus_workflows/types.py`, `temporal/olympus_workflows/retry_policies.py`, `temporal/olympus_workflows/temporal_base/retry_policies.py`, `temporal/olympus_workflows/activities/bundle_activities.py`, `temporal/olympus_workflows/activities/renditions.py`

All three are **thin** Temporal workflow bodies; the heavy logic lives in their activities. This doc captures the workflow-layer behavior to parity; activity internals are documented in the activities bundle but summarized here where load-bearing for control flow.

---

## Shared prerequisites (reproduce exactly)

### Retry policy `RETRY_POLICIES["transient"]`
`temporal/olympus_workflows/retry_policies.py:34` aliases `TRANSIENT_RETRY_POLICY = HTTP_RETRY_POLICY`, registered at `retry_policies.py:110-111`.
`HTTP_RETRY_POLICY` is defined at `temporal/olympus_workflows/temporal_base/retry_policies.py:35-40`:
```
RetryPolicy(
    initial_interval=timedelta(seconds=1),
    maximum_interval=timedelta(seconds=15),
    maximum_attempts=3,
    backoff_coefficient=2.0,
)
```
So "transient" = **3 attempts max, 1s→2s→(cap 15s) exponential backoff, no non_retryable list**. A rebuild MUST use exactly these numbers for both `expire_due_bundles_activity` and `render_rendition`.

### `@workflow.unsafe.imports_passed_through()`
All three files wrap their `olympus_workflows.*` imports in this context manager (`bundle_reaper.py:36`, `bundle_helpers.py:58`, `rendition.py:21`) so the Temporal sandbox passes them through unpatched. GOTCHA: reproducing without this block will make Temporal's workflow sandbox re-import and reject non-deterministic modules.

### Signal payload dataclasses (`temporal/olympus_workflows/types.py`)
- `BundleCompletedSignal` (`types.py:359-372`): `bundle_id: str`, `outcome: str` (`'accepted'|'rejected'`), `outputs: dict[str,str] = field(default_factory=dict)` (artifact_kind → artifact_ref), `validation_summary: str = ""`.
- `BundleExpiredSignal` (`types.py:375-387`): `bundle_id: str`, `reason: str = "expired"` (cron path emits `"expired"`; admin force-release emits `"released"`).
- `RenderRenditionInput` (`types.py:583-600`): `rendition_id: str`, `app_id: str`, `rendition_type: str` (`requirements_doc|architecture_deck|test_report`), `template_name: str`, `artifact_repo: str`, `application_name: str = ""`.
- `RenderRenditionResult` (`types.py:603-610`): `rendition_id: str`, `status: str` (`completed|failed`), `content_length: int = 0`, `error: str = ""`.

---

## 1. BundleReaperWorkflow

`@workflow.defn` at `bundle_reaper.py:46-47`. Class docstring `:48-62`.

### 1.1 STATE
**None.** No `__init__`, no instance variables, no mutable state. Explicitly documented as "no inter-run state, no signal handlers" (`bundle_reaper.py:52-53`). Each cron tick is a fresh, independent workflow execution. A rebuild MUST NOT add any accumulator, buffer, or cross-run field.

### 1.2 SIGNALS & QUERIES
**None.** The reaper defines no `@workflow.signal` and no `@workflow.query` handlers (`bundle_reaper.py:53`: "the reaper consumes nothing beyond the cron tick"). It only *sends* signals outbound (see §1.4). A rebuild MUST NOT add inbound signal handlers.

### 1.3 SCHEDULING / CRON (critical — not in the workflow body)
The workflow body itself contains **no cron/timer/`continue_as_new`** logic. Scheduling is **provisioned out-of-band** via the Temporal Schedules API (`bundle_reaper.py:10-21`, matching SustainmentWorkflow/GovernanceWorkflow). Canonical schedule (docstring `:16-21`):
```
temporal schedule create \
    --schedule-id bundle-reaper \
    --workflow-id bundle-reaper \
    --workflow-type BundleReaperWorkflow \
    --task-queue olympus-main \
    --interval 15m
```
Cadence: **15 minutes** (`bundle_reaper.py:4`, §3.6 of delegated-bundles-design). Task queue: `olympus-main`. GOTCHA: the 15m cadence is a *schedule* property, NOT encoded in the workflow — a rebuild that bakes a `workflow.sleep(15m)` + `continue_as_new` loop into the body would be WRONG; the body is one-shot ("runs `expire_due_bundles_activity` once and exits", `:50-51`).

### 1.4 CONTROL FLOW — `run(self) -> dict[str, int]` (`bundle_reaper.py:64-118`)

Returns a summary dict: `expired` (# transitioned this run), `signalled` (# parent workflows successfully signalled; always `<= expired`, `:73-74`).

```
run():
    # --- Step 1: sweep activity (with catch-all guard) ---
    try:
        expired = await execute_activity(
            expire_due_bundles_activity,
            start_to_close_timeout = 2 minutes,          # bundle_reaper.py:78
            retry_policy = RETRY_POLICIES["transient"],  # bundle_reaper.py:79  (3 attempts, 1-15s expo)
        )
    except Exception as exc:                             # bundle_reaper.py:81  (bare, noqa BLE001)
        workflow.logger.warning("bundle-reaper.sweep-failed: %s", exc)   # :82-84
        return {"expired": 0, "signalled": 0}            # bundle_reaper.py:85  EARLY RETURN

    # --- Step 2: fan-out signals to dispatching workflows ---
    signalled = 0                                        # bundle_reaper.py:87
    for entry in (expired or []):                        # bundle_reaper.py:88  (None-safe)
        bundle_id = entry.get("bundle_id", "")           # :89
        wfid       = entry.get("workflow_id", "")        # :90
        if not wfid:                                     # :91  BRANCH A — no parent workflow
            # Activity already emitted log_internal_fallback_stub for this row.
            continue                                     # :94  (skip; NOT counted in signalled)
        # BRANCH B — parent workflow known
        try:
            handle = workflow.get_external_workflow_handle(wfid)   # :97
            await handle.signal(                                    # :98-103
                "bundle_expired",
                BundleExpiredSignal(bundle_id=bundle_id, reason="expired"),
            )
            signalled += 1                                          # :104  (only on success)
        except Exception as exc:                                    # :105  (bare, noqa BLE001)
            workflow.logger.info(
                "bundle-reaper.signal-failed: bundle=%s wf=%s err=%s",
                bundle_id, wfid, exc,                               # :109-113
            )
            # NO re-raise, NO retry — external wf likely complete/cancelled; stub log already covered it.

    # --- Step 3: summary ---
    return {                                              # bundle_reaper.py:115-118
        "expired":   len(expired or []),   # counts ALL expired rows incl. empty-wfid ones
        "signalled": signalled,            # counts only successful signals
    }
```

Behavioral notes a rebuild MUST preserve:
- The `expired or []` idiom appears **twice** (`:88`, `:116`) — activity returning `None` must be treated as empty, never crash.
- `expired` count includes empty-`workflow_id` rows (`len(expired or [])` at `:116`), but `signalled` does **not** count them (they `continue` at `:94`). So `signalled <= expired` always, and can be strictly less even with no signal failures.
- A signal failure (Branch B `except`) is swallowed and does NOT increment `signalled`, does NOT re-raise, and does NOT abort the loop — the reaper keeps signalling remaining bundles. GOTCHA: signalling is *best-effort*; a dead parent workflow silently drops its expiry notification, relying on the activity's already-emitted structured log.
- The Step-1 `except` returns `{"expired":0,"signalled":0}` (`:85`) — a failed sweep is reported as zero, NOT re-raised. GOTCHA: because retries are exhausted inside `execute_activity` (3 attempts) before this catch fires, a persistently-failing DB means the reaper "succeeds" with a zero summary each 15m tick; monitoring must watch the `bundle-reaper.sweep-failed` warning log, not the workflow completion status.

### 1.5 ACTIVITY & CHILD CALLS
- `expire_due_bundles_activity` (`bundle_reaper.py:76-80`) — **1 call, sequential**, no args. `start_to_close_timeout=2m`, retry `transient`. Returns `list[{bundle_id, workflow_id}]`.
  - Activity behavior (`bundle_activities.py:765-833`): opens one `_bundle_session()`, calls `bundle_svc.expire_due_bundles(db)` → list of expired ids; for each, post-fetches the row (`scope_kind,target_id,portfolio_id,application_id,wave_id,fallback_policy,dispatching_workflow_id`); `workflow_id = dispatching_workflow_id or ""`; if empty, calls `log_internal_fallback_stub(...)` and still appends the row with `workflow_id=""`; if row is `None` it `continue`s (skips). Both queries share one `AsyncSession` for a consistent view (`:781-782`).
- **Outbound signal** `bundle_expired` via `workflow.get_external_workflow_handle(wfid).signal(...)` (`:97-103`) — fire-and-forget, one per known-workflow entry, sequential in the loop (NOT gathered).

No `asyncio.gather`, no child workflows.

### 1.6 GATE / RESILIENCE
- No gates.
- No heartbeats (activity is short; 2m S2C timeout).
- No `continue_as_new` — scheduling is external (§1.3).
- Idempotency: the reaper is safe to re-run because `expire_due_bundles` only transitions rows still `claimed AND expires_at < now()`; already-expired rows are no longer selected (`bundle_reaper.py:4-7`). A double-fire produces an empty second sweep.
- No compensation/rollback — expiry is terminal for the bundle row.

---

## 2. BundleAwareMixin (`bundle_helpers.py`)

A **mixin**, not a `@workflow.defn`. Consuming workflows inherit it (`bundle_helpers.py:27`, `:68`) alongside other mixins (e.g. `HILSignalsMixin`). Purely additive; as of chunk D no existing workflow uses it (`:18-20`). `BundleOutcome = Literal["accepted","rejected","expired","released","timeout"]` (`:65`).

### 2.1 STATE (`__init__`, `bundle_helpers.py:84-93`)
Three dicts, all init to `{}`:
- `_bundle_outcomes: dict[str, str]` (`:91`) — bundle_id → terminal outcome (`accepted`/`rejected`/`expired`/`released`). Set by both signal handlers; consumed by `await_bundle_completion` and the two queries.
- `_bundle_outputs: dict[str, dict[str, str]]` (`:92`) — bundle_id → submitted outputs (artifact_kind → artifact_ref). Populated only on `accepted` (via `bundle_completed`, `:113-114`); read by `get_bundle_outputs`.
- `_bundle_validation_summaries: dict[str, str]` (`:93`) — bundle_id → audit summary string. Populated by `bundle_completed` when present (`:115-118`). No query reads it (failure-narrative use only).

GOTCHA (`__init__` ordering, `:84-93`): calls `super().__init__()` **first** (`:90`), then sets its three dicts. Comment (`:85-89`): safe in multi-base workflows because bundle state is local; the initializer never resets dicts a sibling mixin set. A rebuild MUST keep `super().__init__()` before the dict assignments so cooperative multiple-inheritance chains initialize correctly (and so this mixin's dicts win their own slots without clobbering others).

### 2.2 SIGNALS & QUERIES

#### Signal `bundle_completed(self, signal: BundleCompletedSignal)` (`:99-118`)
```
outcome = (signal.outcome or "").strip().lower()      # :109
if not outcome:                                        # :110
    return                                             # :111  EARLY RETURN — empty/blank outcome ignored, nothing recorded
self._bundle_outcomes[signal.bundle_id] = outcome      # :112
if signal.outputs:                                     # :113
    self._bundle_outputs[signal.bundle_id] = dict(signal.outputs)   # :114  (copy, not alias)
if signal.validation_summary:                          # :115
    self._bundle_validation_summaries[signal.bundle_id] = signal.validation_summary  # :116-118
```
- Records `outcome` verbatim after `.strip().lower()` — does NOT validate against a whitelist here (v1 only fires `accepted`, but `rejected` would round-trip cleanly, `:104-107`). Whitelist enforcement happens later in `await_bundle_completion`.
- `outputs`/`validation_summary` only stored when truthy. `dict(signal.outputs)` makes a defensive copy (`:114`).

#### Signal `bundle_expired(self, signal: BundleExpiredSignal)` (`:120-134`)
```
reason = (signal.reason or "expired").strip().lower()  # :128  (None/blank → "expired")
if reason not in ("expired", "released"):              # :132
    reason = "expired"                                 # :133  normalize unknown → "expired"
self._bundle_outcomes[signal.bundle_id] = reason       # :134
```
- Only two valid terminal reasons: `expired` (cron) and `released` (admin force-release). Anything else is coerced to `expired` (`:129-133`).

#### Query `get_bundle_outcome(self, bundle_id) -> str` (`:182-185`)
Returns `self._bundle_outcomes.get(bundle_id, "")` — terminal outcome or `""` if unknown.

#### Query `get_bundle_outputs(self, bundle_id) -> dict[str,str]` (`:187-190`)
Returns `dict(self._bundle_outputs.get(bundle_id, {}))` — copy of accepted outputs, `{}` if not accepted.

MUST-NOT-OVERRIDE note: both `bundle_completed` and `bundle_expired` are the sole consumers/mutators of `_bundle_outcomes` that `await_bundle_completion`'s `wait_condition` predicate depends on. A subclass overriding either handler without writing `_bundle_outcomes[bundle_id]` would deadlock `await_bundle_completion` (it would never satisfy `bundle_id in self._bundle_outcomes` and always time out). The docstrings do not formally forbid overriding, but parity requires that any override still populate `_bundle_outcomes`.

### 2.3 CONTROL FLOW — `await_bundle_completion(self, bundle_id, timeout_seconds) -> BundleOutcome` (`:140-176`)
```
from datetime import timedelta as _td                  # :161  (local import inside method — GOTCHA below)
try:
    await workflow.wait_condition(                     # :164-167
        lambda: bundle_id in self._bundle_outcomes,     # :165  PREDICATE (membership, not value)
        timeout = _td(seconds=timeout_seconds),
    )
except TimeoutError:                                   # :168
    return "timeout"                                   # :169  EARLY RETURN
outcome = self._bundle_outcomes.get(bundle_id, "")     # :170
if outcome not in ("accepted","rejected","expired","released"):  # :174  defensive whitelist
    return "timeout"                                   # :175  unknown value → "timeout"
return outcome                                          # :176  (typed BundleOutcome)
```
Behavioral rules a rebuild MUST preserve:
- The wait predicate checks **key presence** (`bundle_id in self._bundle_outcomes`), NOT a specific value — so the *first* terminal signal for that bundle_id unblocks it. Because `bundle_completed` early-returns on empty outcome (`:111`) without inserting the key, a blank-outcome signal does NOT unblock the wait.
- On timeout → `"timeout"`. On unknown recorded value → also `"timeout"` (defensive, `:174-175`).
- `timeout_seconds` is a workflow-internal safety net independent of the bundle's DB `expires_at` / reaper (`:154-159`). Callers may set it longer (redispatch fallback) or shorter (safety-critical) than the bundle TTL.
- GOTCHA (local import `:161`): `timedelta` is re-imported inside the method as `_td`. Harmless but a rebuild reproducing exactly should keep the method self-contained; it works under the Temporal sandbox because `datetime` is a passthrough stdlib module.

### 2.4 GATE/RESILIENCE
- No activities, no child workflows, no gates directly — the mixin only wires signals + one wait. Consuming workflows do the dispatch + gate-evidence projection (usage example `:22-49`: dispatch via `dispatch_delegated_bundle` activity, then `await_bundle_completion`, then branch on `accepted` vs `expired/timeout`).
- The single durable wait is `workflow.wait_condition(..., timeout=...)` — Temporal timer-backed; survives worker restarts.
- No continue-as-new, no heartbeat, no compensation in the mixin itself.

---

## 3. RenditionWorkflow (`rendition.py`)

`@workflow.defn` at `rendition.py:27-28`. Started by API `POST /applications/{app_id}/renditions/generate` (`rendition.py:6`); API inserts the `pending` row + starts the workflow; UI polls `GET /applications/{app_id}/renditions` until row flips `completed`/`failed` (`:11-13`).

### 3.1 STATE
**None.** No `__init__`, no instance variables, no signals, no queries. Single-shot request/response workflow.

### 3.2 SIGNALS & QUERIES
**None.**

### 3.3 CONTROL FLOW — `run(self, input: RenderRenditionInput) -> dict` (`rendition.py:31-49`)
```
run(input):
    if isinstance(input, dict):                        # :33  BRANCH — dict-shaped input (Temporal payload)
        input = RenderRenditionInput(**input)          # :34  coerce to dataclass
    result: RenderRenditionResult = await workflow.execute_activity(  # :36-43
        render_rendition,
        input,                                          # positional single arg
        start_to_close_timeout = 10 minutes,            # :41
        retry_policy = RETRY_POLICIES["transient"],     # :42  (3 attempts, 1-15s expo)
    )
    return {                                            # :44-49
        "rendition_id":   result.rendition_id,
        "status":         result.status,               # "completed" | "failed"
        "content_length": result.content_length,
        "error":          result.error,
    }
```
Behavioral rules a rebuild MUST preserve:
- Dict-input coercion (`:33-34`): mirrors the activity's own coercion (`renditions.py:296-297`). GOTCHA: Temporal may deliver the input as a dict rather than a `RenderRenditionInput`; both the workflow and the activity defensively re-wrap it.
- **No try/except in the workflow.** Rendering is best-effort: the *activity* itself catches all exceptions internally (`renditions.py:303-305`), sets the `rendition` row to `failed` with the truncated error (`str(exc)[:1000]`, `:305`), and STILL returns a `RenderRenditionResult(status="failed", ...)` (`:327-332`). So the workflow's `execute_activity` normally returns a result even on render failure — the workflow does not crash and the return dict carries `status="failed"`, `error=...`. GOTCHA: the only way the workflow itself fails is if the activity raises *outside* the internal try (e.g. the DB `UPDATE` at `renditions.py:307-323` fails) after exhausting the 3 transient retries — then the exception propagates and the workflow fails without updating the row to `completed`/`failed`. A rebuild MUST keep the activity's internal catch so normal render errors surface as a `failed` row, not a failed workflow.
- 10-minute S2C timeout is deliberately generous because the activity reads artifacts from GitHub (`rendition.py:39-40`).

### 3.4 ACTIVITY CALLS
- `render_rendition` (`rendition.py:36-43`) — **1 call, sequential**, positional single arg `input`. `start_to_close_timeout=10m`, retry `transient` (3 attempts). No `non_retryable_errors`. Returns `RenderRenditionResult`.
  - Activity (`renditions.py:287-332`): coerce dict→dataclass; `try: content = await _render(input); status,error="completed",""` else on any exc → `content,status,error = "","failed", str(exc)[:1000]` and `logger.exception`; then `asyncpg.connect(_db_url())`, `UPDATE rendition SET status,content,error,completed_at WHERE id=$1` (content/error stored as `None` when empty via `or None`), `finally: conn.close()`; return result with `content_length=len(content)`.

### 3.5 GATE / RESILIENCE
- No gates, no child workflows, no `asyncio.gather`, no heartbeat, no continue-as-new.
- Idempotency: re-running overwrites the same `rendition` row by `rendition_id` (`renditions.py:316` `WHERE id=$1`) — safe to retry; last write wins. GOTCHA: Temporal-level activity retries or a re-started workflow re-render the same row idempotently.
- Compensation: none; a `failed` row is the terminal record (UI reads it).

---

## Behavioral parity checklist

BundleReaperWorkflow:
- [ ] Workflow has zero state, zero signal handlers, zero query handlers.
- [ ] `run()` calls `expire_due_bundles_activity` exactly once with `start_to_close_timeout=2m` and `RETRY_POLICIES["transient"]` (3 attempts, 1s→2s cap-15s expo).
- [ ] A raised sweep exception (post-retry) is caught, logged as `bundle-reaper.sweep-failed`, and `run()` returns `{"expired":0,"signalled":0}` WITHOUT re-raising.
- [ ] For each returned entry: empty `workflow_id` → `continue` (no signal, not counted in `signalled`); non-empty → `get_external_workflow_handle(wfid).signal("bundle_expired", BundleExpiredSignal(bundle_id, reason="expired"))`, incrementing `signalled` only on success.
- [ ] A signal exception is caught, logged as `bundle-reaper.signal-failed`, loop continues to next entry; `signalled` NOT incremented.
- [ ] Return `expired = len(expired or [])` (all rows), `signalled` = successful signals only; assert `signalled <= expired`.
- [ ] `expired` treated as `[]` when the activity returns `None` (both use sites).
- [ ] No cron/timer/continue-as-new in the body; cadence is external (Temporal Schedule, 15m, task queue `olympus-main`).

BundleAwareMixin:
- [ ] `__init__` calls `super().__init__()` before initializing three `{}` dicts: `_bundle_outcomes`, `_bundle_outputs`, `_bundle_validation_summaries`.
- [ ] `bundle_completed`: blank/empty outcome (after strip+lower) → early return, nothing recorded; otherwise set `_bundle_outcomes[id]=outcome`, set `_bundle_outputs[id]=dict(outputs)` only if outputs truthy, set validation summary only if truthy.
- [ ] `bundle_expired`: reason defaults to `"expired"` (None/blank), any value not in `{expired,released}` normalized to `"expired"`; set `_bundle_outcomes[id]=reason`.
- [ ] `await_bundle_completion`: waits on predicate `bundle_id in self._bundle_outcomes` with `timeout=timedelta(seconds=timeout_seconds)`; `TimeoutError` → `"timeout"`; recorded value not in `{accepted,rejected,expired,released}` → `"timeout"`; else return the value.
- [ ] `get_bundle_outcome` returns outcome or `""`; `get_bundle_outputs` returns a copy or `{}`.

RenditionWorkflow:
- [ ] `run(input)` coerces dict → `RenderRenditionInput`, calls `render_rendition` once with `start_to_close_timeout=10m`, `RETRY_POLICIES["transient"]`, no non_retryable list.
- [ ] Returns dict `{rendition_id, status, content_length, error}` from the result.
- [ ] No try/except in the workflow; render failures surface as `status="failed"` via the activity's internal catch (row set to `failed`), NOT as a failed workflow — the workflow only fails if the activity raises outside its internal try after retry exhaustion.
- [ ] Re-run overwrites the same `rendition` row by `rendition_id` (idempotent).
