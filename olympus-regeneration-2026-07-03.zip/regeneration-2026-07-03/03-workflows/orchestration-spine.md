# Orchestration Spine — `PortfolioWorkflow` → `WaveWorkflow` → `AppWorkflow`

**Sources of truth (canonical primary tree only):**
- `temporal/olympus_workflows/workflows/portfolio.py` (79 lines)
- `temporal/olympus_workflows/workflows/wave.py` (247 lines)
- `temporal/olympus_workflows/workflows/application.py` (182 lines)
- Inherited signal/query surface: `temporal/olympus_workflows/temporal_base/signals.py` (`HILSignalsMixin`) — see also `_base-workflow.md` §1.2.
- Payload/response dataclasses: `temporal/olympus_workflows/types.py`; cross-service signals re-exported from `olympus-contracts/olympus_contracts/signals.py`; `AssemblyLine` enum from `olympus-contracts/olympus_contracts/enums.py`.

> **Regeneration premise.** The codebase will be deleted. These three classes are the *coordination spine*: a portfolio fans out into waves, a wave fans out into per-app pipelines, and each per-app pipeline (today) runs exactly one child (`DiscoveryWorkflow`) before returning. Reproduce HOW each fan-out, concurrency guard, failure-isolation branch, and child-cancel path works — not what it "does."

> **CRITICAL up-front facts (read first):**
> 1. All three classes extend `HILSignalsMixin` (`portfolio.py:24`, `wave.py:34`, `application.py:44`), NOT `LineWorkflowBase`. They therefore inherit the approve/cancel/plan/document signal surface (§ *Inherited signals* below) but **none** of the gate-decision / evidence / rework machinery documented in `_base-workflow.md`. There is **no `_wait_for_gate_decision`, no `_gate_decisions`, no rework loop, no `merge_retry`, no `continue_as_new`** in any of these three classes.
> 2. **`PortfolioWorkflow` is a STUB.** Every `@workflow.run`, `@workflow.signal`, and `@workflow.query` body is `raise NotImplementedError` (`portfolio.py:41-79`). It is registered with the worker (`worker.py:192`) but must not be started — calling it fails immediately. It exists to lock the *interface* (method names = replay contract) for a future implementation. See §PortfolioWorkflow.
> 3. Neither `WaveWorkflow` nor `AppWorkflow` awaits any gate. Their gate-decision signal handlers are deliberate **accept-and-ignore no-ops** (`wave.py:152-160`, `application.py:132-140`). Gates are delivered point-to-point by the API to the workflow that *created* the gate (looked up by `workflow_id` on the gate row); the gate-bearing children (`DiscoveryWorkflow` and the per-line workflows spawned by `WaveRationalizationWorkflow`) own and await their own gates. See the load-bearing design notes at `wave.py:126-151` and `application.py:108-131`.
> 4. **Determinism:** all timestamps come from `_now_iso()` = `workflow.now().isoformat()` (`wave.py:245-247`, `application.py:180-182`) — never `datetime.now()`. Both files define their own module-level `_now_iso`; they are independent copies.
> 5. **The MRO super() chain is load-bearing.** Each `__init__` calls `super().__init__()` first (`wave.py:49`, `application.py:62`, `portfolio.py:39`) → `HILSignalsMixin.__init__` (`signals.py:29`) → which itself calls `super().__init__()`. Omitting it loses both the class's own state and the HIL state (`approved`, `cancelled`, etc.), and inherited signal handlers `AttributeError` on first delivery.

---

## 0. Composition & child-launch summary

```
PortfolioWorkflow (STUB — NotImplementedError)
  └─(intended)→ WaveWorkflow  (max 4 concurrent waves; MAX_CONCURRENT_WAVES=4)
        └─ AppWorkflow        (max 10 concurrent per wave; MAX_APPS_PER_WAVE=10)
              └─ DiscoveryWorkflow  (exactly one child today; then AppWorkflow returns "completed")
```

Concurrency constants (`types.py:133-137`): `MAX_CONCURRENT_WAVES = 4`, `MAX_APPS_PER_WAVE = 10`.

**Child-launch mechanics used by the spine:**

| Parent → child | Call site | child id | task_queue | parent-close / id-reuse |
|---|---|---|---|---|
| Wave → App | `workflow.execute_child_workflow("AppWorkflow", child_input, id=..., task_queue=...)` (`wave.py:103-108`) | `f"app-{app_id}-wave-{input.wave_id}"` (`wave.py:106`) | `workflow.info().task_queue` (`wave.py:107`) — child runs on the SAME queue as the parent | No `parent_close_policy` / `id_reuse_policy` args passed → both default (Temforal defaults: `PARENT_CLOSE_POLICY_TERMINATE`, `WORKFLOW_ID_REUSE_POLICY_ALLOW_DUPLICATE`). GOTCHA: default parent-close = TERMINATE means if the wave itself is terminated, in-flight App children are terminated too. |
| App → Discovery | `workflow.execute_child_workflow("DiscoveryWorkflow", discovery_input, id=..., task_queue=...)` (`application.py:101-106`) | `f"discovery-{input.app_id}"` (`application.py:104`) — **NOTE: no wave_id in the id**, unlike the App id | `workflow.info().task_queue` (`application.py:105`) | Same defaults as above. |

**GOTCHA (child id uniqueness):** the App child id embeds the wave (`app-{app_id}-wave-{wave_id}`) but the Discovery child id does NOT (`discovery-{app_id}`). If the same `app_id` appears in two concurrent waves, the two App children get distinct ids but both would try to start `discovery-{app_id}` — a workflow-id collision on the shared queue. With the default `ALLOW_DUPLICATE` reuse policy that only matters if the first is still open (then the second start fails). This is an ordering/uniqueness hazard to preserve/flag on rebuild, not a bug the code guards.

Children are invoked by **string name** (`"AppWorkflow"`, `"DiscoveryWorkflow"`) rather than class reference — the class need not be imported into the parent, but the string MUST match the registered `@workflow.defn` name exactly.

---

## 1. `WaveWorkflow` — `wave.py:33`

`@workflow.defn class WaveWorkflow(HILSignalsMixin)` (`wave.py:33-34`). Coordinates one wave: fan out one `AppWorkflow` child per app, bounded by a semaphore; isolate per-app failures; aggregate status for queries.

### 1.1 STATE (`__init__`, `wave.py:48-60`)

`super().__init__()` first (`wave.py:49`) → inherits all `HILSignalsMixin` state (§Inherited).

| Attr | Type | Initial | Mutated by / when |
|---|---|---|---|
| `_status` | `WorkflowStatus` | `PENDING` (`:51`) | `run()` sets `RUNNING` at start (`:72`), `COMPLETED` at end (`:135`). Read by `get_status` (`:224`). Never set to FAILED at wave grain — a failing app never fails the wave. |
| `_app_statuses` | `dict[str, WorkflowStatus]` | `{}` (`:52`) | Seeded to `PENDING` per app id in `run()` (`:79-80`). Set `RUNNING` when a slot opens (`:91`), `COMPLETED` on child success (`:110`), `FAILED` on child exception unless removed (`:118`), `CANCELLED` by `remove_app` (`:167`). Read by both queries. |
| `_removed_apps` | `set[str]` | `set()` (`:53`) | `remove_app` adds (`:166`). Consulted by `run_one_app` twice: skip-if-removed (`:88`), and don't-overwrite-CANCELLED-with-FAILED (`:117`). |
| `_wave_gate_status` | `str \| None` | `None` (`:54`) | **DEAD STATE** — declared, never read, never written anywhere. Vestige of the scoped-then-dropped `G-WAVE-DC` gate (see design note `:126-133`). GOTCHA: do not wire it to anything; nothing consumes it. |
| `_started_at` | `str` | `""` (`:55`) | Set once at run start (`:73`). Read by `get_status` (`:229`). |
| `_updated_at` | `str` | `""` (`:56`) | Touched (`= _now_iso()`) on virtually every state transition and every signal handler. Read by `get_status` (`:230`). |
| `_wave_id` | `str` | `""` (`:59`) | Set from `input.wave_id` at run start (`:75`). Used by `remove_app` to build the child handle id (`:173`) and by both queries (`:223`, `:241`). |
| `_portfolio_id` | `str` | `""` (`:60`) | Set from `input.portfolio_id` at run start (`:76`). Stored for query handlers; not otherwise read in this file. |

**Local (non-instance) run-scope state:** `semaphore = asyncio.Semaphore(input.max_apps_per_wave)` (`wave.py:83`) and `tasks` (`:123`). The semaphore is a *local variable*, not an instance attr — it lives only for the duration of `run()`.

### 1.2 SIGNALS & QUERIES

**Own signals (defined on the class):**

| Signal | Payload | Handler body | Consumed by |
|---|---|---|---|
| `gate_approved` | `GateApprovedSignal` (`signals.py:25`: `gate_id, approved_by, justification="", card_decisions=[], reviewer_notes=None`) | Accept-and-ignore no-op; sets `_updated_at` only (`wave.py:152-155`). | **Nothing.** Intentional inert handler so a mis-addressed signal is a benign no-op, not an unhandled-signal error (design note `:143-151`). |
| `gate_rejected` | `GateRejectedSignal` (`signals.py:47`: `gate_id, rejected_by, reason, reason_category=None, card_decisions=[], reviewer_notes=None`) | Accept-and-ignore no-op; `_updated_at` only (`:157-160`). | Nothing (same rationale). |
| `remove_app` | `RemoveAppFromWaveSignal` (`types.py:176`: `app_id, reason="", removed_by=""`) | Adds `app_id` to `_removed_apps`, sets `_app_statuses[app_id]=CANCELLED`, touches `_updated_at`, then tries to cancel the child (see §1.4). (`:162-177`) | The two `_removed_apps` checks in `run_one_app` (`:88`, `:117`). |
| `override_approved` | `OverrideApprovedSignal` (`types.py:147`: `gate_id, override_by, justification, override_type: OverrideType`) | No-op; `_updated_at` only (`:179-182`). | Nothing. |
| `escalation_resolved` | `EscalationResolvedSignal` (`types.py:157`: `escalation_id, resolved_by, resolution_type: ResolutionType, resolution`) | No-op; `_updated_at` only (`:184-187`). | Nothing. |
| `stakeholder_approved` | `StakeholderApprovedSignal` (`types.py:167`: `approval_id, stakeholder, scope`) | No-op; `_updated_at` only (`:189-192`). | Nothing. |
| `wave_patterns_ready` | `WavePatternsReadySignal` (`types.py:185`: `wave_id, patterns: list[str]=[]`) | No-op; `_updated_at` only (`:194-197`). | Nothing. |

**GOTCHA:** every wave signal except `remove_app` is inert. Only `remove_app` mutates behavior-affecting state. Do not "helpfully" wire the others up on rebuild — they are deliberately inert (`:143-151`).

**Inherited signals** from `HILSignalsMixin` (`signals.py`): `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`, `cancel_workflow`. These set flags (`plan_approved`, `cancelled`, etc.) but **`WaveWorkflow.run` never consults them** — no `wait_condition` in this file reads `self.cancelled`. So `cancel_workflow` sets `self.cancelled=True` and nothing acts on it. (Contrast `LineWorkflowBase`, whose waits DO consult `self.cancelled`.)

**Queries:**

| Query | Return | Logic |
|---|---|---|
| `get_status()` (`:203-231`) | `WaveStatusResponse` (`types.py:441`) | Recomputes three counts over `_app_statuses.values()` on every call: `completed` = count `== COMPLETED` (`:206-208`); `in_progress` = count `== RUNNING` (`:209-211`); `blocked` = count in `{WAITING_FOR_SIGNAL, FAILED, CANCELLED}` (`:212-220`). Returns `wave_id, status=_status, total_apps=len(_app_statuses), apps_completed, apps_in_progress, apps_blocked, started_at, updated_at`. GOTCHA: `blocked` conflates three very different states (waiting/failed/cancelled) into one number by design. `PENDING` apps count toward `total_apps` but toward none of completed/in-progress/blocked. |
| `get_app_status(app_id: str)` (`:233-242`) | `AppStatusResponse` (`types.py:410`) | `status = _app_statuses.get(app_id, PENDING)` — unknown app id returns `PENDING`, not an error. Returns `app_id, app_name=app_id` (name is NOT resolved — the raw id is echoed), `status`, `workflow_id=f"app-{app_id}-wave-{_wave_id}"`. |

### 1.3 CONTROL FLOW — `run(input: WaveWorkflowInput) -> str` (`wave.py:62-137`)

```
run(input):                                             # input: WaveWorkflowInput (types.py:1226)
    _status = RUNNING                                   # :72
    _started_at = _now_iso()                            # :73
    _updated_at = _started_at                           # :74
    _wave_id = input.wave_id                            # :75
    _portfolio_id = input.portfolio_id                  # :76

    for app_id in input.app_ids:                        # :79  seed statuses
        _app_statuses[app_id] = PENDING                 # :80

    semaphore = asyncio.Semaphore(input.max_apps_per_wave)   # :83  LOCAL var

    # ---- inner coroutine: run_one_app(app_id) ----     :85
    async def run_one_app(app_id):
        async with semaphore:                           # :87  bounded concurrency
            if app_id in _removed_apps:                 # :88  EARLY-RETURN
                return "removed"                        # :89
            _app_statuses[app_id] = RUNNING             # :91
            _updated_at = _now_iso()                    # :92
            try:                                        # :94
                child_input = AppWorkflowInput(         # :95-101
                    app_id=app_id,
                    app_name=app_id,     # id echoed as name; App resolves the real name
                    wave_id=input.wave_id,
                    portfolio_id=input.portfolio_id,
                    artifact_repo=input.artifact_repo,
                )                        # NOTE: disposition/risk_tier/complexity_tier NOT passed → default None
                await workflow.execute_child_workflow(  # :103-108  (blocks until child completes)
                    "AppWorkflow", child_input,
                    id=f"app-{app_id}-wave-{input.wave_id}",
                    task_queue=workflow.info().task_queue,
                )
                _app_statuses[app_id] = COMPLETED       # :110
                _updated_at = _now_iso()                # :111
                return "completed"                      # :112
            except Exception:                           # :113  FAILURE ISOLATION
                if app_id not in _removed_apps:         # :117
                    _app_statuses[app_id] = FAILED      # :118   (else: keep CANCELLED)
                _updated_at = _now_iso()                # :119
                return "failed"                         # :120

    # ---- fan out ----                                  :122
    tasks = [asyncio.ensure_future(run_one_app(a)) for a in input.app_ids]   # :123
    await asyncio.gather(*tasks, return_exceptions=True)                     # :124

    # (No wave-level gate — G-WAVE-DC intentionally NOT implemented; :126-133)

    _status = COMPLETED                                 # :135
    _updated_at = _now_iso()                            # :136
    return "completed"                                  # :137
```

**Branch-by-branch notes:**
- `run_one_app` acquires the semaphore *before* checking `_removed_apps` (`:87` then `:88`). So a removed app still consumes a slot momentarily to observe the removal and return `"removed"`. Removed-before-start apps never transition to RUNNING (early return at `:89`).
- The `except Exception` block (`:113`) catches everything including a child cancellation raised by `remove_app`. The `if app_id not in _removed_apps` guard (`:117`) is exactly what preserves the `CANCELLED` status set by `remove_app` instead of clobbering it with `FAILED`. GOTCHA (race): if the child raises for a *non-removal* reason but `remove_app` fires and adds the id to `_removed_apps` before line `:117` executes, the app is recorded `CANCELLED` (set at `:167`) and the FAILED write is skipped — the removal "wins."
- `asyncio.gather(..., return_exceptions=True)` (`:124`) means a raised exception inside a task is captured as a result object, not propagated — but `run_one_app` already swallows all exceptions in its own `try/except`, so `gather` here essentially just awaits all of them. Wave `run()` therefore **never raises** and always returns `"completed"` regardless of how many apps failed.
- **Wave completion is unconditional:** after all app tasks settle, `_status=COMPLETED` and return `"completed"` (`:135-137`). A wave with every app FAILED still reports wave `COMPLETED`. Failure is surfaced only via per-app `_app_statuses` / the `blocked` count in `get_status`.

### 1.4 `remove_app` child-cancel path (`wave.py:162-177`)

```
remove_app(signal):
    app_id = signal.app_id                              # :165
    _removed_apps.add(app_id)                           # :166
    _app_statuses[app_id] = CANCELLED                   # :167
    _updated_at = _now_iso()                            # :168
    try:                                                # :171
        child_handle = workflow.get_external_workflow_handle(  # :172-174
            f"app-{app_id}-wave-{_wave_id}")
        await child_handle.cancel()                     # :175
    except Exception:
        pass                                            # :176-177  child may not exist yet / already done
```

**GOTCHA (handle id must match the launch id byte-for-byte):** the cancel targets `app-{app_id}-wave-{_wave_id}` (`:173`) which must exactly equal the id used at launch (`:106`). Both derive from the same `wave_id`, so they match — but if a rebuild changes either template it silently fails to cancel (the `except` swallows the "not found"). The cancel is best-effort: any exception (child not yet started, already completed, not found) is swallowed (`:176`). Uses `get_external_workflow_handle` (not the child handle from `execute_child_workflow`) because the handler runs in a different coroutine than `run_one_app`.

### 1.5 RESILIENCE (Wave)
- **No explicit retry policy, timeouts, heartbeats.** `execute_child_workflow` (`:103`) passes only `id` and `task_queue` — no `retry_policy`, no `execution_timeout`, no `run_timeout`. Child failures propagate as the awaited exception and are caught by the failure-isolation block. Child retry/timeout behavior is whatever `AppWorkflow` and its `DiscoveryWorkflow` define internally.
- **No continue-as-new.** Wave history grows with `app_ids` count; there is no history-size guard. For very large waves this is an unmitigated growth path (flag on rebuild).
- **Idempotency:** re-seeding `_app_statuses` is a plain dict assignment; re-running is not designed. The App child id is deterministic per `(app_id, wave_id)`, so a replayed history reproduces identical child ids.
- **No compensation/rollback:** removing an app cancels its child but does not roll back any work the child committed.

---

## 2. `AppWorkflow` — `application.py:43`

`@workflow.defn class AppWorkflow(HILSignalsMixin)` (`application.py:43-44`). Per-application pipeline coordinator. **Today it runs exactly one child (`DiscoveryWorkflow`) and returns.** The docstring's full line ordering (Discovery → Rationalization → [Architecture‖Data] → Modernization → Validation → Deployment; and the Retire/Replace/Retain variant) describes the *intended* progression, but the implemented `run()` stops after Discovery — downstream lines are launched by `WaveRationalizationWorkflow`, not here (`application.py:108-114`).

### 2.1 STATE (`__init__`, `application.py:61-68`)

`super().__init__()` first (`:62`) → HIL state inherited.

| Attr | Type | Initial | Mutated by / when |
|---|---|---|---|
| `_status` | `WorkflowStatus` | `PENDING` (`:64`) | `run()`: `RUNNING` at start (`:81`), `COMPLETED` after Discovery (`:115`). Read by `get_status` (`:171`) and its `progress_pct` ternary (`:174`). Never FAILED here (a Discovery failure raises out of `run()` — see §2.3). |
| `_current_line` | `AssemblyLine \| None` | `None` (`:65`) | Set to `AssemblyLine.DISCOVERY` (`enums.py:312`, value `"Discovery"`) at `:86`; reset to `None` at `:117`. Read by `get_status` (`:172`). |
| `_current_step` | `str` | `""` (`:66`) | `"discovery"` at `:87`; `"discovery_complete"` at `:116`. Read by `get_status` (`:173`). |
| `_started_at` | `str` | `""` (`:67`) | Set once at run start (`:82`). Read by `get_status` (`:175`). |
| `_updated_at` | `str` | `""` (`:68`) | Touched on each transition and every signal handler. Read by `get_status` (`:176`). |

### 2.2 SIGNALS & QUERIES

**Own signals** — payload types identical to the Wave equivalents:

| Signal | Payload | Body | Consumed by |
|---|---|---|---|
| `gate_approved` | `GateApprovedSignal` | no-op, `_updated_at` (`:132-135`) | Nothing (inert; design note `:125-131`). |
| `gate_rejected` | `GateRejectedSignal` | no-op, `_updated_at` (`:137-140`) | Nothing. |
| `override_approved` | `OverrideApprovedSignal` | no-op, `_updated_at` (`:142-145`) | Nothing. |
| `escalation_resolved` | `EscalationResolvedSignal` | no-op, `_updated_at` (`:147-150`) | Nothing. |
| `stakeholder_approved` | `StakeholderApprovedSignal` | no-op, `_updated_at` (`:152-155`) | Nothing. |
| `wave_patterns_ready` | `WavePatternsReadySignal` | no-op, `_updated_at` (`:157-160`) | Nothing. |

**AppWorkflow has NO `remove_app` signal** — removal is a wave-grain operation. To stop an app you cancel it via the wave's `remove_app` (which cancels the App child externally). GOTCHA: do not add `remove_app` to AppWorkflow; the wave owns removal.

**Inherited signals** (same list as Wave). Again, `run()` consults none of them — no `wait_condition` reads `self.cancelled`. The only thing that stops an in-flight AppWorkflow is external cancellation (from the wave's `child_handle.cancel()`), which manifests as a `CancelledError` propagating out of the awaited child.

**Query:**

| Query | Return | Logic |
|---|---|---|
| `get_status()` (`:166-177`) | `WorkflowStatusResponse` (`types.py:396`) | `workflow_id=workflow.info().workflow_id`, `status=_status`, `current_line=_current_line`, `current_step=_current_step`, `progress_pct = 100.0 if _status==COMPLETED else 0.0` (`:174` — binary, never intermediate), `started_at`, `updated_at`. `pending_gate` is left at its default `None` (never set — AppWorkflow awaits no gate). |

### 2.3 CONTROL FLOW — `run(input: AppWorkflowInput) -> str` (`application.py:71-119`)

```
run(input):                                             # input: AppWorkflowInput (types.py:1238)
    _status = RUNNING                                   # :81
    _started_at = _now_iso()                            # :82
    _updated_at = _started_at                           # :83

    # -- Step 1: Discovery --
    _current_line = AssemblyLine.DISCOVERY              # :86
    _current_step = "discovery"                         # :87
    _updated_at = _now_iso()                            # :88

    discovery_input = LineWorkflowInput(                # :90-99
        app_id=input.app_id,
        app_name=input.app_name,
        wave_id=input.wave_id,
        portfolio_id=input.portfolio_id,
        artifact_repo=input.artifact_repo,
        disposition=input.disposition,        # forwarded (may be None from wave)
        risk_tier=input.risk_tier,            # forwarded (may be None)
        complexity_tier=input.complexity_tier,# forwarded (may be None)
    )
    await workflow.execute_child_workflow(              # :101-106  BLOCKS until Discovery completes
        "DiscoveryWorkflow", discovery_input,
        id=f"discovery-{input.app_id}",
        task_queue=workflow.info().task_queue,
    )
    # (Rationalization + downstream lines intentionally NOT started here; :108-114)

    _status = COMPLETED                                 # :115
    _current_step = "discovery_complete"                # :116
    _current_line = None                                # :117
    _updated_at = _now_iso()                            # :118
    return "completed"                                  # :119
```

**Branch-by-branch notes:**
- **There are NO branches.** `run()` is a straight-line sequence: set RUNNING, run Discovery, set COMPLETED. There is no disposition/tier/gate switch here — despite the docstring's disposition-dependent line ordering, the *implemented* body ignores `input.disposition` entirely for control flow (it is only forwarded into `discovery_input`). A rebuild MUST reproduce this: AppWorkflow does not branch on disposition today.
- **No try/except around the Discovery child** (`:101-106`). If `DiscoveryWorkflow` fails or is cancelled, the exception propagates straight out of `AppWorkflow.run` → the App workflow fails/cancels. `_status` is NOT set to FAILED (the lines after the await never execute). GOTCHA: this is exactly why the wave wraps the App child in its own `try/except` (`wave.py:113`) — failure isolation lives at the wave grain, not here.
- The three-way `disposition`/`risk_tier`/`complexity_tier` forwarding uses whatever the wave passed. The wave's `run_one_app` (`wave.py:95-101`) does NOT pass these, so they arrive as `None`. So in the current spine, Discovery is always started with `disposition=None, risk_tier=None, complexity_tier=None`. (A direct start of AppWorkflow with a populated input would forward them.)

### 2.4 RESILIENCE (App)
- **No retry policy / timeout / heartbeat** on the Discovery child (`:101-106` passes only `id`+`task_queue`). `RETRY_POLICIES` is imported (`application.py:27`) but **unused** here (`# noqa: F401`) — GOTCHA: the import is a vestige; do not assume a retry policy is applied.
- **No continue-as-new**, no compensation. Because `run()` is single-child straight-line, history is bounded and small.
- **Idempotency:** deterministic child id `discovery-{app_id}` (see §0 collision GOTCHA).

---

## 3. `PortfolioWorkflow` — `portfolio.py:23` (STUB / interface only)

`@workflow.defn class PortfolioWorkflow(HILSignalsMixin)` (`portfolio.py:23-24`). Registered with the worker (`worker.py:192`). **Not implemented.**

### 3.1 STATE (`__init__`, `portfolio.py:38-39`)
`__init__` calls only `super().__init__()` (`:39`) → HIL state. **No own instance variables.** A future implementation must add portfolio state (e.g. wave statuses, `_portfolio_id`) itself.

### 3.2 SIGNALS & QUERIES — all raise
Every member body is `raise NotImplementedError`:

| Member | Kind | Payload / return | Body |
|---|---|---|---|
| `run(input: PortfolioWorkflowInput)` | `@workflow.run` | → `str` | `raise NotImplementedError("PortfolioWorkflow.run is a stub interface")` (`:41-43`) |
| `gate_approved` | signal | `GateApprovedSignal` | `raise NotImplementedError` (`:47-49`) |
| `gate_rejected` | signal | `GateRejectedSignal` | `raise NotImplementedError` (`:51-53`) |
| `override_approved` | signal | `OverrideApprovedSignal` | `raise NotImplementedError` (`:55-57`) |
| `escalation_resolved` | signal | `EscalationResolvedSignal` | `raise NotImplementedError` (`:59-61`) |
| `stakeholder_approved` | signal | `StakeholderApprovedSignal` | `raise NotImplementedError` (`:63-65`) |
| `wave_patterns_ready` | signal | `WavePatternsReadySignal` | `raise NotImplementedError` (`:67-69`) |
| `get_status` | query | → `PortfolioStatusResponse` (`types.py:426`) | `raise NotImplementedError` (`:73-75`) |
| `get_app_status(app_id: str)` | query | → `AppStatusResponse` (`types.py:410`) | `raise NotImplementedError` (`:77-79`) |

**Input:** `PortfolioWorkflowInput` (`types.py:1214`): `portfolio_id, portfolio_name, artifact_repo="", profile_id="", max_concurrent_waves=MAX_CONCURRENT_WAVES(4), max_apps_per_wave=MAX_APPS_PER_WAVE(10)`.

**GOTCHA — signal handlers must NOT raise in a real implementation.** The *interface* defines these method names as the replay contract (`signals.py:11-12`: signal method names are preserved byte-for-byte). But a live `@workflow.signal` handler that raises `NotImplementedError` would fail signal processing (Temporal treats a raising signal handler as a workflow task failure that retries indefinitely). So this stub is safe ONLY because it is never started. When implemented, the signal handler *names* must be kept identical (replay contract) but the bodies must be replaced with real logic. The intended hierarchy (`portfolio.py:29`): PortfolioWorkflow → WaveWorkflow (max 4 concurrent) → AppWorkflow, with responsibilities: wave planning/sequencing, spawning WaveWorkflow children with concurrency limits, cross-wave status aggregation (`portfolio.py:31-36`).

---

## 4. Inherited signals (all three classes) — `HILSignalsMixin` (`signals.py:19-106`)

Set by `super().__init__()`; these are the *base* signal surface every spine class carries whether it uses them or not.

**Inherited state (`signals.py:29-45`):** `approved:bool=False`, `plan_approved:bool=False`, `plan_feedback_received:bool=False`, `plan_feedback_comments:str=""`, `document_approved:bool=False`, `document_feedback_received:bool=False`, `document_feedback_comments:str=""`, `cancelled:bool=False`.

**Inherited signals:**
- `approve_plan()` (`:48-53`) → `plan_approved=True`, clears plan feedback.
- `provide_plan_feedback(comments:str)` (`:55-60`) → `plan_feedback_received=True`, stores comments, `plan_approved=False`.
- `approve_research()` (`:63-68`) → `document_approved=True`, clears doc feedback.
- `provide_feedback(comments:str)` (`:70-75`) → `document_feedback_received=True`, stores comments, `document_approved=False`.
- `approve()` (`:78-81`) → `approved=True`.
- `cancel_workflow()` (`:83-85`) → `cancelled=True`.

Helper (non-signal) methods also inherited: `reset_plan_feedback`, `reset_document_feedback`, `is_plan_decision_received`, `is_document_decision_received` (`:89-105`).

**GOTCHA:** none of the three spine classes' `run()` methods read any HIL flag — no `workflow.wait_condition(lambda: self.cancelled)` anywhere in the three files. So on the spine, `cancel_workflow`/`approve`/etc. mutate state that is never consulted. (This is the key behavioral divergence from `LineWorkflowBase`, whose waits DO consult `self.cancelled` — see `_base-workflow.md` §1.2.) These handlers are inherited (not overridden) and must keep their names for replay compatibility.

---

## 5. Gate handling (spine)

**There is none at the spine grain — and that is the load-bearing design.** (`wave.py:126-151`, `application.py:108-131`.)
- No evidence assembly, no `_wait_for_gate_decision`, no rework loop, no rework counters exist in these three files.
- Gate signals (`gate_approved`/`gate_rejected`/`override_approved`) are accept-and-ignore no-ops so a mis-addressed signal is a benign no-op rather than an "unhandled signal" error.
- The scoped-but-dropped `G-WAVE-DC` wave-level gate (P5-S30.6, decided 2026-06-09) was intentionally NOT implemented; `_wave_gate_status` is its only vestige and is dead (`wave.py:54`).
- Actual gates live in the children: `DiscoveryWorkflow` (owns G-DC) and the per-line workflows spawned by `WaveRationalizationWorkflow`. The API signals the gate-owning workflow directly by the `workflow_id` stored on the gate row (`send_gate_temporal_signal`), never fans out through the spine. To reproduce gate behavior, see the per-line workflow docs and `_base-workflow.md`.

---

## 6. Behavioral parity checklist

A rebuild of the orchestration spine MUST satisfy every assertion below.

**WaveWorkflow:**
1. `run()` returns `"completed"` and sets `_status=COMPLETED` **unconditionally** after all app tasks settle — even if every app FAILED. It never raises and never sets a wave-grain FAILED.
2. Concurrency is bounded by `asyncio.Semaphore(input.max_apps_per_wave)` (default 10), created as a run-local variable, not an instance attr.
3. Each app runs as one `AppWorkflow` child with id `app-{app_id}-wave-{wave_id}` on `workflow.info().task_queue`, launched by the string name `"AppWorkflow"`, awaited to completion.
4. `run_one_app` acquires the semaphore BEFORE checking `_removed_apps`; a removed-before-start app returns `"removed"` without transitioning to RUNNING.
5. On child exception, the app is marked `FAILED` **only if** `app_id not in _removed_apps`; otherwise the `CANCELLED` status set by `remove_app` is preserved.
6. `remove_app` adds to `_removed_apps`, sets `_app_statuses[app_id]=CANCELLED`, and best-effort cancels the external child `app-{app_id}-wave-{wave_id}` inside a try/except that swallows all exceptions.
7. `get_status` recomputes counts live: completed=`COMPLETED`, in_progress=`RUNNING`, blocked=`{WAITING_FOR_SIGNAL,FAILED,CANCELLED}`; `total_apps=len(_app_statuses)`; PENDING apps count only toward total.
8. `get_app_status` echoes `app_name=app_id` (no name resolution), returns `PENDING` for unknown ids, and builds `workflow_id=f"app-{app_id}-wave-{wave_id}"`.
9. All six gate/override/escalation/stakeholder/patterns signals except `remove_app` are inert no-ops touching only `_updated_at`.
10. All timestamps derive from `workflow.now().isoformat()`.

**AppWorkflow:**
11. `run()` is straight-line: RUNNING → run one `DiscoveryWorkflow` child (id `discovery-{app_id}`, string name `"DiscoveryWorkflow"`, awaited) → COMPLETED; returns `"completed"`.
12. `run()` does NOT branch on `disposition`/`risk_tier`/`complexity_tier`; it forwards them into `LineWorkflowInput` unchanged (they arrive `None` from the wave path).
13. No try/except around the Discovery child — a Discovery failure/cancel propagates out of `run()` and `_status` is NOT flipped to COMPLETED/FAILED.
14. No `remove_app` signal on AppWorkflow.
15. `get_status.progress_pct` is exactly `100.0` when COMPLETED else `0.0` (binary); `pending_gate` stays `None`.
16. `RETRY_POLICIES` import is unused; no retry policy/timeout/heartbeat is applied to the Discovery child.

**PortfolioWorkflow:**
17. Every `run`/signal/query body raises `NotImplementedError` (run with the exact message `"PortfolioWorkflow.run is a stub interface"`); it is registered but never started.
18. `__init__` calls only `super().__init__()` and defines no own state.

**All three:**
19. Each extends `HILSignalsMixin` (not `LineWorkflowBase`); `__init__` calls `super().__init__()` first, and the inherited HIL signal method names are preserved verbatim.
20. No `continue_as_new`, no `_wait_for_gate_decision`, no gate/rework machinery, and no `wait_condition` consulting `self.cancelled` appears in any of the three files.
21. Child workflows are launched with only `id` + `task_queue` (from `workflow.info().task_queue`) — no `parent_close_policy`, `id_reuse_policy`, `retry_policy`, or timeouts passed (all default).
