# ValidationWorkflow — Atomic Regeneration Spec

Source of truth: `temporal/olympus_workflows/workflows/validation.py` (1440 lines).
Base class: `LineWorkflowBase` (`temporal/olympus_workflows/workflows/base.py`) via `HILSignalsMixin` (`temporal/olympus_workflows/temporal_base/signals.py`). See `_base-workflow.md` for inherited machinery; this doc captures every override + the full `run()` body.

`@workflow.defn class ValidationWorkflow(LineWorkflowBase)` — `validation.py:217-218`.

Purpose: per-target-app orchestration of the Validation assembly line, canonical 18-step shape (`validation.py:1-55`). Runs once per target after Modernization's G-04c approves. Gates: **G-V1** (automated functional parity), **G-V2** (compliance + security + accessibility rolled up), **G-V3** (safety — Tier-1 only). Terminal step emits `ValidationApprovedSignal` to Deployment.

---

## 0. Module-level constants (must be reproduced exactly)

- `VALIDATION_STEPS: dict[str, dict]` — `validation.py:118-148`. Keys and values:
  - `"functional-parity"`: `{title:"Functional Parity Verification", skills:["parity-verifier","acceptable-divergences"], artifact:"parity-report.json", kind:"agent"}` (`:123-128`)
  - `"security-compliance"`: `{title:"Security & Compliance Assessment", skills:["security-scan-review","cato-evidence-validator"], artifact:"security-assessment-report.json", kind:"agent"}` (`:129-134`)
  - `"accessibility-ux"`: `{title:"Accessibility & UX Audit", skills:["accessibility-checker","design-system"], artifact:"accessibility-audit.json", kind:"agent"}` (`:135-140`)
  - `"safety-assurance"`: `{title:"Safety Assurance", skills:["safety-critical-verifier","traceability-checker"], artifact:"safety-case.json", kind:"agent"}` (`:142-147`)
  - GOTCHA: `VALIDATION_STEPS` only contains the 4 **agent** stream roots — NOT the code/git/gate step ids (`intake`, `bundle-*`, `create-*-pr`, `gate-review-*`, etc.). Those live only in `STEP_WEIGHTS`. `_dispatch_agent`/`_commit_step_artifacts`/`_build_evidence_data` index `VALIDATION_STEPS[step_name]` and would `KeyError` for a non-stream step — but they are only ever called with the 4 stream names.
- `PARALLEL_STREAMS = ["functional-parity","security-compliance","accessibility-ux"]` — `validation.py:151-155`. The three always-on parallel streams.
- `TIER1_STEP = "safety-assurance"` — `validation.py:158`.
- `STEP_WEIGHTS: dict[str,float]` — `validation.py:164-183`. Values (insertion order matters — see `_progress_at`): intake 2.0, functional-parity 18.0, security-compliance 18.0, accessibility-ux 18.0, bundle-g-v1-evidence 2.0, create-g-v1-pr 2.0, gate-review-v1 4.0, bundle-g-v2-evidence 2.0, create-g-v2-pr 2.0, ai-pre-review-v2 2.0, gate-review-v2 6.0, safety-assurance 12.0, bundle-g-v3-evidence 1.0, create-g-v3-pr 1.0, ai-pre-review-v3 2.0, gate-review-v3 4.0, persist-validation-side-effects 2.0, merge-final-gate-pr 2.0. Module-import assertion: `abs(sum - 100.0) < 0.01` (`:184-186`).
- `MAX_REWORK_ITERATIONS = 3` — `validation.py:188`.
- `GATE_EVIDENCE_CATALOG_ID = "nist-800-53-rev5"` — `validation.py:199`.
- `GATE_ASSESSMENT_CONTROLS: dict[str, tuple[str,str]]` — `validation.py:200-205`: `{ G_V1.value: ("CA-2","CA"), G_V2.value: ("CA-2","CA"), G_V3.value: ("CA-7","CA") }`. Used by `_emit_gate_evidence`; `.get(gate.value, ("CA-2","CA"))` default.
- `PARITY_THRESHOLDS: dict[int|None,float]` — `validation.py:209-214`: `{1:99.0, 2:98.0, 3:95.0, None:98.0}`. Tier-1 ≥99%, Tier-2 ≥98%, Tier-3 ≥95%, unclassified ≥98%.

### LineWorkflowBase classvar configuration — `validation.py:234-239`
`ASSEMBLY_LINE = AssemblyLine.VALIDATION`; `ARTIFACT_ROOT = "validation"`; `LINE_LABEL = "Validation"`; `STATUS_PREFIX = "validation"`; `STEPS = VALIDATION_STEPS`; `STEP_WEIGHTS = STEP_WEIGHTS`. `SINGLE_GATE_KEY` NOT set (defaults `None`) — Validation overrides `_rework_gate_key_for_step`. `_task_type_prefix()` inherited → returns `"validation"` (so `_dispatch_agent` builds `task_type = "validation-{step_name}"`).

---

## 1. STATE

### Inherited from `HILSignalsMixin.__init__` (signals.py:29-45)
`approved=False`, `plan_approved=False`, `plan_feedback_received=False`, `plan_feedback_comments=""`, `document_approved=False`, `document_feedback_received=False`, `document_feedback_comments=""`, **`cancelled: bool = False`** (mutated by `cancel_workflow` signal; read by every gate/stakeholder/merge wait predicate).

### Inherited from `LineWorkflowBase.__init__` (base.py:136-191)
- `_app_id: str = ""` — set to `input.app_id` at run start (`validation.py:349`).
- `_portfolio_id: str = ""` — NOTE: Validation NEVER sets this. Consequence: `_execution_ctx` returns `None` for every activity (base.py:345-346), so Layer-B step_execution rows are not emitted for this workflow. GOTCHA: contrast with sibling lines that hydrate `_portfolio_id`; `portfolio_id` still flows to gate records via `input.portfolio_id` directly.
- `_wave_id: str = ""` — never set by Validation.
- `_status: WorkflowStatus = PENDING` — mutated: `RUNNING` at `:344`; `WAITING_FOR_SIGNAL`/`RUNNING` inside `_wait_for_gate_decision`; `CANCELLED` at `:629,785`; `FAILED` at `:375` (run except) and `:1324` (`_fail`); `COMPLETED` at `:883`.
- `_current_step: str = ""` — set by every `_set_step`; `"failed"` at `:376`; `reason_step` at `:1325`; `"completed"` at `:885`.
- `_progress_pct: float = 0.0` — set by `_set_step`; forced `100.0` at `:884`.
- `_pending_gate: GateType|None = None` — set in `_wait_for_gate_decision` (base.py:1114) and cleared (base.py:1140).
- `_started_at: str = ""` — set `_now_iso()` at `:345`.
- `_updated_at: str = ""` — refreshed pervasively.
- `_gate_decisions: list[tuple] = []` — appended by `gate_approved` (5-tuple, base.py:200-208) / `gate_rejected` (5-tuple, base.py:223-231). Consumed in `_wait_for_gate_decision`.
- `_gate_decisions_consumed: int = 0` — advanced one per consumed decision (base.py:1138).
- `_rework_feedback: dict[str,dict] = {}` — keyed by gate value; set on reject / popped on approve in `_wait_for_gate_decision`; read by `_dispatch_agent` via `_rework_gate_key_for_step`.
- `_rework_iterations: dict[str,int] = {}` — per-gate counter; `_bump_rework`/`_rework_count`.
- `_step_results: dict[str,list[str]] = {}` — set to `result.output_artifacts` for each stream (`:927,975`); read by `_first_output`, `_parity_meets_threshold`, `_build_evidence_data`, persist step.
- `_step_committed_paths: dict[str,list[str]] = {}` — set by `_commit_step_artifacts` (base.py:872); read for evidence assembly, cato inputs, output_refs.
- `_agent_metadata: dict[str,dict] = {}` — set by `_dispatch_agent` (base.py:494-501).
- `_risk_tier: int|None = None` — set at `:353-355` from `int(input.risk_tier)` or `None`.
- `_merge_retry_signalled: bool = False` — set by `merge_retry` signal; consumed by `_reconcile_and_merge_with_retry_loop`.
- `_profile_id: str = ""` — NOTE: Validation never calls `_load_delegation_config`, so this stays `""`; passed to `emit_evidence` as `self._profile_id or None` → `None` (`:1041`).
- `_portfolio_fallback_policy: str = "internal_fallback"`; `_redispatch_guard: set = set()` — unused (Validation never delegates bundles).

### Own state — `ValidationWorkflow.__init__` (validation.py:241-267)
Calls `super().__init__()` first (`:242`).
- `_stakeholder_compliance_approved: bool = False` (`:245`) — set True by `stakeholder_approved(scope="g-v2-compliance")`; consumed by Tier-1 G-V2 wait predicate (`:622`).
- `_stakeholder_security_approved: bool = False` (`:246`) — set True by scope `"g-v2-security"`; G-V2 wait predicate (`:623`).
- `_stakeholder_safety_approved: bool = False` (`:247`) — set True by scope `"g-v3-safety"`; G-V3 wait predicate (`:778`); **reset to False** on G-V3 rejection (`:769`).
- `_stakeholder_cert_approved: bool = False` (`:248`) — set True by scope `"g-v3-cert"`; G-V3 wait predicate (`:779`); **reset to False** on G-V3 rejection (`:770`).
  - GOTCHA: All four flags are only consulted when `self._risk_tier == 1`. Tier-2/Tier-3 ignore them entirely (`:230`, `:618`).
- `_stream_status: dict[str,str] = {s:"queued" for s in PARALLEL_STREAMS}` (`:251-253`) — per-stream marker. Mutated: `"running"` when a parallel run starts (`:914`); `"completed"`/`"failed"` inside `_run_stream` (`:935,938`).
- `_stream_started_at: dict[str,str] = {}` (`:254`) — set `_now_iso()` at `:915`.
- `_stream_completed_at: dict[str,str] = {}` (`:255`) — set on stream completion or failure (`:936,939`).
- `_safety_case_ref: str = ""` (`:258`) — set at `:681-684` to `f"validation/{app_id}/{VALIDATION_STEPS[TIER1_STEP]['artifact']}"` = `validation/{app_id}/safety-case.json`; threaded to persist step (`:823`).
- `_cato_paths: dict[str,list[str]] = {}` (`:262`) — keyed by stage `"G-V1"|"G-V2"|"G-V3"`; set only after a successful cato commit (`:1188`). Read for evidence path unions and to decide which cATO ssp/sar/poam path strings persist (`:829,834,839`).
- `_cato_target_uuid: str = ""` (`:263`) — set to `app_id` in `_dispatch_cato_evidence` (`:1104-1105`). Read at `:812`.
- `_cato_evidence_records: list[str] = []` (`:267`) — raw JSON contents of files whose path contains `/evidence/`; set at `:1198-1199` (only if non-empty). Serialized into persist input (`:842-846`).
- `_cato_highest_stage: str = ""` (`:268`) — set to `stage` on each successful cato commit (`:1189`); threaded to persist (`:826`).

---

## 2. SIGNALS & QUERIES

### Own signal — `stakeholder_approved` (validation.py:309-335)
- Decorator `@workflow.signal`; async; payload `signal: StakeholderApprovedSignal` (dataclass `approval_id, stakeholder, scope` — types.py:167-173).
- Body: reads `scope = signal.scope`, then:
  - `if scope == "g-v2-compliance"`: `_stakeholder_compliance_approved = True` (`:322-323`)
  - `elif scope == "g-v2-security"`: `_stakeholder_security_approved = True` (`:324-325`)
  - `elif scope == "g-v3-safety"`: `_stakeholder_safety_approved = True` (`:326-327`)
  - `elif scope == "g-v3-cert"`: `_stakeholder_cert_approved = True` (`:328-329`)
  - `else`: `workflow.logger.warning(..., extra={"scope":scope})` — unknown scopes logged and ignored (`:330-334`).
  - Always: `self._updated_at = _now_iso()` (`:335`).
- Consumed by wait_conditions:
  - G-V2 (Tier-1): `lambda: (self._stakeholder_compliance_approved and self._stakeholder_security_approved) or self.cancelled` (`:619-627`).
  - G-V3 (Tier-1): `lambda: (self._stakeholder_safety_approved and self._stakeholder_cert_approved) or self.cancelled` (`:775-782`).

### Inherited signals (base.py) — MUST NOT be overridden by subclasses (base.py:11-13, 116-118: re-decoration duplicate-registers in Temporal)
- `gate_approved(GateApprovedSignal)` (base.py:197-209): appends 5-tuple `(GateStatus.APPROVED, approved_by, justification, None, [])` to `_gate_decisions`; refresh `_updated_at`.
- `gate_rejected(GateRejectedSignal)` (base.py:211-232): normalizes `card_decisions = list(getattr(signal,"card_decisions",[]) or [])`, `reason_category = getattr(signal,"reason_category",None)`; appends `(GateStatus.REJECTED, rejected_by, reason, reason_category, card_decisions)`.
- `escalation_resolved(EscalationResolvedSignal)` (base.py:234-239): only refreshes `_updated_at`.
- `merge_retry(GateMergeRetrySignal)` (base.py:241-257): sets `_merge_retry_signalled = True`; idempotent no-op if already True.
- From HILSignalsMixin (signals.py): `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`, `cancel_workflow` (sets `cancelled=True`). Only `cancel_workflow` is load-bearing for Validation (drives every cancellation branch).

### Query — `get_status` (base.py:1353-1365)
`@workflow.query` returns `WorkflowStatusResponse(workflow_id, status=_status, current_line=ASSEMBLY_LINE, current_step=_current_step, progress_pct=_progress_pct, pending_gate=_pending_gate, started_at, updated_at)`. Validation does not override.

---

## 3. CONTROL FLOW

### `run(self, input: LineWorkflowInput) -> str` (validation.py:341-387)
```
@workflow.run
async run(input):
    _status = RUNNING                         # :344
    _started_at = _now_iso(); _updated_at = _started_at   # :345-346
    app_id = input.app_id; _app_id = app_id   # :348-349
    _risk_tier = int(input.risk_tier) if input.risk_tier is not None else None  # :353-355
    is_tier_1 = (_risk_tier == 1)             # :356
    wf_id = workflow.info().workflow_id       # :358
    run_suffix = wf_id.rsplit("-",1)[-1] if "-" in wf_id else wf_id[:8]  # :359
    branch = f"olympus/validation/{app_id}/{run_suffix}"    # :360
    workspace_key = f"validation-{app_id}-{run_suffix}"     # :361
    repo = getattr(input,"target_repo_url","") or input.artifact_repo   # :365-368  (W19 repo-split; falls back to artifact_repo)
    try:
        return await _execute_validation(input, app_id, repo, branch, workspace_key, is_tier_1)   # :371-373
    except Exception:                          # :374
        _status = FAILED; _current_step = "failed"; _updated_at = _now_iso()   # :375-377
        try: await _update_app_status(app_id, "validation_failed", "failed", "Validation")  # :378-381
        except Exception: pass  # best-effort   # :382-383
        raise                                   # :384
```
GOTCHA: the outer `except` is the catch-all for stream `asyncio.gather` failures, cato non-recoverable paths (none — cato is best-effort), and any activity error not caught inside helpers. The status-update failure is swallowed but the original exception always re-raises (workflow fails).

### `_execute_validation(input, app_id, repo, branch, workspace_key, is_tier_1) -> str` (validation.py:386-887)
```
prior_artifacts = list(input.prior_artifacts)           # :396

# STEP 1 — intake
await _set_step("intake", STEP_WEIGHTS["intake"])       # :399  (progress 2.0)

# ===== G-V1 / G-V2 gate loop =====
while True:                                              # :406
    # STEPS 2-4 — three parallel streams
    await _run_parallel_streams(app_id, repo, branch, workspace_key, prior_artifacts)  # :408-410

    # STEP 5 — bundle G-V1 evidence
    await _set_step("bundle-g-v1-evidence", _progress_at("bundle-g-v1-evidence"))      # :413-416
    await _dispatch_cato_evidence(app_id, repo, branch, workspace_key,
        stage="G-V1", input_artifacts=_step_committed_paths.get("security-compliance", []))  # :419-425
    gv1_evidence_paths = dedup_paths(
        _step_committed_paths.get("functional-parity", []) + _cato_paths.get("G-V1", []))     # :426-429

    # STEP 6 — create G-V1 PR
    await _set_step("create-g-v1-pr", _progress_at("create-g-v1-pr"))                   # :432-434
    gv1_pr = await _create_gate_pr(repo, branch, app_id,
        gate_type=G_V1.value,
        title=f"Gate G-V1: Functional Parity — {app_id}",
        body=_build_gv1_pr_body(app_id))                                               # :435-440
    gv1_record = await execute_activity(create_gate_record,
        CreateGateRecordInput(gate_type=G_V1.value, app_id, portfolio_id=input.portfolio_id,
            workflow_id=workflow.info().workflow_id, evidence_package_url=gv1_pr.pr_url),
        start_to_close=30s, retry=transient)                                           # :441-452
    await _submit_gate_evidence(gate_id=gv1_record.gate_id, gate_type=G_V1, app_id,
        artifact_paths=dedup_paths(gv1_evidence_paths), pr_url=gv1_pr.pr_url,
        assembly_line="Validation", step="gate-review-v1")                             # :453-461
    await _run_gate_pre_review(gv1_record.gate_id, G_V1.value, dedup_paths(gv1_evidence_paths),
        artifact_repo=repo, artifact_ref=branch)                                       # :469-475
        # GOTCHA (:462-468): G-V1 pre-review is what flips gate preparing→pending
        # (via mark-gate-ready-for-review inside _run_gate_pre_review.finally). Without
        # it G-V1 would dead-end waiting on a signal that can never arrive.

    # STEP 7 — Gate G-V1 (automated pass/fail)
    await _set_step("gate-review-v1", _progress_at("gate-review-v1"))                   # :484-486
    if not _parity_meets_threshold():                                                  # :487
        logger.info("G-V1 auto-rejected — parity below threshold", ...)               # :488-494
        _bump_rework("G-V1")                                                           # :495
        if _rework_count("G-V1") > MAX_REWORK_ITERATIONS:                              # :496
            return await _fail("max-rework-exceeded-gv1", app_id)                      # :497-499
        continue   # re-enter stream dispatch                                          # :500
    gv1_decision = await _wait_for_gate_decision(G_V1)                                 # :502
    if gv1_decision == "cancelled": return "cancelled"                                 # :503-504
    if gv1_decision == "rejected":                                                     # :505
        _bump_rework("G-V1")                                                           # :506
        if _rework_count("G-V1") > MAX_REWORK_ITERATIONS:
            return await _fail("max-rework-exceeded-gv1", app_id)                      # :507-510
        continue                                                                       # :511
    # --- approved path ---
    await _emit_gate_evidence(gate_type=G_V1, gate_id=gv1_record.gate_id, app_id,
        portfolio_id=input.portfolio_id, decision=gv1_decision)  # FAIL-CLOSED FIRST   # :519-525
    await _reconcile_and_merge_with_retry_loop(repo, pr_number=gv1_pr.pr_number,
        gate_id=gv1_record.gate_id, merge_method="merge")                             # :526-531
    await _update_app_status(app_id, "validation_parity_approved", "gate-review-v1", "Validation")  # :532-535

    # STEP 8 — bundle G-V2 evidence
    await _set_step("bundle-g-v2-evidence", _progress_at("bundle-g-v2-evidence"))      # :538-541
    await _dispatch_cato_evidence(app_id, repo, branch, workspace_key, stage="G-V2",
        input_artifacts=dedup_paths(_step_committed_paths.get("security-compliance",[]) + _cato_paths.get("G-V1",[])))  # :543-550
    gv2_evidence_paths = dedup_paths(
        _step_committed_paths.get("security-compliance",[]) + _step_committed_paths.get("accessibility-ux",[]) + _cato_paths.get("G-V2",[]))  # :551-555

    # STEP 9 — create G-V2 PR
    await _set_step("create-g-v2-pr", _progress_at("create-g-v2-pr"))                  # :558-560
    gv2_pr = await _create_gate_pr(..., gate_type=G_V2.value,
        title=f"Gate G-V2: Compliance & Security — {app_id}", body=_build_gv2_pr_body(app_id))  # :561-566
    gv2_record = await execute_activity(create_gate_record, CreateGateRecordInput(G_V2.value,...evidence_package_url=gv2_pr.pr_url), 30s, transient)  # :567-578
    await _submit_gate_evidence(gv2_record.gate_id, G_V2, app_id, gv2_evidence_paths, gv2_pr.pr_url, "Validation", "gate-review-v2")  # :579-587
        # NOTE: gv2 artifact_paths passed NOT re-deduped (already deduped at :551).

    # STEP 10 — AI pre-review G-V2
    await _set_step("ai-pre-review-v2", _progress_at("ai-pre-review-v2"))              # :590-592
    await _run_gate_pre_review(gv2_record.gate_id, G_V2.value, gv2_evidence_paths, artifact_repo=repo, artifact_ref=branch)  # :593-599

    # STEP 11 — Gate G-V2
    await _set_step("gate-review-v2", _progress_at("gate-review-v2"))                  # :602-604
    gv2_decision = await _wait_for_gate_decision(G_V2)                                 # :605
    if gv2_decision == "cancelled": return "cancelled"                                 # :606-607
    if gv2_decision == "rejected":                                                     # :608
        _bump_rework("G-V2")
        if _rework_count("G-V2") > MAX_REWORK_ITERATIONS:
            return await _fail("max-rework-exceeded-gv2", app_id)                      # :609-613
        continue                                                                       # :614
    # --- approved: Tier-1 triple-signal wait ---
    if _risk_tier == 1:                                                                # :618
        await workflow.wait_condition(
            lambda: (_stakeholder_compliance_approved and _stakeholder_security_approved) or self.cancelled)  # :619-627
        if self.cancelled:
            _status = CANCELLED; return "cancelled"                                    # :628-630
    await _emit_gate_evidence(G_V2, gv2_record.gate_id, app_id, input.portfolio_id, gv2_decision)  # FAIL-CLOSED FIRST  # :635-641
    await _reconcile_and_merge_with_retry_loop(repo, gv2_pr.pr_number, gv2_record.gate_id, "merge")  # :642-647
    await _update_app_status(app_id, "validation_compliance_approved", "gate-review-v2", "Validation")  # :648-651
    break   # exit G-V1/G-V2 loop                                                      # :652

final_pr = gv2_pr    # Tier-2/3 final gate; Tier-1 overrides below                     # :656

# ===== STEPS 12-16 — Safety + G-V3 (Tier-1 only) =====
if is_tier_1:                                                                          # :659
    while True:                                                                        # :660
        # STEP 12 — safety-assurance stream
        await _run_safety_stream(app_id, repo, branch, workspace_key,
            dedup_paths(list(input.prior_artifacts) + _step_committed_paths.get("functional-parity",[])
              + _step_committed_paths.get("security-compliance",[]) + _step_committed_paths.get("accessibility-ux",[])))  # :662-679
        _safety_case_ref = f"validation/{app_id}/{VALIDATION_STEPS[TIER1_STEP]['artifact']}"  # :681-684

        # STEP 13 — bundle G-V3 evidence
        await _set_step("bundle-g-v3-evidence", _progress_at("bundle-g-v3-evidence"))  # :687-690
        await _dispatch_cato_evidence(..., stage="G-V3",
            input_artifacts=dedup_paths(_step_committed_paths.get(TIER1_STEP,[]) + _cato_paths.get("G-V2",[])))  # :692-699
        gv3_evidence_paths = dedup_paths(_step_committed_paths.get(TIER1_STEP,[]) + _cato_paths.get("G-V3",[]))  # :700-703

        # STEP 14 — create G-V3 PR
        await _set_step("create-g-v3-pr", _progress_at("create-g-v3-pr"))              # :706-708
        gv3_pr = await _create_gate_pr(..., gate_type=G_V3.value,
            title=f"Gate G-V3: Safety Assurance (Tier 1) — {app_id}", body=_build_gv3_pr_body(app_id))  # :709-716
        gv3_record = await execute_activity(create_gate_record, CreateGateRecordInput(G_V3.value,...evidence_package_url=gv3_pr.pr_url), 30s, transient)  # :717-728
        await _submit_gate_evidence(gv3_record.gate_id, G_V3, app_id, dedup_paths(gv3_evidence_paths), gv3_pr.pr_url, "Validation", "gate-review-v3")  # :729-737

        # STEP 15 — AI pre-review G-V3
        await _set_step("ai-pre-review-v3", _progress_at("ai-pre-review-v3"))          # :740-743
        await _run_gate_pre_review(gv3_record.gate_id, G_V3.value, dedup_paths(gv3_evidence_paths), artifact_repo=repo, artifact_ref=branch)  # :744-750

        # STEP 16 — Gate G-V3
        await _set_step("gate-review-v3", _progress_at("gate-review-v3"))              # :753-755
        gv3_decision = await _wait_for_gate_decision(G_V3)                             # :756-758
        if gv3_decision == "cancelled": return "cancelled"                            # :759-760
        if gv3_decision == "rejected":                                                # :761
            _bump_rework("G-V3")
            if _rework_count("G-V3") > MAX_REWORK_ITERATIONS:
                return await _fail("max-rework-exceeded-gv3", app_id)                 # :762-766
            _stakeholder_safety_approved = False   # reset so prior approvals don't leak  # :769
            _stakeholder_cert_approved = False                                        # :770
            continue                                                                  # :771
        # --- approved: Tier-1 triple-signal wait ---
        await workflow.wait_condition(
            lambda: (_stakeholder_safety_approved and _stakeholder_cert_approved) or self.cancelled)  # :775-782
        if self.cancelled:
            _status = CANCELLED; return "cancelled"                                   # :784-786
        await _emit_gate_evidence(G_V3, gv3_record.gate_id, app_id, input.portfolio_id, gv3_decision)  # FAIL-CLOSED FIRST  # :791-797
        final_pr = gv3_pr                                                             # :798
        break                                                                         # :799

# STEP 17 — persist validation side-effects
await _set_step("persist-validation-side-effects", _progress_at("persist-validation-side-effects"))  # :802-805
gv1_json = _first_output("functional-parity")                                         # :806
gv2_compliance_json = _first_output("security-compliance")                            # :807
gv2_accessibility_json = _first_output("accessibility-ux")                            # :808
gv3_safety_json = _first_output(TIER1_STEP) if is_tier_1 else ""                      # :809-811
cato_uuid = _cato_target_uuid or app_id                                               # :812
try:
    await execute_activity(persist_validation_side_effects,
        PersistValidationSideEffectsInput(
            target_app_id=app_id,
            risk_tier=str(_risk_tier) if _risk_tier else "",   # NOTE: falsy 0 → "" (never happens; tiers are 1/2/3)  # :818
            parity_report_json=gv1_json, security_report_json=gv2_compliance_json,
            accessibility_audit_json=gv2_accessibility_json, safety_case_json=gv3_safety_json,
            safety_case_ref=_safety_case_ref, decided_at=_now_iso(),
            cato_target_uuid=cato_uuid, cato_stage=_cato_highest_stage,
            cato_ssp_path=f".cato/{cato_uuid}/ssp.json" if _cato_paths.get("G-V1") else "",   # :827-831
            cato_sar_path=f".cato/{cato_uuid}/sar.json" if _cato_paths.get("G-V2") else "",   # :832-836
            cato_poam_path=f".cato/{cato_uuid}/poam.json" if _cato_paths.get("G-V3") else "", # :837-841
            control_evidence_json=json.dumps(_cato_evidence_records) if _cato_evidence_records else ""),  # :842-846
        start_to_close=60s, retry=transient, activity_id="persist-validation-side-effects")  # :848-851
except Exception:   # observability only — logged, NOT fatal                           # :852-856
    logger.exception("persist_validation_side_effects failed; ... keep stale validation fields")

# STEP 18 — merge final gate PR + emit ValidationApprovedSignal
await _set_step("merge-final-gate-pr", _progress_at("merge-final-gate-pr"))            # :859-862
if is_tier_1:                                                                          # :866
    await _reconcile_and_merge_with_retry_loop(repo, final_pr.pr_number, gv3_record.gate_id, "merge")  # :867-872
    # Tier-2/3: G-V2 PR already merged in gate-approval branch — merge is a no-op, skipped.
await _fire_validation_approved_signal(input, app_id)                                 # :878
await _update_app_status(app_id, "validation_complete", "completed", "Validation")    # :880-882
_status = COMPLETED; _progress_pct = 100.0; _current_step = "completed"; _updated_at = _now_iso()  # :883-886
return "completed"                                                                     # :887
```

GOTCHAS in run flow:
- The G-V1/G-V2 `while True` loop (`:406`) re-runs ALL streams (steps 2-4) and re-bundles/re-PRs G-V1 on every rework `continue`. There is no partial re-run — rejection at G-V2 also re-runs the parity stream. (`continue` returns to `:406` top.)
- `_bump_rework` increments BEFORE the `> MAX_REWORK_ITERATIONS` check, so the 4th failure (count==4 > 3) fails; iterations 1,2,3 loop. Auto-reject (parity) and PM-reject share the same G-V1 counter (`:495` and `:506` both key `"G-V1"`).
- Tier-1 stakeholder waits happen AFTER the PM gate approval is consumed and BEFORE evidence emit / merge — a Tier-1 G-V2/G-V3 gate is not "done" until PM + both stakeholder scopes land.
- `gv3_record` at `:870` is only defined when `is_tier_1` (assigned inside the Tier-1 block at `:717`). The `:866 if is_tier_1` guard ensures it is only referenced when defined. GOTCHA: `final_pr` for Tier-1 is `gv3_pr`; Tier-2/3 `final_pr = gv2_pr` (`:656`) but the merge at `:867` is skipped so `final_pr` is unused on that path (G-V2 already merged at step 11).
- `_parity_meets_threshold` DEFAULTS TO TRUE on any parse ambiguity (see §Helpers) — so a mock-agent run with no parity_score passes G-V1 automatically.

### `_run_parallel_streams(app_id, repo, branch, workspace_key, prior_artifacts)` (validation.py:893-952)
```
await _set_step("functional-parity", _progress_at("functional-parity"))               # :910-912
for stream in PARALLEL_STREAMS:                                                        # :913
    _stream_status[stream] = "running"; _stream_started_at[stream] = _now_iso()        # :914-915

async _run_stream(step_name):                                                          # :917
    try:
        result = await _dispatch_agent(app_id, step_name, input_artifacts=prior_artifacts,
            workspace_key, artifact_repo=repo, artifact_ref=branch)                     # :919-926
        _step_results[step_name] = result.output_artifacts                              # :927
        artifact_path = f"validation/{app_id}/{VALIDATION_STEPS[step_name]['artifact']}"  # :928-931
        await _commit_step_artifacts(repo, branch, app_id, step_name, result, artifact_path)  # :932-934
        _stream_status[step_name] = "completed"; _stream_completed_at[step_name] = _now_iso()  # :935-936
    except Exception:
        _stream_status[step_name] = "failed"; _stream_completed_at[step_name] = _now_iso(); raise  # :937-940

await asyncio.gather(*[_run_stream(s) for s in PARALLEL_STREAMS])                       # :945  (PARALLEL — 3 concurrent)
await _set_step("accessibility-ux", _progress_at("accessibility-ux"))                  # :950-952  (advance pointer past all stream roots)
```
GOTCHA (`:942-944`): `asyncio.gather` surfaces the FIRST exception; remaining streams are cancelled; the run's outer handler fails the workflow. No compensation for the already-committed streams — partial commits stay in git.
GOTCHA: `_set_step("functional-parity",...)` before gather and `_set_step("accessibility-ux",...)` after are cosmetic stepper-pointer moves; the actual parity progress weight is 18.0 and accessibility 18.0, but security-compliance's pointer is never set (progress jumps functional-parity→accessibility-ux). Monotonic because `_progress_at("accessibility-ux") > _progress_at("functional-parity")`.

### `_run_safety_stream(app_id, repo, branch, workspace_key, safety_inputs)` (validation.py:954-982)
```
await _set_step(TIER1_STEP, _progress_at(TIER1_STEP))                                  # :963-965
result = await _dispatch_agent(app_id, TIER1_STEP, input_artifacts=safety_inputs, workspace_key, artifact_repo=repo, artifact_ref=branch)  # :967-974
_step_results[TIER1_STEP] = result.output_artifacts                                    # :975
artifact_path = f"validation/{app_id}/{VALIDATION_STEPS[TIER1_STEP]['artifact']}"      # :976-979
await _commit_step_artifacts(repo, branch, app_id, TIER1_STEP, result, artifact_path)  # :980-982
```
Sequential (single dispatch). No try/except — a safety dispatch failure propagates to the run's outer `except`.

### `_parity_meets_threshold() -> bool` (validation.py:1210-1241)
```
raw = _first_output("functional-parity")                          # :1220
if not raw: return True                                           # :1221-1222  (no parity output → pass)
try:
    import json
    start = raw.find("{"); end = raw.rfind("}")                   # :1226-1227
    if start == -1 or end <= start: return True                   # :1228-1229
    report = json.loads(raw[start:end+1])                         # :1230
except Exception: return True                                     # :1231-1232
if not isinstance(report, dict): return True                      # :1233-1234
score = report.get("parity_score") or report.get("score")        # :1235
if not isinstance(score, (int,float)): return True               # :1236-1237
threshold = PARITY_THRESHOLDS.get(_risk_tier, PARITY_THRESHOLDS[None])  # :1238-1240
return float(score) >= threshold                                  # :1241
```
GOTCHA: fail-OPEN by default — every parse/type ambiguity returns True (passes G-V1). Only an explicit numeric `parity_score`/`score` below threshold auto-rejects. GOTCHA: `report.get("parity_score") or report.get("score")` — a literal `0`/`0.0` parity_score is falsy so it falls through to `score`; if both are 0 the `isinstance(0,(int,float))` check passes and `0.0 >= threshold` is False (auto-reject). But a parity_score of exactly `0` written as the only key would be treated as "missing" and fall back to `score` (may be absent → True).

### Helper accessors
- `_first_output(step_name) -> str` (`:1243-1246`): `outputs = _step_results.get(step_name, [])`; return `outputs[0] if outputs else ""`.
- `_progress_at(step_name) -> float` (`:1248-1259`): iterate `STEP_WEIGHTS.items()` accumulating `total += weight`, break when `name == step_name`; return `min(total, 100.0)`. GOTCHA: relies on dict INSERTION ORDER of `STEP_WEIGHTS` (Python 3.7+ ordered). Reordering the dict breaks monotonic progress.
- `_primary_skill_for_step(step_name)` (`:274-276`): returns `VALIDATION_STEPS[step_name]["skills"][0]` (overrides base which reads `["skill_id"]`). For streams: parity→`parity-verifier`, security→`security-scan-review`, accessibility→`accessibility-checker`, safety→`safety-critical-verifier`.
- `_evidence_step_metadata(step_name, step_def)` (`:278-286`): returns `{"title": step_def.get("title",step_name), "skills": step_def["skills"], "artifact": step_def["artifact"]}` (uses `skills` list, not `skill_id`).
- `_rework_gate_key_for_step(step_name)` (`:288-303`): `functional-parity`→`"G-V1"`; `{security-compliance, accessibility-ux}`→`"G-V2"`; `safety-assurance`→`"G-V3"`; else `None`. Drives which `_rework_feedback` entry `_dispatch_agent` forwards.
- `_fail(reason_step, app_id) -> "failed"` (`:1322-1330`): `_status=FAILED`, `_current_step=reason_step`, `_updated_at=_now_iso()`, `await _update_app_status(app_id,"validation_failed",reason_step,"Validation")`, return `"failed"`. (No swallow here — a status-update failure would propagate and be caught by run's outer except, still yielding FAILED.)

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS (in run order)

No child workflows. `_fire_validation_approved_signal` uses `signal_external_workflow` (a signal, not a child). All activity calls with args/timeouts/retry:

| # | Activity | Where | Args (key) | start_to_close | retry_policy | non_retryable | seq/par |
|---|---|---|---|---|---|---|---|
| A0 | `update_application_status` | every `_set_step` (base.py:391-401) | `UpdateAppStatusInput(app_id, f"validation_in_progress", step, "Validation")` | 30s | transient | — | seq |
| A1 | `dispatch_agent_task` ×3 | `_run_parallel_streams`→`_dispatch_agent` (base.py:486-492) | `AgentTaskInput(task_type="validation-{step}", skill_id=first skill, input_artifacts=prior_artifacts, artifact_repo=repo, artifact_ref=branch, workspace_key, context{rework_feedback?, context_priors?, fixture_scenario?})`, `activity_id=f"agent-{step}"` | `AGENT_START_TO_CLOSE`=3h | `agent_failure` (3 attempts, exp 5-60s) | — | **PARALLEL via asyncio.gather** |
| A1b | `load_context_priors` | inside `_dispatch_agent` IF `workflow.patched("context-priors-v1")` (base.py:453-469) | `LoadContextPriorsInput(skill_id)` | 10s | transient | — | seq (best-effort, swallowed) |
| A2 | `write_artifacts_batch` ×3 | `_commit_step_artifacts` (base.py:822-836) | `WriteArtifactsBatchInput(repo, branch, files=[summary+output files], commit_message="validation({app}): {step} artifacts")`, `activity_id=f"commit-{step}"` | 120s | transient | — | seq (per stream, inside its gather task) |
| A2b | `update_agent_task_output_ref` | IF `workflow.patched("patch-output-artifact-ref-v1")` (base.py:877-891) | `args=[app_id, "validation-{step}", artifact_path]`, `activity_id=f"patch-output-ref-{step}"` | 30s | transient | — | seq (best-effort swallowed) |
| C1 | `dispatch_agent_task` (cato) | `_dispatch_cato_evidence` (`:1112-1132`) | `AgentTaskInput(task_type=f"validation-cato-{stage.lower()}", skill_id="cato-compliance", input_artifacts, artifact_repo, artifact_ref, workspace_key, context={stage, prior_ssp_path, fixture_scenario})`, `activity_id=f"cato-evidence-{stage.lower()}"` | `AGENT_START_TO_CLOSE`=3h | `agent_failure` | — | seq; **best-effort** (except→warn+return) |
| C2 | `write_artifacts_batch` (cato) | `_dispatch_cato_evidence` (`:1162-1180`) | `WriteArtifactsBatchInput(repo, branch, files=normalized batch, commit_message=f"cato({app}): {stage} evidence [{wf_id}]")`, `activity_id=f"commit-cato-{stage.lower()}"` | 120s | transient | — | seq; **best-effort** |
| G1 | `create_pr` | `_create_gate_pr` (base.py:915-920) | `CreatePRInput(repo, source_branch=branch, target_branch="main", title, body, labels=["gate-review","validation",gate_type])` → returns `CreatePRResult(pr_number, pr_url)` | 60s | transient | — | seq |
| G2 | `create_gate_record` | run (`:441-452, 567-578, 717-728`) | `CreateGateRecordInput(gate_type, app_id, portfolio_id, workflow_id, evidence_package_url=pr.pr_url)` → `CreateGateRecordResult(gate_id,...)` | 30s | transient | — | seq |
| G3 | `check_gate_criteria` | `_submit_gate_evidence`→(base.py:1001-1006) | `CheckGateCriteriaInput(gate_id, gate_type, app_id, evidence_paths, evidence_data=criteria_evidence, risk_tier)` (forward_risk_tier True) | 60s | transient | — | seq |
| G4 | `submit_gate_evidence` | `_submit_gate_evidence` (base.py:1016-1021) | `SubmitGateEvidenceInput(gate_id, gate_type, app_id, artifact_paths, pr_url, evidence_data=slim_evidence)` | 60s | transient | — | seq |
| P1 | `dispatch_agent_task` (gate-pre-review) | `_run_gate_pre_review` (base.py:1049-1071) | `AgentTaskInput(skill_id="gate-pre-review", task_type="gate-pre-review", input_artifacts=evidence_paths, artifact_repo, artifact_ref, context={gate_id, gate_type})` | `AGENT_START_TO_CLOSE`=3h + `heartbeat_timeout`=2min | transient | — | seq; **best-effort** (try/except warns) |
| P2 | `store_gate_pre_review` | `_run_gate_pre_review` (base.py:1079-1087) | `StoreGatePreReviewInput(gate_id, agent_output=markdown)` | 30s | transient | — | seq (inside try) |
| P3 | `mark_gate_ready_for_review` | `_run_gate_pre_review.finally` IF `workflow.patched("mark-gate-ready-for-review-v1")` (base.py:1095-1101) | `args=gate_id` | 30s | transient | — | seq (finally — runs even if pre-review failed) |
| E1 | `emit_evidence` | `_emit_gate_evidence` (`:1022-1052`) | `EmitEvidenceInput(portfolio_id, application_id=app_id, control_id, family, status="implemented", assessed_at_gate=gate.value, implementation_statement, risk_tier, run_id, subject_kind="gate", subject_id=gate_id, owner_scope=portfolio_id, owner_scope_type="portfolio", profile_id=None, mappings=[ControlMappingInput(catalog_id="nist-800-53-rev5", control_id)])`, `activity_id=f"emit-evidence-{gate.value.lower()}-{gate_id}"` | 30s | transient | **EvidenceWriteError marked non-retryable inside `@foundry_activity`** | seq; **FAIL-CLOSED (re-raises)** |
| M1 | `reconcile_and_merge_pr` | `_reconcile_and_merge_with_retry_loop` (base.py:1208-1218) | `MergePRInput(repo, pr_number, merge_method="merge", execution_context)` | 60s | `git_merge` (3 attempts, 5-30s) | `MergeConflict`, `MergeDivergenceUnresolved`, `MergeBranchProtectionRejected` | seq; merge_blocked retry loop |
| M2 | `set_gate_merge_blocked` | `_reconcile_and_merge_with_retry_loop` on structured merge error (base.py:1263-1268) | `args=[gate_id, detail]` | 30s | transient | — | seq |
| S1 | `persist_validation_side_effects` | run step 17 (`:814-851`) | `PersistValidationSideEffectsInput(...)` (see §3), `activity_id="persist-validation-side-effects"` | 60s | transient | — | seq; **best-effort** (except→logger.exception) |

`_fire_validation_approved_signal` (step 18): `handle = workflow.get_external_workflow_handle(deployment_wf_id); await handle.signal("validation_approved", payload)` (`:1312-1314`) — signal, best-effort try/except.

---

## 5. GATE HANDLING

### Evidence assembly per gate
- G-V1 (`gv1_evidence_paths`, `:426-429`): `dedup_paths(functional-parity committed paths + cato G-V1 paths)`. cATO input for G-V1 dispatch = `security-compliance` committed paths (`:422-424`).
- G-V2 (`gv2_evidence_paths`, `:551-555`): `dedup_paths(security-compliance + accessibility-ux + cato G-V2 paths)`. cATO input = `dedup(security-compliance + cato G-V1)`.
- G-V3 (`gv3_evidence_paths`, `:700-703`): `dedup_paths(safety-assurance + cato G-V3 paths)`. cATO input = `dedup(safety-assurance + cato G-V2)`.
- `_submit_gate_evidence` (base.py:922-1021): builds slim evidence (no inline content) via `_build_evidence_data`; for gates with `GATE_THRESHOLDS` it rebuilds a `criteria_evidence` bundle including only threshold-target file contents, calls `check_gate_criteria` then `submit_gate_evidence`.

### The wait — `_wait_for_gate_decision(gate_type)` (base.py:1103-1157)
```
_status = WAITING_FOR_SIGNAL; _pending_gate = gate_type; _updated_at = _now_iso()
consumed = _gate_decisions_consumed
await workflow.wait_condition(lambda: len(_gate_decisions) > consumed or self.cancelled)   # buffered-signal safe
if self.cancelled: _status=CANCELLED; return "cancelled"
entry = _gate_decisions[consumed]
if len(entry)==5: decision, actor, reason, reason_category, card_decisions = entry
else: decision, actor, reason = entry[0..2]; reason_category=None; card_decisions=[]
_gate_decisions_consumed = consumed+1
_pending_gate=None; _status=RUNNING
if decision == APPROVED: _rework_feedback.pop(gate_key,None); return "approved"
_rework_feedback[gate_key] = {gate, rejected_by, reason, reason_category, card_decisions, rejected_at}; return "rejected"
```
GOTCHA: decisions are buffered by index (`consumed`), so a signal arriving before the wait is not lost. The predicate `or self.cancelled` makes cancel win the race.

### Routing per verdict (each gate)
- **`"cancelled"`** → immediate `return "cancelled"` from run (`:504, 607, 760`). Tier-1 stakeholder wait cancellation sets `_status=CANCELLED` then returns (`:628-630, 784-786`).
- **`"rejected"`** → `_bump_rework(gate)`; if count > 3 → `return await _fail("max-rework-exceeded-g{v1|v2|v3}", app_id)`; else `continue` (re-enter loop). G-V3 additionally resets both safety+cert stakeholder flags before `continue` (`:769-770`).
- **`"approved"`** → (Tier-1 G-V2/G-V3 only) wait for two stakeholder scopes; then `_emit_gate_evidence` (fail-closed FIRST), then merge (G-V1/G-V2 via `_reconcile_and_merge_with_retry_loop`; G-V3 merge deferred to step 18), then `_update_app_status`.
- **G-V1 auto-reject** (parity below threshold, `:487`) → NO wait for PM signal: `_bump_rework("G-V1")`, cap-check, `continue`. This is distinct from a PM `gate_rejected` at the same gate but shares the counter.

### merge-blocked routing — `_reconcile_and_merge_with_retry_loop` (base.py:1159-1279)
```
merge_failure_types = {MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected}
while True:
    try: await reconcile_and_merge_pr(MergePRInput(...), 60s, git_merge); return   # success
    except (ActivityError, ApplicationError) as outer:
        inner = unwrap __cause__ chain to first ApplicationError
        if not ApplicationError: raise
        failure_type = inner.type or ""
        if failure_type not in merge_failure_types: raise    # non-merge error propagates
        detail = {failure_type, reason, pr_number, detected_at}
        _merge_retry_signalled = False    # reset before blocking to avoid stale-signal race
        await set_gate_merge_blocked(args=[gate_id, detail], 30s, transient)
        await workflow.wait_condition(lambda: _merge_retry_signalled or self.cancelled)
        if self.cancelled: return
        # loop back — retry merge
```
GOTCHA: on cancel during merge-blocked wait the helper `return`s (does NOT raise), so run continues past the merge as if it succeeded. GOTCHA: the flag is reset at top of each blocked cycle, not on the success path.

### Rework loop counters
Keyed in `_rework_iterations` by gate value `"G-V1"|"G-V2"|"G-V3"` (base.py `_bump_rework`/`_rework_count`). Cap = `MAX_REWORK_ITERATIONS = 3`; the 4th bump (>3) fails. PR bodies show `_rework_count(gate)` (only when >0). GOTCHA: counters are never reset across the workflow's life — a G-V1 that reworks twice then passes leaves the counter at 2; unrelated to G-V2/G-V3 counters.

---

## 6. RESILIENCE

- **Timeouts**: agent dispatch 3h (`AGENT_START_TO_CLOSE`) + 2min heartbeat on pre-review; DB/gate activities 30-60s; git batch 120s; merge 60s. See `agent_timeouts.py` ladder (idle 600s < absolute 10500s < HTTP 10800s ≤ start_to_close 10800s).
- **Retries**: `transient`=`HTTP_RETRY_POLICY` (3 attempts, exp 1-15s); `agent_failure`=3 attempts exp 5-60s; `git_merge`=3 attempts exp 5-30s with 3 non-retryable merge error types.
- **Heartbeats**: only `_run_gate_pre_review`'s dispatch passes `heartbeat_timeout` (base.py:1069). Stream dispatches (`_dispatch_agent`) do NOT set a heartbeat timeout — only `start_to_close`.
- **continue-as-new**: NONE. The workflow does not call `workflow.continue_as_new`. Long-lived rework loops accumulate history (bounded by MAX_REWORK=3 per gate).
- **Idempotency / determinism**: all timestamps via `_now_iso()` = `workflow.now().isoformat()` (base.py:106-108) — replay-safe. `_emit_gate_evidence` captures timestamp INSIDE the activity (REQ-TEMP-001); workflow reads no clock/DB there. Patch gates: `context-priors-v1`, `patch-output-artifact-ref-v1`, `mark-gate-ready-for-review-v1` — IDs preserved verbatim for replay.
- **Compensation / rollback**: NONE explicit. Failed streams leave committed artifacts in git. `_emit_gate_evidence` is fail-closed — a durability failure raises `EvidenceWriteError` (non-retryable) BEFORE merge/status advance, so a verdict cannot commit without its evidence record (REQ-EV-001/005/009, `:997-1017`). Dangling control mappings (REQ-EV-010) are logged, not raised (`:1053-1061`).
- **Best-effort (never fatal)**: cATO dispatch + commit (`:1133-1139, 1181-1187`), `persist_validation_side_effects` (`:852-856`), `_fire_validation_approved_signal` (`:1315-1320`), gate pre-review (base.py:1088-1093), `load_context_priors` (base.py:464), `update_agent_task_output_ref` (base.py:890), mirror writes.

---

## 7. cATO evidence dispatch — `_dispatch_cato_evidence` (validation.py:1078-1204)

`_CATO_STAGE_FIXTURE = {"G-V1":"ssp-g-v1","G-V2":"sar-g-v2","G-V3":"poam-g-v3"}` (`:1072-1076`).
```
target_uuid = app_id; _cato_target_uuid = target_uuid                                  # :1104-1105
context = {stage, prior_ssp_path=f".cato/{target_uuid}/ssp.json", fixture_scenario=_CATO_STAGE_FIXTURE.get(stage,"")}  # :1106-1110
try:
    result = await execute_activity(dispatch_agent_task, AgentTaskInput(task_type=f"validation-cato-{stage.lower()}", skill_id="cato-compliance", ...), AGENT_START_TO_CLOSE, agent_failure, activity_id=f"cato-evidence-{stage.lower()}")  # :1112-1132
except Exception as exc: logger.warning(...); return       # best-effort               # :1133-1139
output_files = result.output_files or []                                               # :1141
if not output_files: return                                                            # :1142-1143
def _normalize(path): if path.startswith(".cato/"): parts=path.split("/",2); if len(parts)==3: return f".cato/{target_uuid}/{parts[2]}"; return path  # :1150-1155
batch = [(_normalize(f.path), f.content) for f in output_files if f.path]              # :1157-1159
committed = [p for p,_ in batch]                                                       # :1160
try: await execute_activity(write_artifacts_batch, WriteArtifactsBatchInput(...), 120s, transient, activity_id=f"commit-cato-{stage.lower()}")  # :1162-1180
except Exception as exc: logger.warning(...); return                                   # :1181-1187
_cato_paths[stage] = committed; _cato_highest_stage = stage                            # :1188-1189
evidence_records = [f.content for f in output_files if "/evidence/" in (f.path or "")]  # :1193-1197
if evidence_records: _cato_evidence_records = evidence_records                         # :1198-1199
logger.info("cato evidence committed at %s", stage, extra={app_id, paths:len(committed)})  # :1200-1204
```
GOTCHA: `_cato_paths[stage]` and `_cato_highest_stage` are ONLY set if BOTH the dispatch and commit succeed. On any failure the stage is absent from `_cato_paths`, so the persist step's `.cato/.../{ssp,sar,poam}.json` path strings stay `""` for that stage. GOTCHA: `_normalize` rewrites only the uuid segment (`parts[1]`) preserving `parts[2]` (the rest); non-`.cato/` paths pass through unchanged.

## 8. `_fire_validation_approved_signal` (validation.py:1261-1320)
```
deployment_wf_id = ""
try: deployment_wf_id = input.peer_workflow_ids.get("Deployment","")
except AttributeError: deployment_wf_id = ""                                           # :1276-1280
output_refs = []; for step in ("functional-parity","security-compliance","accessibility-ux",TIER1_STEP): output_refs.extend(_step_committed_paths.get(step,[]))  # :1282-1291
output_refs = dedup_paths(output_refs)                                                 # :1292
payload = ValidationApprovedSignal(target_app_id=app_id, portfolio_id, validation_output_refs=output_refs, approved_at=_now_iso(), risk_tier=str(_risk_tier) if _risk_tier is not None else "")  # :1294-1302
if not deployment_wf_id: logger.info("skipped — no peer Deployment"); return           # :1304-1310
try: handle = workflow.get_external_workflow_handle(deployment_wf_id); await handle.signal("validation_approved", payload)  # :1312-1314
except Exception as exc: logger.warning("signal failed ...")                           # :1315-1320
```
GOTCHA: `risk_tier` here uses `if _risk_tier is not None` (unlike step 17's `if _risk_tier` at `:818`), so tier `0` would serialize as `"0"` here but `""` there — moot since tiers are 1/2/3.

## 9. PR body builders (deterministic strings)
- `_build_gv1_pr_body(app_id)` (`:1336-1367`): includes `_rework_count("G-V1")`, tier-adjusted parity threshold from `PARITY_THRESHOLDS.get(_risk_tier, PARITY_THRESHOLDS[None])`, risk tier line (`or 'unclassified'`), automated-gate note, stream-1 checklist, artifact list, PM-acknowledgement checklist; appends `**Rework iteration:** {n}` when >0.
- `_build_gv2_pr_body(app_id)` (`:1369-1410`): conditionally adds `**Risk tier:**` line only when `_risk_tier is not None`; adds Tier-1 triple-signal note when `_risk_tier==1`; stream-2/3 checklists + artifacts + compliance/security/accessibility checklist; rework suffix when >0.
- `_build_gv3_pr_body(app_id)` (`:1412-1439`): fixed "Risk tier: 1", Tier-1 triple-signal note (`g-v3-safety` + `g-v3-cert`), stream-4 checklist + artifacts + safety-board checklist; rework suffix when >0.

---

## 10. Behavioral parity checklist

A rebuild MUST satisfy:

1. `STEP_WEIGHTS` sums to exactly 100.0 (module import assertion) and preserves insertion order; `_progress_at` returns the cumulative sum through the named step, capped at 100.
2. Constants exact: `MAX_REWORK_ITERATIONS=3`, `PARITY_THRESHOLDS={1:99,2:98,3:95,None:98}`, `GATE_ASSESSMENT_CONTROLS` (G_V1/G_V2→CA-2/CA, G_V3→CA-7/CA), catalog id `nist-800-53-rev5`, `_CATO_STAGE_FIXTURE` (ssp-g-v1/sar-g-v2/poam-g-v3).
3. branch = `olympus/validation/{app_id}/{run_suffix}`, workspace_key = `validation-{app_id}-{run_suffix}` where `run_suffix = wf_id.rsplit("-",1)[-1]` (or first 8 chars if no `-`). repo = `target_repo_url or artifact_repo`.
4. `run` sets RUNNING then on any exception sets FAILED + `_current_step="failed"`, best-effort `validation_failed` status update (swallowed), and re-raises.
5. Three streams (parity/security/accessibility) dispatch CONCURRENTLY via `asyncio.gather`; first exception fails the run; each stream's `_step_results` and `_step_committed_paths` set only on its own success; `_stream_status` transitions queued→running→completed|failed.
6. Each stream dispatches `dispatch_agent_task` with `task_type="validation-{step}"`, `skill_id`=first skill in the `skills` list, `input_artifacts=prior_artifacts`, retry `agent_failure`, 3h timeout, `activity_id=f"agent-{step}"`; commits summary+files in one `write_artifacts_batch`.
7. G-V1 is automated: `_parity_meets_threshold()` fails ONLY on an explicit numeric `parity_score`/`score` below the tier threshold; all parse/missing/type cases return True. Auto-reject bumps `"G-V1"` rework and `continue`s WITHOUT waiting for a PM signal; passing parity still awaits a PM `gate_approved`.
8. Gate loop order per gate: `_set_step` → cato dispatch (best-effort) → evidence path union (dedup) → `_create_gate_pr` → `create_gate_record`(30s/transient) → `_submit_gate_evidence` → `_run_gate_pre_review` (flips gate to pending, incl. G-V1). On approve: `_emit_gate_evidence` FIRST (fail-closed) → merge-with-retry-loop → app status.
9. Rework: reject/auto-reject → `_bump_rework(gate)` then `if count > 3: _fail("max-rework-exceeded-g{v1|v2|v3}")` else `continue` (re-runs ALL streams + re-PRs from loop top). Counters keyed per gate, never reset. G-V3 reject also zeroes `_stakeholder_safety_approved`/`_stakeholder_cert_approved`.
10. Tier-1 (`_risk_tier==1`) G-V2 approval additionally awaits `(_stakeholder_compliance_approved and _stakeholder_security_approved) or cancelled`; G-V3 approval awaits `(_stakeholder_safety_approved and _stakeholder_cert_approved) or cancelled`. Tier-2/3 skip these waits AND the entire steps 12-16 block.
11. `stakeholder_approved` routes by scope (g-v2-compliance/g-v2-security/g-v3-safety/g-v3-cert); unknown scopes logged+ignored; always refreshes `_updated_at`. Subclass MUST NOT redefine `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry`.
12. `_emit_gate_evidence` emits `emit_evidence` (30s/transient, `EvidenceWriteError` non-retryable) with `subject_kind="gate"`, `subject_id=gate_id`, `owner_scope=portfolio_id`/`owner_scope_type="portfolio"`, `profile_id=None`, mapping to catalog `nist-800-53-rev5`; dangling mappings logged not raised.
13. merge uses `_reconcile_and_merge_with_retry_loop` with `git_merge` policy; on `MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected` → `set_gate_merge_blocked` + await `merge_retry` signal (flag reset before block); cancel during block returns (not raise); non-merge errors propagate.
14. cATO: dispatch `cato-compliance` per stage (best-effort), commit outputs to normalized `.cato/{app_id}/...` paths; only on full success set `_cato_paths[stage]`, `_cato_highest_stage`, and (if any `/evidence/` files) `_cato_evidence_records`. Persist step derives ssp/sar/poam path strings only when the matching `_cato_paths` stage exists.
15. Step 17 `persist_validation_side_effects` (60s/transient) is best-effort (logged, not fatal), with `risk_tier=str(tier) if tier else ""`, per-stream `_first_output`s, safety json only Tier-1, and cato fields.
16. Step 18: Tier-1 merges `final_pr=gv3_pr` via retry loop with `gv3_record.gate_id`; Tier-2/3 skip the merge (G-V2 already merged). Always `_fire_validation_approved_signal` (best-effort; skipped if no `peer_workflow_ids["Deployment"]`), then `validation_complete` status, `_status=COMPLETED`, `_progress_pct=100.0`, return `"completed"`.
17. `ValidationApprovedSignal` payload: `target_app_id`, `portfolio_id`, `validation_output_refs`=dedup union of committed paths across the 3 streams + safety, `approved_at`=`_now_iso()`, `risk_tier`=`str(tier) if not None else ""`; signal name `"validation_approved"`.
18. `_portfolio_id` is never set → `_execution_ctx` returns None → no Layer-B step_execution rows for Validation.
19. All timestamps via `workflow.now().isoformat()`; patch IDs `context-priors-v1`, `patch-output-artifact-ref-v1`, `mark-gate-ready-for-review-v1` preserved.
20. Return values: `"completed"` (success), `"cancelled"` (any cancel), `"failed"` (rework cap exceeded); uncaught exceptions propagate as workflow failure with FAILED status.
