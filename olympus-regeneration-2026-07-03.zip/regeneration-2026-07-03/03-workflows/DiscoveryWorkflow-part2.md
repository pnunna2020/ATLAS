# DiscoveryWorkflow — Atomic Regeneration Spec (Part 2 of 2)

Continues `DiscoveryWorkflow.md`. Source: `temporal/olympus_workflows/workflows/discovery.py`. All line refs relative to that file unless noted.

---

## 7. BUILD / REQUIREMENTS MODE (net-new applications, P6-S5.4 / P6-S5.5)

Entered from `_execute_discovery` when `input.source_type in ("requirements_doc","interview")` (`:287-290`). No code-analysis passes run — there is no legacy source. Produces the **`requirements-capability`** artifact at `build/{app_id}/requirements/requirements-capability.json` (`:693-695`), then converges on the SAME commit → PR → G-DC gate tail.

### 7.1 `_execute_requirements_mode(input, app_id, repo, branch) -> str` (`:669-809`)
`artifact_repo_path = f"build/{app_id}/requirements/requirements-capability.json"` (`:693-695`).

```
while True:                                                                     (:697)
    if input.source_type == "interview":                                        (:699)
        committed_paths = await self._intake_interview(app_id, repo, branch, artifact_repo_path)   (:700-702)
        if committed_paths is None:   # session expired before submit           (:703)
            self._status=FAILED; self._current_step="interview-expired"; _updated_at   (:705-707)
            await self._update_app_status(app_id,"discovery_failed","interview-expired","Discovery")   (:708-711)
            return "failed"                                                      (:712)
    else:                                                                        (:713)
        committed_paths = await self._intake_requirements_doc(app_id, input, repo, branch, artifact_repo_path)   (:714-716)

    await self._set_step("create-pr", 90.0)                                     (:719)
    pr_result = await self._create_gate_pr_requirements(repo, branch, app_id, input.source_type)   (:720-722)

    wf_id = workflow.info().workflow_id                                         (:725)
    gate_record = execute_activity(create_gate_record,
        CreateGateRecordInput("G-DC", app_id, input.portfolio_id, wf_id, pr_result.pr_url),
        start_to_close=30s, retry=transient)                                    (:726-737)
    gate_id = gate_record.gate_id                                               (:738)

    await self._submit_gate_evidence(gate_id, GateType.G_DC, app_id,
        artifact_paths=committed_paths, pr_url=pr_result.pr_url,
        assembly_line="Discovery", step="gate-review", forward_risk_tier=False) (:742-751)

    await self._set_step("gate-readiness-check", 95.0)                          (:754)
    await self._run_gate_pre_review(gate_id, "G-DC", committed_paths,
        artifact_repo=repo, artifact_ref=branch)                                (:755-761)

    await self._update_app_status(app_id, "gate_review", "gate-review", "Discovery")   (:763-765)
    await self._set_step("gate-review", 98.0)                                   (:768)
    decision = await self._wait_for_gate_decision(GateType.G_DC)                (:769)

    if decision == "cancelled": return "cancelled"                             (:771-772)

    if decision == "approved":                                                  (:774)
        await self._reconcile_and_merge_with_retry_loop(repo, pr_result.pr_number, gate_id, "merge")   (:775-780)
        await self._update_app_status(app_id, "discovery_complete", "completed", "Discovery")   (:781-783)
        self._status=COMPLETED; self._progress_pct=100.0; self._current_step="completed"; _updated_at   (:784-787)
        return "completed"                                                      (:788)

    # rejected — rework                                                         (:790)
    self._bump_rework("G-DC")                                                   (:796)
    if self._rework_count("G-DC") > MAX_REWORK_ITERATIONS:                      (:797)
        self._status=FAILED; self._current_step="max-rework-exceeded"; _updated_at   (:798-800)
        await self._update_app_status(app_id,"discovery_failed","max-rework-exceeded","Discovery")   (:801-804)
        return "failed"                                                         (:805)
    if input.source_type == "interview":                                        (:806)
        self._interview_completed = False; self._interview_artifact = None      (:808-809)
    # loop back to top of while → re-intake                                     (:697)
```
BRANCHES:
- **interview + expired** → immediate FAILED return.
- **doc-driven** → `_intake_requirements_doc` (never returns None).
- **approved** → merge → complete (does NOT call `_calculate_and_record_score`, unlike the code-analysis path — GOTCHA: score snapshot is code-analysis only).
- **rejected, count ≤ 3** → doc path re-dispatches ingester with rework feedback; interview path resets `_interview_completed`/`_interview_artifact` and loops to await a fresh submission.
- **rejected, count > 3** → FAILED.
GOTCHA: `_set_step` progress values here are hard-coded literals (90/95/98) — NOT contract-weight sums like the code-analysis path. Requirements steps (`requirements-ingest`/`requirements-interview`=10, `commit-artifacts`=60) are also hard-coded in the intake helpers.

### 7.2 `_intake_requirements_doc(app_id, input, repo, branch, artifact_repo_path) -> list[str]` (`:811-839`)
```
await self._set_step("requirements-ingest", 10.0)                              (:826)
result = await self._dispatch_pass_requirements(app_id, skill_id="requirements-doc-ingester",
    source_uri=input.source_uri)                                               (:827-831)
return await self._commit_requirements_artifact(app_id, repo, branch, artifact_repo_path,
    result_files=result.output_files,
    fallback_content=self._extract_pass_content("requirements-ingest"))        (:835-839)
```

### 7.3 `_intake_interview(app_id, repo, branch, artifact_repo_path) -> list[str] | None` (`:841-865`)
```
await self._set_step("requirements-interview", 10.0)                           (:853)
completed = await self._wait_for_interview_completion()                        (:854)
if self.cancelled: return None                                                 (:855-856)
if not completed: return None    # expired                                     (:857-858)
artifact = self._interview_artifact or {}                                      (:859)
content = json.dumps(artifact, indent=2)                                       (:860)
return await self._commit_requirements_artifact(app_id, repo, branch, artifact_repo_path,
    result_files=[], fallback_content=content)                                 (:861-865)
```
Returns `None` on cancel OR expiry (both surface as `committed_paths is None` → FAILED in caller).

### 7.4 `_wait_for_interview_completion() -> bool` (`:1057-1075`)
```
self._status = WAITING_FOR_SIGNAL; _updated_at                                 (:1066-1067)
await workflow.wait_condition(lambda: self._interview_completed
    or self._interview_expired or self.cancelled)                             (:1068-1072)
self._status = RUNNING; _updated_at                                            (:1073-1074)
return self._interview_completed                                               (:1075)
```
GOTCHA: **NO workflow-side timer** — the 14-day TTL lives API-side and arrives as `interview_expired`. A sleep here would be a redundant racy second deadline (`:1058-1064`). Returns `_interview_completed` (True=completed, False=expired-or-cancelled).

### 7.5 `_commit_requirements_artifact(...)` (`:867-920`)
```
await self._set_step("commit-artifacts", 60.0)                                 (:885)
batch=[]; committed=[]                                                          (:886-887)
for f in result_files or []:                                                    (:888)
    if not isinstance(f, OutputFile): continue                                  (:889-890)
    path = f.path                                                               (:891)
    if not path.startswith(f"build/{app_id}/"):                                 (:893)
        path = f"build/{app_id}/requirements/{path.lstrip('/')}"                (:894)
    batch.append((path, f.content)); committed.append(path)                     (:895-896)
if artifact_repo_path not in committed:                                         (:899)
    content = fallback_content or "{}"                                          (:900)
    batch.append((artifact_repo_path, content)); committed.append(artifact_repo_path)   (:901-902)
commit_ctx = self._execution_ctx("commit-requirements", app_id=app_id)          (:904)  # None (no portfolio_id)
execute_activity(write_artifacts_batch,
    WriteArtifactsBatchInput(repo, branch, files=batch,
        commit_message=f"discovery({app_id}): requirements-capability artifact",
        execution_context=commit_ctx),
    start_to_close_timeout=120s, retry=transient, activity_id="commit-requirements")   (:905-919)
return dedup_paths(committed)                                                   (:920)
```
GOTCHA: guarantees the canonical `requirements-capability.json` path is always committed (empty `{}` fallback if the agent produced no files) so the Build line's spec phase always finds a file (`:898-902`).

### 7.6 `_dispatch_pass_requirements(app_id, skill_id, source_uri) -> AgentTaskResult` (`:922-966`)
```
context = {"source_uri": source_uri}                                           (:935)
fb = self._rework_feedback.get("G-DC")                                         (:936)
if fb is not None: context["rework_feedback"] = fb                             (:937-938)
task_input = AgentTaskInput(task_type="discovery-requirements-ingest", app_id,
    skill_id, input_artifacts=[], source_repo="", context=context)             (:939-946)
result = execute_activity(dispatch_agent_task, task_input,
    start_to_close_timeout=AGENT_START_TO_CLOSE (3h),
    heartbeat_timeout=2m, retry=RETRY_POLICIES["agent_failure"],
    activity_id="agent-requirements-ingest")                                   (:947-954)
self._agent_metadata["requirements-ingest"] = {model_used, duration_ms,
    token_usage_input, token_usage_output, cost_estimate_usd, output_files}    (:955-962)
self._pass_results["requirements-ingest"] = result.output_artifacts            (:965)
return result
```
Note metadata key is `"requirements-ingest"` (not `skill_id`), mirroring `_dispatch_pass` so `_extract_pass_content("requirements-ingest")` works.

### 7.7 `_create_gate_pr_requirements(repo, branch, app_id, source_type)` (`:968-1005`)
```
rework_iter = self._rework_count("G-DC")                                       (:972)
intake_label = "interview-driven (requirements-elicitation)" if source_type=="interview"
             else "doc-driven (requirements-doc-ingester)"                     (:973-977)
pr_body = "## Gate G-DC Review: Discovery Complete (Build / requirements)\n\n..."
    + Application/Intake path/net-new explanation/Artifacts line              (:978-988)
if rework_iter > 0: pr_body += f"\n**Rework iteration:** {rework_iter}\n"       (:989-990)
pr_input = CreatePRInput(repo, source_branch=branch, target_branch="main",
    title=f"Gate G-DC: Requirements Complete — {app_id}",
    body=pr_body, labels=["gate-review","discovery","G-DC","build"])           (:992-999)
return execute_activity(create_pr, pr_input, start_to_close=60s, retry=transient)   (:1000-1005)
```
Labels include `"build"` (vs code-analysis PR labels `["gate-review","discovery","G-DC"]`).

---

## 8. VARIANT SELECTION (tech-stack specialist for Pass 1)

### 8.1 `_select_discovery_patterns_variant(catalog_artifacts) -> str | None` (`:1149-1230`)
Pure/deterministic — safe inside `@workflow.defn`; no IO/Temporal.
```
if not catalog_artifacts: return None                                          (:1162-1163)
raw = catalog_artifacts[0]                                                      (:1164)
if not isinstance(raw,str) or not raw.strip(): return None                     (:1165-1166)
try: parsed = json.loads(raw)
except (JSONDecodeError,TypeError,ValueError): return None                     (:1167-1170)
if not isinstance(parsed,dict): return None                                    (:1171-1172)
fingerprint = parsed.get("tech_fingerprint")                                   (:1179)
if not isinstance(fingerprint,dict):                                           (:1180)
    ts = parsed.get("tech_stack") or {}                                        (:1181)
    if isinstance(ts,dict):
        # normalize languages list-of-dicts → flat names                       (:1184-1192)
        langs_raw = ts.get("languages") or []
        lang_names=[]; for entry in langs_raw: if dict w/ name → str(name); elif str → entry
        dbs_raw = ts.get("databases") or []                                    (:1201)
        primary_db = dbs_raw[0] if dbs_raw and isinstance(dbs_raw,list) else ""(:1202)
        runtimes = ts.get("runtimes") or []                                    (:1208)
        fingerprint = {languages:lang_names, frameworks:ts.get("frameworks") or [],
            platforms:runtimes, runtimes:runtimes, databases:dbs_raw,
            database:primary_db, primary_language:lang_names[0] if lang_names else ""}   (:1209-1217)
    else: fingerprint = None                                                   (:1218-1219)
has_source = parsed.get("has_source_available")                                (:1220)
if not isinstance(has_source,bool): has_source = True                          (:1221-1222)
inputs = discovery_selector_inputs(fingerprint, has_source_available=has_source)   (:1227-1229)
return select_skill(DISCOVERY_PATTERNS_COMPOSITION, inputs)                     (:1230)
```
Any parse failure / non-dict → `None` → only the generic mapper dispatches (malformed catalog can't stall Discovery). GOTCHA: `has_source_available` defaults to **True** when absent/non-bool — so a catalog lacking that field will NOT select `discovery-patterns-doc-only`.

### 8.2 Composition evaluation (`composition/registered.py`, `composition/evaluator.py`, `composition/rules.py`)
- `DISCOVERY_PATTERNS_COMPOSITION` (`registered.py:105-119`): variant-selection table with `default="discovery-patterns"`.
- `discovery_selector_inputs(fp, has_source_available)` (`registered.py:122-187`): builds `SelectorInputs` with:
  - `tokens`: normalized items from `languages/frameworks/platforms/runtimes/tech_stack` (+ `tech_family`).
  - `candidates`: lowercased names from `languages/frameworks/platforms/runtimes` (str or dict-with-name) + `databases` strings, **prefixed** by `[database, primary_language, ...]` (`:170-177`).
  - `fields`: `{database, primary_language, has_source_available: "true"|"false"}`.
- `select_skill(...)` → `evaluate_composition(...).primary_skill` → `VariantSelectionTable.select(inputs)` — **first matching rule wins, else default** (`rules.py:170-179`).
- Rule order (`_discovery_rules`, `registered.py:71-102`), evaluated top-to-bottom:
  1. `equals has_source_available == "false"` → `discovery-patterns-doc-only` (`:74-79`).
  2. `token` match against mainframe tokens → `discovery-patterns-mainframe` (`:81-85`).
  3. `substring` over mainframe tokens → `discovery-patterns-mainframe` (`:86-90`). Mainframe tokens: `natural,adabas,cobol,jcl,cics,bms,copybook,tn3270,unisys,mainframe,broker,entirex,infoimage,ewf` (`registered.py:34-37`).
  4. DB matchers (substring), in order (`_DISCOVERY_DB_MATCHERS`, `:40-48`): `oracle/plsql → discovery-patterns-oracle`; `sqlserver/sql server/mssql/t-sql/tsql → discovery-patterns-sqlserver`.
  5. Language matchers (substring), in order (`_DISCOVERY_LANG_MATCHERS`, `:50-68`): `c#/csharp/vb.net/vbnet/classic asp/classic-asp/asp.net/.net/dotnet/vb6 → discovery-patterns-dotnet`; `javascript/typescript → discovery-patterns` (base — effectively no specialist); `java-ee/java ee/j2ee/struts/java → discovery-patterns-java`.
  6. No match → default `discovery-patterns`.
- Substring `_match` scans `rule.fields` if named, else `[*tokens, *candidates]` (`rules.py:193-204`).
GOTCHA: `javascript`/`typescript` map to the base `discovery-patterns`, so per `_execute_discovery` (`:330`), NO second dispatch happens for JS/TS apps (variant == default). GOTCHA: match precedence means `has_source_available=="false"` beats every tech signal — a doc-only project always routes to `discovery-patterns-doc-only`.

---

## 9. DISPATCH HELPERS

### 9.1 `_dispatch_pass(app_id, pass_name, input_artifacts, source_repo="", workspace_key="", artifact_repo="", artifact_ref="") -> AgentTaskResult` (`:1082-1147`)
```
pass_def = DISCOVERY_PASSES[pass_name]                                          (:1105)  # KeyError if unknown pass
context = {}
fb = self._rework_feedback.get("G-DC")                                         (:1107)
if fb is not None: context["rework_feedback"] = fb                             (:1108-1109)
task_input = AgentTaskInput(task_type=f"discovery-{pass_name}", app_id,
    skill_id=pass_def["skill_id"], input_artifacts, source_repo, workspace_key,
    artifact_repo, artifact_ref, context)                                      (:1110-1120)
result = execute_activity(dispatch_agent_task, task_input,
    start_to_close_timeout=AGENT_START_TO_CLOSE (3h),
    heartbeat_timeout=2m, retry=RETRY_POLICIES["agent_failure"] (3 attempts, 5-60s exp),
    activity_id=f"agent-{pass_name}")                                          (:1121-1135)
self._agent_metadata[pass_name] = {model_used, duration_ms, token_usage_input,
    token_usage_output, cost_estimate_usd, output_files}                       (:1138-1145)
return result
```
GOTCHA: `_dispatch_pass` writes ONLY `_agent_metadata[pass_name]` — it does NOT write `_pass_results`; the caller assigns `_pass_results[pass_name] = result.output_artifacts`. Rework feedback for the single gate G-DC is injected uniformly into every pass dispatch.

### 9.2 `_dispatch_discovery_patterns_variant(*, app_id, skill_id, input_artifacts, source_repo, workspace_key) -> AgentTaskResult` (`:1232-1281`)
Same retry/timeouts as `_dispatch_pass`. `task_type=f"discovery-{skill_id}"`, `activity_id=f"agent-{skill_id}"`, metadata stored under `_agent_metadata[skill_id]` (variant-specific key so it doesn't clobber the base pass telemetry). Injects `rework_feedback["G-DC"]` if present. Runs same `workspace_key`/`source_repo` as generic mapper.

---

## 10. `_run_parallel_passes(app_id, structural_artifacts, source_repo="", workspace_key="")` (`:1283-1439`)

Fan-out at contract sequence 3. Progress base for each: `cumulative_base = STEP_WEIGHTS["catalog"] + STEP_WEIGHTS["structural-analysis"]` (`:1323-1325`).

```
_set_step("business-logic-extraction", cumulative_base)                        (:1326)
_set_step("quality-risk-assessment", cumulative_base)                          (:1327)
_set_step("ux-accessibility-assessment", cumulative_base)                      (:1328)

include_data_passes = workflow.patched("discovery-data-steps-v1")              (:1330)
if include_data_passes:
    _set_step("data-domain-discovery", cumulative_base)                        (:1332)
    _set_step("shared-database-analysis", cumulative_base)                     (:1333)
include_capability_pass = workflow.patched("discovery-capability-extraction-v1")  (:1335-1337)
if include_capability_pass: _set_step("capability-extraction", cumulative_base)(:1339)
include_citation_pass = workflow.patched("discovery-citation-mapping-v1")      (:1341-1343)
if include_citation_pass: _set_step("compliance-citation-mapping", cumulative_base)  (:1345)

bl_task = self._dispatch_pass("business-logic-extraction", structural_artifacts, ...)   (:1347-1353)
qr_task = self._dispatch_pass("quality-risk-assessment", structural_artifacts, ...)     (:1354-1360)
ux_task = self._dispatch_pass("ux-accessibility-assessment", structural_artifacts, ...) (:1361-1367)
tasks = [bl_task, qr_task, ux_task]                                            (:1369)
if include_data_passes:
    tasks.extend([dispatch data-domain-discovery, dispatch shared-database-analysis])   (:1370-1385)
if include_capability_pass:
    cap_inputs = list(structural_artifacts) + self._pass_results.get("catalog",[])      (:1395-1396)
    tasks.append(dispatch capability-extraction with cap_inputs)               (:1397-1404)
if include_citation_pass:
    cite_inputs = list(structural_artifacts) + self._pass_results.get("catalog",[])     (:1413-1414)
    tasks.append(dispatch compliance-citation-mapping with cite_inputs)        (:1415-1422)

results = await asyncio.gather(*tasks)   # ALL PARALLEL                         (:1424)

self._pass_results["business-logic-extraction"] = results[0].output_artifacts  (:1426)
self._pass_results["quality-risk-assessment"]    = results[1].output_artifacts (:1427)
self._pass_results["ux-accessibility-assessment"]= results[2].output_artifacts (:1428)
idx = 3                                                                         (:1429)
if include_data_passes: assign results[idx], results[idx+1]; idx += 2          (:1430-1433)
if include_capability_pass: assign results[idx]; idx += 1                       (:1434-1436)
if include_citation_pass: assign results[idx]; idx += 1                         (:1437-1439)
```
GOTCHA (index alignment): `idx` bookkeeping MUST match the exact order tasks were appended (`data, capability, citation`). A rebuild must preserve both the dispatch append order AND the result-assignment order or artifacts get mis-assigned. GOTCHA (replay determinism): the three `workflow.patched(...)` guards keep in-flight histories deterministic — pre-patch runs fan out only the legacy three passes; a rebuild MUST gate the extra passes behind the identically-named patch IDs.

---

## 11. `_run_synthesis_and_tco(app_id, synthesis_input_artifacts, source_repo="", workspace_key="", artifact_repo="", artifact_ref="") -> (AgentTaskResult, AgentTaskResult)` (`:1441-1507`)
```
cumulative_base = sum(catalog, structural-analysis, business-logic-extraction,
    quality-risk-assessment, ux-accessibility-assessment)                      (:1463-1469)
_set_step("synthesis", cumulative_base)                                        (:1470)
_set_step("tco-baseline", cumulative_base)                                     (:1471)
synthesis_task = self._dispatch_pass("synthesis", synthesis_input_artifacts,
    source_repo, workspace_key, artifact_repo, artifact_ref)                   (:1473-1481)
tco_inputs = (self._committed_pass_paths.get("catalog") or self._pass_results.get("catalog",[]))
           + (self._committed_pass_paths.get("structural-analysis") or self._pass_results.get("structural-analysis",[]))   (:1487-1493)
tco_task = self._dispatch_pass("tco-baseline", tco_inputs, source_repo, workspace_key,
    artifact_repo, artifact_ref)                                               (:1494-1502)
synthesis_result, tco_result = await asyncio.gather(synthesis_task, tco_task)  (:1504-1506)  # PARALLEL
return synthesis_result, tco_result
```
GOTCHA: TCO inputs prefer committed branch paths (`_committed_pass_paths`) over raw pass-result strings so TCO also hydrates from git in commit-before-synthesis mode.

---

## 12. ARTIFACT-CONTENT & COLLECTION HELPERS

### 12.1 `_extract_pass_content(pass_name) -> str` (`:1509-1529`)
```
metadata = self._agent_metadata.get(pass_name) or {}                           (:1517)
output_files = metadata.get("output_files") or []                              (:1518)
target = DISCOVERY_PASSES.get(pass_name, {}).get("artifact", "")               (:1519)
if not target: return ""                                                       (:1520-1521)
for f in output_files:                                                          (:1523)
    if f.path.endswith(target): return f.content or ""   # exact match first   (:1524-1525)
for f in output_files:                                                          (:1526)
    if f.path.endswith(".json"): return f.content or ""  # any .json fallback  (:1527-1528)
return ""                                                                       (:1529)
```

### 12.2 `_collect_all_pass_artifacts() -> list[str]` (`:1531-1572`)
```
artifacts=[]; seen=set()
contract_pass_order = [p for p in DISCOVERY_PASSES
    if p not in ("synthesis","tco-baseline","gate-readiness-check")]           (:1547-1550)
for pass_name in contract_pass_order:                                           (:1551)
    if in seen: continue; seen.add
    artifacts.extend(self._committed_pass_paths.get(pass_name) or self._pass_results.get(pass_name,[]))   (:1558-1561)
for pass_name, vals in self._pass_results.items():   # fold runtime-only keys  (:1563)
    if in seen: continue
    if pass_name in ("synthesis","tco-baseline"): continue                     (:1566-1567)
    seen.add; artifacts.extend(self._committed_pass_paths.get(pass_name) or vals)   (:1568-1571)
return dedup_paths(artifacts)                                                   (:1572)
```
Prefers committed branch paths; excludes synthesis/tco/gate-readiness from synthesis inputs (they run after / aren't evidence). Deterministic contract order first.

---

## 13. COMMIT HELPERS

### 13.1 `_commit_artifacts(repo, branch, app_id) -> list[str]` (`:1574-1596`)
```
if workflow.patched("discovery-batch-writes-v1"):
    return await self._commit_artifacts_batched(repo, branch, app_id)          (:1594-1595)
return await self._commit_artifacts_legacy(repo, branch, app_id)               (:1596)
```
GOTCHA (why batched exists, `:1580-1590`): the old per-file path exceeded Temporal's 2 MB activity-input cap once evidence climbed past ~40 files (each scheduled activity accumulated all prior artifact paths in history). Batched keeps history linear in pass count (~9), not file count.

### 13.2 `_commit_artifacts_batched(repo, branch, app_id) -> list[str]` (`:1598-1623`)
```
committed_paths=[]
for pass_name in DISCOVERY_PASSES:                                             (:1613)
    if pass_name in self._committed_pass_paths:   # already committed incrementally
        committed_paths.extend(self._committed_pass_paths[pass_name]); continue  (:1618-1620)
    paths = await self._commit_one_pass(pass_name, repo, branch, app_id)       (:1621)
    committed_paths.extend(paths)
return dedup_paths(committed_paths)                                            (:1623)
```
In commit-before-synthesis mode, most passes already committed → this re-commits only synthesis/tco (idempotent otherwise).

### 13.3 `_commit_one_pass(pass_name, repo, branch, app_id) -> list[str]` (`:1625-1703`)
```
pass_def = DISCOVERY_PASSES.get(pass_name)
if pass_def is None: return []                                                 (:1637-1639)
artifacts = self._pass_results.get(pass_name, [])
if not artifacts: return []                                                    (:1640-1642)
artifact_path = f"discovery/{app_id}/{pass_def['artifact']}"                   (:1644)
metadata = self._agent_metadata.get(pass_name, {})                            (:1645)
output_files = metadata.get("output_files", [])                               (:1646)
file_paths = [f.path for f in output_files] if output_files else []           (:1647)
content = json.dumps({pass, skill_id, artifacts, file_artifacts=file_paths,
    model_used, duration_ms, token_usage:{input,output}, cost_estimate_usd,
    timestamp: workflow.now().isoformat()}, indent=2)                         (:1649-1662)
committed_paths=[artifact_path]; batch=[(artifact_path, content)]             (:1664-1665)
for file_artifact in output_files:                                            (:1666)
    file_path = f"discovery/{app_id}/files/{pass_name}/{file_artifact.path}"  (:1667-1669)
    batch.append((file_path, file_artifact.content)); committed_paths.append(file_path)   (:1670-1671)
commit_ctx = self._execution_ctx(f"commit-{pass_name}", app_id=app_id)        (:1673)  # None
execute_activity(write_artifacts_batch, WriteArtifactsBatchInput(repo, branch, files=batch,
    commit_message=f"discovery({app_id}): {pass_name} artifacts", execution_context=commit_ctx),
    start_to_close_timeout=120s, retry=transient, activity_id=f"commit-{pass_name}")   (:1673-1686)
if workflow.patched("patch-output-artifact-ref-v1"):                          (:1688)
    try: execute_activity(update_agent_task_output_ref,
        args=[app_id, f"discovery-{pass_name}", artifact_path],
        start_to_close=30s, retry=transient, activity_id=f"patch-output-ref-{pass_name}")   (:1689-1696)
    except Exception: pass   # observability only                             (:1697-1698)
self._committed_pass_paths[pass_name] = committed_paths                        (:1702)
return committed_paths                                                        (:1703)
```
GOTCHA: `workflow.now().isoformat()` embedded in committed content — deterministic on replay (Temporal-safe clock), but means re-committing the same pass on rework produces different content (timestamp changes) → not a strict no-op commit, though `commit_files` tolerates it.

### 13.4 `_commit_artifacts_legacy(repo, branch, app_id) -> list[str]` (`:1705-1795`)
Kept verbatim for replay determinism of pre-`discovery-batch-writes-v1` runs. Per-pass, per-file `write_artifact` (single-file) calls:
```
for pass_name, pass_def in DISCOVERY_PASSES.items():                          (:1712)
    artifacts = self._pass_results.get(pass_name, [])
    if not artifacts: continue                                                (:1713-1715)
    artifact_path = f"discovery/{app_id}/{pass_def['artifact']}"; content = same JSON shape as above   (:1717-1738)
    execute_activity(write_artifact, WriteArtifactInput(repo, branch, artifact_path, content,
        commit_message=...), start_to_close=60s, retry=transient, activity_id=f"commit-{pass_name}")   (:1740-1753)
    committed_paths.append(artifact_path)
    if workflow.patched("patch-output-artifact-ref-v1"): try update_agent_task_output_ref ... except pass   (:1756-1766)
    for file_artifact in output_files:                                        (:1768)
        file_path = f"discovery/{app_id}/files/{pass_name}/{file_artifact.path}"
        execute_activity(write_artifact, WriteArtifactInput(..., file_artifact.content, ...),
            start_to_close=60s, retry=transient,
            activity_id=f"commit-file-{pass_name}-{file_artifact.path.replace('/','-')}")   (:1773-1792)
        committed_paths.append(file_path)
return dedup_paths(committed_paths)                                           (:1795)
```
GOTCHA: legacy path does NOT populate `_committed_pass_paths` — so `_collect_all_pass_artifacts` falls back to raw pass-result strings for legacy runs. `activity_id` for file commits slugifies `/`→`-`.

---

## 14. PR-BODY & EVIDENCE & SCORE HELPERS

### 14.1 `_create_gate_pr_discovery(repo, branch, app_id)` (`:1797-1841`)
```
rework_iter = self._rework_count("G-DC")
pass_labels = {catalog:"Catalog", structural-analysis:"Application & Data Mapping",
    business-logic-extraction:"Business Logic Extraction", quality-risk-assessment:"Quality & Risk Assessment",
    ux-accessibility-assessment:"UX & Accessibility Assessment", data-domain-discovery:"Data Domain Discovery",
    shared-database-analysis:"Shared Database Analysis", capability-extraction:"Capability + System Grain",
    compliance-citation-mapping:"Compliance Citation Mapping", synthesis:"Discovery Synthesis",
    tco-baseline:"TCO Baseline"}                                              (:1800-1812)
pr_body = "## Gate G-DC Review: Discovery Complete\n\n**Application:** {app_id}\n\n### Discovery Passes Completed\n"
for pass_name, pass_def in DISCOVERY_PASSES.items():
    pr_body += f"- [x] {label} ({pass_def['skill_id']})\n"                     (:1818-1820)
pr_body += "\n### Artifacts\n"
for pass_name, pass_def in DISCOVERY_PASSES.items():
    pr_body += f"- `discovery/{app_id}/{pass_def['artifact']}`\n"             (:1822-1823)
if rework_iter > 0: pr_body += f"\n**Rework iteration:** {rework_iter}\n"      (:1825-1826)
pr_input = CreatePRInput(repo, branch, target_branch="main",
    title=f"Gate G-DC: Discovery Complete — {app_id}",
    body=pr_body, labels=["gate-review","discovery","G-DC"])                  (:1828-1834)
return execute_activity(create_pr, pr_input, start_to_close=60s, retry=transient)   (:1836-1841)
```
GOTCHA: PR body lists EVERY pass in `DISCOVERY_PASSES` as `[x]` completed regardless of whether patch-gated passes actually ran. Cosmetic only.

### 14.2 `_build_evidence_data(app_id, assembly_line="Discovery", step="", *, include_content=False, content_paths=None) -> dict` (`:1843-1920`) — OVERRIDE
Uses a `passes` key (not `steps`), keyed by pass name; top-level `pass_count`.
```
pass_titles = {same label map as pass_labels above}                           (:1864-1876)
passes={}
for pass_name, pass_def in DISCOVERY_PASSES.items():                          (:1879)
    artifacts = self._pass_results.get(pass_name, [])
    metadata = self._agent_metadata.get(pass_name, {})
    output_files = metadata.get("output_files", [])
    raw_file_artifacts=[]
    for f in output_files:
        if not isinstance(f, OutputFile): continue                            (:1888-1889)
        content_str = f.content if isinstance(f.content,str) else ""
        entry = {path, encoding, size=len(content_str.encode utf-8) or 0}     (:1891-1895)
        if include_content or (content_paths is not None and f.path in content_paths):
            entry["content"] = f.content                                      (:1896-1899)
        raw_file_artifacts.append(entry)
    deduped = list({f["path"]: f for f in raw_file_artifacts}.values())       (:1901-1903)  # last-wins per path
    passes[pass_name] = {title, skill_id, artifact,
        output=artifacts[0] if artifacts else "",
        metadata={k:v for k,v in metadata.items() if k != "output_files"},
        file_artifacts=deduped}                                              (:1904-1913)
return {assembly_line:"Discovery", app_id,
    pass_count=len([p for p in passes.values() if p["output"]]), passes}      (:1915-1920)
```
GOTCHA: `pass_count` counts only passes with a non-empty `output` (an artifact). Slim by default (no content) — content lives in git; `_submit_gate_evidence` never sets `include_content`/`content_paths` for G-DC (no thresholds).

### 14.3 `_calculate_and_record_score(app_id)` (`:1922-1945`) — code-analysis path only
```
score_input = CalculateReadinessScoreInput(app_id,
    dimensions=["code_quality","architecture_clarity"])                       (:1924-1927)
score_result = execute_activity(calculate_readiness_score, score_input,
    start_to_close=60s, retry=transient)                                      (:1928-1933)
snapshot_input = RecordScoreSnapshotInput(app_id, scores=score_result,
    snapshot_reason="discovery-complete")                                     (:1935-1939)
execute_activity(record_score_snapshot, snapshot_input, start_to_close=60s, retry=transient)   (:1940-1945)
```

---

## 15. RESILIENCE

- **Timeouts:** every agent dispatch uses `start_to_close=AGENT_START_TO_CLOSE` (3h, `agent_timeouts.py`) + `heartbeat_timeout=2m` (dispatch heartbeats ~30s → dead worker detected in ~2 min without waiting the full 3h). Agent-runtime also self-bounds via idle (600s) / absolute (10500s) timeouts (`agent_timeouts.py`). All non-agent activities: `start_to_close` 30s (status/gate-record/side-effects/score/output-ref) / 60s (create_pr/create_gate_record?30s/legacy write_artifact/score) / 120s (batch commits).
- **Retry policies:** `agent_failure` (max 3 attempts, 5→60s exp backoff) for agent dispatches; `transient` (= HTTP_RETRY_POLICY) for all DB/git/gate ops; `git_merge` (3 attempts, 5→30s, non_retryable=`MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected`) for the merge activity ONLY. `retry_policies.py:95-116`.
- **Heartbeats:** only agent dispatches set `heartbeat_timeout` (2m); non-agent activities don't heartbeat.
- **continue-as-new:** NONE. Discovery never calls `workflow.continue_as_new`. History length is bounded by MAX_REWORK_ITERATIONS (≤4 gate cycles) and batched commits (linear in pass count) — the `_commit_artifacts_batched` design (`:1580-1590`) is the explicit mitigation for what would otherwise be an unbounded-history risk under the legacy per-file path.
- **Idempotency:** `_commit_one_pass`/batch commits are idempotent on content (`commit_files` advances the ref with an unchanged tree). `update_agent_task_output_ref` swallows exceptions (observability-only). All three `persist_*` side-effect activities are best-effort (wrapped in try/except, logged, never fatal) and their DB UPSERTs are natural-key idempotent.
- **Compensation/rollback:** NONE explicit. On any unhandled exception in `_execute_discovery`, `run()`'s outer `except` sets `_status=FAILED`, best-effort pushes `discovery_failed`, and re-raises. Merge failures that aren't structured merge errors propagate → FAILED. There is no artifact cleanup/rollback; the per-app branch simply stays as-is.
- **Replay determinism guards (patch IDs a rebuild MUST preserve exactly):** `discovery-commit-before-synthesis-v1`, `discovery-batch-writes-v1`, `discovery-data-steps-v1`, `discovery-capability-extraction-v1`, `discovery-citation-mapping-v1`, `patch-output-artifact-ref-v1`, and (base) `mark-gate-ready-for-review-v1`. Changing/removing any of these breaks replay of in-flight histories.

---

## 16. GOTCHA INDEX (cross-cutting)
1. Single `@workflow.defn` class only; no second workflow class; no `discovery_patterns_router`; single gate G-DC (see Part 1 §0).
2. `_complexity_tier` and `reclassify_complexity` are effectively observability-only — no branch reads the tier (`:1011-1022`, §Part1 3.1).
3. `_portfolio_id`/`_wave_id` never set in `run()` → all `_execution_ctx(...)` calls return `None` → execution-context envelopes are absent (`base.py:345-346`).
4. Rework re-runs ONLY sequence-3 parallel passes + synthesis/tco; catalog & Pass 1 are NOT re-run (`:659`).
5. Rework counter check is strict `>` after bump → up to 3 reworks / 4 total cycles (`:648-649`).
6. `has_source_available` defaults True in variant selection (`:1220-1222`); JS/TS map to base skill → no specialist dispatch.
7. `persist_discovery_side_effects` parses a fixed list of 7 passes — data/capability/citation passes are NOT projected there (`:459-476`).
8. Requirements/Build path does NOT record a readiness score (`_calculate_and_record_score` is code-analysis only).
9. `_dispatch_pass` writes only `_agent_metadata`; callers must assign `_pass_results` — a rebuild that forgets this yields empty synthesis inputs.
10. `_run_parallel_passes` result-index bookkeeping must match dispatch append order (`data, capability, citation`).
11. Committed pass JSON embeds `workflow.now()` timestamp — re-commit content changes on rework (`:1661`).
12. Batched vs legacy commit is patch-gated for replay; batched exists to dodge Temporal's 2 MB activity-input cap (`:1580-1590`).

---

## 17. BEHAVIORAL PARITY CHECKLIST
A rebuild MUST satisfy every assertion:

1. `discovery.py` defines exactly one `@workflow.defn` workflow class (`DiscoveryWorkflow`); no `discovery_patterns_router`; `SINGLE_GATE_KEY == "G-DC"`.
2. `DISCOVERY_PASSES` and `STEP_WEIGHTS` are built from the authoritative Discovery contract at import; a missing/renamed step id raises `KeyError` at first weight lookup / import.
3. `run()` derives `branch = olympus/discovery/{app_id}/{run_suffix}` and `workspace_key = discovery-{app_id}-{run_suffix}` where `run_suffix` = last `-`-segment of workflow id (or first 8 chars).
4. `source_type ∈ {requirements_doc, interview}` forks to requirements mode BEFORE any code-analysis pass; all other source types run catalog → Pass 1 → parallel passes → synthesis+tco → commit → PR → gate.
5. Pass 1 always dispatches `legacy-architecture-mapper` (structural-analysis); a tech-stack specialist is dispatched IN PARALLEL (`asyncio.gather`) iff `_select_discovery_patterns_variant` returns a skill that is truthy AND `!= "discovery-patterns"`; specialist outputs merge into the `structural-analysis` pass bucket.
6. Variant selection is pure and follows first-match-wins rule order: doc-only (has_source_available=="false") → mainframe(token then substring) → DB matchers → language matchers → default `discovery-patterns`; `has_source_available` defaults True when absent.
7. Sequence-3 parallel passes always include business-logic-extraction/quality-risk-assessment/ux-accessibility-assessment; data-domain+shared-database, capability-extraction, and compliance-citation-mapping are each added iff their respective `workflow.patched(...)` guard is active, and result assignment matches dispatch order.
8. Synthesis + TCO run in parallel via `asyncio.gather`; synthesis input = `_collect_all_pass_artifacts()` (contract order, committed-paths preferred, excluding synthesis/tco/gate-readiness); TCO inputs = committed-or-raw catalog + structural-analysis.
9. In `discovery-commit-before-synthesis-v1` mode, each input pass is committed to the branch before synthesis and synthesis/TCO receive `artifact_repo`/`artifact_ref`; otherwise both are `""`.
10. Commit uses batched path under `discovery-batch-writes-v1`, legacy per-file path otherwise; both are idempotent and return dedup'd paths; committed pass JSON carries pass/skill_id/artifacts/file_artifacts/model_used/duration_ms/token_usage/cost/timestamp.
11. Three best-effort side-effect activities (`persist_decomposition_map`, `persist_discovery_side_effects`, `persist_capability_catalog`) run after commit, each wrapped in try/except that logs and never fails the workflow; capability persist only fires when `capability-extraction` produced parseable content.
12. Gate flow: `create_gate_record(G-DC)` → `_submit_gate_evidence(..., forward_risk_tier=False)` (slim bundle, no risk_tier/evidence_data on the criteria check since G-DC has no thresholds) → `_run_gate_pre_review` (fault-tolerant) → `_update_app_status(gate_review)` → `_wait_for_gate_decision(G_DC)`.
13. On `cancelled` → return `"cancelled"`. On `approved` (code path) → merge-with-retry → `_calculate_and_record_score` (`code_quality`,`architecture_clarity`, reason `discovery-complete`) → status `discovery_complete`/`completed`, progress 100, return `"completed"`; does NOT auto-start Rationalization.
14. On `rejected` → `_bump_rework("G-DC")`; if count `> 3` → FAILED (`max-rework-exceeded`, status `discovery_failed`), return `"failed"`; else re-run parallel passes with rework feedback (`context["rework_feedback"]`) and loop to synthesis.
15. Merge helper: `reconcile_and_merge_pr` with `git_merge` policy; on `MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected` → `set_gate_merge_blocked` → wait for `merge_retry` signal (`_merge_retry_signalled`, reset before blocking) → retry; other errors propagate → workflow FAILED; cancel during wait → return.
16. Requirements mode produces `build/{app_id}/requirements/requirements-capability.json` (canonical path always committed, `{}` fallback); doc path dispatches `requirements-doc-ingester` with `source_uri`; interview path parks on `interview_completed` / `interview_expired` (no workflow timer); expiry → FAILED; requirements PR labels include `"build"`; requirements mode does NOT record a score.
17. Signal handlers `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry` are inherited and NOT redefined; `reclassify_complexity`/`interview_completed`/`interview_expired` are Discovery-defined; `get_status` query returns current status snapshot.
18. All agent dispatches: `start_to_close=3h`, `heartbeat_timeout=2m`, `agent_failure` retry; non-agent ops use `transient` (30/60/120s); no continue-as-new; failure path sets `_status=FAILED` and re-raises.
