# CveTriageWorkflow — Atomic Regeneration Spec

**Source:** `temporal/olympus_workflows/workflows/cve_triage.py` (209 lines)
**Class:** `CveTriageWorkflow` — `temporal/olympus_workflows/workflows/cve_triage.py:109-118` (decorated `@workflow.defn` at line 109)
**Run method:** `run()` — `cve_triage.py:120-175`
**Phase:** P9-S17.3 — the SECOND autonomy-gated continuous-loop *executor* (sibling of `DependencySweepWorkflow`, which is P9-S17.2). Report-only CVE exposure assessment routed through the existing `autonomy_level` gate.

> Behavioral summary (the spec must reproduce HOW, not this): one-shot hourly cron workflow. It (1) coerces two dict lists into typed records, (2) runs one activity that assesses a synthetic CVE feed against a dependency manifest into prioritised exposure findings, (3) routes a *report action* through the autonomy gate requesting `report_only`, and (4) returns a 5-key summary dict. It performs **no git mutation, opens no PR, proposes no code change** — it is a reporting / governance layer. `cve_triage.py:19-24`, `:109-118`.

---

## 0. Class shape & inheritance (READ FIRST)

- **`CveTriageWorkflow` does NOT inherit from `BaseWorkflow`** (or any base). It is a bare `@workflow.defn` class with a single `@workflow.run` method — confirmed: `class CveTriageWorkflow:` at `cve_triage.py:110` has no base classes. Therefore **none of the inherited machinery in `_base-workflow.md` applies** — there is NO gate-signal handler, NO query handler, NO rework loop, NO continue-as-new, NO heartbeating, NO state beyond method locals. Do not import base behavior into a rebuild; a rebuild that subclasses BaseWorkflow would drift.
- **No instance state.** The class defines no `__init__`, no instance attributes, no class attributes. Each cron run is fully independent — "no inter-run state, no signal handlers" `cve_triage.py:114-117`.
- The workflow is a near-exact structural mirror of `DependencySweepWorkflow` (`workflows/dependency_sweep.py:103`) but calls a *different* assess activity and requests `report_only` instead of `assisted`. `cve_triage.py:5-6`.

**GOTCHA (module-import boundary):** All activity/type/registry imports are inside `with workflow.unsafe.imports_passed_through():` (`cve_triage.py:60-71`). This is mandatory — it lets the Temporal determinism sandbox pass these imports through unchanged. A rebuild that imports `assess_cve_exposure`, `gate_cve_report`, `LOOP_PATTERN_REGISTRY`, `RETRY_POLICIES`, `AutonomyPolicy` at module top-level *outside* this block will raise sandbox restriction errors at workflow load.

---

## 1. STATE

There are **no instance variables**. All state is local to `run()`:

| Local | Type | Initial value | Mutated when |
|---|---|---|---|
| `requested_level` | `str` | `LOOP_PATTERN_REGISTRY.get("cve-triage").default_autonomy_level` → `"report_only"` | assigned once, never mutated. `cve_triage.py:132-134` |
| `paths` | `tuple[str, ...]` | `tuple(triage_input.report_paths or ())` | assigned once. `cve_triage.py:136` |
| `feed` | `list[Advisory]` | `_advisories_from_dicts(triage_input.feed)` | assigned once. `cve_triage.py:137` |
| `manifest` | `list[DependencyPin]` | `_pins_from_dicts(triage_input.manifest)` | assigned once. `cve_triage.py:138` |
| `assessment` | `AssessCveResult` | result of `assess_cve_exposure` activity | assigned once (awaited). `cve_triage.py:140-145` |
| `gated_report_only` | `int` | `0` | set to `1` iff gate held at floor (see §5). `cve_triage.py:147`, `:166-167` |
| `outcome` | `GatedReportOutcome` | result of `gate_cve_report` activity | assigned once (awaited). `cve_triage.py:151-165` |

**GOTCHA (`requested_level` is data-driven, not hardcoded):** The requested rung is read from the registry at runtime — `LOOP_PATTERN_REGISTRY.get(_PATTERN_NAME).default_autonomy_level` with `_PATTERN_NAME = "cve-triage"` (`cve_triage.py:78`, `:132-134`). The registry entry for `"cve-triage"` has `default_autonomy_level="report_only"` (`registries/loop_pattern.py:151-153`). A rebuild must resolve this via the registry, not inline the literal `"report_only"`, so behavior tracks the registry if the pattern's default changes. `LOOP_PATTERN_REGISTRY.get()` raises `UnknownLoopPatternError` if the name is missing (`loop_pattern.py:102-108`) — but `"cve-triage"` is always registered.

### Input dataclass — `CveTriageInput` (`cve_triage.py:81-106`)

Single positional payload (idiomatic Temporal one-arg shape). NOT a frozen `olympus_contracts` member (`cve_triage.py:94-95`).

| Field | Type | Default | Meaning |
|---|---|---|---|
| `loop_id` | `str` | (required) | loop identity, passed to gate. `:98` |
| `application_id` | `str` | (required) | touched app identity, passed to gate. `:99` |
| `risk_tier` | `str \| int \| None` | (required) | touched app tier the gate caps the requested level to. `:100` |
| `feed` | `list[dict[str, str]]` | `field(default_factory=list)` | synthetic vuln feed: `{cve_id, severity, affected_package, affected_version_range}` dicts. `:101` |
| `manifest` | `list[dict[str, str]]` | `field(default_factory=list)` | installed deps: `{name, version}` dicts. `:102` |
| `report_paths` | `tuple[str, ...]` | `()` | path(s) the report is associated with; fed to gate as denylist-matched `paths`. `:103` |
| `profile_id` | `str \| None` | `None` | profile whose autonomy policy the gate loads from DATA. `:104` |
| `portfolio_id` | `str \| None` | `None` | portfolio scope, passed to gate. `:105` |
| `policy_override` | `AutonomyPolicy \| None` | `None` | inject a policy directly (pin tiers/denylist deterministically for tests); else gate loads profile policy from DATA. `:106` |

---

## 2. SIGNALS & QUERIES

**NONE.** The class defines no `@workflow.signal` and no `@workflow.query` handlers. Confirmed by absence in `cve_triage.py` and by the explicit design note "no signal handlers" (`cve_triage.py:114`). There is no `wait_condition`, no gate-approval signal, no rework signal. A rebuild MUST NOT add signal/query handlers — the workflow terminates deterministically after two sequential activity awaits. (Contrast: gate-bearing workflows like ModernizationWorkflow buffer a gate decision via a signal + `wait_condition`; this executor does not — the "gate" here is an activity call, §4/§5.)

---

## 3. CONTROL FLOW — `run()` (`cve_triage.py:120-175`)

Structured pseudocode preserving every statement. There are **no `if/elif/else` chains, no loops, no try/except, no early returns** inside `run()` except the single `if` at `:166`. It is straight-line: two awaited activities and one conditional flag set.

```
async def run(triage_input: CveTriageInput) -> dict[str, int]:

    # (1) Resolve requested rung from the loop-pattern registry (NOT hardcoded)
    requested_level = LOOP_PATTERN_REGISTRY.get("cve-triage").default_autonomy_level
    #   -> "report_only"   (registries/loop_pattern.py:151-153)

    # (2) Normalise inputs — pure, deterministic, safe in workflow code
    paths    = tuple(triage_input.report_paths or ())          # :136
    feed     = _advisories_from_dicts(triage_input.feed)        # :137  (helper §3a)
    manifest = _pins_from_dicts(triage_input.manifest)          # :138  (helper §3b)

    # (3) ACTIVITY 1 — assess exposure (sequential, awaited)
    assessment = await execute_activity(
        assess_cve_exposure,
        AssessCveInput(feed=feed, manifest=manifest, report_paths=paths),
        start_to_close_timeout = 2 minutes,
        retry_policy = RETRY_POLICIES["transient"],            # :140-145
    )   # -> AssessCveResult

    gated_report_only = 0                                       # :147

    # (4) ACTIVITY 2 — route report action through autonomy gate (sequential, awaited)
    outcome = await execute_activity(
        gate_cve_report,
        GateReportInput(
            loop_id         = triage_input.loop_id,
            application_id  = triage_input.application_id,
            requested_level = requested_level,                 # "report_only"
            risk_tier       = triage_input.risk_tier,
            paths           = paths,
            profile_id      = triage_input.profile_id,
            portfolio_id    = triage_input.portfolio_id,
            policy_override = triage_input.policy_override,
        ),
        start_to_close_timeout = 1 minute,
        retry_policy = RETRY_POLICIES["transient"],            # :151-165
    )   # -> GatedReportOutcome

    # (5) THE ONLY BRANCH — did the gate hold the report at the floor?
    if (not outcome.escalate) and (outcome.permitted_level == "report_only"):   # :166
        gated_report_only = 1                                                    # :167
    # else: leave gated_report_only == 0 (gate escalated: denylist hit / attempt cap)

    # (6) Return the 5-key operator summary
    return {
        "assessed":          assessment.assessed,          # manifest entries examined
        "exposed":           len(assessment.findings),     # exposed deps (NOT a stored count field)
        "critical":          assessment.critical,
        "high":              assessment.high,
        "gated_report_only": gated_report_only,
    }   # :169-175
```

**GOTCHA (the branch is an AND of two conditions):** `gated_report_only = 1` requires BOTH `outcome.escalate is False` AND `outcome.permitted_level == "report_only"` (`cve_triage.py:166`). If the gate escalated (`escalate == True`) OR the permitted level is anything other than the exact string `"report_only"`, the flag stays `0`. Because the request is `report_only` (the ladder floor), the *normal* path is `escalate=False, permitted_level="report_only"` → flag `1`. A denylist hit forces `escalate=True` → flag `0`. Capping never inflates above `report_only`, so `permitted_level` is `"report_only"` on every non-escalated path. `cve_triage.py:16-17`, `:126-128`.

**GOTCHA (`exposed` is computed, not stored):** The summary's `"exposed"` value is `len(assessment.findings)` (`cve_triage.py:172`), NOT any single count field on `AssessCveResult`. Per `AssessCveResult` docs, `len(findings)` = critical+high+medium+low + any unknown-severity findings (`activities/cve_triage.py:166-167`). The summary omits `medium` and `low` and the unknown bucket — the operator triages critical/high first (`cve_triage.py:27-32`).

### §3a Helper `_advisories_from_dicts(feed)` (`cve_triage.py:178-193`)

Pure, safe in workflow code (no I/O, no clock).

```
_advisories_from_dicts(feed):
    return [
        Advisory(
            cve_id                 = str(a.get("cve_id", "")),
            severity               = str(a.get("severity", "")),
            affected_package       = str(a.get("affected_package", "")),
            affected_version_range = str(a.get("affected_version_range", "")),
        )
        for a in feed
    ]
```
- **GOTCHA:** Missing keys default to `""` (empty string), which the assessment treats as non-matching / non-actionable — no exception is raised for a malformed feed entry. `cve_triage.py:181-183`. All values are stringified via `str(...)`.

### §3b Helper `_pins_from_dicts(manifest)` (`cve_triage.py:196-208`)

```
_pins_from_dicts(manifest):
    return [
        DependencyPin(
            name    = str(m.get("name", "")),
            version = str(m.get("version", "")),
        )
        for m in manifest
    ]
```
- **GOTCHA:** Missing `name`/`version` become `""` → treated as non-matching, no raise. `cve_triage.py:199-201`.

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS

**No child workflows.** Two activities, **strictly sequential** (each `await`ed before the next; no `asyncio.gather`, no parallelism).

### Activity 1 — `assess_cve_exposure` (`cve_triage.py:140-145`)

| Property | Value |
|---|---|
| Callable | `assess_cve_exposure` (activity in `activities/cve_triage.py:300-312`, `@foundry_activity(config=ActivityConfig(enable_observability=True))`) |
| Argument | `AssessCveInput(feed=feed, manifest=manifest, report_paths=paths)` |
| `start_to_close_timeout` | `timedelta(minutes=2)` |
| `retry_policy` | `RETRY_POLICIES["transient"]` = `HTTP_RETRY_POLICY` → `initial_interval=1s, maximum_interval=15s, maximum_attempts=3, backoff_coefficient=2.0` (`retry_policies.py:34,110-111`; `temporal_base/retry_policies.py:35-40`) |
| `non_retryable_errors` | none declared |
| Returns | `AssessCveResult` |
| Sequencing | sequential (awaited before Activity 2) |

**Assessment activity behavior** (must reproduce; delegates to pure `assess_exposure`, `activities/cve_triage.py:245-297`):

```
assess_exposure(feed, manifest, report_paths):
    findings = []
    for dep in manifest:                                    # examine EVERY manifest entry
        dep_name = (dep.name or "").strip().lower()
        for adv in feed:                                    # against EVERY advisory
            if (adv.affected_package or "").strip().lower() != dep_name:
                continue                                    # package name mismatch (case-insensitive)
            if not _version_in_range(dep.version, adv.affected_version_range):
                continue                                    # installed version not in affected range
            findings.append(ExposureFinding(
                cve_id                 = adv.cve_id,
                severity               = (adv.severity or "").strip().lower(),
                package                = dep.name,           # original-case name
                version                = dep.version,
                affected_version_range = adv.affected_version_range,
                paths                  = report_paths,       # echoed onto every finding
            ))
    findings.sort(key=lambda f: _severity_rank(f.severity)) # STABLE sort, most-severe first
    counts = {critical:0, high:0, medium:0, low:0}
    for f in findings:
        if f.severity in counts: counts[f.severity] += 1     # unknown severity NOT counted
    return AssessCveResult(
        findings=findings, assessed=len(manifest),
        critical=..., high=..., medium=..., low=...,
    )
```

- **Nested loop = O(manifest × feed).** One finding per (dep, advisory) match — a single dep can appear multiple times if matched by multiple advisories. `activities/cve_triage.py:264-280`.
- **Case-insensitive package match** via `.strip().lower()` on both sides (`:265,:267`).
- **`_severity_rank`** (`activities/cve_triage.py:63-73`): index into `SEVERITY_ORDER = ("critical","high","medium","low")` (`:60`); **unknown/empty severity ranks LAST** (`len(SEVERITY_ORDER)` = 4) so it can never jump the queue (`:71-73`). GOTCHA: rank uses `(severity or "").strip().lower()`.
- **Stable sort** keeps discovery (manifest→feed) order on severity ties (`:282-283`).
- **`_version_in_range`** (`activities/cve_triage.py:206-242`): range is `"lo-hi"` (inclusive both ends) or a single pinned version treated as `[v,v]`. Parses dotted-numeric via `_parse_version` (`:187-203`) which returns `None` for empty/non-numeric → comparison **fails conservative → not exposed** (never a false positive). Versions zero-padded to equal length before tuple compare. GOTCHA: any unparseable version OR bound returns `False` (`:215-217,:230-231`).
- **`assessed = len(manifest)`** — counts every manifest entry examined, matched or not (`:290-296`).
- Pure + total: never raises (`:259-260`).

### Activity 2 — `gate_cve_report` (`cve_triage.py:151-165`)

| Property | Value |
|---|---|
| Callable | `gate_cve_report` (activity in `activities/cve_triage.py:365-406`, `@foundry_activity(config=ActivityConfig(enable_observability=True))`) |
| Argument | `GateReportInput(loop_id, application_id, requested_level="report_only", risk_tier, paths, profile_id, portfolio_id, policy_override)` |
| `start_to_close_timeout` | `timedelta(minutes=1)` |
| `retry_policy` | `RETRY_POLICIES["transient"]` = `HTTP_RETRY_POLICY` (3 attempts, 1→15s exp backoff) |
| `non_retryable_errors` | none declared |
| Returns | `GatedReportOutcome` (concrete scalar fields only) |
| Sequencing | sequential (awaited after Activity 1) |

**Gate adapter behavior** (`activities/cve_triage.py:365-406`) — this is the **autonomy-gate seam**:

```
gate_cve_report(payload):
    # lazy import INSIDE the activity body (keeps module import-light)
    from olympus_workflows.activities.autonomy_eval import EvaluateAutonomyInput, evaluate_autonomy
    result = await evaluate_autonomy(EvaluateAutonomyInput(
        loop_id         = payload.loop_id,
        application_id  = payload.application_id,
        requested_level = payload.requested_level,   # "report_only"
        risk_tier       = payload.risk_tier,
        profile_id      = payload.profile_id,
        paths           = tuple(payload.paths),
        control_ids     = (),                        # cve-triage supplies NO control ids
        policy_override = payload.policy_override,
        portfolio_id    = payload.portfolio_id,
    ))
    decision = result.decision
    return GatedReportOutcome(
        permitted_level = decision.permitted_level,
        escalate        = decision.escalate,
        reason          = decision.reason,
        requested_level = decision.requested_level,
        risk_tier       = decision.risk_tier,
    )
```

- **GOTCHA (Temporal-boundary serialisation seam — this is WHY the adapter exists):** The workflow does NOT call `evaluate_autonomy` directly. `evaluate_autonomy` returns an `EvaluateAutonomyResult` whose nested `AutonomyDecision.metadata` is typed `dict[str, object]`, and Temporal's payload converter **cannot round-trip a bare `object` value** across the activity→workflow boundary. So `gate_cve_report` calls the real gate IN-PROCESS and projects only concrete scalar fields onto `GatedReportOutcome`. The report genuinely passes through the gate's per-tier cap / denylist / attempt-cap logic — the adapter adds NO gate logic, it is purely the serialisation seam. `activities/cve_triage.py:30-38,:365-380`; module docstring `cve_triage.py` workflow-side note `:46-49`.
- **GOTCHA (decision recording is a side effect of the gate):** `evaluate_autonomy` records the verdict exactly as always — decision log by default; **evidence emit when the flag is on** (`activities/cve_triage.py:378-379`; and `autonomy_eval.py:297-301` sets `status = "non-compliant" if decision.escalate else "compliant"`). The workflow itself emits nothing; recording is entirely inside the gate activity.
- **`control_ids=()`** is hardcoded empty for cve-triage (`activities/cve_triage.py:394`) — the report action carries no control ids; only `paths` are matched against the denylist.

---

## 5. GATE HANDLING

**There is no Temporal signal-based gate here.** The "gate" is the synchronous `gate_cve_report` activity call (Activity 2, §4). There is:
- **No evidence-assembly-then-wait** in the workflow (the gate activity records the decision internally).
- **No `workflow.wait_condition`** on any approve/reject signal.
- **No rework loop, no rework counter, no `merge_blocked` handling.** (Contrast W17 merge-blocked loops — cve-triage performs no merge, opens no PR: `cve_triage.py:19-21`.)

**Routing of the gate verdict** (the sole decision the workflow makes with the verdict) — `cve_triage.py:166-167`:

| `outcome.escalate` | `outcome.permitted_level` | `gated_report_only` | Meaning |
|---|---|---|---|
| `False` | `"report_only"` | `1` | Expected steady state — gate held the report at the ladder floor. `:166-167,:30-32` |
| `True` | (any) | `0` | Gate escalated — denylist hit / attempt cap. `:16-17,:32` |
| `False` | `!= "report_only"` | `0` | (Not reachable on the normal path — capping never inflates above the requested floor; defensive.) `:166` |

- **GOTCHA (`report_only` is the ladder floor, so capping never inflates):** The autonomy ladder is `report_only` (L1) < `assisted` < `unattended` (`loop_pattern.py:24,:44`). Because cve-triage *requests* the lowest rung, the per-tier cap can only hold it at `report_only` — even a Tier-3 app does not raise it. The only way `gated_report_only` becomes `0` is an escalation forced by a denylist hit or attempt cap. `cve_triage.py:16-17`.

---

## 6. RESILIENCE

- **Timeouts:** Activity 1 `start_to_close_timeout = 2 min` (`:143`); Activity 2 `= 1 min` (`:163`). No `schedule_to_close`, no `heartbeat_timeout`, no `schedule_to_start` set. No workflow-level `run_timeout` set here.
- **Heartbeats:** none — neither activity heartbeats; both are short pure/in-process computations.
- **Retries:** both activities use `RETRY_POLICIES["transient"]` = `HTTP_RETRY_POLICY` (max 3 attempts, exp backoff 1→15s, coeff 2.0). No `non_retryable_error_types`. `retry_policies.py:34,110`; `temporal_base/retry_policies.py:35-40`.
- **`@foundry_activity` error wrapping** (`temporal_base/activities.py:79+`): on exception, already-typed `WorkflowError`/`ApplicationError` pass through unchanged; otherwise `_is_retryable_error` (string-match on type name for timeout/connection/network/etc.) decides whether it re-raises as `RetryableError` — so transient-looking failures retry under the transient policy. `activities/cve_triage.py:57-76`.
- **Continue-as-new:** **NONE.** No `continue_as_new`, no turn cap, no run counter — the workflow is one-shot and completes after the two awaits. Recurrence is external via the Temporal Schedules API cron `"0 * * * *"` (hourly); the schedule creates a fresh workflow run each hour (`cve_triage.py:34-44,:111`).
- **Idempotency:** The workflow reads no clock/env/DB and holds no state (`cve_triage.py:46-49`); it is deterministic given its input. All clock/decision/timestamp logic lives in the activities (`assess_cve_exposure` is pure; `evaluate_autonomy` captures the timestamp and resolves the cap). Re-running with identical input yields an identical summary. The gate's decision-record write is the only persistent side effect.
- **Compensation / rollback:** **NONE and BY DESIGN** — the workflow makes no mutation to compensate for: no git write, no PR, no code change (`cve_triage.py:19-21`). Nothing to roll back.

---

## 7. GOTCHAs (consolidated)

1. **No BaseWorkflow inheritance** — bare `@workflow.defn`; do not add gate signals/queries/rework loops. `cve_triage.py:110`.
2. **Imports inside `workflow.unsafe.imports_passed_through()`** — mandatory sandbox pass-through. `cve_triage.py:60-71`.
3. **`requested_level` from registry, not literal** — resolves to `"report_only"` via `LOOP_PATTERN_REGISTRY.get("cve-triage").default_autonomy_level`. `cve_triage.py:132-134`; `loop_pattern.py:151-153`.
4. **The single `run()` branch is an AND** — `not escalate` AND `permitted_level == "report_only"`. `cve_triage.py:166`.
5. **`exposed = len(findings)`**, a computed count, not a stored field; may exceed critical+high (includes medium/low/unknown). `cve_triage.py:172`; `activities/cve_triage.py:166-167`.
6. **Gate seam via adapter** — workflow never calls `evaluate_autonomy` directly because `AutonomyDecision.metadata: dict[str, object]` cannot round-trip; `gate_cve_report` projects scalars. `activities/cve_triage.py:30-38`.
7. **Unknown severity ranks LAST and is not counted** — `_severity_rank` returns `len(SEVERITY_ORDER)`; count dict has no unknown bucket. `activities/cve_triage.py:71-73,:285-288`.
8. **Version comparison fails conservative** — unparseable version/bound → not exposed (no false positives). `activities/cve_triage.py:215-217,:230-231`.
9. **Case-insensitive package match**, but `ExposureFinding.package`/`version` keep original manifest case. `activities/cve_triage.py:265-277`.
10. **Missing dict keys tolerated as `""`** in both helpers — never raises on malformed feed/manifest. `cve_triage.py:181-183,:199-201`.
11. **Report-only, always** — no mutation, no PR, no upgrade proposal; contrast dependency-sweep. `cve_triage.py:19-21`; `activities/cve_triage.py:17-25`.
12. **Both activities sequential** — no `asyncio.gather`; assess must complete before gate. `cve_triage.py:140-165`.

---

## 8. Behavioral parity checklist

A rebuild MUST satisfy every assertion:

- [ ] Class is a bare `@workflow.defn` with a single `@workflow.run async def run(self, triage_input: CveTriageInput) -> dict[str, int]` — no base class, no signals, no queries, no instance state.
- [ ] `run()` resolves `requested_level` via `LOOP_PATTERN_REGISTRY.get("cve-triage").default_autonomy_level` (== `"report_only"`); does NOT inline the literal.
- [ ] `paths = tuple(triage_input.report_paths or ())`.
- [ ] Coerces `feed`→`list[Advisory]` and `manifest`→`list[DependencyPin]` via the two helpers, tolerating missing dict keys as `""`, stringifying all values.
- [ ] Calls exactly two activities, sequentially, in order: `assess_cve_exposure` then `gate_cve_report`. No child workflows. No `asyncio.gather`.
- [ ] `assess_cve_exposure` invoked with `AssessCveInput(feed, manifest, report_paths=paths)`, `start_to_close_timeout=2min`, `retry_policy=transient` (HTTP: 3 attempts, 1→15s, coeff 2.0).
- [ ] `gate_cve_report` invoked with `GateReportInput(loop_id, application_id, requested_level, risk_tier, paths, profile_id, portfolio_id, policy_override)`, `start_to_close_timeout=1min`, `retry_policy=transient`.
- [ ] `gated_report_only` starts at `0`; set to `1` iff `(not outcome.escalate) and (outcome.permitted_level == "report_only")`; else remains `0`.
- [ ] Return dict has exactly keys `{"assessed","exposed","critical","high","gated_report_only"}` with `exposed == len(assessment.findings)`, `assessed == assessment.assessed`, `critical/high` from the assessment. (No `medium`/`low` in the summary.)
- [ ] Given a Tier-3 app with no denylist hit: `permitted_level == "report_only"`, `escalate == False`, `gated_report_only == 1` (capping never inflates above the floor).
- [ ] Given a denylist-hit path: `escalate == True`, `gated_report_only == 0`.
- [ ] Assessment: for each manifest dep × each advisory, a finding iff package names match case-insensitively AND installed version is inside the inclusive range (`"lo-hi"` or single pinned `[v,v]`); a single dep may yield multiple findings.
- [ ] Findings sorted most-severe first by `("critical","high","medium","low")`, stable on ties; unknown/empty severity sorts LAST and is excluded from all four severity counts.
- [ ] Unparseable version or range bound → dep NOT exposed (conservative; no false positive).
- [ ] Workflow performs no git mutation, opens no PR, proposes no code change; no continue-as-new; no compensation. Recurs only via external hourly cron `"0 * * * *"`.
- [ ] `gate_cve_report` routes the report through the real `evaluate_autonomy` in-process (with `control_ids=()`), returning only the scalar `GatedReportOutcome` fields — the workflow never touches `EvaluateAutonomyResult`/`AutonomyDecision.metadata`.
