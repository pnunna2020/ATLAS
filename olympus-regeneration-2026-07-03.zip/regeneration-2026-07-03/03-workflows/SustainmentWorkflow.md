# SustainmentWorkflow — Atomic Regeneration Spec

**Source of truth:** `temporal/olympus_workflows/workflows/sustainment.py` (lines 1–666). Every claim below cites `path:line` relative to repo root.
**Base class / inherited machinery:** `HILSignalsMixin` (`temporal/olympus_workflows/temporal_base/signals.py`). `SustainmentWorkflow` inherits DIRECTLY from `HILSignalsMixin` (`sustainment.py:172`) — it is NOT a `LineWorkflowBase` subclass. See `_base-workflow.md` for the shared mixin surface; the full mixin surface is also reproduced in §2 here because it is small and load-bearing.
**Decorators:** `@workflow.defn` on the class (`sustainment.py:171`); `@workflow.run` on `run` (`sustainment.py:213`); one `@workflow.signal` — `override_approved` (`sustainment.py:597`); one `@workflow.query` — `get_status` (`sustainment.py:627`).

**What this workflow IS (from docstring `sustainment.py:1–43`):** a continuous, portfolio-wide, cron/Temporal-Schedule-triggered workflow that runs ONE bounded sweep per invocation to keep legacy + modernized apps operational. It is **NOT a long-running loop** and holds **NO per-app state** — it emits ONE portfolio-wide sweep report artifact per invocation (`sustainment.py:28–33`). There are **NO HIL gates, NO wait_conditions, NO continue-as-new** in `run()`. The only signal (`override_approved`) is fire-and-forget, consumed passively by later steps that read `self._override_decisions`.

The 8-step canonical shape (docstring `sustainment.py:5–16`):
1. intake (code) — activity selection
2–6. cve-triage, incident-response, sla-monitoring, change-conflict-detection, cost-anomaly-detection (agent) — run in parallel via `asyncio.gather`
7. persist-sustainment-sweep-side-effects (code) — DB projection, best-effort
8. commit-sweep-summary (code) — portfolio-wide summary + `SustainmentSweepCompletedSignal`

---

## 0. Module-level constants and pure helpers (MUST reproduce verbatim)

### 0.1 `SUSTAINMENT_ACTIVITIES` (`sustainment.py:88–109`)
Dict mapping activity name → `{"skill_id", "artifact"}`. Reproduce EXACTLY:

| activity key | skill_id | artifact filename |
|---|---|---|
| `cve-triage` | `patch-assessment` | `cve-triage.json` |
| `incident-response` | `incident-response` | `incident-response.json` |
| `sla-monitoring` | `sla-breach-investigation` | `sla-monitoring.json` |
| `change-conflict-detection` | `change-conflict-resolver` | `change-conflict.json` |
| `cost-anomaly-detection` | `cost-anomaly-investigation` | `cost-anomaly.json` |

**GOTCHA (name mismatch):** the artifact filename for `change-conflict-detection` is `change-conflict.json` (NOT `change-conflict-detection.json`), and `cost-anomaly-detection` → `cost-anomaly.json`. The activity KEY and the artifact NAME differ for exactly these two. Also note `incident-response`'s activity key equals BOTH its skill_id and its artifact base. Do not "regularize."

### 0.2 `ACTIVITY_ORDER` (`sustainment.py:115–121`)
Ordered list — the canonical serialization order AND the order the sweep-summary `activities` map is built in:
```python
["cve-triage", "incident-response", "sla-monitoring",
 "change-conflict-detection", "cost-anomaly-detection"]
```

### 0.3 `CANONICAL_STEPS` (`sustainment.py:126–131`)
```python
["intake", *ACTIVITY_ORDER, "persist-sustainment-sweep-side-effects", "commit-sweep-summary"]
```
= 8 entries. Sequence numbers per docstring (`sustainment.py:123–125`): intake=1, the 5 activities share sequence=2 (parallel), persist=3, commit-sweep-summary=4. These sequence numbers are **documented intent only** (used by the FE `stepRegistry`); this class does NOT store them anywhere and never references `CANONICAL_STEPS` in code (constant is defined but unused at runtime).

### 0.4 `_SCHEDULE_CADENCE` (`sustainment.py:138–141`)
```python
{"sus-daily":  ["cve-triage", "incident-response"],
 "sus-weekly": list(ACTIVITY_ORDER)}   # copy of all 5, in canonical order
```

### 0.5 `_activities_for_schedule(schedule_id, override=None) -> list[str]` (`sustainment.py:144–168`)
Pure module-level function. Reproduce this branch structure EXACTLY:
```python
sid = (schedule_id or "").lower()                       # :157
if sid.startswith("sus-adhoc"):                         # :158
    if override:                                        # :159 truthy, non-empty list
        picked = [a for a in ACTIVITY_ORDER if a in set(override)]   # :161
        return picked if picked else list(ACTIVITY_ORDER)            # :162
    return list(ACTIVITY_ORDER)                         # :163
for prefix, cadence in _SCHEDULE_CADENCE.items():       # :164 iterates sus-daily THEN sus-weekly
    if sid.startswith(prefix):                          # :165
        return list(cadence)                            # :166
return list(ACTIVITY_ORDER)                             # :168 unknown prefix → all 5 (back-compat)
```
- **GOTCHA (canonical-order forcing):** `override` is filtered THROUGH `ACTIVITY_ORDER` (`:161`), so the returned list is ALWAYS in canonical order regardless of the order the caller passed override items. The comprehension iterates `ACTIVITY_ORDER` and keeps items present in `set(override)`.
- **GOTCHA (empty-filter fallback):** if `override` is truthy but contains ONLY unknown names, `picked` is empty → falls back to full `ACTIVITY_ORDER` (`:162`). An override of e.g. `["bogus"]` runs ALL 5, not zero.
- **GOTCHA (case-insensitive):** `schedule_id` is lowercased before matching (`:157`), so `SUS-DAILY-…` matches `sus-daily`. `None` schedule_id → `""` → falls through to the loop, matches nothing, returns all 5.
- **GOTCHA (adhoc short-circuits):** `sus-adhoc*` is checked FIRST and returns before the `_SCHEDULE_CADENCE` loop; a schedule id `sus-adhoc-daily` is treated as adhoc, not daily.

### 0.6 `_sustainment_repo(portfolio_id) -> str` (`sustainment.py:653–661`)
```python
return f"olympus/{portfolio_id}-sustainment"
```
Portfolio-scoped repo. Deployment may override via workflow input; this default is used only by tests (`sustainment.py:658–660`).

### 0.7 `_now_iso() -> str` (`sustainment.py:664–666`)
```python
return workflow.now().isoformat()
```
Deterministic time via Temporal's `workflow.now()`. **Every timestamp in this workflow comes from here or `workflow.now().isoformat()` inline (`:380`)** — never `datetime.now()`.

---

## 1. STATE — every instance variable

Set in `__init__` (`sustainment.py:185–207`), after `super().__init__()` (`:186`) which runs `HILSignalsMixin.__init__` (see §2 for the inherited attributes).

| Attr | Type | Initial | Mutated where / when |
|---|---|---|---|
| `_portfolio_id` | `str` | `""` (`:187`) | Set in `run` from `input.portfolio_id` (`:223`). Read-only after. |
| `_schedule_id` | `str` | `""` (`:188`) | Set in `run`: `input.schedule_id or "adhoc"` (`:224`). **GOTCHA:** empty/falsy schedule_id defaults to the literal string `"adhoc"`, which is then used in ALL repo branches/paths. But note `_activities_for_schedule` is called with this `"adhoc"` value at intake (`:276`) — `"adhoc"` does NOT start with `"sus-adhoc"`, so it falls through to the unknown-prefix branch → runs ALL 5 activities (`:168`). |
| `_status` | `WorkflowStatus` | `PENDING` (`:189`) | `RUNNING` at run start (`:220`); `COMPLETED` on success (`:249`); `FAILED` in except (`:254`). Surfaced by `get_status`. |
| `_current_step` | `str` | `""` (`:190`) | Set via `_set_step` at each step (`:648`); `"completed"` (`:250`) / `"failed"` (`:255`) in run. |
| `_progress_pct` | `float` | `0.0` (`:191`) | Set via `_set_step` (`:649`); `100.0` on success (`:248`). Step values: intake=5.0, each activity=`self._progress_pct` (see GOTCHA below), persist=92.0, commit=96.0. |
| `_started_at` | `str` | `""` (`:192`) | Set once in run to `_now_iso()` (`:221`). |
| `_updated_at` | `str` | `""` (`:193`) | `= _started_at` at start (`:222`); refreshed by `_set_step` (`:650`), by `override_approved` (`:621`), and in run terminal blocks (`:251`, `:256`). |
| `_findings` | `dict[str, list[str]]` | `{}` (`:196`) | Per-activity: `self._findings[activity] = result.output_artifacts` inside `_run_activity` (`:297`). Read in sweep-summary for `findings_count` (`:499–501`). |
| `_activity_metadata` | `dict[str, dict]` | `{}` (`:197`) | Set per activity in `_dispatch_activity` (`:336–342`) with `model_used`, `duration_ms`, `token_usage_input/output`, `cost_estimate_usd`. Read in `_commit_activity_artifact` (`:364`). |
| `_activity_artifacts` | `dict[str, str]` | `{}` (`:201`) | Set per activity in `_commit_activity_artifact` to the raw JSON string (`:384`). Read in `_persist_sweep_side_effects` (`:438–450`) to avoid a read_artifact round-trip. |
| `_active_activities` | `list[str]` | `[]` (`:204`) | Set ONCE at intake from `_activities_for_schedule` (`:276`). Read in `_execute_parallel_activities` (`:303`), sweep-summary (`:494`, `:502`). |
| `_override_decisions` | `list[dict]` | `[]` (`:207`) | Appended by `override_approved` signal handler (`:610`). Read (copied) in persist step (`:451`), sweep-summary (`:506`), and signal-fire critical count (`:569`). |
| `_completion_signal` | `SustainmentSweepCompletedSignal` | **NOT declared in `__init__`** | Assigned dynamically in `_fire_sweep_completed_signal` (`:591`). **GOTCHA:** this attribute is created only at step 8; there is NO query that returns it and it is NEVER declared in `__init__`. Any pre-step-8 access raises `AttributeError`. It exists purely as a "captured on workflow state" hook for future signal routing (`:588–591`). A rebuild must NOT declare it in `__init__` (behavioral parity: attribute must be absent until step 8). |

**GOTCHA (per-activity progress is stale/racy):** In `_run_activity`, `self._set_step(activity, self._progress_pct)` passes the CURRENT `_progress_pct` back into itself (`:295`) — i.e. progress is NOT advanced per activity; it stays at whatever intake set (5.0) until persist bumps it to 92.0. Because the 5 activities run concurrently under `asyncio.gather`, `_current_step` is overwritten by whichever coroutine ran `_set_step` last — the final `_current_step` after the gather is nondeterministic among the active activities. This is intentional (progress strip is rendered from step_execution rows, not this field) but a rebuild must preserve: (a) progress stays flat at 5.0 during the parallel phase, (b) `_current_step` ends up as one-of the active activity names, order-undefined.

---

## 2. SIGNALS & QUERIES

### 2.1 Inherited signals from `HILSignalsMixin` (`temporal_base/signals.py:47–86`)
These are part of the replay contract and are inherited unchanged. `SustainmentWorkflow` does NOT override any of them and never reads their state, but they remain registered signal handlers on the workflow:
- `approve_plan()` (`signals.py:48`), `provide_plan_feedback(comments: str)` (`:56`), `approve_research()` (`:64`), `provide_feedback(comments: str)` (`:71`), `approve()` (`:79`), `cancel_workflow()` (`:84`).
- **GOTCHA:** these mutate mixin state (`self.approved`, `self.plan_approved`, `self.cancelled`, etc., initialized in `signals.py:29–45`) but SustainmentWorkflow's `run()` NEVER checks any of them — `cancel_workflow` does NOT stop the sweep. They exist only because the class inherits the mixin. A rebuild must still register them (replay/signal-surface parity) even though they are inert here.

### 2.2 `override_approved` — the only domain signal (`sustainment.py:597–621`)
```python
@workflow.signal
async def override_approved(self, signal: OverrideApprovedSignal) -> None:
```
- **Payload type:** `OverrideApprovedSignal` (`types.py:146–153`): `gate_id: str`, `override_by: str`, `justification: str`, `override_type: OverrideType`. `OverrideType` (`types.py:110–116`) is a `str` enum: `CRITICAL_PATCH="critical_patch"`, `EXECUTIVE_OVERRIDE="executive_override"`, `TIME_SENSITIVE="time_sensitive"`.
- **What it buffers/mutates:** appends a dict to `self._override_decisions` (`:610–620`) with keys `gate_id`, `override_by`, `justification`, `override_type`, `timestamp`. The `override_type` value is derived defensively:
  ```python
  signal.override_type.value if hasattr(signal.override_type, "value") else str(signal.override_type)   # :614–618
  ```
  **GOTCHA:** handles both a real `OverrideType` enum (uses `.value`) and a raw string/other (uses `str(...)`) — this must be preserved because signals deserialize enums as their raw string in some transports. Then sets `self._updated_at = _now_iso()` (`:621`).
- **Consuming predicate:** THERE IS NO `wait_condition` that consumes this signal. The signal is fire-and-forget; its buffered decisions are read passively by:
  - persist step: `override_decisions=list(self._override_decisions)` (`:451`)
  - sweep-summary artifact: `"override_decisions": self._override_decisions` (`:506`)
  - completion-signal critical count (`:567–572`).
- **GOTCHA (timing / lost signals):** because `run()` does not wait on this signal, only overrides delivered BEFORE the persist step (`:454`) reach the DB projection, and only those before the summary build (`:507`) reach the artifact. Overrides arriving after `_commit_sweep_summary` starts are recorded in state but never persisted. A rebuild must NOT add a wait.
- **MUST NOT override note:** the inherited HIL signal method NAMES are the replay contract (`signals.py:10–12`); a subclass must not shadow `approve`/`cancel_workflow`/etc. with different semantics. `override_approved` is unique to this class and is safe to define.

### 2.3 `get_status` query (`sustainment.py:627–639`)
```python
@workflow.query
def get_status(self) -> WorkflowStatusResponse:
```
Returns `WorkflowStatusResponse` (`types.py:395–406`) built EXACTLY as:
```python
WorkflowStatusResponse(
    workflow_id=workflow.info().workflow_id,   # :631
    status=self._status,                        # :632
    current_line=AssemblyLine.SUSTAINMENT,      # :633
    current_step=self._current_step,            # :634
    progress_pct=self._progress_pct,            # :635
    pending_gate=None,                          # :636  Sustainment has NO gates
    started_at=self._started_at,                # :637
    updated_at=self._updated_at,                # :638
)
```
- **GOTCHA:** `pending_gate` is ALWAYS `None` (`:636`) — hardcoded because Sustainment has no gates. `current_line` is ALWAYS `AssemblyLine.SUSTAINMENT`. Query is synchronous (no `async`), reads state only — no mutation.

---

## 3. CONTROL FLOW — `run()` and helpers as structured pseudocode

### 3.1 `run(self, input: CronWorkflowInput) -> str` (`sustainment.py:213–257`)
`CronWorkflowInput` (`types.py:2727–2741`): `portfolio_id: str`, `schedule_id: str=""`, `triggered_at: str=""`, `activities: list[str]=[]`.

```python
self._status = WorkflowStatus.RUNNING          # :220
self._started_at = _now_iso()                  # :221
self._updated_at = self._started_at            # :222
self._portfolio_id = input.portfolio_id        # :223
self._schedule_id = input.schedule_id or "adhoc"   # :224  (falsy → "adhoc")

try:                                           # :226
    await self._intake(input)                          # Step 1  :231
    await self._execute_parallel_activities(input)     # Steps 2-6 :234
    await self._persist_sweep_side_effects(input)      # Step 7  :240
    await self._commit_sweep_summary(input)            # Step 8  :246

    self._progress_pct = 100.0                 # :248
    self._status = WorkflowStatus.COMPLETED    # :249
    self._current_step = "completed"           # :250
    self._updated_at = _now_iso()              # :251
    return "completed"                         # :252
except Exception:                              # :253  bare Exception, NO variable bound
    self._status = WorkflowStatus.FAILED       # :254
    self._current_step = "failed"              # :255
    self._updated_at = _now_iso()              # :256
    raise                                      # :257  re-raises → Temporal marks workflow failed
```
- **Return values:** `"completed"` on success; on any exception it sets FAILED state then **re-raises** (`:257`) — so the workflow result is a Temporal failure, NOT the string `"failed"`. The docstring says returns "completed" or "failed" (`:218`) but the code only ever RETURNS `"completed"`; the "failed" path raises. A rebuild must re-raise, not return, on error.
- **No finally block.** No compensation/rollback. No continue-as-new. Steps run strictly sequentially (1 → 2-6 → 7 → 8).

### 3.2 `_intake(input)` — Step 1 (`sustainment.py:263–284`)
```python
self._set_step("intake", 5.0)                                      # :274
override = list(input.activities) if input.activities else None    # :275
self._active_activities = _activities_for_schedule(self._schedule_id, override)   # :276
workflow.logger.info("sustainment intake: portfolio=%s schedule=%s activities=%s", ...)   # :279
```
- No activity dispatch, no artifact write (code-kind step). `override` is `None` when `input.activities` is empty/falsy (`:275`), else a copy of the list.

### 3.3 `_execute_parallel_activities(input)` — Steps 2-6 (`sustainment.py:290–306`)
```python
async def _run_activity(activity):                        # :294 nested closure
    self._set_step(activity, self._progress_pct)          # :295  (progress passed to itself — see §1 GOTCHA)
    result = await self._dispatch_activity(activity, input)   # :296
    self._findings[activity] = result.output_artifacts    # :297
    await self._commit_activity_artifact(activity, result, input)   # :298

if self._active_activities:                               # :303  skip gather if empty
    await asyncio.gather(*[_run_activity(a) for a in self._active_activities])   # :304
```
- **GOTCHA (empty guard):** if `_active_activities` is empty, the gather is skipped entirely (`:303`). Given `_activities_for_schedule` always returns a non-empty list, this is defensive-only, but a rebuild must keep the guard.
- **Parallelism:** all active activities run CONCURRENTLY via `asyncio.gather` (`:304`). Each coroutine independently does dispatch → record findings → commit artifact. There is no cross-activity ordering (`:300–302`).
- **GOTCHA (fail-fast gather):** `asyncio.gather` with default `return_exceptions=False` — if ANY activity coroutine raises (e.g. dispatch retries exhausted), gather propagates the first exception, which bubbles to `run`'s except (`:253`) → workflow FAILED. Other in-flight activities are cancelled. There is no per-activity error isolation here.

### 3.4 `_dispatch_activity(activity, input) -> AgentTaskResult` (`sustainment.py:308–343`)
```python
act_def = SUSTAINMENT_ACTIVITIES[activity]                # :312
task_input = AgentTaskInput(
    task_type=f"sustainment-{activity}",                  # :314
    app_id="",                                            # :315  portfolio-scoped, no app
    skill_id=act_def["skill_id"],                         # :316
    input_artifacts=[],                                   # :317
    artifact_repo="", artifact_ref="",                    # :318-319
    workspace_key=f"sustainment-{input.portfolio_id}-{self._schedule_id}",   # :320-322
    context={                                             # :323-327
        "portfolio_id": input.portfolio_id,
        "schedule_id": self._schedule_id,
        "triggered_at": input.triggered_at,
    },
)
result = await workflow.execute_activity(dispatch_agent_task, task_input, ...)   # :329-335
self._activity_metadata[activity] = { model_used, duration_ms,
    token_usage_input, token_usage_output, cost_estimate_usd }   # :336-342
return result                                             # :343
```
- **GOTCHA:** `app_id=""` and `wave_id` unset — this is a portfolio-scoped dispatch with NO app. `AgentTaskInput` normally requires exactly-one of app_id/wave_id (`types.py:474–482`); Sustainment intentionally leaves both blank because it operates on the whole inventory. Preserve the empty `app_id`.
- `workspace_key` uses `self._schedule_id` (the possibly-`"adhoc"`-defaulted value), NOT `input.schedule_id`.

### 3.5 `_commit_activity_artifact(activity, result, input)` (`sustainment.py:345–416`)
```python
act_def = SUSTAINMENT_ACTIVITIES[activity]                            # :357
repo   = _sustainment_repo(input.portfolio_id)                       # :358  -> olympus/{pid}-sustainment
branch = f"sustainment/{input.portfolio_id}/{self._schedule_id}"     # :359
path   = f"sustainment/{input.portfolio_id}/{self._schedule_id}/{act_def['artifact']}"   # :360-363
metadata = self._activity_metadata.get(activity, {})                 # :364

content = json.dumps({                                               # :366-381
    "activity": activity,
    "skill_id": act_def["skill_id"],
    "portfolio_id": input.portfolio_id,
    "schedule_id": self._schedule_id,
    "triggered_at": input.triggered_at,
    "findings": result.output_artifacts,
    "model_used": metadata.get("model_used", ""),
    "duration_ms": metadata.get("duration_ms", 0),
    "token_usage": {"input": metadata.get("token_usage_input", 0),
                    "output": metadata.get("token_usage_output", 0)},
    "cost_estimate_usd": metadata.get("cost_estimate_usd", 0.0),
    "timestamp": workflow.now().isoformat(),
}, indent=2)

self._activity_artifacts[activity] = content                         # :384  cache for persist step

if workflow.patched("sustainment-batch-writes-v1"):                  # :386  VERSIONING GATE
    await workflow.execute_activity(write_artifacts_batch, WriteArtifactsBatchInput(
        repo=repo, branch=branch, files=[(path, content)],
        commit_message=f"sustainment({input.portfolio_id}): {activity} sweep"), ...)   # :387-400
else:
    await workflow.execute_activity(write_artifact, WriteArtifactInput(
        repo=repo, branch=branch, path=path, content=content,
        commit_message=f"sustainment({input.portfolio_id}): {activity} sweep"), ...)   # :402-416
```
- **GOTCHA (`workflow.patched` version gate):** `workflow.patched("sustainment-batch-writes-v1")` (`:386`) — NEW executions take the batch-write branch; workflows started before the patch replay the single-write branch. A rebuild MUST use `workflow.patched` with this exact patch id (`"sustainment-batch-writes-v1"`), and the batch branch writes a SINGLE file `[(path, content)]` in a batch call. The `commit_message` is identical between branches.
- `timestamp` field uses `workflow.now().isoformat()` inline (`:380`) — deterministic, distinct call from `_now_iso()` but semantically identical.

### 3.6 `_persist_sweep_side_effects(input)` — Step 7 (`sustainment.py:422–465`)
```python
self._set_step("persist-sustainment-sweep-side-effects", 92.0)       # :433
payload = PersistSustainmentSweepSideEffectsInput(                   # :434-452
    portfolio_id=input.portfolio_id,
    schedule_id=self._schedule_id,
    sweep_completed_at=_now_iso(),
    cve_triage_json      = self._activity_artifacts.get("cve-triage", ""),
    incident_response_json = self._activity_artifacts.get("incident-response", ""),
    sla_monitoring_json  = self._activity_artifacts.get("sla-monitoring", ""),
    change_conflict_json = self._activity_artifacts.get("change-conflict-detection", ""),
    cost_anomaly_json    = self._activity_artifacts.get("cost-anomaly-detection", ""),
    override_decisions   = list(self._override_decisions),
)
try:                                                                 # :453
    await workflow.execute_activity(persist_sustainment_sweep_side_effects, payload, ...)   # :454-460
except Exception as exc:                                             # :461  best-effort — swallow
    workflow.logger.warning("persist_sustainment_sweep_side_effects failed — continuing: %s", exc)   # :462-465
```
- **GOTCHA (best-effort / swallowed):** the persist activity is wrapped in try/except that SWALLOWS any exception (`:461–465`), logging a warning and CONTINUING to step 8. DB failures must NOT block the sweep-summary commit. A rebuild must preserve this swallow — the sweep is considered successful even if projection fails.
- **GOTCHA (mapping keys):** the JSON fields map activity KEYS (not artifact filenames) to payload fields; `change-conflict-detection` → `change_conflict_json`, `cost-anomaly-detection` → `cost_anomaly_json`. Missing artifacts (activity didn't run) default to `""` via `.get(key, "")`.

### 3.7 `_commit_sweep_summary(input)` — Step 8 (`sustainment.py:471–547`)
```python
self._set_step("commit-sweep-summary", 96.0)                         # :482
repo   = _sustainment_repo(input.portfolio_id)                       # :483
branch = f"sustainment/{input.portfolio_id}/{self._schedule_id}"     # :484
path   = f"sustainment/{input.portfolio_id}/{self._schedule_id}/sweep-summary.json"   # :485-488

summary = {                                                          # :489-507
    "portfolio_id": input.portfolio_id,
    "schedule_id": self._schedule_id,
    "triggered_at": input.triggered_at,
    "completed_at": _now_iso(),
    "active_activities": list(self._active_activities),
    "activities": {                                                  # :495-505  built over ACTIVITY_ORDER (all 5)
        activity: {
            "artifact": SUSTAINMENT_ACTIVITIES[activity]["artifact"],
            "skill_id": SUSTAINMENT_ACTIVITIES[activity]["skill_id"],
            "findings_count": len(self._findings.get(activity, [])),
            "ran": activity in self._active_activities,
        }
        for activity in ACTIVITY_ORDER
    },
    "override_decisions": self._override_decisions,
}
summary_content = json.dumps(summary, indent=2)                      # :508

if workflow.patched("sustainment-batch-writes-v1"):                  # :509  SAME patch gate as :386
    await workflow.execute_activity(write_artifacts_batch, WriteArtifactsBatchInput(
        repo=repo, branch=branch, files=[(path, summary_content)],
        commit_message=f"sustainment({input.portfolio_id}): {self._schedule_id} sweep summary"), ...)   # :510-524
else:
    await workflow.execute_activity(write_artifact, WriteArtifactInput(
        repo=repo, branch=branch, path=path, content=summary_content,
        commit_message=f"sustainment({input.portfolio_id}): {self._schedule_id} sweep summary"), ...)   # :526-541

await self._fire_sweep_completed_signal(input, summary)              # :547
```
- **GOTCHA (summary covers ALL 5, marks `ran`):** the `activities` map iterates `ACTIVITY_ORDER` (all 5) regardless of what ran (`:504`). Each entry gets `"ran": activity in self._active_activities` (`:502`). Activities that didn't run get `findings_count=0` (`.get` default `[]`, `:499–501`) and `"ran": False`. A rebuild must emit all 5 entries in canonical order, not just the active ones.
- Same `workflow.patched("sustainment-batch-writes-v1")` gate (`:509`), same single-file batch vs single write; commit_message uses `self._schedule_id`.

### 3.8 `_fire_sweep_completed_signal(input, summary)` (`sustainment.py:549–591`)
```python
finding_counts = { activity: summary["activities"][activity]["findings_count"]
                   for activity in ACTIVITY_ORDER }                  # :563-566
critical_findings = sum(1 for dec in self._override_decisions
    if (dec.get("override_type") or "").lower()
       in {"critical_patch", "executive_override"})                  # :567-572
signal_payload = SustainmentSweepCompletedSignal(                    # :573-579
    portfolio_id=input.portfolio_id,
    schedule_id=self._schedule_id,
    sweep_completed_at=_now_iso(),
    finding_counts=finding_counts,
    critical_findings=critical_findings,
)
workflow.logger.info("sustainment sweep completed signal: ...", ...) # :580-587
self._completion_signal = signal_payload                             # :591
```
- `SustainmentSweepCompletedSignal` (`types.py:310–330`): `portfolio_id`, `schedule_id`, `sweep_completed_at`, `finding_counts: dict[str,int]`, `critical_findings: int`.
- **GOTCHA (critical count only counts 2 of 3 override types):** `critical_findings` counts override decisions whose `override_type` (lowercased) is in `{"critical_patch", "executive_override"}` (`:571`) — `"time_sensitive"` is EXCLUDED. The `(dec.get("override_type") or "")` guards against `None`. Preserve the exact set.
- **GOTCHA (no external signal actually sent):** despite the name, this method does NOT call `signal_external_workflow` — it only builds the payload, logs it, and stashes it on `self._completion_signal` (`:588–591`). There is NO subscriber/target; Governance reads the artifact directly today (`:543–546`). A rebuild must NOT emit a real Temporal signal here; just capture state + log.

### 3.9 `_set_step(step, progress)` (`sustainment.py:645–650`)
```python
self._current_step = step        # :648
self._progress_pct = progress    # :649
self._updated_at = _now_iso()    # :650
```
No DB write (Sustainment has no per-app application status row, `:646–647`).

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS (in run() order)

**No child workflows.** All work is `execute_activity`. No `asyncio.gather` across DIFFERENT activities except the 5-way agent fan-out.

| # | Step / method | Activity | Args | start_to_close_timeout | retry_policy | non_retryable | seq/parallel | activity_id |
|---|---|---|---|---|---|---|---|---|
| 1 | intake | — (code only) | — | — | — | — | — | — |
| 2–6 | `_dispatch_activity` (`:329`) | `dispatch_agent_task` | `AgentTaskInput` (task_type `sustainment-{activity}`, app_id `""`, skill_id per registry, workspace_key, context) | `AGENT_START_TO_CLOSE` = `timedelta(hours=3)` (`agent_timeouts.py:67`) | `RETRY_POLICIES["agent_failure"]` = 3 attempts, initial 5s, backoff 2.0, max 60s (`retry_policies.py:38–43`) | none set | **PARALLEL** — one per active activity, all under `asyncio.gather` (`sustainment.py:304`) | `sustainment-{activity}` (`:334`) |
| 2–6 | `_commit_activity_artifact` batch path (`:387`) | `write_artifacts_batch` | `WriteArtifactsBatchInput(repo, branch, files=[(path,content)], commit_message)` | `timedelta(seconds=120)` (`:397`) | `RETRY_POLICIES["transient"]` = HTTP_RETRY_POLICY (3 retries, exp backoff 1-15s) (`retry_policies.py:34`) | none | runs INSIDE each parallel `_run_activity` coroutine, after its dispatch | `commit-sustainment-{activity}` (`:399`) |
| 2–6 | `_commit_activity_artifact` single path (`:402`) | `write_artifact` | `WriteArtifactInput(repo, branch, path, content, commit_message)` | `timedelta(seconds=60)` (`:413`) | `RETRY_POLICIES["transient"]` (`:414`) | none | same as above (pre-patch executions) | `commit-sustainment-{activity}` (`:415`) |
| 7 | `_persist_sweep_side_effects` (`:454`) | `persist_sustainment_sweep_side_effects` | `PersistSustainmentSweepSideEffectsInput` (5 JSON strings + override_decisions) | `timedelta(seconds=60)` (`:457`) | `RETRY_POLICIES["transient"]` (`:458`) | none | **SEQUENTIAL**, wrapped in try/except that swallows failure | `persist-sustainment-sweep-side-effects` (`:459`) |
| 8 | `_commit_sweep_summary` batch path (`:510`) | `write_artifacts_batch` | `WriteArtifactsBatchInput(files=[(path, summary_content)], …)` | `timedelta(seconds=120)` (`:521`) | `RETRY_POLICIES["transient"]` (`:522`) | none | **SEQUENTIAL** | `commit-sweep-summary` (`:523`) |
| 8 | `_commit_sweep_summary` single path (`:526`) | `write_artifact` | `WriteArtifactInput(path, summary_content, …)` | `timedelta(seconds=60)` (`:538`) | `RETRY_POLICIES["transient"]` (`:539`) | none | **SEQUENTIAL** (pre-patch) | `commit-sweep-summary` (`:540`) |

- **GOTCHA (activity_id collision by design):** the batch and single write paths for a given step share the SAME `activity_id` (`commit-sustainment-{activity}` / `commit-sweep-summary`). Only one path ever executes per activity (mutually exclusive via `workflow.patched`), so no real collision, but a rebuild must keep the ids identical across both branches.
- No `non_retryable_error_types` are set on ANY call in this workflow. (Contrast with `GIT_MERGE_RETRY_POLICY` used elsewhere — NOT used here.)

---

## 5. GATE HANDLING

**There are NO gates in this workflow.** Explicitly:
- `get_status` returns `pending_gate=None` unconditionally (`sustainment.py:636`).
- Docstring: "Sustainment has no gates" (`:636`).
- No `wait_condition`, no evidence assembly, no approve/reject/merge-blocked/rework loop, no rework counters exist.

The `override_approved` signal is the ONLY human-coordination surface, and it is NOT a gate: it does not pause `run()`, has no wait, and is consumed passively (see §2.2). A rebuild must NOT introduce any gate wait.

---

## 6. RESILIENCE

- **Timeouts:** agent dispatch `AGENT_START_TO_CLOSE = 3 hours` (`agent_timeouts.py:67`). Git writes: batch 120s, single 60s. Persist 60s. (See §4.)
- **Heartbeats:** NONE declared in this workflow. (Heartbeating, if any, is internal to the activity implementations, not configured here.)
- **Retries:** agent → `agent_failure` (3 attempts, 5s→60s exp backoff). All git/persist → `transient` = HTTP_RETRY_POLICY (3 retries, 1-15s exp). No non-retryable overrides.
- **Continue-as-new:** NONE. Each invocation is one bounded sweep (`sustainment.py:176`). The workflow relies on the external Temporal Schedule for recurrence, not `@workflow.cron_schedule` and not continue-as-new (docstring `:35–42`).
- **Idempotency:** artifacts are written to a deterministic branch/path keyed by `{portfolio_id}/{schedule_id}` (`:359–363`, `:484–488`). Re-running the same schedule_id overwrites the same paths. `activity_id`s are deterministic per activity, so Temporal replay dedupes retried commits.
- **Compensation / rollback:** NONE. There is no finally block and no undo. The persist step is best-effort (swallowed on failure, `:461`); the summary commit still lands. If an agent activity or the summary commit fails, `run` sets FAILED and re-raises (`:253–257`) with NO cleanup of partially-written per-activity artifacts (they remain committed).
- **Determinism:** all time via `workflow.now()` (`_now_iso`, `:664–666`; inline `:380`). Version gate via `workflow.patched("sustainment-batch-writes-v1")` (`:386`, `:509`). `asyncio.gather` over a list built from `_active_activities` (deterministic order = canonical).
- **GOTCHA (partial-failure artifact residue):** because the 5 activities each commit their own artifact independently (`:298`), a failure in one activity AFTER others have committed leaves those others' artifacts in Git with NO sweep-summary. On workflow retry (if the schedule/parent retries), the sweep re-runs from step 1 and overwrites them. No cleanup is performed.

---

## 7. GOTCHAs — consolidated

1. `_schedule_id = input.schedule_id or "adhoc"` (`:224`) — falsy → literal `"adhoc"`, which does NOT match `"sus-adhoc"` prefix → runs ALL 5 activities (§1, §3.2).
2. Artifact filenames for `change-conflict-detection` (`change-conflict.json`) and `cost-anomaly-detection` (`cost-anomaly.json`) differ from their activity keys (§0.1).
3. `_activities_for_schedule` filters override THROUGH `ACTIVITY_ORDER` → always canonical order; all-unknown override → all 5 (§0.5).
4. Per-activity `_set_step(activity, self._progress_pct)` keeps progress flat at 5.0 during the parallel phase; final `_current_step` is nondeterministic among active activities (§1).
5. `_completion_signal` is set only at step 8, never declared in `__init__`, and never queryable — pre-step-8 access raises `AttributeError` (§1).
6. Inherited HIL signals (`approve`, `cancel_workflow`, etc.) are registered but INERT — `cancel_workflow` does NOT stop the sweep (§2.1).
7. `override_approved` handles both enum (`.value`) and raw-string `override_type` (§2.2); overrides after step-8 start are dropped from persistence.
8. `run` re-raises on error (does not return `"failed"`); the docstring's "failed" return is misleading (§3.1).
9. Persist step (Step 7) swallows all exceptions — DB failure never blocks the sweep (§3.6).
10. Sweep summary emits ALL 5 activities with a `ran` flag, not just active ones (§3.7).
11. `critical_findings` counts only `critical_patch` + `executive_override`, excludes `time_sensitive` (§3.8).
12. `_fire_sweep_completed_signal` does NOT send a real Temporal signal — only builds/logs/stashes (§3.8).
13. `workflow.patched("sustainment-batch-writes-v1")` version gate appears TWICE (`:386`, `:509`) — must use the exact patch id (§3.5, §3.7).
14. `AgentTaskInput.app_id=""` with no `wave_id` — portfolio-scoped, intentionally violates the usual exactly-one rule (§3.4).
15. `asyncio.gather` default fail-fast: one activity failure fails the whole sweep and cancels siblings (§3.3).

---

## 8. Behavioral parity checklist

A rebuild must satisfy ALL of the following:

- [ ] Class `SustainmentWorkflow` inherits `HILSignalsMixin` directly; `@workflow.defn`; `run` is `@workflow.run`.
- [ ] `__init__` declares exactly the 11 listed attrs with listed initial values; `_completion_signal` is NOT declared.
- [ ] Module constants `SUSTAINMENT_ACTIVITIES`, `ACTIVITY_ORDER`, `CANONICAL_STEPS`, `_SCHEDULE_CADENCE` reproduced byte-for-byte, including the two mismatched artifact filenames.
- [ ] `_activities_for_schedule("sus-daily-…")` → `["cve-triage","incident-response"]`; `"sus-weekly-…"` → all 5; `"sus-adhoc-…"` with `["sla-monitoring","cve-triage"]` → `["cve-triage","sla-monitoring"]` (canonical order); `"sus-adhoc-…"` with `["bogus"]` → all 5; unknown/`""`/`"adhoc"` → all 5; case-insensitive.
- [ ] `run` with falsy `schedule_id` sets `_schedule_id="adhoc"` and runs all 5 activities.
- [ ] Steps execute strictly: intake → gather(active activities) → persist → commit-summary. Progress: 5.0 → (flat 5.0 during parallel) → 92.0 → 96.0 → 100.0.
- [ ] Each active activity dispatches `dispatch_agent_task` with `task_type="sustainment-{activity}"`, `app_id=""`, correct `skill_id`, 3h timeout, `agent_failure` retry, `activity_id="sustainment-{activity}"`.
- [ ] Each active activity commits ONE artifact to `sustainment/{pid}/{sid}/{artifact}` on branch `sustainment/{pid}/{sid}` in repo `olympus/{pid}-sustainment`, with the exact JSON body (activity, skill_id, portfolio_id, schedule_id, triggered_at, findings, model_used, duration_ms, token_usage{input,output}, cost_estimate_usd, timestamp), `indent=2`.
- [ ] Batch-vs-single write chosen by `workflow.patched("sustainment-batch-writes-v1")`; batch uses `files=[(path,content)]` @120s, single @60s; both `transient` retry; both `activity_id="commit-sustainment-{activity}"`.
- [ ] Step 7 builds `PersistSustainmentSweepSideEffectsInput` from cached `_activity_artifacts` (empty string for non-run activities) + `list(_override_decisions)`; @60s `transient`; exceptions SWALLOWED (workflow continues).
- [ ] Step 8 writes `sweep-summary.json` with `activities` map over ALL 5 in canonical order, each with `artifact`/`skill_id`/`findings_count`/`ran`; `active_activities`, `override_decisions` included.
- [ ] Step 8 then calls `_fire_sweep_completed_signal`: builds `SustainmentSweepCompletedSignal` with `finding_counts` per ACTIVITY_ORDER and `critical_findings` = count of overrides in `{critical_patch, executive_override}`; logs; assigns `self._completion_signal`; sends NO external signal.
- [ ] `override_approved` appends `{gate_id, override_by, justification, override_type, timestamp}`, resolving `override_type` via `.value`-or-`str`; updates `_updated_at`; never gates `run`.
- [ ] `get_status` returns `WorkflowStatusResponse` with `current_line=SUSTAINMENT`, `pending_gate=None` always, live `status/current_step/progress_pct/started_at/updated_at`.
- [ ] On any exception, `run` sets FAILED + `_current_step="failed"` and RE-RAISES (workflow fails); on success returns `"completed"`.
- [ ] No child workflows, no gates, no wait_conditions, no continue-as-new, no compensation, no heartbeats configured.
- [ ] All timestamps via `workflow.now()` (deterministic).
