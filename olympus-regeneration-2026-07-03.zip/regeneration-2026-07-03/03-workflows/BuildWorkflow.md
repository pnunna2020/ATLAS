# BuildWorkflow — atomic regeneration spec

Source of truth: `temporal/olympus_workflows/workflows/build.py` (759 lines).
Base scaffolding: `temporal/olympus_workflows/workflows/base.py` (`LineWorkflowBase`) — see `_base-workflow.md` for inherited behavior; this doc fully captures BuildWorkflow's own overrides + `run()` body.
Generate-loop internals (`GenerateBCWorkflow` Ralph Loop) are deferred to `13-generation-engine.md`; this doc captures orchestration + gates only.

Rebuild bar: **behavioral parity**. Every branch, counter, wait predicate, retry policy, and ordering constraint below is load-bearing.

---

## 0. Identity & class configuration

- `@workflow.defn class BuildWorkflow(LineWorkflowBase)` — `build.py:70-71`.
- The Build (greenfield/net-new) line: **Spec-from-Requirements → Design → Generate**, gates **G-NEW-1 / G-NEW-2 / G-NEW-3** (`build.py:31`).
- Does NOT inherit `BundleAwareMixin` (Build v1 has no kickoff-delegation requirement) — `build.py:77-78`. Consequence: `_maybe_dispatch_bundle` (inherited) would short-circuit to `fallback_fn` because `hasattr(self,"await_bundle_completion")` is False (`base.py:591-592`) — but BuildWorkflow never calls `_maybe_dispatch_bundle` at all, so this is moot. It DOES call `_load_delegation_config` (`build.py:260`), which is harmless: it only sets `self._profile_id` / `self._portfolio_fallback_policy`.

### Class constants (`build.py:62-67`)
| Name | Value | Meaning |
|---|---|---|
| `MAX_REWORK_ITERATIONS` | `3` | Per-gate rework cap. Loop fails when `_rework_count(gate) > 3` (i.e. the 4th rejection). |
| `MAX_BC_CHILDREN_PER_APP` | `12` | Cap on `GenerateBCWorkflow` children spawned per app in Generate. `bc_names[:12]` slice. |
| `_FRONTEND_BC_NAMES` | `{"frontend","ui","web-app","spa"}` | Case-insensitive match routes a BC to a frontend code-gen variant. |

### Classvars overriding `LineWorkflowBase` (`build.py:82-130`)
| Classvar | Value | Notes |
|---|---|---|
| `ASSEMBLY_LINE` | `AssemblyLine.BUILD` (`= "Build"`, enums.py:41) | Returned in `get_status().current_line`. |
| `ARTIFACT_ROOT` | `"build"` | Path prefix + `_task_type_prefix()` default (task_type = `build-{step}`). |
| `LINE_LABEL` | `"Build"` | Human label; `_execution_ctx` line_id = `"build"` (lowercase-kebab). |
| `STATUS_PREFIX` | `"build"` | Status strings: `build_in_progress` / `build_failed` / etc. |
| `SINGLE_GATE_KEY` | **intentionally unset** (inherits `None`) — `build.py:86-87` | Build has 3 gates → routing done by `_rework_gate_key_for_step` override. |
| `STEPS` | 8-entry dict (below) | Consumed by base `_dispatch_agent`/`_primary_skill_for_step`/`_commit_step_artifacts`/`_build_evidence_data`. |
| `_DESIGN_STEPS` | `["module-design","api-specification","data-modeling","traceability-audit"]` (`build.py:125-130`) | Ordered Design sub-step chain. |

**`STEPS` map** (`build.py:95-122`) — each value has `skill_id` + `title`:
| step key | `skill_id` | `title` |
|---|---|---|
| `spec-from-requirements` | `spec-from-requirements` | Spec-from-Requirements |
| `module-design` | `module-design` | Module Design |
| `api-specification` | `api-specification` | API Specification |
| `data-modeling` | `data-modeling` | Data Modeling |
| `traceability-audit` | `traceability-audit` | Traceability Audit |
| `synthesis` | `code-synthesis` | Code Synthesis |
| `adversarial-review` | `adversarial-review` | Adversarial Review |
| `security-scan-review` | `security-scan-review` | Security Scan Review |

GOTCHA (`build.py:112-122`): the `synthesis` step's `skill_id` is **`code-synthesis`**, NOT `synthesis`. The step *key* is `synthesis`. `_primary_skill_for_step("synthesis")` returns `"code-synthesis"` (base.py:287). Per-BC Generate work runs in `GenerateBCWorkflow` children — NOT via these `STEPS` dispatches; `STEPS` covers only the Spec + Design direct dispatches plus the Generate synthesis/review chain.

---

## 1. STATE — every instance variable

### 1a. Own state set in `__init__` (`build.py:132-156`), after `super().__init__()`
| Attribute | Type | Initial | Mutated by / when |
|---|---|---|---|
| `_spec_results` | `dict[str, list[str]]` | `{}` | `_execute_spec`: `_spec_results["spec-from-requirements"] = list(committed)` after Spec commit (`build.py:333`). Read by `_execute_design` (`build.py:386`). |
| `_design_results` | `dict[str, list[str]]` | `{}` | `_execute_design`: `_design_results[step_name] = list(step_committed)` per design sub-step (`build.py:412`). Read by `_collect_design_artifacts` (`build.py:744-745`). |
| `_generate_results` | `list[GenerateBCResult]` | `[]` | `_execute_generate`: reassigned to normalized child results after `asyncio.gather` (`build.py:489-492`). |
| `_rework_iterations` | `dict[str,int]` (inherited attr) | seeded `{"G-NEW-1":0,"G-NEW-2":0,"G-NEW-3":0}` (`build.py:143-145`) | `_bump_rework(gate_key)` (base.py:1376-1381) on each rejection. Read via `_rework_count` / `_gate_pr_body`. GOTCHA: base `_wait_for_gate_decision` does **not** touch `_rework_iterations` on rejection — only the phase loops call `_bump_rework`. |
| `_g_new_1_stakeholder_approved` | `bool` | `False` | `stakeholder_approved` signal scope `g-new-1-stakeholder` → `True` (`build.py:191-192`); reset to `False` in Spec rework branch (`build.py:369`). |
| `_g_new_3_ea_approved` | `bool` | `False` | signal scope `g-new-3-ea` → `True` (`build.py:193-194`); reset `False` in Generate rework branch (`build.py:632`). |
| `_g_new_3_security_approved` | `bool` | `False` | signal scope `g-new-3-security` → `True` (`build.py:195-196`); reset `False` in Generate rework branch (`build.py:633`). |

### 1b. Inherited state set by BuildWorkflow's `run()` / `_execute_build` (from `LineWorkflowBase.__init__`, base.py:136-191)
| Attribute | Type | Initial (base) | Set/mutated in BuildWorkflow |
|---|---|---|---|
| `_status` | `WorkflowStatus` | `PENDING` | `RUNNING` at run start (`build.py:211`); `FAILED` on exception (`build.py:223`) & max-rework (`build.py:707`); `CANCELLED` on gate cancel (`build.py:349,359,427,610,623`) & tier-1 cancel; `COMPLETED` at end (`build.py:282`); `WAITING_FOR_SIGNAL` inside base `_wait_for_gate_decision`. |
| `_started_at` | `str` | `""` | `workflow.now().isoformat()` at run start (`build.py:212`). |
| `_updated_at` | `str` | `""` | many sites incl. `build.py:224,285,709`, `stakeholder_approved` (`build.py:201`). |
| `_app_id` | `str` | `""` | `input.app_id` (`build.py:213`). |
| `_portfolio_id` | `str` | `""` | `input.portfolio_id` (`build.py:214`). |
| `_wave_id` | `str` | `""` | `input.wave_id` (`build.py:215`). |
| `_input` | `LineWorkflowInput` | (not in base `__init__`; set here) | `input` (`build.py:216`). Read by base `_dispatch_agent` for `fixture_scenarios`, and `_workflow_created_by`. |
| `_risk_tier` | `int \| None` | `None` | `int(input.risk_tier) if not None else None` (`build.py:217-219`). Gates tier-1 stakeholder waits. |
| `_artifact_repo` | `str` | (set here) | `input.artifact_repo` (`build.py:235`). READ repo for cross-line priors only. |
| `_target_repo_url` | `str` | (set here) | `input.target_repo_url or ""` (`build.py:255`). |
| `_current_step` | `str` | `""` | `_set_step` per step; `"completed"` at end (`build.py:284`); `"{phase}-max-rework-exceeded"` on fail (`build.py:708`). |
| `_progress_pct` | `float` | `0.0` | via `_set_step`; `100.0` at end (`build.py:283`). |
| `_pending_gate` | `GateType\|None` | `None` | set/cleared inside base `_wait_for_gate_decision`. |
| `_gate_decisions` | `list[tuple]` | `[]` | appended by base `gate_approved`/`gate_rejected` handlers; consumed by base `_wait_for_gate_decision`. |
| `_gate_decisions_consumed` | `int` | `0` | incremented in base `_wait_for_gate_decision`. |
| `_rework_feedback` | `dict[str,dict]` | `{}` | base `_wait_for_gate_decision` sets `[gate_key]` on reject, pops on approve. Forwarded by `_dispatch_agent`. |
| `_step_committed_paths` | `dict[str,list[str]]` | `{}` | set by base `_commit_step_artifacts`. Read after every commit here. |
| `_agent_metadata` | `dict[str,dict]` | `{}` | set by base `_dispatch_agent`. |
| `_merge_retry_signalled` | `bool` | `False` | base `merge_retry` handler / `_reconcile_and_merge_with_retry_loop`. |
| `_profile_id` | `str` | `""` | `_load_delegation_config(portfolio_id)` (`build.py:260`). |
| `_portfolio_fallback_policy` | `str` | `"internal_fallback"` | possibly overwritten by delegation config load. |
| `_redispatch_guard` | `set[str]` | `set()` | unused by Build (no bundle dispatch). |
| HIL flags (`approved`, `plan_approved`, …, `cancelled`) | mixed | see signals.py:31-45 | `cancelled` flipped by `cancel_workflow` signal; consumed by every wait predicate here. |

---

## 2. SIGNALS & QUERIES

### 2a. Own signal — `stakeholder_approved` (`build.py:180-201`)
```python
@workflow.signal
async def stakeholder_approved(self, signal: StakeholderApprovedSignal) -> None:
```
- Payload: `StakeholderApprovedSignal` (types.py:167-172) — fields `approval_id: str`, `stakeholder: str`, `scope: str`.
- Reads `scope = getattr(signal, "scope", "")` (defensive default `""`).
- Branch (exhaustive):
  - `scope == "g-new-1-stakeholder"` → `self._g_new_1_stakeholder_approved = True`
  - `elif scope == "g-new-3-ea"` → `self._g_new_3_ea_approved = True`
  - `elif scope == "g-new-3-security"` → `self._g_new_3_security_approved = True`
  - `else` → `workflow.logger.warning("...unknown scope %r", scope)` (no state change beyond `_updated_at`).
- Always: `self._updated_at = workflow.now().isoformat()` (`build.py:201`).
- GOTCHA: signal is monotonic-set-only — it never resets flags to False. Resets happen ONLY in the rework branches of the run helpers (`build.py:369,632-633`) so an early-arriving signal from a prior iteration can't satisfy a later gate. GOTCHA: `approval_id` / `stakeholder` fields are ignored — only `scope` matters.
- This is a NEW signal method name distinct from base `gate_approved`/`gate_rejected` — safe to add (does not collide with base).

### 2b. Wait predicates that consume `stakeholder_approved`
- **G-NEW-1 tier-1 wait** (`build.py:353-360`), only when `self._risk_tier == 1`, after gate approval:
  ```python
  await workflow.wait_condition(
      lambda: self._g_new_1_stakeholder_approved or self.cancelled)
  if self.cancelled: self._status = CANCELLED; return "cancelled"
  ```
- **G-NEW-3 tier-1 wait** (`build.py:614-623`), only when `self._risk_tier == 1`, after gate approval:
  ```python
  await workflow.wait_condition(
      lambda: (self._g_new_3_ea_approved and self._g_new_3_security_approved)
              or self.cancelled)
  if self.cancelled: self._status = CANCELLED; return "cancelled"
  ```
  GOTCHA: G-NEW-2 has **no** tier-1 stakeholder wait — Design approval merges immediately regardless of tier.

### 2c. Inherited signals — DO NOT redefine (base.py:197-257)
Decorated on `LineWorkflowBase`; re-decorating in the subclass duplicate-registers with Temporal (base module docstring, base.py:11-13, 117-119). BuildWorkflow correctly does NOT redefine them:
| Signal | Payload | Effect |
|---|---|---|
| `gate_approved` | `GateApprovedSignal(approved_by, justification)` | appends 5-tuple `(APPROVED, approved_by, justification, None, [])` to `_gate_decisions`. |
| `gate_rejected` | `GateRejectedSignal(rejected_by, reason, [reason_category], [card_decisions])` | appends 5-tuple `(REJECTED, rejected_by, reason, reason_category, card_decisions)`. |
| `escalation_resolved` | `EscalationResolvedSignal` | only refreshes `_updated_at`. |
| `merge_retry` | `GateMergeRetrySignal` | sets `_merge_retry_signalled = True` (consumed by `_reconcile_and_merge_with_retry_loop`). |
Plus HIL mixin signals: `approve_plan`, `provide_plan_feedback`, `approve_research`, `provide_feedback`, `approve`, `cancel_workflow` (signals.py:47-86). Only `cancel_workflow` (→ `self.cancelled = True`) is consumed by Build's wait predicates.

### 2d. Query — `get_status` (inherited, base.py:1353-1365)
Returns `WorkflowStatusResponse(workflow_id, status=_status, current_line=AssemblyLine.BUILD, current_step, progress_pct, pending_gate, started_at, updated_at)`. BuildWorkflow does not override it.

---

## 3. CONTROL FLOW

### 3a. `run(input)` — `@workflow.run` (`build.py:207-231`)
```
run(input: LineWorkflowInput) -> str:
    if isinstance(input, dict):                 # accept dict or dataclass
        input = LineWorkflowInput(**input)
    self._status = RUNNING
    self._started_at = workflow.now().isoformat()
    self._app_id = input.app_id
    self._portfolio_id = input.portfolio_id
    self._wave_id = input.wave_id
    self._input = input
    self._risk_tier = int(input.risk_tier) if input.risk_tier is not None else None
    try:
        return await self._execute_build(input)
    except Exception:
        self._status = FAILED
        self._updated_at = workflow.now().isoformat()
        try:
            await self._update_app_status(input.app_id, "build_failed", "failed", "Build")
        except Exception:                       # noqa BLE001 — best-effort status flip
            pass
        raise                                   # re-raise original exception
```
GOTCHA (`build.py:225-230`): the status-flip DB write is wrapped in its own try/except; if `update_application_status` itself fails, it is swallowed and the ORIGINAL exception still propagates. GOTCHA (`build.py:217-219`): `_risk_tier` is coerced with `int(...)` — a `RiskTier` enum or numeric string becomes an int; `None` stays `None`. The tier-1 comparisons later use `== 1`.

### 3b. `_execute_build(input)` (`build.py:233-286`)
```
_execute_build(input) -> str:
    app_id = input.app_id
    self._artifact_repo   = input.artifact_repo
    self._target_repo_url = input.target_repo_url or ""
    repo = input.target_repo_url or input.artifact_repo        # COMMIT/work repo
    run_suffix = workflow.info().workflow_id.rsplit("-", 1)[-1] # last "-"-segment of wf id
    workspace_key = f"build-{app_id}-{run_suffix}"

    await self._load_delegation_config(input.portfolio_id)     # best-effort; sets profile/fallback
    await self._update_app_status(app_id, "build_in_progress", "spec-from-requirements", "Build")

    spec_result = await self._execute_spec(input, repo, workspace_key)
    if spec_result != "approved":
        return spec_result                                     # "cancelled" | "failed"

    design_result = await self._execute_design(input, repo, workspace_key)
    if design_result != "approved":
        return design_result

    generate_result = await self._execute_generate(input, repo, run_suffix, workspace_key)
    if generate_result != "approved":
        return generate_result

    await self._update_app_status(app_id, "build_complete", "completed", "Build")
    self._status = COMPLETED
    self._progress_pct = 100.0
    self._current_step = "completed"
    self._updated_at = workflow.now().isoformat()
    return "completed"
```
Repo-routing rule (`build.py:236-256`, GOTCHA — critical):
- `repo` = `target_repo_url or artifact_repo` = the **COMMIT/work repo** for ALL Build deliverables (spec, design, code, tests) AND its gate-review PRs.
- `self._artifact_repo` (portfolio repo) is the **READ repo** for the three cross-line priors ONLY: `build/{app_id}/requirements/requirements-capability.json`, `architecture/{app_id}/architecture-blueprint.json`, `data/{app_id}/data-architecture.json`.
- Fallback: when `target_repo_url` empty, `repo == artifact_repo` (both seams collapse) so legacy/non-provisioned callers still run.
- The base separates seams: `_dispatch_agent(artifact_repo=...)` selects what the agent READS; `_commit_step_artifacts(repo=...)` selects where output LANDS.

Sequential-phase contract: each phase returns one of `"approved" | "cancelled" | "failed"`. Only `"approved"` advances; anything else is returned verbatim up through `run`. There is NO retry across phases — a failed phase terminates the whole workflow (status already set inside the phase helper).

### 3c. `_rework_gate_key_for_step(step_name)` override (`build.py:161-174`)
```
if step_name == "spec-from-requirements": return "G-NEW-1"
if step_name in set(self._DESIGN_STEPS):   return "G-NEW-2"   # the 4 design sub-steps
return None                                                    # Generate steps → None
```
GOTCHA: returns `None` for `synthesis`/`adversarial-review`/`security-scan-review` → base `_dispatch_agent` forwards **no** `rework_feedback` for those. Generate rework is instead carried through re-running `GenerateBCWorkflow` children on the next loop iteration (`build.py:167-169`). So on a G-NEW-3 rejection the child inputs are re-derived but the rejection reason is NOT threaded into agent context for the synthesis/review steps.

### 3d. Phase 1 — `_execute_spec(input, repo, workspace_key)` (`build.py:292-372`)
```
app_id = input.app_id
gate_key = "G-NEW-1"
branch = f"olympus/build/spec/{app_id}/{workspace_key.rsplit('-',1)[-1]}"   # = run_suffix
spec_inputs = [
    f"build/{app_id}/requirements/requirements-capability.json",
    f"architecture/{app_id}/architecture-blueprint.json",
    f"data/{app_id}/data-architecture.json",
]
while True:                                                   # rework loop
    await self._set_step("spec-from-requirements", 0.0)
    result = await self._dispatch_agent(
        app_id, "spec-from-requirements", spec_inputs,
        workspace_key=workspace_key,
        artifact_repo=self._artifact_repo)                    # READ from PORTFOLIO repo
    artifact_path = f"build/{app_id}/specs/spec-from-requirements.json"
    await self._commit_step_artifacts(
        repo, branch, app_id, "spec-from-requirements", result, artifact_path)  # COMMIT to work repo
    committed = self._step_committed_paths.get("spec-from-requirements", [artifact_path])
    self._spec_results["spec-from-requirements"] = list(committed)

    decision, pr_number, gate_id = await self._run_one_gate(
        input=input, repo=repo, branch=branch,
        gate_type=GateType.G_NEW_1, gate_key="G-NEW-1",
        step="spec-from-requirements", artifact_paths=committed,
        pr_title=f"Gate G-NEW-1: Spec Review — {app_id}",
        pr_body=self._gate_pr_body("Spec-from-Requirements", "G-NEW-1", committed))

    if decision == "cancelled":
        self._status = CANCELLED; return "cancelled"
    if decision == "approved":
        if self._risk_tier == 1:                              # Tier-1 SME sign-off gate
            await workflow.wait_condition(
                lambda: self._g_new_1_stakeholder_approved or self.cancelled)
            if self.cancelled:
                self._status = CANCELLED; return "cancelled"
        await self._reconcile_and_merge_with_retry_loop(
            repo=repo, pr_number=pr_number, gate_id=gate_id, merge_method="merge")
        return "approved"
    # decision == "rejected" → rework
    self._g_new_1_stakeholder_approved = False                # reset SME flag
    self._bump_rework("G-NEW-1")
    if self._rework_count("G-NEW-1") > MAX_REWORK_ITERATIONS:  # > 3 (i.e. 4th reject)
        return await self._fail_max_rework(app_id, "spec")
    # else: fall to top of while — re-dispatch spec agent with rework feedback
```
GOTCHAs:
- `branch` suffix `workspace_key.rsplit('-',1)[-1]` == `run_suffix` (workspace_key ends `-{run_suffix}`). Branch is STABLE across rework iterations (no per-iteration suffix) — rework commits stack onto the same branch/PR (`build.py:297`).
- `_dispatch_agent` reads from `self._artifact_repo` here (the ONLY place Build reads the portfolio repo, `build.py:305-309`), because the cross-line priors were written there by upstream lines.
- `_spec_results` stores COMMITTED file paths, NOT `result.output_artifacts` (which is the agent's free-text summary) — feeding prose to the next step's `_fetch_input_artifacts` would try to fetch prose as a path and hard-fail (`build.py:327-333`, DECISION-018 defensive-output).
- SME flag reset happens BEFORE `_bump_rework` on every rejection (`build.py:369`).

### 3e. Phase 2 — `_execute_design(input, repo, workspace_key)` (`build.py:378-439`)
```
app_id = input.app_id
gate_key = "G-NEW-2"
branch = f"olympus/build/design/{app_id}/{workspace_key.rsplit('-',1)[-1]}"   # = run_suffix
spec_artifacts = self._spec_results.get("spec-from-requirements", [])          # committed spec paths
while True:                                                    # rework loop
    committed_all = []
    base_progress = 35.0
    for i, step_name in enumerate(self._DESIGN_STEPS):         # module-design, api-specification,
                                                               # data-modeling, traceability-audit
        await self._set_step(step_name, base_progress + i*3.0) # 35.0, 38.0, 41.0, 44.0
        result = await self._dispatch_agent(
            app_id, step_name, spec_artifacts,
            workspace_key=workspace_key,
            artifact_repo=repo)                                # READ from WORK repo (spec already there)
        artifact_path = f"build/{app_id}/design/{step_name}.json"
        await self._commit_step_artifacts(repo, branch, app_id, step_name, result, artifact_path)
        step_committed = self._step_committed_paths.get(step_name, [artifact_path])
        self._design_results[step_name] = list(step_committed)
        committed_all.extend(step_committed)

    decision, pr_number, gate_id = await self._run_one_gate(
        input=input, repo=repo, branch=branch,
        gate_type=GateType.G_NEW_2, gate_key="G-NEW-2",
        step="module-design",                                  # evidence anchored on module-design
        artifact_paths=committed_all,
        pr_title=f"Gate G-NEW-2: Build Design Review — {app_id}",
        pr_body=self._gate_pr_body("Design", "G-NEW-2", committed_all))

    if decision == "cancelled":
        self._status = CANCELLED; return "cancelled"
    if decision == "approved":                                 # NO tier-1 wait for G-NEW-2
        await self._reconcile_and_merge_with_retry_loop(
            repo=repo, pr_number=pr_number, gate_id=gate_id, merge_method="merge")
        return "approved"
    self._bump_rework("G-NEW-2")
    if self._rework_count("G-NEW-2") > MAX_REWORK_ITERATIONS:
        return await self._fail_max_rework(app_id, "design")
    # else re-run ALL 4 design sub-steps
```
GOTCHAs:
- The 4 design sub-steps run **SEQUENTIALLY** (a `for` loop, each awaited), NOT in parallel (`build.py:390-413`).
- Progress values: 35.0 / 38.0 / 41.0 / 44.0 (`build.py:389,392`).
- Design reads spec via `artifact_repo=repo` (work repo), because the spec was committed there in phase 1 — contrast with phase 1 reading the portfolio repo (`build.py:399` vs `build.py:315`).
- On rework, `_design_results[step_name]` is overwritten each pass; `committed_all` is rebuilt fresh each pass (`build.py:388,412-413`).
- No SME/EA/security stakeholder gate for G-NEW-2.
- Rework feedback IS forwarded for design steps (they map to `G-NEW-2` via `_rework_gate_key_for_step`).

### 3f. Phase 3 — `_execute_generate(input, repo, run_suffix, workspace_key)` (`build.py:445-636`)
```
app_id = input.app_id
gate_key = "G-NEW-3"
branch = f"olympus/build/generate/{app_id}/{run_suffix}"
while True:                                                    # rework loop
    await self._set_step("generate", 70.0)
    bc_names = await self._parse_bounded_contexts(repo, app_id)   # activity read + parse; fallback ["default"]
    design_artifacts = self._collect_design_artifacts()           # flatten _design_results values

    # ---- Fan-out per bounded context (PARALLEL child workflows) ----
    bc_tasks = []
    for bc_name in bc_names[:MAX_BC_CHILDREN_PER_APP]:            # cap 12
        is_frontend = bc_name.lower() in _FRONTEND_BC_NAMES
        bc_input = GenerateBCInput(
            app_id=app_id, bc_name=bc_name, wave_id=input.wave_id,
            portfolio_id=input.portfolio_id, artifact_repo=repo,
            source_repo="",                                       # greenfield: no legacy tree
            design_artifacts=design_artifacts,
            target_framework=(None if is_frontend else input.target_framework),
            target_frontend=(input.target_frontend if is_frontend else None),
            primary_language=input.primary_language)
        bc_tasks.append(workflow.execute_child_workflow(
            "GenerateBCWorkflow", bc_input,
            id=f"generate-bc-{app_id}-{bc_name}-{run_suffix}",
            task_queue=workflow.info().task_queue))
    raw_results = await asyncio.gather(*bc_tasks)                 # all children in parallel
    self._generate_results = [
        r if isinstance(r, GenerateBCResult) else GenerateBCResult(**r)
        for r in raw_results]

    # ---- Persist per-BC generated code to work repo BEFORE synthesis ----
    bc_code_files = []; bc_code_paths = []
    for r in self._generate_results:
        for f in (r.output_files or []):
            if not getattr(f, "path", ""):
                continue                                          # skip files with empty path
            repo_path = f"build/{app_id}/generate/code/{r.bc_name}/{f.path}"
            bc_code_files.append((repo_path, f.content))
            bc_code_paths.append(repo_path)
    if bc_code_files:                                             # only commit if any files
        await workflow.execute_activity(
            write_artifacts_batch,
            WriteArtifactsBatchInput(
                repo=repo, branch=branch, files=bc_code_files,
                commit_message=f"build({app_id}): generated source ({len(bc_code_files)} files)",
                execution_context=self._execution_ctx("commit-generate-code", app_id=app_id)),
            start_to_close_timeout=timedelta(seconds=180),
            retry_policy=RETRY_POLICIES["transient"],
            activity_id=f"commit-generate-code-{run_suffix}")

    # ---- Synthesis (direct dispatch) ----
    await self._set_step("synthesis", 82.0)
    synthesis = await self._dispatch_agent(
        app_id, "synthesis", bc_code_paths,
        workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)
    synth_path = f"build/{app_id}/generate/synthesis.json"
    await self._commit_step_artifacts(repo, branch, app_id, "synthesis", synthesis, synth_path)
    committed = list(self._step_committed_paths.get("synthesis", [synth_path]))
    synth_inputs = list(committed)

    # ---- Adversarial review (direct dispatch) ----
    await self._set_step("adversarial-review", 88.0)
    adversarial = await self._dispatch_agent(
        app_id, "adversarial-review", synth_inputs,
        workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)
    adv_path = f"build/{app_id}/generate/adversarial-review.json"
    await self._commit_step_artifacts(repo, branch, app_id, "adversarial-review", adversarial, adv_path)
    committed.extend(self._step_committed_paths.get("adversarial-review", [adv_path]))

    # ---- Security scan (BEST-EFFORT — try/except swallows) ----
    try:
        await self._set_step("security-scan-review", 92.0)
        sec = await self._dispatch_agent(
            app_id, "security-scan-review", synth_inputs,
            workspace_key=workspace_key, artifact_repo=repo, artifact_ref=branch)
        sec_path = f"build/{app_id}/generate/security-scan-review.json"
        await self._commit_step_artifacts(repo, branch, app_id, "security-scan-review", sec, sec_path)
        committed.extend(self._step_committed_paths.get("security-scan-review", [sec_path]))
    except Exception as exc:                                      # noqa BLE001 — non-fatal
        workflow.logger.warning("build security-scan-review failed (non-fatal): %s", exc)

    # ---- Gate G-NEW-3 ----
    decision, pr_number, gate_id = await self._run_one_gate(
        input=input, repo=repo, branch=branch,
        gate_type=GateType.G_NEW_3, gate_key="G-NEW-3",
        step="synthesis", artifact_paths=committed,
        pr_title=f"Gate G-NEW-3: Code & Test Review — {app_id}",
        pr_body=self._gate_pr_body("Generate", "G-NEW-3", committed))

    if decision == "cancelled":
        self._status = CANCELLED; return "cancelled"
    if decision == "approved":
        if self._risk_tier == 1:                                  # Tier-1 triple-signal: EA + security
            await workflow.wait_condition(
                lambda: (self._g_new_3_ea_approved and self._g_new_3_security_approved)
                        or self.cancelled)
            if self.cancelled:
                self._status = CANCELLED; return "cancelled"
        await self._reconcile_and_merge_with_retry_loop(
            repo=repo, pr_number=pr_number, gate_id=gate_id, merge_method="merge")
        return "approved"
    self._g_new_3_ea_approved = False                             # reset triple-signal
    self._g_new_3_security_approved = False
    self._bump_rework("G-NEW-3")
    if self._rework_count("G-NEW-3") > MAX_REWORK_ITERATIONS:
        return await self._fail_max_rework(app_id, "generate")
    # else re-run entire Generate loop (re-fan-out children)
```
GOTCHAs (Generate):
- **Frontend routing** (`build.py:462,471-476`): a BC whose lowercased name ∈ `{"frontend","ui","web-app","spa"}` gets `target_framework=None` + `target_frontend=input.target_frontend`; every other BC gets `target_framework=input.target_framework` + `target_frontend=None`. Mutually exclusive per BC.
- **Children are EPHEMERAL** (no shared `workspace_key` on the child dispatches): generated files survive only as `GenerateBCResult.output_files` (path+content) in workflow memory, NOT in repo/workspace (`build.py:495-506`). The `write_artifacts_batch` commit persists them to `build/{app_id}/generate/code/{bc_name}/{f.path}` so synthesis can read real files.
- **Synthesis inputs** are the committed CODE paths `bc_code_paths` (`build.py:540`), NOT child `output_artifacts` (prose). `artifact_ref=branch` REQUIRED because files live on the build branch (not yet merged to main) — otherwise fetch 404s on the default branch (`build.py:552-559`).
- Review chain (`adversarial`, `security`) reads the synthesis' COMMITTED path (`synth_inputs`), again with `artifact_ref=branch` (`build.py:560,564-565,579-581`).
- Security scan is the ONLY step wrapped in try/except — its failure is logged and the workflow proceeds to the gate anyway (`build.py:577-596`). Synthesis and adversarial-review failures are NOT caught → propagate → `run` catches → `FAILED`.
- `committed` accumulates: synthesis paths → +adversarial paths → (+security paths if it succeeded). This full list is the gate evidence (`build.py:548-592,605`).
- Empty-path child files are skipped (`build.py:511-512`). If no BC produced any file, the `write_artifacts_batch` commit is skipped entirely (`if bc_code_files:` guard, `build.py:518`).
- Progress values: generate 70.0, synthesis 82.0, adversarial 88.0, security 92.0 (`build.py:456,538,562,578`).
- Child result normalization: dict → `GenerateBCResult(**r)` (`build.py:489-492`).
- On G-NEW-3 rework, the whole loop re-runs: children re-spawn with the SAME `id=generate-bc-{app_id}-{bc_name}-{run_suffix}` (run_suffix stable) — GOTCHA: re-executing a child workflow with an already-used ID within the same parent will hit Temporal's child-ID-reuse semantics; the design relies on the previous children having COMPLETED (they returned results via gather) so the ID can be reused. Rework re-parses BCs and re-fans-out.

### 3g. `_run_one_gate(...)` — shared gate cycle (`build.py:642-700`)
Keyword-only args: `input, repo, branch, gate_type, gate_key, step, artifact_paths, pr_title, pr_body`. Returns `(decision, pr_number, gate_id)`.
```
app_id = input.app_id
pr_result = await self._create_gate_pr(repo, branch, app_id, gate_type.value, pr_title, pr_body)
gate_record = await workflow.execute_activity(
    create_gate_record,
    CreateGateRecordInput(
        gate_type=gate_type.value, app_id=app_id, portfolio_id=input.portfolio_id,
        workflow_id=workflow.info().workflow_id, evidence_package_url=pr_result.pr_url),
    start_to_close_timeout=timedelta(seconds=30),
    retry_policy=RETRY_POLICIES["transient"])
await self._submit_gate_evidence(
    gate_record.gate_id, gate_type, app_id, artifact_paths, pr_result.pr_url, "Build", step)
await self._run_gate_pre_review(
    gate_record.gate_id, gate_type.value, artifact_paths,
    artifact_repo=repo, artifact_ref=branch)
await self._update_app_status(app_id, "gate_review", f"{gate_key.lower()}-review", "Build")
decision = await self._wait_for_gate_decision(gate_type)      # blocks on gate signal
return decision, pr_result.pr_number, gate_record.gate_id
```
Order (all sequential, awaited): create PR → create gate record → submit evidence (+check criteria) → AI pre-review → status flip → block on decision.
- `create_gate_record` passes `app_id` (not `wave_id`) — satisfies the DB one-of constraint (`build.py:667-675`, types.py CreateGateRecordInput).
- Status becomes `gate_review` / step `{gate_key.lower()}-review` (e.g. `g-new-1-review`) — `build.py:696-698`.
- Returns the tuple rather than stashing on `self` to keep merge target explicit and avoid cross-phase state coupling (`build.py:655-661`).

### 3h. `_fail_max_rework(app_id, phase)` (`build.py:706-713`)
```
self._status = FAILED
self._current_step = f"{phase}-max-rework-exceeded"           # e.g. "spec-max-rework-exceeded"
self._updated_at = workflow.now().isoformat()
await self._update_app_status(app_id, "build_failed", f"{phase}-max-rework-exceeded", "Build")
return "failed"
```
`phase` ∈ {`"spec"`,`"design"`,`"generate"`}. Returns `"failed"` → phase helper returns `"failed"` → `_execute_build` returns `"failed"`.

### 3i. `_parse_bounded_contexts(repo, app_id)` (`build.py:715-742`)
```
module_map_path = f"build/{app_id}/design/module-design.json"
try:
    result = await workflow.execute_activity(
        read_artifact,
        ReadArtifactInput(repo=repo, path=module_map_path, branch="main"),   # NOTE: branch="main"
        start_to_close_timeout=timedelta(seconds=30),
        retry_policy=RETRY_POLICIES["transient"])
    names = parse_bc_names_from_yaml(result.content)
    return names or ["default"]
except Exception as exc:                                      # noqa BLE001
    workflow.logger.warning("build: could not parse bounded contexts (%s); using default", exc)
    return ["default"]
```
GOTCHA (`build.py:731`): reads `module-design.json` from **`branch="main"`** — this relies on the G-NEW-2 Design PR having been MERGED to main (which it was, via `_reconcile_and_merge_with_retry_loop` before phase 3). Reading the build branch would be wrong here.
GOTCHA (`build.py:736-737`): `parse_bc_names_from_yaml` returns `[]` on malformed/empty YAML; `names or ["default"]` then yields `["default"]`. Any exception (read failure, etc.) also falls back to `["default"]` — a single-BC generate still produces a working app. Imports `read_artifact`/`ReadArtifactInput` locally inside the method.
`parse_bc_names_from_yaml` (modernization.py:2771+): `yaml.safe_load` (never `yaml.load`); expects dict with `bounded_contexts` or `contexts` array; non-dict/malformed → `[]`; truncation to cap happens at call site via slicing, not here.

### 3j. `_collect_design_artifacts()` (`build.py:744-745`)
```
return [a for arts in self._design_results.values() for a in arts]
```
Flattens all committed design paths (dict-insertion order: module-design, api-specification, data-modeling, traceability-audit) into one list. Fed as `design_artifacts` to every BC child.

### 3k. `_gate_pr_body(phase, gate_key, artifacts)` (`build.py:747-759`)
```
rework = self._rework_count(gate_key)
lines = [f"## Build — {phase} ({gate_key})", "", f"Rework iteration: {rework}", "", "### Artifacts"]
lines.extend(f"- `{a}`" for a in artifacts)
return "\n".join(lines)
```
GOTCHA: PR body is built from `_rework_count(gate_key)` at CALL time (before `_bump_rework`), so the first PR shows `Rework iteration: 0`; after a rejection the loop bumps then re-enters, so the next PR body reflects the incremented count. But note the PR/branch is REUSED across rework (stable branch) — a fresh `_create_gate_pr` may create a duplicate PR or the create activity may be idempotent (see `create_pr` activity doc).

---

## 4. ACTIVITY & CHILD-WORKFLOW CALLS (in execution order)

| # | Call | Args (key) | Timeout | Retry policy | non_retryable | Seq/Par |
|---|---|---|---|---|---|---|
| 1 | `load_portfolio_delegation_activity` (base `_load_delegation_config`) | `[profile_id]` | 15s | `transient` | — | seq; best-effort (except→default) |
| 2 | `update_application_status` (base `_update_app_status`) — `build_in_progress` | UpdateAppStatusInput | 30s | `transient` | — | seq |
| — | **Phase 1 loop:** | | | | | |
| 3 | `update_application_status` (via `_set_step`) | `build_in_progress`, step | 30s | `transient` | — | seq |
| 4 | `load_context_priors` (base `_dispatch_agent`, patch-gated `context-priors-v1`) | LoadContextPriorsInput(skill_id) | 10s | `transient` | — | seq; best-effort |
| 5 | `dispatch_agent_task` (spec agent) | AgentTaskInput | `AGENT_START_TO_CLOSE`=3h | `agent_failure` (3 attempts, 5→60s) | — | seq; `activity_id=agent-spec-from-requirements` |
| 6 | `write_artifacts_batch` (base `_commit_step_artifacts`) | WriteArtifactsBatchInput | 120s | `transient` | — | seq; `activity_id=commit-spec-from-requirements` |
| 7 | `update_agent_task_output_ref` (patch `patch-output-artifact-ref-v1`) | `[app_id, task_type, path]` | 30s | `transient` | — | seq; best-effort |
| 8 | `create_pr` (base `_create_gate_pr`) | CreatePRInput | 60s | `transient` | — | seq |
| 9 | `create_gate_record` (`_run_one_gate`) | CreateGateRecordInput | 30s | `transient` | — | seq |
| 10 | `check_gate_criteria` (base `_submit_gate_evidence`) | CheckGateCriteriaInput(+risk_tier) | 60s | `transient` | — | seq |
| 11 | `submit_gate_evidence` (base) | SubmitGateEvidenceInput (slim) | 60s | `transient` | — | seq |
| 12 | `dispatch_agent_task` (gate-pre-review, base `_run_gate_pre_review`) | AgentTaskInput(gate-pre-review) | 3h + heartbeat 2m | `transient` | — | seq; best-effort (except logged) |
| 13 | `store_gate_pre_review` (base) | StoreGatePreReviewInput | 30s | `transient` | — | seq; only if pre-review produced output |
| 14 | `mark_gate_ready_for_review` (base, patch `mark-gate-ready-for-review-v1`, in `finally`) | `gate_id` | 30s | `transient` | — | seq |
| 15 | `update_application_status` — `gate_review` | UpdateAppStatusInput | 30s | `transient` | — | seq |
| 16 | (`_wait_for_gate_decision`) — no activity; blocks on `wait_condition` | — | — | — | — | BLOCK |
| 17 | On approve: `reconcile_and_merge_pr` (base retry loop) | MergePRInput(merge_method="merge") | 60s | `git_merge` (3 attempts, 5→30s) | `MergeConflict`, `MergeDivergenceUnresolved`, `MergeBranchProtectionRejected` | seq; loop |
| 18 | On merge_blocked: `set_gate_merge_blocked` | `[gate_id, detail]` | 30s | `transient` | — | seq; then `wait_condition(_merge_retry_signalled or cancelled)` |
| — | **Phase 2 loop:** repeats #3–#17 for each of 4 design steps (dispatch+commit sequential ×4), then one gate cycle (#8–#17). Design dispatch `activity_id=agent-{step}`, commit `activity_id=commit-{step}`. | | | | | |
| — | **Phase 3 loop:** | | | | | |
| 19 | `read_artifact` (`_parse_bounded_contexts`) | ReadArtifactInput(branch="main") | 30s | `transient` | — | seq; except→["default"] |
| 20 | `GenerateBCWorkflow` **child** ×N (N≤12) | GenerateBCInput; `id=generate-bc-{app_id}-{bc}-{suffix}`; `task_queue=current` | — | (child policy) | — | **PARALLEL via asyncio.gather** |
| 21 | `write_artifacts_batch` (generated code) | WriteArtifactsBatchInput | 180s | `transient` | — | seq; `activity_id=commit-generate-code-{suffix}`; only if files |
| 22 | `dispatch_agent_task` (synthesis) + `write_artifacts_batch` | — | 3h / 120s | `agent_failure`/`transient` | — | seq |
| 23 | `dispatch_agent_task` (adversarial-review) + commit | — | 3h / 120s | `agent_failure`/`transient` | — | seq |
| 24 | `dispatch_agent_task` (security-scan-review) + commit | — | 3h / 120s | `agent_failure`/`transient` | — | seq; **in try/except (best-effort)** |
| 25 | gate cycle #8–#17 for G-NEW-3 | — | — | — | — | seq |
| 26 | `update_application_status` — terminal (`build_complete`/`build_failed`) | UpdateAppStatusInput | 30s | `transient` | — | seq |

Retry policy definitions (retry_policies.py): `transient`=HTTP_RETRY (3 attempts, 1→15s, coeff 2.0); `agent_failure`=(3 attempts, 5→60s, coeff 2.0); `git_merge`=(3 attempts, 5→30s, coeff 2.0, non-retryable = the 3 merge error types). `AGENT_START_TO_CLOSE`=3h, `AGENT_DISPATCH_HEARTBEAT_TIMEOUT`=2m (agent_timeouts.py:67,72). GOTCHA: agent dispatches in `_dispatch_agent` do NOT set a heartbeat_timeout (only `_run_gate_pre_review` does, base.py:1069); the spec/design/synthesis dispatches rely on the 3h start_to_close ceiling alone.

---

## 5. GATE HANDLING

All three gates flow through `_run_one_gate` → base helpers. Per gate:

**Evidence assembly** (base `_submit_gate_evidence`, base.py:922-1021):
- Builds a SLIM `evidence_data` (path/encoding/size, no content) via `_build_evidence_data` for persistence.
- For `check_gate_criteria`, resolves `GATE_THRESHOLDS[gate_type]`; if the gate declares threshold artifacts, rebuilds a bundle including ONLY those artifacts' content (`content_paths`), keeping input size O(threshold-count). If no thresholds, the slim bundle is reused.
- `forward_risk_tier=True` (default) → `check_gate_criteria` carries `evidence_data` + `risk_tier`.
- `submit_gate_evidence` always uses the slim bundle + `pr_url`.

**The wait** (base `_wait_for_gate_decision`, base.py:1103-1157):
- Sets `_status=WAITING_FOR_SIGNAL`, `_pending_gate=gate_type`.
- `consumed = _gate_decisions_consumed`; `await wait_condition(len(_gate_decisions) > consumed or self.cancelled)`.
- If `cancelled` → status CANCELLED, return `"cancelled"`.
- Reads `_gate_decisions[consumed]` (5-tuple: decision, actor, reason, reason_category, card_decisions; 3-tuple legacy path also handled), increments `_gate_decisions_consumed`.
- APPROVED → pops `_rework_feedback[gate_key]`, returns `"approved"`.
- REJECTED → writes `_rework_feedback[gate_key] = {gate, rejected_by, reason, reason_category, card_decisions, rejected_at}`, returns `"rejected"`. GOTCHA: this method does NOT bump `_rework_iterations` — the phase loops own that counter.

**Routing per decision** (in each phase helper):
| decision | action |
|---|---|
| `"cancelled"` | `_status=CANCELLED`; return `"cancelled"` (propagates to terminate workflow). |
| `"approved"` | (tier-1 gate G-NEW-1/G-NEW-3 only: await stakeholder signals; cancel-aware) → `_reconcile_and_merge_with_retry_loop` → return `"approved"`. |
| `"rejected"` | reset stakeholder flags (G-NEW-1: SME; G-NEW-3: EA+security; G-NEW-2: none) → `_bump_rework(gate)` → if `_rework_count > 3`: `_fail_max_rework` returns `"failed"`; else loop re-runs the phase. |

**Merge routing** (`_reconcile_and_merge_with_retry_loop`, base.py:1159-1279):
- Calls `reconcile_and_merge_pr` (merge_method="merge") under `git_merge` policy.
- On the 3 structured merge errors (unwrapped from `ActivityError.__cause__` to the `ApplicationError.type`): logs `merge_blocked`, resets `_merge_retry_signalled=False`, calls `set_gate_merge_blocked(gate_id, detail)`, then `await wait_condition(_merge_retry_signalled or cancelled)`. If cancelled → returns (no status flip here). Otherwise loops back and retries the merge.
- Success → returns immediately. Non-merge-structured errors → re-raised (propagate → workflow FAILED).

**Rework loop counters:** one counter per gate key in `_rework_iterations`, seeded to 0 for G-NEW-1/2/3 in `__init__`. `_bump_rework` increments; fail condition is `> MAX_REWORK_ITERATIONS` (3), i.e. the loop tolerates 3 rejections and fails on the 4th. Design re-runs all 4 sub-steps per rework; Generate re-fans-out all children per rework.

---

## 6. RESILIENCE

- **Timeouts:** every activity has an explicit `start_to_close_timeout` (table §4). Agent dispatches 3h; git/DB writes 30–180s.
- **Heartbeats:** only the gate-pre-review dispatch sets `heartbeat_timeout=2m` (base.py:1069). BuildWorkflow's own spec/design/synthesis/review dispatches do NOT.
- **Continue-as-new:** NONE. BuildWorkflow never calls `continue_as_new`. Long gate waits + rework loops accumulate history; there is no history-size guard here. GOTCHA: a workflow stuck in many rework cycles or a long merge_blocked wait grows event history unbounded.
- **Idempotency / determinism:** `run_suffix` derived deterministically from `workflow.info().workflow_id`; branch names stable across rework (spec/design use run_suffix; generate uses run_suffix). Child IDs `generate-bc-{app_id}-{bc}-{suffix}` are deterministic. Patch gates (`context-priors-v1`, `patch-output-artifact-ref-v1`, `mark-gate-ready-for-review-v1`) preserved verbatim in base so in-flight replays stay deterministic. No wall-clock/random/direct-I/O in workflow code (all time via `workflow.now()`).
- **Compensation / rollback:** NONE explicit. On any uncaught exception, `run` sets `_status=FAILED`, best-effort flips app status to `build_failed`, and re-raises. Committed artifacts and merged PRs are NOT rolled back. Security-scan failure is the only intra-phase soft-fail (swallowed). Max-rework is a controlled failure (`_fail_max_rework` → `"failed"`, no raise).
- **Cancellation:** cooperative — `cancel_workflow` sets `self.cancelled`; every long `wait_condition` (gate decision, tier-1 stakeholder, merge retry) is `or self.cancelled`-guarded and returns `"cancelled"` / sets CANCELLED. GOTCHA: cancellation between activities (e.g. mid-fan-out) is not explicitly checked — only at the wait points.

---

## 7. Behavioral parity checklist

A rebuild MUST satisfy all of:

1. Phases execute strictly Spec → Design → Generate; a non-`"approved"` phase result short-circuits `_execute_build` and returns that value verbatim; only all-approved reaches `build_complete`/COMPLETED/progress 100.0.
2. `repo = target_repo_url or artifact_repo`. Phase-1 spec agent READS from `self._artifact_repo` (portfolio) with exactly the 3 prior paths; every commit lands in `repo`. Phase-2/3 agents read from `repo`.
3. `run_suffix = workflow_id.rsplit("-",1)[-1]`; `workspace_key = build-{app_id}-{run_suffix}`; branches `olympus/build/spec|design|generate/{app_id}/{run_suffix}` (spec/design derive suffix via `workspace_key.rsplit('-',1)[-1]`).
4. Each gate: create_pr → create_gate_record(app_id) → submit evidence (slim) + check_gate_criteria (risk_tier forwarded) → gate-pre-review (best-effort) → mark_ready (patch-gated, finally) → status `gate_review`/`{gate}-review` → block on decision. Returns `(decision, pr_number, gate_id)`.
5. Rework counters seeded {G-NEW-1:0,G-NEW-2:0,G-NEW-3:0}; each rejection bumps its gate counter; failure when count `> 3` (4th rejection) → `_fail_max_rework` sets FAILED, step `{phase}-max-rework-exceeded`, status `build_failed`, returns `"failed"`.
6. Tier-1 (`_risk_tier == 1`) ONLY: G-NEW-1 waits for `_g_new_1_stakeholder_approved`; G-NEW-3 waits for `_g_new_3_ea_approved AND _g_new_3_security_approved`; G-NEW-2 has NO stakeholder wait. All three flags reset to False in their respective rework branches; the SME reset for G-NEW-1 precedes `_bump_rework`.
7. `stakeholder_approved` sets the flag for scope ∈ {`g-new-1-stakeholder`,`g-new-3-ea`,`g-new-3-security`}; unknown scope logs a warning and changes nothing but `_updated_at`. Flags are never cleared by the signal.
8. Design runs the 4 sub-steps SEQUENTIALLY at progress 35/38/41/44; stores committed paths per step; gate evidence = concatenation of all 4 steps' committed paths; gate `step="module-design"`.
9. Generate parses BCs from `build/{app_id}/design/module-design.json` on `branch="main"`, falling back to `["default"]` on any failure/empty; slices to ≤12; fans out `GenerateBCWorkflow` children in PARALLEL via `asyncio.gather` with deterministic child ids; normalizes dict results to `GenerateBCResult`.
10. Frontend BC routing: lowercased name ∈ {frontend,ui,web-app,spa} → `target_framework=None`,`target_frontend=input.target_frontend`; else the inverse. `source_repo=""` always (greenfield).
11. Generated child files persisted to `build/{app_id}/generate/code/{bc_name}/{path}` (empty-path files skipped) via one `write_artifacts_batch` (180s) BEFORE synthesis, only if any files exist; synthesis input = those committed code paths.
12. synthesis (82) → adversarial-review (88) → security-scan-review (92, best-effort try/except) → gate G-NEW-3; all Generate dispatches pass `artifact_ref=branch`; `committed` accumulates synthesis+adversarial(+security) paths as gate evidence.
13. Merge uses `_reconcile_and_merge_with_retry_loop` with `git_merge` policy (non-retryable: MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected); on those → `set_gate_merge_blocked` then await `merge_retry` signal; cancel-aware.
14. On uncaught exception `run` sets FAILED, best-effort `build_failed` status flip (its own failure swallowed), re-raises. No continue-as-new, no rollback.
15. Base signals `gate_approved`/`gate_rejected`/`escalation_resolved`/`merge_retry` and query `get_status` are NOT redefined by the subclass; `stakeholder_approved` is the only added signal.
16. `_rework_gate_key_for_step`: spec→G-NEW-1, any design sub-step→G-NEW-2, everything else→None (Generate steps forward no rework_feedback).
