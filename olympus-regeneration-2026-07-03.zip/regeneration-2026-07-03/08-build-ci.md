# 08 — Build & CI

Atomic regeneration spec for the Olympus **CI/CD, test-gating, coverage-floor,
lint/type, schema-validation, and anti-drift** subsystem. Behavioral parity bar:
an engineer with no access to the repo must rebuild these workflows + guard
scripts so they gate identically.

All paths relative to repo root `/Users/pnunna/Documents/GitHub/olympus`.
Canonical code only (build/lib, .venv, node_modules, .claude/worktrees excluded).

---

## 0. Inventory of workflow files

`.github/workflows/` contains **7** workflow files (the prior spec listed 5;
`drift-backward.yml` + `drift-forward.yml` were added in P8):

| File | Trigger surface | Blocking? |
|---|---|---|
| `ci.yml` | PR→main, push→main, nightly cron `0 7 * * *` | yes (the gate) |
| `deploy.yml` | `workflow_run` on CI completion (main) + `workflow_dispatch` | deploy only |
| `branch-protection-sync.yml` | push→main on policy-file change + dispatch | no-op if no token |
| `pages-publish-traceability.yml` | push→main on traceability paths + dispatch | no |
| `traceability-check.yml` | PR on many paths | advisory (never fails CI) |
| `drift-backward.yml` | push main/`integration/**` + PR closed→main | yes (asserts wiring) |
| `drift-forward.yml` | push any branch on spec/schema paths + PR on spec/schema | yes (asserts wiring) |

Declarative branch-protection contract: `.github/branch-protection.yml`
(see §9).

---

## 1. `ci.yml` — the CI gate

`.github/workflows/ci.yml` (name `CI`, :1).

### 1.1 Triggers & top-level config
- `on:` `pull_request: branches: [main]` (:4-5); `push: branches: [main]` (:6-7);
  `schedule: - cron: "0 7 * * *"` — nightly heavy-scan at 07:00 UTC (:8-13).
- `concurrency`: group `ci-${{ github.workflow }}-${{ pr.number || github.ref }}`;
  `cancel-in-progress: ${{ github.event_name == 'pull_request' }}` — PR runs
  cancel superseded runs; push-to-main runs keyed on `github.sha` never cancel
  each other (:17-19).
- `permissions`: `contents: read`, `pull-requests: read` (:21-23).

### 1.2 `preflight` job — changed-path classification (:33-282)
`runs-on: ubuntu-latest`. `actions/checkout@v5` with `fetch-depth: 0` (:61-63).
Emits **24 boolean outputs** (:37-59): `docs_only`, `run_all`,
`contracts_changed`, `skill_catalog_changed`, `objectives_changed`,
`doc_sync_changed`, `step_registry_changed`, `sql_schema_changed`,
`line_contracts_changed`, `api_changed`, `worker_changed`,
`agent_runtime_changed`, `mcp_changed`, `temporal_changed`,
`contracts_pkg_changed`, `dashboard_changed`, `helm_changed`,
`terraform_changed`, `argocd_changed`, `python_any_changed`,
`stack_spin_changed`, `live_e2e_changed`, `devsecops_baseline_changed`.

**Classification algorithm** (step `classify`, :65-282):
1. **Force-full-CI short-circuit** (:80-97): if `EVENT == schedule` OR `push`,
   set `run_all=true`, `docs_only=false`, and every `*_changed=true`; exit.
   This is what gives heavy scanners a reliable nightly/main cadence.
2. **Resolve BASE/HEAD** (:99-127): for `pull_request`, use `base.sha`/`head.sha`;
   else `github.event.before`/`github.sha`. If BASE is the all-zeros sha or empty,
   fall back to `git merge-base origin/main HEAD`. If still empty →
   `::warning::` + force-full-CI (safe fallback), exit (:110-127).
3. `CHANGED=$(git diff --name-only BASE HEAD)` (:129).
4. **docs_only** (:133-140): true iff *every* changed path matches
   `\.(md|mdx)$` OR is under `specifications/`, `docs/`, `reference/`,
   `.claude/`, `.agents/`. GOTCHA: the `grep -Ev` inverts — non-docs remaining
   ⇒ docs_only=false.
5. **Workflow-edit short-circuit** (:145-162): any changed path under
   `^\.github/workflows/` ⇒ force-full-CI. Prevents a workflow edit passing
   because nothing it touched ran.
6. `match <regex>` helper (:165-171): echoes `true`/`false` on grep match.
7. Per-surface globs (:173-191):
   - `contracts_changed` ← `^schemas/|^specifications/api/|^olympus-contracts/`
   - `skill_catalog_changed` ← `^cross-cutting/skills/|^scripts/validate_skill_registry\.py$|^tests/test_validate_skill_registry\.py$`
   - `objectives_changed` ← `^profiles/.+/objectives\.yaml$|^schemas/profiles/objectives\.schema\.json$|^schemas/cross-cutting/metric\.schema\.json$|^scripts/validate_objectives\.py$|^tests/test_validate_objectives\.py$|^cross-cutting/.+\.ya?ml$|^assembly-lines/.+\.ya?ml$`
   - `doc_sync_changed` ← `^README\.md$|^CLAUDE\.md$|^reference/terminology\.md$|^cross-cutting/extensibility/README\.md$|^cross-cutting/skills/registry\.yaml$|^olympus-contracts/olympus_contracts/enums\.py$|^presentation/|^scripts/check_doc_sync\.py$|^tests/test_check_doc_sync\.py$`
   - `step_registry_changed` ← `^olympus-api/src/services/step_mapping/|^dashboard/src/.+step|^scripts/verify_step_registry\.py$|^specifications/phase-5/assembly-line-contracts/`
   - `sql_schema_changed` ← `^db/alembic/|^olympus-api/src/|^scripts/verify_sql_schema\.py$|^tests/test_verify_sql_schema\.py$`
   - `line_contracts_changed` ← `^specifications/phase-5/assembly-line-contracts/|^dashboard/scripts/parse-line-contracts\.mjs$|^dashboard/package-lock\.json$`
   - `api/worker/agent_runtime/mcp/temporal/contracts_pkg/dashboard/helm/terraform/argocd_changed`
     ← their `^<dir>/` prefixes (:182-191).
8. **SHARED_PYTHON amplification** (:197-204): if any of
   `^olympus-contracts/|^tests/|^scripts/|^pyproject\.toml$|^requirements.*\.txt$|^\.pre-commit-config\.yaml$`
   changed, force `api/worker/agent_runtime/mcp/temporal_changed = true` (shared
   surface consumed transitively).
9. **python_any_changed** (:206-212): OR of api/worker/agent_runtime/mcp/temporal/contracts_pkg.
10. **stack_spin_changed** (:219): runtime pkgs OR `docker-compose.ya?ml`,
    `db/`, `scripts/seed_*.py`, `scripts/seed_all.py`,
    `scripts/seed_service_tokens.py`, `scripts/demo_smoke.py`, `Makefile`,
    `.+/Dockerfile`.
11. **live_e2e_changed** (:229-244): `LIVE_E2E_DIRECT` glob (live suite,
    dashboard/src, runtime pkgs, compose, db, seed scripts) OR the "big enough"
    heuristic — `CHANGED_COUNT >= 40` files OR `CHURN >= 1500` lines
    (`git diff --numstat` added+deleted). GOTCHA: a sweeping refactor missing the
    globs still triggers live-e2e via the size heuristic.
12. **devsecops_baseline_changed** (:253): the baseline template tree,
    code-synthesis fixtures, `devsecops_contract.py`,
    `activities/devsecops_validation.py`, `activities/profile_devsecops.py`,
    `scripts/devsecops_fresh_clone_smoke.py`, its test, or
    `profiles/.+/(profile|technology)\.yaml`.
13. Writes all 24 outputs to `$GITHUB_OUTPUT` and `cat`s them (:255-282).

### 1.3 Always-on cheap jobs
- **`branch-naming`** (:284-298): only `if: github.event_name == 'pull_request'`.
  Regex `^(phase-[0-9]+[a-z]?|feat|fix|refactor|docs|ci|chore|dependabot|integration)/`
  against `github.head_ref`; `::error::` + exit 1 on mismatch (:292-297). No
  `needs:` — independent of preflight.
- **`secrets-scan`** (:1120-1175): always runs (no `if`, no `needs`). Checkout
  `fetch-depth: 0`. Caches the gitleaks 8.21.2 binary (key
  `gitleaks-8.21.2-linux-x64`, path `~/.local/bin/gitleaks`, :1131-1137).
  Install-if-cache-miss downloads from the gitleaks GH release (:1138-1147).
  **Two modes**: PR fast-lane `gitleaks protect --log-opts="$BASE..$HEAD"`
  (:1153-1161); non-PR full-history `gitleaks detect` (:1163-1167). Both use
  `--config=.gitleaks.toml --redact --report-format=sarif`. SARIF uploaded
  always (:1169-1175).

### 1.4 Anti-drift / consistency jobs (each `needs: preflight`, gated)
Each installs Python 3.13 (`setup-python@v6`, `cache: pip`) unless noted:

| Job | Gate `if:` | Command(s) | Guards |
|---|---|---|---|
| `contracts` (:300-382) | `contracts_changed` | Redocly lint+bundle of `specifications/api/openapi.yaml` (only if present); `check-jsonschema --check-metaschema` per `schemas/**/*.schema.json`; inline Python validates `schemas/samples/*.json` via `Draft202012Validator`+`RefResolver` | OpenAPI + JSON-Schema validity + samples valid instances |
| `skill-catalog` (:384-401) | `skill_catalog_changed` | `pip install pyyaml`; `python3 scripts/validate_skill_registry.py` | skill registry ↔ disk ↔ line-README consistency (§4.2) |
| `doc-sync` (:403-429) | `doc_sync_changed` | `pip install pyyaml pytest`; `python3 scripts/check_doc_sync.py`; `pytest tests/test_check_doc_sync.py -v` | doc/reality count drift (§4.1) |
| `agency-objectives` (:431-455) | `objectives_changed` | `pip install pyyaml jsonschema pytest`; `python3 scripts/validate_objectives.py`; `pytest tests/test_validate_objectives.py -v` | objectives.yaml schema + metric/line/skill references (§4.5) |
| `step-registry-consistency` (:457-474) | `step_registry_changed` | `pip install -e olympus-contracts`; `python3 scripts/verify_step_registry.py` | frontend `stepRegistry.ts` ↔ backend `step_mapping.py` (§4.4) |
| `sql-schema-drift` (:476-496) | `sql_schema_changed` | `pip install pytest`; `python3 scripts/verify_sql_schema.py`; `pytest tests/test_verify_sql_schema.py -v` | raw SQL in API ↔ alembic schema (§4.3) |
| `line-contracts-consistency` (:498-517) | `line_contracts_changed` | Node 22 + `npm ci` in dashboard; `node dashboard/scripts/parse-line-contracts.mjs --validate-only` | line-contract step sequences |

### 1.5 Integration / portability / smoke jobs
- **`profile-portability`** (:519-551): `if:` api OR temporal OR contracts_pkg
  changed. Installs contracts + temporal + `olympus-api[dev]` (editable).
  `pytest tests/test_generic_profile_portability.py -v --no-cov` with
  `AGENT_RUNTIME_MODE=mock APP_ENV=test`. Capstone for P4-S6.G5.6.
- **`stack-spin-smoke`** (:562-658): `if: stack_spin_changed`. Boots the CORE
  stack via `docker compose ... up -d --build --scale olympus-agent-runtime=1`
  of postgres, db-migrate, temporal-server, temporal-namespace-init, redis,
  olympus-api, olympus-temporal-worker, olympus-agent-runtime (:638-641). Env:
  DATABASE_* → localhost:5432 (olympus/olympus_dev/olympus), `API_URL=http://localhost:8000`,
  `JWT_SECRET=olympus-ci-smoke-secret`, `AGENT_RUNTIME_MODE=mock`,
  `DEMO_PORTFOLIO_NAME="Test Portfolio 4"`, `READY_RETRIES=90`,
  `READY_INTERVAL=4` (:567-585). Steps: install host slice
  (`olympus-contracts` editable + python-jose/pydantic/asyncpg/PyYAML — NOT the
  full api pkg, :594-610) → `seed_service_tokens.py` → **Docker Hub login**
  (only `if: env.DOCKERHUB_TOKEN != ''`, :623-628 — GOTCHA: token mirrored to
  job `env` because `secrets` context is unreliable in step `if:`) → build+start
  → `make demo-wait` → `seed_all.py --reset` → `demo_smoke.py` → dump logs on
  failure → `docker compose down -v` always (:643-658).
- **`live-e2e`** (:675-860): `if: live_e2e_changed`, `timeout-minutes: 30`.
  Spins the FULL primary `olympus` stack under REAL auth (`DEV_AUTH_BYPASS=false`,
  :695) + `AGENT_RUNTIME_MODE=mock`. `JWT_SECRET=olympus-dev-secret` MUST match
  minted tokens. Stack-neutral `OLYMPUS_E2E_*` env points suite at
  dashboard:3000 / API:8000 / pg:5432, admin `admin`/`olympus-ci-e2e-admin-pw`
  (:681-715). Node 22 (:724-728). Host deps add `bcrypt` (seed_admin_user hashes)
  vs stack-spin (:730-739). Sequence: mint tokens → Docker Hub login (gated) →
  `npm ci` + `npx playwright install --with-deps chromium` (runs on HOST, never
  containerized — GOTCHA: dashboard `npm ci` fails silently exit-2 in BuildKit on
  the GHE runner, :751-763) → `docker compose -p olympus build` the 3 Python
  images → `up -d --scale olympus-agent-runtime=1` backend only → `make demo-wait`
  → `seed_all.py --reset` → `seed_phase5_testdata.py` (deep gate/bundle/score
  data) → `seed_admin_user.py --reset-password` → launch Vite dev server
  `nohup npm run dev` on host (:805-818) with `VITE_API_BASE_URL=http://localhost:8000`
  → poll `:3000` for 200 (60×4s) → run 6 journey specs via
  `CI=true npx playwright test --config=playwright.config.live.ts` (01-rbac-gate-review,
  03-cato-evidence, 14-gate-write-flows, 16-compliance-cato, 27-write-flow-terminals,
  29-build-line-action-and-gates, :838-844) → upload report + dump logs on failure →
  `docker compose -p olympus down -v` always.
- **`devsecops-baseline-smoke`** (:1497-1551): `if: devsecops_baseline_changed
  OR push OR schedule`. Installs contracts+temporal editable + ruff/pytest, plus
  gitleaks 8.21.2 and Trivy v0.71.2 binaries (driven against the *fixture* repo,
  not this repo). `python scripts/devsecops_fresh_clone_smoke.py --profile faa`
  then `pytest tests/test_devsecops_fresh_clone_smoke.py -q`. Blocking, no
  advisory window.

### 1.6 Test-matrix jobs (see §2 for coverage floors)
- **`python`** (:873-1005): `if: python_any_changed`, `strategy.fail-fast: false`.
  Matrix (:892-917): 5 legs — olympus-api (cov=src, py3.13, flag api_changed,
  runner **ubuntu-latest-large**), temporal (cov=olympus_workflows, py3.12, flag
  temporal_changed, runner **ubuntu-latest-large**), olympus-agent-runtime
  (cov=src, py3.13, ubuntu-latest), olympus-worker (cov=src, py3.13,
  ubuntu-latest), mcp-server (cov=olympus_mcp, py3.12, ubuntu-latest).
  Per-leg **double gate**: step `gate` maps `matrix.flag` → the preflight output
  and sets `skip` (:924-935); all subsequent steps guarded on
  `steps.gate.outputs.skip == 'false'`. GOTCHA: temporal/api use
  `ubuntu-latest-large` (4 dedicated cores) because temporal's suite spawns a
  Rust WorkflowEnvironment sidecar per xdist worker; large runners do NOT support
  service containers (see python-integration).
  Install (:943-963): editable contracts + temporal always; for temporal leg ALSO
  editable olympus-worker + olympus-api with `--ignore-requires-python` (they pin
  py>=3.13, leg is 3.12); then `pip install -e "./${package}[dev]"` + ruff.
  Lint: `ruff check .` (:965-967). Test (:969-998) with
  `AGENT_RUNTIME_MODE=mock APP_ENV=test`: temporal leg adds `XDIST_FLAGS="-n ${{ vars.TEMPORAL_XDIST_WORKERS || '4' }}"`;
  runs `pytest $XDIST_FLAGS --cov=${cov_source} --cov-report=term-missing
  --cov-report=xml:coverage.xml --tb=short -q`. Coverage XML uploaded always.
- **`python-integration`** (:1007-1073): `if: api_changed`. **Must stay on
  ubuntu-latest** (declares a `postgres:16` `services:` container; large ARC
  scale set has no Docker-in-DinD). Service uses `services.credentials` for
  Docker Hub auth (the ONLY hook that authenticates a service-image pull — pulled
  before any step runs, :1035-1037). pg health-checked (:1044-1048). Installs
  `olympus-api[dev,integration]`. Lints `tests/integration/`. Runs
  `pytest tests/integration/ -v --no-cov --tb=short` with
  `OLYMPUS_INTEGRATION_DATABASE_URL=postgresql://olympus:olympus_dev@localhost:5432/olympus`,
  mock runtime, `APP_ENV=test`.
- **`frontend`** (:1075-1112): `if: dashboard_changed`. **Node 20** (GOTCHA:
  every other Node job uses 22; this leg alone pins 20, :1088). `npm ci` →
  `npm run lint --if-present` → `npm run typecheck --if-present` → `npm run build
  --if-present` → `npx vitest run --coverage` (:1105). Coverage dir uploaded.

### 1.7 Nightly/main-only heavy scanners
- **`codeql`** (:1184-1208): `if: push OR schedule`. `security-events: write`.
  Matrix `language: [python, javascript]`, `queries: security-and-quality`.
  Blocking (advisory window expired, P6-S8.7).
- **`trivy-fs`** (:1215-1276): `if: push OR schedule`. Caches trivy 0.59.1;
  install step `continue-on-error` sets `installed` output; if unreachable →
  `::warning::` + skip (soft). Scan `trivy fs . --severity CRITICAL,HIGH
  --exit-code 1` — **blocking** on findings (:1260-1268).
- **`sbom`** (:1287-1341): `if: push OR schedule`, `continue-on-error: true`
  (job-level advisory). `trivy fs . --format cyclonedx` → SBOM artifact
  (90-day retention); on tag ref, attaches to GH release.
- **`trivy-image`** (:1350-1385): `if: push OR schedule`,
  `continue-on-error: true`. Matrix service [olympus-api, olympus-worker,
  olympus-agent-runtime, mcp-server]. `docker build -f <svc>/Dockerfile .` then
  `aquasecurity/trivy-action@0.24.0` with `exit-code: "0"` (advisory) severity
  CRITICAL,HIGH → SARIF artifacts.
- **`helm-lint`** (:1391-1433): `if: helm_changed OR push OR schedule`. Matrix
  8 charts (olympus-api, olympus-worker, olympus-agent-runtime,
  olympus-mcp-server, olympus-dashboard, db-migrate, ingress, olympus-umbrella).
  `helm lint` + `helm template` (>/dev/null); umbrella also `dependency update`
  and renders values-{dev,staging,prod}.
- **`terraform-validate`** (:1438-1481): `if: terraform_changed OR push OR
  schedule`. Terraform 1.7.5. Matrix = 7 modules (vpc, eks, rds, redis, ecr, s3,
  secrets) + 5 environments (dev, staging, prod, dev-csn-fargate,
  olympus-demo-fargate). Per path: `fmt -check -recursive`, `init -backend=false`,
  `validate`. GOTCHA: gfi-mirror/dms/dms-endpoint modules intentionally omitted —
  their sources were never committed to main (:1454-1460).
- **`kubeval-argocd`** (:1553-1571): `if: argocd_changed OR push OR schedule`.
  `yamllint` (relaxed, line-length/comments/truthy/indentation disabled) over
  `infra/argocd/`.

GOTCHA: there is **no `build-push` job** — it's commented out (:1573-1585,
disabled until the deploy pipeline is wired end-to-end). Yet
`.github/branch-protection.yml` lists a required `build` context (§9) that no job
produces; that required check would never report unless renamed. Ordering trap.

---

## 2. Test suites & coverage floors (VERIFIED against live config)

Each Python package's floor is `--cov-fail-under=N` inside `[tool.pytest.ini_options] addopts`;
the CI `python` matrix (§1.6) runs `pytest` (which reads addopts) so the floor is
enforced by the local config, not the workflow.

| Package | pytest addopts location | `--cov=` | Floor | requires-python |
|---|---|---|---|---|
| olympus-api | `olympus-api/pyproject.toml:89` | `src` | **87** | `>=3.13` (:9) |
| olympus-worker | `olympus-worker/pyproject.toml:56` | `src` | **90** | `>=3.13` (:9) |
| olympus-agent-runtime | `olympus-agent-runtime/pyproject.toml:69` | `src` | **90** | `>=3.13` (:9) |
| mcp-server | `mcp-server/pyproject.toml:41` | `olympus_mcp` | **90** | `>=3.11` (:9) |
| temporal | `temporal/pyproject.toml:123` | `olympus_workflows` | **80** | `>=3.11` (:9) |
| olympus-contracts | `olympus-contracts/pyproject.toml` | (no `--cov` in addopts) | — | `>=3.11` (:9) |

- olympus-api addopts (verbatim): `--cov=src --cov-report=term-missing
  --cov-report=html:htmlcov --cov-fail-under=87 --ignore=tests/integration`
  (`olympus-api/pyproject.toml:89`). GOTCHA: `--ignore=tests/integration` keeps
  the real-Postgres suite OUT of the default run — that suite is invoked
  separately by the `python-integration` CI job / `pytest tests/integration/`.
- **GOTCHA — temporal floor is 80, not 87.** The repo `CLAUDE.md` / prior spec
  say "temporal 87"; the LIVE config is `--cov-fail-under=80`
  (`temporal/pyproject.toml:123`). Its comment (:118-122) documents that
  `olympus_workflows` genuinely sits at ~80.7% (WorkflowEnvironment-gated
  wave_rationalization / validation Tier-1 / G-V3 branches are integration-only
  and uncovered), so 87 is deferred. **Rebuild MUST use 80.**
- temporal `[tool.coverage.run]` (:125): `source=["olympus_workflows"]`,
  `omit=["olympus_workflows/__init__.py","olympus_workflows/*/__init__.py"]`.
  `[tool.coverage.report]` excludes `pragma: no cover`, `if __name__ == .__main__.`,
  `if TYPE_CHECKING:` (:128).
- mcp-server: `asyncio_mode = "auto"`, `testpaths=["tests"]`
  (`mcp-server/pyproject.toml`).

### 2.1 Dashboard (Vitest) coverage floors — `dashboard/vitest.config.ts`
- Provider `v8`, reporters `text`/`text-summary`/`html`, dir `./coverage` (:44-47).
- `include: ["src/**/*.{ts,tsx}"]`; `exclude`: `src/test/**`, `src/main.tsx`,
  `src/vite-env.d.ts`, `src/**/*.test.{ts,tsx}`, `src/data/**` (:48-55).
- **Thresholds (VERIFIED)** (:67-72): `lines: 81`, `branches: 70`,
  `functions: 76`, `statements: 78`.
- **GOTCHA — statements floor is 78, not 79.** Prior spec / `CLAUDE.md` say
  "81/70/76/79"; the LIVE config is 78 (P5-S26 dropped 79→78 to match main-branch
  drift, comment :62-66). **Rebuild MUST use 78.**
- `testTimeout: 15000` (:16 — axe sweeps run 4-8s on shared runners).
- `exclude` (test-file discovery, :20-38): node_modules, dist, `tests-e2e/**`,
  `tests-e2e-live/**`, `playwright.config.*`, `worktrees/**` (Playwright specs
  crash under vitest; worktrees would double-count).
- Dashboard scripts (`dashboard/package.json`): `test` = `vitest run`,
  `test:coverage` = `vitest run --coverage`, `test:e2e` = `playwright test`,
  `test:e2e:live` = `playwright test --config=playwright.config.live.ts`,
  `build` = `tsc -b && vite build`, `lint` = `eslint .`.
- **GOTCHA — coverage floors ratchet only up (DECISION-017).** Lowering a floor
  to unblock a PR is prohibited; CI fails below floor.

---

## 3. Lint & type config

### 3.1 Ruff (Python) — per-package, no root config
No repo-root `pyproject.toml`/`ruff.toml`. Each package declares its own
`[tool.ruff]`; all share `line-length = 100` and lint `select = ["E","F","I","W"]`:

| Package | `[tool.ruff]` line | target-version |
|---|---|---|
| olympus-api | :120 | `py313` |
| olympus-worker | :66 | `py313` |
| olympus-agent-runtime | :59 | `py313` |
| temporal | :133 | `py311` |
| olympus-contracts | :17 | `py311` |
| **mcp-server** | *(none)* | ruff defaults |

- **GOTCHA — mcp-server has NO `[tool.ruff]`.** But no `python` matrix leg runs
  `ruff check .` for mcp-server anyway? — it does (`ruff check .` runs for every
  leg, :965-967); with no config it uses ruff defaults (E/F only,
  line-length 88). Rebuild: leave mcp-server ruff-config-less to preserve
  identical lint behavior.
- CI lints: `python` matrix `ruff check .` (:967); `python-integration`
  `ruff check tests/integration/` (:1066).

### 3.2 Mypy (Python) — only two packages configured
`[tool.mypy]` present ONLY in `olympus-api` (:91) and `temporal` (:1 match).
Not in worker / agent-runtime / mcp-server / contracts.
- olympus-api mypy: `mypy_path = "../olympus-contracts"` (so editable
  `olympus_contracts` resolves against its `py.typed`, :99); override
  `module = "src.services.bundle"` disables `arg-type`/`return-value` (inherited
  RowMapping↔dict debt, :103-119). GOTCHA: mypy is NOT run as a dedicated CI job
  — it is a per-subtree DoD gate developers run locally; the config exists to
  keep those local runs green.

### 3.3 ESLint (dashboard) — `dashboard/eslint.config.js` (flat config)
- Extends `js.configs.recommended` + `tseslint.configs.recommended`; files
  `**/*.{ts,tsx}`; ignores `dist`.
- Plugins: `react-hooks` (recommended rules), `react-refresh`
  (`only-export-components: warn, {allowConstantExport:true}`).
- `ecmaVersion: 2020`, `globals.browser`.
- Invoked via `npm run lint` (`eslint .`) in the `frontend` job.

### 3.4 TypeScript
`npm run typecheck --if-present` + `npm run build` (`tsc -b && vite build`) in
the `frontend` job.

---

## 4. Anti-drift tests (what each guards)

### 4.1 doc-sync — `scripts/check_doc_sync.py` (438 lines)
**Guards:** prose docs + the presentation microsite hard-code framework counts
(skills, gates, lines, dispositions, concerns, extension points) that silently
go stale ("~65 → 137 → 167 skills" history, :5-10). Fails (exit 1) or `--fix`
rewrites when a *managed claim* diverges from source of truth.
- **Metric derivers** (each returns int, :70-140):
  - `skills` ← `len(registry["skills"])` from `cross-cutting/skills/registry.yaml` (:70-80).
  - `gates` / `assembly_lines` / `dispositions` ← `_count_enum_members` textually
    parses the StrEnum body in `olympus-contracts/olympus_contracts/enums.py`
    (regex, NOT import, so the CI job needs only PyYAML, :83-110).
  - `concerns` ← count of `cross-cutting/` dirs (skip `templates`, :124-132).
  - `assembly_lines` (dir variant `_count_assembly_line_dirs`) skips
    `overview`/`templates` (:113-121).
  - `extension_points` ← hardcoded constant `6` (:140, framework concept, not a
    file count).
- **Managed claims** (`MANAGED_CLAIMS`, :204+): each is `(path, regex-with-one-
  capture-group, metric)` enrolled explicitly — README current-state skill line,
  CLAUDE.md, terminology.md, extensibility README, and multiple `presentation/*.html`
  hero-stat / glossary sites. GOTCHA: ONLY enrolled sites are checked — historical
  numbers ("49 skills" ATLAS lineage) must NOT be enrolled (:23-27). Each pattern
  MUST have exactly one capturing group around the integer.
- CI also runs the checker's unit test `tests/test_check_doc_sync.py`
  (`ci.yml:428-429`).
- `make check-docs` / `make fix-docs` invoke the same script (`Makefile`).

### 4.2 skill-catalog — `scripts/validate_skill_registry.py` (380 lines)
**Guards** (invariants, :3-33) three-way drift between `registry.yaml`, SKILL.md
files on disk, and line READMEs:
1. Every registry skill id has a SKILL.md at `cross-cutting/skills/<id>/SKILL.md`
   OR `profiles/<profile>/skills/<id>/SKILL.md`.
2. Every on-disk SKILL.md dir has a matching registry entry.
3. Every skill has a `depends_on` field present (may be empty).
4. Every `depends_on` target is a real skill id.
5. Every dispatch alias resolves to a real skill id.
6. No dispatch alias name also exists as a SKILL.md dir (ambiguous dispatch).
7. Naming: skill ids must not start with `plan-`/`step-`/`execute-`
   (`RESERVED_PREFIXES`, :64).
8. Every skill id in an assembly-line README `## Skills` table exists as a
   registered id.
8b. Reverse: every registered skill is listed in its consuming line's README
   `## Skills` table (or exempt: `line == "Cross-Cutting"` / documented variant).
   Hard gate since P5-S30.10.
9. `olympus-worker/config/agents.yaml` stays a single generic catch-all (every
   agent has empty `skill_ids`) — prevents per-skill agent-role drift.
- Line-README slugs scanned (:68-81) include the P8-additive
  `reverse-engineering` (12th line). Exit 0 with summary / exit 1 with structured
  violations.

### 4.3 sql-drift — `scripts/verify_sql_schema.py` (1492 lines)
**Guards:** raw SQL string literals in `olympus-api/src/` must agree with the
alembic schema. **Static analyzer, no DB** (:1-46):
- AST-replays `db/alembic/versions/*.py` migrations — `op.create_table`,
  `add_column`, `drop_column`, `rename_table`, `alter_column`, plus raw
  `op.execute("ALTER TABLE ... ADD/DROP COLUMN")` — into a
  `{table: {column: type_category}}` map (:5-11).
- AST-walks API source for every `sqlalchemy.text("…")` literal (handles adjacent
  / `+` concat + f-string interpolation), splits paren-aware into clauses, and
  checks: SELECT target/WHERE/ORDER BY columns exist; INSERT columns exist;
  UPDATE — same bind param assigned to two columns of DIFFERENT type categories
  (e.g. Date vs DateTime = the `actual_start`/`updated_at` bug) is flagged; every
  referenced table exists (:14-23).
- `TYPE_CATEGORY` maps SQLAlchemy type ctor names → coarse families (:72+).
- Scope limits (:28-43): only `text()` SQL (ORM `select()`/`Query` out of scope);
  f-string placeholders → `__PLACEHOLDER__`; alias tracking in joins;
  case-insensitive column compare; JSONB `col->'foo'` stripped to `col`.
- Exit 1 on any violation with file:line:statement:problem. CI also runs
  `tests/test_verify_sql_schema.py`.

### 4.4 skill-line ↔ step-registry — `scripts/verify_step_registry.py` (252 lines)
**Guards:** the WorkflowStepper step registry is identical across frontend +
backend. Sources of truth (:3-8): `dashboard/src/components/WorkflowStepper/stepRegistry.ts`
and `olympus-api/src/services/step_mapping.py` (`UI_STEP_IDS`).
- Fails (non-zero) when (:9-18): a line has different step ids or count between
  the two; a step id repeats within a line EXCEPT Disposition Execution where
  `data-migration`/`legacy-decommission` legitimately recur across
  Replace/Replatform branches (accepted only if the TS entries carry distinct
  `disposition` values); a referenced gate id is not a known `GateType`.
- `LINES` list (:26-42) enumerates 12 lines mapping display-name → TS const →
  `AssemblyLine` enum member (Discovery … Governance).
- TS parser (`_read_ts_blocks`, :45-86) resolves the
  `DISPOSITION_EXECUTION_STEPS` spread-operator composition from `_DE_*` helper
  consts (:88+). Reads `stepRegistry.ts` textually (regex on `const NAME_STEPS:
  StepRegistryEntry[] = [...]`).
- (The `skill-line` valid-set concept — every registry skill's `line` is a valid
  line name — is enforced by `validate_skill_registry.py` §4.2 invariants 8/8b;
  the valid-set includes `Reverse Engineering`.)

### 4.5 agency-objectives — `scripts/validate_objectives.py` (512 lines)
**Guards** (invariants, :6-27): profile objectives structural drift:
1. Every `profiles/<id>/objectives.yaml` schema-validates against
   `schemas/profiles/objectives.schema.json`.
2. Every objective id is namespaced `<profile-id>.*`.
3. Every metric ref (primary/secondary, top + sub-objective) resolves in
   `cross-cutting/metrics/registry.yaml` (missing registry tolerated; when
   present, all must resolve).
4. Every `contributes_from.lines` id resolves under `assembly-lines/`.
5. Every `contributes_from.skills` id resolves in the skill registry or a
   profile-scoped skill dir.
6. Every `narrative_template` placeholder is drawable from the bindable
   vocabulary.
7. `contributes_to:` reverse tags reference an existing objective id (warning in
   AO-0, `--strict` promotes to failure). CI also runs
   `tests/test_validate_objectives.py`.

### 4.6 no-hardcoded-step-list — `olympus-contracts/tests/test_no_hardcoded_step_lists.py`
**Guards** (pytest, runs inside the `olympus-contracts` suite / temporal-leg
transitively): prevent literal step-id lists creeping into source, which go stale
on a contract rename (the 2026-05-05 gate-review bug where stale `_DISCOVERY_ORDER`
keys dropped 4 of 7 cards, :5-8).
- Scans `olympus-api/src`, `olympus-worker/src`, `temporal/olympus_workflows`
  (`SCAN_DIRS`, :37-41). Skips `.venv`, `__pycache__`, `build`, `.agents`,
  `.codex`, `tests`, `registries/defaults/` (:44-52).
- Step ids come from `olympus_contracts.list_lines()` (`_collect_step_ids`, :71-77).
- **Cluster detection** (:104-171): a violation is `CLUSTER_THRESHOLD = 5` step-id
  string literals within a `CLUSTER_WINDOW = 10`-line sliding window. Individual
  per-step references (`self._set_step("catalog")` … dozens of lines later
  `"synthesis"`) pass; a hand-written enumerating dict fails.
- Waivers: `# allow: step-list-literal — <reason>` on same/preceding line
  (`ALLOWLIST_RE`, non-empty reason, :56-101); whole-file
  `# allow-file: step-list-literal — <reason>` (`FILE_ALLOWLIST_RE`, :65-68).
- GOTCHA: this test lives under `olympus-contracts/tests/`, so its `--cov` gate is
  contracts', and it imports `olympus_contracts` — it runs whenever
  contracts/api/worker/temporal legs run (SHARED_PYTHON amplifies contracts→all).

### 4.7 CLIENT-BLIND guards — the DoD gate + three enforcement surfaces
The CLIENT-BLIND constraint (client/agency/domain tokens live ONLY in `profiles/`,
never in platform-layer "Zone-B" executable code) is enforced by **THREE distinct
guards** driven by a bash DoD-gate runner. There is **NO `scripts/check_client_blind.py`**
(the runner is `.sh`, and it re-uses pytest guards rather than a standalone `.py`
scanner). Do not conflate these three surfaces — they cover mutually-exclusive token
sets and file scopes.

#### 4.7.1 `scripts/check_client_blind.sh` — the Phase-7 CLIENT-BLIND DoD-gate runner
(`scripts/check_client_blind.sh`.) A **thin runner** over two pytest guards; it does
NOT re-implement scanning.
- **GOTCHA (documented in the header, :7-14):** an earlier bash draft re-derived the
  comment/docstring stripper and immediately mis-flagged a docstring line, a wrapped-
  string continuation, and a test file — the exact cases the Python scanner already
  handles. The lesson is baked in: **reuse the proven Python scanner, never fork it.**
- `set -euo pipefail` (:26). `REPO_ROOT` = `dirname $BASH_SOURCE/..` then `cd` there (:28-29).
- **Python resolution order** (:34-37): caller `$PYTHON` override → active `$VIRTUAL_ENV/bin/python`
  → repo `$REPO_ROOT/.venv/bin/python` → bare `python3` (CI's own env). First match wins.
- **Env defaults** (:41-42): `AGENT_RUNTIME_MODE=${AGENT_RUNTIME_MODE:-mock}`,
  `APP_ENV=${APP_ENV:-test}` — olympus-api's conftest errors on import without them
  (DECISION-018 MockAgentRuntime).
- **Invocation** (:48-52): `cd olympus-api` then
  `"$PYTHON" -m pytest tests/test_zone_b_faa_leakage_guard.py tests/test_zone_b_client_token_guard.py -q -o addopts="" -p no:cacheprovider`.
  GOTCHA: `-o addopts=""` **disables the pyproject `addopts`** (coverage floor + flags)
  so the gate runs the two guard files in isolation; `-p no:cacheprovider` avoids
  writing a `.pytest_cache`.
- **Exit** (:20-21 header): `0` = client-blind holds; non-zero = a client token leaked
  into Zone-B code. On success prints `CLIENT-BLIND GUARD: PASS …` (:55-56).

#### 4.7.2 `olympus-api/tests/test_zone_b_faa_leakage_guard.py` — the FAA|faa surface (P6-S10.6)
(`olympus-api/tests/test_zone_b_faa_leakage_guard.py`.) Owns the `FAA|faa` token surface
with a curated KEEP allowlist + dead-entry ratchet. This is the shared-scanner OWNER;
the sibling (§4.7.3) imports its `_repo_root` and `_scan_zone_b_code`.

- **Zone-B roots** (`ZONE_B_ROOTS`, :47-54): `dashboard/src`, `olympus-api/src`,
  `olympus-worker`, `temporal`, `mcp-server`, `olympus-cli`. Repo-root-relative.
- **Source suffixes** (`SOURCE_SUFFIXES`, :56): `.ts`, `.tsx`, `.py`.
- **Path-fragment exclusions** (`EXCLUDE_PATH_RE`, :59): regex `test|spec|fixture|__mocks__`
  — any rel-path containing one of these substrings is skipped.
- **Token regex** (`FAA_RE`, :61): `FAA|faa`.
- **Whole-file exclusions** (`ZONE_D_FILES`, :64-69): frozenset of two Zone-D
  recording-only demo files — `dashboard/src/pages/OneStopShopDemo/OneStopShopDemo.tsx`
  and `.../OneStopShopDemo/mockData.ts` (design §4.1 — "leave").
- **`ALLOWLISTED`** (`tuple[tuple[str,str],...]`, :80-125): each entry is
  `(repo-relative-path, code-substring)`. An occurrence is allowed **iff** its file
  matches the path AND the (comment-stripped) line contains the substring. The exact
  entries (all legitimate code-level KEEPS from the P6-S10.2 triage table):
  - `("olympus-api/src/services/skill_bootstrap.py", 'return "faa"')` — default profile id.
  - `("olympus-api/src/routers/profiles.py", 'or "faa"')` and
    `("olympus-api/src/routers/profiles.py", "or 'faa' for demo portfolios")` — demo default.
  - `("olympus-api/src/services/profile_loader.py", "def faa_additions(self)")` — deprecated
    compat-alias property (design §6 OQ-2).
  - `("temporal/olympus_workflows/activities/profile_devsecops.py", 'repo_root / "profiles" / "faa"')`
    and `(".../activities/context_priors.py", 'repo_root / "profiles" / "faa"')` — local-dev
    fallback paths (used only when `OLYMPUS_PROFILE_ROOT` unset).
  - `("olympus-api/src/services/profile_loader.py", 'body.get("faa_additions")')`,
    `("temporal/olympus_workflows/registries/worker_bootstrap.py", 'body.get("faa_additions")')`,
    `("temporal/olympus_workflows/registries/profile_overrides.py", '"faa_additions": additions')`
    — compat-shim reads of the legacy YAML/dict key for one release.
  - Six `skill_registry.py` entries: `'"faa-code-standards"'`, `'"faa-style-greenfield"'`,
    `'"faa-style-brownfield"'`, `"Enforce FAA-specific coding standards"`,
    `"Apply FAA branding, styling"`, `"Apply FAA branding updates"` — FALLBACK descriptions
    keyed by FAA-profile-only skill ids, dormant under any other active profile.
- **`_repo_root()`** (:128-133): walks `Path(__file__).resolve()` + parents; returns the
  first dir containing `cross-cutting/skills/`; else raises `RuntimeError`.
- **`_strip_comments(line, suffix)`** (:136-178) — best-effort (NOT a full tokenizer),
  conservative (keeps text when unsure so a real leak is never hidden):
  - `.py` branch (:152-166): pure `#`-comment line → `""`; **any** line containing `"""`
    or `'''` → `""` (FAA inside a docstring is a KEEP); inline `#` → keep text before the
    first `#`; else keep the line.
  - TS/TSX branch (:169-178): line starting `//` → `""`; line starting `*`/`/*`/`/**` → `""`;
    line ending `*/` when it also has `/*` or starts with `*` → `""`; inline `//` → keep text
    before it; else keep.
- **`_scan_zone_b_code(root, token_re=FAA_RE)`** (:181-252) — the SHARED scanner. Returns
  `[(rel_path, lineno, code)]`. Per Zone-B root: skip non-dirs; `rglob("*")`; skip non-files;
  skip suffix not in `SOURCE_SUFFIXES`; skip if `EXCLUDE_PATH_RE` matches rel; skip if rel in
  `ZONE_D_FILES`; skip if rel contains `node_modules`/`/dist/`/`/htmlcov/` (:210); read text
  (skip on OSError/UnicodeDecodeError). Then per-line with **two cross-line state flags**:
  - **Python triple-quote tracking** (:224-236): `in_py_docstring` — while inside, `continue`
    until a line with `"""` or `'''` closes it; a line whose triple-quote **count == 1**
    (opens but doesn't close on one line) sets `in_py_docstring=True` and `continue`s.
    GOTCHA: a single-line triple-quoted string (open+close, count == 2) is NOT treated as a
    span — it falls through to `_strip_comments` which drops it anyway.
  - **TS block-comment tracking** (:239-248): `in_block_comment` — while inside, if `*/`
    present, clear the flag and keep the text after `*/`; else `continue`. A line with `/*`
    and no `*/` sets the flag and keeps text before `/*`.
  - After stripping (`code = _strip_comments(raw, suffix)`, :249), if `token_re.search(code)`
    append `(rel, lineno, code.strip())`.
  - **GOTCHA:** `token_re` defaults to `FAA_RE` but is parametrized so the sibling guard
    reuses this exact multi-line-aware scanner with a different pattern (ONE implementation,
    two token surfaces).
- **`_is_allowed(rel_path, code)`** (:255-259): true iff some `ALLOWLISTED` `(path, substring)`
  matches `rel_path == path and substring in code`.
- **`test_no_unallowlisted_faa_in_zone_b_code()`** (:262-290): scan; `offenders` = hits not
  `_is_allowed`; `assert not offenders` with a remediation message ("fix code to read the
  ACTIVE profile; do NOT add leakage to the allowlist") listing each `rel:lineno: code`.
- **`test_allowlist_has_no_dead_entries()`** (:293-316): builds `by_path` from hits; for each
  `ALLOWLISTED (path, substring)`, if no scanned line for that path contains the substring →
  `dead`. `assert not dead` — keeps the allowlist honest (a moved/reworded KEEP is flagged
  for cleanup so it can't silently mask a future matching line).

#### 4.7.3 `olympus-api/tests/test_zone_b_client_token_guard.py` — every OTHER client token
(`olympus-api/tests/test_zone_b_client_token_guard.py`.) Owns every non-FAA agency/client
proper noun the FAA-only regex structurally cannot see. **Imports and REUSES** the FAA
guard's `_repo_root` and `_scan_zone_b_code` (:40) — one scanner, two token surfaces, no
parallel re-implementation (the header repeats the same anti-fork lesson, :10-16).
- **`CLIENT_TOKEN_RE`** (:56-62, `re.IGNORECASE`): alternation with **per-token boundary
  policy** (design rationale :18-24, :47-55):
  - `tyrion|veterans|iacra|medxpress` — distinctive proper nouns, match ANYWHERE (a
    word-boundary would skip the snake_case `tyrion_requirements` since `_` is a word char —
    the exact leak P7-S16.3 removed).
  - `(?:^|[^a-z])vba(?:[^a-z]|$)`, `(?:^|[^a-z])rms(?:[^a-z]|$)`, `(?:^|[^a-z])dms(?:[^a-z]|$)`
    — short acronyms, LETTER-bounded so they catch `vba`/`"vba"`/`vba_x`/`profiles/vba` and
    `RMS`/`"dms"`/`rms_x`/`/rms` but NOT the substring inside `GovBanner`/`navbar`/`forms`/
    `terms`/`admin`/`transforms`. GOTCHA: `iacra`/`medxpress`/`rms`/`dms` are the real FAA
    legacy-source repo names (client-blind-source-oracle) — they must never appear in
    platform code.
- **`ALLOWLISTED`** (:69-79): ONE entry —
  `("olympus-api/src/services/skill_registry.py", "for Tyrion Container Platform.")` — the
  wrapped tail of the `faa-code-standards` FALLBACK description (the FAA guard allowlists the
  other lines of the same string literal; same KEEP rationale, just the "Tyrion" fragment).
- **`KNOWN_LEAKS`** (`tuple[tuple[str,str,str],...]`, :100-121): a **ratchet** of real
  pre-existing leaks, each `(path, code-substring, owning-ticket)`. Agency tokens
  (tyrion/veterans/vba) are EMPTY (all removed by P7-S16.3). The four remaining entries are
  all `dashboard/src/pages/Compliance/ApplicationCompliance.tsx` IACRA demo-fixture wiring,
  ticket `P8-followup-de-hardcode-compliance-demo-fixtures`:
  - `'import iacraFixture from "../../fixtures/cato-evidence-IACRA.json"'`
  - `"IACRA: iacraFixture as CatoEvidence"`
  - `"iacra: iacraFixture as CatoEvidence"`
  - `'to="/compliance/IACRA">IACRA'`
  GOTCHA: these are baselined (NOT allowlisted) — they SHOULD be de-hardcoded to load
  fixtures by active profile/app id; the list may only SHRINK.
- **`_is_allowed`** (:124-128) and **`_known_leak`** (:131-135): same `(path, substring)`
  membership test; `_known_leak` iterates the 3-tuple ignoring the ticket.
- **`test_no_new_nonfaa_client_token_in_zone_b_code()`** (:138-159): scan with
  `CLIENT_TOKEN_RE`; `offenders` = `f"{rel}:{lineno}: {code}"` for hits that are neither
  `_is_allowed` nor `_known_leak`; `assert not offenders`.
- **`test_known_leaks_still_present()`** (:162-182): builds `present = {(rel, code)}`; for each
  `KNOWN_LEAKS (path, substring, ticket)`, if no present `(rel, code)` matches
  `leak_path == rel and substring in code` → `dead`; `assert not dead`. GOTCHA: this FAILS
  when a known leak disappears — forcing removal of the `KNOWN_LEAKS` line so the ratchet
  tightens (proves the fix landed rather than silently masked).
- **`test_allowlist_has_no_dead_entries()`** (:185-200): mirror of the FAA guard's dead-entry
  test over `CLIENT_TOKEN_RE` hits.

#### 4.7.4 `tests/test_feature_tree_schema.py` — the narrow Build feature-tree scan (SEPARATE)
This is a THIRD, unrelated client-token check — not driven by `check_client_blind.sh`.
The pytest `test_client_blind_no_agency_token_in_new_files`
(`tests/test_feature_tree_schema.py:514`):
- Scans exactly TWO files (`SCHEMA_PATH`, `SAMPLE_PATH` — the Build feature-tree schema + its
  sample, parametrized :513) for the regex `\b(?:faa|vba|veterans|tyrion|epa)\b`
  (case-insensitive, `_CLIENT_TOKENS`, :508-510); asserts no hits (:514-517).
- **GOTCHA — narrow coverage.** It does NOT scan the whole tree and does NOT match
  `iacra`/`medxpress`/`rms`/`dms`. That whole-tree Zone-B coverage is provided by §4.7.2/§4.7.3,
  NOT this feature-tree guard. The `Zone-B client-blind scan` referenced in
  `tests/profiles/conftest.py:47` is a concept note, not an implemented sweep of its own.

---

## 5. Schema validation

### 5.1 `make validate-schemas` → `schemas/validate.sh`
(`Makefile:200` → `bash schemas/validate.sh`.)
- **Metaschema pass** (validate.sh): for each `*.schema.json` under a FIXED list
  of subdirs — common, discovery, rationalization, architecture, data,
  modernization, build, gates, cross-cutting, compliance, profiles, dispositions
  — a Python one-liner asserts valid JSON + presence of `$schema`, `$id`,
  `title`, `description`; else FAIL + increment `ERRORS`. GOTCHA: the subdir list
  is hardcoded — a schema in a new subdir is silently not metaschema-checked here.
- **Sample round-trip**: runs `scripts/validate_schema_samples.py` — each sample
  must be a valid INSTANCE of the schema it names (its `$schema` ref stripped
  before validation), and every schema must have ≥1 sample so it is
  instance-exercised (uncovered-schema backlog tracked in the helper).
- Summary counts schemas (excluding `*/samples/*`) + `*.sample.json`; exit 1 if
  any errors ("VALIDATION FAILED").
- CI's `contracts` job does an EQUIVALENT-but-separate check (it does NOT call
  `validate.sh`): Redocly OpenAPI lint/bundle, `check-jsonschema --check-metaschema`
  over `schemas/**/*.schema.json`, and an inline `Draft202012Validator` +
  `RefResolver` sample validation (`ci.yml:317-382`).

### 5.2 `make validate-objectives` → `scripts/validate_objectives.py`
(`Makefile:203`.) Same script as §4.5; CI's `agency-objectives` job runs it.

### 5.3 `make validate-profile PROFILE=<id>` → `scripts/validate_profile.py` (218 lines)
(`Makefile:206`.) Validates ALL SEVEN (actually up-to-eight) bundles of a named
profile against `schemas/profiles/*.schema.json` (script header):
`profile.yaml` (loader-only, no schema), `compliance.yaml`,
`risk-classification.yaml`, `gates.yaml`, `scoring.yaml`, `technology.yaml`,
`objectives.yaml` (optional-when-absent), `delegation.yaml`
(optional-when-absent). jsonschema-validates each, accumulates violations with
file+reason, exits non-zero on any. Encoded invariants: tier-key set is exactly
`tier_1/tier_2/tier_3`; per-dimension weight in `[0,1]`. Does NOT duplicate the
loader's weight-sum / registry-resolution checks. **GOTCHA:** `validate-profile`
is NOT wired into any CI job — it's a Make target / authoring-tool gate only.

---

## 6. `deploy.yml` — deployment pipeline

`.github/workflows/deploy.yml` (name `Deploy`).
- Triggers (:3-18): `workflow_run` on CI completion for `main` + `workflow_dispatch`
  with `target_env` choice (dev/staging/prod, default dev).
- `permissions`: `id-token: write`, `contents: read` (AWS OIDC, :20-22).
- **`deploy-dev`** (:31-133): `if` workflow_run-success OR dispatch(dev).
  `environment: dev`. Configure AWS via `aws-actions/configure-aws-credentials@v4`
  (role `AWS_DEPLOY_ROLE_ARN`), ECR login, kubectl, Helm v3.14.0,
  `aws eks update-kubeconfig` (cluster `EKS_CLUSTER_NAME_DEV||olympus-dev`). Runs
  db migrations via `helm upgrade --install olympus-db-migrate` (tag =
  `workflow_run.head_sha || github.sha`), then the umbrella chart with `-f
  values-dev.yaml` and per-service image repo/tag overrides (5 services,
  `--wait --timeout 600s`, :76-98). **Smoke** (:100-133): polls ingress ALB
  hostname (12×10s); dumps pods; `::error::`+exit1 if ALB never materializes or
  `curl https://$ALB/health/live` != 200. GOTCHA: smoke now HARD-FAILS (was
  `::warning::` — broken deploys used to show green, :100-106).
- **`deploy-staging`** (:145-205): `needs: deploy-dev` + `if: always() && (
  workflow_run+deploy-dev==success OR dispatch(staging) )`. `environment:
  staging`. GOTCHA: the `always() && …` pattern lets a staging dispatch run
  WITHOUT deploy-dev (avoids "skipped because dependency skipped", :135-143).
  Umbrella deploy with `values-staging.yaml`. No smoke step.
- **`deploy-prod`** (:215-269): dispatch(prod)-ONLY, `environment: prod`
  (required-reviewers gate). GOTCHA: `needs: deploy-staging` was dropped — a prod
  dispatch skips deploy-staging, which used to skip prod too (:207-214). Tag =
  `github.sha`. Umbrella deploy with `values-prod.yaml`.

---

## 7. `branch-protection-sync.yml`

`.github/workflows/branch-protection-sync.yml` (name `Branch Protection Sync`).
- Reconciles GitHub-side `main` protection against `.github/branch-protection.yml`
  (:3-5). Triggers: push→main on change to the policy file or the workflow itself,
  + dispatch (:14-20). `permissions: contents: read` (:22-23).
- Single job `sync` (:26-91): checkout, then Python (heredoc) reads the YAML,
  builds a protection body (`required_status_checks {strict, contexts}`,
  `enforce_admins`, `required_pull_request_reviews`, `restrictions: None`), and
  `gh api --method PUT /repos/{repo}/branches/{branch}/protection` (:41-90).
- **GOTCHA:** needs `BRANCH_PROTECTION_TOKEN` (admin:write; default GITHUB_TOKEN
  cannot edit protection). When the secret is EMPTY the job emits `::warning::`
  and `exit 0` (no-op) rather than failing (:37-40).

---

## 8. Traceability workflows

### 8.1 `pages-publish-traceability.yml` (name `Publish traceability dashboard`)
- Trigger: push→main on `specifications/phase-3-traceability-appendix.md`,
  `scripts/traceability/build_dashboard_json.py`, `parse_matrix.py`,
  `traceability/index.html`, or the workflow itself; + dispatch (:9-19).
  `permissions: contents: write` (:21-23). `concurrency` group
  `pages-publish-traceability`, `cancel-in-progress: false` (:24-26).
- Job `publish` (:29-59): checkout (depth 1), Python 3.12,
  `build_dashboard_json.py --appendix … --out traceability/traceability.json`,
  then commit-if-changed as `github-actions[bot]` with message
  `chore(traceability): regenerate dashboard JSON [skip ci]` (GOTCHA: `[skip ci]`
  prevents retrigger loop, :49-59). Skips commit when the diff is clean.

### 8.2 `traceability-check.yml` (name `Traceability check`)
- Trigger: PR on many paths (specifications/**, temporal/**, dashboard/**,
  cross-cutting/**, profiles/**, docs/**, schemas/**,
  olympus-agent-runtime/**, scripts/traceability/**, the workflow, :11-24).
  `permissions: contents: read, pull-requests: write`. concurrency per-PR,
  cancel-in-progress (:30-32).
- Job `check` (:34-91): checkout depth 0, Python 3.12,
  `scripts/traceability/check.py --base base.sha --head head.sha --output … --json …`.
  Emits `has_signal`, `backslide_count`, `coverage_gap_count`. On signal,
  finds+upserts a `<!-- traceability-check -->` PR comment
  (peter-evans find/create-or-update). Uploads result JSON (14-day). Backslide →
  `::warning::`; coverage gap → `::notice::`.
- **GOTCHA — advisory only.** Three signals (status-progression, impact,
  coverage-gap); a status backslide (Supported→Partial, anything→Gap) is a
  WARNING not a failure; coverage gaps + impact are advisory. This workflow NEVER
  fails CI (:6-9).

---

## 9. `.github/branch-protection.yml` (required-checks contract)

Declarative policy (source of truth for §7 sync):
- `branch: main`; `required_status_checks.strict: true`.
- Required contexts: `lint / Python`, `lint / Dashboard`, `test / Python`,
  `test / Dashboard`, `build`, `CodeQL: python`, `CodeQL: javascript`,
  `SCA: Trivy fs`, `Secrets Scan`.
- Commented-out (advisory until 14-day window clears): `SBOM (CycloneDX)`, the 4
  `Image CVE Scan: <svc>` contexts.
- `enforce_admins: false`; `required_pull_request_reviews`:
  `required_approving_review_count: 1`, `dismiss_stale_reviews: true`,
  `require_code_owner_reviews: false`.
- **GOTCHA — context names don't match `ci.yml` job names.** The policy lists
  `lint / Python`, `test / Dashboard`, `build`, etc., but `ci.yml` produces jobs
  named `Python: olympus-api`, `Frontend Checks`, `Secrets Scan`, `CodeQL: python`,
  `SCA: Trivy fs` — only the last three overlap. `build` maps to the
  commented-out `build-push` job. Any rebuild must reconcile these names or the
  required-check gate references non-producing contexts.

---

## 10. `drift-backward.yml` / `drift-forward.yml` (P8 drift triggers)

Both run in mock-runtime mode (`AGENT_RUNTIME_MODE=mock`, `APP_ENV=test`) and NEVER
apply a cross-boundary edit (REQ-DR-008) — they only assert the drift engine is
wired and produce a persisted report + proposed_diff.

### 10.1 `drift-backward.yml` (name `drift-backward`, code→obligation)
- Trigger (:18-27): push→`main`/`integration/**` + PR `closed`→main. concurrency
  per-ref, cancel-in-progress. `permissions: contents: read`.
- Job `backward-pass` (:36-93): checkout depth 0, **Python 3.13** (GOTCHA:
  olympus-api pins py>=3.13 so `pip install -e olympus-api` fails on 3.12,
  :49-54). Install editable contracts + temporal + worker
  (`--ignore-requires-python`, because worker.py imports `render_rendition` whose
  engine re-exports from `src.renditions` in olympus-worker, :56-72) +
  `olympus-api[dev]` (`--ignore-requires-python`).
- **Assert-wiring step** (:73-84): imports `ALL_ACTIVITIES` from
  `olympus_workflows.worker`, asserts both `detect_drift` and
  `persist_drift_report` are registered (fails the job if the real persist path
  isn't wired).
- Run (:86-93): `cd olympus-api; pytest tests/drift/test_backward.py
  tests/drift/test_activity_persists.py -q --no-cov`. GOTCHA: `--no-cov` — this is
  a focused trigger smoke, NOT the coverage gate (the 87 floor is the full
  olympus-api suite's job).

### 10.2 `drift-forward.yml` (name `drift-forward`, obligation→code)
- Trigger (:19-31): push on ANY branch (`"**"`) when `specifications/**`,
  `schemas/**`, `assembly-lines/**`, or `cross-cutting/**` change; + PR on
  `specifications/**`/`schemas/**`. concurrency per-ref, cancel-in-progress.
- Job `forward-pass` (:41-96): identical install + assert-wiring as backward,
  then `cd olympus-api; pytest tests/drift/test_forward.py
  tests/drift/test_activity_persists.py -q --no-cov`.

---

## 11. Local-vs-CI parity notes (Makefile)

- `make demo-wait` (`Makefile:61`): polls `$(API_URL)/health/ready` until 200,
  `READY_RETRIES`×`READY_INTERVAL`s then fail — used verbatim by stack-spin &
  live-e2e CI jobs.
- `make demo-smoke` (`Makefile:87`): `python scripts/demo_smoke.py` — same
  portfolio-shape assertion CI runs.
- `make validate-schemas`/`validate-objectives`/`validate-profile` (§5).
- `make check-docs`/`fix-docs` (`Makefile`): run `check_doc_sync.py` [`--fix`].
</content>
</invoke>
