# 09 — Regeneration Order & Contracts Appendix

**Repository root:** `/Users/pnunna/Documents/GitHub/olympus` (the canonical `olympus` tree). All citations are `path:line` relative to this root. Stale/duplicate trees (`build/lib/`, `.claude/worktrees/`, `node_modules/`, `.venv/`, `dist/`, `__pycache__/`) are excluded from every count and never cited.

**Purpose of this doc.** Every other regen doc in `/Users/pnunna/Documents/regeneration-2026-07-03/` describes *what a component is and how it behaves*. This doc answers the orthogonal question: **in what ORDER do you rebuild them, and what command PROVES each layer works before you advance?** It is the assembly instruction sheet for the whole spec set. The second half is the **contracts appendix** — the shared type surface and schema catalog that is the true bedrock of the dependency graph.

The rebuild is dependency-correct: **contracts → framework/data → temporal + api → worker/agent/mcp/cli → dashboard → full-stack**. Each phase below names (a) the regen docs that specify it, (b) the exact proof GATE command + its pass criterion, and (c) what breaks downstream if it is skipped.

The single **behavioral-parity DONE definition** for the whole rebuild is § Phase 8. It is a *behavior* test — the stack comes up green, a Temporal workflow runs to a signal-gate and resumes when signalled, and the dashboard drives a flow end-to-end — NOT a coverage threshold. Coverage floors are per-package guard-rails inside each package's own regen doc, not the definition of done.

> **Drift note vs the prior (2026-07-02) spec.** This is ~184 commits newer. Verified deltas that the prior order doc got wrong and this one corrects (all re-derived from live code): **113 JSON schemas** (was 103) across **18 dirs** (was 13) + **44 samples** (was 37); **12 assembly-line YAMLs** including a now-CANONICAL `reverse-engineering.yaml` so `list_lines()` returns **12** (was 11, and `reverse-engineering.yaml` was wrongly called stale-tree-only); **52 routers** (was 44); **temporal coverage floor 80** (`temporal/pyproject.toml:123`, was 78); **90 alembic migrations** (was 80); a **5th** `registries/defaults/` YAML (`autonomy.yaml`) plus a new `loop_pattern.py` registry catalog; and three new subsystems — Capabilities Service (P9-W18), NL Action Console (P10-W6), Autonomy-Gating Runtime (P9/P10-S18) — covered by `14-capabilities-nl-autonomy.md`.

---

## 0. The current regen doc set (source: `ls /Users/pnunna/Documents/regeneration-2026-07-03/`)

Every phase below points into these files. They are the authoritative build inputs; this doc only orders them.

| Doc | Covers | Rebuild phase |
|---|---|---|
| `00-overview.md` | System map, four pillars, glossary | Read-first (all phases) |
| `00b-environment.md` | Local env, `.venv` on 3.12, `AGENT_RUNTIME_MODE`/`APP_ENV`, docker-compose services, ports, Dockerfiles | Phase 0 (+ Phase 7 images) |
| `06-contracts.md` | `olympus-contracts` package + the 113 JSON schemas + `validate.sh` | **Phase 1** |
| `06b-assembly-line-contracts.md` | The 12 assembly-line contract YAMLs shipped inside `olympus-contracts` | **Phase 1** |
| `07-framework.md` | The 6 extension registries + `defaults/` YAMLs + autonomy POLICY model | **Phase 2a** |
| `07b-profiles.md` | Client profiles (FAA) — risk tiers, compliance, gates, scoring, tech, autonomy overrides | **Phase 2a** |
| `11-skill-registry.md`, `11b-skill-line-wiring.md` | Skill catalog (`cross-cutting/skills/registry.yaml`), loading, dispatch/line wiring | Phase 2a |
| `skill-authoring-contract.md` | `SKILL.md` shape + pydantic contract + fixtures | Phase 2a |
| `04-data-layer.md`, `-part2.md`, `-part3.md` | Postgres schema, 90 Alembic migrations, repositories, JSONB query layer, event outbox | **Phase 2b** |
| `03-workflows/*` (27 files) | Every Temporal workflow incl. `IngestionWorkflow` + the 4 autonomy executors (`CiRepair`, `CveTriage`, `ErrorTriage`, `DependencySweep`) + `_base-workflow`, `orchestration-spine`, `bundle-rendition` | **Phase 3** |
| `03b-activities/*` (16 files) | Every Temporal activity family incl. `autonomy-activities`, `evidence-drift-eval`, `ingestion-activities`, `deployment-provisioning` | **Phase 3** |
| `01-api.md`, `-part2.md`, `-part3.md` | FastAPI app, 52 routers, middleware, auth posture, health, OpenAPI surface | **Phase 4** |
| `01-api-services.md`, `-part2.md` | API service layer (business logic behind the routers) | **Phase 4** |
| `02-agent-runtime.md` | `olympus-agent-runtime` service; live/mock dispatch, `MockAgentRuntime`, fixtures | **Phase 5** |
| `02b-worker-mcp-cli.md` | `olympus-worker` (Temporal worker bootstrap), `mcp-server`, `olympus-cli` | **Phase 5** |
| `13-generation-engine.md` | Modernization Extract→Design→Generate factory + Ralph-Loop TDD engine | Phase 4/6 (co-req of Modernization workflow) |
| `14-capabilities-nl-autonomy.md` | Capabilities Service (P9-W18) + NL Action Console (P10-W6) + Autonomy-Gating RUNTIME (P9/P10-S18) | **Phase 4c** (after API + contracts + profiles) |
| `05-dashboard.md`, `05-dashboard-pages*.md`, `05-dashboard-components*.md` | React + USWDS SPA (Vite), pages, components | **Phase 6** |
| `ROADMAP-TO-BE-IMPLEMENTED.md` | Not-yet-built backlog — NOT part of the parity rebuild | (reference only) |

> **There is no separate `08-build-ci.md` in this doc set.** The CI-gate / coverage-floor / anti-drift authority is folded into **this** doc (§ Phase 7) and `00b-environment.md` §1 is the source of truth for the Dockerfiles + both compose files. Phase 7's proof GATE combines `docker compose build` (00b's images) with the Makefile validation guards.

> If a doc in the table above is missing when you start (e.g. `06-contracts.md` was deleted), STOP — you cannot begin Phase 1 without its contract spec. The order below assumes the full set is present.

---

## 1. The dependency graph (why this order)

The arrows are **hard build/import dependencies verified from live code**, not editorial preference.

```
                    ┌─────────────────────────────┐
                    │  Phase 0: Environment        │  00b-environment.md
                    │  .venv(3.12) · docker · node │
                    └──────────────┬──────────────┘
                                   │
                    ┌──────────────▼──────────────┐
                    │  Phase 1: CONTRACTS          │  06 / 06b
                    │  olympus-contracts pkg       │  113 schemas + validate.sh
                    │  + 12 assembly-line YAMLs    │  + shared enums/signals/errors
                    └───────┬───────────────┬──────┘
                            │               │
             ┌──────────────▼──┐        ┌───▼─────────────────┐
             │ Phase 2a:       │        │ Phase 2b:           │
             │ FRAMEWORK       │        │ DATA LAYER          │
             │ 6 registries +  │        │ Postgres + Alembic  │
             │ loop_pattern    │        │ 04-data-layer*      │
             │ 07 · 07b · 11   │        │ (90 migrations)     │
             └───────┬─────────┘        └───────┬─────────────┘
                     │                          │
                     └───────────┬──────────────┘
                                 │  (both feed workflows AND api)
                  ┌──────────────┴───────────────┐
       ┌──────────▼───────────┐      ┌────────────▼─────────────┐
       │ Phase 3: TEMPORAL     │      │ Phase 4: API              │
       │ workflows+activities  │◄────►│ FastAPI routers+services  │
       │ 03-workflows/* (27)   │ REST │ 01-api* + 01-api-services*│
       │ 03b-activities/* (16) │signal│ (52 routers)              │
       │ + 4 autonomy executors│      │ + 14 (caps/NL/autonomy)   │
       └──────────┬────────────┘      └────────────┬─────────────┘
                  │  (worker hosts workflows;       │
                  │   activities call the API +     │
                  │   agent-runtime + git)          │
       ┌──────────▼─────────────────────────────────▼──────────┐
       │ Phase 5: SERVICE PROCESSES                              │
       │ olympus-worker · olympus-agent-runtime · mcp-server ·   │
       │ olympus-cli    02-agent-runtime.md · 02b-worker-mcp-cli │
       └──────────────────────────┬─────────────────────────────┘
                                  │  (dashboard consumes the API)
                    ┌─────────────▼──────────────┐
                    │ Phase 6: DASHBOARD          │  05-dashboard*
                    │ React + USWDS (Vite)        │
                    └─────────────┬──────────────┘
                                  │
                    ┌─────────────▼──────────────┐
                    │ Phase 7: PACKAGING          │  00b (images) + CI/floors/guards
                    │ images·CI·floors·guards     │
                    └─────────────┬──────────────┘
                                  │
                    ┌─────────────▼──────────────┐
                    │ Phase 8: FULL-STACK PARITY  │  make demo-up  ← DONE
                    │ green stack · signal-gate   │
                    │ resume · dashboard flow     │
                    └─────────────────────────────┘
```

**Critical path (longest hard-dependency chain — what to build first at every fork):**

```
Phase 0 → Phase 1 (contracts) → Phase 2b (data layer) → Phase 4 (API) →
Phase 5 (worker+agent-runtime) → Phase 6 (dashboard) → Phase 8 (parity)
```

Phase 2a (framework registries + skills + profiles) and Phase 3 (workflows) are on a **parallel branch** that must complete before Phase 5 but does not block Phase 4's router surface from compiling. Phase 4c (Capabilities / NL Action Console / Autonomy runtime) rides on top of Phase 4 + Phase 1 (contracts) + Phase 2a (profiles/autonomy defaults) and must finish before the Phase 4 test gate is fully green. With two builders, put the critical path on one and Phase 2a→3 on the other; they rejoin at Phase 5. With one builder, follow the numeric order below.

### Why each edge exists (verified)

- **Everything → contracts.** `olympus-api`, `temporal`, `mcp-server`, `olympus-worker` all `from olympus_contracts import ...`. The package declares `pydantic>=2.0.0` as a **runtime** dependency (`olympus-contracts/pyproject.toml:dependencies`, comment above it) precisely because `olympus_contracts.__init__` re-exports `reusable_parts`, which imports pydantic at module load — a consumer that installs contracts alone must get pydantic transitively or `import olympus_contracts` throws `ModuleNotFoundError`. **GOTCHA:** the contracts package is `pip install -e`'d into the **primary checkout's** `.venv`, not any worktree — editable installs point at the primary tree (MEMORY: "editable-install=PRIMARY not worktree").
- **Framework registries → contracts.** `assembly_line.py` loads its default line set from the contracts package; `list_lines()` (`olympus-contracts/olympus_contracts/assembly_lines.py:384`) iterates `data/assembly-lines/*.yaml` via `_load_all()` (`:346-378`) and now returns **12** lines including `Reverse Engineering` (`reverse-engineering.yaml`, `name: Reverse Engineering`). So the 12 assembly-line YAMLs (Phase 1 payload) must exist before the registries load.
- **Capabilities/NL/Autonomy → contracts + API + profiles.** `14`'s three subsystems each depend on new contract modules (`capability_types.py`, `intent_types.py`, `evidence_types.py`, `drift_types.py`, `worklog_types.py`) that ship in Phase 1, on the FastAPI routers/services in Phase 4, and — for the autonomy gate — on the profile autonomy overrides layered atop `registries/defaults/autonomy.yaml` in Phase 2a. They add NO new dispatch mechanism; the Capabilities service wraps the one canonical single-skill path (`14`, PART 1).
- **Workflows → framework + activities.** The worker registers `workflows=ALL_WORKFLOWS, activities=ALL_ACTIVITIES` (`olympus-worker/src/worker.py:129-130`, imported from `olympus_workflows.worker` at `:27`). Workflows call the registries (gate providers, dispositions, scoring dimensions, loop patterns) and dispatch activities.
- **Activities → API + agent-runtime + git.** Activity families (`03b-activities/agent-dispatch.md`, `gate-operations.md`, `git-operations.md`) call the agent-runtime HTTP surface and the Git store; gate activities read/write API-backed state.
- **Worker → workflows+activities (host), API (state), agent-runtime (dispatch).** The worker is the process hosting Phase 3 code; it cannot start until Phases 3+4 exist. **GOTCHA:** against a secured API (`DEV_AUTH_BYPASS=false`, e.g. olympus2) the agent-runtime MUST present `OLYMPUS_API_TOKEN` to load skills from `/api/v1/skills/dispatch` — a bare request 401s and every dispatch dies at skill-load. So service tokens (`make seed-tokens` → `.service-tokens.env`) are a boot-time dependency of Phase 5 against a secured API.
- **Dashboard → API.** Core principle #2 (API before UI): the SPA only consumes REST — no import edge on Python packages; its dependency is *runtime* (the API must answer).
- **Parity → all.** `make demo-up` (`Makefile:49-59`) orchestrates compose up (`--scale olympus-agent-runtime=$(AGENT_SCALE)`) → `demo-wait` (poll `$(API_URL)/health/ready`) → `demo-seed` (`python scripts/seed_all.py --reset`) → `demo-smoke` (`python scripts/demo_smoke.py`).

---

## 2. Phase-by-phase rebuild order with proof GATES

Each phase's GATE is a **command + pass criterion**. Do not advance until the gate is green. Run all Python commands with the Phase-0 env (`AGENT_RUNTIME_MODE=mock APP_ENV=test` for tests) inside the 3.12 `.venv`.

---

### Phase 0 — Environment (`00b-environment.md`)

**Build:** the 3.12 virtualenv (default `python3` is 3.9.6, too old — build `.venv` via `scripts/dev-setup.sh`), Docker + docker-compose, Node/npm (`.nvmrc`), and the env conventions: `AGENT_RUNTIME_MODE=live|mock`, `APP_ENV`, `.env`/`.env.example`, `.service-tokens.env`. Compose services (source `docker-compose.yml`): `postgres`, `redis`, `localstack`, `db-migrate`, `temporal-server`, `temporal-namespace-init`, `temporal-ui`, `olympus-api`, `olympus-temporal-worker`, `olympus-dashboard`, `olympus-agent-runtime`, `olympus-agent` (HAProxy LB on :8100), `olympus-mcp-server`. Named volumes: `postgres-data`, `redis-data`, `localstack-data`, `agent-workspace`.

**Ports (host):** dashboard `:3000`, API `:8000`, Temporal UI `:8080` (`Makefile:56-59`). The `olympus2` integration stack shifts every published port +1000: **the host-side seed/readiness `API_URL` is `http://127.0.0.1:18000`** (`Makefile:109` `OLYMPUS2_ENV`), postgres `:6432`, and the up-banner also announces dashboard `:4000`, API `:18000`, Temporal UI `:9080` (`Makefile:126-127`). **GOTCHA:** the comment at `Makefile:102` says "API :9000" but the operative `API_URL`/banner value is `:18000` — trust `:18000`. **GOTCHA:** on macOS the olympus2 seed's asyncpg connect intermittently fails to resolve `localhost` (gaierror), so the Makefile pins `DATABASE_HOST=127.0.0.1` for that stack (`Makefile:104-109`). macOS has no `timeout` command — don't wrap calls in it.

**GATE:**
```bash
python3.12 -c "import sys; assert sys.version_info[:2]==(3,12)" && docker compose version && node --version
```
Pass: all three print without error; Python is 3.12.x.

---

### Phase 1 — CONTRACTS (`06-contracts.md`, `06b-assembly-line-contracts.md`)

**Build:** the full `olympus-contracts` package AND the `schemas/` tree. Nothing else compiles without these. See § Contracts Appendix (below) for the exhaustive index.

- `olympus-contracts/olympus_contracts/` — **20 Python modules** (`ls olympus-contracts/olympus_contracts/*.py`): `__init__.py`, `assembly_lines.py`, `blueprint_types.py`, `capability_types.py`, `catalog_types.py`, `connected_memory.py`, `drift_types.py`, `enums.py`, `errors.py`, `eval_types.py`, `event_outbox.py`, `evidence_types.py`, `feedback_types.py`, `git_types.py`, `graph_types.py`, `ingestion_types.py`, `intent_types.py`, `net.py`, `reusable_parts.py`, `signals.py`, `worklog_types.py`. Package is PEP-561 typed (`py.typed`) and ships `data/assembly-lines/*.yaml` as package data. Version `0.5.0`, `requires-python >=3.11`, deps `pyyaml>=6.0` + `pydantic>=2.0.0` (`olympus-contracts/pyproject.toml`).
- The **12 assembly-line YAMLs** under `olympus_contracts/data/assembly-lines/`: `architecture`, `build`, `data`, `deployment`, `discovery`, `disposition-execution`, `governance`, `modernization`, `rationalization`, `reverse-engineering`, `sustainment`, `validation`. **`reverse-engineering.yaml` is CANONICAL now** (`name: Reverse Engineering`) and is loaded by `list_lines()` — do NOT drop it (this reverses the prior spec's stale-tree assumption).
- The **113 JSON schemas** across 18 dirs + 44 samples + `schemas/validate.sh` (see § 3.2/3.3).

**GATE:**
```bash
pip install -e olympus-contracts \
  && python3 -c "import olympus_contracts; from olympus_contracts import list_lines; print(len(list_lines()))" \
  && bash schemas/validate.sh
```
Pass: `import olympus_contracts` succeeds (no `ModuleNotFoundError` — proves pydantic is a resolved runtime dep), `list_lines()` returns **12**, and `validate.sh` prints `ALL VALIDATIONS PASSED` with `Schemas: 113` / `Samples: 44` / `Errors: 0`. **This gate is load-bearing** — a broken contract layer silently corrupts every downstream phase.

---

### Phase 2a — FRAMEWORK: 6 extension registries + loop-pattern catalog + skills + profiles (`07-framework.md`, `07b-profiles.md`, `11-skill-registry.md`, `11b-skill-line-wiring.md`, `skill-authoring-contract.md`)

**Build:** the shared registry substrate `temporal/olympus_workflows/registries/`: `engine.py` (shared base), `worker_bootstrap.py`, `profile_overrides.py`, the **6 extension points**, plus the **`loop_pattern.py`** catalog (P10-S18.1 autonomy — a catalog of continuous-loop patterns, NOT a 7th extension point):

| # | Registry file | Default source |
|---|---|---|
| 1 | `assembly_line.py` | `olympus-contracts` 12 YAMLs (via `list_lines`) |
| 2 | `disposition.py` | `registries/defaults/dispositions.yaml` |
| 3 | `analysis_pass.py` | code defaults (`register_default_passes()`) — no standalone `defaults/` YAML |
| 4 | `scoring_dimension.py` | `registries/defaults/scoring-dimensions.yaml` |
| 5 | `gate_provider.py` | `registries/defaults/gate-providers.yaml` |
| 6 | `skill_composition.py` | `registries/defaults/skill-compositions.yaml` |
| (cat) | `loop_pattern.py` | `registries/defaults/autonomy.yaml` (loop patterns + autonomy policy DEFAULTS) |

So `registries/defaults/` now contains **5** YAML files: `dispositions.yaml`, `scoring-dimensions.yaml`, `gate-providers.yaml`, `skill-compositions.yaml`, **`autonomy.yaml`** (new — conservative fail-closed autonomy policy defaults; `header:1-20` documents `default_level: report_only`, `deny_by_default: true`, `auto_merge_allowlist: []`; schema `schemas/cross-cutting/autonomy-policy.schema.json`).

Plus the **skill catalog** (`cross-cutting/skills/registry.yaml`), each skill's `SKILL.md` + pydantic contract + `fixtures/` (validated per skill; used by `MockAgentRuntime`), and the **client profiles** (`profiles/faa/*`, `07b-profiles.md`) which layer overrides — including autonomy overrides — atop the defaults. All extensions register through these registries — never modify core definitions directly.

**GATE:**
```bash
cd temporal && AGENT_RUNTIME_MODE=mock APP_ENV=test python -c "from olympus_workflows.registries import assembly_line, disposition, analysis_pass, scoring_dimension, gate_provider, skill_composition, loop_pattern; print('registries OK')" \
  && cd .. && make validate-objectives && python scripts/check_doc_sync.py
```
Pass: all registries import and self-populate defaults; `validate-objectives` passes against schema+registries; `check_doc_sync.py` reports no drift (skill/gate/line counts match source of truth). **GOTCHA:** `check_doc_sync` is a CI guard; count drift fails the build on main-targeting PRs only.

---

### Phase 2b — DATA LAYER (`04-data-layer.md`, `-part2.md`, `-part3.md`)

**Build:** the Postgres + JSONB derived query layer. Alembic lives at `db/alembic/` with **90 migration versions** under `db/alembic/versions/` (`ls db/alembic/versions/*.py | wc -l` = 90; chain is linear). Repositories, the event-outbox pattern, and the seed scripts (`scripts/seed_*.py`) sit on top. Postgres is *derived and disposable* — rebuilt from Git (Core principle #4). The `db-migrate` compose service runs alembic on stack up.

**GATE:**
```bash
docker compose up -d postgres && docker compose run --rm db-migrate   # or: cd db && alembic upgrade head
```
Pass: alembic reaches `head` with no error; `alembic current` shows the single linear head; `alembic history` shows no branch points. Then `cd olympus-api && AGENT_RUNTIME_MODE=mock APP_ENV=test pytest tests/ -k "repositor or migration or outbox"` passes.

---

### Phase 3 — TEMPORAL workflows + activities (`03-workflows/*`, `03b-activities/*`)

**Build:** the workflow modules in `temporal/olympus_workflows/workflows/` (per-line workflows + orchestration spine + `base.py` + bundle/rendition helpers) and the **16 activity families** in `03b-activities/`. Named workflows include `DiscoveryWorkflow`, `RationalizationWorkflow`, `WaveRationalizationWorkflow`, `WaveArchitectureWorkflow`, the per-app `WaveWorkflow`/`ApplicationWorkflow` coordinator (`wave.py`, `application.py`), `ArchitectureWorkflow`, `DataWorkflow`, `ModernizationWorkflow`, `BuildWorkflow`, `ValidationWorkflow`, `DeploymentWorkflow`, `DispositionWorkflow`, `SustainmentWorkflow`, `GovernanceWorkflow`, the new **`IngestionWorkflow`** (`ingestion.py:54` input / `:71` result), and the **4 autonomy executor cron workflows**: `DependencySweepWorkflow` (`dependency_sweep.py:103`), `CiRepairWorkflow` (`ci_repair.py:117`), `ErrorTriageWorkflow` (`error_triage.py:132`), `CveTriageWorkflow` (`cve_triage.py:110`). Activity families add `autonomy-activities`, `evidence-drift-eval`, `ingestion-activities`, `deployment-provisioning`.

The **signal-gate mechanic** is the behavioral heart. Anchor — Discovery: the workflow commits artifacts, opens the gate PR, runs the G-DC gate-readiness check, then blocks on a wait-condition awaiting the gate decision signal; on `"approved"` it proceeds, on reject it bumps rework and re-runs, aborting once rework exceeds `MAX_REWORK_ITERATIONS` (`workflows/discovery.py`; see `03-workflows/DiscoveryWorkflow.md` for exact line anchors). Every line follows the same wait-condition-on-signal pattern; do NOT collapse the approve/reject/rework branches.

**GOTCHA:** workflow tests must use `MockAgentRuntime` for canned agent responses (DECISION-018) but exercise **real workflow logic** — never mock the workflow itself. Fixtures under `cross-cutting/skills/<skill>/fixtures/`. The 4 autonomy executors run on a Temporal cron and their requested `default_autonomy_level` is only *requested* — the advisory autonomy gate caps it to the touched app's tier (`loop_pattern.py:16-19`).

**GATE:**
```bash
cd temporal && AGENT_RUNTIME_MODE=mock APP_ENV=test pytest
```
Pass: temporal package tests pass at the **80% floor** (`temporal/pyproject.toml:123` `--cov-fail-under=80` — do NOT use 78 or 87). Critically, the workflow-replay / signal tests that drive a workflow to G-DC and resume on the approve signal must pass — that is the Phase-3 proof of the signal-gate mechanic in isolation (the full-stack version is Phase 8).

---

### Phase 4 — API: FastAPI routers + service layer (`01-api*`, `01-api-services*`)

**Build:** `olympus-api/src/main.py` `create_app()` (`:157`) and its **52 routers** (`grep -c include_router` = 52; router imports `grep -c '^from src.routers'` = 52). Middleware order is load-bearing (CORS → RequestId → RateLimit → Metrics → routes); `expose_headers` includes `X-Trace-ID`/`X-Request-ID` so the SPA can read correlation ids.

**Security posture (fail-closed, DECISION-016 / P7-S16.1):** `assert_secure_auth_posture()` (`:166`) refuses to boot in production when auth is effectively disabled (skip-verification, dev bypass, or the shipped default JWT secret); permissive under `APP_ENV in {dev, local, test}`. `assert_safe_cors()` (`:188`) rejects a credentialed CORS wildcard. Do not weaken either — production refuses to start in mock mode.

**GATE:**
```bash
cd olympus-api && AGENT_RUNTIME_MODE=mock APP_ENV=test pytest \
  && AGENT_RUNTIME_MODE=mock APP_ENV=test python -c "from src.main import create_app; app=create_app(); print(len(app.routes)); import json; json.dumps(app.openapi())"
```
Pass: API tests pass (**87% floor**, `olympus-api/pyproject.toml:89`); `create_app()` builds without tripping the auth/CORS asserts; `app.openapi()` serializes (the **OpenAPI-from-FastAPI surface** — derived from the live router + pydantic models, not a checked-in file).

---

### Phase 4c — CAPABILITIES · NL ACTION CONSOLE · AUTONOMY RUNTIME (`14-capabilities-nl-autonomy.md`, co-req `13-generation-engine.md`)

**Build (rides on Phase 4 + Phase 1 contracts + Phase 2a profiles):**
- **Capabilities Service (P9-W18)** — `olympus-api/src/routers/capabilities.py` (mounted `main.py:263`) + `olympus-api/src/services/capabilities/{service,provenance,verification,defaults,run_event,store,models,allowlist}.py`, backed by contract `capability_types.py` (`ProvenanceTier` bare/provenance/verified — a run DIMENSION, NOT a `GateType`). Wraps the one canonical single-skill dispatch; adds no new dispatch mechanism.
- **NL Action Console (P10-W6)** — the plan+execute conversational surface under the user's token, exposed via the `intake` router (`main.py:266`, "intent front door — confirm gate + material pause"), `chat` router (`:267`), and `delegations` router; backed by `intent_types.py`.
- **Autonomy-Gating Runtime (P9/P10-S18)** — `autonomy` router (`main.py:256`, escalation + operator/AO status live-view) and `autonomy_incidents` router (`:260`, `GET /autonomy/incidents`), the RUNTIME that OBTAINS and ENFORCES the autonomy decision. The POLICY MODEL lives in `07-framework.md`; the on-disk defaults in `registries/defaults/autonomy.yaml`; the executor shells in Phase 3.

The Modernization **Extract→Design→Generate** factory + Ralph-Loop TDD engine (`13-generation-engine.md`) is a co-requisite of the Modernization workflow; build it here or alongside Phase 3.

**GATE:** covered by the Phase-4 `pytest` (these routers/services are in `olympus-api`). Additionally assert the three router groups mount:
```bash
cd olympus-api && AGENT_RUNTIME_MODE=mock APP_ENV=test python -c "from src.main import create_app; paths={r.path for r in create_app().routes}; assert any(p.startswith('/api/v1/capabilities') for p in paths); assert any('autonomy' in p for p in paths); print('caps+autonomy mounted')"
```
Pass: the capabilities and autonomy paths are present; the fail-closed autonomy defaults load (`report_only`, `deny_by_default: true`, empty `auto_merge_allowlist`).

---

### Phase 5 — SERVICE PROCESSES: worker · agent-runtime · mcp · cli (`02-agent-runtime.md`, `02b-worker-mcp-cli.md`)

**Build:**
- `olympus-worker/src/worker.py` — hosts `Worker(workflows=ALL_WORKFLOWS, activities=ALL_ACTIVITIES)` (`:129-130`, imported from `olympus_workflows.worker` at `:27`), plus agent registry loading (`agents.yaml` cards, skill→agent resolution). This process wires Phase 3 into Temporal.
- `olympus-agent-runtime/` — dispatch service. `AGENT_RUNTIME_MODE=live` uses Claude Agent SDK on Bedrock; `=mock` serves `MockAgentRuntime` from skill fixtures. **Production refuses to start in mock mode.**
- `mcp-server/` — MCP protocol server exposing Olympus resources/tools.
- `olympus-cli/` — CLI client.

**GOTCHA (boot dependency):** against a secured API (`DEV_AUTH_BYPASS=false`, e.g. olympus2), mint service tokens FIRST (`make seed-tokens` → `.service-tokens.env`; `JWT_SECRET` must match the stack's `olympus-dev-secret` default) or the agent-runtime 401s at `/api/v1/skills/dispatch` and every dispatch fails at skill-load. **GOTCHA:** scale the RUNTIME pool (`--scale olympus-agent-runtime=N`, default `$(AGENT_SCALE)`), NOT the `olympus-agent` HAProxy LB — the LB is a single host-:8100 binder and scaling it collides on that port.

**GATE:**
```bash
for d in olympus-worker olympus-agent-runtime mcp-server; do (cd $d && AGENT_RUNTIME_MODE=mock APP_ENV=test pytest) || exit 1; done \
  && (cd olympus-cli && AGENT_RUNTIME_MODE=mock APP_ENV=test pytest 2>/dev/null || python -c "import olympus_cli")
```
Pass: worker (**90% floor**, `olympus-worker/pyproject.toml:56`), agent-runtime (**90%**, `olympus-agent-runtime/pyproject.toml:69`), mcp-server (**90%**, `mcp-server/pyproject.toml:41`) tests pass; worker entrypoint imports `ALL_WORKFLOWS`/`ALL_ACTIVITIES` without error.

---

### Phase 6 — DASHBOARD (`05-dashboard.md`, `05-dashboard-pages*.md`, `05-dashboard-components*.md`)

**Build:** the React + USWDS SPA under `dashboard/` (Vite build, Vitest unit, Playwright e2e). Consumes ONLY the API (no Python import edge). Pages and components are exhaustively specified across the `05-*` docs. **GOTCHA (MEMORY):** the running dashboard bind-mounts a *worktree's* `src`, not the primary checkout — author/verify live e2e against the worktree the stack actually mounts.

**GATE:**
```bash
cd dashboard && npm ci && npm run lint && npm run build && npm test
```
Pass: lint clean, `vite build` produces `dist/` with no error, Vitest passes with coverage floors **lines 81 / branches 70 / functions 76 / statements 78** (`dashboard/vitest.config.ts:68-71`; statements is **78** — dropped 79→78 at P5-S26 to match main drift, `:62`, NOT 79). Playwright e2e is deferred to Phase 8 (needs the live stack).

---

### Phase 7 — PACKAGING: images (`00b`) + CI/floors/guards

**Build (images — spec in `00b-environment.md` §1):** each service's Dockerfile and both compose files (`docker-compose.yml` primary; `docker-compose.olympus2.yml` +1000-port overlay). `00b` §1 is the source of truth for all compose services (build stanza, ports, env, volumes, healthcheck) and the multi-stage Dockerfiles.

**Build (CI gate set + coverage floors + anti-drift guards):** the Makefile lifecycle + validate targets, the GitHub Actions pipeline (`.github/workflows/*.yml` — path-classifier preflight → branch-naming, contracts, skill-catalog, doc-sync, agency-objectives, step-registry-consistency, sql-schema-drift, line-contracts-consistency, profile-portability, stack-spin-smoke, live-e2e, the per-package `python` matrix, `python-integration`, `frontend`, `secrets-scan`, plus nightly/push-only codeql/trivy/sbom/helm-lint/terraform-validate), the **coverage floors** (api **87**, worker **90**, agent-runtime **90**, mcp **90**, **temporal 80**, dashboard **81/70/76/78**), and the anti-drift guard scripts (`check_doc_sync`, `validate_skill_registry`, `verify_sql_schema`, `verify_step_registry`, `validate_objectives`, `validate_profile`, `check_client_blind`, the no-hardcoded-step-list test).

**GOTCHA (MEMORY):** the full CI matrix runs only on main-targeting PRs and its logs are unavailable until the run completes — reproduce the guards locally (`make validate-schemas`, `make validate-objectives`, `make check-docs`, per-package `pytest`) before pushing. **GOTCHA (floors vs project CLAUDE.md):** the LIVE temporal floor is **80** (`temporal/pyproject.toml:123`) and dashboard statements is **78** (`dashboard/vitest.config.ts:71`), NOT the 87 / 79 the project CLAUDE.md claims — reproduce the LIVE numbers.

**GATE:**
```bash
docker compose build && make validate-schemas && make validate-objectives && make check-docs
```
Pass: all service images build; all three validation guards pass. (Coverage floors are enforced per-package inside Phases 1–6, not here — this phase proves the *packaging*.)

---

### Phase 8 — FULL-STACK BEHAVIORAL PARITY (the DONE definition)

This is the **single stop condition for the entire rebuild**. It is a behavior test, not a metric.

**DONE ⇔ all three of the following pass on a freshly-rebuilt stack:**

**(1) The stack comes up green and seeds.**
```bash
make demo-up
```
Pass (`Makefile:49-59, 61-95`): runs `docker compose up -d --scale olympus-agent-runtime=$(AGENT_SCALE)` → `demo-wait` (polls `GET $(API_URL)/health/ready` until HTTP 200, `READY_RETRIES`×`READY_INTERVAL`s) → `demo-seed` (`python scripts/seed_all.py --reset`) → `demo-smoke` (`python scripts/demo_smoke.py`). `demo_smoke.py` GETs `/api/v1/portfolio`, asserts a portfolio named **`Modernization Corpus`** (`CORPUS_PORTFOLIO`, `:36`) AND the demo portfolio (`DEMO_PORTFOLIO_NAME`) both exist (`:88-93`), and that each has a non-empty application count (`GET /api/v1/applications?portfolio_id=<pid>` non-empty, `:96-115`). Exit 0 = green; any assertion failure prints a `FAIL:` diagnostic line and exits 1 (`:118-126`). Endpoints answer: dashboard `:3000`, API `:8000`, Temporal UI `:8080`.

**(2) A Temporal workflow runs to a signal-gate and RESUMES on the signal.**
Start a line, drive it to its gate, then approve via the API signal inbox and confirm it proceeds:
```bash
# start a Discovery run (line-start router: POST /api/v1/lines/discovery/start), then:
#   observe it block at G-DC in the Temporal UI (:8080),
#   POST the gate decision (workflow-signals / gates router → approve),
#   confirm the workflow leaves the wait and completes the merge tail.
curl -s -X POST $API_URL/api/v1/lines/discovery/start -H "$AUTH" -d '{...}'
curl -s -X POST $API_URL/api/v1/waves/<id>/gates/approve-pending -H "$AUTH"
```
Pass: the workflow (`DiscoveryWorkflow`, blocked at its `_wait_for_gate_decision(GateType.G_DC)` wait-condition, `workflows/discovery.py`) transitions from *running/blocked* to *completed* after the approve signal — proving the durable signal-gate mechanic end-to-end across API→Temporal. (The olympus2 stack pre-seeds a pending quorum gate via its Phase-5 test-data seeder for the live Playwright assertion of the same behavior.)

**(3) The dashboard drives a flow end-to-end.**
```bash
cd dashboard && npm run test:e2e   # Playwright against the live stack (:3000 → API :8000)
```
Pass: the live e2e suite navigates the SPA, drives a real workflow-backed flow (viewing a portfolio, opening a pending gate, claiming an offered bundle, approving a gate), and asserts the UI reflects the workflow-produced state — with NO mocked API.

**If all three pass, the rebuild has behavioral parity and is DONE.** Coverage floors, lint, and schema validation are guard-rails that must already be green from Phases 1–7 — necessary but not the definition of done. Do NOT declare done on a coverage number.

---

## 3. CONTRACTS APPENDIX

The bedrock of the whole graph. Rebuild these in Phase 1 exactly.

### 3.1 The `olympus-contracts` package

`olympus-contracts/pyproject.toml`: name `olympus-contracts`, version `0.5.0`, `requires-python >=3.11`, build-backend `setuptools.build_meta`, deps `pyyaml>=6.0` + `pydantic>=2.0.0` (pydantic is RUNTIME, not just dev — the comment above `dependencies` explains the Step-Registry CI job needs it transitively). Ruff `target-version py311`. Package data: `py.typed` (PEP-561) + `data/assembly-lines/*.yaml`.

**20 Python modules** under `olympus-contracts/olympus_contracts/`:

| Module | Role |
|---|---|
| `__init__.py` | Re-exports (incl. `reusable_parts` → pydantic load at import; `list_lines`) |
| `assembly_lines.py` | Line contract loader/types; `_load_all()` (`:346`) + `list_lines()` (`:384`) read the 12 YAMLs, cached via `@lru_cache` |
| `enums.py` | Shared enums — e.g. `GateType` incl. `G_DC` used by workflows |
| `signals.py` | Temporal signal name/type contracts (gate decisions) |
| `errors.py` | Shared error/exception types (`EntityNotFound`, etc.) |
| `reusable_parts.py` | Reusable-part pydantic models (P7-S16.11) |
| `event_outbox.py` | Event-outbox record contract (data-layer pattern) |
| `git_types.py` | Git artifact-store types (commit/PR/branch contracts) |
| `connected_memory.py` | Connected-memory contract types |
| `net.py` | Network/transport contract helpers |
| `capability_types.py` | **NEW** — Capabilities Service (`ProvenanceTier`, `CapabilityRequest/Result`) — P9-W18 |
| `intent_types.py` | **NEW** — NL Action Console intent model — P10-W6 |
| `evidence_types.py` | **NEW** — evidence-ledger record contract |
| `drift_types.py` | **NEW** — evidence/schema-drift eval contract |
| `worklog_types.py` | **NEW** — work-log / provenance contract |
| `blueprint_types.py` | **NEW** — target-architecture blueprint contract |
| `catalog_types.py` | **NEW** — catalog contract types |
| `eval_types.py` | **NEW** — eval-harness contract |
| `feedback_types.py` | **NEW** — feedback contract |
| `graph_types.py` | **NEW** — dependency-graph contract |
| `ingestion_types.py` | **NEW** — legacy-ingestion contract |

The **12 assembly-line YAMLs** (`olympus_contracts/data/assembly-lines/`): `architecture`, `build`, `data`, `deployment`, `discovery`, `disposition-execution`, `governance`, `modernization`, `rationalization`, **`reverse-engineering`** (canonical — `name: Reverse Engineering`), `sustainment`, `validation`. `_load_all()` loads every `*.yaml` not starting with `_` (`assembly_lines.py:356`), raises on a duplicate `name` (`:367`) or an empty set (`:375`); `list_lines()` returns them sorted by name (12 total).

### 3.2 The 113 JSON schemas (by dir)

`schemas/` — **113** `*.schema.json` (excluding samples) + **44** `*.sample.json`, JSON-Schema 2020-12. Counts (`find schemas -name '*.schema.json' ! -path '*/samples/*'`):

| Dir | `.schema.json` |
|---|---|
| `schemas/rationalization/` | 18 |
| `schemas/discovery/` | 17 |
| `schemas/cross-cutting/` | 15 |
| `schemas/architecture/` | 12 |
| `schemas/dispositions/` | 8 |
| `schemas/profiles/` | 8 |
| `schemas/modernization/` | 7 |
| `schemas/data/` | 6 |
| `schemas/design/` | 6 |
| `schemas/common/` | 4 |
| `schemas/build/` | 3 |
| `schemas/gates/` | 3 |
| `schemas/ingestion/` | 2 |
| `schemas/compliance/` | 1 |
| `schemas/drift/` | 1 |
| `schemas/evidence/` | 1 |
| `schemas/oscal/` | 1 |
| **Total** | **113** |

Samples (44) live under `schemas/samples/` and per-dir `samples/` subtrees.

> **GOTCHA:** `schemas/validate.sh`'s metaschema/shape pass iterates only an EXPLICIT dir list (`schemas/validate.sh:12`): `common, discovery, rationalization, architecture, data, modernization, build, gates, cross-cutting, compliance, profiles, dispositions`. **The 5 dirs `design/`, `drift/`, `evidence/`, `ingestion/`, `oscal/` are NOT in that loop** — their 11 schemas skip the per-file `$schema/$id/title/description` presence check. They are still counted in the summary `find` (contributing to the 113) and exercised by the sample round-trip (§ 3.3 pass 2). If you regenerate, keep those 5 dirs sample-covered or they drift unchecked.

### 3.3 `schemas/validate.sh` behavior (reproduce exactly)

`set -e` (`:5`). `SCHEMA_DIR` = the `schemas/` dir; `REPO_ROOT` = its parent (`:7-8`). Two passes then a summary:
1. **Metaschema/shape pass** (`:11-35`): for each schema in the explicit dir glob list (`:12`), run inline Python (`:15-27`) that loads the JSON and asserts presence of `$schema`, `$id`, `title`, `description` **in that check order**; missing any → prints the specific `MISSING ...` and the outer shell prints `FAIL` and increments `ERRORS` (`:31-32`).
2. **Sample round-trip + completeness** (`:38-45`): runs `scripts/validate_schema_samples.py` — every sample must be a valid *instance* of the schema it names (the sample's `$schema` pointer is stripped before validation), AND every schema must have ≥1 sample so it is instance-exercised and cannot silently drift; a tracked backlog of uncovered schemas lives in that helper. Non-zero exit → `ERRORS++` (`:43-44`).
3. **Summary** (`:47-60`): recomputes `SCHEMA_COUNT` = `find ... -name "*.schema.json" ! -path "*/samples/*" | wc -l` (expect 113, `:49`), `SAMPLE_COUNT` = `*.sample.json | wc -l` (expect 44, `:50`). If `ERRORS>0` → prints `VALIDATION FAILED`, exit 1 (`:55-57`); else `ALL VALIDATIONS PASSED`, exit 0 (`:58-59`).

Invoked via `make validate-schemas` (`Makefile:200`).

### 3.4 OpenAPI-from-FastAPI surface

There is **no checked-in `openapi.json`** and no generator script — the OpenAPI document is **derived at runtime** from the live FastAPI app. `create_app()` (`olympus-api/src/main.py:157`) constructs `FastAPI(...)` (`:171`), enforces `assert_secure_auth_posture()` (`:166`) and `assert_safe_cors(config.cors_origins, allow_credentials=True)` (`:188`), and mounts **52 routers** (`include_router` ×52; router imports `from src.routers ...` ×52). The contract surface = the union of those routers' path operations + their pydantic request/response models (many sourced from `olympus_contracts`). To regenerate the OpenAPI JSON: `app = create_app(); app.openapi()`. The dashboard consumes THIS surface (API-before-UI). Correlation-id headers `X-Trace-ID`/`X-Request-ID` are part of the contract (`expose_headers`). Notable router families beyond the prior set: `capabilities` (`:263`), `autonomy` (`:256`), `autonomy_incidents` (`:260`), `intake` (`:266`), `chat` (`:267`), `delegations`.

### 3.5 The 6 extension-registry default YAMLs (+ autonomy)

Extension points (`temporal/olympus_workflows/registries/`) and their default sources:

| # | Extension point | Registry file | Default data |
|---|---|---|---|
| 1 | Assembly Line Registry | `assembly_line.py` | `olympus-contracts` 12 assembly-line YAMLs (via `list_lines`) |
| 2 | Disposition Strategy Registry | `disposition.py` | `registries/defaults/dispositions.yaml` |
| 3 | Analysis Pass Registry | `analysis_pass.py` | code defaults: `register_default_passes()` — no standalone `defaults/` YAML |
| 4 | Scoring Dimension Registry | `scoring_dimension.py` | `registries/defaults/scoring-dimensions.yaml` |
| 5 | Gate Provider Interface | `gate_provider.py` | `registries/defaults/gate-providers.yaml` |
| 6 | Skill Composition Model | `skill_composition.py` | `registries/defaults/skill-compositions.yaml` |
| (catalog) | Loop-Pattern catalog (P10-S18.1) | `loop_pattern.py` | `registries/defaults/autonomy.yaml` |

So `registries/defaults/` now contains **5** YAML files (`ls`): `dispositions.yaml`, `scoring-dimensions.yaml`, `gate-providers.yaml`, `skill-compositions.yaml`, **`autonomy.yaml`**. The assembly-line defaults live in the contracts package (Phase 1 payload); analysis-pass defaults are registered in code. `loop_pattern.py` is a **catalog of continuous-loop patterns** (dependency-sweep, cve-triage, error-triage, ci-repair), NOT a 7th extension point — the 6 extension points are unchanged. **GOTCHA:** the autonomy defaults NEVER fail open — `autonomy.yaml` header (`:1-20`) documents `default_level: report_only`, `deny_by_default: true`, empty `auto_merge_allowlist`; a Python constant alongside the resolver is the authoritative fallback so a missing file cannot fail the gate open. Shared substrate: `engine.py` (base registry), `worker_bootstrap.py` (registers all six at worker start), `profile_overrides.py` (profile-driven overrides layered atop defaults). **All extensions register through these — never edit core definitions directly.**

---

## 4. Quick reference — one-line gate per phase

```
P0  env       : python3.12 -c 'assert 3.12' && docker compose version && node --version
P1  contracts : pip install -e olympus-contracts && python -c 'import olympus_contracts; len(list_lines())==12' && bash schemas/validate.sh  → ALL VALIDATIONS PASSED (113/44/0)
P2a framework : python -c 'import all 6 registries + loop_pattern' && make validate-objectives && python scripts/check_doc_sync.py
P2b data      : docker compose run --rm db-migrate  → alembic head, linear, no branches (90 migrations)
P3  temporal  : cd temporal && AGENT_RUNTIME_MODE=mock APP_ENV=test pytest  (floor 80; signal-gate replay green)
P4  api       : cd olympus-api && pytest (floor 87) && python -c 'create_app(); app.openapi()'  (52 routers)
P4c caps/nl   : create_app() mounts /capabilities + autonomy + intake/chat routers; autonomy defaults fail-closed
P5  services  : pytest in olympus-worker(90), olympus-agent-runtime(90), mcp-server(90); cli imports
P6  dashboard : cd dashboard && npm ci && npm run lint && npm run build && npm test  (floors 81/70/76/78)
P7  packaging : docker compose build && make validate-schemas validate-objectives check-docs
P8  PARITY    : make demo-up (green+seed+smoke) AND workflow→G-DC→approve→completes AND npm run test:e2e
```
