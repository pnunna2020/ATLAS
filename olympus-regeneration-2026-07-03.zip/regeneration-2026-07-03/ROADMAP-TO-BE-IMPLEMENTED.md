# Olympus — Roadmap: To Be Implemented

> **Scope note.** This document is the *forward* roadmap — work that is **planned but not yet built**.
> It is deliberately kept SEPARATE from the rest of this regeneration spec set (docs 00–14), which is a
> **behavioral-parity** specification of the system *as it exists* at `origin/main @ 6c99bb6b`
> (2026-07-03). Those docs let an engineer rebuild what is there; THIS doc lists what still has to be
> added. Do not fold the two together — a regenerator rebuilds 00–14 to reach parity, then works this
> roadmap to move forward.

**Baseline reconciled against:** `origin/main` HEAD `6c99bb6b`; alembic head `091_create_error_signal`.
**Method:** every planned deliverable in Phase 9 and Phase 10 was classified BUILT / PARTIAL / NOT-STARTED
by verifying live code at HEAD (file + load-bearing symbol + merged-PR evidence), treating the plans'
`STATE.md` PROGRESS blocks as *builder claims* to be independently confirmed — not trusted.

---

## Executive summary

| Program | Status | Remaining |
|---|---|---|
| **Phase 9 — Autonomous Operations (W17)** | ✅ **fully built** (S17.1–S17.6) | none |
| **Phase 9 — Capability Services (W18)** | ✅ **fully built** (S18.1–S18.9) | none |
| **Phase 10 — Platform Productization** | **10 of 13 built** | **W4, W8, W12** (backends) + **U2, U5, U6** (UI pages) |
| **Beyond Phase 10** | — | **nothing planned**; only W13 multi-customer isolation is deferred by design (DECISION-022, demand-gated) |

> ⚠️ The Phase-9 backlog markdown files still read "Not started" in places — that is **stale**. PRs #93 and
> #130–#143 landed all of W17 + W18; the autonomy executors (`workflows/{dependency_sweep,cve_triage,ci_repair,error_triage}.py`)
> and the capability services (`olympus-api/src/services/capabilities/`) are on `main`. See docs
> `03-workflows/*` and `14-capabilities-nl-autonomy.md` for their as-built behavior.

**Net remaining roadmap = 3 backend deliverables (W4, W8, W12) + 3 UI pages (U2, U6 buildable now; U5 blocked on W12).**
Everything else across Phases 9–10 is on `main`.

---

## The three backend gaps (all Phase 10, all the "agent-orchestration loops" workstream)

Each has a **complete, autonomous-build-ready spec already written** under `specifications/phase-10/specs/`
(7-section format: Intent / Constitution / EARS requirements / code-graded acceptance / copy-pasteable
`/goal` Definition of Done / test plan / out-of-scope). This roadmap does **not** duplicate them — it points
to them and records the verified gap. Build order follows the Phase-10 wave graph.

### W4 — skill-evolution-loop-closure  *(Wave 1)*
- **Spec:** `specifications/phase-10/specs/skill-evolution-loop-closure-delta.md`
- **Gap (verified):** the Governance sweep emits a `skill-evolution.json` proposal that **nothing consumes**,
  and `services/skill.py::create_skill` writes no dispatchable artifact. `activities/line_transitions/governance.py`
  has 5 `_extract_*` side-effect handlers — **none for skill-evolution**. No `skill-evolution` source_type in
  `models/feedback.py`; no `services/skill_evolution*`; no `tests/skill_evolution/`.
- **What to build:**
  - **REQ-SE-001/002** — `_extract_skill_evolution_side_effects` in `governance.py` → normalize each proposal
    into a `feedback_item` with a new additive `skill-evolution` `source_type`, `status='pending_review'`
    (**never** auto-approve — LOAD-BEARING).
  - **REQ-SE-003/006** — a **pure** proposal-quality predicate → structured APPROVE/REJECT; a bad proposal
    surfaces as needs-fix, never silently dropped.
  - **REQ-SE-004/005/007** — on `/approve`, scaffold `SKILL.md` + `registry.yaml` entry + line-README row on a
    branch, open a PR, stamp `promotion_ref`; the scaffold must pass `scripts/validate_skill_registry.py`.
    **Human merges — no auto-merge** (LOAD-BEARING).
  - **REQ-SE-008 (UI)** — EXTEND the existing `dashboard/src/pages/feedback/` triage page to render the
    skill-evolution `source_type` + the `promotion_ref` PR link. *Not* a new page/UI spec.
- **Surfaces:** API (extends `/approve`), UI (extends existing feedback-triage page, phase-8 U7). No CLI/MCP.
- **DoD anchor:** `skill-evolution-loop-closure-delta.md` §5 (load-bearing: `test_no_auto_approve.py`,
  `validate_skill_registry.py` on the scaffold, `test_human_merges.py`).
- **Depends on:** phase-8 feedback queue (present); no new migration unless a column is needed.

### W8 — verify-loop-primitive  *(Wave 2)*
- **Spec:** `specifications/phase-10/specs/verify-loop-primitive-delta.md`
- **Gap (verified):** the Ralph Loop exists **only** inside `workflows/generate_bc.py` (the substrate,
  `MAX_RALPH_ITERATIONS`). `workflows/base.py` has `gate_approved/rejected/escalation_resolved` signal handlers
  but **no reusable verify-loop helper, no structured verdict, no application beyond Generate**.
- **What to build:**
  - **REQ-VL-001/003** — a reusable verify-loop helper on `LineWorkflowBase`: reject→iterate, approve→exit.
  - **REQ-VL-002** — a `VerifyVerdict` enum in `olympus-contracts` with `APPROVE / REJECT / ESCALATE`.
  - **REQ-VL-004** — cap exhausted without APPROVE → durable escalation (WAITING_FOR_SIGNAL, resolves on
    `escalation_resolved`).
  - **REQ-VL-005 (LOAD-BEARING)** — verifier skill is **always distinct** from the maker skill; equal
    `skill_id`s rejected.
  - **REQ-VL-006** — migrate Generate onto the helper with **behavior parity** (golden test).
  - **REQ-VL-007 (LOAD-BEARING)** — demonstrate on **≥1 line other than Generate**.
  - **REQ-VL-008/009** — preserve Temporal determinism; project each iteration's verdict to
    `step_execution.payload.verify_verdict` (no schema change).
- **Surfaces:** internal only — the sole surface is **observability** (verdict on `step_execution.payload`).
  A dedicated verdict-history table is a named follow-on, not part of this delta.
- **DoD anchor:** `verify-loop-primitive-delta.md` §5 (load-bearing: `test_verifier_not_maker.py`,
  `test_second_line_adopts.py`).
- **Depends on:** Ralph Loop substrate in `generate_bc.py` (present). No migration.

### W12 — agent-cost-rollup-governance-events  *(Wave 3)*
- **Spec:** `specifications/phase-10/specs/agent-cost-rollup-governance-events-delta.md`
- **Gap (verified):** **no cost-rollup endpoint** in any router (all existing "rollup" hits are cATO /
  target-state, unrelated). `services/event_outbox.py` has **zero** governance/sweep triggers (only the
  pre-existing on-demand `POST /sweep` + cron). Two disjoint closures on already-landed substrate:
- **What to build:**
  - **REQ-CR-001/002** — read-only `GET /api/v1/agent-cost/rollup` aggregating `ai_work_log` into per-app /
    per-portfolio token+cost totals (join `agent_task`→`application`→portfolio); totals **reconcile** to raw rows.
  - **REQ-CR-003 (LOAD-BEARING)** — **visibility only**: NO budget guard / kill-switch / throttle; no cost total
    halts anything (explicit negative test).
  - **REQ-CR-004** — read-only over the append-only `ai_work_log` (issues no writes).
  - **REQ-CR-005 (CLI)** — `olympus agent-cost rollup --portfolio <id> [--app <id>]` over the endpoint.
  - **REQ-GE-001/002/003 (LOAD-BEARING)** — enqueue a governance-trigger event on the EXISTING outbox at
    designated state changes (in-txn); a drain sink starts a sweep via the existing `start_governance_sweep`
    path; **idempotent** (same event drained twice → no duplicate sweep).
  - **REQ-GE-004 (LOAD-BEARING)** — KEEP the existing cron schedule; both cron and event paths can start a sweep.
  - **U5 (UI)** — the agent-cost dashboard page (see UI section).
- **Surfaces:** API (primary), CLI, UI (**U5**). MCP optional/not load-bearing. Governance enqueue/drain is
  service-internal.
- **DoD anchor:** `agent-cost-rollup-governance-events-delta.md` §5 (load-bearing: `test_no_throttle.py`,
  `test_drain_starts_sweep.py`, `test_cron_kept.py`).
- **Depends on:** `ai_work_log` (mig 069, present), event outbox (`services/event_outbox.py`, present),
  governance cron + sweep-start (present).

---

## UI pages still to build (U1–U6 status)

`●` built · `○` not built. All 6 UI delta-specs exist under `specifications/phase-10/ui/`.

| UI spec | Backend | Page built? | Evidence / gap |
|---|---|---|---|
| **U1** ui-nl-action-console | W6 | ● | `dashboard/src/pages/nl-console/` (+ agentic tool-use, PR #152) |
| **U2** ui-provenance-panel | W1 | ○ | Backend + MCP shipped (`routers/runs.py` provenance endpoint); **panel UI never built. Buildable now.** |
| **U3** ui-scoped-line-launch | W9 | ● | `dashboard/src/pages/ScopedLineLaunch/` |
| **U4** ui-delegation-management | W10 | ● | `dashboard/src/pages/delegation-management/` |
| **U5** ui-agent-cost | W12 | ○ | **Blocked** — W12 backend itself is unbuilt (build W12 first). |
| **U6** ui-layered-profile | W11 | ○ | Backend + CLI shipped (`services/layer_resolution.py`); **effective-profile view never built. Buildable now** (spec cites extending `Admin/ProfileComparison.tsx`). |

*(Bonus, already built beyond the U-list: the Phase-9 S17.5 autonomy-ops dashboard `dashboard/src/pages/autonomy-ops/`.)*

**Immediately buildable UI (backend ready):** U2 (provenance panel), U6 (layered-profile view).
**Blocked UI:** U5 (agent-cost) — gated on W12.

---

## Recommended build order

Following the Phase-10 foundation-first wave graph and the verified dependencies:

1. **W4** (Wave 1) — independent; closes the skill-evolution dead-end. Ships with its UI extension.
2. **W8** (Wave 2) — independent; internal primitive. No UI.
3. **W12** (Wave 3) — independent; then **U5** on top of it.
4. **U2** and **U6** — can be built any time (their backends are live); good parallel fill-in work.

All three backends are in the same "agent-orchestration loops" workstream (originally Pattabhi's column) and
were simply never picked up — none has a blocking dependency on the others.

---

## Beyond Phase 10

**There is no Phase 11** — no `specifications/phase-11*` dir, spec, or plan exists. `implementation-plan.md`
documents Phases 0–4 only (the original core plan; Phases 5–10 live in their own `specifications/phase-N/`
dirs). The single genuinely-deferred forward item is:

- **W13 — Multi-customer isolation** — **design-only, deferred by demand.** Captured as **DECISION-022**
  (`specifications/decisions.md`, status *Deferred, demand-gated*) + the design doc
  `specifications/phase-10/multi-customer-isolation-design.md`. DECISION-009 (single-tenant) still stands;
  the interim customer boundary is deployment-per-customer. The recommended first increment when demand fires
  is database-per-tenant (Option B). **Next step is human architecture-owner ADR acceptance — not an
  autonomous build.**

---

*Generated 2026-07-03 alongside the atomic regeneration spec (docs 00–14). Reconciliation evidence: live code
at `6c99bb6b` + merged PRs #93, #116–#127, #130–#143, #152.*
