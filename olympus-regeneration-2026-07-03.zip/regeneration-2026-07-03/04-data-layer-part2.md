# 04 — Data Layer (Part 2 of 3): Core Domain Tables

> Column catalog for the core entity + workflow + analytics tables. Types are
> SQLAlchemy → Postgres. `PK` = primary key; all `id` UUID PKs default
> `gen_random_uuid()`. All `created_at`/`updated_at` are `TIMESTAMPTZ NOT NULL
> DEFAULT now()` unless noted. "Added" cites the migration that introduced the
> column. See Part 1 §2.1 for the migration ledger and §3 for enum value sets.

---

## portfolio (`002`)

| Column | Type | Null | Default | Notes / Added |
|---|---|---|---|---|
| id | UUID | PK | gen_random_uuid() | 002 |
| name | String(255) | no | — | 002 |
| owner | String(255) | no | — | 002 |
| created_at | TIMESTAMPTZ | no | now() | 002 |
| updated_at | TIMESTAMPTZ | no | now() | 002 |
| status | String(50) | no | `active` | 002 |
| artifact_repo_url | Text | yes | — | **008** |
| profile_id | Text | yes | — | **079** |

## wave (`002`)

| Column | Type | Null | Default | Notes / Added |
|---|---|---|---|---|
| id | UUID | PK | gen_random_uuid() | 002 |
| portfolio_id | UUID | no | — | FK→portfolio.id **ON DELETE CASCADE** (002) |
| wave_number | Integer | no | — | 002 |
| status | String(50) | no | `draft` (was `planned`) | CHECK `wave_status_lifecycle_chk`, see Part 1 §4.1 |
| planned_start / planned_end / actual_start / actual_end | Date | yes | — | 002 |
| name | String(255) | yes | — | **006** |
| created_at | TIMESTAMPTZ | no | now() | 006 |
| updated_at | TIMESTAMPTZ | no | now() | 006 |
| workflow_id | String(255) | yes | — | **007** (`ix_wave_workflow_id`) |
| description | Text | yes | — | **041** |
| failed_at | TIMESTAMPTZ | yes | — | **043** |
| failure_reason | Text | yes | — | **043** |
| architecture_workflow_id | String(255) | yes | — | **054** |

## application (`002`) — the projection-heavy table

Core columns (002): `id` UUID PK; `portfolio_id` UUID FK→portfolio **CASCADE**;
`name` String(255); `repo_url` Text; `business_domain` String(255); `owner`
String(255); `current_line` `assembly_line_enum`; `current_step` String(100);
`current_status` String(50); `risk_tier` `risk_tier_enum`; `risk_tier_source`
`tier_source_enum`; `complexity_tier` `complexity_tier_enum`;
`complexity_tier_source` `tier_source_enum`; `decomposition_map` JSONB;
`user_context` JSONB; `ux_assessment` JSONB; `disposition` `disposition_enum`;
`user_impact` JSONB; `wave_assignment` Integer; `analyzed_commit_sha` String(40);
`created_at`/`updated_at` TIMESTAMPTZ.

Added columns by migration (all nullable unless noted):

| Column(s) | Type | Added |
|---|---|---|
| source_git_token, source_git_base_url | Text | 009 |
| workflow_id | String(255) | 010 |
| description, target_repo_url, target_git_token, target_git_base_url | Text | 016 |
| archetype | `archetype_enum` | 021 |
| archetype_source | `tier_source_enum` | 021 |
| portfolio_score | JSONB | 024 |
| **Discovery**: tech_stack, size_metrics, architecture, business_logic, quality, tco | JSONB | 028 |
| safety_tier | String(8) | 028 |
| **Rationalization**: disposition_source | String(16) | 029 |
| disposition_rationale_ref | Text | 029 |
| **Architecture**: architecture_blueprint_ref | Text | 030 |
| architecture_pattern | String(32) | 030 |
| architecture_decided_at | TIMESTAMPTZ | 030 |
| source_app_ids | `ARRAY(UUID)` | 030 |
| **Data**: data_architecture_ref, data_migration_plan_ref | Text | 031 |
| data_decided_at | TIMESTAMPTZ | 031 |
| data_pattern | String(32) | 031 |
| data_domains | JSONB | 031 |
| data_current_status | String(64) | 031 |
| **Modernization**: extraction_ref, design_ref | Text | 032 |
| extraction_at, design_at, generate_at | TIMESTAMPTZ | 032 |
| bounded_contexts, generated_module_refs | JSONB | 032 |
| modernization_pattern | String(32) | 032 |
| modernization_current_status | String(64) | 032 |
| **Disposition**: disposition_output_ref | Text | 034 |
| disposition_completed_at | TIMESTAMPTZ | 034 |
| disposition_current_status | String(64) | 034 |
| cost_savings_annual_usd | Numeric(12,2) | 034 |
| **Validation**: validation_parity_score | Numeric(5,2) | 035 |
| validation_critical_vuln_count | Integer | 035 |
| validation_accessibility_score | Numeric(5,2) | 035 |
| validation_safety_case_ref | Text | 035 |
| validation_completed_at | TIMESTAMPTZ | 035 |
| validation_current_status | String(64) | 035 |
| **Deployment**: deployed_at, legacy_decommissioned_at | TIMESTAMPTZ | 036 |
| deployment_env | String(64) | 036 |
| cutover_strategy | String(32) | 036 |
| parallel_run_duration_days | Integer | 036 |
| cost_savings_realized_usd, license_reclamation_usd | Numeric(12,2) | 036 |
| deployment_current_status | String(64) | 036 |
| **Sustainment**: sustainment_current_status, sustainment_last_sweep_at | (see 037) | 037 |
| **metadata** | JSONB **NOT NULL DEFAULT `'{}'::jsonb`** | **051** |
| target_service_id | String(64) | 053 |
| profile_id | Text | 079 |

**GOTCHA (`metadata` column name).** `application.metadata` (051) collides with
SQLAlchemy's reserved `MetaData` attribute name; the ORM model must map it to a
differently-named Python attribute (`metadata_` / column override). It is the only
NOT-NULL JSONB with a server default (`'{}'::jsonb`). Merged via
`_merge_application_metadata` (Part 1 §5.1); dashboard reads namespaces defensively
(missing → "unknown").

Indexes (005): `ix_application_portfolio_id`, `ix_application_current_status`,
`ix_application_disposition`, `ix_application_risk_tier`. Plus partial
`WHERE current_status='consolidated_into_target'` index (047).

## wave_application (`002`) — junction

`wave_id` UUID FK→wave **CASCADE** (PK), `application_id` UUID FK→application
**CASCADE** (PK). Composite PK.

---

## gate (`003`)

| Column | Type | Null | Default | Notes / Added |
|---|---|---|---|---|
| id | UUID | PK | gen_random_uuid() | 003 |
| gate_type | `gate_type_enum` | no | — | 003 |
| portfolio_id | UUID | no | — | FK→portfolio **CASCADE** (003) |
| application_id | UUID | **yes** (was no) | — | FK→application **CASCADE**; made nullable in **042** |
| status | `gate_status_enum` | no | `pending` | 003; `ix_gate_status` |
| requested_at | TIMESTAMPTZ | no | now() | 003 |
| decided_at | TIMESTAMPTZ | yes | — | 003 |
| decided_by | String(255) | yes | — | 003 |
| justification | Text | yes | — | 003 |
| retry_count | Integer | no | 0 | 003 |
| workflow_id | String(255) | yes | — | 011 |
| sla_deadline | TIMESTAMPTZ | yes | — | 011 |
| evidence_package_url | Text | yes | — | 011 |
| evidence_data | JSONB | yes | — | 012 |
| reject_reason_category | Text | yes | — | 020 |
| merge_failure_detail | JSONB | yes | — | 040 |
| wave_id | UUID | yes | — | FK→wave; added **042**; `ix_gate_wave_id` |
| minimum_approvals | Integer | no | 1 | 062 |
| oversight_role | String(64) | yes | — | 062 |
| management_override_allowed | Boolean | no | true | 062 |

CHECK `gate_application_or_wave_ck` (042): exactly one of application_id / wave_id
set (Part 1 §4.2). Indexes (003/005): `ix_gate_application_id`, `ix_gate_gate_type`.

## agent_task (`003`)

Core (003): `id` UUID PK; `task_type` String(100); `application_id` UUID FK→application
**CASCADE** (nullable since 044); `module_name` String(255); `status`
`task_status_enum` DEFAULT `queued`; `agent_backend` String(100); `agent_session_id`
String(255); `model_requested`/`model_used`/`model_source` String(100);
`dispatched_at`/`completed_at` TIMESTAMPTZ; `duration_ms` BigInteger; `retry_count`
Integer DEFAULT 0; `last_error` Text; `input_artifact_refs` JSONB;
`output_artifact_ref` Text; `token_usage` JSONB; `cost_estimate` Numeric.

Metrics cols (027): `agent_id` String(100); `skill_id` String(150); `workflow_id`
String(255); `started_at` TIMESTAMPTZ (backfilled from dispatched_at); `input_tokens`,
`output_tokens`, `cache_read_tokens`, `cache_write_tokens` Integer; `quality_score`
Numeric(3,2); `error_code` String(100); `artifact_id` UUID. Indexes on
`(agent_id, started_at DESC)`, `(skill_id, started_at DESC)`,
`(application_id, started_at DESC)`, etc. Creates the `agent_benchmark` VIEW.

Human-paired-agent cols (050): `actor_kind` String(32) NOT NULL DEFAULT
`olympus_agent`; `human_user_id` String(255); `local_agent_descriptor` JSONB.
CHECKs: `agent_task_actor_kind_chk` = `actor_kind IN ('olympus_agent','human',
'human_with_agent')`; `agent_task_actor_kind_human_id_chk` =
`(actor_kind='olympus_agent' AND human_user_id IS NULL) OR (actor_kind IN
('human','human_with_agent') AND human_user_id IS NOT NULL)`.

Wave-scope (044): `wave_id` UUID FK→wave; CHECK `agent_task_application_or_wave_ck`
(exactly one of application_id/wave_id). Provider (064): `provider_name`,
`provider_fallback_from` String(64).

Indexes (005): `ix_agent_task_status`, `ix_agent_task_application_id`,
`ix_agent_task_task_type`.

### agent_benchmark VIEW (`027`, `CREATE OR REPLACE VIEW`)

`GROUP BY agent_id, skill_id` over `agent_task WHERE agent_id IS NOT NULL`. Columns:
`sample_count`; `terminal_count` (status IN completed/failed/timed_out);
`success_count`/`failure_count`/`timeout_count`; `success_rate` (=completed/terminal,
NULL when terminal=0); `avg_duration_ms`; `p50_duration_ms`/`p95_duration_ms`
(`percentile_cont … WITHIN GROUP (ORDER BY duration_ms) FILTER (WHERE duration_ms IS
NOT NULL)`); `avg_input_tokens`/`avg_output_tokens`; `avg_quality_score`;
`total_cost_estimate`/`avg_cost_estimate`; `first_seen_at`/`last_seen_at` (MIN/MAX
started_at).

## escalation (`003`)

`id` UUID PK; `type` `escalation_type_enum` NOT NULL; `severity`
`escalation_severity_enum` NOT NULL; `application_id` UUID FK→application **CASCADE**;
`line` `assembly_line_enum`; `step`/`skill` String(100); `agent` String(255);
`trigger_type` String(100); `trigger_details` JSONB; `status` `escalation_status_enum`
DEFAULT `open`; `resolver` String(255); `resolution_type` String(100); `resolution`
JSONB; `pattern_extracted` Boolean NOT NULL DEFAULT false; `pattern_id` String(255);
`created_at`/`updated_at` TIMESTAMPTZ. Indexes: `ix_escalation_status`,
`ix_escalation_application_id`.

---

## Analytics tables (`004`)

### model_config
`id` UUID PK; `task_type` String(100) NOT NULL **UNIQUE**; `default_model`
String(100) NOT NULL; `default_model_tier` String(50); `recommended_alternatives` JSONB.

### model_override
`id` UUID PK; `application_id` UUID FK→application **CASCADE**; `task_type`
String(100) NOT NULL; `model` String(100) NOT NULL; `rationale` Text; `created_at`
TIMESTAMPTZ; `created_by` String(255).

### score_history
`id` UUID PK; `application_id` UUID FK→application **CASCADE**; `dimension`
String(100) NOT NULL; `score` Numeric NOT NULL; `recorded_at` TIMESTAMPTZ DEFAULT
now(); `source_artifact` Text; `governance_cycle` String(100). Indexes (005):
`ix_score_history_app_recorded (application_id, recorded_at)`,
`ix_score_history_dimension`.

### traceability_link
`id` UUID PK; `app_id` UUID FK→application **CASCADE**; `source_artifact` Text NOT
NULL; `source_element` Text; `source_version` String(100); `target_artifact` Text NOT
NULL; `target_element` Text; `target_version` String(100); `relationship` String(100)
NOT NULL; `produced_by` JSONB; `validated_at` JSONB; **`producing_skill` String(150)**
(078). Indexes (005): app_id, source_artifact, target_artifact.

### audit_log
`id` UUID PK; `timestamp` TIMESTAMPTZ DEFAULT now(); `actor` String(255) NOT NULL;
`actor_type` `actor_type_enum` NOT NULL; `action` String(100) NOT NULL;
`resource_type` String(100) NOT NULL; `resource_id` String(255) NOT NULL; `details`
JSONB; `ip_address` String(45). Indexes: `(resource_type, resource_id)`, `timestamp`.

---

## chat_message (`014`)

`id` UUID PK; `gate_id` String(255) (indexed); `app_id` String(255) (indexed);
`context_type` String(50) NOT NULL (`"gate"|"application"|"portfolio"`); `context_id`
String(255) NOT NULL (indexed); `role` String(20) NOT NULL (`"reviewer"|"agent"`);
`content` Text NOT NULL; `sources` JSONB (`[{artifact, section, finding_id}]`);
`model_used` String(100); `token_usage` JSONB (`{input, output}`); `created_at`
TIMESTAMPTZ DEFAULT now(). Index `ix_chat_message_context (context_type, context_id)`.
**GOTCHA:** gate_id/app_id/context_id are **String, not UUID FK** — chat is stored
loosely-typed and un-cascaded.

## skill (`015`)

`id` UUID PK; `skill_id` String(100) NOT NULL **UNIQUE**; `name` String(255) NOT NULL;
`description` Text; `category` String(100); `assembly_line` String(100);
`enrichment_level` String(20) NOT NULL DEFAULT `minimal`; `model_tier` String(20);
`source` String(50) NOT NULL DEFAULT `core`; `content` Text; `status` String(20) NOT
NULL DEFAULT `active`; `created_at`/`updated_at` TIMESTAMPTZ. Indexes: `ix_skill_skill_id`,
`ix_skill_assembly_line`, `ix_skill_status`.

Structured cols via raw `ALTER TABLE` (017): `system_prompt` TEXT; `references_data`
JSONB DEFAULT `'{}'`; `assets_data` JSONB DEFAULT `'{}'`; `config_data` JSONB DEFAULT
`'{}'`; `allowed_tools` JSONB DEFAULT `'[]'`; `dispatch_ids` JSONB DEFAULT `'[]'`;
`skill_path` TEXT; + `ix_skill_dispatch_ids` **GIN** index. `scripts_data` JSONB
DEFAULT `'{}'` (018). `bundled_resources` JSONB DEFAULT `'{}'` (067).

## user_account (`026`)

`id` UUID PK; `username` String(150) NOT NULL; `email` String(255) NOT NULL;
`full_name` String(255); `password_hash` String(255) (NULL for OIDC users);
`identity_provider` String NOT NULL DEFAULT `'local'` (or `"oidc:<provider>"`);
`external_id` String(255); `roles` JSONB NOT NULL DEFAULT `'["viewer"]'::jsonb`;
`is_active` Boolean NOT NULL DEFAULT true; `last_login_at` TIMESTAMPTZ;
`created_at`/`updated_at` TIMESTAMPTZ.
Partial unique indexes (all `WHERE is_active = true` except the last):
`uq_user_email_active (email)`, `uq_user_username_active (username)`,
`uq_user_external_identity (identity_provider, external_id) WHERE external_id IS NOT
NULL`, plus `ix_user_identity_provider`. **GOTCHA:** table is **`user_account`**, not
`user` (reserved word).

## step_execution (`033`) — Layer B execution envelope

**PK is `execution_id`** (UUID, gen_random_uuid()) — NOT `id`. Columns: `app_id` UUID
(nullable); `wave_id` UUID (nullable); `portfolio_id` UUID NOT NULL; `line_id`
String(64) NOT NULL; `step_id` String(128) NOT NULL; `step_kind`
`step_execution_kind_enum` NOT NULL; `status` `step_execution_status_enum` NOT NULL;
`started_at` TIMESTAMPTZ; `completed_at` TIMESTAMPTZ; `duration_ms` BigInteger;
`attempt` Integer NOT NULL DEFAULT 1; `last_error` Text; `input_artifacts` JSONB NOT
NULL DEFAULT `'[]'::jsonb`; `output_artifacts` JSONB NOT NULL DEFAULT `'[]'::jsonb`;
`payload` JSONB NOT NULL DEFAULT `'{}'::jsonb`; `workflow_id` String(255) NOT NULL;
`agent_task_id` UUID FK→agent_task **ON DELETE SET NULL**; `gate_id` UUID.
CHECKs: `step_execution_agent_fk_ck` = `(step_kind = 'agent') = (agent_task_id IS NOT
NULL)`; `step_execution_gate_fk_ck` = `(step_kind = 'gate') = (gate_id IS NOT NULL)`.
Indexes: `(workflow_id, line_id, step_id)`, `(app_id, line_id)`, partial
`(wave_id, line_id) WHERE wave_id IS NOT NULL`, partial `(agent_task_id) WHERE
agent_task_id IS NOT NULL`.

## Governance tables (`025`)

- **health_check**: `id` UUID PK; `portfolio_id` UUID (nullable, no FK); `date` Date
  NOT NULL; `health_index` Numeric(4,3) NOT NULL; `checks` JSONB NOT NULL DEFAULT
  `'[]'::jsonb`; `created_at` TIMESTAMPTZ.
- **drift_alert**: `id` UUID PK; `type` String(100) NOT NULL; `application_id` UUID
  FK→application **CASCADE** (nullable); `details` JSONB; `acknowledged` Boolean NOT
  NULL DEFAULT false; `acknowledged_by` String(255); `acknowledged_at` TIMESTAMPTZ;
  `created_at` TIMESTAMPTZ.
- **pattern** (025:94-122): `id` UUID PK; `name` String(255) NOT NULL; `category`
  String(100) NOT NULL; `description` Text; `wave_id` UUID (nullable, no FK);
  `source_apps` JSONB NOT NULL DEFAULT `'[]'::jsonb` (025:107-111); `reuse_count` Integer
  NOT NULL DEFAULT 0; `content` JSONB; `created_at` TIMESTAMPTZ. Indexes:
  `ix_pattern_category`, `ix_pattern_wave_id`.

## Architecture / Data / Modernization lineage tables

- **application_lineage** (030): `target_app_id` UUID FK→application **CASCADE**,
  `source_app_id` UUID FK→application **CASCADE**, `relationship` String(32) NOT NULL,
  `created_at` TIMESTAMPTZ DEFAULT NOW(), `retired_at` TIMESTAMPTZ. PK
  `(target_app_id, source_app_id)` = `application_lineage_pkey`. Index on source_app_id.
- **shared_db_cluster** (031): `target_app_id` UUID FK→application **CASCADE**,
  `cluster_id` String(128) NOT NULL, `role` String(16) NOT NULL, `pattern` String(32)
  NOT NULL, `created_at`/`retired_at`. PK `(target_app_id, cluster_id)`. Index on cluster_id.
- **bounded_context** (032): `target_app_id` UUID FK→application **CASCADE**, `bc_name`
  String(128) NOT NULL, `status` String(32) NOT NULL, `ralph_iterations` Integer,
  `escalations` JSONB, `generated_path` Text, `created_at`/`updated_at`. PK
  `(target_app_id, bc_name)`. Index `(target_app_id, status)`.

## Sustainment tables (`037`)

Seven tables, all with `id` UUID PK + `portfolio_id` UUID NOT NULL + `sweep_id`
String(255):
- **patching_compliance**: critical/high/medium/low_open_count Integer DEFAULT 0,
  sla_compliance_pct, evaluated_at. Index `(portfolio_id, evaluated_at)`.
- **incident_log**: `app_id` UUID FK→application **SET NULL**; severity String(16);
  symptom String(255); status String(32); resolution_summary Text; recorded_at. Indexes
  `(portfolio_id, recorded_at)`, `(app_id)`.
- **sla_compliance_record** (037:156-209): `app_id` UUID FK→application **CASCADE**;
  availability_pct Numeric(5,3); `response_time_p95_ms` Numeric(10,2) nullable (037:178);
  incident_resolution_mean_hours Numeric(10,2); breach_count Integer DEFAULT 0;
  recorded_at TIMESTAMPTZ DEFAULT NOW(). Indexes `ix_sla_compliance_portfolio`
  `(portfolio_id, recorded_at)`, `ix_sla_compliance_app` `(app_id, recorded_at)`.
- **do_not_modify_flag**: `app_id` UUID FK→application **CASCADE**; flagged_at; wave_id;
  expires_at; `active` Boolean DEFAULT true; override_count. UNIQUE
  `(portfolio_id, app_id)` = `uq_do_not_modify_flag_portfolio_app`. Index
  `(portfolio_id, active)`.
- **cost_anomaly_record**: `app_id` FK→application; baseline_usd/observed_usd
  Numeric(14,2); variance_pct Numeric(7,2); `flagged` Boolean DEFAULT false; recorded_at.
- **sustainment_override_log**: `app_id`; gate_id String(255); override_by String(255)
  NOT NULL; justification Text; override_type String(64) NOT NULL; recorded_at.

Plus `application.sustainment_current_status` + `sustainment_last_sweep_at`.

## Governance sweep tables (`038`)

- **factory_capacity_plan** (038:47-76): `id` UUID PK; portfolio_id (nullable); sweep_id
  String(255) NOT NULL; concurrent_wave_max Integer; throughput_apps_per_month
  Numeric(10,2); cost_per_app_usd Numeric(12,2); gate_first_pass_rate Numeric(5,4);
  ralph_loop_iteration_avg Numeric(6,2); escalation_rate/pattern_reuse_rate/automation_ratio
  Numeric(5,4); time_to_modernize_days Numeric(8,2); `computed_at` TIMESTAMPTZ NOT NULL
  DEFAULT NOW() (038:71 — the trailing timestamp is **computed_at**, NOT recorded_at).
  Indexes `ix_factory_capacity_plan_portfolio_id` `(portfolio_id)`,
  `ix_factory_capacity_plan_computed_at` `(computed_at)`.
- **model_benchmark_result** (038:91-125): `id` UUID PK; portfolio_id; sweep_id
  String(255) NOT NULL; model_id String(255) NOT NULL; tier String(20) NOT NULL;
  task_suite String(255) NOT NULL; pass_rate Numeric(5,4); cost_per_call_usd
  Numeric(12,6); latency_p95_ms Integer; `regression_flag` Boolean NOT NULL DEFAULT false
  (038:108); `refresh_recommended` Boolean NOT NULL DEFAULT false (038:114);
  `benchmarked_at` TIMESTAMPTZ NOT NULL DEFAULT NOW() (038:120 — trailing timestamp is
  **benchmarked_at**, NOT recorded_at). Indexes `ix_model_benchmark_result_portfolio_id`
  `(portfolio_id)`, `ix_model_benchmark_result_model_id` `(model_id)`,
  `ix_model_benchmark_result_benchmarked_at` `(benchmarked_at)`.

> **Continue to Part 3** for capability-grain, delegation/bundle, evidence/control,
> drift, intent/decomp, catalog, eval, feedback, signal, and misc tables.
