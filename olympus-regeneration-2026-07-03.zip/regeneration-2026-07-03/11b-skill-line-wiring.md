# 11b. Skill Registry — Assembly-Line Dispatch Wiring

> Companion to `11-skill-registry.md`. Joins the `line`/`step` fields on every entry in `cross-cutting/skills/registry.yaml` to reconstruct the static step→skill→schema dispatch map. See `11-skill-registry.md` §11.0 for derivation and GOTCHAs.

## 11.4 Per assembly-line step → skill → schema wiring

**Wiring source (GOTCHA):** there are NO per-line `*.yaml` files — the 13 assembly lines under `assembly-lines/*/` are README.md prose. The machine-readable step→skill binding is the `line` + `step` field pair ON EACH registry entry (`cross-cutting/skills/registry.yaml`). The Extension-Point-6 runtime composition registry `temporal/olympus_workflows/registries/defaults/skill-compositions.yaml` ships EMPTY (`compositions: []`, `:9`) — compositions are registered at runtime by profiles (FAA registers `faa-profile-skills` via `profile_overrides.apply_profile`). Therefore the authoritative static step→skill map is reconstructed below from the registry `line`/`step` fields; the `schema` column is the skill's declared `output_schemas`.

Lines observed in registry (skill counts): Architecture 18 · Build 1 · Cross-Cutting 4 · Data 6 · Deployment 7 · Discovery 21 · Disposition Execution 22 · Governance 14 · Modernization 49 · Rationalization 16 · Reverse Engineering 1 · Sustainment 6 · Validation 8. (13 line-values; the framework names 10 lines + Build + Reverse Engineering + a Cross-Cutting bucket.)

### Discovery (21 skills · 20 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Pre-Discovery — Regulatory Knowledge Ingestion | `regulatory-knowledge-ingestion` (`:58`) | opus | — |
| Step 1 — Catalog | `catalog-application` (`:76`) | sonnet | `application-catalog-entry.json`→`schemas/discovery/catalog.schema.json` |
| Step 3 — Conditional image-corpus assessment | `tiff-corpus-assessor` (`:485`) | opus | — |
| Step 3 — Pass 1 (Application & Data Mapping — tech-stack patterns) | `discovery-patterns` (`:131`) | sonnet | — |
| Step 3 — Pass 1 (Application & Data Mapping) | `legacy-architecture-mapper` (`:120`) | opus | — |
| Step 3 — Pass 1 (data-flow tracing) | `legacy-data-flow-tracer` (`:384`) | opus | — |
| Step 3 — Pass 1 (database archaeology) | `legacy-database-archaeologist` (`:350`) | opus | — |
| Step 3 — Pass 1 (language detection + reader dispatch) | `legacy-language-reader` (`:334`) | sonnet | — |
| Step 3 — Pass 2 (Business Logic) | `legacy-business-rule-extractor` (`:169`) | opus | `business-logic.json`→`schemas/discovery/business-logic.schema.json` |
| Step 3 — Pass 3 (Quality & Risk) | `quality-risk-assessor` (`:266`) | sonnet | `quality-risk.json`→`schemas/discovery/quality-risk.schema.json` |
| Step 3 — Pass 4 (UX & Accessibility) | `accessibility-checker` (`:210`) | sonnet | — |
| ↳ | `ux-accessibility-assessor` (`:297`) | sonnet | `ux-accessibility.json`→`schemas/discovery/ux-accessibility.schema.json` |
| Step 3 — Pass 6 (Capability + System Grain) | `capability-extraction` (`:222`) | sonnet | `capability-catalog.json`→`schemas/discovery/capability-catalog.schema.json` |
| Step 3 — Portfolio identity pass (NIST 800-63 inventory) | `identity-landscape-analyzer` (`:424`) | opus | — |
| Step 3 — Regulatory citation scan (pre-Rationalization) | `compliance-citation-mapper` (`:442`) | sonnet | — |
| Step 3 — Requirements Discovery (Build mode, doc-driven) | `requirements-doc-ingester` (`:87`) | opus | `requirements-capability.json`→`schemas/build/requirements-capability.schema.json` |
| Step 3 — Requirements Discovery (Build mode, interview-driven) | `requirements-elicitation` (`:104`) | opus | `requirements-capability.json`→`schemas/build/requirements-capability.schema.json` |
| Step 4 — Dependency Mapping | `dependency-mapper` (`:180`) | opus | — |
| Step 5 — SRS derivation (pre-G-DC) | `srs-from-discovery` (`:504`) | opus | — |
| Step 5 — Synthesis | `discovery-synthesizer` (`:309`) | opus | `discovery-synthesis.json`→`schemas/discovery/discovery-synthesis.schema.json` |
| Step 5 — TCO Baseline | `tco-analyzer` (`:237`) | sonnet | — |

### Reverse Engineering (1 skills · 1 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Step 1/2 — Ingest (read-only) + Reconstruct Spec | `reverse-engineer-spec` (`:403`) | opus | — |

### Rationalization (16 skills · 16 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Capability Consolidation Advisory (post per-app disposition) | `capability-consolidation-advisor` (`:745`) | opus | `capability-consolidation-plan.json`→`schemas/rationalization/capability-consolidation-plan.schema.json` |
| Classification & Risk Tiering (sibling of classify-application) | `classify-complexity` (`:658`) | sonnet | — |
| Cross-App Business Rule Synthesis (pre-disposition) | `cross-app-business-rule-analyzer` (`:725`) | opus | `business-rule-redundancy.json`→`schemas/rationalization/business-rule-redundancy.schema.json` |
| On-demand — cost & effort estimation | `cocomo-cosmic-analysis` (`:249`) | — | — |
| Portfolio Integration Mapping (pre-disposition) | `portfolio-integration-mapper` (`:675`) | sonnet | `integration-graph.json`→`schemas/rationalization/integration-graph.schema.json` |
| Portfolio Manifest (final wave close-out) | `portfolio-manifest-generator` (`:764`) | opus | — |
| Portfolio Redundancy Synthesis (pre-disposition) | `analyze-portfolio-redundancy` (`:694`) | sonnet | `portfolio-redundancy-matrix.json`→`schemas/rationalization/rationalization-clustering-plan.schema.json` |
| Step 10 — Wave Planning | `sequencer` (`:618`) | opus | `wave-plan.json`→`schemas/rationalization/wave-plan.schema.json`<br>`wave-plan-validation.json`→`schemas/rationalization/wave-plan-validation.schema.json` |
| Step 1c — UX Overlap Analysis | `compare-ux-overlap` (`:549`) | opus | `ux-overlap-matrix.json`→`schemas/rationalization/ux-overlap-matrix.schema.json` |
| Step 5 — Disposition Recommendation | `disposition-recommender` (`:567`) | opus | `disposition-recommendation.json`→`schemas/rationalization/disposition-recommendation.schema.json` |
| Step 6 — Disposition Governance | `disposition-governance` (`:581`) | sonnet | `disposition-governance.json`→`schemas/rationalization/disposition-governance.schema.json` |
| Step 7 — User Impact Analysis | `assess-user-impact` (`:593`) | sonnet | `user-impact-analysis.json`→`schemas/rationalization/user-impact-analysis.schema.json` |
| Step 8 — Classification & Risk Tiering | `classify-application` (`:606`) | opus | `classification.json`→`schemas/rationalization/classification.schema.json` |
| Step 8 — Wave Outcome Synthesis | `wave-outcome-synthesizer` (`:640`) | opus | `wave-outcome-synthesis.json`→`schemas/rationalization/wave-outcome-synthesis.schema.json` |
| Step 9 — Portfolio Scoring | `portfolio-scorer` (`:537`) | opus | `portfolio-score.json`→`schemas/rationalization/portfolio-score.schema.json` |
| Steps 1a/1b — Cross-App & Intra-App Redundancy | `redundancy-analyzer` (`:525`) | opus | `redundancy-matrix.json`→`schemas/rationalization/redundancy-matrix.schema.json`<br>`intra-app-redundancy.json`→`schemas/rationalization/redundancy-matrix.schema.json` |

### Architecture (18 skills · 14 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Step 1 — Constraint Definition | `phase2-constraint-loader` (`:2661`) | sonnet | — |
| Step 1 — Target-State Mapping | `target-state-mapper` (`:784`) | opus | `architecture-target-plan.json`→`schemas/architecture/architecture-target-plan.schema.json` |
| Step 10 — Blueprint Assembly | `blueprint-assembly` (`:936`) | opus | `architecture-blueprint.json`→`schemas/architecture/architecture-blueprint.schema.json` |
| Step 10b — Cloud Cost Estimate | `cloud-cost-estimator` (`:1043`) | sonnet | `cost-estimate.json`→`schemas/architecture/cost-estimate.schema.json` |
| Step 10c — Well-Architected Review | `well-architected-reviewer` (`:1063`) | opus | `well-architected-review.json`→`schemas/architecture/well-architected-review.schema.json` |
| Step 10d — Traceability Validation (pre-G-02) | `architecture-traceability-validator` (`:1083`) | sonnet | — |
| Step 2 — Target Architecture Strategy | `migration-strategy-advisor` (`:803`) | opus | `cloud-pattern.json`→`schemas/architecture/cloud-pattern.schema.json` |
| ↳ | `deployment-topology` (`:1001`) | sonnet | — |
| Step 2b — Target Architecture Blueprint | `target-architecture-blueprint` (`:963`) | opus | — |
| Step 3 — EA Compliance Verification | `ea-compliance` (`:818`) | sonnet | `ea-compliance-report.json`→`schemas/architecture/ea-compliance.schema.json` |
| Step 4 — Integration Architecture | `api-contract-validator` (`:834`) | sonnet | `api-contract-compliance-report.json`→`schemas/architecture/integration-arch.schema.json` |
| ↳ | `event-contract` (`:847`) | sonnet | — |
| ↳ | `resilience-designer` (`:1022`) | opus | — |
| Step 6 — Security Architecture | `security-posture-analyzer` (`:878`) | opus | — |
| ↳ | `cato-compliance` (`:890`) | sonnet | `security-arch.json`→`schemas/architecture/security-arch.schema.json` |
| Step 7 — Design System Mapping | `design-system` (`:905`) | sonnet | `design-system.json`→`schemas/architecture/design-system.schema.json` |
| Step 8 — Accessibility Review | `accessibility-reviewer` (`:921`) | sonnet | `accessibility-review.json`→`schemas/architecture/accessibility-review.schema.json` |
| Step 9 — AI/ML Integration | `ai-ml-integration` (`:860`) | opus | `ai-ml-integration.json`→`schemas/architecture/ai-ml-integration.schema.json` |

### Data (6 skills · 6 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Reference-only (no dispatch) | `data-mesh-architecture` (`:1196`) | opus | — |
| Step 1 — Data Domain Discovery | `data-domain-patterns` (`:1107`) | opus | `data-domains.json`→`schemas/data/data-domains.schema.json` |
| Step 4 — Migration Planning | `data-migration-planner` (`:1130`) | opus | `data-migration-plan.json`→`schemas/data/data-migration-plan.schema.json` |
| Step 5 — Data Product Design | `data-product-specification` (`:1142`) | opus | `data-product-design.json`→`schemas/data/data-product-design.schema.json` |
| Step 6 — Data Architecture Synthesis | `data-modeling` (`:1172`) | opus | `data-architecture.json`→`schemas/data/data-architecture.schema.json` |
| Steps 2–3 — Shared-DB Analysis + Decomposition Strategy | `decomposition-patterns` (`:1118`) | opus | `decomposition-strategy.json`→`schemas/data/decomposition-strategy.schema.json` |

### Modernization (49 skills · 41 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| All gates | `gate-review-package` (`:1605`) | sonnet | — |
| Factory Configuration — test-data provisioning (Private Pilot scenario fan-out) | `gfi-pp-scenarios` (`:1420`) | sonnet | — |
| Step 1 — Extract | `extraction` (`:1212`) | opus | — |
| ↳ | `validation-rule-template` (`:2674`) | sonnet | — |
| Step 1 — Extract (UX flow derivation) | `ux-flow-derivation` (`:1299`) | opus | `ux-flow-inventory.json`→`schemas/modernization/ux-flow-inventory.schema.json` |
| Step 1 — Extract (UX page specification) | `ux-page-specification` (`:1316`) | opus | — |
| Step 1 — Extract (batch archetype) | `batch-extraction` (`:1239`) | opus | — |
| Step 1 — Extract (modern requirement harvest) | `requirement-aggregation` (`:1262`) | opus | — |
| Step 1 — Extract (rule reconciliation) | `business-rule-reconciliation` (`:1279`) | opus | — |
| Step 1 — Extract (validation pass) | `cross-validation` (`:1250`) | sonnet | — |
| Step 2 — Design | `module-design` (`:1337`) | opus | — |
| ↳ | `api-specification` (`:1377`) | sonnet | — |
| ↳ | `workflow-state-machine-template` (`:2693`) | sonnet | — |
| ↳ | `user-guide-generator` (`:2740`) | opus | — |
| ↳ | `smart-defaults-analyzer` (`:2762`) | sonnet | — |
| Step 2 — Design (Data Model — DDL authoring) | `target-schema-ddl` (`:1403`) | sonnet | — |
| Step 2 — Design (FAA Form 8710 validators) | `form-8710-validator` (`:2947`) | sonnet | — |
| Step 2 — Design (FAA form single-source schemas) | `faa-form-schema-generator` (`:2915`) | sonnet | — |
| Step 2 — Design (FAA medical class definitions) | `aerospace-medical-certification-mapper` (`:2931`) | opus | — |
| Step 2 — Design (FAA pilot cert schema) | `pilot-certification-domain-modeler` (`:2896`) | opus | — |
| Step 2 — Design (UX component specification) | `ux-component-specification` (`:1356`) | opus | — |
| Step 2 — Design (audit) | `traceability-audit` (`:1438`) | sonnet | — |
| Step 2 — Design (auth principal mapping) | `jwt-claim-mapper` (`:1638`) | sonnet | — |
| Step 2 — Design (batch archetype) | `batch-design` (`:1390`) | sonnet | — |
| Step 2 — Design (form conditional rules) | `form-rules-engine-scaffolder` (`:1655`) | sonnet | — |
| Step 3 — Generate | `gherkin-scenario-generator` (`:2715`) | sonnet | — |
| ↳ | `tdd-plan-writer` (`:2785`) | sonnet | — |
| ↳ | `faa-code-standards` (`:2854`) | — | — |
| ↳ | `faa-style-greenfield` (`:2866`) | — | — |
| Step 3 — Generate (AME decision workflow) | `ame-decision-workflow-scaffolder` (`:2980`) | sonnet | — |
| Step 3 — Generate (FSM scaffold) | `xstate-fsm-generator` (`:1692`) | sonnet | — |
| Step 3 — Generate (MedXPress integration) | `medxpress-confirmation-binder` (`:2963`) | sonnet | — |
| Step 3 — Generate (OIDC server config) | `oidc-server-integration` (`:1779`) | sonnet | — |
| Step 3 — Generate (Ralph Loop escalation) | `escalation-handler` (`:1594`) | sonnet | — |
| Step 3 — Generate (audit append-only) | `audit-immutability-trigger-generator` (`:1760`) | sonnet | — |
| Step 3 — Generate (batch archetype) | `batch-generation` (`:1537`) | sonnet | — |
| Step 3 — Generate (cATO evidence) | `oscal-fragment-emitter` (`:1798`) | sonnet | — |
| Step 3 — Generate (cross-context merge) | `code-synthesis` (`:1549`) | opus | — |
| Step 3 — Generate (durable workflow) | `temporal-workflow-scaffolder` (`:1672`) | sonnet | — |
| Step 3 — Generate (implementation — Ralph Loop step 2) | `code-generation` (`:1478`) | sonnet | — |
| Step 3 — Generate (infrastructure) | `iac-scaffolding-generator` (`:2824`) | sonnet | — |
| Step 3 — Generate (multi-section wizard) | `schema-driven-wizard-generator` (`:1743`) | sonnet | — |
| Step 3 — Generate (post-generation) | `spec-reviewer` (`:2806`) | opus | — |
| Step 3 — Generate (real-time push) | `sse-broadcaster-scaffolder` (`:1709`) | sonnet | — |
| Step 3 — Generate (review) | `adversarial-review` (`:1563`) | sonnet | — |
| Step 3 — Generate (security posture) | `security-posture-review` (`:1575`) | sonnet | — |
| Step 3 — Generate (test authoring — Ralph Loop step 1) | `tdd-generation` (`:1456`) | sonnet | — |
| Step 3 — Generate (test verification) | `test-validation` (`:1525`) | sonnet | — |
| Step 3 — Generate (transactional outbox) | `outbox-pattern-scaffolder` (`:1726`) | sonnet | — |

### Build (1 skills · 1 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Step 1 — Spec-from-Requirements | `spec-from-requirements` (`:1829`) | opus | `scenario-spec.json`→`schemas/build/scenario-spec.schema.json` |

### Validation (8 skills · 7 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Stream 1 — Functional Parity | `parity-verifier` (`:1848`) | sonnet | — |
| ↳ | `acceptable-divergences` (`:1859`) | sonnet | — |
| Stream 1 — Functional Parity (formal test plan, T1/T2 mandatory pre-G-V1) | `formal-test-plan-generator` (`:1967`) | sonnet | — |
| Stream 2 — Security & Compliance | `cato-evidence-validator` (`:1871`) | sonnet | — |
| Stream 2 — Security & Compliance (anomaly resolution, pre-G-V2) | `security-anomaly-resolution` (`:1943`) | opus | — |
| Stream 2 — Security & Compliance (scan triage) | `security-scan-review` (`:1925`) | sonnet | — |
| Stream 4 — Safety Assurance | `safety-critical-verifier` (`:1888`) | opus | — |
| Streams 1, 4 — Traceability | `traceability-checker` (`:1914`) | sonnet | — |

### Deployment (7 skills · 5 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Step 1 — Deployment Orchestration | `deploy-modernized-app` (`:1993`) | sonnet | — |
| Step 2 — Traffic Shifting | `traffic-shift` (`:2005`) | sonnet | — |
| Step 3 — Parallel Run | `parallel-run-monitor` (`:2017`) | sonnet | — |
| Step 4 — Adoption Verification | `adoption-analytics` (`:2028`) | sonnet | — |
| ↳ | `user-adoption-coordinator` (`:2040`) | sonnet | — |
| Step 5 — Legacy Decommission | `legacy-decommission` (`:2057`) | sonnet | — |
| ↳ | `environment-cleanup` (`:2069`) | sonnet | — |

### Disposition Execution (22 skills · 22 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Consolidate — Data Reconciliation Planning | `data-reconciliation-planning` (`:2169`) | sonnet | — |
| Consolidate — Enhancement Planning | `enhancement-planning` (`:2181`) | sonnet | — |
| Consolidate — Feature Gap Analysis | `feature-gap-analysis` (`:2157`) | sonnet | — |
| Consolidate — Target Selection | `target-selection` (`:2146`) | opus | — |
| Pre-cutover — Consumer Migration Planning | `consumer-migration-planning` (`:2111`) | sonnet | — |
| Pre-cutover — Data Archival Planning | `data-archival-planning` (`:2100`) | sonnet | — |
| Pre-cutover — User Transition Planning | `user-transition-planning` (`:2089`) | sonnet | — |
| Replace — Integration Specification | `integration-specification` (`:2204`) | sonnet | — |
| Replace — Requirements Derivation | `requirements-derivation` (`:2193`) | sonnet | — |
| Replace — Vendor/COTS Evaluation | `vendor-evaluation` (`:2123`) | opus | — |
| Replace/Replatform — Data Migration Planning | `data-migration-planning` (`:2252`) | sonnet | — |
| Replatform — Component Configuration | `component-configuration` (`:2228`) | sonnet | — |
| Replatform — Platform Selection | `platform-selection` (`:2135`) | opus | — |
| Replatform — Validation & Cut-over | `validation-cutover` (`:2240`) | sonnet | — |
| Replatform — Workflow Mapping | `workflow-mapping` (`:2216`) | sonnet | — |
| Retain — Documentation | `documentation-remediation` (`:2307`) | sonnet | — |
| Retain — Handoff | `sustainment-handoff` (`:2347`) | sonnet | — |
| Retain — Observability | `monitoring-bootstrap` (`:2334`) | sonnet | — |
| Retain — Quality | `test-coverage-uplift` (`:2321`) | sonnet | — |
| Retain — Security | `security-remediation-planning` (`:2293`) | sonnet | — |
| Retire — License Reclamation | `license-reclamation` (`:2274`) | sonnet | — |
| Retire — Security Decommission | `security-decommission` (`:2263`) | sonnet | — |

### Sustainment (6 skills · 3 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Activity 1 — O&M | `incident-response` (`:2363`) | sonnet | — |
| ↳ | `patch-assessment` (`:2375`) | sonnet | — |
| ↳ | `sla-breach-investigation` (`:2387`) | sonnet | — |
| ↳ | `faa-style-brownfield` (`:2878`) | — | — |
| Activity 2 — Coordination | `change-conflict-resolver` (`:2399`) | sonnet | — |
| Activity 3 — AIOps | `cost-anomaly-investigation` (`:2410`) | sonnet | — |

### Governance (14 skills · 7 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| Activity 1 — Health | `portfolio-health-check` (`:2425`) | sonnet | — |
| Activity 2 — Drift Detection | `drift-detection` (`:2469`) | sonnet | — |
| ↳ | `drift-detection-architecture` (`:2485`) | sonnet | — |
| ↳ | `drift-detection-compliance` (`:2496`) | sonnet | — |
| ↳ | `drift-detection-performance` (`:2509`) | sonnet | — |
| ↳ | `drift-detection-cost` (`:2520`) | sonnet | — |
| ↳ | `drift-detection-adoption` (`:2532`) | sonnet | — |
| Activity 5 — Pattern Extraction | `skill-builder` (`:2555`) | opus | — |
| Activity 5 — Skill Lifecycle | `decomposition-skill-writer` (`:2566`) | opus | — |
| ↳ | `skill-validator` (`:2584`) | sonnet | — |
| Activity 6 — Capacity | `factory-capacity-manager` (`:2447`) | opus | — |
| Activity 6 — Factory Analytics | `factory-health-check` (`:2436`) | sonnet | — |
| ↳ | `model-benchmark` (`:2544`) | opus | — |
| Activity 6 — Reporting | `wave-status-report` (`:2458`) | sonnet | — |

### Cross-Cutting (4 skills · 4 steps)

| step | skill(s) (`:LINE`) | agent | output_schema |
|---|---|---|---|
| All 15 gates | `gate-pre-review` (`:2619`) | sonnet | — |
| Client Onboarding — Profile Authoring | `profile-authoring` (`:2600`) | sonnet | — |
| Feature/blueprint decomposition (confirmed IntentRecord -> BlueprintHierarchy) | `decomposition-agent` (`:3016`) | opus | `blueprint-hierarchy.json`→`schemas/build/blueprint-hierarchy.schema.json` |
| Human-paired-agent dispatch + return | `olympus-collaboration` (`:2636`) | — | — |
