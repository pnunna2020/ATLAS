# 05 — Dashboard (Part 1): App Shell, Routing, State, API Layer, Design System

**Scope of this part (doc 05 part 1).** App-wide reproduction fidelity for the
`dashboard/` React + USWDS SPA: the complete route table (`App.tsx`), router
structure and providers, the `Layout` shell + `navConfig` + sidebar, the
state-management model (React contexts + `@tanstack/react-query` + polling
hooks + WebSocket), the API layer (`api/client.ts` + `api/*.ts` modules), demo
mode, and the USWDS design-token / branding system precisely enough to
reproduce the look. **Per-page deep-dives (props/state/API/render logic for the
~40 page components and ~60 shared components) are deferred to parts 2+.** This
part ends with a complete page inventory (route → component → file → size)
so those parts have a map.

Stack (from imports, verified live): React 18 (`StrictMode`), `react-router-dom`
v6 (`BrowserRouter`), `@tanstack/react-query` v5, `axios`, `sonner` (toasts),
`@trussworks/react-uswds` + `@uswds/uswds` CSS, Vite (`import.meta.env`,
`vite-env.d.ts`). Entry: `dashboard/src/main.tsx`.

---

## 1. Entry point — `main.tsx`

`dashboard/src/main.tsx` (13 lines):

```
import "./styles/index.css";
const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Root element not found");
createRoot(rootElement).render(<StrictMode><App /></StrictMode>);
```

- Imports the CSS manifest (`styles/index.css`) as the single global stylesheet
  (`:4`). Throws synchronously if `#root` is absent (`:7`). Wraps `<App/>` in
  `<StrictMode>` (`:10-12`). No other bootstrap.
- GOTCHA (StrictMode double-invoke): all effects in the app run twice in dev.
  The WebSocket hook and contexts are written to tolerate this (mount guards).

---

## 2. `App.tsx` — providers, route table, cross-cutting boot logic

File: `dashboard/src/App.tsx` (403 lines). This is the single router config.

### 2.1 Provider nesting (outer → inner) — `App.tsx:163-402`

Exact order (must be reproduced; inner providers depend on outer):

```
<QueryClientProvider client={queryClient}>       (:165)
  <ArtifactContextProvider>                       (:166)
    <PortfolioProvider>                            (:167)
      <BreadcrumbProvider>                         (:168)
        <BrowserRouter>                            (:169)
          <UnauthorizedRedirect />                 (:170)
          <Toaster position="top-right" richColors closeButton />  (:171)
          <DemoModeIndicator />                    (:172)
          <Routes> … </Routes>                     (:173)
```

- `queryClient` is a module-level singleton (`:132-139`):
  `defaultOptions.queries = { staleTime: 30_000, refetchOnWindowFocus: true }`.
- `<Toaster>` from `sonner`: top-right, `richColors`, `closeButton`.
- `installDemoToastGuard(toast)` is invoked at **module load** (`:96-98`), before
  the component renders, so every `toast(...)` call site across the app is routed
  through the suppressor when demo mode is on. Cast: `toast as unknown as
  Parameters<typeof installDemoToastGuard>[0]`.

### 2.2 `UnauthorizedRedirect` — 401 → /login bridge (`:149-161`)

A render-null component mounted inside `<BrowserRouter>`. On mount it registers
`setUnauthorizedHandler(cb)` where `cb` navigates to `/login` with
`{ replace: true, state: { from: location } }` — **but only if `location.pathname
!== "/login"`** (`:154`). Cleanup unsets the handler (`:158`). `useEffect` deps
`[navigate, location]`. This is the bridge from the axios interceptor (which lives
outside React) into router navigation. See §7.1.

### 2.3 Legacy redirect components (`:104-130`)

Three tiny `<Navigate replace>` wrappers reading route params:
- `LegacySkillRedirect` (`:104`): `/agents/skills/:skillId` → `/skills/:skillId`.
- `WavePlanRedirect` (`:116`): `/waves/:waveId/plan` → `/waves/:waveId#plan`
  (hash scrolls to the embedded wave-plan section).
- `LegacyPortfolioWavePlanRedirect` (`:127`): `/portfolios/:portfolioId/waves/:waveId/plan`
  → `/waves/:waveId#plan` (reads only `waveId`).

### 2.4 Complete route table

Routes are grouped: **unauthenticated** (outside Layout), then a `RequireAuth`
gate wrapping the `Layout` element (which renders `<Outlet/>`). React Router v6
ranks static paths ahead of param paths automatically. **70 `<Route` elements
total: 67 path/index routes (66 `path=` + 1 `index`) + 2 element-only wrapper
routes (`RequireAuth`, `Layout`)** — verified via `grep`. The tables below list
every navigable route.

**Public / outside Layout (`:177-191`):**

| Path | Element | Notes |
|---|---|---|
| `login` | `<Login/>` | Auth form; outside shell so anon users see no sidebar (`:177`) |
| `auth/callback` | `<OidcCallback/>` | OIDC redirect handler (`:178`) |
| `demo/one-stop-shop` | `<OneStopShopDemo/>` | Demo-only, outside Layout (`:185`) |
| `demo/cold-open` | `<DemoColdOpen/>` | Full-screen ribbon splash; `?close=true` variant (`:191`) |

**Guarded subtree — `<Route element={<RequireAuth/>}>` → `<Route element={<Layout/>}>` (`:196-395`):**

| Path | Element | Source |
|---|---|---|
| `index` (`/`) | `<PortfolioOverview/>` | `:199` |
| `portfolios/:portfolioId/applications` | `<ApplicationsPage/>` | `:200-203` |
| `applications/:id` | `<ApplicationDetail/>` | `:204` |
| `applications/:appId/design-review` | `<DesignReview/>` | `:208-211` |
| `portfolios/:portfolioId/applications/:appId/interview` | `<Interview/>` | `:214-217` |
| `applications/:appId/interview` | `<Interview/>` | `:218-221` |
| `applications/:appId/build` | `<BuildProgress/>` | `:222-225` |
| `gates` | `<GateQueue/>` | `:226` |
| `gates/:gateId/review` | `<GateReview/>` | `:227` |
| `escalations` | `<EscalationQueue/>` | `:228` |
| `autonomy-ops` | `<AutonomyOps/>` | **NEW** P9-S17.5 (`:235`) |
| `feedback` | `<FeedbackTriagePage/>` | **NEW** Phase 8 U7 (`:242`) |
| `action-console` | `<NlActionConsole/>` | **NEW** W6 nl-action-engine (`:244`) |
| `me/tasks` | `<MyTasks/>` | `:251` |
| `me/tasks/:taskId` | `<MyTaskDetail/>` | `:252` |
| `me/bundles` | `<MyBundles/>` | `:254` |
| `bundles/:bundleId` | `<BundleDetail/>` | `:255` |
| `waves` | `<WaveManagement/>` | `:256` |
| `waves/:waveId` | `<WaveDetail/>` | `:257` |
| `waves/:waveId/plan` | `<WavePlanRedirect/>` | 301→`#plan` (`:261-264`) |
| `portfolios/:portfolioId/waves/:waveId/redundancy-matrix` | `<RedundancyMatrix/>` | `:265-268` |
| `portfolios/:portfolioId/waves/:waveId/plan` | `<LegacyPortfolioWavePlanRedirect/>` | `:273-276` |
| `analytics/scoring-heat-map` | `<ScoringHeatMap/>` | `:277` |
| `lines/launch` | `<ScopedLineLaunch/>` | `:280` |
| `assembly-lines` | `<AssemblyLinesIndex/>` | `:281` |
| `assembly-lines/:lineId` | `<AssemblyLineDashboard/>` | `:282` |
| `assembly-lines/:lineId/anatomy` | `<LineAnatomyPage/>` | `:283-286` |
| `skills` | `<SkillCatalog/>` | `:293` |
| `skills/:skillId` | `<SkillDetail/>` | `:294` |
| `skills/evaluation` | `<SkillEvaluation/>` | `:295` |
| `catalog` | `<CatalogBrowsePage/>` | **NEW** Phase 8 U5 reusable-parts (`:302`) |
| `agents` | `<Navigate to="/analytics/model-usage" replace/>` | legacy (`:305-308`) |
| `agents/performance` | `<Navigate to="/analytics/model-usage" replace/>` | legacy (`:309-312`) |
| `agents/skills` | `<Navigate to="/skills" replace/>` | legacy (`:313-316`) |
| `agents/skills/:skillId` | `<LegacySkillRedirect/>` | legacy (`:317-320`) |
| `agents/evaluation` | `<Navigate to="/skills/evaluation" replace/>` | legacy (`:321-324`) |
| `analytics/readiness` | `<ReadinessScores/>` | `:327` |
| `analytics/growth` | `<CompoundGrowth/>` | `:328` |
| `analytics/velocity` | `<FactoryVelocity/>` | `:329` |
| `analytics/cost` | `<CostDashboard/>` | `:330` |
| `analytics/model-usage` | `<ModelUsage/>` | `:331` |
| `admin/profile` | `<ClientProfile/>` | `:334` |
| `admin/profile/compare` | `<ProfileComparison/>` | `:335` |
| `admin/system` | `<SystemStatus/>` | `:336` |
| `admin/workflow-health` | `<WorkflowHealth/>` | `:337` |
| `admin/config` | `<Configuration/>` | `:338` |
| `admin/scoring` | `<ScoringConfig/>` | `:339` |
| `admin/registries` | `<ExtensibilityRegistry/>` | `:340` |
| `admin/users` | `<UserManagement/>` | `:341` |
| `admin/portfolio-members` | `<PortfolioMembers/>` | `:343` |
| `admin/delegation` | `<Delegation/>` | bundle force-release (`:344`) |
| `admin/delegation-management` | `<DelegationManagement/>` | **NEW** P10-W10 on-behalf-of (`:346-349`) |
| `compliance` | `<CompliancePosture/>` | `:352` |
| `compliance/cato` | `<CatoEvidence/>` | `:359` |
| `compliance/evidence-ledger` | `<EvidenceLedgerPage/>` | **NEW** Phase 8 U3 (`:364-367`) |
| `compliance/:appId` | `<ApplicationCompliance/>` | ranked AFTER static paths (`:371`) |
| `security` | `<SecurityPosture/>` | `:372` |
| `target-architecture` | `<TargetArchitecture/>` | `:379` |
| `capability-lineage` | `<CapabilityLineage/>` | `:380` |
| `traceability` | `<TraceabilityExplorerPage/>` | `:383` |
| `about` | `<AboutOverview/>` | `:390` |
| `getting-started` | `<GettingStarted/>` | `:391` |
| `*` | `<NotFound/>` | catch-all inside Layout (`:393`) |

- GOTCHA (ordering, `:359-371`): `compliance/evidence-ledger` and
  `compliance/cato` are STATIC and MUST out-rank `compliance/:appId`
  (param). React Router v6 ranks by specificity, so declaration order is not
  load-bearing here, but the code comment (`:360-363`) calls this out. If
  reproduced under a router without specificity ranking, static routes must be
  declared first.
- GOTCHA (`:196-197`): `RequireAuth` wraps `Layout` — an unauthenticated visit
  to ANY guarded route (including `*`) redirects to `/login`, not to `NotFound`.

---

## 3. `RequireAuth` — client-side route guard

File: `dashboard/src/components/RequireAuth.tsx` (26 lines).

```
export default function RequireAuth() {
  const location = useLocation();
  if (!getAuthToken()) return <Navigate to="/login" replace state={{ from: location }} />;
  return <Outlet />;
}
```

- "Authenticated" == a token exists in `localStorage` under
  `olympus:auth:token` (via `getAuthToken()`; §7.2). It does NOT validate the
  token — a stale token still renders the shell; the axios 401 interceptor
  handles expiry (§7.1). Stashes attempted `location` in `state.from` for
  post-login return (`:23`).

---

## 4. `Layout` — the app shell

File: `dashboard/src/components/Layout/Layout.tsx` (304 lines). Imported in
`App.tsx` as `./components/Layout` → resolves to `Layout/index.ts` which
re-exports `Layout.tsx` default. Also named-exports `breadcrumbsForPath`.

### 4.1 Structure (render tree, `:203-303`)

1. `<a class="usa-skipnav" href="#main-content">Skip to main content</a>` (`:205`).
2. USWDS `<Header basic showMobileOverlay={mobileNavOpen}>` (`:209`):
   - `.usa-nav-container` → `.usa-navbar` with `.usa-logo#olympus-logo`
     containing `<Link to="/" class="olympus-brand"><BrandIcon/>Olympus</Link>`
     (`:212-219`) and `<NavMenuButton label="Menu" onClick={toggleMobileNav}/>`.
   - `<PrimaryNav items={navItems} mobileExpanded={mobileNavOpen}
     onToggleMobileNav={toggleMobileNav}>` (`:225`). `navItems` is built from
     `NAV_SECTIONS.map(...)` (`:190-201`): one `<NavLink to={section.topNavPath}>`
     per section; className is `usa-nav__link` + `usa-current` when
     `section.id === activeSection.id` OR the NavLink `isActive`.
   - Inside PrimaryNav children: `.header-right-group` with `<PortfolioPicker/>`,
     `<ActiveProfileBadge/>`, the connection indicator (`connection-dot`
     connected/disconnected + "Live"/"Offline"), `<ThemeToggle theme onToggle/>`,
     `<CurrentUserMenu/>` (`:230-247`).
3. `.olympus-layout` (`:252`):
   - `<nav class="olympus-sidebar [--collapsed]">` (`:253`) containing
     `<SidebarNav collapsed={sidebarCollapsed}/>` and a `.sidebar-collapse-toggle`
     button rendering `<CollapseIcon collapsed/>` (`:258-266`).
   - `<main id="main-content" class="olympus-main" role="main">` (`:269`)
     containing `<BreadcrumbBar class="olympus-breadcrumbs">` (crumbs mapped
     from `breadcrumbsForPath`, `:270-283`) then `<Outlet/>` (`:285`).
4. Conditional `<ChatDrawer>` (`:291-301`): **hidden when
   `location.pathname === "/action-console"`** (the console is itself a chat
   surface). Keyed by ``${chatCtx.contextType}-${chatCtx.contextId}-${chatCtx.section ?? ""}``
   so switching context remounts the drawer. Props: `contextType`, `contextId`,
   `section`, `artifactContext`, `suggestedQuestions`, `openSignal`.

### 4.2 State & hooks (`:172-188`)

- `mobileNavOpen` (`useState(false)`), `sidebarCollapsed` (`useState(false)`).
- `useLocation()`, `useWebSocket()` → `{ connected }`, `useTheme()` →
  `{ theme, toggle: toggleTheme }`, `useChatContext()`, `useArtifactContext()` →
  `{ artifactContext, openChatSignal }`, `useBreadcrumbContext()` →
  `{ segments }`.
- `toggleMobileNav = useCallback(() => setMobileNavOpen(p=>!p), [])`.
- `crumbs = breadcrumbsForPath(location.pathname, breadcrumbSegments)`.
- `activeSection = resolveActiveSection(location.pathname)`.

### 4.3 Inline SVG brand assets (must reproduce for visual parity)

- `CollapseIcon` (`:31-48`): 16×16 double-chevron; points flip on `collapsed`.
- `HomeIcon` (`:50-59`): 14×14 house, used as the breadcrumb root icon.
- `BrandIcon` (`:61-81`): a 32×32 SVG "temple/network" mark — three stacked
  temple-base paths in `#211D1E`, connective lines, and 4 nodes: three cyan
  `#23D2D7` circles (r=2) and one teal `#177480` apex circle (r=2, stroke 1.5),
  all stroked `#211D1E`. Wrapped in `<span class="olympus-brand-icon">`. This is
  the Olympus logo; reproduce the path data verbatim from `Layout.tsx:64-78`.

### 4.4 `breadcrumbsForPath(pathname, context)` — exported (`:85-168`)

Returns an array of `{ label, href?, icon? }`. Always starts with
`{ label: "Portfolio", href: "/", icon: true }` (`:90`). Branch cascade (order
matters — first match wins):

- `startsWith("/applications/")` (`:93`): if `context.waveName` push
  `{waveName, href:"/waves"}`; push `context.appName || "Application Detail"`;
  if `context.assemblyLine` push it; if `context.leaf` push it.
- `match(/^\/portfolios\/[^/]+\/applications/)` → push "Applications" (`:108`).
- `match(/^\/gates\/[^/]+\/review/)` → "Gate Queue"(href `/gates`) + "Gate Review".
- `=== "/gates"` → "Gate Queue".
- `=== "/me/tasks"` → "My Tasks"; `startsWith("/me/tasks/")` → "My Tasks"(href)+"Task Detail".
- `=== "/me/bundles"` → "My Bundles"; `startsWith("/bundles/")` → "My Bundles"(href)+"Bundle Detail".
- `=== "/waves"` → "Wave Management".
- `=== "/assembly-lines"` → "Assembly Lines"; `startsWith("/assembly-lines/")`
  → title-cased slug (`slug.replace(/-/g," ").replace(/\b\w/g, c=>c.toUpperCase())`).
- `=== "/skills/evaluation"` → "Skills"(href)+"Skill Evaluation"; other
  `startsWith("/skills/")` → "Skills"(href)+"Skill Detail"; `=== "/skills"` → "Skill Catalog".
- `startsWith("/analytics/")` → label from map {readiness, growth, velocity,
  cost, model-usage} else "Analytics".
- `startsWith("/admin/")` → label from map {profile, system, config, scoring,
  portfolio-members, delegation} else "Admin".
- GOTCHA: many newer routes (autonomy-ops, feedback, catalog, compliance/*,
  target-architecture, traceability, action-console, etc.) have NO explicit
  branch, so they render only the root "Portfolio" crumb.

Rendering (`:270-283`): each crumb → `<Breadcrumb current={i===last}>`; if
`href` → `<BreadcrumbLink href>` (with `<HomeIcon/>` when `c.icon`) else `<span>`.

---

## 5. Navigation — `navConfig.ts` + `SidebarNav` + `SidebarIcon`

### 5.1 `navConfig.ts` (`components/Layout/navConfig.ts`, 217 lines)

Types: `NavItem { label, path, icon? }`; `NavSection { id, label, matchPrefix,
extraPrefixes?, topNavPath, items }` (`:6-26`).

`NAV_SECTIONS` (`:28-194`) — six sections (top-nav order):

1. **portfolio** (`matchPrefix:"/"`, `topNavPath:"/"`). Items (`:34-79`):
   Overview `/` grid; My Tasks `/me/tasks` user; My Bundles `/me/bundles`
   package; Action Console `/action-console` comment; Wave Management `/waves`
   wave; Gate Queue `/gates` lock; Escalations `/escalations` shield;
   **Autonomy Ops `/autonomy-ops` activity**; **Feedback Triage `/feedback`
   refresh**; Target Architecture `/target-architecture` box; Capability
   Lineage `/capability-lineage` search; Traceability `/traceability` search;
   Compliance Posture `/compliance` check-circle; cATO Evidence
   `/compliance/cato` shield; Security Posture `/security` shield.
2. **assembly-lines** (`matchPrefix:"/assembly-lines"`). Items (`:86-102`):
   Overview + one per line: Discovery, Rationalization, Architecture, Data,
   Modernization, **Build**, Disposition Execution, Validation, Deployment,
   Sustainment, Governance (paths `/assembly-lines/<slug>`; icons per item).
3. **skills** (`matchPrefix:"/skills"`, `extraPrefixes:["/catalog"]`). Items:
   Skill Catalog `/skills` book; Skill Evaluation `/skills/evaluation` trending;
   **Reusable Parts `/catalog` package** (`:116-123`).
4. **analytics** (`matchPrefix:"/analytics"`, `topNavPath:"/analytics/readiness"`).
   Items: Readiness Scores, Scoring Heat Map (`/analytics/scoring-heat-map`),
   Compound Growth, Factory Velocity, Cost Dashboard, Model Usage (`:130-137`).
5. **admin** (`matchPrefix:"/admin"`, `topNavPath:"/admin/profile"`). Items:
   Client Profile, Profile Comparison (`/admin/profile/compare`), System Status,
   Workflow Health, Configuration, Scoring Config, Extensibility Registry, User
   Management, Portfolio Members, Delegation, **Delegation Management**
   (`/admin/delegation-management`) (`:145-167`).
6. **about** (`matchPrefix:"/about"`, `extraPrefixes:["/getting-started"]`).
   Items: Platform Overview `/about`, Getting Started `/getting-started` (`:181-192`).

`resolveActiveSection(pathname)` (`:200-217`): sorts sections by
`matchPrefix.length` descending (specific first), SKIPS the `"/"` root section
during the loop, returns the first section where any of
`[matchPrefix, ...extraPrefixes]` is a `pathname.startsWith` match; falls back to
`NAV_SECTIONS[0]` (portfolio). GOTCHA: the `"/"` section can only be reached by
fallback, so any path not matching another prefix lands on Portfolio.

### 5.2 `SidebarNav` (`components/Layout/SidebarNav.tsx`, 80 lines)

Props: `{ collapsed: boolean }`. Reads `useLocation().pathname`,
`resolveActiveSection(pathname)`, `usePortfolioContext().activePortfolio`.

- Injects a portfolio-scoped "Applications" item **only when
  `section.id === "portfolio" && activePortfolio`** (`:19-30`): spliced between
  Overview (index 0) and the rest, path
  `/portfolios/${activePortfolio.id}/applications`, icon `box`.
- `isActive(path)` (`:32-42`): `"/"` matches only exact `/`; otherwise
  `pathname === path || pathname.startsWith(path + "/")` (trailing-slash guard
  against sibling-prefix false positives like `/gates` vs `/gates-foo`).
- Collapsed branch (`:44-59`): renders `<SideNav>` of icon-only `<Link>`s
  (title = label, class `usa-current` when active).
- Expanded branch (`:61-78`): first a `.sidebar-section-title` div with
  `section.label`, then `<Link class="sidebar-link-with-icon [usa-current]">`
  with `<SidebarIcon size=14/>` + `.sidebar-link-text`.

### 5.3 `SidebarIcon` (`components/Layout/SidebarIcon.tsx`, 67 lines)

A `Record<string,string>` `ICONS` of SVG path strings keyed by name (`:6-37`):
`grid, layers, wave, lock, search, filter, box, database, cpu, play,
check-circle, upload, refresh, shield, bot, book, trending, bar-chart, zap,
dollar, package, user, activity, settings`. Component renders a 16×16 (or `size`)
`<svg stroke="currentColor" strokeWidth=1.5 fill=none>` with the path; if the
name is unknown, falls back to `<span class="sidebar-icon">` with the uppercased
first letter (`:46-48`). Reproduce the path data verbatim for icon parity.

---

## 6. Header controls

### 6.1 `PortfolioPicker` (`components/PortfolioPicker.tsx`, 59 lines)

Consumes `usePortfolioContext()` → `{ portfolios, activePortfolio,
setActivePortfolioId, loading }`. Branches:
- `loading` → placeholder `<span>` (minWidth 12rem, `aria-busy`) to avoid header
  reflow (`:14-26`).
- `portfolios.length === 0` → `null` (`:28`).
- exactly 1 → static `.portfolio-picker--single` label of `portfolios[0].name`
  (no dropdown) (`:33-40`).
- else → native `<select id="portfolio-picker-select">` (Section-508 native
  control) with `value={activePortfolio?.id ?? ""}`, `onChange` →
  `setActivePortfolioId(e.target.value)`, one `<option>` per portfolio (`:42-58`).

### 6.2 `ActiveProfileBadge` (`components/ActiveProfileBadge.tsx`, 65 lines)

Read-only. `useEffect` fetches `fetchActiveProfile().catch(()=>null)` once with a
`cancelled` guard (`:22-35`). `loading` → placeholder span; `!active` → `null`
(renders nothing to avoid confusing placeholder); else a badge showing label
"Profile" + `active.name`, `title="Active profile: <name>"` (`:53-63`). No picker
(profile switching is admin-only).

### 6.3 `ThemeToggle` (`components/ThemeToggle.tsx`, 26 lines)

Props `{ theme:"light"|"dark", onToggle }`. Renders a `.theme-toggle` pill button;
`aria-label` "Switch to {light|dark} mode"; icon `☀` (`☀`) when dark else
`◑` (`◑`); label "Light"/"Dark".

### 6.4 `CurrentUserMenu` (`components/Layout/CurrentUserMenu.tsx`, 173 lines)

- State: `user` (`UserProfile|null`), `loading` (init true), `open`,
  `containerRef`.
- `reload = useCallback` → `fetchCurrentUser()`; on error `setUser(null)`
  (`:44-54`); called once on mount.
- Outside-click + Escape close (only while `open`): `mousedown` listener closes
  when target outside `containerRef`; `keydown` closes on Escape (`:61-80`).
- `handleSignOut` (`:82-89`): `await logoutSession()` (finally
  `clearAuthToken(); navigate("/login")`).
- Render branches: `loading` → `<span class="current-user">…</span>` (`:91-97`);
  `!user && !getAuthToken()` → `<Link to="/login">Sign in</Link>` (`:99-105`);
  else avatar button (`initialsOf(label)` — up to 2 letters) with
  `aria-haspopup/expanded/controls`, and when `open` a `.current-user__menu`
  dropdown: identity (name from `full_name || username || "User"`, email),
  role chips (`user.roles`), and a "Sign out" unstyled button.
  `initialsOf` (`:28-35`): splits on whitespace; 1 word → first two chars; else
  first char of first + first char of last, uppercased; empty → "?".

---

## 7. API layer

Directory `dashboard/src/api/`: `client.ts` (4236 lines — the axios instance +
~150 typed helpers + chat/streaming), plus feature modules `autonomy.ts`,
`bundlesApi.ts`, `catalog.ts`, `evidence.ts`, `feedback.ts`, `lines.ts`. All
feature modules `import apiClient from "./client"`.

### 7.1 `client.ts` — axios instance & interceptors (`:6-214`)

- `API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000"`
  (`:9`).
- `apiClient = axios.create({ baseURL, headers:{"Content-Type":"application/json"},
  timeout: 30_000 })` (`:12-18`). Default export.
- **Request interceptor** (`:82-89`): reads `getAuthToken()`; if present sets
  `Authorization: Bearer <token>`.
- **Response interceptor** (`:147-212`):
  - On `error.response`: if `status === 401 && !isAuthEndpoint(url)` →
    `clearAuthToken(); unauthorizedHandler?.()` (`:156-162`). `isAuthEndpoint`
    (`:73-80`) matches `/auth/login`, `/auth/config`, `/auth/callback` — those
    401s stay inline (bad credentials), no redirect loop.
  - Builds a human message with resolution order (`:168-194`):
    (1) Olympus envelope `data.error.message`; (2) FastAPI string `data.detail`;
    (3) generic `data.message`; (4) Pydantic array `data.detail` → flattened
    `field: msg; …` (loc joined minus "body"); else `Server error (STATUS)`.
    Final message form: `"<status>: <detail>"`.
  - Rejects with `ApiError(msg, traceId, status)` (`:199`).
  - On `error.request` (no response): rejects `ApiError("Unable to reach API at
    <base>. Is the server running?", "")` (`:201-209`).
  - Otherwise re-rejects the raw error.
- `class ApiError extends Error` (`:100-113`): fields `traceId` (string), `status?`
  (number); `name="ApiError"`; preserves the `"<status>: <detail>"` message so
  call sites branching on `err.message.startsWith("404:")` keep working.
- `extractTraceId(response)` (`:117-131`): header `x-trace-id` ?? `x-request-id`,
  else body `data.error.trace_id ?? data.error.request_id`, else `""`.
- Session-expired bridge: `unauthorizedHandler` module var +
  `setUnauthorizedHandler(fn|null)` (`:63-68`); registered by
  `UnauthorizedRedirect` (§2.2).

### 7.2 Auth token helpers (`:29-53`)

`AUTH_TOKEN_KEY = "olympus:auth:token"`. `setAuthToken` / `clearAuthToken` /
`getAuthToken` wrap `localStorage` in try/catch (silent on quota/privacy errors;
`getAuthToken` returns `null` on failure).

### 7.3 Typed request helpers in `client.ts` (endpoint reference)

~150 exported functions, each `async` returning typed data (all `GET` return
`data`, `POST/PUT/DELETE` as noted). Grouped by domain with method+path (cite
`client.ts:NN`). This is the exhaustive HTTP surface the pages consume:

**Portfolios / Applications**
- `fetchPortfolios()` GET `/api/v1/portfolio` (`:288`)
- `fetchApplications({page,per_page,portfolio_id})` GET `/api/v1/applications` (`:295`)
- `fetchApplicationDetail(id)` GET `/api/v1/applications/{id}` (`:305`)
- `fetchApplicationRationale(id)` GET `…/{id}/rationale` (`:324`)
- `fetchApplicationStatus(id)` GET `…/{id}/status` (`:333`)
- `fetchDesignArtifacts(appId,{line,artifact_type,page,per_page})` GET `…/{appId}/design-artifacts` (`:344`)
- `submitDesignFeedback(appId,body)` POST `…/{appId}/design-feedback` (`:355`)
- `startInterview(appId,body)` POST `…/{appId}/interview` (`:368`)
- `fetchInterview(appId)` GET `…/{appId}/interview` (`:379`)
- `submitInterviewTurn(appId,answer)` POST `…/{appId}/interview/turns` (`:388`)
- `completeInterview(appId)` POST `…/{appId}/interview/complete`-ish (`:399`)
- `fetchApplicationDispositions(...)` GET `…dispositions` (`:426`)
- `fetchApplicationLineage(...)` GET `…lineage` (`:443`)
- `fetchSourceArtifactsIndex(...)` (`:485`)
- `createApplication(body)` POST `/api/v1/applications` (`:656`); `uploadApplicationZip(...)` POST multipart (`:676`); `updateApplication(id,body)` PATCH (`:708`)
- `createPortfolio(body)` POST (`:623`); `seedSamplePortfolio(...)` POST (`:646`)

**Gates / Escalations**
- `fetchPendingGates(portfolioId?)` GET `/api/v1/gates` (paginated `GateSummary`) (`:500`)
- `fetchWaveGates(waveId)` GET (`:519`); `approveGate(id,comment)` POST `…/{id}/approve` (`:529`); `rejectGate(id,feedback)` POST `…/{id}/reject` (`:536`)
- `fetchGateEvidence(id)` GET (`:543`); `fetchApplicationGateEvidence(...)` GET (`:557`)
- `submitGateDecision(id,body)` POST → `GateDetail` (`:566`); `forceAdvanceGate(...)` POST (`:584`); `resolveEscalation(...)` POST (`:601`)

**Discovery / Workflows**
- `startDiscovery` / `startDiscoveryAlias` / `retryDiscovery` / `rerunDiscovery` POST (`:719-759`)
- `fetchStepExecution(...)` GET (`:765`); `fetchWorkflowDetails(...)` GET (`:776`)
- `startLineWorkflow(...)` POST (`:798`); `cancelWorkflow` / `retryWorkflow` / `resetWorkflow` POST (`:810-845`); `listWorkflowResetPoints(...)` GET (`:858`)
- `fetchWorkflowHealthList/Detail` GET, `restartWorkflowHealth` / `failWorkflowHealth` POST (`:871-903`)
- `fetchAgentRunRecentErrors(...)` GET (`:914`); `fetchAgentRoles(...)` GET (`:940`); `fetchModelUsage(...)` GET (`:960`)

**Waves** (`:994-1412`) — `fetchWaves`, `createWave`, `fetchWaveDetail`,
`updateWave` (PUT), `deleteWave` (DELETE), `startWave`, `startRationalization`,
`cancelWaveRationalization`, `retryWaveRationalization`, `resetWave`,
`resumeWave`, `assignWaves`, `fetchWavePendingGates`, `cancelAllWaveChildren`,
`bulkOnboardApps`, `markWaveReady`, `cancelWave`, `revertWaveToDraft`,
`assignAppsToWave`, `removeAppsFromWave`, `fetchWaveAppProgress`,
`fetchWaveProgress`, `fetchWavePerformanceReport`, `fetchWaveArtifact`.

**Analytics / scoring** (`:1412-1516`) — `fetchReadinessScores`,
`fetchOverlapMatrix`, `fetchPortfolioHealth`, `fetchPortfolioScoringHeatMap`,
`fetchDispositionConfidence`, `fetchCompoundGrowth`, `fetchGatePassRate`,
`fetchScoreHistory`, `fetchDimensionRegistry` (GET), `updateDimensionRegistry` (PUT).

**Lines status / Traceability** (`:1543-1705`) — `fetchLineStatus`,
`fetchLineThroughput`, `fetchTraceability`, `fetchForwardTrace`,
`fetchBackwardTrace`, `fetchTraceabilityCoverage`, `validateGateTraceability`,
`fetchCrossValidation`, `fetchStaleArtifacts`.

**Renditions** — `generateRendition` POST (`:1705`), `fetchRenditions` GET (`:1721`).

**Skills** (`:1735-1828`) — `fetchSkills`, `fetchSkill`, `fetchSkillByDispatch`,
`createSkill` (POST), `updateSkill` (PUT), `deleteSkill` (DELETE),
`fetchSkillMetricsByLine`.

**Health / Governance** (`:1838-1942`) — `fetchDetailedHealth`,
`fetchGovernanceLatestHealthCheck`, `fetchGovernanceHealthChecks`,
`fetchGovernanceDriftAlerts`, `acknowledgeDriftAlert` (POST),
`fetchGovernancePatterns`, `startGovernanceSweep`/`triggerGovernanceSweep`
(POST), `fetchGovernanceSweeps`.

**Registries** — `fetchRegistriesIndex` GET (`:1942`), `fetchRegistryEntries` GET (`:1957`).

**Chat (advisory + action + agentic)** — see §7.4.

**Auth / Users** (`:2499-2604`) — `fetchAuthConfig` GET `/api/v1/auth/config`,
`fetchCurrentUser` GET `/api/v1/auth/me`, `loginLocal(...)` POST
`/api/v1/auth/login`, `logoutSession()` POST `/api/v1/auth/logout` (`.catch`
swallows), `fetchRoles`, `fetchGateReviewerRoles`, `fetchAuditLog`, `fetchUsers`,
`fetchUser`, `createUser` (POST), `updateUserProfile` (PUT),
`deactivateUserProfile` (DELETE), `updateUserPassword` (POST).

**Profiles** (`:2847-2891`) — `fetchProfiles` GET `/api/v1/profiles`,
`fetchActiveProfile` (returns `{active}` unwrapped to `ActiveProfileDetail|null`),
`switchPortfolioProfile` (PUT), `fetchPortfolioProfileBundle`.

**Architecture dispatch** (`:2941-3247`) — `fetchDispatchPreview`,
`dispatchArchitecture`, `fetchDispatchTargetPreview`, `dispatchArchitectureV2`,
`normaliseDispatchTargets` (pure), `fetchDispatchStatus`, `dispatchRetry`,
`fetchGitRepoAvailable`.

**Capability / systems** (`:3308-3573`) — `fetchWaveCapabilityLineage`,
`ratifyCapabilityLineageRow` (POST), `rejectCapabilityLineageRow` (POST),
`fetchPortfolioComplianceSystemRollup`, `fetchSystems`, `fetchSystemDetail`,
`fetchSystemCapabilities`, `fetchSystemLineage`, `fetchCapabilityLineage`.

**Tasks (human-paired agent)** (`:3679-3739`) — `fetchMyTasks`, `submitTaskReturn`
(POST), `acceptTask` (POST), `fetchTaskAuditNarrative`.

**cATO / compliance** (`:3862-3913`) — `fetchPortfolioCatoEvidence`,
`downloadComplianceEvidence` (GET blob), `triggerGovernanceSweep`.

**Wave app activity / Tier-1** (`:3977-4076`) — `fetchWaveAppActivity`,
`fetchTier1Pending`, `submitTier1Approval` (POST).

**Viewer analytics (dwell)** (`:4107-4170`) — `recordViewerDwell` (POST),
`beaconViewerDwell` (uses `navigator.sendBeacon` to `VIEWER_EVENTS_PATH`,
returns bool), `fetchViewerAnalyticsSummary`.

**Delegations (on-behalf-of, P10-W10)** (`:4217-4235`) — `listDelegations` GET
`DELEGATIONS_PATH`, `issueDelegation` (POST), `revokeDelegation` (DELETE
`{path}/{grantId}`).

Several fetchers wrap the call in try/catch and return `null`/empty on 404 or
partial envelopes (e.g. `fetchWaveArtifact`, `fetchDispositionOutput`,
`fetchStructuralAnalysis`, `fetchSourceArtifactsIndex`) so pages render empty
states rather than crash.

### 7.4 Chat: advisory, action-mode, and agentic streaming

Types (`:1974-2158`): `ChatContextType = "gate"|"application"|"portfolio"`;
`ChatMessage`, `UnifiedChatMessage {context_type,context_id,section?,message,
artifact_context?}`, `ChatResponse {response, model_used, sources?}`,
`ChatSourceItem {artifact,section?,finding_id?,file?,line?}`, `ChatHistoryMessage`,
`ChatHistoryResponse`.

Action-mode types (`:2047-2158`): `NlActionTier =
"reversible"|"high_stakes"|"gate_decision"`; `NlActionStatus =
"planned"|"executed"|"awaiting_confirmation"|"staged"|"needs_input"|"denied"|
"failed"`; `NlPlannedAction`, `NlCapability`, `NlActionResponse {mode:"action",
session_id,intent_id,intent_text,actions[],summary,reply?,capabilities?}`,
`NlActionRequest {context_type,context_id,message,session_id?,action_params?}`,
`NlConfirmActionRequest`.

Functions:
- `sendChat(UnifiedChatMessage)` POST `/api/v1/chat` (advisory) (`:2026`).
- `sendChatAction(...)` POST `/api/v1/chat` with action mode (`:2115`);
  `confirmChatAction(...)` POST (`:2132`).
- `sendGateChat(gateId,body)` POST `/api/v1/gates/{id}/chat` (legacy) (`:2387`).
- `fetchChatHistory(...)` GET (`:2406`); `fetchGateChatHistory(...)` GET (`:2424`);
  `clearChatHistory(...)` DELETE `/api/v1/chat/history` (`:2441`).
- `fetchRecentActivity(...)` GET → `ActivityEvent[]` (`:2470`).

**`streamChatAction(body, cbs): AbortController`** (`:2160-2233`) — SSE over
`fetch` (not axios, because axios can't stream + needs POST body + bearer). Posts
`{...body, mode:"action", action_params: body.action_params ?? {}}` to
`/api/v1/chat/action/stream` with `Authorization` header and `signal` from an
`AbortController`. Reads `resp.body.getReader()`, decodes with `TextDecoder`,
buffers, splits on `\n\n` frames. `handleFrame` parses `event:`/`data:` lines
(concatenating `data:` slices), JSON-parses, and dispatches: `token` →
`cbs.onToken(payload.text)`, `plan` → `cbs.onPlan`, `done` → `cbs.onDone?.()`.
On stream end calls `cbs.onDone?.()`. `AbortError` is swallowed; other errors →
`cbs.onError?.(err)`. GOTCHA: `onDone` may fire twice (once on `done` event, once
at loop end) — consumers must be idempotent.

**`streamAgentAction(body, cbs): AbortController`** (`:2294-2384`) — identical
transport but hits `/api/v1/chat/action/agent` and dispatches a RICHER event set
via a `switch`: `token, tool_call (→onToolCall NlToolCall), tool_result
(→onToolResult NlToolResult), artifact (→onArtifact NlArtifactEvent), navigate
(→onNavigate NlNavigateEvent), plan, done`. `AgentStreamCallbacks extends
StreamChatCallbacks` with the four optional new callbacks (`:2276-2285`).
Additional wire types `NlToolCall {id,name,kind:"read"|"navigate",args}`,
`NlToolResult {id,name,ok,summary}`, `NlArtifactEvent {app_id?,artifact_path?,
artifact_type?,content}`, `NlNavigateEvent {route,page?}` (`:2247-2274`). The
agentic path READS live data and NAVIGATES the dashboard in-loop; writes still
flow through the same gated engine.

### 7.5 Feature API modules

- **`autonomy.ts`** (291 lines) — P9-S17.5 autonomy-ops (READ-ONLY). GOTCHA:
  calls the **bare `/autonomy/...` prefix**, NOT `/api/v1/...` (both routers
  mounted at `/autonomy`) (`:22-27`). `getAutonomyStatus(params?)` GET
  `/autonomy/status` (`:187`); `getAutonomyIncidents(params?)` GET
  `/autonomy/incidents` (`:224`). Both defensively normalize arrays/counts so a
  drifted envelope never white-screens. Types: `AutonomyLevel
  ="report_only"|"assisted"|"unattended"`, `EscalationStatus`, `TriageDecision
  ="report_only"|"fix_proposal"|"escalate"`, `CaptureSource
  ="ai_work_log"|"agent_run"|"event_outbox"|"prometheus_alert"|"mixed"`,
  `IncidentStatus`; wire types `LoopPatternStatus`, `EscalationRecord`,
  `AutonomyStatusPage`, `IncidentRecord`, `IncidentPage`. Label maps +
  `autonomyLevelLabel`/`triageDecisionLabel`/`captureSourceLabel` fall back to
  the raw value/"—".
- **`bundlesApi.ts`** (354 lines) — Phase 5 W20 delegated bundles. Unions:
  `BundleScopeKind`, `BundleStatus` (offered/claimed/submitted/accepted/rejected/
  expired/released), `BundleFallbackPolicy`, `BundleSessionArtifactKind`,
  `RBACRoleValue`. Wire types `BundleSummary`, `BundleDetail`,
  `BundleValidationResult`, `PortfolioMembership`, etc. Endpoints: `listBundles`
  GET `/api/v1/me/bundles` (returns `[]` if non-array), `getBundle`, `claimBundle`
  POST, `releaseBundle` POST, `validateBundle` POST, `submitBundle` POST →
  `{bundle,validation}`, `getBundleAudit` GET; admin: `listPortfolioMembers`,
  `addPortfolioMember` POST, `removePortfolioMember` DELETE, `createBundle` POST
  `/api/v1/admin/portfolios/{id}/bundles`, `forceReleaseBundle` POST
  `/api/v1/admin/bundles/{id}/force-release`.
- **`catalog.ts`** (142 lines) — Phase 8 U5 reusable-parts (READ-ONLY).
  `listCatalog(filters?)` GET `/api/v1/reusable-parts` (`:124`); server-side
  filters `kind/status/q/limit/offset`; normalizes `{items:[],total}`. Types
  `CatalogStatus` (draft/in_review/published/deprecated | string), `CatalogEntry`
  (with CONTRACT-RECONCILE optional fields `profile_scope`, `control_coverage`,
  `eval_status` — absent until backend ships them), `CatalogListResponse`.
- **`evidence.ts`** (391 lines) — Phase 8 U3 AO Evidence Ledger (READ-ONLY at
  `/api/v1/compliance`). `VIEWER_PLUS_ROLES` (viewer, tech_lead, arch_lead,
  compliance_lead, operations_lead, safety_board, portfolio_manager,
  portfolio_admin — `service` excluded) + `hasViewerPlus(roles)`.
  `fetchEvidenceRecords(portfolioId,{limit,offset})` GET
  `…/portfolios/{id}/evidence-records` (`:125`); `fetchEvidenceChain(portfolioId,
  controlId,applicationId?)` GET `…/evidence-chain/{controlId}` (`:151`).
  OSCAL export is BLOCKED: `OSCAL_EXPORT_AVAILABLE = false`; `requestOscalExport`
  throws `OscalExportUnavailableError` (code `OSCAL_EXPORT_UNAVAILABLE`).
  Pure presentation logic (LOAD-BEARING, REQ-UEL-002): `catalogIdFor(controlId)`
  (regex namespace → "OMB M-25-21"/"NIST AI RMF"/"NIST 800-53"/"Other"),
  `controlIsSatisfied(records)` — satisfied ONLY if a record is `ratified &&
  !superseded && status==="implemented"` (`:297-301`), `groupRecordsByControl`
  (buckets catalog→controls, sorts, per-control ratified/unratified counts;
  `current` = first live record since served newest-first),
  `summarizeSatisfaction`. GOTCHA: unratified `implemented` records NEVER count.
- **`feedback.ts`** (162 lines) — Phase 8 U7 (prefix `/api/v1/feedback`).
  Unions `FeedbackSourceType` (escalation/sustainment_finding/manual),
  `FeedbackStatus` (pending_review/approved/dismissed), `FeedbackSeverity`
  (critical/standard/low). `listFeedback(filters?)` GET (returns `{data:[]}` on
  bad envelope) (`:114`); `approveFeedback(id,{promotion_ref,note?})` POST
  `…/{id}/approve` (`:141`); `dismissFeedback(id,{dismiss_reason})` POST
  `…/{id}/dismiss` (`:153`).
- **`lines.ts`** (166 lines) — Phase 10 W9/U3 scoped-line launch. Unions
  `RunMode` (full-pipeline/isolated/partial/composed) + `RUN_MODES` array,
  `AssuranceLevel` (full/provisional/partial/context-starved), `InputOrigin`.
  `resolveLineInputs(line,targetAppId)` POST `/api/v1/lines/{line}/resolve-inputs`
  (`:59`); `startScopedLine(line,body)` POST `/api/v1/lines/{line}/start` (`:99`);
  `getRunScope(line,runId)` GET `/api/v1/lines/{line}/runs/{runId}/scope`
  (`:123`). `assuranceBadge(level)` maps to `{label,icon,tone}` (508: icon +
  label, never color-only) — full ✓ success, provisional ◐ warning, partial ◑
  warning, context-starved ! error; unknown → `?` warning.

---

## 8. State-management model

Three layers: (a) React contexts for cross-cutting UI state; (b)
`@tanstack/react-query` for server state; (c) bespoke polling / websocket hooks.

### 8.1 Contexts (all under `hooks/`)

- **`PortfolioProvider` / `usePortfolioContext`** (`hooks/usePortfolioContext.tsx`,
  110 lines). State: `portfolios`, `activeId` (init from `localStorage`
  `"olympus-active-portfolio"`), `loading` (init true). `load()` (`:53-75`)
  fetches `fetchPortfolios()`, and if the stored id matches nothing picks
  `list[0]` and persists it; swallows API errors (portfolios stays empty).
  `setActivePortfolioId(id)` sets state + localStorage. `activePortfolio =
  portfolios.find(p=>p.id===activeId) ?? null` (derived each render). Exposes
  `refresh: load`. GOTCHA: `load` has empty deps (`activeId` read stale via
  closure) — deliberate, `eslint-disable`d (`:75`).
- **`ArtifactContextProvider` / `useArtifactContext`** (63 lines). State:
  `artifactContext:string|null` + `openChatSignal:number`. `requestOpenChat()`
  increments `openChatSignal` (monotonic counter watched by ChatDrawer to open
  itself). `setArtifactContext(ctx)` feeds the chat scope.
- **`BreadcrumbProvider` / `useBreadcrumbContext`** (72 lines).
  `BreadcrumbContextSegments {appName?,assemblyLine?,leaf?,waveName?}`. Pages
  push contextual crumb labels via `setBreadcrumbContext(next)`;
  `clearBreadcrumbContext()` resets to `{}`. Layout reads `segments` for the
  breadcrumb bar (§4.4).

### 8.2 React Query — `hooks/useQueries.ts` (458 lines)

`queryKeys` factory (`:57-76`): `portfolios`, `applications(params)`,
`applicationDetail(id)`, `applicationStatus(id)`, `pendingGates(portfolioId)`,
`gateEvidence(gateId)`, `gateReviewerRoles(gateId)`, `waveDetail`, `waveProgress`,
`waveGates`, `designArtifacts(appId,params)`, `interview(appId)`. Portfolio-scoped
keys embed the portfolio id so switching portfolios auto-refetches.

Query hooks: `usePortfolios`, `useApplications(params)`,
`useApplicationDetail(id)` (enabled on id), `useApplicationStatus(id)`,
`usePendingGates(portfolioId)`, `useWaveGates(waveId)`, `useGateEvidence(gateId)`,
`useGateReviewerRoles(gateId)`, `useDesignArtifacts(appId,params)`,
`useInterviewSession(appId)` (`refetchOnWindowFocus:false`).

`useWaveProgress(waveId)` (`:91-120`) — polls
`WaveRationalizationWorkflow` progress: swallows 409/`WAVE_WORKFLOW_NOT_STARTED`
→ returns `null` (empty state); `refetchInterval` = 5000 while
`data.status==="RUNNING"` else `false`; `refetchIntervalInBackground:false`.

Mutation hooks: `useSubmitGateDecision(gateId)` — GOTCHA: in demo mode
(`shouldShortCircuitGateDecision()`) returns a synthetic `GateDetail` from
`buildDemoGateDecisionResponse` WITHOUT hitting the backend (`:234-260`);
on success invalidates `["gates","pending"]` (unscoped prefix so all portfolios
refresh) + this gate's evidence. `useStartDiscovery`, `useUpdateApplication`
(`setQueryData` optimistic), `useCancelWaveRationalization`,
`useRetryWaveRationalization`, `useResetWave`, `useSubmitDesignFeedback`,
`useStartInterview`/`useSubmitInterviewTurn` (`setQueryData` cache seed),
`useCompleteInterview` (invalidate).

### 8.3 Realtime — `useWebSocket` (`hooks/useWebSocket.ts`, 158 lines)

`WS_BASE = VITE_WS_BASE_URL ?? "ws://localhost:8000"`; `SSE_BASE =
VITE_API_BASE_URL ?? "http://localhost:8000"`. Returns `{events, connected,
error}`. Options `{eventTypes[]=[], maxEvents=50}`. `addEvent` filters by
`eventTypes` and prepends, capping at `maxEvents`.

- Primary: `WebSocket(${WS_BASE}/api/v1/events/ws)` (`:93`). On close: exponential
  backoff `min(1000*2^retries, 30_000)`; after **>5 attempts** falls back to SSE
  (`:118-139`).
- SSE fallback (`:49-86`): `EventSource(${SSE_BASE}/api/v1/events?access_token=…)`
  — GOTCHA: EventSource can't set headers, so the JWT is passed as the
  `access_token` query param. On error closes + nulls the source.
- `mountedRef` guards every callback against post-unmount setState; cleanup
  closes both. Empty deps effect (mount once). GOTCHA: WS_BASE fixed at module
  load; no auth on the WS URL itself (only the SSE fallback carries the token).

### 8.4 Adaptive polling — `usePollingBackoff` (`hooks/usePollingBackoff.ts`, 146 lines)

Generic `usePollingBackoff<T>({fetcher, enabled=true, minMs=3000, midMs=5000,
maxMs=10000, unchangedThreshold=3, onError})` → `{data, error, intervalMs,
refresh}`. Compares consecutive payloads by `JSON.stringify` (`stableKey`); on N
unchanged polls steps min→mid→max (`stepInterval`: `<threshold`→min,
`<2*threshold`→mid, else max); any change resets count. Uses `setTimeout`
chaining (not `setInterval`) so each schedule reads the latest interval. GOTCHA:
`tick` calls `shouldPollTick()` first and SKIPS the tick when demo mode is on and
the document is hidden (`:89`). Fetcher/onError read via refs so identity changes
don't reschedule; effect re-runs only when `enabled` flips.

### 8.5 `useChatContext` — route→chat-scope derivation (`hooks/useChatContext.ts`, 211 lines)

Returns `{contextType, contextId, section, suggestedQuestions}`. Branch cascade
(first match wins), reading `pathname`, `params`, `activePortfolio`:
- `/gates/:gateId/review` → `{gate, gateId, null, [3 gate qs]}`.
- `/applications/:id` → `{application, id, null, [3 app qs]}`.
- else portfolio-scoped: `portfolioId = activePortfolio?.id ?? "default"`
  (backend resolves "default" to first portfolio). Sub-branches set
  `section`: `assembly-line:<lineId>`, `skills`, `analytics`, `admin`,
  `wave:<id>` (MUST precede the bare `/waves` check — comment `:139-143`),
  `waves`, `applications`, `gate-queue`, default `overview`. Each carries a
  3-question suggestion list (used by ChatDrawer).

### 8.6 Other hooks (present; detailed in later parts)

`useChartTheme.ts` (chart palette from CSS vars), `useSectionDwell.ts` (viewer
dwell analytics → `recordViewerDwell`/`beaconViewerDwell`), `useWaveTelemetry.ts`.

---

## 9. Demo mode — `demo-mode.ts` (280 lines)

Activated by `VITE_DEMO_MODE === "true"` (`IS_DEMO_MODE`, evaluated once at module
load, `:59`). Every branch is a **no-op when the flag is off** (hard rule — live
dashboards must not change behavior).

- `isDemoMode()` runtime check (`:87`).
- `FIXED_DEMO_CLOCK_ISO = "2026-05-08T14:22:00Z"` (`:73`); `useDemoClock()` returns
  the frozen date in demo mode (no ticking, no listeners) or a live `new Date()`
  updated on a 1s interval otherwise (`:99-111`).
- `DEMO_FIXTURE_PATH = "/test-data/demo/atlas-challenge"`; `getDemoFixture(name)`
  (`:140`) fetches `<path>/<name>.json` from `public/`, returns `null` when off /
  missing / empty / unparseable (comment-only placeholder) so callers fall back
  to the live API.
- `shouldPollTick()` (`:123`): `true` unless demo mode on AND
  `document.visibilityState !== "visible"`.
- `shouldShortCircuitGateDecision()` returns `isDemoMode()` (`:170`) — gate
  decisions skip the backend (see §8.2).
- **Toast suppression**: `installDemoToastGuard(toast)` (`:211-256`, called at
  `App.tsx` module load) wraps `toast.success/error/info/warning/message` so any
  call WITHOUT the `__demo_passthrough__` marker becomes a no-op (returns
  `undefined`). Idempotent (`guardInstalled`). `toastForDemo(toastFn, msg,
  extraOpts)` (`:265`) is the escape hatch — sets `__demo_passthrough__:true`
  (marker stripped before forwarding). `__resetDemoToastGuardForTesting()`
  test-only.
- **`DemoModeIndicator`** (`components/DemoModeIndicator/DemoModeIndicator.tsx`):
  returns `null` when off; else a `role="status"` `.demo-mode-indicator` pill
  (bottom-right, opacity ~0.4) with an sr-only label + dot + "DEMO MODE".

---

## 10. Design system — USWDS tokens, theme, branding

CSS manifest `styles/index.css` (`:1-14`) imports in order: `base.css`,
`layout.css`, `components.css`, `gate-review.css`,
`../components/GateReviewCards/GateReviewCards.css`, `app-detail.css`,
`chat.css`, `assembly-lines.css`. (Total ~3.9k CSS lines.)

### 10.1 Tokens — `styles/base.css` (238 lines)

Imports `@uswds/uswds/css/uswds.css` (`:6`) and Google-fonts **Inter**
(weights 400/500/600/700/900, `:7`).

`:root` custom properties (`:10-32`) — LIGHT theme (reproduce exactly):
```
--olympus-primary:#211D1E; --olympus-teal:#177480; --olympus-cyan:#23D2D7;
--olympus-accent:#00A5B5;  --olympus-gate:#6B4FBB (violet, gate-boundary accent);
--olympus-bg:#F2F7F7;      --olympus-bg-card:#ffffff;
--olympus-text:#211D1E;    --olympus-text-light:#464646;  --olympus-text-inverse:#ffffff;
--olympus-border:#E8E8E8;
--olympus-shadow:0 1px 3px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
--olympus-shadow-md:0 4px 6px rgba(0,0,0,.07),0 2px 4px rgba(0,0,0,.06);
--olympus-radius:8px;  --olympus-sidebar-width:240px;  --olympus-topnav-height:56px (legacy);
```
DARK theme `[data-theme="dark"]` (`:35-49`) overrides:
```
--olympus-primary:#fff; --olympus-teal:#23D2D7; --olympus-cyan:#5CE0E4;
--olympus-accent:#23D2D7; --olympus-gate:#B49CF0; --olympus-bg:#161213;
--olympus-bg-card:#211D1E; --olympus-text:#E8E8E8; --olympus-text-light:#999;
--olympus-text-inverse:#000; --olympus-border:#352F30; + darker shadows.
```
`body` font-family `'Inter', -apple-system, …` bg `var(--olympus-bg)` (`:52-56`).
Headings: `h1` 1.75rem primary; `h2` 1.25rem primary with a 2px
`--olympus-accent` bottom border (`:68-80`). Links: `a:visited` pinned to
`#005ea2` (kills USWDS stale-purple, `:127-129`); dark-mode links `#23D2D7`
hover `#5CE0E4`. `.empty-state`, `.onboarding-form`, `.form-field/.form-actions`,
`.discovery-action`, `.placeholder-page`, `.skill-edit-form` styles. Search-input
normalization (`:222-231`) neutralizes USWDS `[type=search]` float/max-width when
outside `.usa-search`. Responsive `@media(max-width:1024px)` → `.olympus-main`
padding 20px.

### 10.2 Theme mechanism — `hooks/useTheme.ts` (43 lines)

Theme `"light"|"dark"` persisted to `localStorage` `"olympus-theme"`. GOTCHA
(FOUC prevention, `:22-24`): at MODULE LOAD (before React) it computes
`getInitialTheme()` and sets `document.documentElement.setAttribute("data-theme",
initial)`. `useTheme()` returns `{theme, toggle}`; effect re-applies `data-theme`
+ persists on change. All theming is driven by the `data-theme` attribute on
`<html>` flipping the CSS custom properties.

### 10.3 Shell styling — `styles/layout.css` (644 lines) — key facts for parity

- `#root` is a full-height flex COLUMN (`height:100vh; overflow:hidden`); header
  is `flex:0 0 auto`; `.olympus-layout` takes the remainder (`flex:1 1 auto;
  min-height:0`). GOTCHA (`:6-20`): deliberately NOT `calc(100vh - topnav)` —
  the USWDS header reflows taller at narrow widths (62px@1440, 74px@1366) so a
  constant would be wrong; the flex column derives the remainder.
- Dark top nav: `.usa-header { background: var(--olympus-primary) !important }`
  (`:27-30`); nav-container full-width, `.usa-navbar` width = sidebar width;
  nav links `rgba(255,255,255,.7)` → white on hover/current with a
  `--olympus-cyan` underline (`::after`).
- `.olympus-brand-icon`: 36×36, `background:var(--olympus-cyan)`, radius 8px
  (the logo tile). `.olympus-brand` flex, white, 700, 1.2rem.
- `.portfolio-picker__select` / `--single` / `.active-profile-badge` — translucent
  white chips on the dark header. `.connection-indicator` pill with
  `.connection-dot--connected` (#22c55e + glow) / `--disconnected` (#ef4444).
- `.current-user__avatar` 2rem circle bg `--olympus-accent` text `#0b1a1d`;
  `.current-user__menu` absolute dropdown (min-width 240, card bg, shadow,
  z-index 1000); role chips use `color-mix(... --olympus-teal ...)`.
- `.olympus-sidebar` width `var(--olympus-sidebar-width)` (240) white, right
  border; collapsed `--collapsed` forces `56px !important` and hides section
  titles + link text. Sidebar links: 3px transparent left border → teal on
  hover/current; current bg `#e0f2f3` (light) / `rgba(23,116,128,.2)` (dark).
  `.sidebar-collapse-toggle` pinned bottom.
- `.olympus-main` `flex:1; padding:24px 32px; overflow-y:auto`.
- `.olympus-breadcrumbs` bottom-bordered, small, muted.
- `.theme-toggle` pill (translucent white border, cyan on hover).
- Full dark-mode overrides (`:566-638`) and `@media(max-width:1024px)` HIDES the
  sidebar entirely (`:640-644`).

### 10.4 Other stylesheets (detailed in later parts)

`components.css` (407) shared component styles; `gate-review.css` (1229) +
`GateReviewCards.css` gate-review surfaces; `app-detail.css` (209) application
detail tabs; `chat.css` (321) ChatDrawer/console; `assembly-lines.css` (837)
pipeline/anatomy visualizations. `DemoModeIndicator.css` scoped.

### 10.5 Config constants (present; detailed later)

`config/gateConsequences.ts` (131) — per-gate consequence copy;
`config/glossary.ts` (215) — canonical Olympus term glossary consumed by the
`<Glossary>` component.

### 10.6 Vite env vars (all `import.meta.env.*` uses)

`VITE_API_BASE_URL` (client, useWebSocket SSE, ProfileComparison, Login),
`VITE_WS_BASE_URL` (useWebSocket), `VITE_DEMO_MODE` (demo-mode),
`VITE_LEGACY_PIPELINE_VIZ` (PortfolioOverview:653 — toggles a legacy pipeline
visualization). Types declared in `vite-env.d.ts`.

---

## 11. Page inventory (route → component → file, for parts 2+)

All page files live under `dashboard/src/pages/`. Route paths per §2.4. Line
counts indicate deep-dive weight. Directory pages export via `index.ts` barrels
(verified §exports).

**Portfolio section**
- `PortfolioOverview/PortfolioOverview.tsx` (818) — index `/`.
- `Applications/ApplicationsPage.tsx` (995) — `/portfolios/:pid/applications`.
- `ApplicationDetail/ApplicationDetail.tsx` (1059) + tabs/ (ArtifactsTab 818,
  OutcomeTab 784, InsightsTab 609, RationaleTab 495, UserImpactTab 414,
  InternalDuplicationTab 328, TraceabilityTab 305, ScoresTab 295,
  DecisionsTimeline 254) — `/applications/:id`.
- `DesignReview/DesignReview.tsx` (319) — `/applications/:appId/design-review`.
- `Interview/Interview.tsx` (317) — interview routes.
- `BuildProgress/` — `/applications/:appId/build`.
- `GateQueue/` — `/gates`. `GateReview/GateReview.tsx` (365) — `/gates/:gateId/review`.
- `Escalations/EscalationQueue.tsx` (469) — `/escalations`.
- `autonomy-ops/AutonomyOps.tsx` (643) — **`/autonomy-ops` (NEW)**.
- `feedback/FeedbackTriagePage.tsx` (429) — **`/feedback` (NEW)**.
- `nl-console/NlActionConsole.tsx` (644) — **`/action-console` (NEW)**.
- `MyTasks/MyTasks.tsx` (541), `MyTasks/MyTaskDetail.tsx` (850) — `/me/tasks[/…]`.
- `MyBundles/MyBundles.tsx` (485), `MyBundles/BundleDetail.tsx` (771) — `/me/bundles`, `/bundles/:bundleId`.
- `Waves/WaveManagement.tsx` (1059) — `/waves`. `WaveDetail/WaveDetail.tsx` (1757) — `/waves/:waveId`.
- `RedundancyMatrix/RedundancyMatrix.tsx` (509) — wave redundancy matrix.
- `ScoringHeatMap/ScoringHeatMap.tsx` (418) — `/analytics/scoring-heat-map`.
- `TargetArchitecture/TargetArchitecture.tsx` (381) — `/target-architecture`.
- `CapabilityLineage/CapabilityLineage.tsx` (520) — `/capability-lineage`.
- `Traceability/TraceabilityExplorerPage.tsx` (317) — `/traceability`.

**Assembly Lines section**
- `ScopedLineLaunch/ScopedLineLaunch.tsx` (310) — `/lines/launch`.
- `AssemblyLines/AssemblyLinesIndex.tsx` (327), `AssemblyLineDashboard.tsx` (895),
  `LineAnatomyPage.tsx`, `LineSpotlight.tsx` (728) — `/assembly-lines[/…]`.

**Skills section**
- `Skills/SkillCatalog.tsx` (439), `SkillDetail.tsx` (1007), `SkillEvaluation.tsx` (561).
- `catalog/CatalogBrowsePage.tsx` (418) — **`/catalog` (NEW)**.

**Analytics section** — `Analytics/`: `ReadinessScores`, `CompoundGrowth`,
`FactoryVelocity`, `CostDashboard`, `ModelUsage.tsx` (336).

**Admin section** — `Admin/`: `ClientProfile.tsx` (676), `ProfileComparison.tsx`
(295), `SystemStatus.tsx` (221), `WorkflowHealth.tsx` (679), `Configuration`,
`ScoringConfig.tsx` (294), `ExtensibilityRegistry.tsx` (281),
`UserManagement.tsx` (431), `PortfolioMembers.tsx` (239), `Delegation`,
`SkillRoutingSection.tsx` (309, helper). `delegation-management/
DelegationManagement.tsx` (271) — **`/admin/delegation-management` (NEW)**.

**Compliance section** — `Compliance/`: `CompliancePosture.tsx` (629),
`CatoEvidence.tsx` (576), `ApplicationCompliance`, `SecurityPosture.tsx` (367).
`evidence-ledger/EvidenceLedgerPage.tsx` (505) — **`/compliance/evidence-ledger` (NEW)**.

**About section** — `AboutOverview/AboutOverview.tsx` (620) `/about`;
`GettingStarted/` `/getting-started`.

**Auth (outside Layout)** — `Auth/Login.tsx`, `Auth/OidcCallback.tsx`.

**Demo (outside Layout)** — `OneStopShopDemo/OneStopShopDemo.tsx` (473)
`/demo/one-stop-shop`; `DemoColdOpen/DemoColdOpen.tsx` (277) `/demo/cold-open`.

**Misc** — `NotFound.tsx` (`*`), `PlaceholderPage.tsx` (shared placeholder).

**Shared components** (`dashboard/src/components/`, ~60 dirs/files — deep-dives in
parts 2+): Chat/ (ChatDrawer), GateReview/, GateReviewCards/, charts/, viewers/,
AssemblyLinePipeline, PipelineNodeGraph, PhaseRibbon, WorkflowStepper,
WorkflowControl, NeedsMyAttention, PendingGatesQueue, GateCardList,
OnboardingWizard, OnboardingCarousel, ApplicationOnboardingForm, CreateModal,
DataGrid, StatusBadge, ScoreBar, TabNav, TraceId, Markdown, Glossary, Insights,
ErrorBoundary, EmptyState, WorkflowFailureBanner, WorkflowRoutingDialog,
PreDispatchPanel, SkillDispatchExplorer, ModelUsageChart, Tier1ApprovalPanel,
WaveSynthesis, WaveRoadmap, WaveGateDecisions, WavePerformanceReport,
WavePlanEmbed, WaveWorkflowProgress, WaveRecoveryBanner, WaveBusinessRuleOverlap,
FanOutStatusTable, RedundancyMatrix helpers, StaleArtifactsCard,
MyTasksSummaryCard, RenditionsDownloadMenu, MoveToWaveDialog, ProfileBundleModal,
CancelAllChildrenButton, ConsolidatedBanner, CapabilityClusterSummary,
CapabilitySystemCallout, LineageBadge, ActorKindBadge,
ApplicationDispositionChips, AgentActivityByLine, LineAnatomy,
ComplianceDashboard, TraceabilityExplorer.

---

## 12. Reproduction gotchas (consolidated)

1. `installDemoToastGuard` is called at `App.tsx` MODULE LOAD, not in a
   component — reproduce that timing or early toasts leak through.
2. `useTheme` sets `data-theme` on `<html>` at module load (pre-React) to avoid
   FOUC — a pure `useEffect` would flash the wrong theme.
3. `autonomy.ts` uses the bare `/autonomy/*` prefix; every other module uses
   `/api/v1/*`.
4. SSE fallback passes the JWT via `?access_token=` (EventSource can't set
   headers); WS uses no auth on the URL.
5. `usePollingBackoff` + `shouldPollTick` couple demo mode to tab visibility.
6. `useSubmitGateDecision` short-circuits in demo mode (no backend POST).
7. Router: `RequireAuth` wraps everything; the `*` catch-all is INSIDE the
   guarded Layout, so anon 404s redirect to /login instead of NotFound.
8. `useChatContext` must test `wave:<id>` (regex) BEFORE the bare `/waves`
   `startsWith`.
9. `evidence.ts` satisfaction counting is ratified-only (`controlIsSatisfied`) —
   the single load-bearing chokepoint.
10. The 401 interceptor whitelists `/auth/login|config|callback` so login errors
    stay inline (no redirect loop).
11. `resolveActiveSection` skips the `"/"` section in its loop; Portfolio is
    reached only by fallback.
12. Streaming `onDone` can fire twice (event + loop end) — consumers must be
    idempotent.
