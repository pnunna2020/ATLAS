# 01 — Olympus API (Part 1): App Factory, Middleware, Auth, Signal Plumbing, and the Largest Routers

> ATOMIC regeneration spec. Behavioral parity is the bar. All facts derived from live code at
> `/Users/pnunna/Documents/GitHub/olympus/olympus-api/`. Every non-trivial claim is cited
> `path:line`. Canonical tree only (no `build/lib`, `.venv`, `__pycache__`, `.claude/worktrees`).
>
> Scope of this document: the app-wide sections (app factory, middleware stack, auth/RBAC,
> gate-signal → Temporal plumbing) plus the largest routers:
> `waves.py` (32 endpoints), `applications.py` (31), `portfolio.py`, `portfolio_members.py`,
> `systems.py`, `lines.py`. Other routers are covered in sibling docs.

---

## §0. Package layout (`olympus-api/src/`)

- `main.py` — app factory (`create_app`) + lifespan (`_lifespan`) + `_configure_logging`.
- `config.py` — `AppConfig` (pydantic-settings) + fail-closed guards.
- `dependencies.py` — DI providers: temporal client cache, config singleton, portfolio-scope RBAC helpers.
- `middleware/` — `auth.py`, `request_id.py`, `rate_limit.py`, `metrics.py`, `error_handler.py`, `pagination.py`.
- `observability/` — optional OpenTelemetry `TracingMiddleware` + `setup_tracing`.
- `models/common.py` — `RBACRole`, `SourceType`, `EventType`, pagination + error envelopes; re-exports contract enums.
- `auth/user_tokens.py`, `auth/service_tokens.py` — JWT issuance.
- `services/oidc.py` — OIDC login (438 LOC; covered in the auth-router doc, referenced here).
- `routers/*.py` — 55 router modules.

The app is started with `uvicorn src.main:create_app --factory --reload --port 8000` (`main.py:3-4`).

---

## §1. App factory — `create_app()` (`main.py:157-288`)

Exact construction order (each step is load-bearing; reproduce in this order):

1. `config = AppConfig()` (`:159`).
2. `_configure_logging(config.log_level)` (`:160`) — see §1.1.
3. **`assert_secure_auth_posture()`** (`:166`) — fail-closed boot guard (§3.1). Runs BEFORE the app object exists.
4. `init_db(config)` (`:169`) — DB engine/session init must precede lifespan.
5. Construct `FastAPI(title="Olympus API", description="Olympus platform backend — portfolio management and orchestration", version=config.version, lifespan=_lifespan)` (`:171-176`).
6. **`assert_safe_cors(config.cors_origins, allow_credentials=True)`** (`:188`) — reject credentialed CORS wildcard BEFORE wiring middleware (§3.2).
7. Register middleware in the exact order in §2.
8. `setup_tracing(app, service_name=config.service_name)` (`:213`) — instruments FastAPI/httpx when OTel is enabled; idempotent + failure-swallowing.
9. `register_error_handlers(app)` (`:216`) — §4.
10. Register routers in the exact order in §5 (mount order matters — see the traceability-before-artifacts note).

### §1.1 `_configure_logging(log_level)` (`main.py:85-105`)

Configures `structlog` with this processor chain (order preserved): `merge_contextvars`,
`filter_by_level`, `add_logger_name`, `add_log_level`, `PositionalArgumentsFormatter`,
`TimeStamper(fmt="iso")`, `StackInfoRenderer`, `format_exc_info`, `UnicodeDecoder`,
`ConsoleRenderer` (`:88-99`). `wrapper_class=BoundLogger`, `context_class=dict`,
`logger_factory=LoggerFactory()`, **`cache_logger_on_first_use=True`** (`:100-103`). Then
`logging.basicConfig(level=getattr(logging, log_level.upper(), logging.INFO))` (`:105`).

> **GOTCHA** (`main.py:103`): `cache_logger_on_first_use=True` means a module-level cached logger
> captured at import will not pick up a later processor swap. Call sites that must be visible to
> test-time `capture_logs` bind the logger at call time via `structlog.get_logger(__name__)` — see
> `lines.py:907` `dispatch_skill`.

### §1.2 Lifespan `_lifespan(app)` (`main.py:108-154`)

Async context manager. On startup, in order:

1. Import `hydrate_portfolios_from_db`, `activate_profile`/`ProfileActivationError`, `bootstrap_skills` locally (`:111-116`).
2. `activate_profile()` inside try/except — on `ProfileActivationError` log `profile_activation.failed` and **re-raise** (fatal: refuse to serve on a half-configured platform) (`:123-127`). Populates the 6 extensibility registries before any handler reads them.
3. `count = 0`. Then `async for db in get_db():` — first (and only) session:
   - `count = await bootstrap_skills(db)`; on any exception log `skill_bootstrap.failed`, set `count = 0` (`:131-136`).
   - `hydrated = await hydrate_portfolios_from_db(db)`; log `portfolio_hydrate.complete` with `count=hydrated`; on exception log `portfolio_hydrate.failed` (`:137-141`).
   - `break` after the first session (`:142`).
   - The whole `async for` is wrapped in try/except → on failure log `skill_bootstrap.db_unavailable` (`:143-144`).
4. `set_skill_count(count)` (`:146`). If `count == 0`, log `startup.no_skills` error "No skills loaded — system will report as unhealthy" (`:148-152`).
5. `yield` (no shutdown teardown) (`:154`).

---

## §2. Middleware stack — ORDER IS LOAD-BEARING (`main.py:189-209`)

Starlette runs middleware in **registration order**, with the **last-registered being the innermost**
(`main.py:178-185`). Registration order (outermost → innermost):

1. **CORSMiddleware** (`:189-201`): `allow_origins=config.cors_origins`, `allow_credentials=True`,
   `allow_methods=["*"]`, `allow_headers=["*"]`, **`expose_headers=["X-Trace-ID","X-Request-ID"]`**
   (the SPA cannot read those response headers from JS without this list — `:195-200`).
2. **RequestIdMiddleware** (`:202`).
3. **TracingMiddleware** (`:207`) — registered just inside RequestId so the correlation id is set when the trace id binds.
4. **RateLimitMiddleware** (`:208`).
5. **MetricsMiddleware** (`:209`).

Effective per-request flow: `CORS → RequestId → Tracing → RateLimit → Metrics → routes`
(`main.py:182-185` states the intended `CORS → RequestId → RateLimit → Metrics → routes`; Tracing is
inserted between RequestId and RateLimit at `:207`). Rationale in comments: request_id is available
inside rate-limit errors; the metrics counter sees the final response status; the rate limiter can
short-circuit before business logic.

### §2.1 RequestIdMiddleware (`middleware/request_id.py`)

- Module contextvar `request_id_ctx: ContextVar[str]` default `""` (`:34`).
- `get_request_id()` / `get_trace_id()` both return `request_id_ctx.get()` — request_id and trace_id
  are the **same** value; dual accessor names only (`:37-48`).
- `dispatch` (`:61-81`):
  1. `rid = request.headers.get("X-Trace-ID") or request.headers.get("X-Request-ID") or f"req-{uuid.uuid4().hex[:12]}"` (`:64-68`). An inbound trace id flows through unchanged.
  2. `token = request_id_ctx.set(rid)`; `structlog.contextvars.bind_contextvars(trace_id=rid)` (`:69-73`).
  3. `response = await call_next(request)`; set `response.headers["X-Request-ID"] = rid` and `["X-Trace-ID"] = rid` (`:74-77`).
  4. `finally`: `unbind_contextvars("trace_id")`; `request_id_ctx.reset(token)` (`:79-81`).

### §2.2 RateLimitMiddleware (`middleware/rate_limit.py`)

Sliding-window, in-process, keyed on JWT `sub` (falling back to client IP). Three tiers.

**Config `RateLimitConfig.__init__` (`:101-113`)** — read once per middleware init:
- `env = APP_ENV.lower()`; `in_pytest = "PYTEST_CURRENT_TEST" in os.environ`; `default_enabled = env != "test" and not in_pytest` (`:102-104`). So the limiter is OFF in tests by default.
- `enabled = _env_bool("RATE_LIMIT_ENABLED", default_enabled)` (`:105`).
- `per_service = _env_int("RATE_LIMIT_PER_SERVICE_PER_MIN", 6000)` (`:106`).
- `per_user = _env_int("RATE_LIMIT_PER_USER_PER_MIN", 600)` (`:107`).
- `per_ip = _env_int("RATE_LIMIT_PER_IP_PER_MIN", 60)` (`:108`).
- `window_seconds = _env_int("RATE_LIMIT_WINDOW_SECONDS", 60)` (`:109`).
- `exempt_prefixes = _env_list("RATE_LIMIT_EXEMPT_PREFIXES", ["/health","/system/metrics","/docs","/openapi.json","/redoc"])` (`:110-113`).

Env parsers: `_env_int` ignores blanks/garbage → default (`:64-72`); `_env_bool` truthy set `{"1","true","yes","on"}` (`:75-79`); `_env_list` splits on commas, strips (`:82-86`).

**`_extract_subject(request)` (`:116-142`)**: returns `(sub, is_service)` or `None`. If Authorization
header isn't `Bearer `, return None. Decode via `jwt.get_unverified_claims(token)` (no signature check
— key is opaque; tampered tokens still fail auth downstream) (`:130-136`). `sub` must be a non-empty
str else None. `is_service = isinstance(roles, list) and "service" in roles` (`:140-141`).

**`_client_ip(request)` (`:145-152`)**: prefers first entry of `X-Forwarded-For`; else `request.client.host`; else `"unknown"`.

**`_SlidingWindow` (`:155-194`)**: one `deque` per key, single coarse `Lock`. `check(key, limit)` (`:168-190`):
- `now = time.time()`, `cutoff = now - window`.
- Prune `bucket[0] < cutoff` from the left.
- If `len(bucket) >= limit`: return `(False, 0, bucket[0]+window)`.
- Else append `now`, `remaining = max(0, limit - len(bucket))`, `reset = bucket[0]+window`, return `(True, remaining, reset)`.

Module singletons `_config = RateLimitConfig()`, `_counter = _SlidingWindow(_config.window_seconds)`
(`:198-199`). `reload_config()` + `reset_rate_limit_state()` for tests (`:202-211`).

**`dispatch` (`:217-273`)**:
1. If `not _config.enabled`: pass through (`:220-221`).
2. If `path` starts with any exempt prefix: pass through (`:224-226`).
3. `extracted = _extract_subject(request)`. If present: service → `key=f"service:{sub}"`, `limit=per_service`; else `key=f"user:{sub}"`, `limit=per_user`. Else `key=f"ip:{client_ip}"`, `limit=per_ip` (`:228-239`).
4. `allowed, remaining, reset_epoch = _counter.check(key, limit)` (`:241`).
5. If not allowed: `record_rate_limited()`; `retry_after = max(1, int(reset_epoch - time.time()))`; return **429** JSONResponse with body `{"error": {"code":"RATE_LIMITED","message":f"Rate limit exceeded ({limit}/min). Try again in {retry_after}s.","details":{"limit":limit,"retry_after":retry_after},"request_id":get_request_id()}}` and headers `X-RateLimit-Limit`, `X-RateLimit-Remaining="0"`, `X-RateLimit-Reset`, `Retry-After` (`:243-267`).
6. Else `response = await call_next(...)`, set `X-RateLimit-Limit/Remaining/Reset` headers, return (`:269-273`).

### §2.3 MetricsMiddleware (`middleware/metrics.py`)

In-process Prometheus-style counters (no `prometheus_client` dep). Module state under a `Lock`:
`_requests_total: dict[(method, path_template, status)→int]`, `_request_duration: dict[(method, path_template)→{sum,count}]`,
`_rate_limited_total: int` (`:36-41`).

`_path_template(request)` (`:44-51`): `request.scope["route"].path` if present (bounded cardinality),
else `"<unmatched>"` (collapses 404s).

`dispatch` (`:83-114`): `t0 = time.monotonic()`. Wrap `call_next` in try/except: **on exception**,
record `(method, template, "500")` and duration BEFORE re-raising (`:88-101`). On success, record
`(method, template, str(response.status_code))` and duration (`:103-113`). `record_rate_limited()`
increments `_rate_limited_total` (`:54-58`); `collect_metrics()` snapshots (`:70-77`); `reset_metrics()`
clears (`:61-67`). The `/system/metrics` endpoint renders these.

### §2.4 TracingMiddleware / `setup_tracing` (`observability/__init__.py`, `observability/tracing.py`)

Pure no-op unless BOTH: the `opentelemetry` SDK is installed AND `OTEL_TRACING_ENABLED` is truthy
(`observability/__init__.py:3-13`). When off, importing the package pulls in zero OTel modules.
`get_trace_id()` returns the active OTel trace id when enabled, else falls back to the request_id — one
correlation id, not two (`:21-24`). Public surface: `TracingMiddleware`, `setup_tracing`,
`get_trace_id`, `extract_trace_context`, `inject_trace_headers`, `otel_tracing_enabled`,
`HEADER_TRACEPARENT`, `HEADER_TRACESTATE` (`__all__`, `:33-42`).

---

## §3. Boot-time fail-closed guards (`config.py`)

### §3.1 `assert_secure_auth_posture(env=None)` (`config.py:49-87`)

Non-prod envs where insecure defaults are tolerated: `_NON_PROD_ENVS = {"dev","local","test"}` (`:20`).
`_is_production(env)` → `env.get("APP_ENV","").strip().lower() not in _NON_PROD_ENVS` — **an UNSET
APP_ENV is treated as production** (`:35-42`). `_truthy(v)` → `(v or "").strip().lower() == "true"` (`:45-46`).

Reads `os.environ` fresh (not the frozen module globals in `middleware/auth.py`) so it reflects the
actual runtime env and is unit-testable (`:57-63`). If not production, return immediately (`:64-65`).
Otherwise accumulate `violations`:
- `AUTH_SKIP_VERIFICATION=true` → "disables JWT signature verification" (`:68-71`).
- `DEV_AUTH_BYPASS=true` → "grants an all-roles user with no token" (`:72-73`).
- `JWT_SECRET` unset/blank OR equal to `_DEFAULT_JWT_SECRET = "olympus-dev-secret"` → "is unset or the shipped default" (`:24, 74-78`).

If any violations: raise `InsecureProductionConfigError` (subclass of `RuntimeError`, `:27-32`) listing every violation (`:80-87`).

### §3.2 `assert_safe_cors(cors_origins, allow_credentials)` (`config.py:90-101`)

If `allow_credentials and "*" in cors_origins`: raise `InsecureProductionConfigError` — a credentialed
CORS wildcard is forbidden (browser rejects it; would echo arbitrary origins with credentials).

### §3.3 `AppConfig` (`config.py:104-196`) — key fields (pydantic-settings, `env_file=".env"`)

`service_name="olympus-api"`, `version="0.1.0"`, `log_level="INFO"`, `api_port=8000`;
DB component vars `database_host/port/name/user/password` (defaults `localhost/5432/olympus/olympus/olympus_dev`);
`temporal_host="localhost:7233"`, `temporal_namespace="default"`, `temporal_task_queue="olympus-main"`,
`temporal_ui_base_url="http://localhost:8080"`; `workflow_staleness_minutes=30`,
`workflow_cancel_grace_seconds=30`; `cors_origins=["http://localhost:3000"]`;
`redis_url`, `mcp_server_url="http://localhost:3001"`; GitHub `github_token=""`, `github_repo=""`,
`github_base_url="https://api.github.com"`, `github_webhook_secret=""`;
`source_intake_root="/workspace/sources"`, `source_intake_max_upload_bytes=500*1024*1024`,
`source_intake_s3_region=""`; `connected_memory_enabled=False` (`:107-172`).
`get_database_url()` validates all four DB vars present, url-quotes the password, composes
`postgresql://user:pw@host:port/name` (`:176-192`); `get_async_database_url()` swaps scheme to
`postgresql+asyncpg://` (`:194-196`).

---

## §4. Error handlers (`middleware/error_handler.py`)

`OlympusHTTPException(status_code, code, message, details=None)` — subclass of
`StarletteHTTPException`, carries a machine-readable `code` + optional `error_details` (`:23-35`).

`_error_response(status_code, code, message, details=None)` (`:38-57`): builds
```
{"error": {"code": code, "message": message, "details": details or {},
           "request_id": get_request_id(), "trace_id": get_trace_id()}}
```
`request_id` and `trace_id` are the same correlation id. Also sets `X-Trace-ID`/`X-Request-ID` headers
because the error path bypasses the normal middleware response (`:44-57`).

`register_error_handlers(app)` (`:60-118`) registers 4 handlers:
- `OlympusHTTPException` → `_error_response(status, code, detail, error_details)` (`:63-70`).
- `StarletteHTTPException` → code from `code_map` `{400:BAD_REQUEST,401:UNAUTHORIZED,403:FORBIDDEN,404:NOT_FOUND,409:CONFLICT,422:VALIDATION_ERROR,429:RATE_LIMITED}` else `"ERROR"` (`:72-84`).
- `RequestValidationError` → 422 `VALIDATION_ERROR`. **GOTCHA** (`:86-113`): pydantic model-validator errors carry a `ctx.error` that is a raw exception (not JSON-serializable). It stringifies any non-primitive `ctx` value and reprs any non-primitive `input` (e.g. `UploadFile` on multipart routes) so the envelope never blows up mid-serialization. `details = {"errors": safe_errors}`.
- `Exception` (catch-all) → log `unhandled_exception` with `exc_info=True`, return 500 `INTERNAL_ERROR` "An internal error occurred" (`:115-118`).

---

## §5. Router mount order (`main.py:219-286`)

Preserve this exact `include_router` order. Two orderings are **load-bearing**:

- **traceability BEFORE artifacts** (`:241-245`): `/api/v1/artifacts/stale` (traceability) must match before the generic `/api/v1/artifacts/{app_id}` UUID path.
- `wave_gates_router` mounts under `/api/v1/waves` for `POST /{id}/gates/approve-pending` (`:232`).

Full order: health, system, systems, auth, portfolio, profiles, portfolio_profile, registries,
reusable_parts, applications, gates, wave_gates, events, activity, analytics, waves, git, lines,
line_start, workflow_signals, traceability, artifacts, escalations, feedback, governance,
evidence_ledger, evidence_runs, drift_reports, autonomy, autonomy_incidents, capabilities, evals,
decomp, intake, chat, delegations, renditions, skills, webhooks, workflows, agent_runs, runs, agents,
agent_roles, admin, admin_audit, portfolio_members, bundles, admin_bundles, users, me,
human_paired_agent (`:219-286`).

---

## §6. Auth / RBAC (JWT / OIDC / service-token)

### §6.1 The 9 roles (`models/common.py:56-65`)

`RBACRole` (str enum): `portfolio_admin`, `portfolio_manager`, `tech_lead`, `arch_lead`,
`compliance_lead`, `operations_lead`, `safety_board`, `viewer`, `service`.

### §6.2 JWT decode + `CurrentUser` (`middleware/auth.py`)

Module globals frozen at import (`:26-29`):
`_JWT_SECRET = os.environ.get("JWT_SECRET","olympus-dev-secret")`,
`_JWT_ALGORITHM = os.environ.get("JWT_ALGORITHM","HS256")`,
`_AUTH_SKIP_VERIFICATION = os.environ.get("AUTH_SKIP_VERIFICATION","true").lower()=="true"` (**defaults to true** — dev-friendly, prod-blocked by §3.1),
`_DEV_AUTH_BYPASS = os.environ.get("DEV_AUTH_BYPASS","").lower()=="true"`.

`CurrentUser(sub, roles, claims)` (`:32-41`): `has_role(*roles)` → `any(r in self.roles for r in roles)`.

`_extract_token(request)` (`:44-49`): returns `auth[7:]` if header starts with `"Bearer "`, else None.

`_user_from_token(token)` (`:52-102`):
1. If `_DEV_AUTH_BYPASS`: return `CurrentUser(sub="local-dev", roles=list(RBACRole), claims={"sub":"local-dev","dev_bypass":True})` — **all roles, no token** (`:61-66`).
2. If not token: raise **401** "Missing authorization token" (`:68-69`).
3. `options = {}`; if `_AUTH_SKIP_VERIFICATION`: `options = {"verify_signature":False,"verify_exp":False,"verify_aud":False}` (`:72-78`).
4. `jwt.decode(token, _JWT_SECRET, algorithms=[_JWT_ALGORITHM], options=options)`; on `JWTError` log `jwt_decode_failed` + raise **401** "Invalid or expired token" (`:79-87`).
5. `sub = payload.get("sub","anonymous")`; parse `payload.get("roles",[])` into `RBACRole` (unknown role → log `unknown_role_in_token`, skip); if none → `[RBACRole.VIEWER]` (`:89-101`).
6. Return `CurrentUser(sub, roles, payload)`.

`get_current_user(request)` (`:105-114`): the header-based dependency → `_user_from_token(_extract_token(request))`.

`get_current_user_sse(request)` (`:117-128`): SSE variant — accepts token from header OR `access_token`
query param (EventSource can't set headers). Only the SSE endpoint accepts a query-param token.

`require_role(*required_roles)` (`:131-144`): dependency factory. `_check` depends on `get_current_user`;
if `not user.has_role(*required_roles)` raise **403** `f"Requires one of: {[r.value for r in required_roles]}"`; else return user.

### §6.3 Token issuance

**User tokens** (`auth/user_tokens.py`): `issue_user_token(user_id, username, roles, identity_provider, ttl_seconds=8h, secret=None, algorithm=None)` (`:21-48`). Payload: `{sub:str(user_id), username, roles:list, identity_provider, iat, exp:now+ttl}`. `DEFAULT_USER_TTL_SECONDS = 8*60*60` (`:18`). Secret/alg default to env `JWT_SECRET`/`JWT_ALGORITHM` (`:46-47`). `sub` is the UUID (stable across renames).

**Service tokens** (`auth/service_tokens.py`): `issue_service_token(service, ttl_seconds=3600, secret=None, algorithm=None)` (`:22-49`). `SERVICE_IDENTITIES = ("agent-runtime","worker")` (`:19`); unknown service → `ValueError`. Payload: `{sub:f"service:{service}", roles:[RBACRole.SERVICE.value], iat, exp:now+ttl, service}`. `DEFAULT_TTL_SECONDS = 3600` (`:18`). Both token shapes flow through the SAME `middleware/auth.py` decoder, so `require_role` accepts either.

**OIDC** (`services/oidc.py`, 438 LOC): human login via IdP → JWKS validation → mints a user token. Full behavior in the auth-router doc.

### §6.4 Portfolio-scoped RBAC helpers (`dependencies.py`)

Retirement note (`:46-84`): the existence-only `require_portfolio_member` was retired in P6-S15.8
because it could not distinguish a `viewer` from a `tech_lead` — use the role-consulting helpers below.
All preserve the global `portfolio_admin` bypass and never loosen membership.

`get_config()` (`:28-31`): `@lru_cache` singleton `AppConfig`.

`get_temporal_client()` (`:34-43`): module-level `_temporal_client` cache; lazily `Client.connect(config.temporal_host, namespace=config.temporal_namespace)`.

`_role_value(role)` (`:87-91`): normalize `RBACRole|str|None` → string (`""` for None; `.value` for enum).

`resolve_portfolio_role(db, user, portfolio_id) → str|None` (`:94-113`): if `user.has_role(PORTFOLIO_ADMIN)` return `"portfolio_admin"`; else `row = membership_svc.get_membership(...)`, `None` if no row, else `_role_value(row.role)` (plain string so profile-extension roles like `faa_issm` round-trip).

`require_portfolio_scoped_role(db, user, portfolio_id, required_roles, *, allow_portfolio_admin_bypass=True) → str` (`:116-166`): service-level. Admin bypass returns `"portfolio_admin"`. No membership row → **403** `PORTFOLIO_NOT_MEMBER`. Row role not in `required_roles` → **403** `PORTFOLIO_ROLE_INSUFFICIENT` (message lists `sorted(required_roles)`). Returns the scoped-role string.

`require_portfolio_role(*required_roles, allow_portfolio_admin_bypass=True)` (`:169-207`): **path-style dependency factory** for routes with `{portfolio_id}` in the path. `_check` depends on Path `portfolio_id`, `get_current_user`, `get_db`; calls `require_portfolio_scoped_role`; returns the user.

`verify_portfolio_access(db, user, portfolio_id) → None` (`:210-238`): service-level membership check for query/body portfolio ids. Admin → return. `membership_svc.is_member(...)` → return; else **403** `PORTFOLIO_NOT_MEMBER`.

Path-style member dependencies (each admin-short-circuits, then resolves the entity's portfolio and calls `verify_portfolio_access`):
- `require_application_member` (`:241-264`) — `{app_id}`; admin short-circuits WITHOUT resolving (avoids a redundant query the handler repeats).
- `require_wave_member` (`:267-276`) — `{wave_id}`.
- `require_gate_member` (`:279-288`) — `{gate_id}`.
- `require_system_member` (`:427-436`) — `{system_id}`.
- `require_capability_member` (`:439-448`) — `{capability_id}`.
- `require_capability_lineage_member` (`:451-460`) — `{lineage_id}`.

Portfolio resolvers (each admin → return `None`; entity-not-found → **404**; else `verify_portfolio_access`):
- `verify_application_portfolio_access` (`:291-320`): `SELECT portfolio_id FROM application WHERE id=:aid`. Returns portfolio_id for reuse.
- `verify_wave_portfolio_access` (`:323-347`): `SELECT portfolio_id FROM wave WHERE id=:wid`.
- `verify_system_portfolio_access` (`:350-369`): `SELECT portfolio_id FROM system WHERE id=:sid`.
- `verify_capability_portfolio_access` (`:372-396`): `capability c JOIN system s ON s.id=c.system_id`.
- `verify_capability_lineage_portfolio_access` (`:399-424`): `capability_lineage cl JOIN capability c ON c.id=cl.target_capability_id JOIN system s`.
- `verify_gate_portfolio_access` (`:463-493`): `SELECT COALESCE(a.portfolio_id, w.portfolio_id) FROM gate g LEFT JOIN application a ON a.id=g.application_id LEFT JOIN wave w ON w.id=g.wave_id WHERE g.id=:gid`. A gate has either `application_id` or `wave_id` set (migration 042). Row absent OR portfolio_id NULL → **404**.

`filter_portfolio_ids_by_membership(db, user, candidate_portfolio_ids=None) → list[UUID]|None` (`:496-518`): admin → `None` ("no filter"); else `member_ids = membership_svc.list_user_portfolio_ids(...)`; if candidates given, intersect; else return member_ids. List endpoints wrap queries in `WHERE portfolio_id = ANY(:ids)` when this returns a list, no-op on None.

`authorize_delegated_action_or_refuse(db, *, grantor, grant_id, action_id, portfolio_id=None, session_id, intent_id, resource_id)` (`:537-582`): loads the grant (404 if absent), runs `delegation_svc.authorize_delegated_action` `(grantor RBAC) ∩ (grant scope)`; on `DelegationError` records the refusal and raises `HTTPException(exc.status_code, exc.detail)`; on success returns None. This is a guard call, not a route — the delegated action rides the SAME endpoint a direct caller would.

### §6.5 Pagination (`middleware/pagination.py`)

`PaginationParams(page, per_page)` dataclass, `.offset = (page-1)*per_page` (`:16-25`).
`get_pagination(page=Query(1,ge=1), per_page=Query(20,ge=1,le=100))` dependency (`:28-33`).
`paginated_response(items, total, params)` → `{"data": items, "pagination": {page, per_page, total, total_pages: max(1, ceil(total/per_page))}}` (`:36-47`).

---

## §7. Gate-signal → Temporal plumbing (`routers/gates.py` + `services/gate.py`)

### §7.1 Role sets (`gates.py:58-84`)

`VIEWER_PLUS` = all 8 human roles. `REVIEWER_ROLES` = the 8 minus VIEWER (tech_lead, arch_lead,
compliance_lead, operations_lead, safety_board, portfolio_manager, portfolio_admin). `MANAGER_ROLES` =
`[PORTFOLIO_MANAGER, PORTFOLIO_ADMIN]`.

Two routers: `router` at `/api/v1/gates` (`:86`); `wave_gates_router` at `/api/v1/waves` (`:92-95`).

`_ESCALATE_REASONS` / `_ESCALATION_RESOLUTION_CATEGORIES` = `set(get_args(...))` of the literal types, validated at import (`:53-56`).

### §7.2 `_enforce_gate_reviewer(db, user, gate_id)` (`gates.py:151-195`)

1. `gate_type, portfolio_id = gate_svc.get_gate_type_and_portfolio(db, gate_id)`.
2. `scoped_role = resolve_portfolio_role(db, user, portfolio_id)` if portfolio resolved, ELSE `"portfolio_admin"` if the caller is admin, ELSE None (orphaned gate fallback so it isn't permanently unreviewable) (`:171-177`).
3. `scoped_role is None` → **403** `PORTFOLIO_NOT_MEMBER` (`:178-183`).
4. `policy = resolve_gate_review_policy(gate_type)`; `decision = evaluate_approver(policy, scoped_role)`.
5. `not decision.allowed` → **403** `PORTFOLIO_ROLE_INSUFFICIENT` (message lists `sorted(policy.allowed_approver_roles())`).
6. Returns `(policy, scoped_role, decision)`.

`_enforce_gate_decider(db, user, gate_id) → str` (`:198-237`): same portfolio/role resolution, but
`permitted = set(policy.required_reviewer_roles) | set(MANAGEMENT_ROLES)` — reject/escalate/retry is
ALWAYS allowed for a reviewer or management role, independent of `management_override_allowed` (rework
is always allowed). Not in permitted → **403** `PORTFOLIO_ROLE_INSUFFICIENT`.

`gate_rbac`: `GateReviewPolicy.allowed_approver_roles()` = `required_reviewer_roles ∪ MANAGEMENT_ROLES`
only when `management_override_allowed` (`gate_rbac.py:97-107`). `MANAGEMENT_ROLES = (portfolio_manager, portfolio_admin)` (`:31`). `evaluate_approver` returns an `ApproverDecision(allowed, is_oversight, is_management_override)` (`:117-119`).

### §7.3 Gate endpoints (mount order)

| Method | Path | Auth | Request | Response | Codes | Line |
|---|---|---|---|---|---|---|
| GET | `/api/v1/gates/pending` | `get_current_user` | query `portfolio_id?`, `wave_id?`, `status="pending"` pattern `^(pending\|rejected\|approved\|escalated\|all)$`, pagination | paginated dict | 200/403 | `gates.py:98` |
| POST | `/api/v1/gates/{gate_id}/approve` | dep `require_gate_member` + `get_current_user` | `GateApproveRequest?` | `GateDetail` | 200/403/404/409 | `:240` |
| POST | `/api/v1/gates/{gate_id}/reject` | dep `require_gate_member` + `get_current_user` | `GateRejectRequest` | `GateDetail` | 200/403/404/409 | `:290` |
| GET | `/api/v1/gates/{gate_id}/evidence` | dep `require_gate_member` + `require_role(*VIEWER_PLUS)` | — | `GateEvidencePackage` | 200/403/404 | `:322` |
| GET | `/api/v1/gates/{gate_id}/reviewer-roles` | dep `require_gate_member` + `get_current_user` | — | dict | 200 | `:342` |
| POST | `/api/v1/gates/{gate_id}/decision` | dep `require_gate_member` + `get_current_user` | `GateDecisionRequest` | `GateDetail` | 200/400/403/404/409 | `:390` |
| POST | `/api/v1/gates/{gate_id}/retry-merge` | dep `require_gate_member` + `require_role(*REVIEWER_ROLES)` | `GateMergeRetryRequest?` | `GateDetail` | 200/403/409 | `:512` |
| POST | `/api/v1/gates/{gate_id}/force-advance` | dep `require_gate_member` + `require_role(*MANAGER_ROLES)` | `GateForceAdvanceRequest` | `GateDetail` | 200/403/409 | `:544` |
| POST | `/api/v1/gates/{gate_id}/resolve-escalation` | dep `require_gate_member` + `require_role(*REVIEWER_ROLES)` | `GateEscalationResolveRequest` | `GateDetail` | 200/400 | `:596` |
| POST | `/api/v1/waves/{wave_id}/gates/approve-pending` | `require_role(*REVIEWER_ROLES)` | `WaveBatchApproveRequest`, query `gate_type?` | `WaveBatchApproveResponse` | 200 | `:640` (wave_gates_router) |

**`list_pending_gates` (`:98-148`)**: if `portfolio_id` given, `verify_portfolio_access`; `member_ids = filter_portfolio_ids_by_membership(...)`; `gate_svc.list_pending_gates(db, pagination, portfolio_id=, portfolio_ids=member_ids, wave_id=, status=)` → `paginated_response`. Non-admin: restricted to member portfolios; explicit outside-membership `portfolio_id` yields empty.

**`approve_gate` (`:245-287`)**: `comment = body.comment if body else None`; `policy, scoped_role, decision = _enforce_gate_reviewer(...)`; `result, advanced = gate_svc.record_gate_approval(db, gate_id, user.sub, scoped_role, minimum_approvals=policy.minimum_approvals, oversight_role=policy.oversight_role, is_oversight=decision.is_oversight, is_management_override=decision.is_management_override, comment=comment)`. **Fire the Temporal signal ONLY when `advanced` is True** — a pending quorum gate must NOT signal (`:283-286`).

**`reject_gate` (`:295-319`)**: `_enforce_gate_decider(...)`; `gate_svc.reject_gate(...reason_category=body.reason_category)`; then fire-and-forget `send_gate_temporal_signal(..., "reject", ..., body.feedback, reason_category=)`.

**`submit_gate_decision` (`:395-509`)** (unified approve/reject/escalate):
1. If `body.action == "escalate"`: `reason_category` required (400 `ESCALATE_REASON_REQUIRED`) and must be in `_ESCALATE_REASONS` (400 `ESCALATE_REASON_INVALID`) (`:416-432`).
2. Serialize `card_decisions` and `capability_lineage_decisions` to dicts (`:437-454`).
3. For each capability-lineage row with `decision == "reject"` and empty feedback → 400 `CAPABILITY_LINEAGE_REJECT_FEEDBACK_REQUIRED` (`:460-472`).
4. RBAC (after cheap 400s): `approve` → `_enforce_gate_reviewer`; else `_enforce_gate_decider` (`:474-478`).
5. `gate_svc.submit_gate_decision(...)`; then if action in `("approve","reject")` fire `send_gate_temporal_signal` (reason_category only on reject) (`:480-508`).

**`retry_merge` (`:517-541`)**: `gate_svc.retry_merge_gate(db, gate_id, user.sub, note)` — 409 `GATE_NOT_MERGE_BLOCKED` if the gate isn't `merge_blocked`; resets to `approved`, clears `merge_failure_detail`, fires `merge_retry` signal.

**`force_advance_gate` (`:549-593`)**: resolve gate_type + policy. If `not policy.management_override_allowed` → **403** `GATE_NOT_OVERRIDABLE` (a non-overridable gate — e.g. FAA G-V3 — cannot be force-advanced by ANY role incl. portfolio_admin; can still be rejected) (`:571-584`). Else `gate_svc.force_advance_gate(db, gate_id, advanced_by=user.sub, comment=, bypass_evidence_check=, config=)`.

**`resolve_escalation` (`:601-632`)**: `resolution_category` must be in `_ESCALATION_RESOLUTION_CATEGORIES` else 400 `ESCALATION_RESOLUTION_INVALID`; `gate_svc.resolve_escalation(...)`. `re-*` → back to `pending`; `rejected-as-escalated` → `rejected`.

**`approve_pending_wave_gates` (`:644-730`)** — batch, per-gate resilient:
1. `rows = gate_svc.list_pending_wave_gates(db, wave_id, gate_type)`; if empty return `WaveBatchApproveResponse(approved=0, gate_ids=[])`.
2. For each `gate_id`:
   - `try _enforce_gate_reviewer`; on `OlympusHTTPException` with status 403 → `continue` (skip, don't abort); other statuses re-raise (`:688-695`).
   - `try record_gate_approval`; on `OlympusHTTPException` code `GATE_ALREADY_DECIDED` → `continue`; else re-raise (`:700-715`).
   - If `advanced`: `send_gate_temporal_signal(..., "approve", user.sub, body.comment)`; append gate_id (`:716-725`).
3. Return `WaveBatchApproveResponse(approved=len(approved_ids), gate_ids=approved_ids)`. `approved` counts only gates that actually advanced (quorum met).

### §7.4 `record_gate_approval` — quorum + oversight (`services/gate.py:622-728`)

1. `row = _get_gate_or_404(...)`; if `row["status"] != "pending"` → **409** `GATE_ALREADY_DECIDED` (`:653-658`).
2. INSERT into `gate_approval (gate_id, approved_by, approver_role, is_oversight, is_management_override, comment)` with `ON CONFLICT (gate_id, approved_by) DO NOTHING` — repeat approval by the same user doesn't double-count (`:660-676`).
3. `approvals = _load_gate_approvals(...)`; `received = len(approvals)`; `quorum_met = received >= minimum_approvals`; `oversight_met = oversight_role is None or any(a["is_oversight"] for a in approvals)`; `advanced = quorum_met and oversight_met` (`:678-684`).
4. If `advanced`: `UPDATE gate SET status='approved', decided_at=now, decided_by=:by, justification=:comment`; `_persist_card_review(...)` (`:687-703`).
5. `db.commit()`; log `gate_approval_recorded`. If advanced return `(GateDetail, True)`; else return `(GateDetail with pending_approvals, False)` (`:704-728`).

### §7.5 `send_gate_temporal_signal(db, gate_id, action, actor, message="", reason_category=None, card_decisions=None, reviewer_notes=None)` (`services/gate.py:808-921`)

Entire body wrapped in try/except → on any exception log `temporal_signal_failed` (warning) and return
(the DB state is already updated; the signal can be retried) (`:828, 915-921`).

1. `SELECT workflow_id, gate_type FROM gate WHERE id=:id`. If no row or no `workflow_id` → log `temporal_signal_skipped_no_workflow_id` and return (`:831-843`). `gate_type = row.get("gate_type")` (missing tolerated).
2. `client = await get_temporal_client()` (`:852-854`).
3. **action == "approve"** (`:856-889`): `client.get_workflow_handle(workflow_id).signal("gate_approved", GateApprovedSignal(gate_id, approved_by=actor, justification=message, card_decisions=card_decisions or [], reviewer_notes=reviewer_notes))`. **G-DA dual-signal** (`:867-889`): if `gate_type == "G-DA"`, ALSO signal `"stakeholder_approved"` with `StakeholderApprovedSignal(approval_id=f"gda-{gate_id}", stakeholder=actor, scope="g-da")` (the wave_rationalization workflow waits for a second `StakeholderApprovedSignal(scope="g-da")` — until a dedicated second-approver role ships, the single approver fires both); log `gda_stakeholder_signal_sent`.
4. **action == "reject"** (`:890-901`): signal `"gate_rejected"` with `GateRejectedSignal(gate_id, rejected_by=actor, reason=message, reason_category=, card_decisions=card_decisions or [], reviewer_notes=)`.
5. **action == "merge_retry"** (`:902-914`): signal `"merge_retry"` with `GateMergeRetrySignal(gate_id, retried_by=actor, note=message or None)`.

---

## §8. Workflow-signal inbox router (`routers/workflow_signals.py`)

`router = APIRouter(prefix="/api/v1/workflow-signals", tags=["Workflow Signals"])` (`:35`). There is
**no POST** — the only writer is the API layer itself (via `dispatch_architecture` etc. through
`signal_inbox.enqueue_signal`); this router is read-only operator triage (`:1-8`). `VIEWER_PLUS` =
all 8 human roles (`:23-32`).

| Method | Path | Auth | Request | Response | Codes | Line |
|---|---|---|---|---|---|---|
| GET | `/api/v1/workflow-signals/pending` | `require_role(*VIEWER_PLUS)` | query `workflow_id?`, `limit=Query(100, ge=1, le=500)` | `PendingSignalsResponse` | 200 | `:56` |

`list_pending_signals` (`:57-79`): `rows = signal_inbox.list_pending(db, workflow_id=, limit=)`; maps each to
`PendingSignalEntry(id=str, workflow_id, signal_name, payload=r["payload"] or {}, status, created_at?, consumed_at?)` (`:38-48`).

---

## §9. Router: `waves.py` (`/api/v1/waves`) — 32 endpoints

`router = APIRouter(prefix="/api/v1/waves", tags=["Waves"])` (`:107`). Role sets: `VIEWER_PLUS` (8
human roles, `:87-96`), `MANAGER_ROLES=[portfolio_manager, portfolio_admin]` (`:98-101`),
`ADMIN_ROLES=[portfolio_admin]` (`:103-105`).

### §9.1 Shared helpers

`_wave_detail_from_row(row, app_count=0, application_ids=None, discovery_ready_count=0) → WaveDetail` (`:110-134`).

`_count_discovery_ready(db, wave_id) → int` (`:137-176`): counts apps in the wave that cleared Discovery. SQL: `application a JOIN wave_application wa ON wa.application_id=a.id WHERE wa.wave_id=:wid AND a.current_line IS NOT NULL AND (a.current_line != 'Discovery' OR a.current_status IN ('completed','discovery_complete'))`. NULL `current_line` → not-ready. Steady state after per-app rationalization retired (PR #398/W19): apps sit at `Discovery/completed` until the wave owner runs `WaveRationalizationWorkflow`.

`_resolve_wave_context(db, wave_id) → (wave_row, apps)` (`:1309-1355`): `SELECT id, portfolio_id, name, status, workflow_id, architecture_workflow_id FROM wave WHERE id=:id` (404 `WAVE_NOT_FOUND` if absent); `apps = [{app_id:str, app_name}]` from `application JOIN wave_application`. `workflow_id` = rationalization coordinator; `architecture_workflow_id` = wave-architecture coordinator (migration 054) targeted by the architecture-dispatch path post-G-DA.

`_resolve_artifact_repo(db, portfolio_id) → str` (`:1358-1372`): `SELECT artifact_repo_url FROM portfolio WHERE id=:id`; `""` if absent/null.

`_reject_path_traversal(path)` (`:1006-1022`): empty → 400 `INVALID_PATH` "path query parameter is required"; leading `/` or `\` → 400 "path must be relative"; normalize separators, if any segment is `..` or empty → 400 "must not contain '..' or empty segments".

### §9.2 Endpoint table (MOUNT ORDER)

| # | Method | Path | Auth | Request | Response | Status | Line |
|---|---|---|---|---|---|---|---|
| 1 | POST | `""` | `require_role(*MANAGER_ROLES)` + `get_current_user` | `WaveCreate` | `WaveDetail` | 201 | `:179` |
| 2 | GET | `""` | `require_role(*VIEWER_PLUS)` + `get_current_user` | query `portfolio_id?`, pagination | paginated dict | 200 | `:269` |
| 3 | GET | `/{wave_id}` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` | — | `WaveDetail` | 200/404 | `:345` |
| 4 | PUT | `/{wave_id}` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` | `WaveUpdate` | `WaveDetail` | 200/404 | `:386` |
| 5 | DELETE | `/{wave_id}` | dep `require_wave_member` + `require_role(*ADMIN_ROLES)` | — | — | 204/404 | `:427` |
| 6 | POST | `/{wave_id}/start` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` + temporal | `WaveStartRequest?` | `WaveStartResponse` | 202 | `:452` |
| 7 | POST | `/assign` | `require_role(*MANAGER_ROLES)` + `get_current_user` | `WaveAssignmentRequest` | `WaveAssignmentResult` | 200 | `:475` |
| 8 | POST | `/bulk-onboard` | `require_role(*MANAGER_ROLES)` + `get_current_user` | `WaveBulkOnboardRequest` | `WaveDetail` | 201 | `:498` |
| 9 | POST | `/{wave_id}/ready` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` | `WaveReadyRequest?` | `WaveDetail` | 200 | `:521` |
| 10 | POST | `/{wave_id}/cancel` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` | — | `WaveDetail` | 200 | `:547` |
| 11 | POST | `/{wave_id}/revert` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` | — | `WaveDetail` | 200/400 | `:567` |
| 12 | POST | `/{wave_id}/assign-apps` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` | `WaveAssignAppsRequest` | `WaveDetail` | 200/400 | `:591` |
| 13 | POST | `/{wave_id}/remove-apps` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` | `WaveRemoveAppsRequest` | `WaveDetail` | 200/400 | `:621` |
| 14 | GET | `/{wave_id}/app-progress` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` | — | `WaveAppProgressResponse` | 200/400 | `:645` |
| 15 | GET | `/{wave_id}/app-activity` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` | — | `WaveAppActivityResponse` | 200/404 | `:666` |
| 16 | GET | `/{wave_id}/progress` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` + temporal | — | `WaveProgressResponse` | 200/404/409 | `:693` |
| 17 | GET | `/{wave_id}/performance-report` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` | — | `WavePerformanceReport` | 200/404 | `:722` |
| 18 | POST | `/{wave_id}/rationalize` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` + temporal | — | `WaveStartResponse` | 202 | `:750` |
| 19 | POST | `/{wave_id}/cancel-rationalization` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` + temporal | — | `WaveCancelRationalizationResponse` | 200/409 | `:779` |
| 20 | POST | `/{wave_id}/reset` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` | — | `WaveResetResponse` | 200/409 | `:809` |
| 21 | POST | `/{wave_id}/resume` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` + temporal | `WaveResumeRequest?` | `WaveResumeResponse` | 202 | `:839` |
| 22 | POST | `/{wave_id}/retry-rationalization` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` + temporal | — | `WaveStartResponse` | 202 | `:880` |
| 23 | GET | `/{wave_id}/pending-gates` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` | — | `WavePendingGatesResponse` | 200 | `:924` |
| 24 | POST | `/{wave_id}/cancel-all-children` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` + temporal | — | `WaveCancelAllChildrenResponse` | 202/404/409 | `:952` |
| 25 | GET | `/{wave_id}/artifacts` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` | query `path` (required) | `WaveArtifactResponse` | 200/400/404/502/503 | `:1025` |
| 26 | GET | `/{wave_id}/dispatch-preview` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` | — | `DispatchPreviewResponse` | 200/404 | `:1947` |
| 27 | GET | `/{wave_id}/dispatch-target-preview` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` | — | `DispatchPreviewTargetResponse` | 200/404/502/503 | `:1970` |
| 28 | POST | `/{wave_id}/dispatch-architecture` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` + temporal | `dict[str,Any]` (v1/v2 shape-sniffed) | `DispatchArchitectureResponse` | 202/400/409/502/503 | `:2326` |
| 29 | GET | `/{wave_id}/dispatch-status` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` + temporal + config | — | `DispatchStatusResponse` | 200/404 | `:2809` |
| 30 | POST | `/{wave_id}/dispatch-retry` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` + temporal | `DispatchRetryRequest` | `DispatchRetryResponse` | 202/409 | `:2921` |
| 31 | GET | `/{wave_id}/tier1-pending` | dep `require_wave_member` + `require_role(*VIEWER_PLUS)` + temporal | — | `Tier1PendingResponse` | 200 | `:3087` |
| 32 | POST | `/{wave_id}/tier1-approval` | dep `require_wave_member` + `require_role(*MANAGER_ROLES)` + temporal | `Tier1ApprovalRequest` | `Tier1ApprovalResponse` | 202/404/409 | `:3245` |

### §9.3 Per-endpoint logic (non-trivial ones as pseudocode)

**#1 `create_wave` (`:180-266`)**:
```
verify_portfolio_access(db, user, body.portfolio_id)
dupe = SELECT 1 FROM wave WHERE portfolio_id=:pid AND lower(name)=lower(:name) LIMIT 1
if dupe: raise 409 WAVE_NAME_EXISTS "A wave named '{name}' already exists in this portfolio."
max_num = SELECT COALESCE(MAX(wave_number),0) FROM wave WHERE portfolio_id=:pid
wave_number = max_num + 1
wave_id = uuid4()
INSERT INTO wave (id, portfolio_id, wave_number, name, description, status) VALUES (..., 'draft')
for app_id in body.application_ids: INSERT INTO wave_application (wave_id, application_id)
commit
return WaveDetail(status="draft", app_count=len(app_ids), application_ids=app_ids, ...)
```

**#2 `list_waves` (`:270-342`)**: if `portfolio_id` given `verify_portfolio_access`. `member_ids = filter_portfolio_ids_by_membership`. Build WHERE: if `member_ids is not None` and empty → clause `"FALSE"`; else `w.portfolio_id = ANY(:pf_ids)`. If `portfolio_id` → add `w.portfolio_id = :pid`. `total = SELECT count(*)`; rows `SELECT w.* ... ORDER BY w.wave_number ASC LIMIT :limit OFFSET :offset`. For each row: `app_count = SELECT count(*) FROM wave_application`; `discovery_ready_count = _count_discovery_ready(...)`; append `_wave_detail_from_row(...).model_dump(mode="json")`. Return `paginated_response`.

**#3 `get_wave` (`:346-383`)**: `SELECT * FROM wave WHERE id=:id` (404 `WAVE_NOT_FOUND`); fetch `application_id`s; `discovery_ready_count`; return `_wave_detail_from_row`.

**#4 `update_wave` (`:387-424`)**: SELECT row (404). Build SET clauses from non-None `body.name`/`body.status`; if any, append `updated_at = now()`, `UPDATE wave SET ... WHERE id=:id`, commit. Return `_wave_detail_from_row(updates)`.

**#5 `delete_wave` (`:428-449`)**: SELECT id (404); `DELETE FROM wave WHERE id=:id` (wave_application cascades); commit; 204.

**#6 `start_wave` (`:458-472`)**: `max_apps = body.max_apps_per_wave if body else 10`; `delegation = body.delegation if body`; `wave_svc.start_wave(db, str(wave_id), temporal, config.temporal_task_queue, max_apps, delegation=)`.

**#7 `assign_waves_endpoint` (`:476-495`)**: `verify_portfolio_access`; `result = assign_waves(db, str(body.portfolio_id), body.max_apps_per_wave)`; `WaveAssignmentResult(**result)`. (F22: now persists — see §10.)

**#8 `bulk_onboard` (`:499-518`)**: `verify_portfolio_access`; `wave_svc.bulk_onboard_apps(db, str(portfolio_id), [str(a) for a in application_ids], target_wave_id=str(wave_id) if wave_id else None)`. Creates a draft wave if none exists; idempotent attach.

**#9 `mark_ready` (`:526-544`)**: `stakeholder = body.stakeholder if body and body.stakeholder else user.sub`; `wave_svc.mark_wave_ready(db, str(wave_id), stakeholder)`.

**#10 `cancel_wave` (`:552-564`)**: `wave_svc.cancel_wave(db, str(wave_id), stakeholder=user.sub)` — draft waves only.

**#11 `revert_wave_to_draft` (`:572-588`)**: `wave_svc.revert_wave_to_draft(...)` — only `ready` and pre-rationalization; 400 `WAVE_NOT_REVERTIBLE` once `workflow_id` set.

**#12 `assign_apps` (`:596-618`)**: `wave_svc.assign_apps_to_wave(db, str(wave_id), [str(a)...], stakeholder=user.sub)`. Target must be `draft` (400 `WAVE_NOT_DRAFT`); any source wave must also be draft (400 `SOURCE_WAVE_LOCKED`).

**#13 `remove_apps` (`:626-642`)**: `wave_svc.remove_apps_from_wave(...)`. Draft only (400 `WAVE_NOT_DRAFT`); idempotent.

**#14–#17**: thin delegates — `wave_svc.get_wave_app_progress` (400 `WAVE_NOT_IN_PROGRESS` if not in_progress), `wave_svc.get_wave_app_activity` (404), `wave_svc.get_wave_progress(db, str(wave_id), temporal, config)` (404/409/200-with-`temporal_unreachable`), `perf_svc.get_wave_performance_report`.

**#18 `start_rationalization` (`:756-776`)**: `wave_svc.start_wave_rationalization(db, str(wave_id), temporal, config.temporal_task_queue, stakeholder=user.sub)` — `draft`/`ready` only; produces one cross-portfolio redundancy matrix; fires G-RR/G-DA at wave scope.

**#19–#22**: cancel/reset/resume/retry rationalization — thin delegates to `wave_svc.cancel_wave_rationalization` (409 `WAVE_NOT_RUNNING`), `reset_wave_to_ready` (409 `WAVE_NOT_FAILED`), `resume_wave_fanout(..., request=body, config=)`, `retry_wave_rationalization`.

**#23 `list_wave_pending_gates` (`:929-949`)**: `wave_svc.list_pending_fanout_gates(db, str(wave_id))` — aggregated G-02/G-DT queue across the wave's apps, ordered by `opened_at ASC`.

**#24 `cancel_all_children` (`:958-982`)**: `wave_svc.cancel_all_wave_children(db, str(wave_id), temporal, config, stakeholder=user.sub)` — 404 `WAVE_NOT_FOUND`, 409 `WAVE_HAS_NO_WORKFLOW`, 202 otherwise. Signals `cancel_all_children`.

**#25 `get_wave_artifact` (`:1030-1131`)**:
```
_reject_path_traversal(path)
wave_row = SELECT id, portfolio_id FROM wave WHERE id=:id   → 404 WAVE_NOT_FOUND if none
artifact_repo = SELECT artifact_repo_url FROM portfolio WHERE id=:portfolio_id  (or "")
if not artifact_repo: raise 404 ARTIFACT_REPO_NOT_CONFIGURED
if not config.github_token: raise 503 GIT_TOKEN_MISSING
full_path = f"rationalization/wave-{wave_id}/{path}"
try: result = GitService(...).read_file(path=full_path)
except GitServiceError as e:
    if "not found" in str(e).lower(): raise 404 ARTIFACT_NOT_FOUND
    else: log wave_artifact_read_failed; raise 502 GIT_READ_FAILED
data = None
if path.endswith(".json"):
    try: parsed = json.loads(result.content); if isinstance(parsed,(dict,list)): data = parsed
    except JSONDecodeError: log wave_artifact_malformed_json (data stays None)
return WaveArtifactResponse(wave_id, path, commit_sha=result.commit_sha, content=result.content, data)
```

**#26 `dispatch_preview` (`:1952-1967`)**: `config = get_config()`; `wave_row, apps = _resolve_wave_context(...)`; `entries = await _load_preview_entries(db, wave_row, apps, config)`; `DispatchPreviewResponse(wave_id, entries)`. See §9.4 for the artifact-loading pipeline.

**#27 `dispatch_target_preview` (`:1975-2105`)** — target-keyed preview from `architecture/wave-{wave_id}/architecture-target-plan.json`:
```
wave_row, _ = _resolve_wave_context(...)
artifact_repo = _resolve_artifact_repo(...); if empty: return empty response
if not config.github_token: raise 503 GIT_TOKEN_MISSING
try: result = GitService(...).read_file(plan_path)
except GitServiceError:
    if "not found": return empty (coordinator hasn't committed yet)
    else: log + raise 502 GIT_READ_FAILED
try: plan = json.loads(result.content)
except JSONDecodeError: log + raise 502 GIT_READ_FAILED
plan_targets = plan.get("targets"); if not list: return empty
collect all source_app_ids across targets → SELECT id,name FROM application WHERE id=ANY(:ids) → name_by_id
for item in plan_targets:
    entries.append(DispatchPreviewTargetEntry(target_app_id, target_service_id,
        target_name_seed=item.target_name, target_repo_slug, relationship,
        source_app_ids, source_app_names=[name_by_id.get(sid,"")], rationale))
return DispatchPreviewTargetResponse(wave_id, entries)
```

**#28 `dispatch_architecture` (`:2332-2526`)** — shape-sniffed v1/v2. `_is_v2_dispatch_body(raw)` (`:2311-2323`): true when `raw["targets"][0]` has `"target_app_id"`.

v2 → `_dispatch_architecture_v2(...)` (`:2109-2308`):
```
wave_row,_ = _resolve_wave_context(...)
if status != "awaiting-architecture-dispatch": raise 409 WAVE_NOT_AWAITING_DISPATCH
arch_wf_id = wave_row["architecture_workflow_id"] or ""; if empty: raise 409 ARCHITECTURE_COORDINATOR_NOT_STARTED
skipped_retire=0; plan_targets=[]
for t in body.targets:
    rel = t.relationship.lower()
    if rel=="retire": skipped_retire+=1; continue
    if not t.target_repo: raise 400 TARGET_REPO_REQUIRED
    if rel!="build" and not t.source_app_ids: raise 400 TARGET_SOURCE_APPS_REQUIRED  # build is greenfield, empty by design
    plan_targets.append({target_app_id, target_service_id, target_name=t.target_app_name,
        target_repo_slug=t.target_repo, relationship=rel, source_app_ids=list(...), rationale:""})
plan = {$schema, wave_id, generated_at:ISO-Z, targets:plan_targets, target_app_count:len, summary:"Operator-confirmed plan from pre-dispatch UI"}
artifact_repo = _resolve_artifact_repo(...); if empty: raise 409 ARTIFACT_REPO_NOT_CONFIGURED
if not github_token: raise 503 GIT_TOKEN_MISSING
try: GitService(...).commit_file(branch="main", path=plan_path, content=json.dumps(plan,indent=2), commit_message=...)  # BEFORE signalling — coordinator re-reads from git
except GitServiceError: log + raise 502 GIT_WRITE_FAILED
signal_payload = {"confirmed_by": user.sub or ""}
inbox_id = signal_inbox.enqueue_signal(db, workflow_id=arch_wf_id, signal_name="pre_dispatch_confirmed", payload, status="sent")
status="dispatched"; detail=""
try: temporal.get_workflow_handle(arch_wf_id).signal("pre_dispatch_confirmed", signal_payload)
except Exception as e: signal_inbox.mark_queued(db, inbox_id); status="queued"; detail=f"Temporal signal failed ({e!r}); queued..."; log signal_queued
commit; log wave.dispatch_architecture (shape="v2")
return DispatchArchitectureResponse(wave_id, workflow_id=arch_wf_id, dispatched=len(plan_targets), skipped_retire, status, detail)
```

v1 (`:2368-2526`):
```
parsed_body = DispatchArchitectureRequest.model_validate(body)
wave_row, apps = _resolve_wave_context(...)
if status != "awaiting-architecture-dispatch": raise 409 WAVE_NOT_AWAITING_DISPATCH
if not workflow_id: raise 409 WAVE_WORKFLOW_NOT_STARTED
preview_entries = _load_preview_entries(db, wave_row, apps, config); preview_by_app = {e.source_app_id: e}
requested_ids = {t.source_app_id for t in parsed_body.targets}
missing_disposition = [e.source_app_id for e in preview_entries if in requested_ids and not e.disposition]
if missing_disposition: raise 409 DISPATCH_MISSING_DISPOSITION (lists affected app_ids + artifact repo path)  # blast-radius guard
skipped_retire=0; augmented_targets=[]
for target in parsed_body.targets:
    preview = preview_by_app.get(target.source_app_id); if None: raise 400 UNKNOWN_SOURCE_APP
    disposition = preview.disposition
    if disposition=="Retire": skipped_retire+=1; continue
    if not target.target_repo: raise 400 TARGET_REPO_REQUIRED  # every non-Retire target gets its own repo
    peer_source_app_ids = list(preview.peer_source_app_ids) if disposition=="Consolidate" else []
    augmented_targets.append({source_app_id, target_app_name, target_repo, default_branch, disposition, peer_source_app_ids})
signal_payload = {"targets": augmented_targets}
inbox_id = signal_inbox.enqueue_signal(db, workflow_id, signal_name="dispatch_architecture", payload, status="sent")  # write BEFORE wire-send
try: temporal.get_workflow_handle(workflow_id).signal("dispatch_architecture", signal_payload); status="dispatched"
except Exception as e: signal_inbox.mark_queued; status="queued"; detail=...  # 202 still returned
commit; log
return DispatchArchitectureResponse(...)
```

**#29 `dispatch_status` (`:2814-2918`)** — authoritative-vs-fallback:
```
wave_row,_ = _resolve_wave_context(...)
lineage_targets = _lineage_targets_for_wave(db, wave_id)
if lineage_targets:  # PRIMARY authoritative path — survives Run-2 recovery
    targets = _build_authoritative_targets(temporal, config, lineage_targets)
    return DispatchStatusResponse(wave_id, status=wave_row["status"], targets)
# SECONDARY fallback: workflow-query path, only when no lineage rows yet
targets=[]
if wave_row["workflow_id"]:
    try: wave_wf_status = temporal.get_workflow_handle(wf_id).describe().status.name
    except: log describe_failed
    if _wave_workflow_status_is_stale(wave_wf_status): log suppressing_stale_query  # TERMINATED/FAILED/COMPLETED/CANCELED/TIMED_OUT
    else:
        try: raw = handle.query("dispatch_results")
        except: log; raw=[]
        for entry in raw: targets.append(DispatchTargetStatusItem(**entry) if dict else <attr-access build>)
return DispatchStatusResponse(wave_id, status=wave_row["status"], targets)
```
`_lineage_targets_for_wave` (`:2574-2641`): `DISTINCT` over `application_lineage al JOIN wave_application JOIN application t (target) JOIN application s (source) WHERE wa.wave_id=:wid AND (t.current_status IS NULL OR t.current_status <> 'consolidated_into_target')`. Collapses on `target_app_id`, accumulating `source_app_ids`/`source_app_names`; `target_repo` prefers `t.target_repo_url` then `t.repo_url`.
`_latest_workflow_for_prefix(temporal, prefix)` (`:2644-2703`): pick workflow type (`ArchitectureWorkflow`/`DataWorkflow`) by prefix; `list_workflows("WorkflowType = '...'", page_size=100)`; filter `wf.id.startswith(prefix)`; keep the one with the latest `start_time` (Python-side — **GOTCHA** `:2656-2665`: the standard PostgreSQL visibility store rejects `ORDER BY`, so no ORDER BY in the query). On any exception log `list_workflows_failed` and return None.
`_build_authoritative_targets` (`:2715-2791`): for each target, probe `architecture-{tid}-` + `data-{tid}-`; map WF status via `_WF_STATUS_TO_LINE_STATUS` (`:2538-2546`: RUNNING/CONTINUED_AS_NEW→in-progress, COMPLETED→complete, FAILED/CANCELED/TERMINATED/TIMED_OUT→failed); line label Architecture→Data→Done; `_coalesce_target_status` (`:2549-2571`: failed if either failed; completed if both complete; in-progress if either in-progress or one complete; else pending); `ui_wf_id = arch_wf_id or data_wf_id`; build `DispatchTargetStatusItem`.

**#30 `dispatch_retry` (`:2927-2980`)**: `_resolve_wave_context`; 409 `WAVE_WORKFLOW_NOT_STARTED` if no workflow_id; 409 `WAVE_NOT_IN_DISPATCH_PHASE` if status not in `{architecture-in-flight, data-in-flight, awaiting-architecture-dispatch}`; signal `retry_target_dispatch` with `{source_app_id, target_app_name, target_repo, default_branch}`; return `DispatchRetryResponse(status="retry-queued")`.

**#31 `tier1_pending` (`:3092-3226`)**:
```
wave_row, apps = _resolve_wave_context(...)
if not workflow_id: return Tier1PendingResponse(items=[])
try: status = asyncio.wait_for(handle.query("get_status"), timeout=8.0)  # _TIER1_QUERY_TIMEOUT_SECONDS
except (Exception, TimeoutError): log query_failed; return empty  # dead worker degrades panel, not the request
current_step, updated_at = parse from status (dict or attr)
pending_app_id = _extract_tier1_pending_app_id(current_step)  # strips "awaiting-tier1-approval-" prefix
if not pending_app_id: return empty
name_by_id = {app_id: app_name}
try: summary = asyncio.wait_for(handle.query("pending_tier1_classification"), timeout=8.0)
except: summary=None
if summary and summary.app_id == pending_app_id:  # guard against stale/racing read
    risk_rationale, risk_confidence(float only, not bool), archetype, complexity_tier, narrative = from summary
item = Tier1PendingItem(app_id, app_name, risk_tier="1", classification_path=f"rationalization/wave-{id}/{app_id}/classification.json", awaiting_since=updated_at, <risk fields>)
return Tier1PendingResponse(wave_id, workflow_id, items=[item])
```

**#32 `tier1_approval` (`:3251-3373`)**:
```
wave_row, apps = _resolve_wave_context(...)
if body.app_id not in apps: raise 404 APP_NOT_IN_WAVE
if not workflow_id: raise 409 WAVE_WORKFLOW_NOT_STARTED
if status not in _TIER1_APPROVAL_OK_STATUSES {in_progress, awaiting-architecture-dispatch, architecture-in-flight, data-in-flight, stuck-awaiting-recovery}: raise 409 WAVE_NOT_AWAITING_TIER1
approval_id = body.approval_id or f"tier1-{app_id}-{int(_now_epoch_ms())}"
stakeholder = body.stakeholder.strip() or _user_sub(user)
signal_payload = {"scope":"tier-1-classification", "approval_id", "stakeholder"}  # EXACT StakeholderApprovedSignal shape
inbox_payload = signal_payload + optional rationale + app_id  # rationale rides inbox only (dataclass has no field)
inbox_id = signal_inbox.enqueue_signal(db, workflow_id, "stakeholder_approved", inbox_payload, status="sent")
status="sent"; detail=""
try: temporal.get_workflow_handle(workflow_id).signal("stakeholder_approved", signal_payload)
except Exception as e: signal_inbox.mark_queued; status="queued"; detail=...
commit; log
return Tier1ApprovalResponse(wave_id, workflow_id, app_id, approval_id, status, detail)
```
`_now_epoch_ms()` (`:3376-3380`): `int(datetime.now(timezone.utc).timestamp()*1000)`. `_user_sub(user)` (`:3383-3391`): `user.sub` if str else `"unknown"`.

### §9.4 Disposition-artifact preview pipeline (helpers `:1375-1944`)

**`_load_preview_entries(db, wave_row, apps, config)` (`:1853-1909`)** — resolution precedence:
1. Per-app `disposition-recommendation.json` `target_hint.peer_app_ids` (authoritative).
2. Markdown fallback (`.md` sidecar) when JSON unparseable (Part B).
3. Portfolio-level `portfolio-redundancy-matrix.json` `consolidation_candidates[]` (Part C).

If no artifact_repo or no github_token: stub every app with `None` → `_build_preview_from_artifacts(apps, per_app)`. Else build a `GitService` and for each app read `rationalization/wave-{id}/{app_id}/disposition-recommendation.json` via `_load_single_preview_artifact`; then read `portfolio_clusters = _load_portfolio_consolidation_clusters(...)`; return `_build_preview_from_artifacts(apps, per_app, portfolio_clusters=)`.

**`_load_single_preview_artifact(git_svc, json_path, app_id, apps=None)` (`:1750-1850`)**:
```
try: result = git_svc.read_file(json_path)
except: return None
parsed_any = parse_agent_json(result.content)  # markdown-fence-tolerant
if dict: parsed=parsed_any; if it has recommended_disposition|disposition: return parsed; else reason="json-missing-disposition-key"
elif None: reason="json-unparseable"; else reason="json-not-object"
# fall back to .md sibling (json_path[:-5]+".md")
try: md_result = git_svc.read_file(md_path)
except: log fallback_failed; return parsed
disposition = _extract_disposition_from_markdown(md_result.content)
if not disposition: log fallback_failed; return parsed
peer_app_ids = []
if apps and disposition=="Consolidate":
    raw = _extract_peers_from_markdown(md_result.content); peer_app_ids = _resolve_peer_entries_to_app_ids(raw, apps, app_id)
log md_fallback
return _md_fallback_artifact(disposition, peer_app_ids)  # {recommended_disposition, target_hint?, _recovered_from_markdown:True}
```

`_extract_disposition_from_markdown` (`:1593-1606`) uses `_MD_DISPOSITION_PATTERN` (`:1581-1590`) — matches label `Recommended Disposition|Recommendation` (optional `#` heading, optional bold), separator `:` OR `|` (table cell), then one of the 7 verbs (optionally bold/backtick). Returns canonical TitleCase or `""`. `_VALID_DISPOSITIONS = (Retire, Retain, Refactor, Rearchitect, Replatform, Replace, Consolidate)` (`:1547-1555`).

`_extract_peers_from_markdown` (`:1641-1665`) uses `_MD_PEERS_PATTERN` (`:1622-1631`) — label `Peers absorbed|Peer app_ids|peer_app_ids|Consolidating`, separator `:`/`|`, capture rest of line; split on `,` or `+` via `_PEERS_SPLIT_PATTERN` (`:1638`); strip decoration.

`_resolve_peer_entries_to_app_ids(raw, apps, self_app_id)` (`:1679-1721`): UUID-shaped (`_UUID_HINT_PATTERN` `:1673-1676`) match `app_id` case-insensitive; else match `app_name` case-insensitive (first declared wins); never returns `self_app_id`; dedup.

`_build_preview_from_artifacts(apps, per_app_artifacts, portfolio_clusters=None)` (`:1466-1540`): if `portfolio_clusters`, apply Part-C fallback first. Identify Consolidate anchors' peers → `consumed_as_peer`. For each app not consumed: `disposition = art.recommended_disposition|disposition|""`; peers from `target_hint.peer_app_ids`; `needs_input = bool(disposition) and disposition != "Retire"`; append `DispatchPreviewEntry`.

`_apply_portfolio_consolidation_fallback(per_app_artifacts, apps, portfolio_clusters)` (`:1375-1463`) — Part C, conservative: for each cluster whose members are ALL in the wave AND ALL say `Consolidate` AND NONE carry a `target_hint`, inject a synthetic `consolidate-target` hint on the anchor (precedence `anchor_app_id` → `canonical_target_candidate` → first member); mark `_recovered_from_portfolio_matrix=True`; log `dispatch_preview_portfolio_cluster_fallback`. Returns a NEW dict (does not mutate).

`_load_portfolio_consolidation_clusters(git_svc, wave_id)` (`:1912-1944`): read `rationalization/wave-{id}/portfolio-redundancy-matrix.json`; `parse_agent_json`; return `consolidation_candidates` list (dict entries only), or `[]` on any failure.

---

## §10. Wave assignment algorithm (`services/wave_assignment.py`)

`assign_waves(db, portfolio_id, max_apps_per_wave=10) → dict` (`:35-161`):
```
rows = SELECT a.id,a.name,a.risk_tier,a.complexity_tier FROM application a
       WHERE a.portfolio_id=:pid AND a.id NOT IN (SELECT wa.application_id FROM wave_application wa)
       ORDER BY a.name
apps = [dict(r)]; apps.sort(key=_sort_key)
if not apps: return {waves:[], waves_created:0, waves_unchanged:0, apps_assigned:0}
next_number = COALESCE(MAX(wave_number),0) FROM wave WHERE portfolio_id=:pid + 1
waves=[]; waves_created=0; apps_assigned=0
for i in range(0, len(apps), max_apps_per_wave):
    chunk = apps[i:i+max_apps_per_wave]
    wave_number = next_number + waves_created; wave_id = uuid4(); wave_name = f"Wave {wave_number}"
    INSERT INTO wave (id,portfolio_id,wave_number,name,status) VALUES (...,'draft'); waves_created+=1
    for app in chunk:
        INSERT INTO wave_application (wave_id,application_id) VALUES (...) ON CONFLICT DO NOTHING
        chunk_ids.append(str(app.id)); apps_assigned+=1
    risk_counts = tally chunk risk_tier (or "unclassified")
    waves.append({id, wave_number, name, application_ids:chunk_ids, risk_summary:risk_counts})
commit
return {waves, waves_created, waves_unchanged:0, apps_assigned}
```
`_sort_key(app)` (`:27-32`): `(risk_tier_order, complexity_tier_order, name)` where
`_RISK_TIER_ORDER={"1":0,"2":1,"3":2}` (default 2), `_COMPLEXITY_TIER_ORDER={"complex":0,"moderate":1,"simple":2}` (default 2). Tier-1/complex first. **F22 note** (`:1-11`): this now PERSISTS (previously a pure proposer that returned nothing saved — the UI toast lied).

---

## §11. Router: `applications.py` (`/api/v1/applications`) — 31 endpoints

`router = APIRouter(prefix="/api/v1/applications", tags=["Applications"])` (`:79`).

### §11.1 Endpoint table (MOUNT ORDER)

| # | Method | Path | Auth | Request | Response | Status | Line |
|---|---|---|---|---|---|---|---|
| 1 | GET | `""` | `get_current_user` | query `portfolio_id?`, pagination | paginated dict | 200 | `:82` |
| 2 | POST | `""` | `get_current_user` | `ApplicationCreate` | `ApplicationDetail` | 201/404/415/422/501 | `:145` |
| 3 | POST | `/upload` | `get_current_user` | multipart (`file`, `name`, `description?`, `portfolio_id?`, `risk_tier?`, `complexity_tier?`, `tags?`) | `ApplicationDetail` | 201/413/422 | `:233` |
| 4 | GET | `/{app_id}` | dep `require_application_member` | — | `ApplicationDetail` | 200 | `:323` |
| 5 | PATCH | `/{app_id}` | dep `require_application_member` | `ApplicationUpdate` | `ApplicationDetail` | 200 | `:336` |
| 6 | GET | `/{app_id}/status` | dep `require_application_member` | — | `ApplicationStatus` | 200 | `:350` |
| 7 | GET | `/{app_id}/lineage` | dep `require_application_member` | — | `ApplicationLineageResponse` | 200 | `:363` |
| 8 | GET | `/{app_id}/design-artifacts` | dep `require_application_member` | query `line?`, `artifact_type?`, pagination | `DesignArtifactsResponse` | 200 | `:383` |
| 9 | POST | `/{app_id}/design-feedback` | dep `require_application_member` + `get_current_user` | `DesignFeedbackRequest` | `DesignFeedbackResponse` | 200 | `:408` |
| 10 | POST | `/{app_id}/interview` | dep `require_application_member` + `get_current_user` | `StartInterviewRequest` | `InterviewSessionState` | 200 | `:443` |
| 11 | GET | `/{app_id}/interview` | dep `require_application_member` | — | `InterviewSessionState` | 200 | `:464` |
| 12 | POST | `/{app_id}/interview/turns` | dep `require_application_member` | `SubmitTurnRequest` | `InterviewSessionState` | 200 | `:477` |
| 13 | POST | `/{app_id}/interview/complete` | dep `require_application_member` + `get_current_user` | — | `CompleteInterviewResponse` | 200 | `:496` |
| 14 | GET | `/{app_id}/source-artifacts-index` | dep `require_application_member` + config | — | `JSONResponse` | 200/404/500 | `:548` |
| 15 | GET | `/{app_id}/rationale` | dep `require_application_member` | — | `ApplicationRationaleResponse` | 200 | `:638` |
| 16 | GET | `/{app_id}/steps/{line}/{step}` | dep `require_application_member` | path `line:AssemblyLineName`, `step` | `StepExecutionRecord` | 200 | `:658` |
| 17 | POST | `/{app_id}/discover` | dep `require_application_member` + temporal | — | `DiscoverResponse` | 202 | `:672` |
| 18 | POST | `/{app_id}/discovery/start` | dep `require_application_member` + temporal | — | `DiscoverResponse` | 202/409 | `:715` |
| 19 | POST | `/{app_id}/discovery/retry` | dep `require_application_member` + temporal | — | `DiscoverResponse` | 202 | `:732` |
| 20 | POST | `/{app_id}/discovery/rerun` | dep `require_application_member` + temporal | — | `DiscoverResponse` | 202/409 | `:755` |
| 21 | GET | `/{app_id}/workflow` | dep `require_application_member` + temporal | — | `WorkflowDetailsResponse` | 200 | `:788` |
| 22 | POST | `/{app_id}/workflow/start` | dep `require_application_member` + temporal | `WorkflowStartRequest` | `WorkflowStartResponse` | 202 | `:803` |
| 23 | POST | `/{app_id}/workflow/cancel` | dep `require_application_member` + temporal | — | `WorkflowActionResponse` | 200 | `:822` |
| 24 | POST | `/{app_id}/workflow/retry` | dep `require_application_member` + temporal | `WorkflowRetryRequest?` | `WorkflowStartResponse` | 202 | `:837` |
| 25 | POST | `/{app_id}/workflow/reset` | dep `require_application_member` + temporal | `WorkflowResetRequest?` | `WorkflowResetResponse` | 200 | `:860` |
| 26 | GET | `/{app_id}/workflow/reset-points` | dep `require_application_member` + temporal | — | `WorkflowResetPointsResponse` | 200 | `:895` |
| 27 | GET | `/{app_id}/insights` | dep `require_application_member` + config | — | `InsightsResponse` | 200 | `:921` |
| 28 | GET | `/{app_id}/gate-evidence` | dep `require_application_member` + config | — | `list[GateEvidencePackage]` | 200 | `:941` |
| 29 | GET | `/{app_id}/decisions` | dep `require_application_member` | — | `DecisionsTimelineResponse` | 200 | `:962` |
| 30 | GET | `/{app_id}/disposition-output` | dep `require_application_member` | — | dict (`DispositionOutputBundle`) | 200/404 | `:975` |
| 31 | GET | `/{app_id}/dispositions` | dep `require_application_member` | — | `AppDispositionResponse` | 200 | `:1000` |

### §11.2 Non-trivial logic

**#1 `list_applications` (`:82-108`)**: if `portfolio_id` → `verify_portfolio_access`; `member_ids = filter_portfolio_ids_by_membership`; `app_svc.list_applications(db, pagination, portfolio_id=, portfolio_ids=member_ids)` → `paginated_response`.

`_resolve_portfolio_id(db, body_portfolio_id)` (`:111-142`): if given, `SELECT id FROM portfolio WHERE id=:id` (404 `PORTFOLIO_NOT_FOUND`); else `SELECT id FROM portfolio LIMIT 1` (400 `NO_PORTFOLIO` if none).

**#2 `create_application` (`:146-230`)** — dispatch on `body.source_type`:
```
portfolio_id = _resolve_portfolio_id(db, body.portfolio_id); verify_portfolio_access(...)
if GIT: return app_svc.create_application(db, body, portfolio_id)
if ZIP: raise 415 ZIP_REQUIRES_MULTIPART "...use POST /applications/upload"
if REQUIREMENTS_DOC or INTERVIEW: return app_svc.create_application(...)  # greenfield Build: no source tree
# remote (s3/confluence/sharepoint/gdrive/gcs):
app_id = uuid4(); destination = source_intake.destination_for(config.source_intake_root, app_id)
try: provider = build_provider(source_type, max_upload_bytes, s3_region); intake_result = provider.unpack(destination, source_uri)
except SourceIntakeNotImplemented as e: return JSONResponse(501, {error:{code:e.code,...,"source_type":...}}, headers={"X-Implementation-Status":"scaffold"})
except SourceIntakeError as e: raise 422 (e.code, e.message)
return app_svc.create_application(db, body, portfolio_id, app_id=, intake_result=)
```

**#3 `upload_application_zip` (`:234-320`)**: `_resolve_portfolio_id`+`verify_portfolio_access`. Parse `tags` JSON up front (422 `BAD_TAGS` if not a dict). `app_id=uuid4()`; read `Content-Length` → `declared_size`. `provider.unpack(destination, upload_stream=file.file, declared_size=)`; on `SourceIntakeError`: status 413 if code `UPLOAD_TOO_LARGE` else 422. Build `ApplicationCreate(source_type=ZIP, ...)`; `app_svc.create_application(..., app_id=, intake_result=)`.

**#14 `get_source_artifacts_index` (`:549-635`)**:
```
row = SELECT a.id,a.name,a.source_app_ids,p.artifact_repo_url,
      (SELECT wave_id FROM wave_application WHERE application_id=a.id LIMIT 1) AS wave_id
      FROM application a JOIN portfolio p ON p.id=a.portfolio_id WHERE a.id=:app_id
if none: raise 404 APP_NOT_FOUND
if not source_app_ids: raise 404 NOT_A_TARGET
if not wave_id or not artifact_repo: raise 404 INDEX_UNAVAILABLE
svc = _build_git_service_for_artifact_repo(config, artifact_repo); if None: raise 404 INDEX_UNAVAILABLE
index_path = f"rationalization/wave-{wave_id}/targets/{app_id}/source-artifacts-index.json"
try: result = svc.read_file(index_path, branch="main")
except GitServiceError: raise 404 INDEX_NOT_FOUND
try: payload = json.loads(result.content)
except: raise 500 INDEX_MALFORMED
payload["_meta"] = {path, commit_sha}; return JSONResponse(payload)
```
`_build_git_service_for_artifact_repo(config, repo)` (`:518-545`): None if repo/token missing or GitService init fails (logged).

**#16 `get_step_execution`**: `line` is a path param typed `AssemblyLineName` (enum-validated) → `app_svc.get_step_execution(db, app_id, line, step)`.

**#17/#18 discovery start**: both call `app_svc.start_discovery(db, app_id, temporal, config.temporal_task_queue)` — the alias 409s if a workflow is already running.
**#19 retry_discovery**: `workflow_control.retry_workflow(..., from_line=AssemblyLineName.DISCOVERY)` → `_to_discover_response`.
**#20 rerun_discovery**: `workflow_control.start_line_workflow(..., DISCOVERY, ...)` (409 if in-flight — use retry to kill-and-respawn). `_to_discover_response(start)` (`:706-712`) narrows `WorkflowStartResponse` → `DiscoverResponse(status="started")`.

**#22–#26 workflow control**: thin delegates — `start_line_workflow(..., body.line, ..., delegation=body.delegation)`, `cancel_workflow`, `retry_workflow(..., from_line=body.from_line if body else None)`, `reset_workflow(..., mode=, step_id=, event_id=, reapply_signals=, reason=)` (defaults `WorkflowResetRequest()`; `before_failure` default), `list_reset_points`.

**#30 `get_application_disposition_output`**: `disposition_output_svc.get_disposition_output(db, app_id, get_config())` — 404 `DISPOSITION_OUTPUT_NOT_EMITTED` if terminal step not reached.

**#31 `get_application_dispositions` (`:1004-1044`)**: `SELECT application_id, dispositions, target_services, rationalization_capability_ids FROM application_disposition WHERE application_id=:app_id`. If no row → `AppDispositionResponse(application_id=app_id)` (empty, NOT 404). Else map lists (rat-cap ids stringified).

---

## §12. Router: `portfolio.py` (`/api/v1/portfolio`) — 4 endpoints + startup/webhook helpers

`router = APIRouter(prefix="/api/v1/portfolio", tags=["portfolio"])` (`:39`). Module in-memory store
`_portfolios: dict[str,dict]` for webhook artifact-repo lookup until the DB schema carries all columns
(`:43`).

### §12.1 Helpers

`hydrate_portfolios_from_db(db) → int` (`:46-90`): `SELECT id,name,owner,status,artifact_repo_url,profile_id FROM portfolio`. For each row NOT already in `_portfolios`, populate with defaults (`artifact_repo_default_branch="main"`, `webhook_secret=""`, `profile_id=row["profile_id"] or ""`). Don't clobber richer in-memory metadata from a prior POST. Returns row count. Called from lifespan.

`persist_portfolio_profile_id(db, portfolio_id, profile_id)` (`:93-110`): `UPDATE portfolio SET profile_id=:pid WHERE id=:id` (empty → NULL); commit; mirror into `_portfolios` (REQ-LP-002).

`find_portfolio_by_repo(repo_full_name) → dict|None` (`:384-392`): scan `_portfolios` for matching `artifact_repo_url` (webhook use).

### §12.2 Endpoint table

| # | Method | Path | Auth | Request | Response | Status | Line |
|---|---|---|---|---|---|---|---|
| 1 | POST | `""` | `require_role(PORTFOLIO_ADMIN)` | `PortfolioCreate` | `PortfolioDetail` | 201/422 | `:113` |
| 2 | GET | `""` | `get_current_user` | — | `list[PortfolioListItem]` | 200 | `:266` |
| 3 | GET | `/{portfolio_id}` | `get_current_user` | — | `PortfolioDetail` | 200/404 | `:311` |
| 4 | GET | `/{portfolio_id}/target-state-rollup` | `get_current_user` | — | dict (`PortfolioTargetStateRollup`) | 200/404 | `:351` |

### §12.3 `create_portfolio` (`:114-263`) — tenant creation

RBAC (`require_role(PORTFOLIO_ADMIN)` resolves `get_current_user` first → 401 unauth / 403 under-priv BEFORE any side effect):
```
config = AppConfig()
if config.github_token:  # validate repo access before persisting
    try: GitService(...).validate_repo_access()
    except GitServiceError as e: raise 422 (str(e))
    except Exception as e: log git_validation_failed; raise 422 "Could not validate repository..."
else: log github_validation_skipped
portfolio_id = uuid4(); now = utcnow()
INSERT INTO portfolio (id,name,owner,status='active',artifact_repo_url,profile_id,created_at,updated_at)
    with profile_id = body.profile_id or None
enqueue_event(db, "portfolio.created", {portfolio_id,name,owner}, aggregate_type="portfolio",
    aggregate_id=str(portfolio_id), profile_id=, owner_scope=body.owner,
    idempotency_key=f"portfolio.created:{portfolio_id}")   # SAME transaction — atomic with INSERT (REQ-EO-003/004)
commit
# best-effort recurring weekly governance-sweep schedule (Temporal outage must NOT block creation)
try: temporal = get_temporal_client(); create_governance_schedule(temporal, str(portfolio_id), cadence="weekly", task_queue=...)
except Exception: log governance_schedule_autocreate_failed
_portfolios[str(portfolio_id)] = {id,name,owner,status:"active",artifact_repo_url,artifact_repo_default_branch,webhook_secret,profile_id}
return PortfolioDetail(status="active", webhook_secret_configured=bool(body.webhook_secret), ...)
```

**#2 `list_portfolios` (`:267-308`)**: `visible = filter_portfolio_ids_by_membership(db, user)`. If None (admin) → all rows `ORDER BY name`; if empty → `[]`; else `WHERE id = ANY(:ids) ORDER BY name`. Map to `PortfolioListItem`.

**#3 `get_portfolio` (`:312-348`)**: `uuid.UUID(portfolio_id)` else 404; `verify_portfolio_access`; `SELECT * FROM portfolio WHERE id=:id` (404 if none); merge in-memory (`artifact_repo_default_branch` default "main", `webhook_secret_configured=bool(...)`, `profile_id = row["profile_id"] or in_mem profile_id`).

**#4 `get_portfolio_target_state_rollup` (`:360-381`)**: `uuid.UUID(...)` else 404; `verify_portfolio_access`; `rollup_svc.get_target_state_rollup(db, pid, get_config())` — reads each wave's `wave-outcome-synthesis.json`, sums counts; pending-synthesis waves appear under `waves_omitted`.

---

## §13. Router: `portfolio_members.py` (`/api/v1/admin`) — 3 endpoints

`router = APIRouter(prefix="/api/v1/admin", tags=["Admin"])` (`:36`). EVERY endpoint requires
`portfolio_admin` (managing membership is privileged).

| # | Method | Path | Auth | Request | Response | Status | Line |
|---|---|---|---|---|---|---|---|
| 1 | GET | `/portfolios/{portfolio_id}/members` | `require_role(PORTFOLIO_ADMIN)` | — | `list[PortfolioMembershipResponse]` | 200 | `:39` |
| 2 | POST | `/portfolios/{portfolio_id}/members` | `require_role(PORTFOLIO_ADMIN)` | `PortfolioMembershipCreate` | `PortfolioMembershipResponse` | 201/404 | `:63` |
| 3 | DELETE | `/portfolios/{portfolio_id}/members/{user_id}` | `require_role(PORTFOLIO_ADMIN)` | — | — | 204/404 | `:115` |

**#1 `list_members`**: `membership_svc.list_portfolio_members(db, portfolio_id)` → map each to `PortfolioMembershipResponse(id, portfolio_id, user_id, role, granted_by, granted_at)`.

**#2 `add_or_update_member` (`:68-112`)**: verify portfolio exists (`SELECT 1 FROM portfolio WHERE id=:pid`; 404 if none — cleaner than the FK 500); `membership_svc.add_member(db, portfolio_id=, user_id=body.user_id, role=body.role, granted_by=user.sub)` (idempotent on `(portfolio_id, user_id)`; new role updates); log `portfolio_membership.added`; return `PortfolioMembershipResponse`.

**#3 `remove_member` (`:119-134`)**: `deleted = membership_svc.remove_member(db, portfolio_id, user_id)`; if not deleted → 404 "Membership not found"; else log `portfolio_membership.removed`; 204.

---

## §14. Router: `systems.py` (`/api/v1`) — 12 endpoints

`router = APIRouter(prefix="/api/v1", tags=["Systems"])` (`:64`). `REVIEWER_ROLES` = the 7 non-viewer
roles (same as gate reviewers) (`:54-62`).

| # | Method | Path | Auth | Request | Response | Line |
|---|---|---|---|---|---|
| 1 | GET | `/systems` | `get_current_user` | query `portfolio_id` (required) | `list[SystemSummary]` | `:67` |
| 2 | GET | `/systems/{system_id}` | dep `require_system_member` | — | `SystemDetail` | `:80` |
| 3 | GET | `/systems/{system_id}/capabilities` | dep `require_system_member` | — | `list[CapabilitySummary]` | `:92` |
| 4 | GET | `/systems/{system_id}/business-domains` | dep `require_system_member` | — | `list[BusinessDomainSummary]` | `:104` |
| 5 | GET | `/systems/{system_id}/lineage` | dep `require_system_member` | — | `SystemLineageView` | `:116` |
| 6 | GET | `/capabilities/{capability_id}` | dep `require_capability_member` | — | `CapabilityRead` | `:126` |
| 7 | GET | `/capabilities/{capability_id}/lineage` | dep `require_capability_member` | — | `CapabilityLineageView` | `:138` |
| 8 | GET | `/capability-lineage/{lineage_id}` | dep `require_capability_lineage_member` | — | `CapabilityLineageRowView` | `:155` |
| 9 | POST | `/capability-lineage/{lineage_id}/ratify` | dep `require_capability_lineage_member` + `require_role(*REVIEWER_ROLES)` | `CapabilityLineageRatifyRequest?` | `CapabilityLineageRowView` | `:168` |
| 10 | POST | `/capability-lineage/{lineage_id}/reject` | dep `require_capability_lineage_member` + `require_role(*REVIEWER_ROLES)` | `CapabilityLineageRejectRequest` | `CapabilityLineageRowView` | `:196` |
| 11 | GET | `/waves/{wave_id}/capability-lineage` | dep `require_wave_member` | — | `WaveCapabilityLineageView` | `:224` |
| 12 | GET | `/portfolios/{portfolio_id}/compliance/system-rollup` | `get_current_user` | — | `PortfolioComplianceRollup` | `:247` |

**#1 `list_systems`**: `verify_portfolio_access`; `system_service.list_systems(db, portfolio_id)`. **#9 ratify**: sets `ratified_by=user.sub`, `ratified_at=now` (idempotent; different reviewer records latest). **#10 reject**: leaves `ratified_at` NULL, appends `[REJECTED]`-prefixed feedback to `notes`. **#11**: scoped via `system_application` (rows whose target OR source capability lives on a system with ≥1 app in the wave). **#12**: `verify_portfolio_access`; `system_service.get_portfolio_compliance_rollup(db, portfolio_id)` — joins `system → system_application → application`, aggregates `application.metadata.compliance` per system (SF3: compliance rolls up at system grain).

---

## §15. Router: `lines.py` — two routers, 11 endpoints

`router = APIRouter(prefix="/api/v1/lines", tags=["Assembly Lines"])` (`:72`);
`line_start_router = APIRouter(prefix="/api/v1", tags=["Assembly Lines"])` (`:76`). Line-start endpoints
mount at top level so imperative verbs don't pollute the registry surface. Role sets: `VIEWER_PLUS`
(8 human roles, `:56-65`), `MANAGER_ROLES` (`:67-70`).

### §15.1 Endpoint table (mount order per router)

| # | Router | Method | Path | Auth | Request | Response | Status | Line |
|---|---|---|---|---|---|---|---|---|
| 1 | router | GET | `/api/v1/lines` | `require_role(*VIEWER_PLUS)` | — | dict `{data:[...]}` | 200 | `:90` |
| 2 | router | GET | `/api/v1/lines/{line_name}` | `require_role(*VIEWER_PLUS)` | — | dict | 200/404 | `:98` |
| 3 | router | GET | `/api/v1/lines/{line_name}/status` | `require_role(*VIEWER_PLUS)` + `get_current_user` | query `portfolio_id?` | dict | 200/404 | `:112` |
| 4 | router | GET | `/api/v1/lines/{line_name}/throughput` | `require_role(*VIEWER_PLUS)` + `get_current_user` | query `days=7 (1-90)`, `portfolio_id?` | dict | 200/404 | `:145` |
| 5 | router | POST | `/api/v1/lines/{line_name}/start` | `require_role(*MANAGER_ROLES)` + temporal | `LineStartRequest` | `LineStartResponse` | 202/400/404/409/502/503 | `:774` |
| 6 | line_start | POST | `/api/v1/lines/{line_name}/resolve-inputs` | `require_role(*MANAGER_ROLES)` | `ResolveInputsRequest` | `ResolveInputsResponse` | 200/404 | `:676` |
| 7 | line_start | GET | `/api/v1/lines/{line_name}/runs/{run_id}/scope` | `require_role(*VIEWER_PLUS)` | — | dict | 200/404 | `:695` |
| 8 | line_start | POST | `/api/v1/architecture/start` | `require_role(*MANAGER_ROLES)` + temporal | `LineStartRequest` | `LineStartResponse` | 202/… | `:717` |
| 9 | line_start | POST | `/api/v1/data/start` | `require_role(*MANAGER_ROLES)` + temporal | `LineStartRequest` | `LineStartResponse` | 202/… | `:732` |
| 10 | line_start | POST | `/api/v1/modernization/start` | `require_role(*MANAGER_ROLES)` + temporal | `LineStartRequest` | `LineStartResponse` | 202/… | `:747` |
| 11 | line_start | POST | `/api/v1/skills/{skill_id}/dispatch` | `get_current_user` + portfolio-scoped RBAC (in-body) + temporal | `SkillDispatchRequest` | `LineStartResponse` | 202/403/404/502 | `:837` |

### §15.2 Registry read endpoints

`_info_as_dict(info)` (`:79-87`): `{name, description, steps, skills, gates, dependencies}`.
**#1** `list_lines` → `{"data":[_info_as_dict(i) for i in lines_svc.list_lines()]}`.
**#2** `get_line` → `lines_svc.get_line(line_name)` (404 `LINE_NOT_FOUND`).
**#3** `get_line_status` (`:113-142`): if `portfolio_id` → `verify_portfolio_access`; `member_ids = filter_portfolio_ids_by_membership`; `lines_svc.get_line_status(db, line_name, portfolio_id=, portfolio_ids=)`; `KeyError` → 404 `LINE_NOT_FOUND`.
**#4** `get_line_throughput` (`:146-175`): same scoping; `lines_svc.get_line_throughput(db, line_name, days=, portfolio_id=, portfolio_ids=)`; `KeyError` → 404.

### §15.3 `_start_line_workflow(line, body, db, temporal)` — the shared line-start core (`:340-604`)

Registry-driven single routing authority (`lines_svc.resolve_startable_line`) shared by #5/#8/#9/#10.
```
resolved = lines_svc.resolve_startable_line(line)
if None: raise 404 LINE_NOT_STARTABLE  # unknown, continuous (Sustainment/Governance), or no per-line workflow (Build)
workflow_name, id_prefix = resolved
target = _validate_target_app(db, body.target_app_id)  # SELECT id,name,portfolio_id; 404 TARGET_APP_NOT_FOUND
# prior-artifact validation
missing = []
if body.prior_artifact_paths:
    if not config.github_token: raise 503 GIT_TOKEN_MISSING
    git_svc = GitService(...); missing = await _read_required_artifacts(git_svc, paths)  # parallel probe via asyncio.to_thread
if missing: raise 400 PRIOR_ARTIFACTS_MISSING details={missing_paths, artifact_repo}
# Phase-10 W9 scoped-execution
run_mode = scoped_svc.normalize_run_mode(body.run_mode)  # full-pipeline | isolated | partial | composed
confirmed = build ConfirmedInput list from body.confirmed_inputs (skip non-dict/empty-path); fall back to prior_artifact_paths (origin "operator-supplied", attestation "operator-supplied:line-start")
if run_mode != FULL_PIPELINE and not confirmed and not body.context_starved:
    raise 400 SEED_CONFIRMATION_REQUIRED  # REQ-SE-001 no silent auto-seed
deps = lines_svc.line_dependencies(line)
unmet = [] if full_pipeline else list(deps)
prereq = scoped_svc.evaluate_prerequisites(run_mode, unmet_dependencies=unmet)
if not prereq.allowed: raise 409 PREREQUISITES_UNMET details={prerequisite_decision}
origins = tuple(normalize_input_origin(ci.origin) for ci in confirmed)
coverage = 0.0 if (context_starved and not confirmed) else 1.0
assurance = compute_assurance(AssuranceInputs(run_mode, input_origins=origins, coverage, all_gates_met=not unmet, context_starved=...))
assurance = cap_assurance(assurance, prereq.assurance_ceiling)  # ceiling can only LOWER
# kickoff delegation (Phase 6 W1)
if body.delegation and body.delegation.is_delegated():
    bundle_svc.dispatch_from_kickoff(db, scope_kind=, target_id=, application_id=body.target_app_id, wave_id=None, expires_in_hours=, fallback_policy=, created_by_user_id="olympus-kickoff")
workflow_id = f"{id_prefix}{body.target_app_id}-{int(time.time())}"
line_input = {app_id, app_name, wave_id, portfolio_id, artifact_repo, target_repo_url,
    disposition: body.disposition.title(), prior_artifacts, peer_workflow_ids:{},
    target_framework, target_frontend, primary_language, run_mode:str, assurance_level:str}
try: temporal.start_workflow(workflow_name, line_input, id=workflow_id, task_queue=config.temporal_task_queue)
except Exception as e: raise 502 WORKFLOW_START_FAILED
# best-effort recording (never fails the started workflow)
if confirmed: try traceability_svc.record_input_provenance(...); except: log input_provenance_record_failed
try: scoped_svc.record_scoped_run(...); except: log scoped_run_record_failed
return LineStartResponse(workflow_id, temporal_ui_url, run_mode:str, assurance_level:str)
```
`_read_required_artifacts(git_svc, paths)` (`:313-337`): parallel `asyncio.gather` of `_probe` (each runs `git_svc.read_file` in a thread; missing on `GitServiceError`); returns the subset that is unreadable.

`_LINE_SPECS` (`:196-213`) is a legacy 3+1-entry map retained only for tests; the authoritative routing is `lines_svc.resolve_startable_line`.

`LineStartRequest` (`:216-269`): `target_app_id:UUID`, `wave_id:UUID`, `artifact_repo` (min 1), `target_repo_url` (min 1), `disposition` (min 1), `prior_artifact_paths:list[str]`, `target_framework?`, `target_frontend?`, `primary_language?`, `delegation:DelegationRequest?`, `run_mode?`, `confirmed_inputs:list[dict]`, `context_starved:bool=False`. `LineStartResponse` (`:272-283`): `workflow_id`, `temporal_ui_url`, `run_mode?`, `assurance_level?`.

### §15.4 Resolve-inputs + run-scope

**#6 `resolve_line_inputs` → `_resolve_inputs(line, body, db)` (`:640-673`)**: 404 `LINE_NOT_STARTABLE` if `resolve_startable_line(line) is None`; `_validate_target_app`; `canonical = lines_svc._canonical_line_name(line) or line`; `scoped_svc.propose_inputs(db, app_id=, target_line=canonical, committed_paths=)`; return `ResolveInputsResponse(app_id, target_line, proposals, requires_confirmation=True always, context_starved)`. NEVER dispatches.

**#7 `get_run_scope` (`:698-714`)**: `scope = scoped_svc.get_scoped_run(db, run_id)`; 404 `RUN_SCOPE_NOT_FOUND` if None; else return scope dict (run-mode + assurance + prereq decision).

### §15.5 `dispatch_skill` (`:842-952`) — single-skill dispatch with portfolio-scoped RBAC

```
# Phase-10 W2 hole #2: RBAC on the TARGET app's portfolio, not a global manager role
portfolio_id = verify_application_portfolio_access(db, user, body.app_id)  # 404 if app missing; None for admin
if portfolio_id is not None:
    require_portfolio_scoped_role(db, user, portfolio_id, [r.value for r in MANAGER_ROLES])  # 403 wrong-portfolio manager
registry = skill_registry_svc.get_registry()
try: canonical_skill_id = registry.resolve_dispatch(skill_id)
except KeyError: raise 404 SKILL_NOT_FOUND
workflow_id = f"skill-{canonical_skill_id}-{app_id}-{int(time.time())}"
structlog.get_logger(__name__).info("skill_dispatch_started", ...)  # bound at call time (GOTCHA cache_logger_on_first_use)
payload = {task_type: body.task_type or canonical_skill_id, app_id, skill_id:canonical_skill_id,
    input_artifacts, optional_input_artifacts, source_repo, artifact_repo, artifact_ref, model_preference, context}
try: temporal.start_workflow("SmokeTestAgentDispatchWorkflow", payload, id=workflow_id, task_queue=...)
except Exception as e: raise 502 WORKFLOW_START_FAILED
return LineStartResponse(workflow_id, temporal_ui_url)
```
`SkillDispatchRequest` (`:814-834`): `app_id:UUID`, `task_type?`, `input_artifacts:list`, `optional_input_artifacts:list`, `source_repo=""`, `artifact_repo=""`, `artifact_ref=""`, `model_preference=""`, `context:dict`. `_SKILL_DISPATCH_WORKFLOW = "SmokeTestAgentDispatchWorkflow"` (`:811`) — held as a string so the API doesn't import the sandbox-heavy workflow class onto the request path.

`_temporal_ui_url(base_url, namespace, workflow_id)` (`:286-289`): `f"{base_url.rstrip('/')}/namespaces/{namespace}/workflows/{workflow_id}"`.

---

## §16. Cross-cutting invariants (apply everywhere)

- **Signal-fires-only-on-advance**: gate approval fires the Temporal signal only when quorum + oversight are met; a pending quorum gate does NOT signal (`gates.py:283-286`; `services/gate.py:684-728`).
- **Inbox-before-wire**: every operator-initiated Temporal signal is persisted to `workflow_signal_inbox` (`status="sent"`) BEFORE the wire-send; on send failure the row is flipped to `queued` and a 202 is still returned (waves `dispatch_architecture`, `tier1_approval`; `signal_inbox.enqueue_signal`/`mark_queued`).
- **Best-effort recording**: input-provenance + scoped-run recording never fail an already-started workflow (`lines.py:548-593`); governance-schedule autocreate never blocks portfolio creation (`portfolio.py:224-239`).
- **Admin short-circuit**: portfolio-scope dependencies short-circuit for `portfolio_admin` before resolving the entity's portfolio, avoiding a redundant query the handler repeats.
- **Fail-closed boot**: the app refuses to start in a production env with insecure auth (`assert_secure_auth_posture`) or a credentialed CORS wildcard (`assert_safe_cors`).
- **Structured errors**: every error returns `{"error":{code,message,details,request_id,trace_id}}` with `X-Trace-ID`/`X-Request-ID` headers; `request_id == trace_id`.
