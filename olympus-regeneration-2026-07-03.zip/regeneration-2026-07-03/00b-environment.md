# 00b — Environment & Bring-up (everything that is NOT application logic)

> ATOMIC regeneration spec. Live source: `/Users/pnunna/Documents/GitHub/olympus` @ `main` HEAD `6c99bb6b`, verified 2026-07-03. Cites `path:line`.

This doc captures how to STAND UP the system: the docker-compose topology, every env var, Temporal worker/namespace/task-queue config, volumes, seed scripts, all 35 Makefile targets, local-vs-deployed differences, and a from-zero runbook.

---

## 1. docker-compose services (all 13) — exact config

Source: `docker-compose.yml`. Named volumes at `:532-536`. Compose has NO top-level `version:` key (Compose v2 spec).

### 1.1 `postgres` (`docker-compose.yml:10-25`)
- **image**: `postgres:16`
- **ports**: `5432:5432`
- **environment**: `POSTGRES_USER=${POSTGRES_USER:-olympus}`, `POSTGRES_PASSWORD=${POSTGRES_PASSWORD:-olympus_dev}`, `POSTGRES_DB=${POSTGRES_DB:-postgres}`
- **volumes**: `postgres-data:/var/lib/postgresql/data`; `./db/init:/docker-entrypoint-initdb.d`
- **healthcheck**: `pg_isready -U ${POSTGRES_USER:-olympus}`, interval 5s / timeout 5s / retries 10
- **init side-effect**: `db/init/01-create-databases.sh` runs once on first launch and creates DBs `olympus`, `temporal`, `temporal_visibility` and GRANTs all to `$POSTGRES_USER` (`db/init/01-create-databases.sh:8-16`). GOTCHA: `POSTGRES_DB` defaults to `postgres`, NOT `olympus` — the app DB is created by the init script, not by the image's `POSTGRES_DB`.

### 1.2 `redis` (`:27-37`)
- **image**: `redis:7`
- **ports**: `6379:6379`
- **volumes**: `redis-data:/data`
- **healthcheck**: `redis-cli ping`, interval 5s / timeout 3s / retries 5

### 1.3 `localstack` (`:39-47`)
- **image**: `localstack/localstack:latest`
- **ports**: `4566:4566`
- **environment**: `SERVICES=s3,secretsmanager`, `DEFAULT_REGION=us-east-1`
- **volumes**: `localstack-data:/var/lib/localstack`
- No healthcheck.

### 1.4 `db-migrate` (`:49-62`)
- **build**: context `.`, dockerfile `db/Dockerfile` (one-shot Alembic runner: `FROM public.ecr.aws/docker/library/python:3.14-slim`, `CMD ["alembic","upgrade","head"]`, `db/Dockerfile`)
- **environment**: `DATABASE_HOST=postgres`, `DATABASE_PORT="5432"`, `DATABASE_NAME=olympus`, `DATABASE_USER=${POSTGRES_USER:-olympus}`, `DATABASE_PASSWORD=${POSTGRES_PASSWORD:-olympus_dev}`
- **depends_on**: `postgres` (service_healthy)
- **restart**: `"no"` — runs to completion, then exits. Other services gate on `service_completed_successfully`.

### 1.5 `temporal-server` (`:67-92`)
- **image**: `temporalio/auto-setup:latest`
- **ports**: `7233:7233`
- **environment**: `DB=postgres12`, `DB_PORT="5432"`, `POSTGRES_USER=${POSTGRES_USER:-olympus}`, `POSTGRES_PWD=${POSTGRES_PASSWORD:-olympus_dev}`, `POSTGRES_SEEDS=postgres`, `DYNAMIC_CONFIG_FILE_PATH="config/dynamicconfig/docker.yaml"`
- **volumes**: `./infra/temporal/dynamicconfig.yaml:/etc/temporal/config/dynamicconfig/docker.yaml:ro`
- **depends_on**: `postgres` (service_healthy)
- **healthcheck**: `tctl --address temporal-server:7233 cluster health 2>/dev/null || nc -z localhost 7233`, interval 10s / timeout 5s / retries 20 / start_period 30s
- **dynamicconfig** (`infra/temporal/dynamicconfig.yaml`): raises `limit.blobSize.warn` → 1 MiB (1048576) and `limit.blobSize.error` → 4 MiB (4194304). Temporal defaults are 512 KiB warn / 2 MiB error. GOTCHA (band-aid, DRIFT D13): masks oversized gate-evidence activity inputs; durable fix is slimming `_build_evidence_data` in `temporal/olympus_workflows/workflows/base.py`.

### 1.6 `temporal-namespace-init` (`:102-114`)
- **image**: `temporalio/auto-setup:latest`
- **depends_on**: `temporal-server` (service_healthy)
- **environment**: `TEMPORAL_ADDRESS=temporal-server:7233`
- **entrypoint**: `["sh","-c"]`; **command**: `temporal operator namespace update -n default --retention 2160h && temporal operator namespace describe -n default | grep RetentionTtl`
- **restart**: `"no"`. Idempotent — pins `default` namespace `WorkflowExecutionRetentionTtl` to **2160h (90 days)** (auto-setup creates it at 24h, too short for reviewers). Spec: `specifications/phase-5/temporal-retention-and-aged-out-workflows.md`.

### 1.7 `temporal-ui` (`:116-125`)
- **image**: `temporalio/ui:latest`
- **ports**: `8080:8080`
- **environment**: `TEMPORAL_ADDRESS=temporal-server:7233`, `TEMPORAL_CORS_ORIGINS=http://localhost:3000`
- **depends_on**: `temporal-server` (service_healthy)

### 1.8 `olympus-api` (`:130-226`)
- **build**: context `.`, dockerfile `olympus-api/Dockerfile`
- **ports**: `8000:8000`
- **environment**: see §2.1 for the full list.
- **volumes**: `~/.aws:/root/.aws:ro`; `./cross-cutting/skills:/app/repo/cross-cutting/skills:ro`; `./profiles:/app/repo/profiles:ro`; `./olympus-worker/config:/app/repo/olympus-worker/config:ro`; `agent-workspace:/workspace`
- **depends_on**: `db-migrate` (completed_successfully), `postgres` (healthy), `temporal-server` (healthy), `redis` (healthy)
- **healthcheck**: `curl -sf http://localhost:8000/health`, interval 10s / timeout 5s / retries 5 / start_period 15s

### 1.9 `olympus-temporal-worker` (`:228-316`)
- **build**: context `.`, dockerfile `olympus-worker/Dockerfile`
- **ports**: NONE (scale-safe; run `docker compose up -d --scale olympus-temporal-worker=N`).
- **environment**: see §2.2.
- **volumes**: `~/.aws:/root/.aws:ro`; `./profiles:/app/repo/profiles:ro`; `./schemas:/app/repo/schemas:ro`
- **depends_on**: `db-migrate` (completed), `temporal-server` (healthy), `postgres` (healthy)
- **healthcheck** (`:309-316`): a Python one-liner that scans `/proc` for another PID whose cmdline contains `src.worker` (excludes own PID via `os.getpid()` — `procps`/`pgrep` not installed in `python:3.14-slim`). interval 15s / timeout 5s / retries 5 / start_period 30s. GOTCHA: `WORKER_IDENTITY` is intentionally UNSET here so the entrypoint derives it per-replica from hostname+pid (`_resolve_worker_identity`, `olympus-worker/src/worker.py:35-54`).

### 1.10 `olympus-dashboard` (`:318-343`)
- **build**: context `./dashboard`, dockerfile `Dockerfile`
- **ports**: `3000:3000`
- **environment**: `API_URL=http://olympus-api:8000` (container-internal), `VITE_API_BASE_URL=http://localhost:8000` (browser-resolved), `VITE_WS_BASE_URL=ws://localhost:8000` (browser-resolved)
- **volumes**: `./dashboard/src:/app/src`; `./dashboard/index.html:/app/index.html`; `./docs:/docs:ro` (the AboutContinuity page imports `docs/phase1-continuity-matrix.md?raw`)
- **depends_on**: `olympus-api` (healthy)
- **healthcheck**: `node -e "fetch('http://localhost:3000')..."` (no interval/retries specified → compose defaults)

### 1.11 `olympus-agent-runtime` (`:360-458`)
- **build**: context `.`, dockerfile `olympus-agent-runtime/Dockerfile`
- **ports**: NONE (replicas reach clients only via the LB). Scale to N≤10 via `--scale olympus-agent-runtime=N`.
- **environment**: see §2.3.
- **volumes**: `~/.aws:/root/.aws:ro`; `./cross-cutting/skills:/app/skills:ro`; `./schemas:/app/repo/schemas:ro`; `./profiles:/app/repo/profiles:ro`; `${OLYMPUS_LOCAL_SOURCE_HOST_DIR:-.}:/seed/vista:ro`; `agent-workspace:/workspace`
- **shm_size**: `${AGENT_SHM_SIZE:-512m}` (up from Docker's 64 MiB default)
- **deploy**: `replicas: ${AGENT_REPLICAS:-3}`; `resources.limits.memory: ${AGENT_MEMORY_LIMIT:-6G}`; `resources.reservations.memory: ${AGENT_MEMORY_RESERVATION:-2G}`
- **healthcheck**: `curl -sf http://localhost:8100/health`, interval 10s / timeout 5s / retries 5 / start_period 15s

### 1.12 `olympus-agent` — HAProxy LB (`:486-506`)
- **image**: `haproxy:2.9-alpine`
- **ports**: `8100:8100` (single host binder — do NOT scale this service)
- **volumes**: `./infra/haproxy/agent-lb.cfg:/usr/local/etc/haproxy/haproxy.cfg:ro`
- **depends_on**: `olympus-agent-runtime` (healthy)
- **healthcheck**: `wget -qO- http://127.0.0.1:8100/lb-health` (127.0.0.1, NOT localhost — alpine resolves localhost→::1 first and HAProxy binds IPv4-only), interval 10s / timeout 5s / retries 5 / start_period 5s
- **routing**: `leastconn` via `server-template` + `resolvers` block that tracks the `--scale` DNS answer dynamically (nginx OSS `upstream` resolves once at load, so `least_conn` would collapse — see comment `:472-480` and `infra/haproxy/agent-lb.cfg`). Retries on a different replica when one returns 503.
- Callers use `OLYMPUS_AGENT_URL=http://olympus-agent:8100` (unchanged from the pre-LB DNS-round-robin design).

### 1.13 `olympus-mcp-server` (`:508-530`)
- **build**: context `.`, dockerfile `mcp-server/Dockerfile`
- **ports**: `3001:3001`
- **environment**: `DATABASE_HOST=postgres`, `DATABASE_PORT="5432"`, `DATABASE_NAME=olympus`, `DATABASE_USER=${POSTGRES_USER:-olympus}`, `DATABASE_PASSWORD=${POSTGRES_PASSWORD:-olympus_dev}`
- **depends_on**: `db-migrate` (completed), `postgres` (healthy)
- **healthcheck**: `python -c "import urllib.request; urllib.request.urlopen('http://localhost:3001/')"`, interval 10s / timeout 5s / retries 5 / start_period 10s

### 1.14 Named volumes
`postgres-data`, `redis-data`, `localstack-data`, `agent-workspace` (`docker-compose.yml:532-536`). `agent-workspace` is shared between `olympus-api` (`/workspace`) and `olympus-agent-runtime` (`/workspace`) so Discovery sees the same non-Git source tree.

---

## 2. Environment variables (per service)

Defaults resolve from Settings classes when the env var is unset. `.env.example` (`/.env.example`) is the copy-to-`.env` template.

### 2.1 `olympus-api` (compose `:136-192`; Settings `olympus-api/src/config.py:108-172`)

| Env var | Purpose | Example / default |
|---|---|---|
| `API_PORT` | listen port | `8000` |
| `DATABASE_HOST` / `_PORT` / `_NAME` / `_USER` / `_PASSWORD` | Postgres components (URL composed at runtime, password `quote_plus`-encoded, `config.py:176-196`) | `postgres` / `5432` / `olympus` / `olympus` / `olympus_dev` (redact pw) |
| `TEMPORAL_HOST` | Temporal gRPC | `temporal-server:7233` |
| `TEMPORAL_NAMESPACE` | namespace | `default` |
| `TEMPORAL_UI_BASE_URL` | link base for "Open in Temporal" | `http://localhost:8080` |
| `REDIS_URL` | Redis | `redis://redis:6379/0` |
| `LOG_LEVEL` | log level | `INFO` |
| `GITHUB_TOKEN` | artifact repo access (portfolio create validates repo; Discovery commits) | `***REDACTED***` |
| `GITHUB_BASE_URL` | GH API root (Enterprise-friendly) | `https://api.github.com` |
| `GITHUB_WEBHOOK_SECRET` | webhook HMAC | `***REDACTED***` |
| `APP_ENV` | fail-closed prod guard (P7-S16.1) — tolerates dev conveniences only in {dev,local,test} | `dev` |
| `DEV_AUTH_BYPASS` | dev convenience: every request gets all roles; set `false` to exercise real RBAC | `true` |
| `AWS_REGION` / `AWS_PROFILE` | AWS creds | `us-east-1` / `ATLAS` |
| `MCP_SERVER_URL` | MCP server | `http://olympus-mcp-server:3001` |
| `SKILLS_ROOT` | skills root inside container | `/app/repo` |
| `OLYMPUS_PROFILES_DIR` | profiles enumeration root (`GET /api/v1/profiles`) | `/app/repo/profiles` |
| `OLYMPUS_PROFILE` | active client profile applied to 6 registries at startup (`activate_profile()`); unset ⇒ framework defaults | `faa` |
| `OLYMPUS_WORKER_CONFIG_DIR` | `/api/v1/agent-roles` reads `agents.yaml` here | `/app/repo/olympus-worker/config` |
| `RATE_LIMIT_ENABLED` | per-IP rate limiting; disabled in dev (dashboard fires 15-20 req/nav) | `false` |
| `JWT_SECRET` | JWT signing; prod refuses the dev default | `olympus-dev-secret` (redact) |
| `SERVICE_TOKEN_PROVISIONING_SECRET` | service-token minting secret | `olympus-dev-provisioning` (redact) |
| `SOURCE_INTAKE_ROOT` | unpacked non-Git sources (shared volume) | `/workspace/sources` |
| `SOURCE_INTAKE_MAX_UPLOAD_BYTES` | max upload zip | `524288000` (500 MiB) |
| `SOURCE_INTAKE_S3_REGION` | S3 intake region (fallbacks to boto3 chain) | `` |
| `CONNECTED_MEMORY_ENABLED` | feature flag (P7-S16.15); read-only view over traceability_link; default off | `false` |
| `WORKFLOW_STALENESS_MINUTES` | stale-workflow flag threshold | `30` |
| `WORKFLOW_CANCEL_GRACE_SECONDS` | graceful cancel wait | `30` |
| `CORS_ORIGINS` | comma-separated allowed origins | `http://localhost:3000` |

### 2.2 `olympus-temporal-worker` (compose `:237-282`; Settings `olympus-worker/src/config.py`)

| Env var | Purpose | Example / default |
|---|---|---|
| `TEMPORAL_HOST` | Temporal gRPC | `temporal-server:7233` |
| `TEMPORAL_NAMESPACE` | namespace | `default` |
| `TASK_QUEUE` | polled queue | `olympus-main` |
| `WORKER_IDENTITY` | (unset in compose) explicit override; else derived hostname+pid (`worker.py:50-54`) | unset |
| `MAX_CONCURRENT_ACTIVITIES` | worker tuning | `100` (default, `config.py:45`) |
| `MAX_CONCURRENT_WORKFLOW_TASKS` | worker tuning | `50` (default, `config.py:46`) |
| `DATABASE_*` | Postgres components | as api |
| `LOG_LEVEL` | log level | `INFO` |
| `AGENT_RUNTIME_MODE` | `live` \| `mock`; non-test APP_ENV refuses `mock` (DECISION-018, `config.py:68-84`) | `live` (default) |
| `APP_ENV` | env classification for the mock guard | `development` (default) |
| `OLYMPUS_AGENT_URL` | agent LB endpoint | `http://olympus-agent:8100` |
| `GITHUB_TOKEN` / `GITHUB_BASE_URL` / `GITHUB_REPO` | Git ops | (redact token) |
| `OLYMPUS_PROFILE` | active profile (`bootstrap_profile_from_env()`) | `faa` |
| `OLYMPUS_PROFILES_DIR` | profiles root | `/app/repo/profiles` |
| `OLYMPUS_PROFILE_ROOT` | profile-scoped data (context-priors) | `/app/repo/profiles/${OLYMPUS_PROFILE:-faa}` |
| `OLYMPUS_SCHEMAS_DIR` | JSON-Schema dir for advisory artifact validation | `/app/repo/schemas` |
| `AGENT_CONFIG_PATH` | agents.yaml path (SIGHUP hot-reloads) | `config/agents.yaml` (default, `worker.py:59`) |

### 2.3 `olympus-agent-runtime` (compose `:364-407`; Settings `olympus-agent-runtime/src/config.py:12-179`)

| Env var | Purpose | Example / default |
|---|---|---|
| `AGENT_NAME` | which registered identity this instance serves (DECISION-019) | `discovery-analyst` |
| `AGENT_PORT` | listen port | `8100` |
| `SKILLS_DIR` | skills root | `/app/skills` |
| `SKILL_API_URL` / `SKILL_API_URL` (compose sets `SKILL_API_URL: http://olympus-api:8000`) | API for skill dispatch | `http://olympus-api:8000` |
| `INFERENCE_PROVIDER` | composite provider id → `models.yaml` key: `bedrock-claude`\|`anthropic`\|`openai`\|`gemini-vertex`\|`bedrock-nova`\|`bedrock-mistral`\|`bedrock-llama` (legacy `bedrock` shimmed → `bedrock-claude`) | `bedrock-claude` |
| `DEFAULT_MODEL_TIER` | model tier | `tier-2` |
| `AWS_REGION` / `AWS_PROFILE` | AWS | `us-east-1` / `ATLAS` |
| `bedrock_model_prefix` (`BEDROCK_MODEL_PREFIX`) | `us`\|`global`\|`eu` | `us` (default) |
| `CLAUDE_CODE_USE_BEDROCK` | route Claude Agent SDK via Bedrock | `1` |
| `BEDROCK_INFERENCE_PROFILE_ARNS` | JSON map model→inference-profile ARN (blank ⇒ empty map via `NoDecode` + validator, `config.py:48-59`) | `` |
| `MAX_CONCURRENT_TASKS` | Semaphore size | `12` |
| `MAX_QUEUED_WAITERS` | extra queued callers before 503+Retry-After | `2` |
| `permission_mode` | Claude Agent SDK edit mode | `acceptEdits` (default) |
| `WORKSPACE_DIR` | agent working dir | `/workspace` |
| `OLYMPUS_API_TOKEN` | service token for API calls (compose maps from `OLYMPUS_AGENT_RUNTIME_TOKEN`) | `***REDACTED***` |
| `OLYMPUS_SCHEMA_ROOT` | schema root folded into system prompt + strict post-run validation | `/app/repo` |
| `OLYMPUS_PROFILE_ROOT` / `OLYMPUS_PROFILES_DIR` | profile/mission context injection | `/app/repo/profiles/${OLYMPUS_PROFILE:-faa}` / `/app/repo/profiles` |
| `OLYMPUS_LOCAL_SOURCE_MAP` | `<slug>=<path>[,...]` map to clone huge repos from `/seed/vista` bind-mount over `file://` | `` |
| `GIT_CLONE_TIMEOUT_SECONDS` | git clone subprocess timeout | `1800` |
| `skill_timeout_seconds` | absolute wall-clock backstop per SDK query | `10500` (175 min, < worker 3h) |
| `skill_idle_timeout_seconds` | PRIMARY hang-guard: max stream SILENCE before kill | `600` (10 min) |
| `skill_max_turns` | optional turn ceiling (default OFF) | `None` |
| `skill_max_budget_usd` | optional cost ceiling (default OFF) | `None` |
| `OLYMPUS_AGENTCORE_MEMORY_ENABLED` / `_GATEWAY_ENABLED` | P6-S3 spike flags, default false; lazy boto3 import inside guard | `false` |
| `AGENTCORE_MEMORY_ID` | AgentCore memory store id (only if Memory flag true) | `` |

Compose-level scaling knobs (`docker-compose.yml:445-452`): `AGENT_SHM_SIZE` (512m), `AGENT_REPLICAS` (3), `AGENT_MEMORY_LIMIT` (6G), `AGENT_MEMORY_RESERVATION` (2G).

### 2.4 `olympus-mcp-server` (`:514-519`)
`DATABASE_HOST` / `DATABASE_PORT` / `DATABASE_NAME` / `DATABASE_USER` / `DATABASE_PASSWORD` — Postgres connection (asyncpg, `mcp-server/olympus_mcp/db.py:28-53`).

### 2.5 Shared / infra env (`.env.example`)
- Postgres: `POSTGRES_USER=olympus`, `POSTGRES_PASSWORD=olympus_dev`, `POSTGRES_DB=postgres` (`.env.example:5-7`)
- LocalStack client-side: `AWS_ENDPOINT_URL=http://localstack:4566`, `AWS_ACCESS_KEY_ID=test`, `AWS_SECRET_ACCESS_KEY=test`, `AWS_DEFAULT_REGION=us-east-1` (`.env.example:30-33`)
- `.service-tokens.env` — minted by `scripts/seed_service_tokens.py`; sourced via `--env-file` so worker + agent-runtime start authenticated (Makefile `up`, `:178-187`). Holds `OLYMPUS_AGENT_RUNTIME_TOKEN` and worker token.

---

## 3. Temporal namespace / task-queue / worker config

- **Namespace**: `default` (`docker-compose.yml:144,239`; worker `WorkerConfig.temporal_namespace` default `default`, `olympus-worker/src/config.py:41`). Retention pinned to **2160h/90d** by `temporal-namespace-init` (`docker-compose.yml:112`).
- **Task queue**: `olympus-main` (`docker-compose.yml:240`; `config.py:42`; api `temporal_task_queue`, `olympus-api/src/config.py:125`). All workers poll this one shared queue.
- **Worker bootstrap** (`olympus-worker/src/worker.py:92-142`):
  1. `WorkerConfig()` loads env; `_configure_logging` sets structlog (`worker.py:69-89`).
  2. `config.validate_agent_runtime_mode()` — refuses `AGENT_RUNTIME_MODE=mock` with a non-test `APP_ENV` (DECISION-018, `config.py:68-84`).
  3. `_load_agent_config()` loads `config/agents.yaml` (path from `AGENT_CONFIG_PATH`) into `olympus_agent_registry` (`worker.py:57-60`).
  4. Registers `SIGHUP` handler → hot-reload agent registry (`worker.py:63-66,111`).
  5. `BaseWorkerConfig.from_env()`, then overrides `temporal_host`, `namespace`, `task_queue`, `max_concurrent_activities`, `max_concurrent_workflow_tasks`, and `worker_identity = _resolve_worker_identity(task_queue)` → `olympus-worker-<task_queue>-<hostname>-<pid>` (`worker.py:114-124`, `:54`).
  6. `create_temporal_client(...)` → `create_worker_with_defaults(client, workflows=ALL_WORKFLOWS, activities=ALL_ACTIVITIES, config=...)` → `worker.run()` (`worker.py:126-142`).
  - `ALL_WORKFLOWS` / `ALL_ACTIVITIES` come from `temporal/olympus_workflows/worker.py:191,258`; 26 workflow definitions across `workflows/`.
- **Concurrency defaults**: `max_concurrent_activities=100`, `max_concurrent_workflow_tasks=50` (`config.py:45-46`).

---

## 4. Volumes, seed data & scripts

### 4.1 Volumes
See §1.14. `postgres-data` persists across `down` (dropped only by `down -v` / `demo-nuke` / `reset`). `agent-workspace` shares the non-Git source tree between api and agent-runtime.

### 4.2 Seed / smoke scripts (`scripts/`)
- `seed_all.py` — orchestrates every seed in-process; `--reset` does a portfolio-scoped wipe then reseed; exit 0 all-ok / 1 named failure (`scripts/seed_all.py:1-30`). Invoked by `make demo-seed`.
- `seed_service_tokens.py` — mints service-account JWTs into `.service-tokens.env` (uses `JWT_SECRET`, default `olympus-dev-secret`). Invoked by `make seed-tokens` / `up` / `olympus2-seed-tokens`.
- `seed_demo_faa.py`, `seed_modernization_corpus.py`, `seed_atlas_challenge.py`, `seed_atlas_mid_flight.py`, `seed_data.py`, `seed_portfolio_memberships.py`, `seed_skills.py`, `seed_admin_user.py`, `seed_test_portfolio_4_demo_grain.py` — individual seeders composed by `seed_all.py`.
- `seed_phase5_testdata.py` — layers phase-5 deep test state (pending gates incl. quorum G-V3, claimable delegated bundle, score history, drift alerts, traceability links) for the live Playwright suite; idempotent (ON CONFLICT upserts). Invoked by `make olympus2-seed-deep`.
- `demo_smoke.py` — hits `/api/v1/portfolio` and asserts `Modernization Corpus` + demo portfolio exist (`make demo-smoke`).
- DB seeds also live at `db/seeds/` (imported by `make csn-migrate-data` → `db/seeds/initial-data.sql`).

---

## 5. Makefile targets (all 35)

Source `Makefile`. 34 have `##` help annotations (`grep -cE '^[a-zA-Z0-9_-]+:.*?##' Makefile` = 34) plus the `help` target = **35** targets. `AGENT_SCALE ?= 8` is the default runtime-pool scale.

### 5.1 Stack up/down
| Target | Line | Does |
|---|---|---|
| `help` | `:46` | Print the annotated target list |
| `seed-tokens` | `:175` | Mint service-account JWTs into `.service-tokens.env` |
| `up` | `:178` | `seed-tokens` + `docker compose --env-file .env --env-file .service-tokens.env up -d --scale olympus-agent-runtime=$(AGENT_SCALE)` |
| `down` | `:189` | `docker compose down` (volumes preserved) |
| `reset` | `:192` | `down -v` + `up` (destructive — drops volumes) |

### 5.2 Demo lifecycle
| Target | Line | Does |
|---|---|---|
| `demo-up` | `:49` | `up -d --scale …=$(AGENT_SCALE)` → `demo-wait` → `demo-seed` → `demo-smoke`; prints dashboard/api/temporal URLs |
| `demo-wait` | `:61` | Poll `$(API_URL)/health/ready` until 200 (60 retries × 2s) |
| `demo-seed` | `:72` | `python scripts/seed_all.py --reset` (FAA demo + Modernization Corpus) |
| `demo-reset` | `:76` | `demo-wait` → `demo-seed` → `demo-smoke` (wipe+reseed without stopping) |
| `demo-down` | `:81` | `docker compose down` (state preserved) |
| `demo-nuke` | `:84` | `docker compose down -v` (destructive) |
| `demo-smoke` | `:87` | `python scripts/demo_smoke.py` — assert portfolios exist |

### 5.3 olympus2 (second parallel stack, +1000 host ports)
| Target | Line | Does |
|---|---|---|
| `olympus2-up` | `:111` | `olympus2-seed-tokens` + build+up under `-p olympus2` with both env-files, wait, seed demo+corpus+deep, smoke |
| `olympus2-seed-tokens` | `:130` | Mint JWTs for olympus2 (`JWT_SECRET` matches stack default) |
| `olympus2-seed` | `:139` | Reseed olympus2 demo+corpus+deep (stack up) |
| `olympus2-seed-deep` | `:143` | `python scripts/seed_phase5_testdata.py` (host 127.0.0.1:6432) |
| `olympus2-reset` | `:153` | `down -v` + `olympus2-up` |
| `olympus2-smoke` | `:157` | Smoke olympus2 |
| `olympus2-down` | `:160` | Stop olympus2 (volumes kept) |
| `olympus2-nuke` | `:163` | Stop + drop olympus2 volumes |

### 5.4 CSN Fargate (deployed AWS env; `CSN_TF_DIR=infra/terraform/environments/dev-csn-fargate`)
| Target | Line | Does |
|---|---|---|
| `csn-apply` | `:238` | `terraform apply` for CSN-Fargate |
| `csn-deploy-dashboard` | `:241` | Build dashboard prod image, push ECR, roll service (`scripts/csn-fargate/build-and-push-dashboard.sh`) |
| `csn-seed-admin` | `:244` | Seed/rotate bootstrap admin user; password → Secrets Manager |
| `csn-migrate-data` | `:247` | Import `db/seeds/initial-data.sql` into RDS |
| `csn-bootstrap` | `:250` | `csn-apply` + `csn-seed-admin` + `csn-migrate-data` + `csn-deploy-dashboard` |
| `csn-admin-password` | `:252` | Print current admin password from Secrets Manager |
| `csn-status` | `:257` | `aws ecs describe-services` health of the 7 ECS services |

### 5.5 Render / serve (Executive View microsite)
| Target | Line | Does |
|---|---|---|
| `render-exec` | `:220` | `validate-objectives` + `python scripts/render_exec_microsite.py` → `presentation/exec/data/` |
| `render-exec-generic` | `:223` | Render the `test-generic` profile (portability demo) |
| `serve-exec` | `:227` | `render-exec` + `python -m http.server $(EXEC_PORT=8765) --directory presentation` |

### 5.6 Validate
| Target | Line | Does |
|---|---|---|
| `validate-schemas` | `:200` | `bash schemas/validate.sh` (JSON Schema metaschema + shape) |
| `validate-objectives` | `:203` | `python scripts/validate_objectives.py` (profiles/*/objectives.yaml vs schema + registries) |
| `validate-profile` | `:206` | `python scripts/validate_profile.py $(PROFILE)` (all 7 bundles of a named profile) |
| `check-docs` | `:209` | `python scripts/check_doc_sync.py` (docs/presentation counts vs source of truth) |
| `fix-docs` | `:212` | `check_doc_sync.py --fix` (rewrite drifted counts) |

---

## 6. Local vs deployed differences

| Concern | Local (compose) | Deployed |
|---|---|---|
| Auth | `DEV_AUTH_BYPASS=true` (every request all roles); `APP_ENV=dev` | `DEV_AUTH_BYPASS=false`, real RBAC, prod `APP_ENV` refuses dev JWT default & mock runtime |
| Rate limiting | `RATE_LIMIT_ENABLED=false` (dashboard bursts) | default on via Helm values |
| Secrets | `JWT_SECRET=olympus-dev-secret`, `.service-tokens.env` minted locally | Secrets Manager (`csn-admin-password`, `foundry/dev/admin-user`) |
| AWS | LocalStack (`s3,secretsmanager`) for S3/Secrets; Bedrock is REAL (LocalStack can't emulate it) | real AWS; ECS Fargate cluster `foundry-dev`, RDS, ECR |
| Orchestration | docker-compose 13 services | ECS Fargate: 7 services (`olympus-api olympus-worker olympus-agent olympus-mcp-server olympus-dashboard temporal-server temporal-ui`, `Makefile:260`); Helm charts under `infra/helm/` + ArgoCD apps `infra/argocd/applications/` (dev/staging/prod) |
| Agent LB | HAProxy `olympus-agent` container | in-cluster equivalent |
| Temporal DB | one Postgres, 3 DBs | managed |
| Migrations | one-shot `db-migrate` (`alembic upgrade head`) | `csn-migrate-data` / migration job |
| `olympus2` | parallel local integration stack, host ports +1000 (api on **18000** not 9000; dashboard 4000; temporal-ui 9080; postgres 6432; redis 7379; localstack 5566; temporal 8233; agent 9100; mcp per override) | N/A |

Observability (deployed): Grafana dashboards `infra/grafana/dashboards/olympus-{agents,api,temporal}.json`; Prometheus `infra/prometheus/`.

---

## 7. From-zero bring-up runbook (clean machine)

Prereqs: Docker Desktop (with compose v2), Python 3.12 (default `python3` is 3.9.6 — too old; build `.venv` via `scripts/dev-setup.sh`), `~/.aws` with a Bedrock-capable profile named `ATLAS` (or override `AWS_PROFILE`). `make`, `curl`, `jq`.

```bash
# 1. Clone + enter
git clone <repo> olympus && cd olympus

# 2. Environment file (secrets)
cp .env.example .env
#    Edit .env: set GITHUB_TOKEN (artifact repo), AWS_PROFILE/AWS_REGION for Bedrock.
#    Leave POSTGRES_* / JWT_SECRET at dev defaults for a local stack.

# 3. Bring up the full stack (mints service tokens, starts 13 services, 8 agent replicas)
make demo-up
#    - seeds .service-tokens.env, docker compose up -d --scale olympus-agent-runtime=8
#    - db-migrate runs `alembic upgrade head` once (postgres must be healthy)
#    - temporal-namespace-init pins default namespace retention to 90d
#    - waits on http://localhost:8000/health/ready (60×2s)
#    - seeds FAA demo + Modernization Corpus, runs smoke

# 4. Verify endpoints
#    Dashboard:    http://localhost:3000
#    API:          http://localhost:8000  (health: /health, /health/ready)
#    Temporal UI:  http://localhost:8080
#    Agent LB:     http://localhost:8100/lb-health
#    MCP server:   http://localhost:3001

# 5. Reseed without restart (idempotent)
make demo-reset

# 6. Tear down
make down          # keep volumes (state preserved)
make demo-nuke     # drop volumes (full wipe)
make reset         # down -v + up (destructive rebuild)
```

Optional parallel integration stack (for the live Playwright suite):
```bash
make olympus2-up   # builds + starts under project olympus2, host ports +1000
                   # dashboard :4000, API :18000, Temporal UI :9080
```

GOTCHAS for a clean machine:
- Run tests with `AGENT_RUNTIME_MODE=mock APP_ENV=test` on Python 3.12 (`.venv`) — the live worker/api refuse `mock` outside {dev,local,test}.
- macOS has no `timeout` command; the `olympus2` seed uses numeric loopback `127.0.0.1` (not `localhost`) to dodge intermittent asyncpg gaierror.
- Bedrock is not emulated by LocalStack — agent execution needs real AWS creds; without them the runtime serves stub responses (`.env.example:36-37`).
- `POSTGRES_DB` is `postgres`, not `olympus`; the app DB + Temporal DBs are created by `db/init/01-create-databases.sh` on first postgres launch (a `down -v` re-triggers it).
