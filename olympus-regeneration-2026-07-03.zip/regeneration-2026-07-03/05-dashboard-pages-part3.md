# 05 — Dashboard Pages (Part 3: Skills, Compliance, AssemblyLines, MyTasks, MyBundles, Admin, Analytics)

Continues `05-dashboard-pages.md` / `-part2.md`. Same stack conventions
(`@trussworks/react-uswds`, `recharts`, `sonner` toast, `useChartTheme()`→ct,
`usePortfolioContext()`→`{portfolios, activePortfolio, loading, refresh}`, API
functions from `../../api/client` unless noted).

---

## Skills

### SkillCatalog.tsx (439 LOC) — route `/skills`
Filterable data grid of all AI skills with full CRUD.
State (:97-106): `filterLine/filterEnrichment/filterSource` ("all" default),
`skills: SkillRow[]`, `loading=true`, `loadError`, `showForm`, `formError`,
`formBusy`, `deleteError`.
`loadSkills` (:108-133): GOTCHA — paginates `fetchSkills({page, per_page:100})` in a
do-while until `page > pagination.total_pages`, concatenating all pages, then maps
via `apiToRow` (:48-59: skill_id→id, category default "General", model_tier default
"sonnet", assembly_line default "Cross-Cutting").
Derived: `filteredSkills` (:137-145) applies line/enrichment/source filters
(`matchesSourceFilter` from `./skillSource`); `assemblyLines` distinct sorted set;
`fullCount`/`partialCount` by enrichment.
`handleDelete(skillId)` (:153-162): `window.confirm` then `deleteSkill` → reload.
`handleCreate` (:223-247): `createSkill({skill_id, name, description?, category?,
assembly_line?, enrichment_level (default minimal), model_tier?, source (default
core)})` from a `FormData`. GOTCHA (P6-S10.3): create form source is Core or Custom
only (no profile tags).
Columns (:164-218): Skill ID (Link `/skills/{id}`), Name, Line, Model
(`AgentBadge` — opus purple, else blue), Enrichment (`EnrichmentBadge` — minimal
gray/partial amber/full green), Source (`profileSourceLabel`), Actions (Edit
navigate + Delete).
Render: header + Register Skill button, `CreateModal` registration form (2-col grid
of skill_id/name/category/assembly_line/enrichment/model_tier/source/description),
4 summary tiles (Total/Full/Partial/Assembly Lines), 3 filter selects (line/
enrichment/source with `PROFILE_SOURCE_OPTION`), `DataGrid` filterable.
`ASSEMBLY_LINE_OPTIONS` (:22-34): 11 entries incl. Cross-Cutting.

### SkillDetail.tsx (1007 LOC) — route `/skills/:skillId`
Full-width view + markdown editor for one skill.
State (:604-626): `skill: DisplaySkill|null`, `notFound`, `loadError`, `editing`,
`saving`, `saveError`, `deleted`, `deleteError`, plus 13 edit-form fields
(editName/Description/Category/AssemblyLine/Enrichment/ModelTier/Source/Status/
SystemPrompt/AllowedTools + editReferences/Assets/Scripts as `Record<string,string>`).
`loadSkill` (:644-655): `fetchSkill(skillId)` → `fromApiSkill` (:68-89 maps all
API fields incl. content, system_prompt, references_data, assets_data, scripts_data,
config_data, allowed_tools, dispatch_ids). GOTCHA: 404 message → notFound state.
Render branches (:659-685): deleted→success Alert; notFound→warning; loadError→error
Alert; !skill→loading. `handleStartEdit` populates form via `populateEditForm`
(:628-642). `handleSave` (:701-732): builds `SkillUpdate` (allowed_tools from
comma-split, references/assets/scripts only when non-empty) → `updateSkill(skillId,
body)`. `handleDelete` (:734-740): confirm → `deleteSkill` → deleted.
EDIT MODE (:745-896): metadata grid (name/category/assembly_line/model_tier
[tier-1 Opus/tier-2 Sonnet/tier-3 Haiku]/enrichment/source [core/custom + preserved
profile tag via `isProfileSource`]/status [active/deprecated/draft]/allowed_tools),
Description textarea, System Prompt `MarkdownEditor`, three `FileCollectionEditor`
(References default .md / Assets / Scripts default .sh), Save/Cancel.
VIEW MODE (:906-1005): header (name+description+skillPath) + Edit/Delete buttons,
`LabeledBadge` strip (Line/Model/Enrichment/Source/Status), Allowed Tools +
Dispatch IDs chips, System Prompt (`RenderedMarkdown`), `FileSection` for
References/Assets/Scripts, Configuration (`SyntaxHighlighter` json).
Helpers: `RenderedMarkdown` (:95-151) uses `AgentMarkdown` with custom code
(`SyntaxHighlighter` oneDark)/table/h1-h3 overrides. `MarkdownEditor` (:157-248):
Edit/Preview tab toggle. `FileSection` (:275-365): collapsible per-file view with
`fileRenderMode` (md/mdx→markdown, json, yaml/yml→yaml, else code) + language badge.
`FileCollectionEditor` (:371-570): add/remove/rename files (window.prompt for
rename), markdown editor for .md else textarea. `extToPrismLang` (:19-30) maps
extension→Prism language.

### SkillEvaluation.tsx (561 LOC) — route `/skills/evaluation`
Aggregate skill effectiveness. Two data sources: registry (`fetchSkills`) +
dispatch telemetry (`fetchSkillMetricsByLine`).
State (:81-86): `skills`, `metrics: SkillMetricsByLineResponse|null`, `loading`,
`selectedLine=ALL_LINES_OPTION`.
Effect (:88-120): paginate `fetchSkills` (all pages); then best-effort
`fetchSkillMetricsByLine` (failure → null, registry panels still render).
Memos: `byEnrichment` (full/partial/minimal counts), `byLine` (per-assembly-line
count sorted desc), `byAgent` (model tier → Opus/Haiku/Sonnet labels), `coverage`
(:172-186 — `covered`=distinct lines with any skill, `fullyEnriched`=lines with a
full skill, `total`=ASSEMBLY_LINES.length=11), `coreCount`, `profileCount`
(`isProfileSource`). `visibleLineBlocks` (:196-200): all lines or the selected one.
`dispatchByLineChart` (:202-207): per-line total_dispatches sorted desc.
Render: 5 summary tiles (Total/Covered N/11/Fully Enriched N/11/Core/Profile),
charts (Skills per line horizontal BarChart, Enrichment PieChart, Model Tier
PieChart, Enrichment Readiness table). Dispatch Activity section (:350-558): line
filter select; when no metrics → "no telemetry" message; else source_breakdown +
totals text, all-lines horizontal BarChart, per-line blocks with per-skill table
(Skill/Dispatches/Success [`successRate`]/Avg Duration [`formatDurationMs`]/Avg Cost
[`formatCostUsd` 4 decimals]/Top Model [max of row.models]/Source env:N task:M).
Helpers: `formatCostUsd` $x.xxxx, `formatDurationMs` (≥60000→min, ≥1000→s, else ms),
`successRate` (completed/total_dispatches %).

---

## Compliance

### CompliancePosture.tsx (629 LOC) — route `/compliance`
Portfolio-wide compliance status. `portfolioId = activePortfolio?.id`.
State (:86-105): `apps`, `health: GovernanceHealthCheck|null`, `complianceAlerts:
GovernanceDriftAlert[]`, `systemRollup: PortfolioComplianceRollup|null`, `loading`,
`error`, sweep state (`sweepStatus: idle|starting|running|error`, `sweepInfo`,
`sweepError`, `sweepCadence: weekly|quarterly`).
Effect (:109-160): `Promise.allSettled([fetchApplications, 
fetchGovernanceLatestHealthCheck, fetchGovernanceDriftAlerts({acknowledged:false,
per_page:100}), portfolioId? fetchPortfolioComplianceSystemRollup : null])`. Filters
alerts to `COMPLIANCE_DRIFT_TYPES` {compliance, accessibility, ea-alignment, cato}.
`getComplianceLabel(app)` (:67-76): reads `metadata.compliance.status` (untyped
JSONB slot); else derives from scores.overall (≥0.9→compliant else needs-review);
else "unknown". `complianceSummary` (:162-172): regex-classifies into compliant/
needsReview/unknown. `assessedCount` = compliant+needsReview; `localHealthIndex` =
compliant/assessed or null (GOTCHA P5-AUDIT-028: falls back to
`health.health_index` when nothing assessed). `certifiedCount` = apps with
`metadata.compliance.certified===true || cato_certified===true`.
`handleStartSweep` (:243-258): `startGovernanceSweep({portfolio_id, cadence})`.
Render: loading/error/`apps.length===0` empty. Header with Governance sweep trigger
(cadence select + Run sweep button + cATO evidence link + running/error banners).
7 metric tiles (Total Apps/cATO Certified/Compliant/Needs Review/Unknown/Open Drift
Alerts/Health Index). Per-system rollup table (SF3 §3 grain) when `systemRollup`.
Per-app compliance table (Application/Risk Tier/Compliance StatusBadge/Certification).
Open compliance drift alerts table (type/app via `appIdLabel`/opened/summary).

### CatoEvidence.tsx (576 LOC) — route `/compliance/cato`
OSCAL-flavored portfolio cATO rollup. `fetchPortfolioCatoEvidence(portfolioId)` →
`evidence: PortfolioCatoEvidence`. State (:70-76): evidence, loading, error, `tab:
"by-system"|"by-family"|"by-control"`, `expandedSystem`, `exporting`, `exportError`.
`handleExport` (:80-93): `downloadComplianceEvidence(portfolioId, "zip")`.
Memos: `byFamily` (:118-129) Map family→controls; `byControlRows` (:134-175) groups
controls by control_id across systems (sorted). Effect fetches when portfolioId.
Render: loading/error/empty (`systems.length===0`). Header + Export button. 6 summary
tiles (Systems/cATO Certified/Implemented/Partial/Planned/Unknown from
`evidence.totals`). Tabs (by-system default). By System: table of `SystemRow`
(:504-576 — expandable per-system control table). By Family: per-NIST-family status
counts. By Control: flat `byControlRows` with per-system status counts. `STATUS_LABEL`
(:55-66) maps statuses to human labels.

### SecurityPosture.tsx (367 LOC) — route `/compliance/security`
Portfolio-wide security state from `fetchApplications` +
`fetchGovernanceDriftAlerts` filtered to `SECURITY_DRIFT_TYPES` {security,
vulnerability, cve, owasp, agent-trust}. `getSecurityStatus(app)` (:59-85): reads
`metadata.security` (open_vulnerabilities/open_cves, highest_severity, status);
derives label clean/at-risk/monitoring. `postureSummary` (:141-160) counts
clean/monitoring/atRisk + totalOpen + critical/high. `sortedAlerts` (:163-179) sorted
by `SEVERITY_ORDER` (critical0..info4). Render: 6 tiles + per-app table
(status/open vulns/highest severity) + security drift alerts table.

### ApplicationCompliance.tsx (59 LOC) — route `/compliance/:appId`
GOTCHA: demo-only, loads a hardcoded fixture `cato-evidence-IACRA.json` from
`MOCK_EVIDENCE` registry (:21-24, keyed IACRA/iacra). `appId` from params; if no
fixture → info Alert with IACRA link. Else renders `ComplianceDashboard evidence`.

---

## AssemblyLines

### AssemblyLinesIndex.tsx (327 LOC) — route `/assembly-lines`
Landing page listing all 11 lines with client-side aggregate counts.
State: `applications`, `pendingGates`, `loading`, `error`. Effect (:91-127):
GOTCHA (P5-AUDIT-021): `fetchApplications({..., per_page:100})` (cap is 100; 200
was 422) + `fetchPendingGates`, each `.catch` to empty. `computeLineAggregates`
(:59-80, exported): `appsInLine` (current_line match), `pendingGates` (gate_type in
line's gates), `completed` (heuristic — apps whose current_line index > this line's
index in `ASSEMBLY_LINES` order). `rows` (:129-142) maps each line to
`{line, status, agg}`; status "active" for `ACTIVE_LINE_NAMES` {Discovery,
Rationalization, Architecture, Data, Validation} else "stubbed". Render: grid of
line cards (Link `/assembly-lines/{id}`, colored left-border, Active/Stubbed badge,
truncated description, Apps/Pending Gates/Completed stats).

### AssemblyLineDashboard.tsx (895 LOC) — route `/assembly-lines/:lineId`
Template for any of the 10/11 lines. `config = findLineConfig(lineId)`,
`liveConfig = findLiveConfig(lineId)`, `stubData = getLineStubData(lineId)`.
`isContinuous = liveConfig?.continuous`.
State (:95-117): applications, pendingGates, modelUsage, lineStatus
`{apps_in_progress/completed/blocked}`, lineThroughput `{apps_per_week,
avg_duration_hours}`, loading, plus governance (`govLatestHealth`, `govDriftAlerts`,
`govPatterns`).
Effect 1 (:122-180): `Promise.all` (each `.catch` to empty shape) of
`fetchApplications({per_page:100, portfolio_id?})`, `fetchPendingGates`,
`fetchModelUsage`, `fetchLineStatus(config.name, portfolioId)`,
`fetchLineThroughput(config.name, portfolioId, 30)`.
Effect 2 (:186-219): ONLY for continuous lines — `fetchGovernanceLatestHealthCheck`,
`fetchGovernanceDriftAlerts({acknowledged:false, per_page:20})`,
`fetchGovernancePatterns`; resets to empty when navigating away.
Memos: `lineApps` (current_line===config.name); `lineGates` (:228-234 — pendingGates
where `getGateAssemblyLine(gate_type)===config.name`); `appById`; `pendingGateRows`
(:243-260 — maps to `{gate: getGateName, app, reviewer, waitingHours: hoursAgo(
sla_deadline), risk: tierFromApp}`); `lineModels`.
Render (:296-894): `!config`→error Alert. KPIs differ for continuous (Health Index/
Open Drift Alerts/Patterns Catalogued/Pattern Reuse) vs gate-driven (Apps in Line/
Completed/Blocked/Avg Cycle Time = avg_duration_hours/24). Model usage table
(liveApiWired). Kanban board (all apps in first step column — GOTCHA: current_step
not exposed to dashboard, so every app aggregates into step 0). `LineSpotlight`.
Governance Signals dl (continuous) or Pending Gate Reviews list (gate-driven, overdue
if waitingHours>24). Agent Activity feed. Throughput ComposedChart + apps table or
Recent Drift Alerts (continuous).
Helpers: `hoursAgo`, `tierFromApp` (risk_tier 1/2/3→tier1/2/3, default tier3).

### LineAnatomyPage.tsx (70 LOC) — route `/assembly-lines/:lineId/anatomy`
`lineId` from params; renders canonical anatomy for the line (thin wrapper).

### LineSpotlight.tsx (728 LOC)
Presentational component (props `{spotlight, accent}`) rendered inside
AssemblyLineDashboard. Multiple internal chart cards each using `useChartTheme`;
payloads intentionally empty in current build (data comes from dedicated panels).

---

## MyTasks

### MyTasks.tsx (541 LOC) — route `/me/tasks`
Lists human-paired-agent tasks. `portfolioId = activePortfolio?.id`.
State (:124-132): `tasks: MyTaskSummary[]`, `loading`, `error`, `filters {scope:
all|claimable|mine, mode: all|ActorKind, search}`, `acceptingId`.
`callerId` (:137): `readCallerSubFromToken()` (:530-541 — decodes JWT `sub` claim
from `localStorage["olympus:auth:token"]`; null for opaque tokens).
Effect (:139-179): guard `!portfolioId`→empty; `fetchMyTasks({include_claimable:true,
portfolio_id, limit:200})`. GOTCHA: always fetches claimable so the UI toggle filters
client-side rather than re-fetching.
`applyFilters(tasks, filters, callerId)` (:78-114): scope claimable/mine
(`isClaimable`=human_user_id==null; mine falls back to "anything claimed" when
callerId null), mode, and free-text over task_type/skill_id/task_id/application_id/
wave_id/status/input_artifact_refs. `counts` (:186-198) by mode.
`handleAccept(taskId)` (:200-219): `acceptTask` → validation_errors toast or
navigate `/me/tasks/{taskId}`.
Render: h1 + mode count tiles (`CountTile`, ActorKindBadge labels), filter fieldset
(scope/mode/search), task table (Skill/Task Link, Mode `ActorKindBadge`, Status,
Dispatched, Inputs count, Owner [Unclaimed/user], Actions — Accept button when
claimable & actor_kind !== olympus_agent + Open link).

### MyTaskDetail.tsx (850 LOC) — route `/me/tasks/:taskId`
Per-task tabbed detail (Overview/Inputs/Return payload/Transcript/Feedback/Audit).
State (:129-137): `task: MyTaskSummary|null`, `narrative: TaskAuditNarrative|null`,
loading, error, `activeTab`, `form: ReturnFormState` (:62-91), submitting, accepting,
`validationErrors`.
`load` (:139-164): `Promise.all([fetchMyTasks({include_claimable:true, limit:200}),
fetchTaskAuditNarrative(taskId)])`; finds task by id (may be absent after completed —
narrative still renders).
`handleAccept` (:172-188): `acceptTask`. `handleSubmit(opts?)` (:190-238): builds
payload — `onlyTranscript` requires a local-agent session (status needs_help),
`onlyFeedback` requires text (needs_help), else `buildReturnRequest(form)`
(:114-124: status, result_artifact_refs [splitRefs], implementation_notes_ref,
gate_evidence_refs, local_agent_session [`buildLocalAgentSession`], feedback_text).
`submitTaskReturn(taskId, payload)` → validation_errors panel or toast.
`actorKind` resolved from task else narrative else olympus_agent.
Tabs: Overview (dl of skill/type/mode/owner/dispatched/completed/output ref),
Inputs (input_artifact_refs list + expected output), Return payload (status radio
completed/needs_help, result/impl-notes/evidence refs, `LocalAgentFields` when
human_with_agent, feedback when needs_help; submit disabled for olympus_agent),
Transcript (`LocalAgentFields` + register), Feedback (textarea + send), Audit
narrative (actor sentence + dl + session artifacts).
`LocalAgentFields` (:752-850): tool/model/version + transcript/prompt/diff/summary
ref inputs. `splitRefs` splits on `[\n,]+`.

---

## MyBundles

### MyBundles.tsx (485 LOC) — route `/me/bundles`
Pair-facing bundle list. Backed by `../../api/bundlesApi` (`listBundles`,
`claimBundle`, `releaseBundle`).
State (:67-78): `bundles: BundleSummary[]`, loading, error, `filters {status,
scope_kind, application_id, wave_id, mine_only}`, `actingId`, `reloadCounter`.
`callerId` via `readCallerSubFromToken`. Effect (:82-123): `listBundles(filters +
limit:200)`, re-runs on any filter change or reloadCounter.
`handleClaim` (:125-138): `claimBundle` → reloadCounter++. `handleRelease` (:140-156):
confirm → `releaseBundle`.
Render: h1 + filter fieldset (status/scope_kind selects + app/wave text + mine_only
checkbox) + bundle table (Scope `bundleScopeSummary` Link, Status
`BundleStatusBadge`, Claimed by, Expires `relativeTime`, Created, Actions). Actions:
Claim (offered), Submit+Release (claimedByMe && claimed), View.
`BundleStatusBadge` (:439-467, exported): color by `bundleStatusTone` (info/warn/
success/error/neutral).

### BundleDetail.tsx (771 LOC) — route `/bundles/:bundleId`
Full bundle envelope. `getBundle`, `getBundleAudit`, `claimBundle`, `releaseBundle`,
`validateBundle`, `submitBundle` from bundlesApi.
State (:62-78): `bundle: BundleDetailT|null`, `audit: BundleAuditNarrative|null`,
loading, error, acting, `outputRefs: Record<kind,ref>`, `sessionRows:
SessionArtifactRow[]`, `validation: BundleValidationResult|null`, `submissionMode:
form|json`, `jsonOutputs`, `reloadCounter`, `historyExpanded`.
`reload` (:80-102): `Promise.all([getBundle, getBundleAudit.catch(null)])`; seeds
outputRefs from prior submissions. `claimedByMe` = `claimed_by_user_id===callerId`.
`buildSubmitBody` (:117-149): form mode = filter non-empty outputRefs; json mode =
`JSON.parse(jsonOutputs)` (validates object shape); session from non-empty sessionRows.
`handleClaim`/`handleRelease`(confirm)/`handleValidate` (`validateBundle` dry-run)/
`handleSubmit` (`submitBundle`) → reload/navigate.
Render: header (scope summary + status badge + expires + claimed by) + Claim/Release
buttons. Inputs list. Outputs table (Kind/Schema link/Description/Submission). Submit
form (claimedByMe && claimed): mode radio (per-output form / JSON textarea) + Session
artifacts rows (kind select transcript/prompt/diff/summary + ref + optional SHA-256 +
add/remove) + validation result Alert + Validate (dry-run)/Submit buttons. Validation
history `<details>`. Audit narrative (actor_sentence + session artifacts). `ViolationList`
(:738-758) renders artifact_kind/field_path/[code]/message.

---

## Admin

### WorkflowHealth.tsx (679 LOC) — route `/admin/workflows`
Operator view of running/failed workflows with restart/fail/escalate.
State (:414-444): `list: WorkflowHealthListResponse|null`, loading, error,
`selectedId`/`appFilter` from `useSearchParams` (`workflow_id`, `app_id`),
`detail: WorkflowHealthDetail|null`, `detailLoading`, `pendingAction`, `actionBusy`.
`loadList` (:446-456): `fetchWorkflowHealthList()`. Effect (:474-480): GOTCHA — polls
`loadList` every `REFRESH_MS` via `setInterval`, cleaned up on unmount. Effect
(:482-488) loads detail (`fetchWorkflowHealthDetail`) when selectedId.
Handlers: `handleRestart` (:490-503): `restartWorkflowHealth(id)` → toast new run.
`handleFail` (:505-518): `failWorkflowHealth(id, reason)` → terminated. `handleEscalate`
(:524-528): GOTCHA — no backend endpoint yet, surfaces a toast only. `filterByApp`
(:41) narrows running+failed lists by `appFilter`. Renders running/failed tables with
per-row detail drawer + confirm for restart/fail. Multiple internal chart-card
sub-components (each `useChartTheme`).

### UserManagement.tsx (431 LOC) — route `/admin/users`
State: `users: UserProfile[]`, `roles: RoleSummary[]`, error, successMessage,
createForm, `savingRoleFor`. Effect (:104): `Promise.all([fetchUsers({per_page:100,
include_inactive:true}), fetchRoles().catch([])])`. Handlers: `createUser({...})`
(:111), `updateUserProfile(id, {roles:[nextRole]})` (:131), `updateUserPassword(id,
{new_password})` (:162). Renders create form + user table with inline role change +
password reset.

### ExtensibilityRegistry.tsx (281 LOC) — route `/admin/extensibility`
Browses the 6 extension-point registries. State: `index: RegistryIndexEntry[]`,
`selected="assembly-lines"`, `entries: RegistryEntryRow[]`, indexError, entriesError.
Effect 1 (:43): `fetchRegistriesIndex()`. Effect 2 (:72): `fetchRegistryEntries(
selected)` when selection changes. Renders a Select of registries + entries table.

### ScoringConfig.tsx (294 LOC) — route `/admin/scoring`
State: `dimensions: DimensionRegistryEntry[]`, `weights: Record<string,number>`,
error. Effect (:60): `fetchDimensionRegistry()`. Save (:90): `updateDimensionRegistry(
weights)` → toast. Renders editable weight inputs + a bar chart.

### ProfileComparison.tsx (295 LOC) — route `/admin/profiles/compare`
State: `profiles: ProfileSummary[]`, `left`, `right`, `data:
ProfileComparisonResponse|null`, error, `filter: all|changed` (default changed).
Effect 1 (:76): local `fetchProfiles()` (:40). Effect 2 (:93): local `fetchCompare(
left, right)` (:45) when both selected. Renders two profile selects + a diff table
filterable to changed rows.

### PortfolioMembers.tsx (239 LOC) — route `/admin/members` (portfolio-scoped)
`usePortfolioContext`. State: `members: PortfolioMembership[]`, error, `newUserId`,
`newRole: RBACRoleValue` (default viewer). Effect (:65): loads members. Handlers:
`addPortfolioMember(portfolioId, {...})` (:79 — requires user id), `removePortfolioMember(
portfolioId, userId)` (:99). Toasts on success/failure.

### SystemStatus.tsx (221 LOC) — route `/admin/system`
State: `health: DetailedHealthResponse|null`. Effect (:63): `fetchDetailedHealth()`
(API + Temporal + DB status). Renders component status cards via `useChartTheme`.

### Configuration.tsx (159 LOC) — route `/admin/config`
Static/informational configuration page (no API); several `useChartTheme` sub-cards.

### Delegation.tsx (169 LOC) — route `/admin/delegation`
Admin bundle oversight. State: `bundles: BundleSummary[]`, error, `acting`. Effect
(:47) lists bundles. `forceReleaseBundle(bundleId, {reason})` (:59) → toast. Reuses
`BundleStatusBadge` from MyBundles.

### SkillRoutingSection.tsx (309 LOC) — component (embedded in Admin)
State: `skills: SkillDetail[]|null`, error, `pending: Record<string,boolean>`. Effect
(:95): `fetchSkills({per_page:100, status:"active"})`. Toggles a skill's model tier
via `updateSkill(skill.skill_id, ...)` with toast (info/success/error).

---

## Analytics (all portfolio-scoped via `usePortfolioContext`, `useChartTheme`)

### CostDashboard.tsx (218 LOC) — route `/analytics/cost`
State: `rows: ModelUsageRow[]|null`, error. Effect (:54): `fetchModelUsage(
activePortfolioId)`. Renders cost charts/tables from model-usage rows.

### ModelUsage.tsx (336 LOC) — route `/analytics/models`
State: `rows: ModelUsageRow[]|null`, `providers: ProviderUsageRow[]`,
`providerFilter`, error. Effect (:53): `fetchModelUsage(activePortfolio?.id)`.
Provider filter + per-model tables/charts.

### ReadinessScores.tsx (203 LOC) — route `/analytics/readiness`
State: `scores: ReadinessScoreEntry[]`. Effect (:54): `fetchReadinessScores(
{portfolioId})` — GOTCHA: watches `activePortfolioId` so switching portfolio reloads.
Renders per-app readiness bars/charts.

### CompoundGrowth.tsx (176 LOC) — route `/analytics/growth`
State: `data: CompoundGrowthResponse|null`, `gateDetail: GatePassRateResponse|null`.
Effect (:28): `Promise.all([fetchCompoundGrowth(activePortfolioId),
fetchGatePassRate(activePortfolioId)])`. Renders compounding-skill growth chart +
gate pass rate detail.

### FactoryVelocity.tsx (136 LOC) — route `/analytics/velocity`
State: `waves: WaveListItem[]`, `apps: ApplicationDetail[]`. Effect (:32):
`Promise.all([fetchWaves(activePortfolioId), fetchApplications({portfolio_id?})])`.
Derives velocity metrics client-side from waves + apps.

---

## Cross-page conventions (behavioral parity notes)
- Every portfolio-scoped page early-returns a loading spinner while
  `portfolioLoading`, and re-fetches keyed on `activePortfolio?.id`.
- Secondary/decorative fetches are wrapped in their own try/catch or
  `Promise.allSettled` so a single 404/500 never blanks the page.
- All list-endpoint pagination caps at `per_page: 100` server-side; pages that need
  everything either loop pages (SkillCatalog/SkillEvaluation) or accept 100 as
  sufficient for demo portfolios.
- `readCallerSubFromToken()` (duplicated verbatim in MyTasks/MyBundles/BundleDetail)
  decodes the JWT `sub` from `localStorage["olympus:auth:token"]`; opaque tokens
  degrade to null.
- Wave/task/bundle mutating actions emit `sonner` toasts and reload via a
  monotonically-incrementing `reloadKey`/`reloadCounter` state rather than optimistic
  updates.
