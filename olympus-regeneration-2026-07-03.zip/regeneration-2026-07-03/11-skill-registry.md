# 11. Skill Registry — Atomic Index

> Regeneration spec for Olympus at `/Users/pnunna/Documents/GitHub/olympus`. Source of truth: `cross-cutting/skills/registry.yaml` (3037 lines; top-level keys `skills`, `dispatch_aliases`). Skill prompt bodies live in a separate SDK env and are intentionally NOT reproduced here — this is an INDEX only.

## 11.0 How this index was derived

- The machine-readable registry is `cross-cutting/skills/registry.yaml`. Its `skills:` list has **173** entries (`registry.yaml:1` root key; first entry `regulatory-knowledge-ingestion` at `:58`, last entry `decomposition-agent` at `:3016`). `dispatch_aliases:` is an empty list (`registry.yaml` top-level key, value `[]`).
- Per-skill fields carried in the registry entry: `id`, `version`, `category`, `enrichment`, `line`, `step`, `is_orchestration`, `variants`, `profile_overrides`, `depends_on`, plus optional `profile`, `status`, `delegatable`, `also_consumed_by`, `benchmark_tags`, `currency`, `failure_classes`, `supported_stacks`, `validation_commands`.
- `declared inputs`, `output_schemas`, and `agent_role` (the `agent:` frontmatter) are NOT in the registry — they live in each skill's `SKILL.md` YAML frontmatter under `cross-cutting/skills/<id>/SKILL.md` (or `profiles/<profile>/skills/<id>/SKILL.md` for the 9 profile skills). This index JOINs registry + `SKILL.md` frontmatter.
- **GOTCHA (inputs are prose, not machine-readable):** only ~10 of 173 `SKILL.md` files declare inputs in a parseable ``**\`token\`**`` form under a `## Inputs` heading; the rest describe inputs in free prose. This index lists parsed input tokens where available and marks the rest `(prose)`. Do NOT treat a blank inputs cell as "no inputs."
- **GOTCHA (agent_role source):** `agent:` in `SKILL.md` frontmatter is either `opus`, `sonnet`, or absent. Distribution across the 173: sonnet=107, opus=61, absent/None=5. Absent means no frontmatter `agent:` key (5 profile skills whose `SKILL.md` omit it or use a different schema).
- **GOTCHA (9 profile skills relocated):** these registry ids have NO directory under `cross-cutting/skills/`; they live under `profiles/faa/skills/<id>/`: `faa-code-standards`, `faa-style-greenfield`, `faa-style-brownfield`, `pilot-certification-domain-modeler`, `faa-form-schema-generator`, `aerospace-medical-certification-mapper`, `form-8710-validator`, `medxpress-confirmation-binder`, `ame-decision-workflow-scaffolder`. All carry `profile: faa` in the registry entry.

## 11.1 Exact count per category (total = 173)

| Category | Count |
|---|---:|
| Business Process & Automation | 31 |
| Code Scaffolding & Templates | 31 |
| Product Verification | 20 |
| Data Fetching & Analysis | 19 |
| Legacy Analysis | 17 |
| Library & API Reference | 12 |
| Runbooks & Operations | 11 |
| Code Quality & Review | 6 |
| Infrastructure Operations | 6 |
| Cross-Cutting | 4 |
| Meta-Tooling | 4 |
| CI/CD & Deployment | 3 |
| Architecture & Design | 2 |
| Identity & Auth | 2 |
| Analysis & Assessment | 1 |
| Compliance & Evidence | 1 |
| Data Modeling & Schema Design | 1 |
| Documentation | 1 |
| Synthesis | 1 |
| **TOTAL** | **173** |

**Verified count = 173**, matching the CLAUDE.md prose ("173 skills"). Parsed by `yaml.safe_load(registry.yaml)["skills"]` → `len == 173`.

## 11.2 Output-schema resolution (GOTCHA flags)

40 of 173 skills declare `output_schemas` in `SKILL.md` frontmatter (each entry is `{path: <artifact-filename>, schema: <schemas/... path>}`). **All declared `schema:` paths RESOLVE on disk under `schemas/`** — 0 dangling references. (Verified by `os.path.exists` against each declared path from repo root.) The remaining 133 skills declare no `output_schemas` frontmatter and produce prose/markdown or file-tree artifacts governed by their `SKILL.md` Outputs prose, not a JSON schema.

## 11.3 Full skill table (all 173, sorted by id)

Columns: **id** (registry.yaml line anchor) · **ver** = version · **cat** = category · **agent** = `agent:` frontmatter role · **inputs** (parsed from `## Inputs`, else `(prose)`) · **output_schemas** (artifact → resolved schema path) · **depends_on** (from registry) · **line/step** (dispatch wiring).

| id (`registry.yaml:LINE`) | ver | category | agent | inputs | output_schemas | depends_on | line → step |
|---|---|---|---|---|---|---|---|
| `acceptable-divergences` (`:1859`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | `parity-verifier` | Validation → Stream 1 — Functional Parity |
| `accessibility-checker` (`:210`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | — | Discovery → Step 3 — Pass 4 (UX & Accessibility) |
| `accessibility-reviewer` (`:921`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | `accessibility-review.json` → `schemas/architecture/accessibility-review.schema.json` | `design-system` | Architecture → Step 8 — Accessibility Review |
| `adoption-analytics` (`:2028`) | 1.0.0 | Data Fetching & Analysis | sonnet | _(prose)_ | — | `user-adoption-coordinator` | Deployment → Step 4 — Adoption Verification |
| `adversarial-review` (`:1563`) | 1.0.0 | Code Quality & Review | sonnet | _(prose)_ | — | `tdd-generation` | Modernization → Step 3 — Generate (review) |
| `aerospace-medical-certification-mapper` (`:2931`) _[profile:faa]_ | 0.1.0 | Legacy Analysis | opus | _(prose)_ | — | `legacy-business-rule-extractor` | Modernization → Step 2 — Design (FAA medical class definitions) |
| `ai-ml-integration` (`:860`) | 1.1.0 | Library & API Reference | opus | _(prose)_ | `ai-ml-integration.json` → `schemas/architecture/ai-ml-integration.schema.json` | `target-state-mapper`, `migration-strategy-advisor` | Architecture → Step 9 — AI/ML Integration |
| `ame-decision-workflow-scaffolder` (`:2980`) _[profile:faa]_ | 0.1.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `aerospace-medical-certification-mapper`, `temporal-workflow-scaffolder` | Modernization → Step 3 — Generate (AME decision workflow) |
| `analyze-portfolio-redundancy` (`:694`) | 1.3.0 | Data Fetching & Analysis | sonnet | `input-artifacts/_dispatch-context.json` | `portfolio-redundancy-matrix.json` → `schemas/rationalization/rationalization-clustering-plan.schema.json` | `redundancy-analyzer`, `portfolio-integration-mapper` | Rationalization → Portfolio Redundancy Synthesis (pre-disposition) |
| `api-contract-validator` (`:834`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | `api-contract-compliance-report.json` → `schemas/architecture/integration-arch.schema.json` | `migration-strategy-advisor` | Architecture → Step 4 — Integration Architecture |
| `api-specification` (`:1377`) | 1.0.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `module-design` | Modernization → Step 2 — Design |
| `architecture-traceability-validator` (`:1083`) | 1.0.0 | Code Quality & Review | sonnet | _(prose)_ | — | `blueprint-assembly` | Architecture → Step 10d — Traceability Validation (pre-G-02) |
| `assess-user-impact` (`:593`) | 1.0.0 | Data Fetching & Analysis | sonnet | _(prose)_ | `user-impact-analysis.json` → `schemas/rationalization/user-impact-analysis.schema.json` | `disposition-recommender`, `ux-accessibility-assessor` | Rationalization → Step 7 — User Impact Analysis |
| `audit-immutability-trigger-generator` (`:1760`) | 0.1.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `data-modeling` | Modernization → Step 3 — Generate (audit append-only) |
| `batch-design` (`:1390`) | 1.0.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `batch-extraction` | Modernization → Step 2 — Design (batch archetype) |
| `batch-extraction` (`:1239`) | 1.0.0 | Code Scaffolding & Templates | opus | _(prose)_ | — | — | Modernization → Step 1 — Extract (batch archetype) |
| `batch-generation` (`:1537`) | 1.0.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `batch-design` | Modernization → Step 3 — Generate (batch archetype) |
| `blueprint-assembly` (`:936`) | 1.0.0 | Business Process & Automation | opus | _(prose)_ | `architecture-blueprint.json` → `schemas/architecture/architecture-blueprint.schema.json` | `target-state-mapper`, `migration-strategy-advisor`, `ea-compliance`, `api-contract-validator`, `event-contract`, `security-posture-analyzer`, `cato-compliance`, `design-system`, `accessibility-reviewer`, `ai-ml-integration`, `target-architecture-blueprint`, `resilience-designer`, `deployment-topology` | Architecture → Step 10 — Blueprint Assembly |
| `business-rule-reconciliation` (`:1279`) | 1.0.0 | Legacy Analysis | opus | `business-rules.yaml`, `modern-requirements.yaml` | — | `extraction`, `legacy-business-rule-extractor`, `requirement-aggregation` | Modernization → Step 1 — Extract (rule reconciliation) |
| `capability-consolidation-advisor` (`:745`) | 1.0.0 | Business Process & Automation | opus | _(prose)_ | `capability-consolidation-plan.json` → `schemas/rationalization/capability-consolidation-plan.schema.json` | `portfolio-integration-mapper`, `disposition-recommender`, `disposition-governance` | Rationalization → Capability Consolidation Advisory (post per-app disposition) |
| `capability-extraction` (`:222`) | 1.0.0 | Legacy Analysis | sonnet | _(prose)_ | `capability-catalog.json` → `schemas/discovery/capability-catalog.schema.json` | `catalog-application`, `legacy-architecture-mapper`, `data-domain-patterns` | Discovery → Step 3 — Pass 6 (Capability + System Grain) |
| `catalog-application` (`:76`) | 1.0.0 | Data Fetching & Analysis | sonnet | _(prose)_ | `application-catalog-entry.json` → `schemas/discovery/catalog.schema.json` | — | Discovery → Step 1 — Catalog |
| `cato-compliance` (`:890`) | 2.0.0 | Library & API Reference | sonnet | _(prose)_ | `security-arch.json` → `schemas/architecture/security-arch.schema.json` | — | Architecture → Step 6 — Security Architecture |
| `cato-evidence-validator` (`:1871`) | 2.0.0 | Library & API Reference | sonnet | _(prose)_ | — | `cato-compliance` | Validation → Stream 2 — Security & Compliance |
| `change-conflict-resolver` (`:2399`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | — | Sustainment → Activity 2 — Coordination |
| `classify-application` (`:606`) | 1.0.0 | Business Process & Automation | opus | _(prose)_ | `classification.json` → `schemas/rationalization/classification.schema.json` | — | Rationalization → Step 8 — Classification & Risk Tiering |
| `classify-complexity` (`:658`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | `catalog-application`, `legacy-architecture-mapper`, `portfolio-integration-mapper` | Rationalization → Classification & Risk Tiering (sibling of classify-application) |
| `cloud-cost-estimator` (`:1043`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | `cost-estimate.json` → `schemas/architecture/cost-estimate.schema.json` | `blueprint-assembly` | Architecture → Step 10b — Cloud Cost Estimate |
| `cocomo-cosmic-analysis` (`:249`) | 1.0.0 | Data Fetching & Analysis | _(none)_ | _(prose)_ | — | — | Rationalization → On-demand — cost & effort estimation |
| `code-generation` (`:1478`) | 1.1.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `tdd-generation`, `module-design`, `api-specification` | Modernization → Step 3 — Generate (implementation — Ralph Loop step 2) |
| `code-synthesis` (`:1549`) | 1.0.1 | Code Scaffolding & Templates | opus | _(prose)_ | — | `tdd-generation`, `module-design`, `api-specification` | Modernization → Step 3 — Generate (cross-context merge) |
| `compare-ux-overlap` (`:549`) | 1.1.0 | Data Fetching & Analysis | opus | _(prose)_ | `ux-overlap-matrix.json` → `schemas/rationalization/ux-overlap-matrix.schema.json` | `ux-accessibility-assessor` | Rationalization → Step 1c — UX Overlap Analysis |
| `compliance-citation-mapper` (`:442`) | 1.0.0 | Legacy Analysis | sonnet | _(prose)_ | — | `catalog-application` | Discovery → Step 3 — Regulatory citation scan (pre-Rationalization) |
| `component-configuration` (`:2228`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | `workflow-mapping` | Disposition Execution → Replatform — Component Configuration |
| `consumer-migration-planning` (`:2111`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | `dependency-mapper` | Disposition Execution → Pre-cutover — Consumer Migration Planning |
| `cost-anomaly-investigation` (`:2410`) | 1.0.0 | Runbooks & Operations | sonnet | _(prose)_ | — | — | Sustainment → Activity 3 — AIOps |
| `cross-app-business-rule-analyzer` (`:725`) | 1.0.0 | Data Fetching & Analysis | opus | _(prose)_ | `business-rule-redundancy.json` → `schemas/rationalization/business-rule-redundancy.schema.json` | `legacy-business-rule-extractor` | Rationalization → Cross-App Business Rule Synthesis (pre-disposition) |
| `cross-validation` (`:1250`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | `extraction` | Modernization → Step 1 — Extract (validation pass) |
| `data-archival-planning` (`:2100`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | — | Disposition Execution → Pre-cutover — Data Archival Planning |
| `data-domain-patterns` (`:1107`) | 1.1.0 | Code Scaffolding & Templates | opus | `context.target_plan_entry` | `data-domains.json` → `schemas/data/data-domains.schema.json` | — | Data → Step 1 — Data Domain Discovery |
| `data-mesh-architecture` (`:1196`) | 1.1.0 | Library & API Reference | opus | _(prose)_ | — | — | Data → Reference-only (no dispatch) |
| `data-migration-planner` (`:1130`) | 1.0.0 | Code Scaffolding & Templates | opus | `context.target_plan_entry` | `data-migration-plan.json` → `schemas/data/data-migration-plan.schema.json` | `decomposition-patterns` | Data → Step 4 — Migration Planning |
| `data-migration-planning` (`:2252`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | — | Disposition Execution → Replace/Replatform — Data Migration Planning |
| `data-modeling` (`:1172`) | 2.0.0 | Synthesis | opus | `context.target_plan_entry` | `data-architecture.json` → `schemas/data/data-architecture.schema.json` | `data-domain-patterns`, `decomposition-patterns`, `data-migration-planner`, `data-product-specification` | Data → Step 6 — Data Architecture Synthesis |
| `data-product-specification` (`:1142`) | 1.2.0 | Code Scaffolding & Templates | opus | `context.target_plan_entry` | `data-product-design.json` → `schemas/data/data-product-design.schema.json` | `data-domain-patterns` | Data → Step 5 — Data Product Design |
| `data-reconciliation-planning` (`:2169`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | `target-selection` | Disposition Execution → Consolidate — Data Reconciliation Planning |
| `decomposition-agent` (`:3016`) | 1.0.0 | Architecture & Design | opus | _(prose)_ | `blueprint-hierarchy.json` → `schemas/build/blueprint-hierarchy.schema.json` | — | Cross-Cutting → Feature/blueprint decomposition (confirmed IntentRecord -> BlueprintHierarchy) |
| `decomposition-patterns` (`:1118`) | 1.1.0 | Legacy Analysis | opus | `context.target_plan_entry` | `decomposition-strategy.json` → `schemas/data/decomposition-strategy.schema.json` | — | Data → Steps 2–3 — Shared-DB Analysis + Decomposition Strategy |
| `decomposition-skill-writer` (`:2566`) | 1.0.0 | Meta-Tooling | opus | _(prose)_ | — | — | Governance → Activity 5 — Skill Lifecycle |
| `dependency-mapper` (`:180`) | 1.1.0 | Data Fetching & Analysis | opus | _(prose)_ | — | — | Discovery → Step 4 — Dependency Mapping |
| `deploy-modernized-app` (`:1993`) | 1.0.0 | CI/CD & Deployment | sonnet | _(prose)_ | — | — | Deployment → Step 1 — Deployment Orchestration |
| `deployment-topology` (`:1001`) | 1.0.0 | Infrastructure Operations | sonnet | _(prose)_ | — | `migration-strategy-advisor`, `target-state-mapper` | Architecture → Step 2 — Target Architecture Strategy |
| `design-system` (`:905`) | 2.1.0 | Library & API Reference | sonnet | _(prose)_ | `design-system.json` → `schemas/architecture/design-system.schema.json` | — | Architecture → Step 7 — Design System Mapping |
| `discovery-patterns` (`:131`) | 1.0.0 | Legacy Analysis | sonnet | _(prose)_ | — | `catalog-application`, `legacy-architecture-mapper` | Discovery → Step 3 — Pass 1 (Application & Data Mapping — tech-stack patterns) |
| `discovery-synthesizer` (`:309`) | 1.2.0 | Data Fetching & Analysis | opus | _(prose)_ | `discovery-synthesis.json` → `schemas/discovery/discovery-synthesis.schema.json` | `catalog-application`, `legacy-architecture-mapper`, `legacy-business-rule-extractor`, `quality-risk-assessor`, `ux-accessibility-assessor`, `data-domain-patterns`, `decomposition-patterns`, `capability-extraction` | Discovery → Step 5 — Synthesis |
| `disposition-governance` (`:581`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | `disposition-governance.json` → `schemas/rationalization/disposition-governance.schema.json` | `disposition-recommender` | Rationalization → Step 6 — Disposition Governance |
| `disposition-recommender` (`:567`) | 1.0.0 | Business Process & Automation | opus | _(prose)_ | `disposition-recommendation.json` → `schemas/rationalization/disposition-recommendation.schema.json` | `legacy-business-rule-extractor`, `redundancy-analyzer`, `portfolio-scorer` | Rationalization → Step 5 — Disposition Recommendation |
| `documentation-remediation` (`:2307`) | 1.0.0 | Runbooks & Operations | sonnet | _(prose)_ | — | — | Disposition Execution → Retain — Documentation |
| `drift-detection` (`:2469`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | `drift-detection-architecture`, `drift-detection-compliance`, `drift-detection-performance`, `drift-detection-cost`, `drift-detection-adoption` | Governance → Activity 2 — Drift Detection |
| `drift-detection-adoption` (`:2532`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | `adoption-analytics` | Governance → Activity 2 — Drift Detection |
| `drift-detection-architecture` (`:2485`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | — | Governance → Activity 2 — Drift Detection |
| `drift-detection-compliance` (`:2496`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | `accessibility-checker` | Governance → Activity 2 — Drift Detection |
| `drift-detection-cost` (`:2520`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | `tco-analyzer` | Governance → Activity 2 — Drift Detection |
| `drift-detection-performance` (`:2509`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | — | Governance → Activity 2 — Drift Detection |
| `ea-compliance` (`:818`) | 2.0.0 | Library & API Reference | sonnet | _(prose)_ | `ea-compliance-report.json` → `schemas/architecture/ea-compliance.schema.json` | `migration-strategy-advisor` | Architecture → Step 3 — EA Compliance Verification |
| `enhancement-planning` (`:2181`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | `feature-gap-analysis` | Disposition Execution → Consolidate — Enhancement Planning |
| `environment-cleanup` (`:2069`) | 1.0.0 | Infrastructure Operations | sonnet | _(prose)_ | — | `legacy-decommission` | Deployment → Step 5 — Legacy Decommission |
| `escalation-handler` (`:1594`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | — | Modernization → Step 3 — Generate (Ralph Loop escalation) |
| `event-contract` (`:847`) | 1.0.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `migration-strategy-advisor` | Architecture → Step 4 — Integration Architecture |
| `extraction` (`:1212`) | 1.1.0 | Code Scaffolding & Templates | opus | _(prose)_ | — | `legacy-business-rule-extractor` | Modernization → Step 1 — Extract |
| `faa-code-standards` (`:2854`) _[profile:faa]_ | 1.0.0 | Library & API Reference | _(none)_ | _(prose)_ | — | — | Modernization → Step 3 — Generate |
| `faa-form-schema-generator` (`:2915`) _[profile:faa]_ | 0.1.0 | Library & API Reference | sonnet | _(prose)_ | — | — | Modernization → Step 2 — Design (FAA form single-source schemas) |
| `faa-style-brownfield` (`:2878`) _[profile:faa]_ | 1.0.0 | Library & API Reference | _(none)_ | _(prose)_ | — | — | Sustainment → Activity 1 — O&M |
| `faa-style-greenfield` (`:2866`) _[profile:faa]_ | 1.0.0 | Library & API Reference | _(none)_ | _(prose)_ | — | — | Modernization → Step 3 — Generate |
| `factory-capacity-manager` (`:2447`) | 1.0.0 | Infrastructure Operations | opus | _(prose)_ | — | — | Governance → Activity 6 — Capacity |
| `factory-health-check` (`:2436`) | 1.0.0 | Infrastructure Operations | sonnet | _(prose)_ | — | — | Governance → Activity 6 — Factory Analytics |
| `feature-gap-analysis` (`:2157`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | `target-selection` | Disposition Execution → Consolidate — Feature Gap Analysis |
| `form-8710-validator` (`:2947`) _[profile:faa]_ | 0.1.0 | Library & API Reference | sonnet | _(prose)_ | — | — | Modernization → Step 2 — Design (FAA Form 8710 validators) |
| `form-rules-engine-scaffolder` (`:1655`) | 0.1.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `legacy-business-rule-extractor` | Modernization → Step 2 — Design (form conditional rules) |
| `formal-test-plan-generator` (`:1967`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | `parity-verifier`, `traceability-checker`, `blueprint-assembly` | Validation → Stream 1 — Functional Parity (formal test plan, T1/T2 mandatory pre-G-V1) |
| `gate-pre-review` (`:2619`) | 1.1.0 | Cross-Cutting | sonnet | _(prose)_ | — | — | Cross-Cutting → All 15 gates |
| `gate-review-package` (`:1605`) | 1.1.0 | Business Process & Automation | sonnet | _(prose)_ | — | — | Modernization → All gates |
| `gfi-pp-scenarios` (`:1420`) | 1.0.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `target-schema-ddl` | Modernization → Factory Configuration — test-data provisioning (Private Pilot scenario fan-out) |
| `gherkin-scenario-generator` (`:2715`) | 1.0.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `extraction`, `validation-rule-template`, `workflow-state-machine-template` | Modernization → Step 3 — Generate |
| `iac-scaffolding-generator` (`:2824`) | 1.0.0 | Code Scaffolding & Templates | sonnet | `iac_target` | — | `phase2-constraint-loader`, `api-specification`, `event-contract` | Modernization → Step 3 — Generate (infrastructure) |
| `identity-landscape-analyzer` (`:424`) | 1.0.0 | Legacy Analysis | opus | _(prose)_ | — | `catalog-application` | Discovery → Step 3 — Portfolio identity pass (NIST 800-63 inventory) |
| `incident-response` (`:2363`) | 1.0.0 | Runbooks & Operations | sonnet | _(prose)_ | — | — | Sustainment → Activity 1 — O&M |
| `integration-specification` (`:2204`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | `vendor-evaluation` | Disposition Execution → Replace — Integration Specification |
| `jwt-claim-mapper` (`:1638`) | 0.1.0 | Identity & Auth | sonnet | _(prose)_ | — | `oidc-server-integration`, `data-modeling` | Modernization → Step 2 — Design (auth principal mapping) |
| `legacy-architecture-mapper` (`:120`) | 1.0.0 | Legacy Analysis | opus | _(prose)_ | — | — | Discovery → Step 3 — Pass 1 (Application & Data Mapping) |
| `legacy-business-rule-extractor` (`:169`) | 1.1.0 | Legacy Analysis | opus | _(prose)_ | `business-logic.json` → `schemas/discovery/business-logic.schema.json` | — | Discovery → Step 3 — Pass 2 (Business Logic) |
| `legacy-data-flow-tracer` (`:384`) | 1.0.0 | Legacy Analysis | opus | _(prose)_ | — | `legacy-architecture-mapper`, `legacy-database-archaeologist` | Discovery → Step 3 — Pass 1 (data-flow tracing) |
| `legacy-database-archaeologist` (`:350`) | 1.0.0 | Legacy Analysis | opus | _(prose)_ | — | `catalog-application`, `legacy-architecture-mapper` | Discovery → Step 3 — Pass 1 (database archaeology) |
| `legacy-decommission` (`:2057`) | 1.0.0 | Runbooks & Operations | sonnet | _(prose)_ | — | — | Deployment → Step 5 — Legacy Decommission |
| `legacy-language-reader` (`:334`) | 1.0.0 | Legacy Analysis | sonnet | _(prose)_ | — | `catalog-application` | Discovery → Step 3 — Pass 1 (language detection + reader dispatch) |
| `license-reclamation` (`:2274`) | 1.0.0 | Runbooks & Operations | sonnet | _(prose)_ | — | — | Disposition Execution → Retire — License Reclamation |
| `medxpress-confirmation-binder` (`:2963`) _[profile:faa]_ | 0.1.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `aerospace-medical-certification-mapper` | Modernization → Step 3 — Generate (MedXPress integration) |
| `migration-strategy-advisor` (`:803`) | 1.1.0 | Cross-Cutting | opus | _(prose)_ | `cloud-pattern.json` → `schemas/architecture/cloud-pattern.schema.json` | `target-state-mapper` | Architecture → Step 2 — Target Architecture Strategy |
| `model-benchmark` (`:2544`) | 1.0.0 | Meta-Tooling | opus | _(prose)_ | — | — | Governance → Activity 6 — Factory Analytics |
| `module-design` (`:1337`) | 1.1.0 | Code Scaffolding & Templates | opus | _(prose)_ | — | `extraction` | Modernization → Step 2 — Design |
| `monitoring-bootstrap` (`:2334`) | 1.0.0 | Runbooks & Operations | sonnet | _(prose)_ | — | — | Disposition Execution → Retain — Observability |
| `oidc-server-integration` (`:1779`) | 0.1.0 | Identity & Auth | sonnet | _(prose)_ | — | `identity-landscape-analyzer` | Modernization → Step 3 — Generate (OIDC server config) |
| `olympus-collaboration` (`:2636`) | 1.0.0 | Cross-Cutting | _(none)_ | _(prose)_ | — | — | Cross-Cutting → Human-paired-agent dispatch + return |
| `oscal-fragment-emitter` (`:1798`) | 0.1.0 | Compliance & Evidence | sonnet | _(prose)_ | — | — | Modernization → Step 3 — Generate (cATO evidence) |
| `outbox-pattern-scaffolder` (`:1726`) | 0.1.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `event-contract`, `data-modeling` | Modernization → Step 3 — Generate (transactional outbox) |
| `parallel-run-monitor` (`:2017`) | 1.0.0 | CI/CD & Deployment | sonnet | _(prose)_ | — | — | Deployment → Step 3 — Parallel Run |
| `parity-verifier` (`:1848`) | 1.1.0 | Product Verification | sonnet | _(prose)_ | — | — | Validation → Stream 1 — Functional Parity |
| `patch-assessment` (`:2375`) | 1.0.0 | Runbooks & Operations | sonnet | _(prose)_ | — | — | Sustainment → Activity 1 — O&M |
| `phase2-constraint-loader` (`:2661`) | 1.0.0 | Architecture & Design | sonnet | _(prose)_ | — | — | Architecture → Step 1 — Constraint Definition |
| `pilot-certification-domain-modeler` (`:2896`) _[profile:faa]_ | 0.1.0 | Data Modeling & Schema Design | opus | _(prose)_ | — | `data-modeling` | Modernization → Step 2 — Design (FAA pilot cert schema) |
| `platform-selection` (`:2135`) | 1.0.0 | Business Process & Automation | opus | _(prose)_ | — | — | Disposition Execution → Replatform — Platform Selection |
| `portfolio-health-check` (`:2425`) | 1.0.0 | Infrastructure Operations | sonnet | _(prose)_ | — | — | Governance → Activity 1 — Health |
| `portfolio-integration-mapper` (`:675`) | 1.0.0 | Data Fetching & Analysis | sonnet | _(prose)_ | `integration-graph.json` → `schemas/rationalization/integration-graph.schema.json` | `catalog-application`, `dependency-mapper`, `legacy-architecture-mapper` | Rationalization → Portfolio Integration Mapping (pre-disposition) |
| `portfolio-manifest-generator` (`:764`) | 1.0.0 | Data Fetching & Analysis | opus | _(prose)_ | — | `wave-outcome-synthesizer`, `disposition-recommender`, `catalog-application` | Rationalization → Portfolio Manifest (final wave close-out) |
| `portfolio-scorer` (`:537`) | 1.0.0 | Data Fetching & Analysis | opus | _(prose)_ | `portfolio-score.json` → `schemas/rationalization/portfolio-score.schema.json` | `legacy-business-rule-extractor` | Rationalization → Step 9 — Portfolio Scoring |
| `profile-authoring` (`:2600`) | 1.0.0 | Cross-Cutting | sonnet | _(prose)_ | — | — | Cross-Cutting → Client Onboarding — Profile Authoring |
| `quality-risk-assessor` (`:266`) | 1.2.0 | Legacy Analysis | sonnet | _(prose)_ | `quality-risk.json` → `schemas/discovery/quality-risk.schema.json` | — | Discovery → Step 3 — Pass 3 (Quality & Risk) |
| `redundancy-analyzer` (`:525`) | 1.0.0 | Data Fetching & Analysis | opus | _(prose)_ | `redundancy-matrix.json` → `schemas/rationalization/redundancy-matrix.schema.json`<br>`intra-app-redundancy.json` → `schemas/rationalization/redundancy-matrix.schema.json` | `legacy-business-rule-extractor` | Rationalization → Steps 1a/1b — Cross-App & Intra-App Redundancy |
| `regulatory-knowledge-ingestion` (`:58`) | 1.0.0 | Data Fetching & Analysis | opus | `raw_document`, `profile_id`, `regulation_id`, `authority`, `title`, `current_version`, `applicable_systems`, `relevance`, `update_frequency` | — | — | Discovery → Pre-Discovery — Regulatory Knowledge Ingestion |
| `requirement-aggregation` (`:1262`) | 1.0.0 | Data Fetching & Analysis | opus | _(prose)_ | — | — | Modernization → Step 1 — Extract (modern requirement harvest) |
| `requirements-derivation` (`:2193`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | — | Disposition Execution → Replace — Requirements Derivation |
| `requirements-doc-ingester` (`:87`) | 1.0.0 | Data Fetching & Analysis | opus | _(prose)_ | `requirements-capability.json` → `schemas/build/requirements-capability.schema.json` | `catalog-application` | Discovery → Step 3 — Requirements Discovery (Build mode, doc-driven) |
| `requirements-elicitation` (`:104`) | 1.0.0 | Data Fetching & Analysis | opus | _(prose)_ | `requirements-capability.json` → `schemas/build/requirements-capability.schema.json` | `catalog-application` | Discovery → Step 3 — Requirements Discovery (Build mode, interview-driven) |
| `resilience-designer` (`:1022`) | 1.0.0 | Infrastructure Operations | opus | _(prose)_ | — | `migration-strategy-advisor` | Architecture → Step 4 — Integration Architecture |
| `reverse-engineer-spec` (`:403`) | 1.0.0 | Legacy Analysis | opus | _(prose)_ | — | `legacy-language-reader`, `legacy-business-rule-extractor` | Reverse Engineering → Step 1/2 — Ingest (read-only) + Reconstruct Spec |
| `safety-critical-verifier` (`:1888`) | 2.1.0 | Product Verification | opus | _(prose)_ | — | — | Validation → Stream 4 — Safety Assurance |
| `schema-driven-wizard-generator` (`:1743`) | 0.1.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `xstate-fsm-generator`, `form-rules-engine-scaffolder` | Modernization → Step 3 — Generate (multi-section wizard) |
| `security-anomaly-resolution` (`:1943`) | 1.0.0 | Code Quality & Review | opus | _(prose)_ | — | `security-scan-review`, `security-posture-analyzer`, `cato-compliance` | Validation → Stream 2 — Security & Compliance (anomaly resolution, pre-G-V2) |
| `security-decommission` (`:2263`) | 1.0.0 | Runbooks & Operations | sonnet | _(prose)_ | — | — | Disposition Execution → Retire — Security Decommission |
| `security-posture-analyzer` (`:878`) | 1.0.0 | Library & API Reference | opus | _(prose)_ | — | — | Architecture → Step 6 — Security Architecture |
| `security-posture-review` (`:1575`) | 1.0.0 | Code Quality & Review | sonnet | _(prose)_ | — | `code-synthesis` | Modernization → Step 3 — Generate (security posture) |
| `security-remediation-planning` (`:2293`) | 1.0.0 | Runbooks & Operations | sonnet | _(prose)_ | — | `security-posture-analyzer` | Disposition Execution → Retain — Security |
| `security-scan-review` (`:1925`) | 1.0.0 | Code Quality & Review | sonnet | _(prose)_ | — | — | Validation → Stream 2 — Security & Compliance (scan triage) |
| `sequencer` (`:618`) | 1.1.0 | Business Process & Automation | opus | _(prose)_ | `wave-plan.json` → `schemas/rationalization/wave-plan.schema.json`<br>`wave-plan-validation.json` → `schemas/rationalization/wave-plan-validation.schema.json` | `disposition-recommender`, `classify-application`, `portfolio-scorer` | Rationalization → Step 10 — Wave Planning |
| `skill-builder` (`:2555`) | 1.0.0 | Meta-Tooling | opus | _(prose)_ | — | — | Governance → Activity 5 — Pattern Extraction |
| `skill-validator` (`:2584`) | 1.0.0 | Meta-Tooling | sonnet | _(prose)_ | — | `skill-builder` | Governance → Activity 5 — Skill Lifecycle |
| `sla-breach-investigation` (`:2387`) | 1.0.0 | Runbooks & Operations | sonnet | _(prose)_ | — | — | Sustainment → Activity 1 — O&M |
| `smart-defaults-analyzer` (`:2762`) | 1.0.0 | Analysis & Assessment | sonnet | _(prose)_ | — | `extraction`, `legacy-business-rule-extractor` | Modernization → Step 2 — Design |
| `spec-from-requirements` (`:1829`) | 1.0.0 | Business Process & Automation | opus | _(prose)_ | `scenario-spec.json` → `schemas/build/scenario-spec.schema.json` | `requirements-elicitation`, `requirements-doc-ingester` | Build → Step 1 — Spec-from-Requirements |
| `spec-reviewer` (`:2806`) | 1.0.0 | Product Verification | opus | _(prose)_ | — | `tdd-plan-writer`, `code-generation` | Modernization → Step 3 — Generate (post-generation) |
| `srs-from-discovery` (`:504`) | 1.0.0 | Business Process & Automation | opus | _(prose)_ | — | `legacy-architecture-mapper`, `legacy-business-rule-extractor`, `discovery-synthesizer` | Discovery → Step 5 — SRS derivation (pre-G-DC) |
| `sse-broadcaster-scaffolder` (`:1709`) | 0.1.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `event-contract` | Modernization → Step 3 — Generate (real-time push) |
| `sustainment-handoff` (`:2347`) | 1.1.0 | Runbooks & Operations | sonnet | _(prose)_ | — | — | Disposition Execution → Retain — Handoff |
| `target-architecture-blueprint` (`:963`) | 1.1.0 | Business Process & Automation | opus | _(prose)_ | — | `target-state-mapper`, `migration-strategy-advisor` | Architecture → Step 2b — Target Architecture Blueprint |
| `target-schema-ddl` (`:1403`) | 1.0.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `data-modeling` | Modernization → Step 2 — Design (Data Model — DDL authoring) |
| `target-selection` (`:2146`) | 1.0.0 | Business Process & Automation | opus | _(prose)_ | — | — | Disposition Execution → Consolidate — Target Selection |
| `target-state-mapper` (`:784`) | 1.0.0 | Business Process & Automation | opus | `references/sf3-target-services.md` | `architecture-target-plan.json` → `schemas/architecture/architecture-target-plan.schema.json` | `disposition-recommender`, `disposition-governance`, `redundancy-analyzer` | Architecture → Step 1 — Target-State Mapping |
| `tco-analyzer` (`:237`) | 1.0.0 | Data Fetching & Analysis | sonnet | _(prose)_ | — | — | Discovery → Step 5 — TCO Baseline |
| `tdd-generation` (`:1456`) | 1.2.1 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `module-design`, `api-specification` | Modernization → Step 3 — Generate (test authoring — Ralph Loop step 1) |
| `tdd-plan-writer` (`:2785`) | 1.0.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `extraction`, `validation-rule-template`, `workflow-state-machine-template` | Modernization → Step 3 — Generate |
| `temporal-workflow-scaffolder` (`:1672`) | 0.1.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `xstate-fsm-generator`, `legacy-business-rule-extractor` | Modernization → Step 3 — Generate (durable workflow) |
| `test-coverage-uplift` (`:2321`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | — | Disposition Execution → Retain — Quality |
| `test-validation` (`:1525`) | 1.1.0 | Product Verification | sonnet | _(prose)_ | — | `tdd-generation` | Modernization → Step 3 — Generate (test verification) |
| `tiff-corpus-assessor` (`:485`) | 1.0.0 | Legacy Analysis | opus | _(prose)_ | — | `catalog-application`, `legacy-architecture-mapper` | Discovery → Step 3 — Conditional image-corpus assessment |
| `traceability-audit` (`:1438`) | 1.1.0 | Product Verification | sonnet | _(prose)_ | — | `module-design`, `api-specification`, `data-modeling`, `target-schema-ddl` | Modernization → Step 2 — Design (audit) |
| `traceability-checker` (`:1914`) | 1.0.0 | Code Quality & Review | sonnet | _(prose)_ | — | — | Validation → Streams 1, 4 — Traceability |
| `traffic-shift` (`:2005`) | 2.0.0 | CI/CD & Deployment | sonnet | _(prose)_ | — | — | Deployment → Step 2 — Traffic Shifting |
| `user-adoption-coordinator` (`:2040`) | 2.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | — | Deployment → Step 4 — Adoption Verification |
| `user-guide-generator` (`:2740`) | 1.0.0 | Documentation | opus | _(prose)_ | — | `gherkin-scenario-generator`, `extraction`, `smart-defaults-analyzer` | Modernization → Step 2 — Design |
| `user-transition-planning` (`:2089`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | — | Disposition Execution → Pre-cutover — User Transition Planning |
| `ux-accessibility-assessor` (`:297`) | 1.0.0 | Legacy Analysis | sonnet | _(prose)_ | `ux-accessibility.json` → `schemas/discovery/ux-accessibility.schema.json` | `accessibility-checker` | Discovery → Step 3 — Pass 4 (UX & Accessibility) |
| `ux-component-specification` (`:1356`) | 1.0.0 | Code Scaffolding & Templates | opus | _(prose)_ | — | `ux-page-specification`, `extraction` | Modernization → Step 2 — Design (UX component specification) |
| `ux-flow-derivation` (`:1299`) | 1.0.0 | Legacy Analysis | opus | _(prose)_ | `ux-flow-inventory.json` → `schemas/modernization/ux-flow-inventory.schema.json` | `extraction`, `legacy-architecture-mapper` | Modernization → Step 1 — Extract (UX flow derivation) |
| `ux-page-specification` (`:1316`) | 1.0.0 | Code Scaffolding & Templates | opus | _(prose)_ | — | `ux-flow-derivation`, `extraction`, `legacy-architecture-mapper` | Modernization → Step 1 — Extract (UX page specification) |
| `validation-cutover` (`:2240`) | 1.0.0 | Product Verification | sonnet | _(prose)_ | — | `component-configuration` | Disposition Execution → Replatform — Validation & Cut-over |
| `validation-rule-template` (`:2674`) | 1.0.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `extraction` | Modernization → Step 1 — Extract |
| `vendor-evaluation` (`:2123`) | 1.0.0 | Business Process & Automation | opus | _(prose)_ | — | `redundancy-analyzer` | Disposition Execution → Replace — Vendor/COTS Evaluation |
| `wave-outcome-synthesizer` (`:640`) | 1.0.0 | Data Fetching & Analysis | opus | _(prose)_ | `wave-outcome-synthesis.json` → `schemas/rationalization/wave-outcome-synthesis.schema.json` | `disposition-recommender`, `disposition-governance`, `tco-analyzer`, `assess-user-impact`, `classify-application`, `redundancy-analyzer`, `sequencer` | Rationalization → Step 8 — Wave Outcome Synthesis |
| `wave-status-report` (`:2458`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | — | Governance → Activity 6 — Reporting |
| `well-architected-reviewer` (`:1063`) | 1.0.0 | Product Verification | opus | _(prose)_ | `well-architected-review.json` → `schemas/architecture/well-architected-review.schema.json` | `blueprint-assembly` | Architecture → Step 10c — Well-Architected Review |
| `workflow-mapping` (`:2216`) | 1.0.0 | Business Process & Automation | sonnet | _(prose)_ | — | `platform-selection` | Disposition Execution → Replatform — Workflow Mapping |
| `workflow-state-machine-template` (`:2693`) | 1.0.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `legacy-business-rule-extractor`, `srs-from-discovery` | Modernization → Step 2 — Design |
| `xstate-fsm-generator` (`:1692`) | 0.1.0 | Code Scaffolding & Templates | sonnet | _(prose)_ | — | `module-design` | Modernization → Step 3 — Generate (FSM scaffold) |

---

> The full per-assembly-line **step → skill → schema** dispatch wiring is in the companion file **`11b-skill-line-wiring.md`** (split for size).
