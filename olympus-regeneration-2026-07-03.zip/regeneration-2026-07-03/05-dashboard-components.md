# 05 — Dashboard: Remaining Pages + New Consoles (Part 1)

Atomic regeneration spec. Source tree: `/Users/pnunna/Documents/GitHub/olympus/dashboard/src`.
All paths below are relative to that root unless absolute. Line cites are `path:NN` or bare `(:NN)` when the file is named at the section head.

This document (parts 1–N) covers the REMAINING page-dirs and the ENTIRE component library
(`components/`, 143 non-test `.tsx` across 56 dirs). The two sibling docs cover the other
page-dirs (`PortfolioOverview`, `Applications`, `ApplicationDetail`, `Admin/*`, `Analytics/*`,
`AssemblyLines/*`, `Compliance/*`, `Skills/*`, `MyTasks`, `MyBundles`, `Waves`, `WaveDetail`,
`Traceability`) and the shared infra (`api/`, `hooks/`, `types/`, routing).

Page-dirs covered HERE (part 1): `CapabilityLineage`, `RedundancyMatrix`, `OneStopShopDemo`,
`Escalations`, `ScoringHeatMap`, `TargetArchitecture`, `GateQueue`, `GateReview`, `Interview`,
`DesignReview`, `BuildProgress`, `ScopedLineLaunch`, `delegation-management`, `Auth`,
`AboutOverview`, `GettingStarted`, `DemoColdOpen`, `catalog`, `evidence-ledger`, `feedback`,
`autonomy-ops`, `nl-console`.

Component library begins at part 2.

---

## Conventions used by nearly every page

- Portfolio scoping: `const { activePortfolio, loading: portfolioLoading } = usePortfolioContext()`.
  Pages gate their fetch on `if (portfolioLoading) return;` inside the effect, and pass
  `activePortfolio?.id` to the API call.
- Effect cancellation: a `let cancelled = false;` flag with `return () => { cancelled = true; }`
  guards every `setState` after an `await`.
- USWDS components from `@trussworks/react-uswds` (`Alert`, `Button`, `Tag`, `Label`, `TextInput`,
  `Textarea`, `Radio`, `Select`, `Checkbox`, `Fieldset`, `Form`, `ButtonGroup`, `GovBanner`).
- Toasts via `sonner` (`toast.success` / `toast.error`).
- 508/AA rule repeated throughout: state is conveyed by ICON + TEXT, never color alone.

---

## pages/CapabilityLineage/CapabilityLineage.tsx

Purpose: portfolio-scoped reviewer surface for SF1→SF3 `capability_lineage` edges (M:N source→target).
Default export `CapabilityLineage()`. No props.

State (`:167`–`:183`): `systems: SystemSummary[]`, `systemsLoading`(init true), `systemsError`,
`selectedSystemId: string|""`, `capabilities: CapabilitySummary[]`, `capabilitiesLoading`,
`capabilitiesError`, `selectedCapabilityId: string|""`, `lineage: CapabilityLineageView|null`,
`lineageLoading`, `lineageError`.

API consumed (`../../api/client`): `fetchSystems(portfolioId)`, `fetchSystemCapabilities(systemId)`,
`fetchCapabilityLineage(capabilityId)`.

Three chained effects:
1. Load systems (`:186`). Early-return if `portfolioLoading`. If no `portfolioId`: clear loading,
   empty systems. Else fetch; default selection = **first `kind==="legacy"`** system, else `list[0]`
   (`:205`–`:207`) — reviewers walk M-rows of a source system.
2. Load capabilities when `selectedSystemId` changes (`:224`). Empty id ⇒ clear caps + selection.
   On success select `list[0]`.
3. Load lineage when `selectedCapabilityId` changes (`:261`). Empty ⇒ null.

Derived: `selectedCapability` (`:290`) memo lookup. `manyToManyTargets` (`:297`) = `lineage.targets`
when `targets.length > 1`, else `[]`.

Render branches (in order): `portfolioLoading || systemsLoading` ⇒ busy `<p>` (`:302`); no
`portfolioId` ⇒ EmptyState "No portfolio selected"; `systemsError` ⇒ error Alert; `systems.length===0`
⇒ EmptyState "No systems registered…" (`:339`). Otherwise the full page: intro `<p>`, a `<form>`
(`onSubmit preventDefault`) with a **System** `<select>` (option label `${external_id} · ${name} (${kind})`)
and a **Capability** `<select>` (disabled while `capabilitiesLoading || capabilities.length===0`; shows a
placeholder option when empty). Below: `capabilitiesError` Alert, selected-capability blurb, `lineageError`
Alert, "Loading lineage…" busy `<p>`, an **info Alert** `data-testid="m-to-n-callout"` shown when
`manyToManyTargets.length > 1`, then two `<EdgeTable>` sections (Targets, Sources).

Helper `relationshipBadgeClass(rel)` (`:52`): `absorbed→status-badge--complete`,
`partial→--in-progress`, `transformed→--pending`, `dropped→--failed`, default `""`.

Sub-component `EdgeTable({caption, direction, edges, emptyHint, testId})` (`:81`): empty ⇒ hint `<p>`
with `data-testid="${testId}-empty"`. Otherwise USWDS `usa-table usa-table--compact`. `direction`
(`"targets"|"sources"`) flips the "other side" columns: for `targets` uses
`target_capability_name/_external_id` + `target_system_external_id`; for `sources` the `source_*` ones.
Column header text = `"Target"` or `"Source"`. Columns: {other} capability (bold, `${external}·${name}`,
falls back to `"(retired — no target)"`), {other} system, Relationship (badge span), Confidence
(`edge.confidence ?? "—"`), Ratified (`ratified_at` → `toLocaleDateString()` else "—"), Notes.

GOTCHA: capabilities effect deps are ONLY `[selectedSystemId]` (`:258`) — it does NOT re-run when
`portfolioId` changes directly; correctness relies on the systems effect resetting `selectedSystemId`.

---

## pages/RedundancyMatrix/RedundancyMatrix.tsx

Purpose (P3.5-U3.1): renders the wave-scoped `redundancy-matrix.json` artifact as an interactive N×N
heat map with a click-to-drill panel. Default export `RedundancyMatrix()`; route params
`{ portfolioId, waveId }` via `useParams`.

Local artifact model (narrow view, `:30`–`:61`): `OverlapEntry{app_1,app_2,overlap_percentage,
shared_entities?,shared_operations?}`, `ConsolidationCandidate{group_name,applications[],
shared_capability,recommendation:"merge"|"shared_service"|"data_sot"}`, `RedundancyMatrixArtifact
{metadata{generated_date,applications_analyzed,analyst}, entity_overlap[], operation_overlap[],
high_overlap_pairs?, consolidation_candidates?}`.

Guard `isRedundancyMatrix(value)` (`:64`): object with object `metadata` and arrays
`entity_overlap` + `operation_overlap`.

Pure logic (exported for tests):
- `deriveAppList(matrix)` (`:95`): first-seen union of app_1/app_2 across entity+operation arrays,
  then `.sort(localeCompare)`. Deterministic order.
- `findOverlap(pairs,a,b)` (`:110`): symmetric pair lookup (a,b or b,a).
- `buildCell(matrix,row,col)` (`:123`): diagonal (`row===col`) ⇒ all-null cell. Else entity/op pcts;
  `composite` = **average of the AVAILABLE dimensions only** (missing skipped, not zeroed, `:147`–`:152`);
  `recommendation` = first consolidation candidate whose `applications` includes both row+col.
- `heatLevel(pct)` (`:178`): null→`none`, `<25`→`low`, `<50`→`med`, else `high`.
- `buildMatrixView(matrix)` (`:186`): `{apps, cells[][]}`.

Component state (`:209`): `matrix`, `loading`(true), `error`, `selected:{r,c}|null`.
Effects: (1) sets breadcrumb context `{appName:null, assemblyLine:"Rationalization"}` via
`useBreadcrumbContext`, cleared on unmount (`:216`). (2) fetch `fetchWaveArtifact(waveId,
"redundancy-matrix.json")` (`:224`): `null` result ⇒ matrix null / no error (empty state);
valid ⇒ set matrix; present-but-unparseable ⇒ error message; throw ⇒ error message.

Derived `view = matrix ? buildMatrixView(matrix) : null` (`:268`).

Render branches: no `waveId` ⇒ error Alert "Missing wave". Each of loading / error / empty state
renders a Back `<Link>` (`backHref` = `/portfolios/${portfolioId}/applications` or `/`) + heading.
Empty when `!matrix || !view || apps.length===0`.

Grid (`:357`): `role="grid"` with `aria-rowcount/colcount = apps.length+1`. Header row = corner +
one `columnheader` per app. Each body row = `rowheader` + one `<button role="gridcell">` per column.
Cell button: `disabled` on diagonal; `aria-selected` when selected & non-diagonal; `aria-label` =
`"{row} versus {col}, composite overlap {n} percent"` or `", no overlap data"`; class carries
`--{level}` + `--selected` + `--diag`; label text `"—"` on diagonal, `""` if composite null, else
`"{round}%"`; `onClick` sets `{r,c}` (guarded `!isDiag`).

Drilldown (`:432`, `aria-live="polite"`): `activeCell` looked up from `selected`. Shows pair,
a `<dl>` (Entity / Operation / Composite, each `round%` or "No data"), Shared entities list,
Shared operations list, and Consolidation recommendation (`group_name` + `recommendation.replace(_→space)`
+ `shared_capability`). Empty selection ⇒ hint.

---

## pages/OneStopShopDemo/OneStopShopDemo.tsx

Purpose: static future-state UX mockup (ATLAS Phase 2 SF2 Scene 5). **Fully static** — data from
`./mockData` (`JANE_AVIATOR, TIMELINE_ENTRIES, MEDICAL_CARD, CERTIFICATE_CARD, AIRCRAFT,
DESIGNEE_APPOINTMENTS, OPEN_ACTIONS, DISCREPANCIES, BEFORE_AFTER_METRICS`). No API calls. NOT linked
from product nav.

State (`:341`): `mobileView`(bool), `activeTab: "timeline"|"main"|"discrepancies"` (init "main").
Root class toggles `oss-demo--mobile`.

Sub-components (all presentational, all `onClick={e=>e.preventDefault()}` for inert affordances):
`FaaSealMark()` inline SVG seal (`:45`); `PersonaChip()` initials + name + airman id (`:74`);
`TimelineRailContent({entries})` ordered list with per-entry dot class by
`status` (`complete`/`in-review`/default) (`:95`); `MedicalCertificationCard()` badge class by
`MEDICAL_CARD.status==="Current"` (`:134`); `AirmanCertificateCard()` (`:176`);
`AircraftCard({aircraft})` (`:212`); `DesigneeCard({appointments})` returns null if empty (`:242`);
`OpenActionsCard({actions})` header badge counts `priority==="high"` (`:273`);
`DiscrepanciesContent({items})` list keyed by severity class (`:313`).

Root (`:340`): `<GovBanner/>`, page header with a **Desktop/Mobile view toggle** button
(`aria-pressed={mobileView}`), product header (seal + title + persona chip), a `role="tablist"` with
three `role="tab"` buttons (each sets `activeTab`), a 3-column grid (timeline aside / main cards /
discrepancies aside — each gets an `--active` modifier when its tab matches), and a Before/After
metrics section rendering `BEFORE_AFTER_METRICS` tiles.

---

## pages/Escalations/EscalationQueue.tsx

Purpose (P3.5-S.1): portfolio-wide list of escalated gates with a structured resolution flow.
Default export `EscalationQueue()`.

`RESOLUTION_OPTIONS` (`:45`): four `{value,label,hint}` — `re-extract`, `manual-augment`,
`re-disposition`, `rejected-as-escalated`. `describeAction(category)` (`:68`): the reject case says the
gate is set rejected + rework; the other three say it returns to the queue with notes.

State (`:83`): `gates: GateSummary[]`, `loading`(true), `search`, `errorMsg`, `selectedGateId`,
`resolution: EscalationResolutionCategory|null`, `notes`, `submitting`.
`useWebSocket({eventTypes:["gate.decided"]})` (`:93`) — subscription only (re-renders on event, no direct handler).

`load` (`:97`, useCallback on `activePortfolioId`): `fetchPendingGates(activePortfolioId, "escalated")`,
sets `res?.data ?? []`; on error sets `errorMsg` + empties. Effect (`:114`) runs it after
`portfolioLoading` clears.

`filteredGates` (`:120`): case-insensitive search over `[gate_type, getGateName, getGateAssemblyLine,
app_name]`. `handleSelect(id)` resets resolution+notes. `handleResolve()` (`:142`):
`resolveEscalation(selectedGateId, {resolution_category, notes?})`, toast, reset, reload.

Render: loading busy `<p>`. Two-column CSS grid (`minmax(0,1fr) minmax(320px,420px)`): left = search
`TextInput` + a `<ul>` of gate `<button>`s (`aria-pressed` on selected, inline border/bg styling), right
= sticky "Resolve escalation" region. When a gate is selected: shows app+gate, an unstyled "Open gate
review for context" button (navigates `/gates/${id}/review` with `state.from={pathname:"/escalations",
label:"Escalations"}`), a required `<fieldset>` of `Radio` resolution options, the `describeAction` line,
an optional notes `Textarea`, and Resolve/Cancel buttons (Resolve disabled unless `resolution` set).
Empty gates ⇒ dashed empty-state block.

---

## pages/ScoringHeatMap/ScoringHeatMap.tsx

Purpose (P3.5-U3.2): 2D scatter of every portfolio app — risk tier (X) vs `overall_weighted` readiness
(Y), colored by disposition, filterable. Recharts `ScatterChart`. Default export `ScoringHeatMap()`.

Constants: `DISPOSITION_COLOR` (`:42`) maps 8 dispositions incl. `Build:#008480` to hex; `UNSCORED_COLOR
=#71767a`; `RISK_JITTER = {"1":1,"2":2,"3":3}`.

State (`:76`): `entries: PortfolioScoringHeatMapEntry[]`, `loading`(true), `error`,
`tierFilter:"all"|"1"|"2"|"3"`, `dispositionFilter:"all"|Disposition|"Unclassified"`, `onlyScored`(bool).
`ct = useChartTheme()`.

Effect (`:86`): `fetchPortfolioScoringHeatMap(activePortfolio?.id)` → `res?.entries ?? []`.

`filtered` (`:104`): drops unscored when `onlyScored`; filters tier; disposition filter treats
`"Unclassified"` as `disposition===null`.
`scatterPoints` (`:119`): per entry — `scored = overall_weighted!==null`; X = `RISK_JITTER[tier] + jitter`
where `jitter = (app_id.charCodeAt(0)%17)/80 - 0.1` (deterministic per-app so overlaps separate);
Y = weighted or 0; `size = max(30, dimensionsCount*20)`; `fill` = disposition color when scored else
UNSCORED; `disposition ?? "Unclassified"`.
`totalScored/totalUnscored/noneScored` (`:140`): `noneScored` = entries exist but zero scored.

DataGrid columns (`:147`): Application (Link to `/applications/${app_id}`), Risk (Tag "Tier {t}" or "—"),
Disposition, Readiness (`toFixed(1)` or "—"), Current Line.

Render: loading busy section. Filters group: tier `<select>`, disposition `<select>` (options from
`DISPOSITION_COLOR` keys + "Unclassified"), "Only scored apps" checkbox, and a counts span.
Chart card: if `scatterPoints.length===0` ⇒ "No applications match…"; else if `noneScored` ⇒
`data-testid="scoring-heatmap-empty"` block with a "Go to applications — run Discovery →" Link
(P5-AUDIT-019); else the Recharts scatter — XAxis `domain[0.5,3.5] ticks[1,2,3]` tickFormatter `Tier {v}`,
YAxis `domain[0,100]`, ZAxis `size range[40,240]`, Tooltip formatter maps x→"Tier n", y→"Not scored"/toFixed,
labelFormatter → app_name; `<Scatter>` with one `<Cell fill={pt.fill}>` per point. Legend of all
dispositions + "Not yet scored". DataGrid of `filtered`.

---

## pages/TargetArchitecture/TargetArchitecture.tsx

Purpose: portfolio-scoped view of SF3 S1–S11 target services + SF1 legacy systems. Default export
`TargetArchitecture()`.

`loadAllSystems(portfolioId)` (`:207`): `fetchSystems` then `Promise.allSettled` over
`fetchSystemDetail(s.id)` — only fulfilled details kept. Returns `{summaries, details}`.

State (`:227`): `details: SystemDetail[]`, `loading`(true), `error`. Effect (`:232`): early-return if
`portfolioLoading`; no `portfolioId` ⇒ clear; else `loadAllSystems`.

Render branches: loading busy; no portfolio ⇒ EmptyState; error ⇒ Alert; `details.length===0` ⇒
EmptyState "No systems registered…".
Grouping (`:320`): `targetSystems (kind==="target")`, `legacySystems (kind==="legacy")`,
`mixedSystems (kind==="mixed")`. Sort: target+legacy by `external_id` with
`localeCompare(...,{numeric:true})` (so S2<S10); mixed by name.

Renders three `<SystemSection>` (target, legacy, and mixed only when `mixedSystems.length>0`).

`SystemSection({heading, description, systems, testIdPrefix, emptyHint})` (`:49`): empty ⇒ heading +
`text-muted` hint. Else `<ul>` of system cards; each card: `h3` with `${external_id} · ${name}`, optional
description, a `Tag` (`status-badge--${kind}`) for kind, a `<dl>` of counts (`capability_count`,
`business_domain_count`, `applications.length`), and a "Realizing applications" list of
`<Link to=/applications/${application_id}>` + `(role)` — or a "No applications link…" note.

---

## pages/GateQueue/GateQueue.tsx + EmptyState.tsx

### GateQueue.tsx
Purpose: portfolio-wide pending/rejected gates rendered via `GateCardList`, text-searchable.

State (`:23`): `gates: GateSummary[]`, `loading`(true), `search`, `filter:"pending"|"rejected"` (init pending).
`useWebSocket({eventTypes:["gate.ready","gate.decided"]})` (`:28`).
Effect (`:31`, deps `[activePortfolioId, portfolioLoading, filter]`): `fetchPendingGates(activePortfolioId,
filter)` → `res?.data ?? []`; error ⇒ empty.
`filtered` (`:53`): same 4-field case-insensitive search as Escalations.

Render: loading busy. A `role="tablist"` with Pending/Rejected buttons (outline when not selected;
Rejected uses `secondary` when selected). Summary `<p>` (singular/plural) only when `gates.length>0`.
Search `TextInput` only when `gates.length>0`. `showEmptyState = filtered.length===0`: renders
`<GateQueueEmptyState filter portfolioName search totalForFilter=gates.length onClearSearch=()=>setSearch("")>`;
else `<GateCardList gates=filtered caption=... emptyMessage="" showApplicationColumn onReview=(gateId)=>
navigate(/gates/${gateId}/review, state.from={pathname:"/gates",label:"Gate Queue"})>`.

### EmptyState.tsx — `GateQueueEmptyState`
Props (`:21`): `{filter:"pending"|"rejected", portfolioName:string|null, search, totalForFilter:number,
onClearSearch}`. Four cases (`:44`):
1. Case 3 — `searchActive && totalForFilter>0` ⇒ "No gates match "{search}"" + Clear-search button.
2. Case 2 — `filter==="rejected" && !searchActive` ⇒ "No gates in rework", no actions.
3. Case 1/4 — pending: heading `No pending gates in {portfolioName || "this portfolio"}`; when
   `searchActive && totalForFilter===0` adds a note; actions = "Switch portfolio →" button (calls
   `focusPortfolioPicker`) + a Link "Start Discovery on an application →"
   (`/applications?line=Discovery&status=onboarded`).
`focusPortfolioPicker()` (`:152`): `getElementById("portfolio-picker-select")` → focus + scrollIntoView;
silent no-op if absent. GOTCHA: couples to a DOM id owned by `PortfolioPicker`.

---

## pages/GateReview/GateReview.tsx

Purpose (W8/P5-S9): card-per-check gate review page. Route `/gates/:gateId/review`. Default export.

Data (react-query via `useQueries`): `useGateEvidence(gateId)` → `{data:evidence, isLoading, error}`;
`useSubmitGateDecision(gateId)` → mutation; `useGateReviewerRoles(gateId)` → `reviewerPolicy`.
`useWebSocket({eventTypes:["gate.decided"]})`.
State: `aiModalOpenRequest` counter (`:146`) — bumped by the AI banner's "View Full Pre-Review" to
re-open the modal inside `GateReviewCardList`.

`_readBackLink(state)` (`:111`): reads `location.state.from = {pathname,label}` (both non-empty strings)
for a contextual back link; else null → default "/gates" / "Gate Queue".

`handleSubmit(payload)` (`:155`): `decisionMutation.mutate(payload,{onSuccess,onError})`. onSuccess:
label from `payload.action` (approve→"approved", reject→"rejected", else "escalated"); toast — in demo
mode via `toastForDemo(toast.success,...)` else `toast.success` (identical call path, `:169`); then
navigate — `evidence.app_id` ⇒ `/applications/${app_id}`, else `wave_id` ⇒ `/waves/${wave_id}`, else
`/gates` (defensive; a DB CHECK guarantees exactly one). onError ⇒ toast.error.

Render: `loading` ⇒ `<GateReviewSkeleton>`. `error || !evidence` ⇒ error Alert + return link.
Otherwise: back link (`data-testid="gate-review-back-link"`), header — `h1` "Gate Review:
{getGateName} (<Glossary term={gate_type}>{gate_type})  — {assembly_line}"; `h2` subject (Wave: name
OR Application: name); meta `<p>` showing "Attempt {previous_attempts+1}" when >0 and an "View agent run
errors (n) →" Link (to `/admin/workflow-health?wave_id=` or `?app_id=`) only when
`agent_error_count>0` (F15). Then, in order: `<ConsequenceBanner>`, `<EvidenceSourcePanel>` (reads
`bundle_evidence_source` defensively via cast), `<DispositionConfidenceChip>`, `<AIRecommendationBanner>`
(only if `ai_recommendation`; onViewDetails bumps counter), `<ValidationWarningsBanner>`,
`<PreviousAttempts>`, a decision-error Alert (`decisionMutation.error`), and `<GateReviewCardList>`
with props: `evidence, onSubmit=handleSubmit, loading=isPending, aiPreReview, autoOpenAiModal,
openAiModalRequest=aiModalOpenRequest, gateName, canApprove` (from policy or `true`), `canDecide`
(`can_approve||can_force_advance` or `true`), `reviewerPolicy`.
GOTCHA (`:135`): while `reviewerPolicy` loads or fails, actions are NOT hidden — server RBAC is
authoritative; defaults to permissive so a slow/failed fetch never locks out a reviewer.

Sub-components: `GateReviewSkeleton` (`:45`) skeleton blocks; `PreviousAttempts({attempts,feedback})`
(`:60`) returns null unless `attempts>0 && feedback.length>0`; per item renders "Attempt {i+1} —
Rejection Reason" (`item.notes ?? item.reason ?? "No reason provided"`) + optional "Changes Made".

---

## pages/Interview/Interview.tsx

Purpose (P6-S5.12): Requirements Interview UI for interview-driven Build intake. Route
`/portfolios/:portfolioId/applications/:appId/interview`. Default export `Interview()`.

Hooks: `useStartInterview(appId)`, `useInterviewSession(appId)`→`{data:session,isLoading}`,
`useSubmitInterviewTurn(appId)`, `useCompleteInterview(appId)`.
State: `answer`, `validationErrors:string[]`.

Effect (`:69`): on mount (deps `appId,portfolioId,start`) `start({portfolio_id: portfolioId ?? null})`
— starts or resumes; seeds the session-query cache.
`onSubmitTurn` (`:75`): no-op on empty; `submitTurn.mutate(answer.trim(),{onSuccess:clear,onError:toast})`.
`onComplete` (`:83`): `complete.mutate(undefined,...)`. onSuccess: if `resp.artifact_valid` ⇒ clear errors
+ success toast (message varies on `resp.signal_sent`); else set `resp.validation_errors` + error toast.

Derived from session (`:102`): `status (??"active")`, `phase (??1)`, `totalPhases (??5)`, `preview`,
`transcript` = `session.transcript` filtered to turns with an `answer` OR whose question equals
`session.current_question`.

Render: breadcrumb nav; header w/ intro; loading `<p>`; validation warning Alert (lists errors);
completed success Alert. Body 2-col: left "Conversation" `<ol>` of turns (each = "Phase {n}" pill +
question + answer); when `status==="active" && current_question` a compose block (Textarea + "Send answer"
button disabled on empty/pending); when `status==="active" && ready_to_submit` a submit block ("Submit
interview" disabled while pending). Right "Requirements (live preview)": summary, Capabilities list
(`id — name` + priority Tag), Functional requirements list (`id: statement`), Acceptance criteria list
(`id: Given … when … then …`) — each with an empty fallback. Footer: `role="progressbar"`
(`aria-valuemin=1 aria-valuemax=totalPhases aria-valuenow=phase`) rendering "Phase p/total" steps with
`--done`/`--current` classes; phase label + `<StatusTag>`.
`StatusTag({status})` (`:38`): label completed/expired/"In progress".

---

## pages/DesignReview/DesignReview.tsx

Purpose (P6-S9.3/9.4): standalone design-artifact review (NOT gate review — no approve/reject).
Route `/applications/:appId/design-review`. Default export.

Constants: `CATEGORIES = ["All","Architecture","API","Data","UX/UI"]` (`:39`); `TYPE_LABELS` (`:42`)
maps artifact_type → human label; `label(type)` falls back to raw type.

Hooks: `useDesignArtifacts(appId)`→`{data,isLoading,isError}`, `useSubmitDesignFeedback(appId)`.
State: `category:Category` (init "All"), `pending: DesignFeedbackAnnotation[]`, `annotationText`.
URL selection via `useSearchParams` (`?artifact=`).

Derived: `artifacts = data?.artifacts ?? []`; `filtered` by category; `selectedId = searchParams.get
("artifact")`; `selected = filtered.find(id) ?? filtered[0] ?? null`.
`selectArtifact(id)` (`:86`): sets `?artifact=` with `{replace:true}`.
`addAnnotation(action)` (`:95`): pushes `{artifact_id, artifact_type, skill_id, annotation_text, action}`
to `pending`, clears text, toast (flag_for_revision vs generic). `flaggedCount` counts flag_for_revision.
`onSubmitFeedback` (`:122`): submits only flagged annotations via
`submitFeedback.mutate({annotations},...)`; onSuccess toast (`resp.dispatched.length` signals) + drops
flagged from pending.

Render: breadcrumb; header with `role="tablist"` category tabs, and a feedback bar (pending count Tag +
"Submit feedback to agent ({flaggedCount})" button disabled when `flaggedCount===0 || isPending`).
Loading/error/empty states. Body 2-col: `role="listbox"` sidebar of artifacts (each `role="option"`,
`tabIndex=0`, Enter/Space selects) showing label + `line` + date; main = `<ArtifactViewer
artifactType data metadata=null schemaVersion="1.0" appId>` + annotation zone (Textarea, context line
with skill_id + `git_sha.slice(0,7)`, "Flag for revision" / "Mark reviewed" buttons disabled on empty
text, and a per-artifact pending list).

---

## pages/BuildProgress/BuildProgress.tsx

Purpose (P6-S5.12): page wrapper deriving `BuildProgressData` from application status; renders
presentational `<BuildLineProgress>`. Route `/applications/:appId/build`.

Hooks: `useApplicationDetail(appId)`→detail, `useApplicationStatus(appId)`→`{data:status,isLoading,isError}`.
`isBuild = detail?.disposition === "Build"`.

Helpers: `gateStatusFor(gates,type)` (`:28`): matches on raw string (`gate_type as string`) because
`G-NEW-*` aren't in the `GateType` enum; missing⇒`not_started`, approved⇒`approved`, rejected⇒`rejected`,
else `pending`. `stepStatusFor(gate)` (`:42`): approved⇒`complete`, pending|rejected⇒`in_progress`,
else `not_started`.

`data` memo (`:55`): builds `{app_id, app_name, spec/design/generate:{status:stepStatusFor(g1/g2/g3)},
gates:{"G-NEW-1":g1,"G-NEW-2":g2,"G-NEW-3":g3}}` from gates G-NEW-1/2/3.

Render: breadcrumb; `h1`; loading `<p>`; error Alert; when `detail && !isBuild` an info Alert "Not a
Build application" (shows `disposition ?? "Undecided"`); always renders `<BuildLineProgress data={data}>`
when not loading/error.

---

## pages/ScopedLineLaunch/ScopedLineLaunch.tsx

Purpose (Phase-10 U3/W9): operator surface for scoped line execution — propose inputs, override same-type,
opt out context-starved, pick run-mode, confirm+start. Consumes `../../api/lines`. NO resolution/assurance
computation here (server-side).

`STARTABLE_LINES` (`:30`): architecture, data, modernization, validation, deployment, disposition
execution, rationalization, discovery (continuous lines excluded — REQ-SE-010).

State (`:46`): `appId, waveId, artifactRepo, targetRepoUrl, disposition("rearchitect"), line("data"),
runMode:RunMode("isolated"), resolved:ResolveInputsResponse|null, overrides:ChosenOverride({}),
contextStarved(bool), started:StartLineResponse|null, error, busy`.

`onResolve` (`:60`): `resolveLineInputs(line, appId)` → set resolved, reset overrides, set
`contextStarved = r.context_starved`.
`confirmedInputs` memo (`:76`): maps `resolved.proposals`; if an override differs from `p.path` ⇒
`{origin:"operator-supplied", attestation:"operator-override:${p.path}"}` (REQ-SE-002), else passthrough.
`onConfirmAndStart` (`:98`): `startScopedLine(line, {target_app_id, wave_id, artifact_repo,
target_repo_url, disposition, run_mode, confirmed_inputs: contextStarved ? [] : confirmedInputs,
context_starved})`. GOTCHA: when context-starved, confirmed inputs are sent EMPTY.
`badge = started?.assurance_level ? assuranceBadge(...) : null`.

Render: `<main>` with launch-params section (Select line, TextInputs app/wave/artifactRepo/targetRepo/
disposition, Select run-mode from `RUN_MODES`, "Propose inputs" button disabled when `busy || !appId`).
When `resolved`: "Proposed inputs" section — context-starved notice OR a `<ul>` of proposals (path, origin
Tag, attestation, and a same-type override `<Select>` from `[p.path, ...p.alternatives]` only when
alternatives exist); a context-starved opt-out checkbox (`data-testid="context-starved-optout"`); and the
"Confirm & start" button (nothing dispatched until this — REQ-SE-001). When `started`: workflow_id,
run_mode, and an assurance badge Tag (icon + label). `error` ⇒ `role="alert"` `<p>`.

---

## pages/delegation-management/DelegationManagement.tsx

Purpose (Phase-10 W10 U4, REQ-UDM-001..007): grantor's control point for scoped, revocable on-behalf-of
delegation. DISTINCT from `Admin/Delegation.tsx` (bundle force-release). Consumes `../../api/client`
(`issueDelegation, listDelegations, revokeDelegation, DelegationGrant`).

`GRANTABLE_ACTIONS` (`:40`): 6 `{id,label}` mirroring W6 `ACTION_SPECS` (onboard_application, start_line,
start_discovery, dispatch_skill, retry_step, rerun_step). The scope is DATA (a whitelist of action ids),
never a role.
`expiryLabel(grant)` (`:49`): no expiry ⇒ "No expiry"; within 24h ⇒ "Expires soon: …" else "Expires …".
`scopeSummary(grant)` (`:57`): empty allowed_actions ⇒ "Analyze-only (no mutating action)" else joined.

State (`:64`): `grants, loading(true), error, reload(counter), agentId, selectedActions:Set<string>,
submitting, revokingId`.
Effect (`:75`, dep `reload`): `listDelegations()` → grants; error ⇒ message.
`toggleAction(id)` (`:96`) mutates the Set. `handleIssue(e)` (`:105`): requires agentId; `issueDelegation
({agent_id, allowed_actions:Array.from(selectedActions)})`; toast; reset; bump reload. On error toast
"Scope is bounded to your rights." `handleRevoke(grantId)` (`:133`): `window.confirm(...)`, then
`revokeDelegation`, toast, bump reload. `activeGrants` = `grants.filter(status==="active")`.

Render: `h1`, intro (effective authority = your rights ∩ grant scope). Issue section: form with agent-id
TextInput, a `Fieldset` of `Checkbox` per grantable action (leave all unchecked ⇒ analyze-only), "Issue
grant" button. Active grants section: loading/error/empty; else a `usa-table` with columns Agent, Scope
(`scopeSummary`), Expiry (`expiryLabel`), Status (icon "● " + "Active" — icon+text per REQ-UDM-007), Actions
(`<details>` audit trail: Issued/Expiry/Revoked + a `secondary` Revoke button disabled while revoking).

---

## pages/Auth/Login.tsx + OidcCallback.tsx

### Login.tsx (P4-S1.11)
Local username/password + OIDC/SSO entry. Renders OUTSIDE the main Layout, so it ships a minimal guest
shell (skip-nav + brand header). Consumes `fetchAuthConfig, loginLocal, setAuthToken`.

State (`:35`): `authConfig:AuthModeConfig|null, emailOrUsername, password, submitting, error`.
`from` (`:33`): `location.state.from?.pathname ?? "/"` — deep-link preservation after RequireAuth bounce.
Effect (`:41`): `fetchAuthConfig()`; on failure defaults to `{local_enabled:true, oidc_enabled:false, ...}`
(non-fatal — form still works).
`handleSubmit` (`:63`): `loginLocal({email_or_username, password})` → `setAuthToken(access_token)` →
`navigate(from, {replace:true})`; error ⇒ message.
`handleOidcLogin` (`:83`): builds `${VITE_API_BASE_URL}${oidc_login_url}?redirect_after=
${origin}/auth/callback` and sets `window.location.href`.

Render: skip-nav anchor, guest header (brand "Olympus"), `<main id="login-main">` with the sign-in card:
error Alert, USWDS `<Form large>` (email/username + password TextInputs, "Sign in" button), and — only
when `authConfig.oidc_enabled` — an SSO section with a button labelled `oidc_provider_label ?? "Sign in
with SSO"` (`data-testid="sso-login-button"`).

### OidcCallback.tsx (P4-S1.11)
Effect (`:17`): parse `window.location.hash` (strip leading `#`) as `URLSearchParams`; if `access_token`
present ⇒ `setAuthToken(token)` + `navigate("/",{replace})`, else `navigate("/login",{replace})`. Renders
a `role="status"` "Completing sign-in…".

---

## pages/GettingStarted/GettingStarted.tsx

Purpose: "how to get rolling" About-section page; launches the guided `OnboardingWizard`. Mostly static.
State: `wizardOpen` (bool). `PATH_STEPS` (`:22`, 4 steps) and `NEXT_STOPS` (`:51`, 4 links) are static
arrays. Render: `<div className="getting-started">` (NOT a second `<main>` — Layout owns it, P6-AUDIT-002);
hero section with a "Launch guided setup" button (label flips to "Guided setup is open below ↓" when open)
+ a "What is Olympus? →" Link; when `wizardOpen` an inline `<OnboardingWizard onComplete=()=>setWizardOpen
(false)>`; a "path to your first run" `<ol>` of PATH_STEPS; an "explore first" section (Link to "/"); and a
"Where to go next" card grid of NEXT_STOPS Links.
GOTCHA (`:70`): NEXT_STOPS copy hardcodes "167 skills" — count drifts from the registry.

---

## pages/AboutOverview/AboutOverview.tsx

Purpose: durable "what is Olympus" landing. Static content + one API call for the active-profile facet.
Consumes `fetchActiveProfile`.

Static data: `DIFFERENTIATORS` (5, `:29`), `ASSEMBLY_LINES` (10, in flow order, each with name/blurb/slug/
color/summary/inputs/outputs/gates[]/mode — `:85`), `FACTORY_PHASES` (Extract/Design/Generate w/ gate ids,
`:238`), `SKILL_FACETS` (4, `:263`, copy hardcodes "167 skills"), `STATIC_PROFILE_FACETS{before[2],
after[1]}` (`:286`), `NO_ACTIVE_PROFILE_FACET` (`:306`).

State (`:315`): `selectedLine` (init 0 = Discovery), `activeProfile:ActiveProfileDetail|null`.
Effect (`:323`): `fetchActiveProfile().catch(()=>null)`.
`activeProfileFacet` (`:334`): when profile present ⇒ `{title:"Active profile: {name}", body: description ||
fallback}`, else `NO_ACTIVE_PROFILE_FACET` (P6-S10.3 — never hardcodes FAA). `PROFILE_FACETS` = before +
activeProfileFacet + after.

Render: `<div>` wrapper (NOT a 2nd main). Hero; "What makes Olympus different" cards; "Ten assembly lines"
section — an `<ol>` of line buttons (`aria-pressed` + `aria-controls="about-overview-line-detail"`,
`--line-color` CSS var, `onClick=setSelectedLine(i)`) plus a `role="region" aria-live="polite"` detail panel
for `active = ASSEMBLY_LINES[selectedLine]` (title, gate chips, summary, inputs/outputs/mode `<dl>`, and two
Links `/assembly-lines/{slug}` + `/anatomy`); "Skills: the programmable control plane" quad-card grid
(+Link to /skills); "Client profiles" quad-card grid rendering PROFILE_FACETS (+Link to /admin/profile);
"Modernization factory" Extract→Design→Generate phase strip; closing exit line.

---

## pages/DemoColdOpen/DemoColdOpen.tsx

Purpose: full-screen animated 7-box process-map ribbon for the ATLAS demo tape (Scene 1 open, Scene 11
close). Renders OUTSIDE the Layout shell. Routes `/demo/cold-open` and `?close=true`.

Constants: `PROCESS_STEPS` (7, `:44`): Secure context, Ingest, Analyze, Decide (human-governed), Sequence,
Architecture & cATO, Repeat. `PULSE_STEP_INDEX=3` (the human-governed box pulses). SVG layout consts
(`:65`): BOX_WIDTH=200, HEIGHT=88, GAP=26, ARROW_LENGTH=16, RIBBON_Y=96, VIEWBOX 1600×260; timings
STAGGER=250ms, FADE=350ms, ARROW_DRAW=150ms.

`computeStepLayout()` (`:81`): centers the row in VIEWBOX_WIDTH; returns `[{label,x}]`.

State: `isClose = searchParams.get("close")==="true"`; `layout` memo; `readyFiredRef`; `visibleCount`
(0→7).
Effect (`:106`): schedules 7 staggered timers that ramp `visibleCount`; cleared on unmount.
Effect (`:120`): once `visibleCount===7` and not already fired, after `FADE+ARROW_DRAW` sets
`document.body.dataset.demoColdOpenReady="true"` and dispatches `window` event `demo:cold-open:ready`
(guarded for SSR/jsdom). Playwright SHOT-01/10 wait on this.

Render: `<main>` with bg div, title card (eyebrow "ATLAS Phase 2 · Subfactor 2", headline, byline
"Booz Allen Hamilton · 2026"), an SVG ribbon (`role="img"` + title/desc) with a glow filter; per step a
`<g>` (`--visible`/`--pulse` classes gated on `visibleCount`) with rect + centered label + (when `hasNext`)
an arrow `<g>` (`--visible` when `visibleCount>i+1`); a visually-hidden `aria-live="polite"` announcement
that reads the full process once all 7 are visible; a footer "Booz · Allen · Hamilton"; and, when
`isClose`, a strap "High Confidence through Proven Relevant Experience".

---

## pages/catalog/CatalogBrowsePage.tsx

Purpose (Phase 8 U5, REQ-UCB-001..005): filterable read-view of the reusable-parts catalog. Read-only.
Data: `listCatalog({limit,offset})` from `../../api/catalog`; helpers `isAtRisk, statusTone, statusLabel`
from `./atRisk`.

`CatalogRow` (`:32`): id, partId, name, version, kind, status, `securityReview:"reviewed"|"unreviewed"`,
atRisk, plus CONTRACT-RECONCILE delta fields profileScope/controlCoverage/evalStatus (null until backend).
`deriveSecurityReview(status)` (`:56`): `published`⇒"reviewed" else "unreviewed" (published ⇒ passed the
security-gated publication). `apiToRow(e)` (`:62`) maps a `CatalogEntry`.

State (`:140`): `entries:CatalogRow[], loading(true), loadError, filterKind(ALL), filterStatus(ALL)`.
`ALL="all"` sentinel.
`loadEntries` (`:148`): `listCatalog({limit:200,offset:0})` → `res.items.map(apiToRow)`. One page covers
the curated library. Tenancy server-enforced — renders exactly what comes back.

Derived: `kinds`/`statuses` = sorted distinct of loaded rows. `profileScopeLive`/`evalStatusLive`/
`controlCoverageLive` = whether ANY row carries the delta field (drives disabled facets). `filtered` by
kind+status. `atRiskCount`.

DataGrid columns (`:207`): Part (name + partId), Version, Kind, Status (`<StatusCell>`; custom `sortingFn`
by raw status.localeCompare so at-risk never sorts into "current"), Security review (`<SecurityReviewCell>`).

`StatusCell({status})` (`:84`): `statusTone` → at-risk ⇒ ⚠ + label + sr-only "(at risk — do not reuse
without review)"; current ⇒ ✓ + label; neutral ⇒ muted label. Icon aria-hidden, meaning in text
(REQ-UCB-003). `SecurityReviewCell` (`:121`): ✓ Reviewed / — Not reviewed.

Render: heading + read-only note; loadError Alert; a 4-stat widget grid (Total/Kinds/At-Risk/Statuses); a
filter `<fieldset>` with LIVE Kind + Status selects and three DISABLED CONTRACT-RECONCILE facets
(Profile scope, Control coverage, Eval status — each shows "Pending backend" hint until its `*Live` flag);
then loading placeholder or `<DataGrid filterable data=filtered columns …>`.

---

## pages/evidence-ledger/EvidenceLedgerPage.tsx

Purpose (Phase 8 U3, REQ-UEL-001..006): the authorizing official's continuous-monitoring window. Evidence
grouped by `(catalog_id, control_id)` with ratified-only satisfaction + OSCAL export. READ-ONLY.
Data from `../../api/evidence` (`fetchEvidenceRecords, groupRecordsByControl, summarizeSatisfaction,
hasViewerPlus, oscalExportFilename, requestOscalExport, OSCAL_EXPORT_AVAILABLE`) + `fetchCurrentUser`.

State (`:257`): `user:UserProfile|null, userResolved(bool), catalogs:CatalogGroup[], summary:
SatisfactionSummary|null, exportRunId, loading(true), error`.
Effect (`:269`): resolve caller once (`fetchCurrentUser`) → `userResolved`. `permitted = hasViewerPlus
(user?.roles)` (REQ-UEL-005).
Effect (`:289`): gated on `!portfolioLoading && userResolved`. If not permitted ⇒ stop (don't fetch).
No portfolio ⇒ clear. Else `fetchEvidenceRecords(portfolioId,{limit:1000})` → `groupRecordsByControl` →
`setCatalogs` + `summarizeSatisfaction`; `exportRunId` = first record with `assessed_at_gate`.

Derived `totalRecords` = sum of all control record counts.

Render branches: loading/portfolioLoading/!userResolved ⇒ `<LedgerSkeleton>` (REQ-UEL-004, never blank).
`!permitted` ⇒ `data-testid="ledger-forbidden"` + warning Alert. `error` ⇒ error Alert. Otherwise: heading
+ note (ratified-only counts), `<ExportButton runId={exportRunId}>`, a satisfaction summary widget grid
(Controls satisfied / Ratified records / Unratified records + `<SatisfactionSummaryChart>`), and either an
EmptyState "No evidence records yet" or per-catalog `<section>`s each with a `usa-table` (Control/Family/
Status/Satisfaction/Ratified/Unratified rows; `<SatisfactionBadge control>`).

Sub-components:
`SatisfactionBadge({control})` (`:65`): `control.satisfied` ⇒ ✓ "Satisfied (ratified)";
`ratified_count===0 && unratified_count>0` ⇒ ⚠ "Awaiting ratification"; else ○ "Not satisfied". Icon+text,
never color alone (REQ-UEL-002).
`LedgerSkeleton` (`:95`): skeleton widgets + rows.
`ExportButton({runId})` (`:131`): if `!OSCAL_EXPORT_AVAILABLE` ⇒ a DISABLED button + "not yet available"
hint (REQ-UEL-003, blocked-until-backend). Else an enabled button whose `onExport` (`:160`) calls
`requestOscalExport(runId)`, builds a `Blob`, creates an `<a download>` with `oscalExportFilename(runId)`,
clicks it programmatically, and revokes the URL. Errors ⇒ `role="alert"`.
`SatisfactionSummaryChart({summary})` (`:201`): Recharts vertical `BarChart` (Satisfied vs Not satisfied),
wrapped `aria-hidden` with `accessibilityLayer={false}` + `tabIndex={-1}` (the figures below carry the
data — avoids an axe `aria-hidden-focus` violation); subtitle "{satisfied} of {total} controls satisfied".

---

## pages/feedback/FeedbackTriagePage.tsx

Purpose (Phase 8 U7, REQ-UFT-001..005): read-view of the learn-from-feedback queue + one write (approve a
`pending_review` item into work). Data from `../../api/feedback` (`approveFeedback, dismissFeedback,
listFeedback`) + `fetchCurrentUser`.

`APPROVER_ROLES` (`:37`): Set of `tech_lead, portfolio_manager, portfolio_admin` (mirrors
`feedback.py::APPROVER_ROLES`). `userCanApprove(profile)` (`:43`): profile roles ∩ APPROVER_ROLES non-empty.
Label maps: `SEVERITY_LABEL, SOURCE_LABEL, STATUS_LABEL`.

State (`:96`): `items:FeedbackItemSummary[], loading(true), errorMsg, profile:UserProfile|null,
activeId(the row being approved), promotionRef, submitting, workOrders:Record<id,ref>`.
`canApprove = userCanApprove(profile)`.
Effects: `load()` (`:111`) = `listFeedback()`→`res.data`; and a fail-closed profile resolve (`:133`,
failure ⇒ profile null ⇒ canApprove false).
`beginApprove(id)`/`cancelApprove()` toggle the inline approve form. `handleApprove(id)` (`:158`):
requires trimmed `promotionRef`; `approveFeedback(id,{promotion_ref})`; toast; record work-order in
`workOrders`; reset; reload. `handleDismiss(id)` (`:184`): `dismissFeedback(id,{dismiss_reason})`; toast;
reload.

Columns memo (`:203`): Feedback (title + mono signature + FlagChips + optional work-order link), Source,
Severity, Status. The **Actions column is only pushed when `canApprove`** (REQ-UFT-004 — no hidden-but-
present DOM node): its cell shows Approve/Dismiss buttons only for `status==="pending_review"`, else the
status label. Deps intentionally exclude activeId/promotionRef/submitting to keep column defs stable (avoids
re-mounting cell inputs and dropping focus, `:321`).
`FlagChip({glyph,label})` (`:72`): icon (aria-hidden) + text label — recurring ↻ `Recurring ×n`
(occurrence_count>1) / escalated ⚠ `Escalated` (source_type==="escalation").

Render: heading + note; errorMsg Alert; the approval form (rendered OUTSIDE the table, only when
`canApprove && activeItem`, so the work-order input keeps focus — REQ-UFT-003): work-order-ref TextInput +
"Confirm approve" (disabled unless ref+not submitting) + Cancel. Then `<DataGrid filterable data=items
columns …>`. `activeItem` = `items.find(id===activeId)`.

---

## pages/autonomy-ops/AutonomyOps.tsx

Purpose (P9-S17.5): a READ-ONLY operator + accrediting-official (AO) live-view of the platform's autonomy
posture — loop patterns (requested vs tier-capped permitted rung), open escalations, the open nightly
error-triage incident backlog, and the L0→L3 readiness ladder (:1-26). No mutations; escalating a loop item
is a separate elevated endpoint deliberately out of scope (:20-21). CLIENT-BLIND: tier labels + autonomy
levels are rendered from the API response and framework-neutral tier ids (:23-25).

Imports (:28-43): `useEffect, useMemo, useState` from react; `Alert` from `@trussworks/react-uswds`; from
`../../api/autonomy` — the funcs `getAutonomyStatus, getAutonomyIncidents, autonomyLevelLabel,
triageDecisionLabel, captureSourceLabel` and the types `AutonomyStatusPage, IncidentPage, LoopPatternStatus,
EscalationRecord, IncidentRecord`; `usePortfolioContext` from `../../hooks/usePortfolioContext`; `EmptyState`
from `../../components/EmptyState`. (See the `pages/autonomy-ops` API doc for `api/autonomy.ts` — the two
routers are mounted at the BARE `/autonomy` prefix, not `/api/v1`.)

### Module-level constants + helpers

`RISK_TIER_OPTIONS` (:51-56): `ReadonlyArray<{value,label}>` = `[{"", "All tiers (no cap resolution)"},
{"tier_1","Tier 1 (highest criticality)"}, {"tier_2","Tier 2"}, {"tier_3","Tier 3"}]`. `""` means send no
`risk_tier`, so the server does NOT resolve caps (:48-49).

`formatWhen(iso: string|null|undefined): string` (:59-64): `if (!iso) return "—"`; `const d = new Date(iso)`;
if `Number.isNaN(d.getTime())` return the raw `iso` string; else `d.toLocaleString()`. GOTCHA: falls back to
the raw string on unparseable input rather than throwing.

### Sub-components (all defined in this file)

`CapBadge({pattern: LoopPatternStatus})` (:71-91): if `pattern.capped` → `<span
className="usa-tag bg-gold" data-testid={`loop-capped-${pattern.name}`} title="The per-risk-tier cap lowered
the requested autonomy level">` with an `aria-hidden` `"⚠ "` glyph + text `"Capped by tier"`. Else →
`<span className="usa-tag bg-base-lighter" data-testid={`loop-uncapped-${pattern.name}`}>` with an
`aria-hidden` `"○ "` glyph + `"Not capped"`. Meaning is carried by text, never colour alone.

`OpsSkeleton()` (:94-113): the loading placeholder — `<div aria-busy="true" aria-label="Loading autonomy
operations" data-testid="autonomy-ops-skeleton">` containing `<h1 id="autonomy-ops-heading">Autonomy
Operations</h1>`, one `usa-skeleton` bar (height 28, width 40%), then an `aria-hidden` block mapping
`[0,1,2,3,4]` to five `usa-skeleton` bars (height 40, marginBottom 8). Never a blank screen.

`ReadinessLadder({rungs: string[]})` (:117-143): if `rungs.length === 0` → `<EmptyState icon="generic"
headingLevel="h3" headline="No readiness ladder published" compact body={<p>The active profile has not
documented an autonomy readiness ladder.</p>} data-testid="ladder-empty" />`. Else → `<ol className="usa-list"
data-testid="readiness-ladder">` mapping each rung to `<li key={`${i}-${rung}`}
data-testid={`ladder-rung-${i}`}>{rung}</li>` (ordered list preserves rung order L0→L3).

`LoopPatternsPanel({patterns: LoopPatternStatus[]})` (:146-207): if empty → `<EmptyState icon="agents"
headline="No loop patterns registered" …data-testid="loop-patterns-empty" />`. Else → a
`usa-table usa-table--borderless width-full` (`data-testid="loop-patterns-table"`) with an `usa-sr-only`
caption; header cols `Loop pattern / Cadence / Requested / Permitted / Tier cap`; one row per pattern
(`key={p.name}`, `data-testid={`loop-row-${p.name}`}`): row-header `<th scope="row">` = `p.name` + (when
`p.description`) a muted `display-block text-muted font-body-2xs` description span; cadence cell `{p.cadence
|| "—"}`; `<td data-testid={`loop-requested-${p.name}`}>{autonomyLevelLabel(p.requested_level)}</td>`;
`<td data-testid={`loop-permitted-${p.name}`}>{autonomyLevelLabel(p.permitted_level)}</td>`; and a
`<CapBadge pattern={p} />` cell.

`EscalationsPanel({escalations: EscalationRecord[]})` (:210-293): if empty → `<EmptyState icon="escalations"
headline="No open escalations" …data-testid="escalations-empty" />`. Else → a borderless table
(`data-testid="escalations-table"`, sr-only caption); header cols `Loop item / Application / Tier /
Requested → Permitted / Reason / Forced by`; one row per escalation (`key={e.loop_item_id}`,
`data-testid={`escalation-row-${e.loop_item_id}`}`): `<th scope="row">{e.loop_item_id}</th>`; app cell
`{e.application_id || "—"}`; tier cell `{e.risk_tier || "—"}`; transition cell renders
`autonomyLevelLabel(e.requested_level)` + an `aria-hidden` `" → "` + an `usa-sr-only` `" to "` +
`autonomyLevelLabel(e.permitted_level)`; reason cell `{e.reason || "—"}`. The **Forced-by** cell (:267-286):
if `e.denylisted` → `<span className="usa-tag bg-red"
data-testid={`escalation-denylisted-${e.loop_item_id}`}>Denylisted path</span>`; if `e.attempt_capped` →
`<span className="usa-tag bg-gold margin-left-1"
data-testid={`escalation-attempt-capped-${e.loop_item_id}`}>Attempt cap</span>` (both can render together); if
NEITHER → `<span className="text-muted">Operator</span>`.

`IncidentsPanel({incidents: IncidentRecord[]})` (:296-358): if empty → `<EmptyState icon="analytics"
headline="No open incidents" …data-testid="incidents-empty" />`. Else → a borderless table
(`data-testid="incidents-table"`, sr-only caption); header cols `Service / Error class / Source / Occurrences
/ First seen / Last seen / Tier / Triage decision`; one row per incident (`key={inc.fingerprint}`,
`data-testid={`incident-row-${inc.fingerprint}`}`): `<th scope="row">{inc.service || "—"}</th>`; error-class
`{inc.error_class || "—"}`; source `{captureSourceLabel(inc.source)}`;
`<td data-testid={`incident-count-${inc.fingerprint}`}>{inc.occurrence_count}</td>`;
`{formatWhen(inc.first_seen)}`; `{formatWhen(inc.last_seen)}`; tier `{inc.risk_tier || "—"}`;
`<td data-testid={`incident-decision-${inc.fingerprint}`}>{triageDecisionLabel(inc.triage_decision)}</td>`.

### Default export `AutonomyOps()` (:360-643)

Portfolio context (:361-362): `const { portfolios, activePortfolio, loading: portfolioLoading } =
usePortfolioContext()`.

State:
- `profileChoice: string|null` init `null` (:368) — `null` = defaulting to the active portfolio; `""` = explicit
  "All profiles"; any other string = explicit profile id (a profile id maps 1:1 to a portfolio id).
- `riskTier: string` init `""` (:369).
- `status: AutonomyStatusPage|null` init `null` (:371).
- `incidents: IncidentPage|null` init `null` (:372).
- `loading: boolean` init `true` (:373).
- `statusError: string|null` init `null` (:374).
- `incidentsError: string|null` init `null` (:375).

Effective profile resolved DURING RENDER (:380-381, no seeding effect to avoid a cascading
setState-in-effect): `activePortfolioId = activePortfolio?.id`; `effectiveProfileId = profileChoice ??
activePortfolioId ?? ""`. So an operator lands pre-filtered to the portfolio they are viewing until they make
an explicit choice.

Load effect (:383-427), deps `[effectiveProfileId, riskTier, portfolioLoading]`:
- `if (portfolioLoading) return;` — gate on portfolio readiness.
- `let cancelled = false;` guard; `return () => { cancelled = true; }`.
- `async load()`: set `loading=true`, clear both errors; build `params = {profileId: effectiveProfileId ||
  undefined, riskTier: riskTier || undefined}`.
- Fetch BOTH surfaces via `Promise.allSettled([getAutonomyStatus(params), getAutonomyIncidents({profileId:
  params.profileId})])` (:396-399) — GOTCHA: incidents is queried by profile ONLY (no riskTier). Independent
  settle so one failing does not blank the other.
- `if (cancelled) return;` after the await.
- statusResult (:401-410): fulfilled → `setStatus(value)`; rejected → `setStatus(null)` and `setStatusError`
  to `reason.message` if `reason instanceof Error` else `"Failed to load autonomy status"`.
- incidentsResult (:411-420): fulfilled → `setIncidents(value)`; rejected → `setIncidents(null)` and
  `setIncidentsError` to `reason.message` if `Error` else `"Failed to load incidents"`.
- `setLoading(false)` (:421).

Derived (:429-440): `loopPatterns = useMemo(() => status?.loop_patterns ?? [], [status])`; `escalations =
status?.open_escalations ?? []`; `incidentRows = incidents?.incidents ?? []`; `ladder =
status?.readiness_ladder ?? []`; `cappedCount = useMemo(() => loopPatterns.filter(p => p.capped).length,
[loopPatterns])`.

Early return (:442-444): `if (loading || portfolioLoading) return <OpsSkeleton />;`.

Render (:446-641), a `<section aria-labelledby="autonomy-ops-heading">`:
- `<h1 id="autonomy-ops-heading">Autonomy Operations</h1>` + a muted intro paragraph.
- **Filters** (:457-502, `data-testid="autonomy-ops-filters"`, flex-wrap gap 16 align flex-end): a Profile
  `<select id="autonomy-profile-filter" data-testid="profile-filter" value={effectiveProfileId}
  onChange={e => setProfileChoice(e.target.value)}>` with an `<option value="">All profiles</option>` then one
  `<option key={p.id} value={p.id}>{p.name}</option>` per portfolio; and a Risk-tier
  `<select id="autonomy-tier-filter" data-testid="risk-tier-filter" value={riskTier}
  onChange={e => setRiskTier(e.target.value)}>` mapping `RISK_TIER_OPTIONS` to options (`key={opt.value ||
  "all"}`). GOTCHA: changing the profile select writes `profileChoice` from `e.target.value`, so the
  displayed value is `effectiveProfileId` but the state stored is the raw select value (never `null` again
  after first change).
- **Summary counters** (:504-544, `widget-grid widget-grid--metrics`, `role="list"`): three `chart-card`
  `role="listitem"` tiles — Loop patterns (`data-testid="summary-loop-count"` = `loopPatterns.length`,
  subtitle `{cappedCount} capped by tier`); Open escalations (`data-testid="summary-escalation-count"` =
  `status?.open_escalation_count ?? escalations.length`, subtitle "awaiting human approval"); Open incidents
  (`data-testid="summary-incident-count"` = `incidents?.open_incident_count ?? incidentRows.length`, subtitle
  "from nightly triage").
- **Loop patterns section** (:546-570, `data-testid="loop-patterns-panel"`): `<h2
  id="loop-patterns-heading">`; if `statusError` → `<Alert type="error" headingLevel="h3" heading="Failed to
  load loop patterns" slim>{statusError}</Alert>` else `<LoopPatternsPanel patterns={loopPatterns} />`.
- **Open escalations section** (:572-591, `data-testid="escalations-panel"`): `<h2
  id="escalations-heading">`; if `statusError` → error Alert "Failed to load escalations" else
  `<EscalationsPanel escalations={escalations} />`. GOTCHA: escalations gate on `statusError` (they come from
  the same `/status` call), NOT on `incidentsError`.
- **Open incidents section** (:593-615, `data-testid="incidents-panel"`): `<h2 id="incidents-heading">`; if
  `incidentsError` → error Alert "Failed to load incidents" else `<IncidentsPanel incidents={incidentRows}
  />`.
- **Readiness ladder section** (:617-640, `data-testid="readiness-panel"`): `<h2 id="readiness-heading">`; if
  `statusError` → error Alert "Failed to load readiness ladder" else `<ReadinessLadder rungs={ladder} />`.

---

## pages/nl-console/NlActionConsole.tsx

Purpose (U1, W6 REQ-NL-011): the HEADLINE conversational human surface for the action engine. The human
describes an intent in plain language; the agent replies conversationally and renders its intent→action plan
inline in the thread; reversible actions execute immediately (result inline + live status from the event
bus); high-stakes actions block on a confirmation modal; gate decisions are staged for the human — the agent
NEVER decides a gate (REQ-NL-004) (:1-25). This is a NEW page: it does not alter the advisory `AgentChatPanel`
(REQ-UNAC-006 / REQ-NL-009); it consumes the extended `POST /api/v1/chat` (action mode) via
`streamAgentAction` and confirmation via `confirmChatAction`. Tiers are read off the server-returned plan; the
UI never hard-codes which actions are high-stakes (REQ-UNAC-001/003) (:19-25).

Imports (:27-51): `useCallback, useEffect, useMemo, useRef, useState` from react; `useNavigate` from
`react-router-dom`; `toast` from `sonner`; from `../../api/client` — `clearChatHistory, confirmChatAction,
getAuthToken, streamAgentAction` (funcs) and types `NlActionResponse, NlArtifactEvent, NlCapability,
NlPlannedAction`; `usePortfolioContext`; `useWebSocket` from `../../hooks/useWebSocket`; `AgentMarkdown` from
`../../components/Markdown/AgentMarkdown`; the local siblings `ActionPlanList, CapabilityGallery,
ConfirmActionModal, InlineArtifact`, `ToolActivity` (+ its `ToolActivityRow` type), and `{AgentAvatar,
SendIcon, SparkIcon}` from `./icons`; and the stylesheet `./nl-console.css`.

### Module-level helpers + types

`let confirmCounter = 0` + `newConfirmationId(): string` (:53-57): increments the module counter and returns
`` `confirm-${Date.now()}-${confirmCounter}` `` — a monotonic per-tab confirmation idempotency key.

`interface NavOffer { route: string; label: string }` (:61-64): a navigation the agent OFFERED this turn,
rendered as a click-to-go chip and NEVER auto-followed.

`interface Turn` (:67-78): one exchange — `id: string`; `userMessage: string`; `response: NlActionResponse |
null` (null until the plan arrives); `streamingReply: string` (reply text accumulating token-by-token);
`streaming: boolean` (true while tokens still arriving); `toolActivity: ToolActivityRow[]`; `artifacts:
NlArtifactEvent[]`; `navOffers: NavOffer[]`.

`navLabel(page: string|undefined, route: string): string` (:81-87): if `!page` → `` `Open ${route}` ``; else
title-cases `page` (replace `_`→space, then upper-case each word's first letter) → `` `Open ${words}` `` (e.g.
`"gate_queue"` → `"Open Gate Queue"`).

Thread persistence (:94-130): `THREAD_STORE_PREFIX = "olympus:nlc:thread:"`. `currentUserKey(): string`
(:97-106) reads `getAuthToken()`; `if (!token) return "anon"`; else JSON-parses `atob(token.split(".")[1] ??
"")` and returns `String(payload?.sub ?? "anon")`, returning `"anon"` on any throw. `threadStoreKey(contextId)`
(:108-110) = `` `${THREAD_STORE_PREFIX}${currentUserKey()}:${contextId}` `` — GOTCHA: scoped per-USER
per-portfolio so switching accounts in a shared tab never surfaces another user's conversation.
`loadTurns(contextId): Turn[]` (:112-122): reads `sessionStorage`; `if (!raw) return []`; JSON-parses to
`Turn[]` and maps each with `{...t, streaming: false}` (GOTCHA: a thread persisted mid-stream would otherwise
restore a stuck `streaming` state — this settles it); returns `[]` on any throw. `saveTurns(contextId, turns)`
(:124-130): `sessionStorage.setItem(threadStoreKey, JSON.stringify(turns))` inside try/catch (quota/serialize
failure is non-fatal). Uses `sessionStorage` (tab-scoped, survives SPA route changes + back/forward).

### Default export `NlActionConsole()` (:132-617)

Setup (:133-135): `const { activePortfolio } = usePortfolioContext()`; `const navigate = useNavigate()`;
`const contextId = activePortfolio?.id ?? "default"`.

State:
- `message: string` init `""` (:136) — composer text.
- `turns: Turn[]` init lazily `() => loadTurns(contextId)` (:139) — restored so navigating away+back keeps the
  conversation.
- `pending: NlPlannedAction|null` init `null` (:140) — the high-stakes action awaiting modal confirmation.
- `busy: boolean` init `false` (:141).
- `error: string|null` init `null` (:142).
- `threadRef = useRef<HTMLDivElement>(null)` (:143); `textareaRef = useRef<HTMLTextAreaElement>(null)` (:144).

Effects:
- (:148-150) on `contextId` change → `setTurns(loadTurns(contextId))` (each portfolio has its own thread).
- (:152-154) on `[contextId, turns]` → `saveTurns(contextId, turns)` (persist on every change).
- `sessionId = useMemo(() => turns.find(t => t.response?.session_id)?.response?.session_id ?? null, [turns])`
  (:157-160) — threads the agent's conversational state across turns.
- `useWebSocket({eventTypes: ["task.started","task.completed","task.failed","gate.ready",
  "app.status_changed"], maxEvents: 40})` → `{events, connected}` (:165-174) — live execution status;
  non-fatal if the socket is down.
- Autoscroll effect (:179-190), deps `[turns, busy]`: grabs `threadRef.current`; if it has `scrollTo` →
  `el.scrollTo({top: el.scrollHeight, behavior: "smooth"})` else set `el.scrollTop = el.scrollHeight` (jsdom /
  older engines). GOTCHA: scrolls the container itself, not `scrollIntoView` on a sentinel (unreliable inside
  a flex scroll region and can scroll the whole page). Re-pins on every token since `turns` changes.

`runMessage(raw: string)` = `useCallback` deps `[contextId, sessionId, turns.length]` (:192-329):
- `trimmed = raw.trim()`; `if (!trimmed) return;`.
- `turnId = `turn-${Date.now()}-${turns.length}``.
- Append a new Turn (`response:null, streamingReply:"", streaming:true, toolActivity:[], artifacts:[],
  navOffers:[]`); `setMessage("")`; `setBusy(true)`; `setError(null)`.
- Calls `streamAgentAction({context_type:"portfolio", context_id: contextId, message: trimmed, session_id:
  sessionId}, handlers)` (:218-326). The handlers all `setTurns(prev => prev.map(...))` matching on `t.id ===
  turnId`:
  - `onToken(text)` (:226-233): append `text` to that turn's `streamingReply`.
  - `onToolCall(tc)` (:234-252): push `{id: tc.id, name: tc.name, kind: tc.kind, status: "running"}` onto
    `toolActivity`.
  - `onToolResult(tr)` (:253-272): map the matching `toolActivity` row (by `row.id === tr.id`) to `{...row,
    status:"done", ok: tr.ok, summary: tr.summary}`.
  - `onArtifact(a)` (:273-280): push `a` onto `artifacts`.
  - `onNavigate(n)` (:281-300): `if (!n.route) return;` else push `{route: n.route, label: navLabel(n.page,
    n.route)}` onto `navOffers`. GOTCHA: NEVER auto-navigates — an unsolicited jump would unmount the
    conversation (the console is a route); surfaced as a click-to-go chip instead.
  - `onPlan(plan)` (:301-306): set that turn's `response = plan`.
  - `onDone()` (:307-315): set that turn's `streaming = false`; `setBusy(false)`; `textareaRef.current?.focus()`.
  - `onError()` (:316-324): `setError("The action engine is unavailable — your request took no action. Try
    again shortly.")`; REMOVE the turn (`prev.filter(t => t.id !== turnId)`); `setBusy(false)`; refocus.

`submit = useCallback(() => void runMessage(message), [message, runMessage])` (:331).

`confirmAction(turnId, action: NlPlannedAction)` = async `useCallback` deps `[turns]` (:336-376):
- `turn = turns.find(t => t.id === turnId)`; `if (!turn?.response) return;`; `plan = turn.response`.
- `setBusy(true)`; try: `resp = await confirmChatAction({session_id: plan.session_id, intent_id:
  plan.intent_id, intent_text: plan.intent_text, action_seq: action.seq, action_id: action.action_id,
  action_params: action.params, confirmation_id: newConfirmationId()})`; `updated = resp.actions[0]`; then
  `setTurns` replacing the matching turn's action (by `a.seq === action.seq && updated`) with `updated`;
  `toast.success(`${action.label} confirmed and run.`)`.
- catch: `toast.error(`Could not run ${action.label}.`)`. finally: `setPending(null)`; `setBusy(false)`.
- GOTCHA (:333-335): only reached from the modal's explicit Confirm click — the action does not execute until
  the human confirms (REQ-UNAC-003).

`useExample = useCallback((example) => { setMessage(example); textareaRef.current?.focus(); }, [])` (:378-384)
— drops a suggested phrasing into the composer.

`clearConversation = useCallback(() => {...}, [contextId])` (:391-399): `setTurns([])`; `setError(null)`; fire
`clearChatHistory("portfolio", contextId, "nl-action")` best-effort (`.catch(()=>{})`); refocus. GOTCHA
(:386-390): clears BOTH the local thread (the persistence effect wipes sessionStorage) AND the backend
nl-action transcript the agent replays for memory; the backend clear is best-effort (a viewer lacks the role),
the local reset always happens.

`hasThread = turns.length > 0` (:401).

Render (:403-616), a `<section className="nlc" aria-label="Action console" data-testid="nl-console">` (a
labelled region, NOT `<main>` — Layout owns the single `<main>`, :404):
- **Hero** (:410-441): `AgentAvatar` badge, title "Action Console", a sub description. Actions:
  when `hasThread`, a `nlc__new-convo` button → `clearConversation`; a live indicator
  `nlc__live is-live|is-offline` (from `connected`) with a dot + "Live"/"Offline" text.
- **Error banner** (:443-447): when `error` → `<div className="nlc__error" role="alert"><strong>No action
  taken.</strong> {error}</div>`.
- **Thread** (:449-545, `data-testid="nl-thread"`, `ref={threadRef}`): if `!hasThread` → `<CapabilityGallery
  onPickExample={useExample} />`; else `<ol className="nlc__turns">` one `<li>` per turn:
  - user bubble `nlc__msg nlc__msg--user` with `{turn.userMessage}`.
  - agent bubble `nlc__msg nlc__msg--agent` with a small `AgentAvatar` and a body containing, in order:
    (a) `<ToolActivity rows={turn.toolActivity} />` when `toolActivity.length > 0`;
    (b) reply block (:474-492): if `turn.streamingReply || turn.response` → `<div className="nlc__reply"
    data-testid="nl-reply"><AgentMarkdown>{turn.response ? (turn.response.reply || turn.response.summary) :
    turn.streamingReply}</AgentMarkdown>` plus, when `turn.streaming && !turn.response`, a blinking
    `nlc__cursor`; ELSE a `nlc__thinking` block (`aria-live="polite"`, three dots + "Thinking…");
    (c) inline artifacts (:496-501): `turn.artifacts.map((a,i) => <InlineArtifact
    key={`${turn.id}-artifact-${i}`} artifact={a} />)`;
    (d) nav offers (:505-523): when `navOffers.length > 0`, a `<ul className="nlc__nav-offers"
    data-testid="nl-nav-offers">` of buttons, each `onClick={() => navigate(nav.route)}` with a 🧭 glyph, the
    label, and a `→` arrow;
    (e) capability chips (:525-531): when `turn.response?.capabilities?.length > 0` → `<CapabilityChips
    capabilities={turn.response.capabilities} onPick={useExample} />`;
    (f) plan (:532-538): when `turn.response` → `<ActionPlanList actions={turn.response.actions}
    liveEvents={events} onRequestConfirm={(a) => setPending(a)} />`.
- **Composer form** (:547-601): `onSubmit` preventDefault → `submit()`. An sr-only label, a `nlc__composer-shell`
  with a `SparkIcon`, a `<textarea id="nl-console-input" ref={textareaRef}>` bound to `message` with a
  context-sensitive placeholder (follow-up prompt when `hasThread`, else an onboarding example), `rows={1}`,
  `disabled={busy}`, and `onKeyDown` where Enter (without Shift) preventDefaults and calls `submit()` while
  Shift+Enter inserts a newline (:572-578). A submit button `disabled={busy || !message.trim()}`
  `aria-label="Plan and run"` showing a spinner + "Working…" when busy else `SendIcon` + "Plan & run". A hint
  line "Reversible actions run immediately · high-stakes actions ask first · gate decisions are staged for
  you".
- **Confirmation modal** (:603-614): when `pending` → `<ConfirmActionModal action={pending}
  onConfirm={...} onCancel={() => setPending(null)} />`. `onConfirm` finds the turn whose response contains an
  action with `a.seq === pending.seq` and, if found, calls `confirmAction(turn.id, pending)`.

### Sub-component in this file — `CapabilityChips` (:620-644)

`CapabilityChips({capabilities: NlCapability[], onPick: (example)=>void})`: renders `<ul className="nlc__cap-chips"
data-testid="nl-capabilities">`, one `<li key={cap.action_id}>` per capability with a button
`onClick={() => onPick(cap.example)}` `title={cap.description}` showing `cap.label` and a "Try it →" span.
These are the AUTHORITATIVE server-provided capabilities (REQ-NL-012), rendered inside an agent reply.

---

## pages/nl-console/ActionPlanList.tsx

Purpose (U1 REQ-UNAC-001/002): renders the agent's intent→action plan as live action cards (:1-17). Tier is
read straight off the server-returned plan — the UI never hard-codes which actions are high-stakes (:15-17).

Imports (:19-28): type `ReactElement`; `RealtimeEvent` from `../../types/api`; types `NlActionStatus,
NlPlannedAction` from `../../api/client`; icons `CheckIcon, GateIcon, HighStakesIcon, ReversibleIcon` from
`./icons`; `StagedGateCard` from `./StagedGateCard`.

Props `ActionPlanListProps` (:30-34): `actions: NlPlannedAction[]`; `onRequestConfirm: (action) => void`;
`liveEvents?: RealtimeEvent[]`.

`interface TierMeta { text; icon: ReactElement; cls }` (:36-40). `tierMeta(tier)` (:42-60): `"high_stakes"` →
`{"High-stakes", <HighStakesIcon>, "is-highstakes"}`; `"gate_decision"` → `{"Gate · you decide", <GateIcon>,
"is-gate"}`; else (reversible) → `{"Reversible", <ReversibleIcon>, "is-reversible"}`. Meaning by icon+text,
never colour alone (REQ-UNAC-007).

`STATUS_TEXT: Record<NlActionStatus,string>` (:62-70): `planned:"Planned", executed:"Done",
awaiting_confirmation:"Needs confirmation", staged:"Staged for you", needs_input:"Needs details",
denied:"Not authorised", failed:"Failed"`.

`resultId(action): string|null` (:72-77): `r = action.result`; `if (!r) return null`; `id = r.workflow_id ??
r.id ?? r.app_id ?? r.portfolio_id`; return `id ? String(id) : null`. `resultText(action): string|null`
(:79-88): `if (!r) return null`; if `resultId` → `` `Result: ${id}` ``; else if `action.status === "denied"`
→ `` `Denied (403): ${String(r.detail ?? "not authorised")}` ``; else `null`.

`liveStatusFor(action, events)` (:95-114): `if (!events || events.length === 0) return null`; `id =
resultId(action)`; `if (!id) return null`; iterate `events`, for each match where `Object.values(ev.payload
?? {}).some(v => String(v) === id)`: `"task.completed"` → `{"Completed","done"}`; `"task.failed"` →
`{"Failed","failed"}`; `"task.started"` → `{"Running…","running"}`; `"gate.ready"` → `{"Gate ready","done"}`;
returns first match, else `null`. Best-effort enrichment on top of the plan's authoritative result.

Default export `ActionPlanList({actions, onRequestConfirm, liveEvents})` (:116-213): `if (actions.length ===
0) return null;` → `<ol className="nlc-plan" aria-label="Proposed action plan" data-testid="nl-plan">`. Per
action (`key={action.seq}`): compute `tm = tierMeta(action.tier)`, `result = resultText(action)`, `live =
liveStatusFor(action, liveEvents)`, `executed = action.status === "executed"`, `running = live?.tone ===
"running"`. `<li className={`nlc-card ${tm.cls} status-${action.status}${running ? " is-running" : ""}`}
data-testid="nl-plan-item">` containing:
- an `aria-hidden` `nlc-card__bar`;
- head (:140-149): label span + a tier span (`data-testid={`nl-tier-${action.action_id}`}`) with `tm.icon` +
  `tm.text`;
- status row (:151-171): a status span (`data-testid={`nl-status-${action.action_id}`}`) with a `CheckIcon`
  when `executed`, an `usa-sr-only` machine `action.status`, and an `aria-hidden` humanized
  `STATUS_TEXT[action.status] ?? action.status`; plus, when `live`, a `nlc-card__live--{tone}` pill with a dot
  + `live.label`;
- result line (:173-180): when `result` → `<p data-testid={`nl-result-${action.action_id}`}>{result}</p>`;
- awaiting-confirmation block (:182-196): when `action.status === "awaiting_confirmation"` → optional
  `explanation` paragraph + a "Review & confirm" button (`data-testid={`nl-confirm-open-${action.action_id}`}`)
  → `onRequestConfirm(action)`;
- needs-input note (:198-202): when `status === "needs_input" && action.explanation` → a paragraph
  (`data-testid={`nl-needs-${action.action_id}`}`);
- staged gate (:204-206): when `status === "staged"` → `<StagedGateCard action={action} />`.

---

## pages/nl-console/CapabilityGallery.tsx

Purpose (:1-14): the inviting EMPTY state for the console — answers "what can this do?" so the human never
faces a blank box. Clickable example cards drop their phrasing into the composer. These are a discovery
affordance for the empty state; the AUTHORITATIVE list comes from the server (REQ-NL-012) and renders as chips
inside the agent's reply.

Imports (:16-21): `GateIcon, HighStakesIcon, ReversibleIcon, SparkIcon` from `./icons`.

`interface GalleryItem {title; blurb; example; kind: "reversible"|"high_stakes"|"gate"}` (:23-28).

`ITEMS: GalleryItem[]` (:32-69) — six hard-coded representative items:
1. "Onboard an application" / "Register a new app so it can move through the assembly lines." / "Onboard an
   app called Billing Gateway" / `high_stakes`.
2. "Start Discovery" / "Kick off the first line that analyzes an app's codebase." / "Start Discovery for the
   Billing Gateway app" / `reversible`.
3. "Start an assembly line" / "Run a specific line — Architecture, Modernization, and more." / "Start the
   architecture line for app 42" / `reversible`.
4. "Retry a failed step" / "Pick a stuck pipeline step back up from where it failed." / "Retry the failed
   generate step for app 42" / `reversible`.
5. "Dispatch a skill" / "Run a single skill ad-hoc against an application." / "Dispatch the code-review skill
   for app 42" / `reversible`.
6. "Stage a gate decision" / "I explain the evidence and the authority needed — you decide." / "Help me decide
   gate G-DC for app 42" / `gate`.

`TierGlyph({kind})` (:71-75): `high_stakes` → `<HighStakesIcon className="nlc-gallery__glyph" />`; `gate` →
`<GateIcon …>`; else `<ReversibleIcon …>`. `tierLabel(kind)` (:77-81): `high_stakes` → "Confirms first";
`gate` → "You decide"; else "Runs now".

Default export `CapabilityGallery({onPickExample})` (:87-121): `<div className="nlc-gallery"
data-testid="nl-capability-gallery">` with an intro (`SparkIcon` + a paragraph nudging `"what can you do?"`
for the full list), then a `nlc-gallery__grid` mapping `ITEMS` to `<li key={item.title}>` buttons
(`className={`nlc-gallery__card nlc-gallery__card--${item.kind}`}`, `onClick={() =>
onPickExample(item.example)}`) each showing `TierGlyph` + `tierLabel`, title, blurb, and the quoted example.

---

## pages/nl-console/ConfirmActionModal.tsx

Purpose (U1 REQ-UNAC-003, LOAD-BEARING): a high-stakes / irreversible action (per the SERVER-driven tier)
MUST NOT execute until the human explicitly confirms here; cancelling leaves it unexecuted. The modal traps
focus, is Esc-dismissible, and conveys the distinction by icon+text (REQ-UNAC-007) (:1-14). It NEVER triggers
execution itself — only reports the decision via `onConfirm`/`onCancel`; the parent calls `confirmChatAction`.

Imports (:16-18): `useCallback, useEffect, useRef`; `Button` from `@trussworks/react-uswds`; type
`NlPlannedAction`. Props (:20-24): `action: NlPlannedAction`; `onConfirm: () => void`; `onCancel: () => void`.

Default export `ConfirmActionModal({action, onConfirm, onCancel})` (:26-120):
- Refs `dialogRef` (:31) and `confirmRef` (:32).
- Mount effect (:35-37): `confirmRef.current?.focus()` — focus-trap entry point (focuses the Confirm button).
- `onKeyDown = useCallback` deps `[onCancel]` (:40-65): `"Escape"` → `e.stopPropagation()` + `onCancel()`;
  `"Tab"` → query `dialogRef` for focusables (`button, [href], input, select, textarea, [tabindex]:not(
  [tabindex="-1"])`); if none, bail; wrap focus (Shift+Tab on `first` → `last.focus()`; Tab on `last` →
  `first.focus()`), preventing default in each wrap case. GOTCHA: manual focus trap.
- Render: overlay `<div className="nl-modal-overlay" role="presentation" onClick={...}>` where a click whose
  `e.target === e.currentTarget` (the backdrop) cancels (:67-75); an inner `<div ref={dialogRef} role="dialog"
  aria-modal="true" aria-labelledby="nl-confirm-title" aria-describedby="nl-confirm-desc" className="nl-modal"
  onKeyDown={onKeyDown}>` (:76-84) containing: a title `<h2 id="nl-confirm-title">` with an `aria-hidden` "⚠️ "
  glyph + "Confirm high-stakes action"; a description `<p id="nl-confirm-desc">` = `<strong>{action.label}
  </strong> is a high-stakes action and will not run until you confirm.` + (when `action.explanation`) a space
  + the explanation (:90-94); a `<dl className="nl-modal__params">` mapping `Object.entries(action.params ??
  {})` to `<div key={k}><dt>{k}</dt><dd>{String(v)}</dd></div>` (:95-102); and actions (:103-116): a `Button`
  (outline) "Cancel" → `onCancel`, and a `<button ref={confirmRef} className="usa-button usa-button--secondary"
  onClick={onConfirm} data-testid="nl-confirm-execute">Confirm & run</button>`.

---

## pages/nl-console/StagedGateCard.tsx

Purpose (U1 REQ-UNAC-004, LOAD-BEARING): the agent STAGES and EXPLAINS a gate decision; a HUMAN decides it.
This card renders the explanation and offers a single human control routing to the EXISTING gate-decision
screen — it exposes NO agent-approve/agent-reject control (W6 REQ-NL-004) (:1-11).

Imports (:13-15): `Link` from `react-router-dom`; `Tag` from `@trussworks/react-uswds`; type
`NlPlannedAction`. Props (:17-19): `action: NlPlannedAction`.

Default export `StagedGateCard({action})` (:21-59): `gateId = String(action.params?.gate_id ?? "")` (:22).
Renders `<section className="nl-staged-gate" aria-label="Staged gate decision"
data-testid="nl-staged-gate">`: a header `<Tag>` with an `aria-hidden` "🔒 " + "Staged for your decision"; an
`<h3>{action.label}</h3>`; an explanation `<p>` = `action.explanation ?? "I have staged this gate and can
explain the evidence, but I will not decide it. A human must decide."`. Then the ONLY control (:44-56): if
`gateId` → `<Link to={`/gates/${gateId}/review`} className="usa-button"
data-testid="nl-gate-human-decide">Review & decide (human)</Link>`; else a fallback `<p className="nl-staged-
gate__nolink">Open the gate queue to review and decide.</p>`. GOTCHA: deliberately NO approve/reject button —
the agent never decides a gate.

---

## pages/nl-console/ToolActivity.tsx

Purpose (W6 agent endpoint): the compact tool-use timeline for one agent turn — renders each read/navigate
tool the agent invoked (`tool_call`) and its outcome (`tool_result`) as a live ordered timeline so the human
watches the agent reason before the plan resolves (:1-12). Accessibility: `aria-live="polite"`; status by
icon+text, never colour alone (REQ-UNAC-007).

`export interface ToolActivityRow` (:15-22): `id: string`; `name: string`; `kind: "read"|"navigate"`; `ok?:
boolean`; `summary?: string`; `status: "running"|"done"`.

`kindIcon(kind)` (:24-26): `"navigate"` → `"🧭"`, else `"🔍"`.

Default export `ToolActivity({rows: ToolActivityRow[]})` (:28-78): `if (rows.length === 0) return null;` → `<ul
className="nlc-tools" aria-live="polite" aria-label="Agent activity" data-testid="nl-tool-activity">`. Per row:
`running = row.status === "running"`; `failed = row.status === "done" && row.ok === false`. `<li
key={row.id} className="nlc-tools__row" + (running?" is-running":"") + (failed?" is-failed":"")
data-testid={`nl-tool-${row.id}`} data-status={row.status}>` with an `aria-hidden` `kindIcon` span, a
`nlc-tools__name` = `row.name`, then: if `running` → a `nlc-tools__state--running` block with a spinner +
"Working…"; else a state block (adding `nlc-tools__state--failed` when `failed`) with an `aria-hidden` mark
(`"✕"` if failed else `"✓"`) + `row.summary ?? (failed ? "Couldn't complete" : "Done")`.

---

## pages/nl-console/InlineArtifact.tsx

Purpose (:1-14): renders an artifact the agentic stream surfaced (`event: artifact`) INLINE in the
conversation, reusing the SAME gate-review viewer library the Artifacts tab and gate-review cards use — no new
viewer code; unknown types fall back gracefully via the registry + `ViewerErrorBoundary`.

Imports (:16-17): type `NlArtifactEvent` from `../../api/client`; `ArtifactViewer` from
`../../components/viewers/ViewerRegistry`.

Default export `InlineArtifact({artifact: NlArtifactEvent})` (:19-47): `artifactType = artifact.artifact_type
?? "file_artifact"` (:20); `data = artifact.content ?? {}` (:21); `schemaVersion = (data.schema_version as
string|undefined) ?? "1.0"` (:22). Renders `<figure className="nlc-artifact" data-testid="nl-artifact">`: when
`artifact.artifact_path` → a `<figcaption>` with an `aria-hidden` 📄 icon + the path; then `<div
className="nlc-artifact__body"><ArtifactViewer artifactType={artifactType} data={data} metadata={null}
schemaVersion={schemaVersion} appId={artifact.app_id} /></div>`. The `ArtifactViewer` dispatcher resolves the
viewer by `artifactType` (falling back to `GenericStructuredViewer`) wrapped in a `ViewerErrorBoundary`, so a
malformed agent payload degrades to a friendly fallback instead of crashing the thread.

---

## pages/nl-console/icons.tsx

Purpose (:1-8): hand-rolled inline SVG icons for the console (the dashboard convention — see `Layout.tsx`) so
glyphs inherit theme colours via `currentColor` and recolour in dark mode, unlike emoji. All are `aria-hidden`
— tier/status meaning is always carried by adjacent text too (REQ-UNAC-007). `interface IconProps { className?:
string }` (:10-12).

Exports:
- `AgentAvatar({small = false})` (:15-42): a hexagon + spark brand mark; `size = small ? 28 : 44`; a
  `viewBox="0 0 44 44"` `<svg className="nlc-agent-avatar" aria-hidden>` with a filled hexagon (`fill="var(--
  olympus-teal)" opacity="0.14"`), a stroked hexagon (`stroke="var(--olympus-teal)"`), and a four-point spark
  (`fill="var(--olympus-cyan)"`). GOTCHA: takes a `{small}` prop object, NOT `IconProps`.
- `SparkIcon({className})` (:44-60): a 24×24 four-point spark, `fill="currentColor"`.
- `SendIcon({className})` (:62-81): a 24×24 paper-plane, `stroke="currentColor" strokeWidth="2"` no fill.
- `ReversibleIcon({className})` (:84-103): a circular-arrow (reversible-tier) glyph, stroked `currentColor`.
- `HighStakesIcon({className})` (:106-126): a shield-alert (high-stakes) glyph — shield outline + exclamation
  stroke + a filled dot.
- `GateIcon({className})` (:129-156): a padlock (gate/human-decides) glyph — a rounded rect body + a shackle
  arc.
- `CheckIcon({className})` (:158-177): a 24×24 checkmark, `stroke="currentColor" strokeWidth="2.4"`.

---

*(Component library begins in Part 2.)*
