# 07b — The Profile System (companion to 07-framework.md)

> Reproduces ALL 4 profiles FULLY — every override key across every YAML and its EFFECT — plus load/overlay mechanics,
> the CAN-vs-CANNOT-override matrix, and the client-agnostic (cATO/OSCAL) blocker status. Derived from live YAML +
> `olympus-api/src/services/profile_loader.py` + `profile_activation.py` + `registries/profile_overrides.py`.
> Read **07-framework.md** first (engine, registries, autonomy).

Profile bundles live at `profiles/<id>/`. **VERIFIED file inventory (live `ls`, 2026-07-03):**

| Profile | YAML count | Files |
|---|---|---|
| **faa** | **11** | profile, compliance, risk-classification, gates, scoring, technology, **autonomy**, **nl-action-policy**, **delegation**, **wave-planning**, objectives (+ dirs: skills/, templates/, branding/, baselines/, config/, context-priors/, regulatory-knowledge/) |
| **vba** | **7** | profile, compliance, risk-classification, gates, scoring, technology, objectives |
| **baseline** | **7** | profile, compliance, risk-classification, gates, scoring, technology, objectives |
| **test-generic** | **13** | profile, compliance, risk-classification, gates, scoring, technology, **autonomy**, **nl-action-policy**, **catalog**, **decomposition**, **drift**, **feedback**, objectives |

> GOTCHA — objectives.yaml is present in all four but is NOT one of the loader's 6 required files (§4). The prompt's
> stated "faa 11 / vba 7 / baseline 7 / test-generic 13" matches the live count exactly (objectives counted).

---

## 1. The load model — what the loader parses & validates (`profile_loader.py`)

`load_profile(profile_root)` (`profile_loader.py:633-684`):
1. Require directory + **all 6 files present** (`_EXPECTED_FILES = profile.yaml, compliance.yaml,
   risk-classification.yaml, gates.yaml, scoring.yaml, technology.yaml`, `:301-308`). Missing → `ProfileLoadError`
   (silent partial loads forbidden, DECISION-010).
2. `_read_yaml` each (must be a top-level mapping) → `_load_metadata` → **`_validate_declared_cardinality`** →
   `_load_compliance` → `_load_risk_classification` → `_load_gates` → `_load_scoring` → `_load_technology`.
3. Return a **frozen** `Profile` dataclass (`:275-293`) with typed sub-records + `raw_profile_yaml` (the raw `profile:`
   dict, preserved for dashboard introspection of unenumerated fields).

**Validations enforced at load:**
- Risk tiers: `set(tiers.keys()) == {tier_1, tier_2, tier_3}` exactly (`:395-400`); tiers built in **canonical order
  tier_1→tier_2→tier_3 regardless of YAML ordering** (`:404`).
- Scoring: each dimension has `name` + `weight`; `weight ∈ [0,1]`; **sum ≈ 1.0 (abs_tol 1e-3)** or `ProfileLoadError`
  (`:520-547`).
- Gates: `overrides` must be a mapping; **every override key must be a canonical gate id** (`:439-451`); an explicit
  `gate_records`/`gate_ids` set must equal the canonical set exactly (`:453-472`); reads `profile_additions` with
  `faa_additions` fallback (`:477-481`).
- Cardinality (`_validate_declared_cardinality`, `:575-630`): a profile MAY declare `profile.dispositions` and
  `profile.assembly_lines`/`profile.lines`, but every value must be in the canonical set (case-insensitive); else
  `ProfileLoadError`. When neither key is declared, the guard is a no-op.

**Typed sub-records** (all frozen): `ProfileMetadata` (`:114-131`), `Compliance` (loose `domains` dict — the core does
NOT cap the domain list, `:133-147`), `RiskClassification`/`RiskTier` (`:149-178`), `Gates`/`GateOverride` (`:181-223` —
`GateOverride.faa_additions` is a deprecated property alias for `profile_additions`), `Scoring`/`ScoringDimension`
(`:226-254`), `Technology` (loose, `:257-272`).

### Activation & overlays (`profile_activation.py` + `profile_overrides.py`)
- `activate_profile(profile_id=None, *, profile_root=None)` (`profile_activation.py:50-111`): resolves via explicit
  `profile_root` → `profile_id`+`OLYMPUS_PROFILES_DIR`/path-walk (`discover_profile_root`, `profile_loader.py:692-728`)
  → `OLYMPUS_PROFILE` env. If none resolvable → registries stay at defaults, returns None (correct for tests/dev).
  Loads the profile, then under a lock calls `apply_profile(profile)` and caches `_ACTIVE_PROFILE`. **Unknown profile →
  `ProfileActivationError` (never silent default.)** Repeated calls are safe (registries idempotent).
- `deactivate_profile()` (`:114-127`): `reset_registries_to_defaults()` + clear cache (used on switch to `default`).
- **How overlays apply**: `apply_profile` (see 07-framework.md §3) is the single seam — it maps the loaded `Profile`
  through the duck-typed Protocols into (a) `scoring.replace_all` (re-validates sum), (b) `gate_providers.set_default`
  + per-gate `set_gate_overrides`, (c) a `"<id>-profile-skills"` `SkillComposition` if the profile ships skills.
  **`profile.yaml`'s `inherits`/`overlays` fields are parsed into `ProfileMetadata` but all 4 shipped profiles set
  `inherits: null, overlays: []`** — no profile currently layers over another; the fields are declared for future use.

---

## 2. What a profile CAN vs CANNOT override

| CAN override (DATA) | CANNOT override (HARD core constant) |
|---|---|
| Risk-tier **labels, definitions, examples, per-tier parameters** | Risk-tier **count (3) and keys** `tier_1/tier_2/tier_3` (loader requires exactly these, `:395-400`) |
| **Scoring-dimension weights** (must sum to 1.0) + rationale/data_source | Adding/removing a **gate** — the 18 `GateType` ids are fixed (`:439-451`) |
| **Gate criteria additions** (`profile_additions`), **reviewer overrides**, **rbac blocks**, **SLAs**, **additional_roles** | Adding/removing a **disposition** — the 8 `Disposition` ids are fixed (`:590-607`) |
| **Default gate provider** + per-gate provider overrides | Adding/removing an **assembly line** — the 11 `AssemblyLine` ids are fixed (`:609-630`); Build is registry-additive, not profile-declarable |
| **Compliance domains** (arbitrary — core does not cap the list), **control catalog**, framework, artifact format | The registry **substrate/engine** and the **≤6 extension-point** invariant (DECISION-010) |
| **Technology stack** (loose schema), branding, deployment targets, devsecops baseline | The **autonomy ladder rungs** `{report_only,assisted,unattended}` and the **fail-closed default** (`report_only`) |
| **Profile skills/templates** (bundled into a `"<id>-profile-skills"` composition) | Enum→string flexibility: the domain enums stay hard (no enum→varchar migration for these) |
| **Autonomy policy** (tier_caps, denylist, allowlist, attempt_cap) — DATA (schema-validated) | The `autonomy_level` gate is NOT a `GateType` member (advisory) — a profile cannot promote it to a standard gate |
| **NL-action tiering** (which actions are reversible vs high_stakes) — DATA, not code | The `gate_decision` posture `agent_may_approve: false` is honored regardless of profile |
| **Objectives** (KPIs, targets), **wave-planning**, **delegation**, **drift/decomposition/catalog/feedback** thresholds | |

The cardinality guard is enforced at BOTH the API loader (`profile_loader.py`) and the worker boot path
(`worker_bootstrap.py:139-236`) — re-derived from the same frozen `olympus_contracts` enums so they cannot diverge.

### The client-agnostic (cATO/OSCAL) blocker — current status
- **Control catalog: RESOLVED (profile-driven).** `olympus-api/src/services/compliance_pack.py` reads the control
  catalog, framework, and artifact format from the **active profile's `compliance.security` block** at runtime
  (`compliance_pack.py:1-18`). The FAA controls now live in `profiles/faa/compliance.yaml` (11 NIST 800-53 controls,
  §3.1 below); a profile with no catalog yields an **empty** catalog, NOT FAA's. Fallbacks (`_FALLBACK_FRAMEWORK =
  "NIST 800-53 Rev 5"`, `_FALLBACK_ARTIFACT_FORMAT = "generic"`, `:28-30`) are agency-neutral and used only when no
  profile is active. `evidence_emit.py:161` consumes `active_compliance_pack()`.
- **OSCAL format/pipeline: still core-resident.** The OSCAL export/evidence machinery lives in core
  (`olympus-api/src/services/evidence_oscal.py`, `evidence_export.py`, routers `governance.py`, `evidence_ledger.py`,
  `evidence_runs.py`); the *artifact format* is a profile string (`compliance.security.artifact_format`,
  `CompliancePack.is_oscal` at `compliance_pack.py:52-55`), but the OSCAL 1.1.2 serialization is not itself
  profile-pluggable. **VBA inherits from FAA the shared OSCAL evidence pipeline and the cATO view shell**, but supplies
  its OWN control catalog/framework via its profile (VBA declares NIST 800-53 Rev 5 + OSCAL + VA Handbook 6500 + FedRAMP
  Moderate; no `control_catalog` list → empty, so it does NOT inherit FAA's SF3 controls). The residual blocker is that
  the OSCAL *pipeline* and the evidence models are core concern #11, not fully profile-swappable.

---

## 3. FAA profile — FULLY reproduced (11 YAMLs)

### 3.1 `profile.yaml` (metadata + activation)
`id: faa`, `name: "Federal Aviation Administration"`, `version: 1.0.0`. `organization` (parent DOT, sector Federal
Transportation). `portfolio`: estimated_size 200, estimated_databases 3000, program_duration "10 years", primary_concern
"NAS safety". `extensions` map: compliance/risk_classification/gates/scoring/technology/wave_planning/objectives →
respective files. `skills` (9): faa-code-standards, faa-style-greenfield, faa-style-brownfield,
pilot-certification-domain-modeler, faa-form-schema-generator, aerospace-medical-certification-mapper,
form-8710-validator, medxpress-confirmation-binder, ame-decision-workflow-scaffolder. `templates` (4): safety-case,
nas-impact-assessment, ato-decommission, security-safety-crosswalk. `branding: "branding/"`. `deployment`: target
"Tyrion Container Platform", cloud "AWS GovCloud (EKS)". `devsecops`: sast_tool codeql, sbom_required true,
container_base distroless, license Apache-2.0, target_cloud aws, primary_ecosystem python, iac terraform, cicd
github-actions, branch_protection (require_status_checks [lint,test,build,sast,sca,image-scan],
require_review_from_codeowners true, require_signed_commits true). `inherits: null`, `overlays: []`. `mission_context`
(path to SOO GFI — inert in this GFI-free repo, fail-soft). `agent_dispatch`: default_provider bedrock-claude,
default_tier tier-2, **require_fedramp_provider true** (a non-FedRAMP provider is REJECTED at selection, never
downgraded).

### 3.2 `risk-classification.yaml` — "NAS Safety Tiering"
- **tier_1 "NAS Safety-Critical"** — directly impacts NAS ops. parameters: traceability_forward/backward 0.99,
  test_coverage_overall 0.90, test_coverage_domain 0.95, parallel_run_days 90, parallel_run_monitoring continuous,
  deployment_strategy **canary**, traffic_shift "5→25→50→100% over 14 days", rollback_window_days 30, **ivv_required
  true, safety_case_required true, safety_board_review true**, model_tier tier_1 (force reasoning models),
  security_safety_crosswalk true, nas_impact_assessment true, stakeholder_confirmation true.
- **tier_2 "Mission Support"** — traceability 0.98, coverage 0.80/0.95, parallel_run_days 30, blue_green, instant
  switch, rollback 14, all safety flags false, model_tier default.
- **tier_3 "Administrative"** — traceability 0.98, coverage 0.80/0.95, parallel_run_days 14, parallel_run_monitoring
  **sampling**, blue_green, rollback 7, all safety flags false.
- `signals` (8 auto-classification rules → tier + confidence), `override_rules` (4, e.g. "reads/writes NAS operational
  DBs must be T1 minimum" enforced; "T1 requires Safety Board confirmation before Discovery" enforced; "downgrade from
  T1 requires justification + Safety Board approval" enforced; read-only T1 access advisory not-enforced).

### 3.3 `gates.yaml` — override keys & effects
`profile: faa`, `default_provider: github-pr`. **8 gate overrides** — each key is a `profile_additions` list of
`{check, description, applies_to, automated}` + optional `reviewer_override` + `rbac`:
- **G-DC**: +nas_interface_inventory (tier_1, automated), +stakeholder_business_criticality (tier_1, manual);
  reviewer_override tier_1 [portfolio_manager, safety_board_liaison]; rbac roles [portfolio_manager,
  safety_board_liaison], min_approvals 1.
- **G-DA**: +faa_issm_security_review (retire,replace, manual); reviewer_override retire/replace [+faa_issm]; rbac
  [portfolio_manager, faa_issm] min 1.
- **G-02**: +faa_ea_review_board (tier_1, manual); reviewer_override tier_1 [arch_lead, faa_ea_review_board]; rbac min 1.
- **G-04b**: +swim_solace_integration (nas_facing, automated), +gravitee_api_gateway (external_api, automated).
- **G-04c**: +faa_code_standards, +faa_security_headers, +twelve_factor_compliance (all, automated).
- **G-V2**: +cato_oscal_package (all, automated), +faa_order_1370_121 (all, automated); rbac [compliance_lead] min 1
  (management_override_allowed defaults true — profile MAY set false).
- **G-V3**: +nas_impact_assessment (tier_1, manual), +safety_case_review (tier_1, manual), +security_safety_crosswalk
  (tier_1, automated); reviewer_override tier_1 [safety_board, compliance_lead]; **rbac min_approvals 2, oversight_role
  compliance_lead, management_override_allowed FALSE (non-overridable safety gate).**
- **G-DP-2**: +ato_decommission_certificate (retire, manual), +data_archival_verification (retire, automated);
  reviewer_override retire [operations_lead, portfolio_manager, faa_issm]; rbac min 1.
- `additional_roles` (3): faa_issm, faa_ea_review_board, safety_board_liaison (each with description + permissions).
- `sla` (hours): tier_1 24/48, tier_2 48/72, tier_3 72/96 (critical_path/standard).

### 3.4 `scoring.yaml` — dimension weight overrides (must sum to 1.0)
| dimension | FAA weight | default | effect |
|---|---|---|---|
| code-quality | **0.15** | 0.20 | reduced — legacy apps old but functional |
| test-coverage | 0.15 | 0.15 | unchanged |
| security-posture | **0.25** | 0.20 | elevated — FAA Order 1370.121 |
| documentation | 0.10 | 0.10 | unchanged |
| dependency-currency | **0.10** | 0.15 | reduced — FAA-approved versions lag |
| architecture-clarity | **0.25** | 0.20 | elevated — shared-DB complexity |
Sum = 1.00. `total_weight: 1.0`; 4 notes.

### 3.5 `technology.yaml`
Keys/values: `infrastructure` (api_gateway **Gravitee mandatory**, identity OKTA SAML/OIDC, compute AWS Lambda[primary
Tyrion]/AWS EKS, container_platform Tyrion (AWS EKS), iac Terraform, cicd GitHub Actions, monitoring Datadog, gitops
ArgoCD on Tyrion). `data` (legacy Oracle ~3000; modern Aurora PostgreSQL[primary]/DynamoDB; migration
per-app/bounded-context, shared_db_handling strangler-fig/db-per-service). `messaging` (nas **Solace PubSub+ / SWIM**;
modern EventBridge, SNS/SQS). `document_management` (Alfresco, SharePoint/OneDrive). `low_code` (PowerApps, PowerBI,
UiPath). `modernization_targets` (java_ee→Spring Boot; coldfusion→Python/FastAPI|Node; **dotnet→Node.js/TypeScript
Lambda** with target_framework express/target_frontend react/target_runtime AWS Lambda; batch_etl→Step
Functions/Lambda/ECS; cobol→Python/FastAPI|Java copybook-first). `phase3_prototype` (TS/Node 20/Lambda/Express+CDK;
React+USWDS; Aurora PG; Cognito; Temporal; EventBridge; GitHub Actions). `platform_requirements` (gitops, OCI containers,
cloud_native, twelve_factor, trunk_based_development, devsecops, automation — all true).

### 3.6 `compliance.yaml` — 5 domains + control catalog + regulatory knowledge
- **accessibility**: WCAG 2.1 AA (federal_minimum WCAG 2.0 AA), USWDS + FAA Design System overlay, axe-core +
  JAWS/NVDA (Tier 1), 6 enforcement points, requirements (semantic_html, keyboard_navigation, color_contrast 4.5/3.0,
  alt_text, touch_targets_min 44, screen_reader, responsive, viewport_meta).
- **security**: framework NIST 800-53 Rev 5, artifact_format **OSCAL 1.1.2**, additional_standards [FAA Order
  1370.121]. **`control_catalog` (11 controls)**: AC-2, AC-3, AU-2, AU-12, IA-2, IA-5, RA-5, SC-7, SC-12, SI-2, SI-4
  (each id/family/title). zero_trust true, encryption AES-256/TLS 1.2+, secrets AWS Secrets Manager, patching_sla
  15/30/90/180, owasp_enforcement (4), 7 enforcement points. **This catalog is what `compliance_pack` reads (§2 blocker
  resolution).**
- **enterprise_architecture**: FAA AMS + EA Policy, gate G-02, tier_1_override review_board "FAA EA Review Board".
- **coding**: FAA Code Standards, linters (ruff/eslint/eslint/checkstyle/dotnet-format), additional_rules (5).
- **safety** (Tier 1 only): FAA System Safety Assessment, traceability 0.99, ivv/safety_case/safety_board/
  security_safety_crosswalk/nas_impact_assessment all true, 3 enforcement points.
- **regulatory_sources** (5, primary domain knowledge, NOT build-governance): 14 CFR Part 47/61/63/67/183, each with
  authority/version/analysis_document/raw_text/relevance/applicable_systems/key_concepts/update_frequency.
- **branding**: font Source Sans Pro, primary_color #15396c, header (usa_banner, dot_ribbon, faa_logo, system_title),
  footer templates, USWDS.

### 3.7 `autonomy.yaml` (NEW — P10-S18) — "NAS Autonomy Ladder"
`profile: faa`, `attempt_cap: 3`. **`tier_caps`**: tier_1 → **report_only**, tier_2 → **assisted**, tier_3 →
**unattended** (the per-tier ceiling — REQ-AG-002; NAS-critical apps can only propose). **`denylist`** (19 globs):
`**/secrets/**, **/secret/**, **/auth/**, **/authn/**, **/authz/**, **/payments/**, **/billing/**, infra/**,
**/infrastructure/**, **/terraform/**, *.tfstate, **/migrations/**, **/alembic/**, **/compliance/**, **/oscal/**,
**/*secret*, **/*.pem, **/*.key` (note FAA adds `**/oscal/**` on top of the default denylist). A match forces human
escalation regardless of tier (REQ-AG-003). **`auto_merge_allowlist`** (6): `**/*.lock, **/package-lock.json,
**/requirements*.txt, **/poetry.lock, docs/**, **/*.md` (bounds where an L3 loop may auto-merge; denylist beats
allowlist).

### 3.8 `nl-action-policy.yaml` (NEW — Phase-10 W6) — tiered-confirmation for the NL Action Console
`profile: faa`, `default_tier: high_stakes` (fail-safe: an unlisted action confirms). **`tiers.reversible`** (execute
directly): start_line, start_discovery, rerun_step, retry_step, reset_step. **`tiers.high_stakes`** (require explicit
human confirmation): onboard_application, create_portfolio, cancel_step, **dispatch_skill**. **GOTCHA — the LOAD-BEARING
differential**: FAA places `dispatch_skill` in `high_stakes` (an ad-hoc analysis run can touch accreditation-relevant
artifacts) whereas test-generic puts it in `reversible` — same engine, different tier boundary, proving tiering is DATA
(REQ-NL-003). `gate_decision`: mode `staged_human_decides`, `agent_may_approve: false` (the agent stages/explains but a
human always decides — REQ-NL-004).

### 3.9 `delegation.yaml` (NEW) — Phase-5 W20 delegated bundles
`fallback_policy: internal_fallback` (allowed: internal_fallback [default] | escalate | fail | redispatch — behavior on
bundle expiry/release). `delegation` block: `default_delegation: disabled` (FAA keeps delegation an explicit choice, not
always-on), `delegated_steps: []`, `default_expires_hours: 168`, `bundle_scope_kind: gate_packet`. Read lazily by
`bundle_activities.load_fallback_policy_for_portfolio` — no worker restart on change.

### 3.10 `wave-planning.yaml` (NEW)
`profile: faa`, `cadence: quarterly`, `concurrent_wave_limit: 4`. `sizing` (wave_1 5-8 T3; wave_2 8-12 T3+simple T2;
wave_3_4 10-15 T2; wave_5_6 12-18 complex T2+first T1; wave_7_plus 15-20+ T1). `constraints` (5, each
name/rule/reason/enforcement: shared_database_co_dependency automated, tier_1_safety_coordination manual,
application_dependencies automated, skill_readiness advisory, team_capacity automated). `compound_growth` (targets per
wave band: pattern_reuse/skill_first_pass/escalation_rate/human_hours). `composition_factors` (6 weighted priority
factors summing to 1.00: risk_tier 0.25, complexity 0.20, database_cluster 0.20, technology_type 0.15, business_value
0.10, pattern_leverage 0.10).

### 3.11 `objectives.yaml`
Agency Objectives (Mission View) — KPI-shaped outcome objectives (same shape as VBA/baseline). (Full body per
`agency-objectives-layer.md`; FAA's is the reference.)

> **TWO top-level keys** in every profile's `objectives.yaml`: a schema/version stamp **`version`** AND the KPI list
> **`objectives`**. FAA sets `version: "1.0.0"` (`profiles/faa/objectives.yaml:17`) with the `objectives:` block at
> `profiles/faa/objectives.yaml:19`. The `version` key is a document-schema version stamp (currently `"1.0.0"` across
> all four profiles), consumed alongside the `objectives` block by the agency-objectives layer; it is NOT one of the
> loader's 6 required files (§4) but IS a real top-level override key. See §7 for the shared note.

---

## 4. VBA profile — FULLY reproduced (7 YAMLs) — the "real non-FAA" proof

### 4.1 `profile.yaml`
`id: vba`, name "Veterans Benefits Administration", parent VA, sector Veterans Services. portfolio: size 120, dbs 1800,
7 years, primary_concern "Veterans claims integrity and benefits timeliness". extensions:
compliance/risk_classification/gates/scoring/technology/objectives. **`skills: []` (zero overlays — proves the
cross-cutting catalog is portable), `templates: []`, `branding: ""`.** deployment target "VA Enterprise Cloud (EKS)",
cloud AWS GovCloud. devsecops (primary_ecosystem **java**, else same as FAA). inherits null, overlays []. agent_dispatch
bedrock-claude/tier-2/require_fedramp_provider true.

### 4.2 `risk-classification.yaml` — "Veteran-Impact Tiering"
- **tier_1 "Benefits-Critical"** (adjudicates/disburses benefits or holds 38 U.S.C. §7332 data): traceability 0.99,
  coverage 0.90/0.95, parallel_run_days 60, canary, rollback 30, ivv_required true, safety_case/safety_board **false**,
  **privacy_impact_assessment_required true**, model_tier tier_1, stakeholder_confirmation true.
- **tier_2 "Mission Support"**: traceability 0.98, coverage 0.80/0.90, parallel_run_days 21, blue_green, rollback 14,
  pia false.
- **tier_3 "Administrative"**: traceability 0.95, coverage 0.70/0.85, parallel_run_days 7, sampling, rollback 3.
- signals (4), override_rules (2: downgrade-from-T1 needs privacy+benefits justification; any PHI-holding system is T1
  regardless of size).

### 4.3 `gates.yaml` — override keys
`default_provider github-pr`. **6 overrides**:
- **G-DC**: +protected_data_inventory (tier_1, automated), +stakeholder_business_criticality (tier_1, manual);
  reviewer tier_1 [portfolio_manager, privacy_officer]; rbac min 1.
- **G-DA**: +vba_isso_security_review (retire,replace); reviewer +vba_isso; rbac [portfolio_manager, vba_isso].
- **G-02**: +one_va_ea_alignment (tier_1), +privacy_impact_assessment (tier_1); reviewer tier_1 [arch_lead,
  va_ea_review_board].
- **G-04c**: +va_secure_coding_standards (all), +audit_logging_present (tier_1), +twelve_factor_compliance (all).
- **G-V2**: +oscal_control_package (all), +va_handbook_6500 (all); rbac [compliance_lead].
- **G-V3**: +privacy_impact_assessment_signoff (tier_1), +benefits_accuracy_validation (tier_1); reviewer tier_1
  [privacy_officer, compliance_lead]; **rbac min 2, oversight compliance_lead, management_override_allowed FALSE.**
- **G-DP-2**: +ato_decommission_certificate (retire), +records_retention_verification (retire, RCS 10-1); reviewer
  retire [operations_lead, portfolio_manager, vba_isso].
- additional_roles (3): vba_isso, va_ea_review_board, privacy_officer. sla same as FAA (24/48, 48/72, 72/96).

### 4.4 `scoring.yaml`
| dim | VBA | default | effect |
|---|---|---|---|
| code-quality | 0.15 | 0.20 | reduced |
| test-coverage | **0.20** | 0.15 | elevated — benefits-computation accuracy |
| security-posture | **0.25** | 0.20 | elevated — 38 U.S.C. §7332 protected data |
| documentation | 0.10 | 0.10 | unchanged |
| dependency-currency | 0.10 | 0.15 | reduced |
| architecture-clarity | 0.20 | 0.20 | unchanged |
Sum 1.00. **Distinct from FAA** (VBA elevates test-coverage; FAA elevates architecture-clarity).

### 4.5 `compliance.yaml` — 5 domains (incl. a distinct **privacy** domain)
- accessibility WCAG 2.1 AA (federal_minimum Section 508), VA Design System.
- security NIST 800-53 Rev 5, **artifact_format OSCAL**, additional_standards [VA Handbook 6500, FedRAMP Moderate].
  **No `control_catalog` list → empty catalog (does NOT inherit FAA's).** encryption AES-256 FIPS 140-3.
- **privacy** (VBA-distinctive): Privacy Act of 1974, statutes 38 U.S.C. §5701/§7332, PIA artifact, data_classifications
  (Veteran PII, PHI, financial/benefits-payment), 3 enforcement points.
- enterprise_architecture (One-VA EA, gate G-02), coding (VA Secure Coding, no-PHI-in-logs, audit-log-every-read).
- branding (VA blue #003e73, usa_banner, VA Design System).

### 4.6 `technology.yaml`
**No Gravitee/SWIM/Solace/Tyrion** (client-blindness proof). api_gateway **Kong**, identity **Keycloak (fed
Login.gov)**, compute EKS on GovCloud, container_platform VA Enterprise Cloud, monitoring CloudWatch+OTel, gitops Argo
CD. data legacy Oracle + Db2/z/OS, modern Aurora PG[primary]/DynamoDB. messaging legacy IBM MQ, modern MSK(Kafka)/SQS.
document_management S3+VBMS eFolder. low_code []. modernization_targets (java_ee→Spring Boot [bulk of portfolio];
mainframe COBOL/CICS/Db2→rearchitected Java/Spring; dotnet; batch_etl). **`tyrion_requirements`** block (note: VBA reuses
the key name generically) gitops/OCI/cloud_native/twelve_factor/trunk_based/devsecops/automation all true.

### 4.7 `objectives.yaml`
**TWO top-level keys**: `version: "1.0.0"` (`profiles/vba/objectives.yaml:11`) + `objectives:`
(`profiles/vba/objectives.yaml:13`). 2 objectives: `vba.modernize` (KPI analytics.factory_velocity.apps_per_wave,
target 24 by wave-6, baseline 6), `vba.compliance` (KPI compliance.overall_pass_rate, target 98 by wave-6, baseline
55). **Carries zero FAA references (W10 portability proof).**

> VBA ships NO autonomy.yaml / nl-action-policy.yaml → the autonomy gate and NL engine fall back to the conservative
> defaults (`registries/defaults/autonomy.yaml`; `default_tier high_stakes` behavior comes from the engine defaults).

---

## 5. baseline profile — FULLY reproduced (7 YAMLs) — the runnable client-blind default

### 5.1 `profile.yaml`
`id: baseline`, name "Olympus Baseline (Generic Default)". The DEFAULT deployable, client-blind profile (unlike
test-generic's CI-only fixture). portfolio size 25, dbs 40, 18 months. extensions
compliance/risk_classification/gates/scoring/technology (NO objectives in extensions map, though objectives.yaml
exists). skills [], templates [], branding "". deployment initial/target/cloud all "default". devsecops (platform
defaults; no target_cloud/primary_ecosystem — those are FAA/VBA-specific). inherits null, overlays [].

### 5.2 `risk-classification.yaml` — "Generic 3-Tier Risk Model"
tier_1 "High Criticality" (traceability 0.99, coverage 0.90/0.95, parallel_run_days 30, canary, traffic "5→25→50→100%
over 7 days", rollback 14, model_tier tier_1, stakeholder_confirmation true), tier_2 "Medium" (0.98, 0.80/0.90, 14 days,
blue_green, rollback 7), tier_3 "Low" (0.95, 0.70/0.85, 7 days, sampling, rollback 3). signals (3), override_rules (2).

### 5.3 `gates.yaml`
`default_provider github-pr`. Overrides for **all 15/18 standard gates** with generic reviewer roles + minimal
additions: G-DC/G-RR (portfolio_manager), G-DA (retire/replace portfolio_manager+stakeholder), G-02/G-DT (arch_lead),
**G-04a** (+extraction_traceability), **G-04b** (+design_security_mapping), **G-04c** (+linter_compliance,
+twelve_factor_compliance), G-DE-1/2 (portfolio_manager), G-V1/V3 (compliance_lead), **G-V2** (+control_evidence_package,
rbac compliance_lead min 1), G-DP-1 (operations_lead+portfolio_manager), **G-DP-2** (+data_archival_verification,
retire). additional_roles []. sla relaxed (48/72, 72/96, 96/120).

### 5.4 `scoring.yaml` — **mirrors registry defaults** (neutral): code-quality 0.20, test-coverage 0.15,
security-posture 0.20, documentation 0.10, dependency-currency 0.15, architecture-clarity 0.20 (sum 1.00; every
`weight == default_weight`).

### 5.5 `compliance.yaml`
accessibility WCAG 2.1 AA (Section 508 min), USWDS. security NIST 800-53 Rev 5, artifact_format **OSCAL**,
additional_standards []. **`control_catalog` (6 generic "-1" policy-and-procedures controls)**: AC-1, AU-1, CM-1, IA-1,
SC-1, SI-1. enterprise_architecture (standards [], gate G-02), coding (standards [], generic linters). branding
(#005ea2, usa_banner true, USWDS).

### 5.6 `technology.yaml` — fully vendor-neutral (api_gateway "generic" not mandatory, identity "generic" OAuth2/OIDC,
compute container-runtime, everything "default"). data legacy [], modern relational[primary]/document. messaging
event-bus/queue. modernization_targets generic.

### 5.7 `objectives.yaml` — **TWO top-level keys**: `version: "1.0.0"` (`profiles/baseline/objectives.yaml:11`) +
`objectives:` (`profiles/baseline/objectives.yaml:13`). `baseline.modernize` (target 15 by wave-4, baseline 4),
`baseline.compliance` (target 95 by wave-4, baseline 50). Client-blind; proves the objectives layer renders for the
default profile.

> baseline ships NO autonomy/nl-action-policy → conservative defaults apply.

---

## 6. test-generic profile — FULLY reproduced (13 YAMLs) — the differential CI fixture

The non-client verification profile used by CI to prove cross-cutting portability + that per-feature policy is DATA.
`estimated_size: 0`. **skills/ MUST be empty (asserted by `tests/test_generic_profile_portability.py`).**

### 6.1 Shared with the 6 required files
- `profile.yaml`: id test-generic, size/dbs 0, extensions (the 5 standard), skills/templates/branding empty, devsecops
  explicit (exercises block wiring not fallback), inherits null.
- `risk-classification.yaml`: "Generic 3-Tier Risk Model" (tier_1 0.99/0.90/0.95/30d/canary/7-day-traffic/rollback14;
  tier_2 0.98/0.80/0.90/14d; tier_3 0.95/0.70/0.85/7d/sampling). signals (3), override_rules (1).
- `scoring.yaml`: mirrors registry defaults exactly (0.20/0.15/0.20/0.10/0.15/0.20 — sum 1.0; activating is a scoring
  no-op).
- `gates.yaml`: minimal overrides only (G-DC, G-DA, G-02, G-V3 reviewer_overrides); additional_roles []; relaxed sla.
- `compliance.yaml`: NIST 800-53 Rev 5, **artifact_format "generic"** (NOT OSCAL — proves cATO view is profile-driven),
  **`control_catalog` (3 generic controls AC-1/AU-1/CM-1)** — a non-FAA profile surfaces ITS OWN controls, never FAA's
  SF3 set (P7-S16.2). No agency frameworks.
- `technology.yaml`: fully generic (like baseline).
- `objectives.yaml`: **TWO top-level keys** — `version: "1.0.0"` (`profiles/test-generic/objectives.yaml:11`) +
  `objectives:` (`profiles/test-generic/objectives.yaml:13`); `test-generic.modernize` (target 15 by wave-4).
  Portability-demo asset.

### 6.2 The 6 EXTRA differential-fixture YAMLs (each proves a per-feature policy is DATA)
- **`autonomy.yaml`** (P10-S18): `profile test-generic`, attempt_cap 3, tier_caps (tier_1 report_only / tier_2 assisted
  / tier_3 unattended), denylist (18 globs — the DEFAULT set, WITHOUT FAA's extra `**/oscal/**`), auto_merge_allowlist
  (same 6 as FAA). Plus a **`triage`** block for the nightly error-triage sweep: sources
  [ai_work_log, agent_run, event_outbox], `propose_fix_enabled: false` (fail-closed report-only), `fix_level: assisted`,
  `metrics_endpoint: ""` (exercises the Prometheus skip path), `control_ids: [CA-7]`.
- **`nl-action-policy.yaml`** (Phase-10 W6): `default_tier high_stakes`. `reversible` = start_line, start_discovery,
  rerun_step, retry_step, reset_step, **dispatch_skill** (← the differential vs FAA). `high_stakes` = onboard_application,
  create_portfolio, cancel_step. `gate_decision` staged_human_decides / agent_may_approve false.
- **`catalog.yaml`** (P8 asset-catalog): `catalog.profile test-generic`, `eval_staleness_days: 90` — the eval-staleness
  window (asset whose evals are older than N days is STALE → publication refused / published asset regresses to
  at_risk). DATA (another profile may set 30 or 180; omit → service default 90).
- **`decomposition.yaml`** (P8): `criticality_review_floor: 2` — a FeatureNode at tier ≤ floor (higher criticality) MUST
  be reviewed before work-order generation (reuses the 3-tier vocabulary; omit → safe default 1).
- **`drift.yaml`** (P8): `severity_order` [low, medium, high, critical]; `reconcile_threshold: high` (finding ≥ threshold
  opens a reconciliation work item + forces spec in_sync=false); `kind_severity` (orphan_citation high, stale_link
  medium, coverage_gap high); `evidence_controls` [CA-7, CM-3 @ nist-800-53-rev5]; drift-as-control
  `control_action_by_severity` (low advisory / medium at_risk / high+critical block; unmapped → advisory);
  `coverage_floor: 0.80` (drift-control authorization signal).
- **`feedback.yaml`** (P8): `auto_generate_threshold: null` (QUEUE MODE — work order only via role-gated `/approve`; an
  integer N would auto-generate at occurrence≥N, a FUTURE flag OFF by default); `work_order_line_by_classification`
  (regression/defect/performance/security/other → **Modernization**, the line that fixes existing code — no new
  orchestration path); `distillation_min_occurrences: 3` (a signature seen ≥3× is proposed to evals-harness).

> These 6 extra YAMLs are NOT parsed by the 6-file `load_profile`; each is read by its own feature service
> (`compliance_pack`/`nl_engine`/catalog/decomposition/drift/feedback loaders) as profile DATA — the recurring pattern
> that makes each per-feature policy client-overridable without a code change.

---

## 7. Override-key count (for the manifest)

**Extension units documented**: 6 extension registries (assembly_line, disposition, analysis_pass, scoring_dimension,
gate_provider, skill_composition) + loop_pattern catalog + engine substrate + worker_bootstrap + profile_overrides
seam = **10 framework units**; plus the autonomy engine.

**Override keys across the 4 profiles (top-level YAML override keys / entries actually consumed):**
- FAA: risk tiers (3) + gate overrides (8) + scoring dims (6) + autonomy (tier_caps 3, denylist 19, allowlist 6,
  attempt_cap 1) + nl-action tiers (2 lists) + wave composition_factors (6) + delegation (4) + compliance domains (5) +
  control catalog (11) ≈ **80+ keyed overrides**.
- VBA: tiers (3) + gate overrides (6) + scoring (6) + compliance domains (5, incl privacy) + objectives (2) ≈ **22**.
- baseline: tiers (3) + gate overrides (15) + scoring (6) + control catalog (6) + objectives (2) ≈ **32**.
- test-generic: tiers (3) + gate overrides (4) + scoring (6) + autonomy (tier_caps 3 + triage 5) + nl-action (2) +
  catalog (1) + decomposition (1) + drift (7) + feedback (3) ≈ **35**.

Total override keys captured ≈ **169** across the 4 profiles (see §§3-6 for the exact per-key list and effect).

> **SHARED NOTE — `objectives.yaml` has TWO top-level keys in every profile.** Each of the 4 `objectives.yaml` files
> declares a top-level **`version`** schema/version stamp (all four currently `"1.0.0"`) IN ADDITION to the
> **`objectives`** KPI list. This `version` wrapper key is easy to miss because it is separate from the per-objective
> `objectives[*].target`/`baseline`/`kpi` fields. Exact citations: `profiles/faa/objectives.yaml:17`,
> `profiles/vba/objectives.yaml:11`, `profiles/baseline/objectives.yaml:11`,
> `profiles/test-generic/objectives.yaml:11` — each paired with its `objectives:` block one/two lines below (faa:19,
> vba:13, baseline:13, test-generic:13). When regenerating, emit both top-level keys.
