# Olympus — Atomic Regeneration Specification (2026-07-03)

**What this is.** A complete **behavioral-parity** specification of the Olympus platform: enough detail
that an engineer with **no access to the source** could rebuild each component so it behaves identically.
The bar is reproduction, not summary — every branch, loop, gate, retry, and field→column mapping is
captured from live code with `path:line` citations.

**Baseline.** Generated against `origin/main` HEAD **`6c99bb6b`** (2026-07-03), alembic head
`091_create_error_signal`. Supersedes the 2026-07-02 set (which was built at `22976138`, ~184 commits back,
before the Capabilities subsystem, NL Action Console, autonomy-gating executors, IngestionWorkflow, and the
`models/` package split).

**Scale.** 77 documents · ~46,600 lines · ~3.3 MB.

**How it was built.** Three sequential background workflows, each doc written by one agent and graded by an
**independent fresh-context verification gate** that re-derives counts/branches from live code (bounded
repair loop), then a final adversarial fidelity audit:
- **WF1 — Foundation** (overview, environment, contracts, framework, 4 profiles)
- **WF2 — Workflows + Activities** (24 workflow classes incl. 5 new; 16 activity-group docs; projection audit)
- **WF3 — Surface + Audit** (agent-runtime, skills, generation, API, data, dashboard, build/CI, order) + FINAL fidelity audit + DRIFT-REGISTER

**Independent-verification results (this run).** Every headline count re-derived by hand matched the gates:
assembly-line steps **189**/12 lines, enums **10**/66 values, extension registries **7**, API endpoints
**301**/50 routers, migrations **90** (gap 055, head 091), dashboard **66** routes, skills **173**. Final
adversarial fidelity scores: **workflows 97 · activities 93 · generation-engine 96 · agent-runtime 96 ·
capabilities-nl-autonomy 93** (all above the 85 bar). One genuine in-scope under-reproduction found and fixed
by hand (`_extract_data_architecture_side_effects` decided_at try/except in `03b-activities/line-transitions-core.md`);
the remaining audit findings were verified as deliberate cross-doc relocations or out-of-sample-scope, not gaps.

---

## Where to start

1. **This README** — the index.
2. **`09-regeneration-order.md`** — the dependency-correct rebuild runbook: which doc to build in what order,
   each phase with its proof-gate (the exact command/test) and a behavioral-parity DONE definition.
3. **`DRIFT-REGISTER.md`** — every code-vs-docs divergence, GOTCHA, and TODO a rebuild must know (read before
   trusting any count — e.g. the skipped migration 055, the reverse-engineering enum lag, the `models/` split).
4. **`ROADMAP-TO-BE-IMPLEMENTED.md`** — *forward* work (planned, not yet built): Phase-10 W4/W8/W12 + UI
   U2/U5/U6. Kept separate from the parity docs on purpose.

---

## Document set

### Foundation & contracts
| Doc | Covers |
|---|---|
| `00-overview.md` | System map, 4 pillars, service topology, 13 compose services, coverage floors, doc index |
| `00b-environment.md` | Stand-up: compose config, env vars, Temporal/task-queue config, 35 make targets, from-zero runbook |
| `06-contracts.md` | `olympus-contracts` — 10 enums (66 values), signals, errors, git types, the loader; 111 JSON schemas; new `capability_types`/`event_outbox`/`catalog_types` |
| `06b-assembly-line-contracts.md` | All **12** assembly-line YAMLs reproduced VERBATIM (189 steps; incl. `reverse-engineering.yaml`) |
| `07-framework.md` | **7** extension-point registries + `worker_bootstrap`; line-to-line contract; risk/disposition/gate models; **autonomy-gating framework** |
| `07b-profiles.md` | All 4 profiles fully (faa 11 / vba 7 / baseline 7 / test-generic 13); override keys + effects; can vs cannot override |

### Orchestration (Temporal)
| Doc | Covers |
|---|---|
| `03-workflows/` (27 docs) | 24 `@workflow.defn` classes — per-class atomic control flow. Incl. **5 new**: `IngestionWorkflow` (brownfield line) + autonomy executors `DependencySweep`/`CveTriage`/`CiRepair`/`ErrorTriage`. `_base-workflow.md` = shared machinery |
| `03b-activities/` (16 docs) | 38 activity modules / 82 `@foundry_activity` fns / **19 persist_*** projections (full field→column mappings). Incl. **new**: autonomy, evidence-drift-eval, ingestion activities |

### Runtime, skills, generation
| Doc | Covers |
|---|---|
| `02-agent-runtime.md` | `execute_skill` pipeline, prompt envelope, validation-retry loop, model selection, providers, A2A, live/mock |
| `02b-worker-mcp-cli.md` | olympus-worker, mcp-server (tools/resources), olympus-cli (every command) |
| `skill-authoring-contract.md` | Standalone contract to author a conformant skill with zero runtime-code access |
| `11-skill-registry.md` + `11b-skill-line-wiring.md` | All **173** skills (id/version/category/schemas/deps) + per-step skill→schema wiring |
| `13-generation-engine.md` | Extract→Design→Generate factory + Ralph Loop: each iteration, stop condition, validation |
| `14-capabilities-nl-autonomy.md` | **NEW subsystems**: Capabilities service (provenance tiers, allowlist, maker≠verifier), NL Action Console (ACTION_SPECS, gated writes), autonomy-gating runtime |

### API, data, dashboard
| Doc | Covers |
|---|---|
| `01-api.md` + `-part2/-part3` | All **301** endpoints across 50 routers (method/path/auth/models/logic), app factory, middleware, auth |
| `01-api-services.md` + `-part2` | 69 service modules + 7 sub-packages (autonomy, capabilities, decomp, drift, drift_control, feedback, nl_tools) |
| `04-data-layer.md` + `-part2/-part3` | **90** migrations (DAG, gap 055), every table column-by-column, enums, CHECK constraints, JSONB shapes, projection model |
| `05-dashboard.md` + pages/components (11 docs) | **66** routes, 34 page-dirs, 56 component-dirs; USWDS tokens/branding; state model; API layer |

### Build & forward
| Doc | Covers |
|---|---|
| `08-build-ci.md` | CI workflows, per-package coverage floors, lint/type config, all anti-drift guard tests |
| `09-regeneration-order.md` | **The rebuild runbook** — dependency-correct order + per-phase proof gates + behavioral-parity DONE |
| `DRIFT-REGISTER.md` | Consolidated drift + GOTCHAs + TODOs (19 confirmed drift items) |
| `ROADMAP-TO-BE-IMPLEMENTED.md` | Forward work not yet built (P10 W4/W8/W12 + UI U2/U5/U6); nothing beyond Phase 10 |

---

*The saved, re-invocable regeneration procedure lives at `<repo>/.claude/regenerate-specs/` (RUNBOOK.md +
the WF1/WF2/WF3 scripts + wf3-finalize.js). To regenerate again: fetch main, re-scout counts, bump `OUT` to a
fresh date, point `OLD` at this run, and launch WF1→WF2→WF3 sequentially, verifying each gate independently.*
