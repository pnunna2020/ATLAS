# Olympus API — Part 2: Extension-Registry, Governance, Gate, Skill & Agent Routers

Atomic regeneration spec. Scope: `olympus-api/src/routers/{registries,governance,gates,skills,agents,agent_roles,agent_runs}.py` plus the service functions they call. Behavioral parity is the bar: reproduce HOW, not WHAT.

All paths are relative to `/Users/pnunna/Documents/GitHub/olympus/olympus-api/src/`. Citations `file.py:NN`; a bare `(:NN)` refers to the file most recently named in that subsection.

## Shared auth/dependency primitives (referenced throughout)

- `require_role(*roles)` — `middleware/auth.py:131`. Returns an async dependency `_check(user=Depends(get_current_user))`; if `not user.has_role(*roles)` raises `HTTPException(403, detail=f"Requires one of: {[r.value for r in required_roles]}")`. Passes with ANY one role. `user.has_role` is variadic-OR.
- `get_current_user` — `middleware/auth.py:105` (reads request state populated by auth middleware; `.sub` is the caller id, `.has_role(...)`).
- `resolve_portfolio_role(db, user, portfolio_id)` — `dependencies.py:94`. If `user.has_role(PORTFOLIO_ADMIN)` → return `"portfolio_admin"` (synthetic). Else `get_membership(db, portfolio_id, user.sub)`; `None` → return `None`; else return `_role_value(row.role)` (plain string; profile-extension roles like `faa_issm` round-trip).
- `verify_portfolio_access(db, user, portfolio_id)` — `dependencies.py:210`. Admin → return. `is_member` → return. Else raise `HTTPException(403, {"code":"PORTFOLIO_NOT_MEMBER", ...})`.
- `require_gate_member` — `dependencies.py:279`. Path dep for `{gate_id}` routes. Admin passes; else `verify_gate_portfolio_access(db, user, gate_id)` (resolves gate→portfolio then membership); returns `user`.
- `filter_portfolio_ids_by_membership(db, user)` — `dependencies.py:496`. Returns `None` for admins (no filter) or the list of member portfolio UUIDs for non-admins.
- `RBACRole` enum (`models/common.py`): VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN, SERVICE (`.value` is the string).

---

# 1. registries.py — Extension-Registry CRUD (33 endpoints, 938 LOC)

Router: `APIRouter(prefix="/api/v1/registries", tags=["registries"])` (`registries.py:61`).
Exposes the six extensibility registries as REST. Writes require `PORTFOLIO_ADMIN`; reads are open to any authenticated caller. Registries are **in-process singleton stores** imported from `olympus_workflows.registries` (`:35-53`); writes DO NOT persist to profile YAML on disk. Profile activation is authoritative for contents.

## 1.1 Shared request/response models

```
VersionBumpRequest:  kind: str  (Field pattern "^(major|minor|patch)$")            (:69)
VersionBumpResponse: id: str; version: str                                          (:77)
DeleteResponse:      id: str; deleted: bool = True                                  (:82)
RegistryIndexEntry:  name: str; count: int; endpoint: str                           (:322)
CompositionValidityResponse: valid: bool; reason: str; unsatisfied: list[str]=[]    (:162)
```

Entity bodies (all have `metadata: dict = {}`, `version: str = "1.0.0"`):
- `AssemblyLineBody` (:92): name, description="", steps=[], gates=[], depends_on=[], inputs=[], outputs=[], mode="per-app".
- `DispositionStrategyBody` (:105): label, workflow="DispositionWorkflow", required_gates=[], has_gate2=True, max_rework_iterations=3, pre_gate1_steps=[](list[dict[str,str]]), post_gate1_steps=[].
- `AnalysisPassBody` (:117): name, skill_id, artifact, depends_on=[], pass_number=0, synthesis_rule="synthesis", parallel_with=[].
- `ScoringDimensionBody` (:129): name, weight(float), default_weight: float|None=None, rationale="", data_source="", scoring_function="", bounds: tuple[float,float]=(0.0,1.0).
- `GateProviderBody` (:141): id, description="", supports_automated=False, requires_human=True, implemented=True.
- `SkillCompositionBody` (:151): name, skills: list[str], mode="sequential", description="", conditions: dict[str,str]={}, variant_selectors: dict[str,str]={}.
- `ScoringBulkReplaceRequest` (:680): dimensions: list[ScoringDimensionBody].

## 1.2 Serialisation helpers

- `_assembly_line_to_body` (:180), `_disposition_to_body` (:195), `_analysis_pass_to_body` (:217), `_scoring_to_body` (:233), `_gate_provider_to_body` (:249), `_composition_to_body` (:285) — copy fields, coercing tuples→lists, `metadata` dict-copied, `version` passed in.
- `_disposition_to_body`: `required_gates` = `strategy.effective_required_gates()`; `pre/post_gate1_steps` = `[{"step":s.step,"skill_id":s.skill_id,"artifact":s.artifact} for s in steps]` via inner `_step_rows` (:198).
- `_json_safe_metadata(metadata)` (:263) — GOTCHA: W5 router-replacement compositions carry a non-JSON `selection_table` (VariantSelectionTable object) in metadata. Loop: str/int/float/bool/None → keep; list/dict → keep; `key=="selection_table"` → replace with `{"has_selection_table": True}`; any other non-JSON value silently dropped. `_composition_to_body` runs metadata through this.
- `_steps_from_rows(rows)` (:447) — build `tuple[StepSpec]` from `[{step,skill_id,artifact}]`; missing key → `HTTPException(422, f"Disposition step missing key: {exc}")`.

## 1.3 Error translation `_translate_registry_error(exc)` (:305)

`EntityNotFound`→404; `RegistryValidationError`→422; `CircularDependencyError`→422; `EntityHasDependents`→409; else→500. `detail=str(exc)`.

## 1.4 Endpoints (mount order preserved)

Auth abbreviations: **[open]** = authenticated only (no role dep); **[ADMIN]** = `require_role(PORTFOLIO_ADMIN)`.

| # | Method | Path | Auth | Req | Resp | Status | Line |
|---|--------|------|------|-----|------|--------|------|
| 1 | GET | `""` (index) | [open] | — | `list[RegistryIndexEntry]` | 200 | :328 |
| 2 | GET | `/assembly-lines` | [open] | — | `list[AssemblyLineBody]` | 200 | :370 |
| 3 | GET | `/assembly-lines/{name}` | [open] | — | `AssemblyLineBody` | 200/404 | :378 |
| 4 | POST | `/assembly-lines` | [ADMIN] | AssemblyLineBody | AssemblyLineBody | 201 | :387 |
| 5 | DELETE | `/assembly-lines/{name}` | [ADMIN] | — | DeleteResponse | 200 | :414 |
| 6 | POST | `/assembly-lines/{name}/version-bump` | [ADMIN] | VersionBumpRequest | VersionBumpResponse | 200 | :426 |
| 7 | GET | `/disposition-strategies` | [open] | — | `list[DispositionStrategyBody]` | 200 | :466 |
| 8 | GET | `/disposition-strategies/{label}` | [open] | — | DispositionStrategyBody | 200/404 | :476 |
| 9 | POST | `/disposition-strategies` | [ADMIN] | DispositionStrategyBody | " | 201 | :490 |
| 10 | DELETE | `/disposition-strategies/{label}` | [ADMIN] | — | DeleteResponse | 200 | :518 |
| 11 | POST | `/disposition-strategies/{label}/version-bump` | [ADMIN] | VersionBumpRequest | VersionBumpResponse | 200 | :532 |
| 12 | GET | `/analysis-passes` | [open] | — | `list[AnalysisPassBody]` | 200 | :553 |
| 13 | GET | `/analysis-passes/{name}` | [open] | — | AnalysisPassBody | 200/404 | :561 |
| 14 | POST | `/analysis-passes` | [ADMIN] | AnalysisPassBody | " | 201 | :572 |
| 15 | DELETE | `/analysis-passes/{name}` | [ADMIN] | — | DeleteResponse | 200 | :600 |
| 16 | POST | `/analysis-passes/{name}/version-bump` | [ADMIN] | VersionBumpRequest | VersionBumpResponse | 200 | :612 |
| 17 | GET | `/scoring-dimensions` | [open] | — | `list[ScoringDimensionBody]` | 200 | :633 |
| 18 | GET | `/scoring-dimensions/{name}` | [open] | — | ScoringDimensionBody | 200/404 | :641 |
| 19 | POST | `/scoring-dimensions` | [ADMIN] | ScoringDimensionBody | " | 201 | :654 |
| 20 | POST | `/scoring-dimensions/replace-all` | [ADMIN] | ScoringBulkReplaceRequest | `list[ScoringDimensionBody]` | 200 | :686 |
| 21 | DELETE | `/scoring-dimensions/{name}` | [ADMIN] | — | DeleteResponse | 200/404 | :719 |
| 22 | POST | `/scoring-dimensions/{name}/version-bump` | [ADMIN] | VersionBumpRequest | VersionBumpResponse | 200 | :733 |
| 23 | GET | `/gate-providers` | [open] | — | `list[GateProviderBody]` | 200 | :754 |
| 24 | GET | `/gate-providers/{provider_id}` | [open] | — | GateProviderBody | 200/404 | :762 |
| 25 | POST | `/gate-providers` | [ADMIN] | GateProviderBody | " | 201 | :773 |
| 26 | DELETE | `/gate-providers/{provider_id}` | [ADMIN] | — | DeleteResponse | 200 | :799 |
| 27 | POST | `/gate-providers/{provider_id}/version-bump` | [ADMIN] | VersionBumpRequest | VersionBumpResponse | 200 | :813 |
| 28 | GET | `/skill-compositions` | [open] | — | `list[SkillCompositionBody]` | 200 | :834 |
| 29 | GET | `/skill-compositions/{name}` | [open] | — | SkillCompositionBody | 200/404 | :842 |
| 30 | POST | `/skill-compositions/{name}/validate` | [open] | — | CompositionValidityResponse | 200/404 | :855 |
| 31 | POST | `/skill-compositions` | [ADMIN] | SkillCompositionBody | " | 201 | :881 |
| 32 | DELETE | `/skill-compositions/{name}` | [ADMIN] | — | DeleteResponse | 200 | :908 |
| 33 | POST | `/skill-compositions/{name}/version-bump` | [ADMIN] | VersionBumpRequest | VersionBumpResponse | 200 | :922 |

GOTCHA: the `/skill-compositions/{name}/validate` route (#30) is declared BEFORE `POST /skill-compositions` (#31) but AFTER the two GET routes; FastAPI matches `{name}/validate` correctly because the static suffix disambiguates. The order in-file must be preserved.

### Endpoint logic (uniform CRUD pattern per registry)

**index (#1)** — returns 6 `RegistryIndexEntry` in fixed order: assembly-lines, disposition-strategies, analysis-passes, scoring-dimensions, gate-providers, skill-compositions; each `count=len(REGISTRY.list_all())`, `endpoint="/api/v1/registries/<slug>"` (:331-362).

**list** — `[_to_body(x, REGISTRY.version(x.<key>)) for x in REGISTRY.list_all()]`. Version key: assembly-line `.name`, disposition `.label`, analysis-pass `.name`, scoring `.name`, gate-provider `.id`, composition `.name`.

**get by id** — most call `REGISTRY.get(id)` in a try, catching `EntityNotFound` → `_translate_registry_error`. Exception: `get_scoring_dimension` (:644) — `SCORING_DIMENSION_REGISTRY.get(name)` returns `None` on miss (not raise), so it does `if dim is None: raise HTTPException(404, f"No scoring dimension registered for {name!r}")`.

**upsert (POST)** — construct the domain object from the body (tuples for list fields, `dict(metadata)`), then `REGISTRY.register(obj)` in try; ANY `Exception` → `_translate_registry_error`. Return `_to_body(obj, REGISTRY.version(body.<key>))`. Status 201. Disposition upsert passes `_steps_from_rows(...)` for pre/post steps (:501-502) and `required_gates=tuple(body.required_gates)`.

**replace-all scoring (#20)** (:690) — build new `ScoringDimensionEntry` list from body.dimensions; `SCORING_DIMENSION_REGISTRY.replace_all(new_set)`; `ValueError`→422 (weights-sum-to-1.0 rule enforced in registry), other Exception→`_translate_registry_error`. Return full `list_all()` re-serialized.

**delete** — `REGISTRY.delete(id)` in try; Exception→`_translate_registry_error`; return `DeleteResponse(id=id)`. Exception: `delete_scoring_dimension` (:722) catches `KeyError`→`HTTPException(404, str(exc))` (registry raises KeyError not EntityNotFound).

**version-bump** — `version = REGISTRY.bump_version(id, body.kind)` in try; Exception→translate; return `VersionBumpResponse(id, version)`.

**validate composition (#30)** (:859) — `comp = SKILL_COMPOSITION_REGISTRY.get(name)` (EntityNotFound→404); `verdict = check_composition_validity(comp, ValidityContext())`; return `CompositionValidityResponse(valid=verdict.valid, reason=verdict.reason, unsatisfied=list(verdict.unsatisfied))`. This uses the SAME predicate set as the REQ-SC-004 preflight gate (`olympus_workflows.composition.validity` — ONE predicate set; `ValidityVerdict` has `{valid, reason, unsatisfied}`). Read-only: never dispatches or mutates a gate. No elevated role required for read.

---

# 2. governance.py — Governance domain (12 endpoints, 1296 LOC)

Router: `APIRouter(prefix="/api/v1/governance", tags=["Governance"])` (`governance.py:83`). Two endpoints override prefix to `/api/v1/portfolios/...` via full path and add `tags=["Compliance"]`.

Role groups (:61-81):
- `EXPORT_ROLES` = [COMPLIANCE_LEAD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN].
- `VIEWER_PLUS` = [VIEWER, TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN].
- `MANAGER_PLUS` = [PORTFOLIO_MANAGER, PORTFOLIO_ADMIN].

Tables (migration 025): `health_check`, `drift_alert`, `pattern`. Empty tables → empty-state payloads, never 404.

## 2.1 Missing-table-tolerant helpers

- `_safe_execute_rows(db, sql, params)` (:134) — run SELECT; on `ProgrammingError|DBAPIError` whose lower-cased message contains (`"undefined"` AND `"relation"`) OR `"does not exist"` → return `[]`; else re-raise. Returns `[dict(r) for r in .mappings().all()]`.
- `_safe_execute_scalar` (:154) — same tolerance, returns `.scalar()` or `None`.

## 2.2 Models

```
HealthCheck (:91):     id: UUID; date: date; health_index: float(ge=0,le=1); alerts: list[dict]=[]; checks: list[dict]=[]
DriftAlert (:99):      id: UUID; type: str; app_id: UUID|None=None; details: dict={}; acknowledged: bool; created_at: datetime
PatternSummary (:108): id: UUID; name; category; wave_id: UUID|None; reuse_count: int; created_at: datetime
PatternDetail (:117):  + description=""; source_apps: list[UUID]=[]; content: dict={}
GovernanceSweepRequest (:448):  portfolio_id: UUID (required); cadence: Literal["weekly","quarterly"]="weekly"
GovernanceSweepResponse (:475): workflow_id; schedule_id; cadence; portfolio_id; started_at: datetime; status="running"; temporal_ui_url: str|None
GovernanceSweepSummary (:492):  workflow_id; portfolio_id: UUID|None; started_at; completed_at; cadence; schedule_id; status; health_index: float|None
GovernanceScheduleRequest (:1210):  portfolio_id: UUID; cadence: Literal[...]="weekly"; enabled: bool=True
GovernanceScheduleResponse (:1224): schedule_id; portfolio_id; cadence; enabled
CatoControlEvidence (:667):  control_id; family; title=""; status: Literal["implemented","partial","planned","not-applicable","unknown"]="unknown"; last_assessed: datetime|None; source: str|None
SystemCatoEvidence (:701):   system_id: UUID; system_name; system_external_id: str|None; cato_state: Literal["not-started","in-progress","transition","inheriting","certified","expired","unknown"]="unknown"; cato_certified=False; application_count=0; cato_certified_application_count=0; controls: list[CatoControlEvidence]; last_assessed
PortfolioCatoEvidenceTotals (:718): system_count, cato_certified_systems, application_count, cato_certified_applications, controls_implemented, controls_partial, controls_planned, controls_unknown (all int=0)
PortfolioCatoEvidence (:731): portfolio_id: UUID; systems: list[SystemCatoEvidence]; totals; generated_at: datetime
```

## 2.3 Endpoint table (mount order)

| # | Method | Path | Auth | Req | Resp | Status | Line |
|---|--------|------|------|-----|------|--------|------|
| 1 | GET | `/health-checks` | VIEWER_PLUS | q:`date`,pagination | `dict` (paginated) | 200 | :170 |
| 2 | GET | `/health-checks/latest` | VIEWER_PLUS | — | `dict` | 200 | :216 |
| 3 | GET | `/drift-alerts` | VIEWER_PLUS | pagination | `dict` (paginated) | 200 | :250 |
| 4 | POST | `/drift-alerts/{alert_id}/acknowledge` | MANAGER_PLUS | — | DriftAlert | 200/404 | :292 |
| 5 | GET | `/patterns` | VIEWER_PLUS | q:`category`,`wave_id`,pagination | `dict` | 200 | :340 |
| 6 | GET | `/patterns/{pattern_id}` | VIEWER_PLUS | — | PatternDetail | 200/404 | :396 |
| 7 | POST | `/sweep` | MANAGER_PLUS | GovernanceSweepRequest | GovernanceSweepResponse | 202/502 | :512 |
| 8 | GET | `/sweeps` | VIEWER_PLUS (+get_current_user) | q:`portfolio_id`,pagination | `dict` | 200 | :587 |
| 9 | GET | `/api/v1/portfolios/{portfolio_id}/cato-evidence` | VIEWER_PLUS | — | PortfolioCatoEvidence | 200/404 | :811 |
| 10 | GET | `/api/v1/portfolios/{portfolio_id}/compliance-evidence-export` | EXPORT_ROLES | q:`app_id`,`format` | Response(zip) | 200/404 | :1100 |
| 11 | POST | `/schedule` | MANAGER_PLUS | GovernanceScheduleRequest | GovernanceScheduleResponse | 201/502 | :1231 |
| 12 | DELETE | `/schedule/{portfolio_id}` | MANAGER_PLUS | q:`cadence` | Response(204) | 204 | :1278 |

## 2.4 Endpoint logic

**1. list_health_checks** (:170) — `where = "WHERE date = :date"` if `date` else "". `total = int(_safe_execute_scalar("SELECT count(*) FROM health_check {where}") or 0)`. rows: `SELECT id,date,health_index,checks ... {where} ORDER BY date DESC, created_at DESC LIMIT :limit OFFSET :offset`. Each → `HealthCheck(... checks=r["checks"] if isinstance list else [], alerts=[]).model_dump(mode="json")`. `paginated_response(data,total,pagination)`.

**2. latest_health_check** (:216) — LIMIT 1 ordered date/created_at DESC. If no rows → `{"data": None, "empty_state": True}`. Else the single HealthCheck dump.

**3. list_drift_alerts** (:250) — filters `acknowledged = false`. total via safe scalar. rows select `id,type,application_id,details,acknowledged,created_at ... WHERE acknowledged=false ORDER BY created_at DESC`. Map `app_id=r["application_id"]`, `details` if dict else {}.

**4. acknowledge_drift_alert** (:292) — `SELECT * FROM drift_alert WHERE id=:id`; None → `OlympusHTTPException(404,"ALERT_NOT_FOUND",...)`. `UPDATE drift_alert SET acknowledged=true, acknowledged_by=:by(user.sub), acknowledged_at=:at(now utc) WHERE id`. commit. Return `DriftAlert(... acknowledged=True, created_at=row["created_at"])` (built from pre-update row).

**5. list_patterns** (:340) — build where from `category`, `wave_id` (AND-joined). total safe scalar. rows `SELECT id,name,category,wave_id,reuse_count,created_at FROM pattern {where} ORDER BY reuse_count DESC, created_at DESC`. Map to PatternSummary.

**6. get_pattern** (:396) — `SELECT * FROM pattern WHERE id`; None→`OlympusHTTPException(404,"PATTERN_NOT_FOUND")`. `source_apps`: iterate `row["source_apps"]` list, `uuid.UUID(str(entry))` skipping ValueError/TypeError. Return PatternDetail (content if dict else {}).

**7. start_governance_sweep** (:512) — `verify_portfolio_access(db,user,body.portfolio_id)`. `now=utcnow`. `schedule_id = f"gov-{cadence}-adhoc-{now:%Y%m%dT%H%M%S}"`. `workflow_id=f"governance-{portfolio_id}-{schedule_id}"`. `input_dict={portfolio_id:str, schedule_id, triggered_at:now.isoformat(), activities:[]}`. `temporal.start_workflow("GovernanceWorkflow", input_dict, id=workflow_id, task_queue=config.temporal_task_queue)`; ANY Exception → `OlympusHTTPException(502,"TEMPORAL_START_WORKFLOW_FAILED", f"...{exc!r}")`. Build `temporal_ui_url`: `base=getattr(config,"temporal_ui_base_url",None) or ""`; if base → `f"{base.rstrip('/')}/namespaces/{namespace}/workflows/{workflow_id}"` (namespace=`getattr(config,"temporal_namespace","default")`), else None. Return 202 GovernanceSweepResponse(status="running").

**8. list_governance_sweeps** (:587) — sourced from `health_check` rows (one per completed sweep). If `portfolio_id` given → `verify_portfolio_access`. `member_ids = filter_portfolio_ids_by_membership`. If `member_ids is not None`: empty→`paginated_response([],0,...)`; else clause `portfolio_id = ANY(:pf_ids)`. If explicit `portfolio_id` → clause `portfolio_id=:portfolio_id`. total safe scalar. rows `SELECT id,portfolio_id,date,health_index,checks,created_at FROM health_check {where} ORDER BY created_at DESC`. Each row → GovernanceSweepSummary(workflow_id=str(id), started_at=completed_at=created_at, cadence=None, schedule_id=None, status="completed", health_index=float or None).

**9. get_portfolio_cato_evidence** (:811) — OSCAL-flavored rollup. Full algorithm:
1. `verify_portfolio_access`. `SELECT 1 FROM portfolio WHERE id`; None→`OlympusHTTPException(404,"PORTFOLIO_NOT_FOUND")`.
2. Join query (:850): `SELECT s.id system_id, s.name system_name, s.external_id, a.id application_id, a.metadata application_metadata FROM system s LEFT JOIN system_application sa ON sa.system_id=s.id LEFT JOIN application a ON a.id=sa.application_id WHERE s.portfolio_id=:pid AND s.retired_at IS NULL ORDER BY s.kind ASC, COALESCE(s.external_id,s.name) ASC`.
3. Bucket per system (`by_system.setdefault`): fields application_count, cato_certified_application_count, `control_status_counts={implemented,partial,planned,unknown}` all 0, `controls_index={}` (control_id→record), last_assessed=None.
4. Per row where `application_id` not None: `application_count += 1`. `meta=r["application_metadata"] or {}`; `comp=meta.get("compliance")`. If comp dict: if `comp.get("certified") or comp.get("cato_certified")` → `cato_certified_application_count += 1`. `controls_meta=comp.get("controls")`; if dict, for each `cid,rec` where rec dict with `status` → `controls_index[cid]=rec`. `ts=comp.get("last_assessed")`; if str, parse `fromisoformat(ts.replace("Z","+00:00"))`, keep max into bucket last_assessed. Then `status=_classify_control_status(meta)` (no control_id passed) and increment `control_status_counts[status]`.
5. Per system: promote cato_state via rules (:940): if `ccac>0 and ccac==application_count` → "certified"/cato_certified=True (cato_certified_systems++); elif `partial>0`→"in-progress"; elif `planned>0`→"transition"; elif `application_count==0`→"not-started"; else "unknown".
6. Build controls list: if `controls_index` non-empty → per sorted cid: `cstatus=str(rec.get("status") or "unknown")`; coerce to allowed set else "unknown"; if `cstatus != "not-applicable"` call `_count_status`; parse `rec.last_assessed` else bucket's; append `CatoControlEvidence(source="Validation")`. Else fallback: for each `_default_cato_controls()` spec → map cato_state→cstatus (certified→implemented, in-progress→partial, transition→planned, else unknown); `_count_status`; append with source Architecture (if certified/in-progress) / Discovery (if transition) / None.
   - `_count_status(cstatus)` (:965) nonlocal-increments totals_implemented/partial/planned/unknown.
7. Build totals: system_count, cato_certified_systems, application_count=sum, cato_certified_applications=sum, controls_* from totals_*. Return PortfolioCatoEvidence(generated_at=utcnow).

- `_default_cato_controls()` (:756) — profile-driven (P7-S16.2): `pack=active_compliance_pack()`; `[{"id":c.id,"family":c.family,"title":c.title} for c in pack.controls]`. No hardcoded agency controls.
- `_classify_control_status(meta, control_id=None)` (:771): meta not dict→"unknown"; `comp=meta.get("compliance")` not dict→"unknown"; if control_id given and `comp["controls"]` dict has a record dict with status → return `str(record["status"])`; else map coarse `comp.get("cato_state")`: certified→implemented, in-progress→partial, transition→planned, else unknown.

**10. export_compliance_evidence** (:1100) — `verify_portfolio_access`. `SELECT artifact_repo_url FROM portfolio WHERE id`; None→404 PORTFOLIO_NOT_FOUND. `repo=repo_row["artifact_repo_url"] or ""`. Resolve apps: `app_clause="AND a.id=:app_id"` if app_id. Join `system→system_application→application WHERE s.portfolio_id AND s.retired_at IS NULL {app_clause} ORDER BY s.name,a.name`. `svc=_export_git_service(config,repo)`. Per app row build `AppEvidence(app_id,app_name,system_name)`; if svc not None read `.cato/{aid}/ssp.json|sar.json|poam.json` via `_read_cato_file`. `summary={portfolio_id,application_count,generated_at,format}`. `archive=build_evidence_zip(portfolio_id=str,portfolio_summary=summary,apps=apps,fmt=format)`. filename `compliance-evidence-{portfolio_id}-{utcnow:%Y%m%dT%H%M%S}.zip`. Return `Response(content=archive, media_type="application/zip", headers={"Content-Disposition": f'attachment; filename="{filename}"'})`.
   - `format` query: `Literal["oscal","pdf","zip"]="zip"`; `app_id` query: `UUID|None=None`.
   - `_export_git_service(config,repo)` (:1075): `token=config.github_token`; if not repo or not token → None; try `GitService(GitServiceConfig(token,repo,base_url=config.github_base_url))`; GitServiceError→None.
   - `_read_cato_file(svc,path)` (:1092): `svc.read_file(path,branch="main").content`; GitServiceError→None.

**11. upsert_governance_schedule** (:1231) — `verify_portfolio_access`. `pid=str(portfolio_id)`. try: `create_governance_schedule(temporal, pid, cadence=body.cadence, task_queue=config.temporal_task_queue, paused=not body.enabled)`; if not enabled → `set_governance_schedule_paused(temporal, pid, cadence, paused=True)`. ANY Exception → `OlympusHTTPException(502,"TEMPORAL_SCHEDULE_FAILED")`. Return 201 GovernanceScheduleResponse(schedule_id=`schedule_id_for(pid,cadence)`, enabled=body.enabled).

**12. deregister_governance_schedule** (:1278) — `verify_portfolio_access`; `delete_governance_schedule(temporal, str(portfolio_id), cadence=cadence)`; return `Response(status_code=204)`. `cadence` query default "weekly".

## 2.5 Governance-schedule service (`services/governance_schedule.py`)

`CADENCE_CRON = {"weekly":"0 7 * * MON", "quarterly":"0 7 1 */3 *"}` (:28).
`schedule_id_for(pid, cadence="weekly")` → `f"gov-{cadence}-{pid}"` (:34).
`create_governance_schedule(temporal,pid,*,cadence,task_queue,paused=False)` (:38): `cron=CADENCE_CRON.get(cadence,weekly)`; `sid=schedule_id_for`; build `Schedule(action=ScheduleActionStartWorkflow("GovernanceWorkflow", {portfolio_id,schedule_id:sid,cadence,activities:[]}, id=f"governance-{pid}-{cadence}", task_queue), spec=ScheduleSpec(cron_expressions=[cron]), state=ScheduleState(paused))`; `temporal.create_schedule(sid,schedule)`; `ScheduleAlreadyRunningError` swallowed (idempotent). Returns sid.
`delete_governance_schedule` (:86): `get_schedule_handle(sid).delete()`; ANY Exception → warn+continue (best-effort).
`set_governance_schedule_paused(...,paused)` (:111): handle.pause(note="Disabled from portfolio settings") if paused else handle.unpause(note="Enabled...").

## 2.6 Evidence-export builders (`services/evidence_export.py`) — pure, no I/O

`AppEvidence` dataclass (:18): app_id, app_name, system_name, ssp_json/sar_json/poam_json: str|None=None, evidence_records: dict[str,str]={}, narrative: dict[str,str]={}.

`build_evidence_zip(portfolio_id, portfolio_summary, apps, fmt="zip", generated_at=None, integrity_records=None)` (:207): in-memory `zipfile.ZipFile(ZIP_DEFLATED)`.
- if fmt in ("oscal","zip"): write `portfolio-summary.json` = `json.dumps(summary, indent=2, default=str)`. Per app: `base=f"systems/{_slug(system_name)}/apps/{_slug(app_name)}"`; write `{base}/ssp.json`, `/sar.json`, `/poam.json` when present; write each `{base}/evidence/{cid}-evidence.json` from evidence_records; each narrative `{base}/narrative/{name}`. If `integrity_records is not None` → write `integrity-manifest.json` = `build_integrity_manifest(...)`. GOTCHA: default `integrity_records=None` reproduces the pre-P7-S16.16 bundle byte-for-byte.
- if fmt in ("pdf","zip"): write `compliance-evidence-summary.pdf` = `build_pdf_summary(...)`.
- if fmt == "zip": write `README.md` = `_readme(...)`.

`build_pdf_summary(portfolio_id, apps, generated_at=None)` (:106): dependency-free single-stream PDF. Header lines (title, Portfolio, Generated iso, Applications count). Per app: parse SAR JSON at `assessment-results.results[0].observations[*].props[*]` counting `name=="implementation-status"` values implemented/partial/planned (swallow ValueError/TypeError/KeyError/IndexError). Emit `System: .../App: ...`, presence line for SSP/SAR/POA&M, and controls counts line when sar present. Build PDF: content stream `BT /F1 11 Tf 50 770 Td 14 TL` + first 55 lines each `(text) Tj` + `T*` + `ET` (text escaped via `_escape_pdf_text`: `\`→`\\`, `(`→`\(`, `)`→`\)`, latin-1 replace). 5 objects (Catalog/Pages/Page[MediaBox 0 0 612 792]/Contents-stream/Helvetica-Font), xref table, trailer. Returns bytes.

`build_integrity_manifest(integrity_records, generated_at=None)` (:36): per rec build `{control_id, application_id, status, content_hash, prev_hash, ratified:bool}`; `chain_heads[f"{app_id or '-'}:{control_id}"]=content_hash` (last record per chain = tip; callers pass oldest-first). Returns `{algorithm:"sha256", generated_at:iso, record_count, records, chain_heads}`.

`_slug(value)` (:91): keep alnum/-/_, spaces→"-", else drop; "" → "unnamed".
`_readme(portfolio_id, apps, generated_at, has_integrity_manifest=False)` (:285): markdown with per-app checkmark rows; optional integrity line.

## 2.7 Compliance pack (`services/compliance_pack.py`)

`ControlSpec(id,family,title)` frozen (:33). `CompliancePack(framework,artifact_format,controls: tuple[ControlSpec])` frozen (:42); `.is_oscal` = artifact_format lowercased startswith "oscal" (:54).
`_FALLBACK_FRAMEWORK="NIST 800-53 Rev 5"`, `_FALLBACK_ARTIFACT_FORMAT="generic"` (:29) — used ONLY when no active profile; NEVER FAA-specific.
`_coerce_controls(raw)` (:60): non-list→`()`; per dict entry with non-empty `id` → `ControlSpec(id, family=entry.family or id.split("-",1)[0], title=entry.title or "")`.
`compliance_pack_from_profile(profile)` (:82): None→fallback+empty controls; `security=profile.compliance.domains.get("security")`; not dict→fallback; else `CompliancePack(framework=security.framework or fallback, artifact_format=security.artifact_format or fallback, controls=_coerce_controls(security.control_catalog))`.
`active_compliance_pack()` (:108) = `compliance_pack_from_profile(active_profile())`.

---

# 3. gates.py — Gate endpoints (9 endpoints, 730 LOC)

Two routers (`gates.py:86,92`):
- `router = APIRouter(prefix="/api/v1/gates", tags=["Gates"])`
- `wave_gates_router = APIRouter(prefix="/api/v1/waves", tags=["Gates","Waves"])` (batch approve co-located here; both registered in main.py).

Import-time literal sets (:53): `_ESCALATE_REASONS = set(get_args(EscalateReasonCategory))` = {out-of-scope, policy-conflict, needs-senior-review, safety-concern}; `_ESCALATION_RESOLUTION_CATEGORIES = set(get_args(EscalationResolutionCategory))` = {re-extract, manual-augment, re-disposition, rejected-as-escalated}.

Role groups: `VIEWER_PLUS` (:58, no SERVICE), `REVIEWER_ROLES` (:69 = TECH_LEAD, ARCH_LEAD, COMPLIANCE_LEAD, OPERATIONS_LEAD, SAFETY_BOARD, PORTFOLIO_MANAGER, PORTFOLIO_ADMIN), `MANAGER_ROLES` (:81 = PORTFOLIO_MANAGER, PORTFOLIO_ADMIN).

## 3.1 Two-layer RBAC helpers (router-local)

**`_enforce_gate_reviewer(db, user, gate_id)`** (:151) — for APPROVE / advancing decisions. Returns `(policy, scoped_role, decision)`.
1. `gate_type, portfolio_id = gate_svc.get_gate_type_and_portfolio(db, gate_id)`.
2. `scoped_role = resolve_portfolio_role(db,user,portfolio_id)` if portfolio_id not None else (`"portfolio_admin"` if `user.has_role(PORTFOLIO_ADMIN)` else None). GOTCHA: orphaned gate with unresolvable portfolio still reviewable by global admin.
3. scoped_role None → `OlympusHTTPException(403,"PORTFOLIO_NOT_MEMBER")`.
4. `policy = resolve_gate_review_policy(gate_type)`; `decision = evaluate_approver(policy, scoped_role)`.
5. `not decision.allowed` → `OlympusHTTPException(403,"PORTFOLIO_ROLE_INSUFFICIENT", f"Role '{scoped_role}' may not approve a {gate_type} gate. Requires one of: {sorted(policy.allowed_approver_roles())}.")`.

**`_enforce_gate_decider(db, user, gate_id)`** (:198) — for reject/escalate/retry/decision (NON-advancing). Returns scoped_role. Same portfolio/role resolution; `permitted = set(policy.required_reviewer_roles) | set(MANAGEMENT_ROLES)` (reject/rework ALWAYS allowed for reviewers + management regardless of `management_override_allowed`, rbac-model §5.1); `scoped_role not in permitted` → 403 PORTFOLIO_ROLE_INSUFFICIENT.

## 3.2 Endpoint table (mount order)

All `{gate_id}` routes carry `dependencies=[Depends(require_gate_member)]` (portfolio membership) EXCEPT `/pending`.

| # | Method | Path | Role dep | Req | Resp | Line |
|---|--------|------|----------|-----|------|------|
| 1 | GET | `/pending` | (get_current_user only) | q:`portfolio_id`,`wave_id`,`status`,pagination | `dict` | :98 |
| 2 | POST | `/{gate_id}/approve` | require_gate_member | GateApproveRequest|None | GateDetail | :240 |
| 3 | POST | `/{gate_id}/reject` | require_gate_member | GateRejectRequest | GateDetail | :290 |
| 4 | GET | `/{gate_id}/evidence` | require_gate_member + VIEWER_PLUS | — | GateEvidencePackage | :322 |
| 5 | GET | `/{gate_id}/reviewer-roles` | require_gate_member | — | `dict` | :342 |
| 6 | POST | `/{gate_id}/decision` | require_gate_member | GateDecisionRequest | GateDetail | :390 |
| 7 | POST | `/{gate_id}/retry-merge` | require_gate_member + REVIEWER_ROLES | GateMergeRetryRequest|None | GateDetail | :512 |
| 8 | POST | `/{gate_id}/force-advance` | require_gate_member + MANAGER_ROLES | GateForceAdvanceRequest | GateDetail | :544 |
| 9 | POST | `/{gate_id}/resolve-escalation` | require_gate_member + REVIEWER_ROLES | GateEscalationResolveRequest | GateDetail | :596 |
| 10 | POST | `/api/v1/waves/{wave_id}/gates/approve-pending` | REVIEWER_ROLES | WaveBatchApproveRequest, q:`gate_type` | WaveBatchApproveResponse | :640 |

(9 on `gates` router + 1 on `wave_gates_router`.)

## 3.3 Request/response models (`models/gate.py`)

- `EscalateReasonCategory` Literal (:38); `EscalationResolutionCategory` Literal (:48).
- `GateSummary` (:56): id, gate_type, app_id/wave_id: UUID|None, app_name="", wave_name="", status, sla_deadline: datetime|None.
- `GateDetail` (:75): id, gate_type, app_id/wave_id, status, checks: list[dict]|None, evidence_package_url, reviewers: list[str]|None, sla_deadline, decided_at, decided_by, created_at, justification, reject_reason_category, merge_failure_detail: dict|None, pending_approvals: PendingApprovals|None.
- `GateApprovalRecord` (:110): approved_by, approver_role, is_oversight=False, is_management_override=False, approved_at.
- `PendingApprovals` (:120): required, received, remaining, oversight_required=False, oversight_role, oversight_satisfied=True, approvals: list[GateApprovalRecord].
- `GateApproveRequest` (:137): comment: str|None; approve_reason_category: ApproveReasonCategory|None.
- `GateRejectRequest` (:157): reason_category: RejectReasonCategory|None; feedback: str (min_length=1, required non-empty).
- `WaveBatchApproveRequest` (:180): comment: str (min_length=1).
- `WaveBatchApproveResponse` (:199): approved: int; gate_ids: list[UUID].
- `GateDecisionRequest` (:420): action: str; notes; escalation_reason; reason_category: str|None (bare string, validated per-action at router); approve_reason_category; card_decisions: list[CardDecision]|None; reviewer_notes; sort_applied: Literal["workflow","severity"]|None; bulk_approved: bool|None; capability_lineage_decisions: list[CapabilityLineageRowDecision]|None.
- `GateMergeRetryRequest` (:521): note: str|None.
- `GateForceAdvanceRequest` (:544): comment: str (min_length=1); bypass_evidence_check: bool=False.
- `GateEscalationResolveRequest` (:577): resolution_category: EscalationResolutionCategory (required); notes: str|None.

## 3.4 Endpoint logic

**1. list_pending_gates** (:98) — query params: `portfolio_id: UUID|None`, `wave_id: UUID|None`, `status: str="pending"` (pattern `^(pending|rejected|approved|escalated|all)$`). If portfolio_id → `verify_portfolio_access`. `member_ids=filter_portfolio_ids_by_membership`. `gates,total = gate_svc.list_pending_gates(db, pagination, portfolio_id, portfolio_ids=member_ids, wave_id, status)`. `paginated_response([g.model_dump(mode="json")...], total, pagination)`.

**2. approve_gate** (:240) — `comment = body.comment if body else None`. `_enforce_gate_reviewer → (policy,scoped_role,decision)`. `result, advanced = gate_svc.record_gate_approval(db, gate_id, user.sub, scoped_role, minimum_approvals=policy.minimum_approvals, oversight_role=policy.oversight_role, is_oversight=decision.is_oversight, is_management_override=decision.is_management_override, comment)`. GOTCHA: fire Temporal signal ONLY if `advanced` — a pending-quorum gate must NOT signal the workflow. If advanced → `gate_svc.send_gate_temporal_signal(db, str(gate_id), "approve", user.sub, comment or "")`. Return result.

**3. reject_gate** (:290) — `_enforce_gate_decider`. `gate_svc.reject_gate(db, gate_id, user.sub, body.feedback, reason_category=body.reason_category)`. Then `send_gate_temporal_signal(..., "reject", user.sub, body.feedback, reason_category=body.reason_category)`. Return.

**4. get_gate_evidence** (:322) — role dep VIEWER_PLUS + config dep. `gate_svc.get_gate_evidence(db, gate_id, config=config)` (config hydrates slim/reference-only evidence from artifact repo).

**5. get_gate_reviewer_roles** (:342) — resolve gate_type/portfolio; scoped_role (admin fallback); `policy=resolve_gate_review_policy(gate_type)`; `decision=evaluate_approver(policy,scoped_role)` if scoped_role else None. Return dict: gate_id, gate_type, required_reviewer_roles(list), allowed_approver_roles(sorted), minimum_approvals, oversight_role, management_override_allowed, caller_role, `can_approve=bool(decision and decision.allowed)`, `can_force_advance = management_override_allowed and scoped_role in MANAGEMENT_ROLES`.

**6. submit_gate_decision** (:390) — unified. Order:
1. If `action=="escalate"`: `reason_category is None` → 400 ESCALATE_REASON_REQUIRED; `reason_category not in _ESCALATE_REASONS` → 400 ESCALATE_REASON_INVALID.
2. `card_decisions_payload = [cd.model_dump(mode="python") for cd in body.card_decisions] if body.card_decisions else None`.
3. `capability_lineage_decisions_payload` similarly.
4. If cap-lineage payload: per row, `decision=="reject" and not feedback.strip()` → 400 CAPABILITY_LINEAGE_REJECT_FEEDBACK_REQUIRED (with lineage_id in message).
5. RBAC (AFTER cheap 400s): `action=="approve"` → `_enforce_gate_reviewer` else `_enforce_gate_decider`.
6. `result = gate_svc.submit_gate_decision(db, gate_id, user.sub, body.action, body.notes, body.escalation_reason, reason_category, approve_reason_category, card_decisions=payload, reviewer_notes, sort_applied, bulk_approved, capability_lineage_decisions=payload)`.
7. If `action in ("approve","reject")` → `send_gate_temporal_signal(db, str(gate_id), action, user.sub, notes or "", reason_category=(reason_category if reject else None), card_decisions, reviewer_notes)`.

**7. retry_merge** (:512) — REVIEWER_ROLES. `note = body.note if body else None`. `gate_svc.retry_merge_gate(db, gate_id, user.sub, note)`.

**8. force_advance_gate** (:544) — MANAGER_ROLES. Resolve gate_type; `policy=resolve_gate_review_policy`; GOTCHA: if `not policy.management_override_allowed` → 403 GATE_NOT_OVERRIDABLE (e.g. FAA G-V3 non-overridable — even portfolio_admin cannot force-advance; reject-for-rework only). Else `config=get_config()`; `gate_svc.force_advance_gate(db, gate_id, advanced_by=user.sub, comment=body.comment, bypass_evidence_check=body.bypass_evidence_check, config)`.

**9. resolve_escalation** (:596) — REVIEWER_ROLES. `body.resolution_category not in _ESCALATION_RESOLUTION_CATEGORIES` → 400 ESCALATION_RESOLUTION_INVALID. `gate_svc.resolve_escalation(db, gate_id, user.sub, body.resolution_category, body.notes)`.

**10. approve_pending_wave_gates** (:640) — REVIEWER_ROLES. query `gate_type: str|None`. `rows = gate_svc.list_pending_wave_gates(db, wave_id, gate_type)`; empty → `WaveBatchApproveResponse(approved=0, gate_ids=[])`. Per gate_id:
- `_enforce_gate_reviewer`; catch `OlympusHTTPException` with `status_code==403` → `continue` (skip, don't abort batch); other status re-raise.
- `record_gate_approval(...)`; catch `OlympusHTTPException` with `.code=="GATE_ALREADY_DECIDED"` → continue; else re-raise.
- If `advanced` → `send_gate_temporal_signal(..., "approve", user.sub, body.comment)`; `approved_ids.append(gate_id)`. GOTCHA: only advanced (quorum-met) gates count and signal.
Return `WaveBatchApproveResponse(approved=len(approved_ids), gate_ids=approved_ids)`.

## 3.5 Gate-RBAC policy resolution (`services/gate_rbac.py`)

Pure policy resolution — NO DB, NO auth (router enforces).

`MANAGEMENT_ROLES = (PORTFOLIO_MANAGER.value, PORTFOLIO_ADMIN.value)` (:31).

`_PLATFORM_DEFAULTS` (:40) — gate_type → `([required_reviewer_roles], minimum_approvals)`:
```
G-DC:   ([tech_lead, portfolio_manager], 1)      G-DE-1: ([operations_lead], 1)
G-RR:   ([arch_lead, portfolio_manager], 1)      G-DE-2: ([operations_lead, portfolio_manager], 1)
G-DA:   ([portfolio_manager], 1)                 G-V1:   ([tech_lead], 1)
G-02:   ([arch_lead], 1)                          G-V2:   ([compliance_lead], 1)
G-DT:   ([arch_lead, tech_lead], 1)              G-V3:   ([safety_board], 2)   <-- quorum 2
G-04a:  ([tech_lead], 1)                          G-DP-1: ([operations_lead, tech_lead], 1)
G-04b:  ([arch_lead, tech_lead], 1)              G-DP-2: ([operations_lead, portfolio_manager], 1)
G-04c:  ([tech_lead], 1)                          G-NEW-1:([tech_lead],1) G-NEW-2:([arch_lead,tech_lead],1) G-NEW-3:([tech_lead],1)
```
`_UNKNOWN_GATE_DEFAULT` (:64) = ([tech_lead, arch_lead, compliance_lead, operations_lead, safety_board, portfolio_manager], 1) — keeps unknown gate reviewable.

`GateReviewPolicy` frozen dataclass (:77): gate_type, required_reviewer_roles: tuple, minimum_approvals=1, oversight_role: str|None=None, management_override_allowed=True, extension_roles: tuple.
- `allowed_approver_roles()` (:97): set(required_reviewer_roles); if management_override_allowed → add MANAGEMENT_ROLES. GOTCHA: non-overridable gate restricts approval to declared reviewers even for manager/admin.
- `is_oversight_role(role)` = oversight_role is not None and role==oversight_role.

`ApproverDecision` frozen (:113): allowed, is_oversight=False, is_management_override=False.

`evaluate_approver(policy, scoped_role)` (:122):
- `is_reviewer = scoped_role in policy.required_reviewer_roles`; `is_management = scoped_role in MANAGEMENT_ROLES`.
- is_reviewer → `ApproverDecision(allowed=True, is_oversight=is_oversight_role(role), is_management_override=False)` (a manager who ALSO holds reviewer role is a normal reviewer, not override).
- elif is_management AND management_override_allowed → `ApproverDecision(True, is_oversight=..., is_management_override=True)`.
- else → `ApproverDecision(allowed=False)`.

`resolve_gate_review_policy(gate_type, *, profile=None)` (:175): profile defaults to `active_profile()`. Start from `_platform_default(gate_type)`. If profile present and `profile.gates.override(gate_type)` has an `rbac` block: `required_reviewer_roles` (list of str), `minimum_approvals` (int), `oversight_role` (str|None), `management_override_allowed` (bool) override the defaults. `extension_roles = _profile_extension_roles(profile)` (from `profile.gates.additional_roles` entries' `role`). Return `GateReviewPolicy(minimum_approvals=max(1,minimum), ...)`.

## 3.6 Gate service (`services/gate.py`) — endpoint-called functions

**`list_pending_gates(db, params, portfolio_id=None, portfolio_ids=None, wave_id=None, status="pending")`** (:282) → `(list[GateSummary], int)`.
- Build clauses: `status != "all"` → `g.status=:status`. `portfolio_ids is not None`: empty→clause `FALSE`; else `g.portfolio_id = ANY(:pf_ids)`. `portfolio_id` → `g.portfolio_id=:portfolio_id`. `wave_id` → `g.wave_id=:wave_id`. (When both portfolio_id and portfolio_ids present they intersect.)
- total = `SELECT count(*) FROM gate g {where}`.
- order_by: GOTCHA: `status=="rejected"` → `ORDER BY g.decided_at DESC NULLS LAST` (recent rework first); else `ORDER BY g.requested_at ASC` (oldest first).
- rows: `SELECT g.*, a.name app_name, w.name wave_name FROM gate g LEFT JOIN application a ON a.id=g.application_id LEFT JOIN wave w ON w.id=g.wave_id {where} {order_by} LIMIT :limit OFFSET :offset`.
- Map each → `GateSummary(id, gate_type, app_id=application_id, wave_id, app_name or "", wave_name or "", status, sla_deadline)`.

**`list_pending_wave_gates(db, wave_id, gate_type=None)`** (:369) → `list[UUID]`. `SELECT id FROM gate WHERE wave_id=:wid AND status='pending' [AND gate_type=:gt] ORDER BY requested_at`. Returns ids only.

**`get_gate_type_and_portfolio(db, gate_id)`** (:408) → `(gate_type, portfolio_id|None)`. `SELECT g.gate_type, COALESCE(a.portfolio_id, w.portfolio_id) portfolio_id FROM gate g LEFT JOIN application a LEFT JOIN wave w WHERE g.id=:gid`. None row → 404 GATE_NOT_FOUND.

**`_get_gate_or_404`** (:395) — `SELECT * FROM gate WHERE id`; None → `OlympusHTTPException(404,"GATE_NOT_FOUND")`.

**`_gate_detail_from_row(row)`** (:436) → GateDetail from dict (created_at=row["requested_at"]).

**`_persist_card_review(db, gate_id, existing_evidence, card_decisions, reviewer_notes, sort_applied, bulk_approved)`** (:452) — no-op if all None/empty. Merge into `evidence["review"]` block (card_decisions, reviewer_notes, sort_applied, bulk_approved); `UPDATE gate SET evidence_data = CAST(:ev AS JSONB)` (`json.dumps(evidence)`). GOTCHA: text→JSONB cast handles prior-NULL evidence_data cleanly.

**`record_gate_approval(db, gate_id, approved_by, approver_role, *, minimum_approvals, oversight_role, is_oversight, is_management_override, comment=None, card_decisions=None, reviewer_notes=None, sort_applied=None, bulk_approved=None)`** (:622) → `(GateDetail, advanced: bool)`.
- `_get_gate_or_404`; `status != "pending"` → 409 GATE_ALREADY_DECIDED.
- INSERT gate_approval `(gate_id,approved_by,approver_role,is_oversight,is_management_override,comment) ... ON CONFLICT (gate_id, approved_by) DO NOTHING` (idempotent — repeat approval by same user does not double-count).
- `approvals = _load_gate_approvals(db, gate_id)` (ordered approved_at); `received=len`. `quorum_met = received >= minimum_approvals`. `oversight_met = oversight_role is None or any(a["is_oversight"] for a in approvals)`. `advanced = quorum_met and oversight_met`.
- If advanced: `UPDATE gate SET status='approved', decided_at=now, decided_by=approved_by, justification=comment WHERE id`; `_persist_card_review(...)`. commit.
- log `gate_approval_recorded`.
- If advanced → return `(_gate_detail_from_row(row updated), True)`. Else → `detail.pending_approvals = _build_pending_approvals(approvals, minimum_approvals, oversight_role)`; return `(detail, False)`.

**`_build_pending_approvals(approvals, minimum_approvals, oversight_role)`** (:590): received=len; oversight_required = oversight_role is not None; oversight_satisfied = (not required) or any is_oversight; PendingApprovals(required=minimum_approvals, received, remaining=max(0, min-received), oversight_required, oversight_role, oversight_satisfied, approvals=[GateApprovalRecord(...)]).

**`reject_gate(db, gate_id, rejected_by, feedback, reason_category=None, card_decisions=None, reviewer_notes=None, sort_applied=None, bulk_approved=None)`** (:731): `_get_gate_or_404`; `status != "pending"` → 409 GATE_ALREADY_DECIDED. `UPDATE gate SET status='rejected', decided_at=now, decided_by, justification=feedback, reject_reason_category=category`. `_persist_card_review`. commit. Reflect columns into in-memory row (justification, reject_reason_category) since response built from dict not re-read. Return GateDetail.

**`send_gate_temporal_signal(db, gate_id: str, action, actor, message="", reason_category=None, card_decisions=None, reviewer_notes=None)`** (:808) — best-effort, wrapped in try/except (Exception → warn `temporal_signal_failed`, DB state still updated). `SELECT workflow_id, gate_type FROM gate WHERE id=UUID(gate_id)`. No workflow_id → warn `temporal_signal_skipped_no_workflow_id`, return. `get_temporal_client()`.
- action=="approve": `handle.signal("gate_approved", GateApprovedSignal(gate_id, approved_by=actor, justification=message, card_decisions=card_decisions or [], reviewer_notes))`. GOTCHA G-DA dual-signal: if `gate_type=="G-DA"` ALSO `handle.signal("stakeholder_approved", StakeholderApprovedSignal(approval_id=f"gda-{gate_id}", stakeholder=actor, scope="g-da"))` (single approver fires both to unblock wave_rationalization stakeholder hold until a 2nd-approver role ships).
- action=="reject": `handle.signal("gate_rejected", GateRejectedSignal(gate_id, rejected_by=actor, reason=message, reason_category, card_decisions or [], reviewer_notes))`.
- action=="merge_retry": `handle.signal("merge_retry", GateMergeRetrySignal(gate_id, retried_by=actor, note=message or None))`.

**`retry_merge_gate(db, gate_id, retried_by, note=None)`** (:2087): `_get_gate_or_404`; `status != "merge_blocked"` → 409 GATE_NOT_MERGE_BLOCKED. `UPDATE gate SET status='approved', merge_failure_detail=NULL WHERE id` (reviewer's original decision preserved; decided_at/by untouched). commit. `send_gate_temporal_signal(db, str(gate_id), "merge_retry", retried_by, note or "")`. Return GateDetail (status approved, merge_failure_detail None).

**`force_advance_gate(db, gate_id, advanced_by, comment, bypass_evidence_check, config)`** (:2216): `_get_gate_or_404`; `status != "preparing"` → 409 GATE_NOT_PREPARING. If not bypass_evidence_check: `_verify_gate_evidence_exists(row, config)` False → 409 GATE_EVIDENCE_NOT_FOUND. `UPDATE gate SET status='approved', decided_at=now, decided_by, justification=comment`. If app-scoped and `application.current_status` in `_APP_STATUS_ADVANCE` map (:2150, `{line}_in_progress`→`{line}_complete` for all 10 lines) → `UPDATE application SET current_status=advance_to, updated_at=now`; record advanced_app_status. INSERT audit_log `(actor=advanced_by, actor_type='human', action='gate.force_advance', resource_type='gate', resource_id, details JSONB={comment, bypass_evidence_check, from_status:preparing, to_status:approved, advanced_app_status})`. commit. log warning `gate_force_advanced`. Return GateDetail.
- `_verify_gate_evidence_exists(row, config)` (:2164): `evidence_url=row["evidence_package_url"]`; falsy→False; no config.github_token→False; parse GitHub PR url (`.../pull/<n>`, requires len>=7 and parts[-2]=="pull") extracting owner/repo/pr_number; construct GitService and `svc._repo.get_pull(pr_number)` → True; ANY Exception → False.

**`resolve_escalation(db, gate_id, resolved_by, resolution_category, notes=None)`** (:2355): `_get_gate_or_404`; `status != "escalated"` → 409 GATE_NOT_ESCALATED. `justification = notes or f"Escalation resolved: {resolution_category}"`. `new_status = "rejected"` if resolution_category=="rejected-as-escalated" else "pending" (re-extract/manual-augment/re-disposition re-open). `UPDATE gate SET status=:status, decided_at=(now if new_status!="pending" else None), decided_by, justification`. commit. GOTCHA: pending resolutions null out decided_at so the gate reads un-decided again.

**`submit_gate_decision(db, gate_id, decided_by, action, notes=None, escalation_reason=None, reason_category=None, approve_reason_category=None, card_decisions=None, reviewer_notes=None, sort_applied=None, bulk_approved=None, capability_lineage_decisions=None)`** (:2556):
1. `row_summary = _apply_capability_lineage_row_decisions(db, decided_by, capability_lineage_decisions)` FIRST (per-row updates commit independently). Returns `{ratified, rejected, rework_feedback:[{lineage_id,source_capability,target_capability,feedback}]}`.
2. If `row_summary["rework_feedback"]`: build a `--- capability_lineage row rework ---` block appended to BOTH augmented_reviewer_notes and augmented_notes (never replaces reviewer prose).
3. `action=="approve"` → `approve_gate(db, gate_id, decided_by, augmented_notes, approve_reason_category, card_decisions, reviewer_notes=augmented_reviewer_notes, sort_applied, bulk_approved)`; then `_persist_capability_lineage_rework_block(db, gate_id, row_summary)`; return.
4. `action=="reject"` → `feedback = augmented_notes or "Rejected without notes"`; `reject_gate(...)`; persist rework block; return.
5. `action=="escalate"` → `_get_gate_or_404`; status!="pending"→409 GATE_ALREADY_DECIDED; `reason=escalation_reason or notes or ""`; `UPDATE gate SET status='escalated', decided_at=now, decided_by, justification=reason`; `_persist_card_review(...augmented_reviewer_notes...)`; commit; persist rework block; log `gate_escalated`; return GateDetail(status escalated).
6. else → 400 INVALID_ACTION.

**`approve_gate(db, gate_id, approved_by, comment=None, approve_reason_category=None, card_decisions=None, reviewer_notes=None, sort_applied=None, bulk_approved=None)`** (:499) — single-decision path (NOT quorum-aware; used by submit_gate_decision). `_get_gate_or_404`; status!="pending"→409; `UPDATE gate SET status='approved', decided_at=now, decided_by, justification=comment`; `_persist_card_review`; commit. `approve_reason_category` logged only (NOT persisted to gate row in this version). Return GateDetail.

**`get_gate_evidence(db, gate_id, config=None)`** (:1652) → GateEvidencePackage. Reads real agent output from `gate.evidence_data` JSONB. Discovery stores units under `passes`; every other step-emitting line under `steps` tagged with `assembly_line`. GOTCHA (fixed 2026-05-09): the `assembly_line` tag drives contract step-order + storage-prefix lookup via `_STEP_BASED_LINE_CONFIG`; earlier code hardcoded Rationalization order causing empty G-DT/G-02/Data/Architecture/Modernization/Disposition/Validation/Deployment cards. `config` hydrates slim (reference-only) evidence contents from artifact repo. (Full ~330-LOC builder: resolves app/wave display names, builds artifact cards per contract pass/step order, substitutes app UUIDs→names, attaches actor-kind badge, AI recommendation, agent_error_count. See :1652-1979.)

---

# 4. skills.py — Skill lifecycle (11 endpoints)

Router: `APIRouter(prefix="/api/v1/skills", tags=["Skills"])` (`skills.py:51`).
Role groups: `VIEWER_PLUS` (:34, INCLUDES SERVICE), `MANAGER_ROLES` (:46 = PORTFOLIO_MANAGER, PORTFOLIO_ADMIN).

| # | Method | Path | Role | Req | Resp | Status | Line |
|---|--------|------|------|-----|------|--------|------|
| 1 | GET | `""` | VIEWER_PLUS | q:`assembly_line`,`source`,`status`,pagination | `dict` | 200 | :54 |
| 2 | POST | `""` | MANAGER_ROLES | SkillCreate | SkillDetail | 201 | :72 |
| 3 | GET | `/categories` | VIEWER_PLUS | — | `dict` | 200 | :82 |
| 4 | GET | `/metrics` | VIEWER_PLUS | — | `dict` | 200 | :104 |
| 5 | GET | `/metrics/by-line` | VIEWER_PLUS | — | `dict` | 200 | :146 |
| 6 | GET | `/dispatch/{dispatch_id}` | VIEWER_PLUS | — | SkillDetail | 200/404 | :174 |
| 7 | GET | `/{skill_id}` | VIEWER_PLUS | — | SkillDetail | 200/404 | :184 |
| 8 | GET | `/{skill_id}/variants` | VIEWER_PLUS | — | `dict` | 200/404 | :194 |
| 9 | GET | `/{skill_id}/metrics` | VIEWER_PLUS | — | `dict` | 200 | :218 |
| 10 | PUT | `/{skill_id}` | MANAGER_ROLES | SkillUpdate | SkillDetail | 200/404 | :238 |
| 11 | DELETE | `/{skill_id}` | MANAGER_ROLES | — | — | 204 | :249 |

GOTCHA: mount order matters — `/categories`, `/metrics`, `/metrics/by-line`, `/dispatch/{...}` are declared BEFORE `/{skill_id}` so the static segments win over the `{skill_id}` catch-all.

## 4.1 Endpoint logic

**1. list_skills** (:54) — `skill_svc.list_skills(db, pagination, assembly_line, source, status)`; `paginated_response([s.model_dump(mode="json")...], total, pagination)`.

**2. create_skill** (:72) — `skill_svc.create_skill(db, body)`.

**3. list_categories** (:82) — registry-sourced (NOT DB): `registry=get_registry()`; count per `s.category`; return `{"data": [{"category":cat,"count":n} for cat in sorted(counts)]}`.

**4. get_global_skill_metrics** (:104) — single aggregate over `agent_task`: `SELECT count(*) total, SUM(CASE status='completed' ...) completed, failed, timed_out, AVG(duration_ms), AVG(cost_estimate)`. Return `{total_dispatches, completed, failed, timed_out, avg_duration_ms(float), avg_cost_estimate(float)}` all zero-defaulted.

**5. get_skill_metrics_by_line** (:146) — `skill_svc.list_line_skill_metrics(db)` (see §4.3).

**6. get_skill_by_dispatch** (:174) — `skill_svc.get_skill_by_dispatch_id(db, dispatch_id)`.

**7. get_skill** (:184) — `skill_svc.get_skill(db, skill_id)`.

**8. get_skill_variants** (:194) — registry-sourced: `entry=registry.find(skill_id)`; None → `OlympusHTTPException(404,"SKILL_NOT_FOUND")`; return `{"skill_id":skill_id, "data":[{"id":v.id,"when":dict(v.when)} for v in entry.variants]}`.

**9. get_skill_metrics** (:218) — `skill_metrics_svc.get_skill_metrics(db, skill_id)`.

**10. update_skill** (:238) — `skill_svc.update_skill(db, skill_id, body)`.

**11. delete_skill** (:249) — `skill_svc.delete_skill(db, skill_id)`; returns None (204).

## 4.2 Skill CRUD service (`services/skill.py`)

`_row_to_detail(row)` (:21) — builds `SkillDetail`. GOTCHA: `output_schemas = load_output_schemas_for_skill(skill_id)` read from disk (SKILL.md frontmatter, baked into API image) not the DB; `or None` (empty→None). Without this the dispatch response carried `output_schemas: null` and strict output validation silently never ran.

`list_skills(db, pagination, assembly_line=None, source=None, status=None)` (:64): where clauses — GOTCHA assembly_line uses `LOWER(assembly_line) = LOWER(:assembly_line)` (stored Title-Cased 'Discovery' but callers pass 'discovery'; exact match silently returned zero). source→`source=:source`; status→`status=:status`. `count(*)`; `SELECT * FROM skill{where} ORDER BY assembly_line, skill_id LIMIT/OFFSET`. Returns `([_row_to_detail], int)`.

`get_skill(db, skill_id)` (:109): `SELECT * FROM skill WHERE skill_id`; None → 404 SKILL_NOT_FOUND.

`create_skill(db, body)` (:124): dup check `SELECT id ... WHERE skill_id` → 409 SKILL_EXISTS. `new_id=uuid4()`; INSERT with `status='active'`; JSONB columns (references_data, assets_data, scripts_data, config_data, allowed_tools, dispatch_ids) `json.dumps(x) if x else None`. commit. Return `get_skill(body.skill_id)`.

`update_skill(db, skill_id, body)` (:188): `get_skill` (404 guard). `updates=body.model_dump(exclude_none=True)`; empty→return get_skill. Serialize `_JSONB_COLUMNS` (:182) via json.dumps. `UPDATE skill SET {set_clauses}, updated_at=now() WHERE skill_id`. commit. Return get_skill.

`delete_skill(db, skill_id)` (:220): `get_skill` (404 guard); `DELETE FROM skill WHERE skill_id`; commit.

`get_skill_by_dispatch_id(db, dispatch_id)` (:230): `SELECT * FROM skill WHERE dispatch_ids @> CAST(:dispatch_ids AS jsonb) AND status='active'` (`json.dumps([dispatch_id])`, uses GIN index); None → 404 SKILL_NOT_FOUND.

## 4.3 Per-line skill metrics `list_line_skill_metrics(db)` (:375)

Aggregates dispatch metrics per assembly line across ALL 10 lines (zero-count blocks included). Two-source dedup:
1. Pre-build `lines[line]=_empty_line_block(line)` and `line_skills[line]={}` for every `AssemblyLine` enum value.
2. **Envelope path (primary)**: `SELECT line_id,status,duration_ms,agent_task_id,payload FROM step_execution WHERE step_kind='agent'`. Map line_id (kebab OR display form both accepted via `line_id_to_enum`). Unknown line_id → skip. Parse payload (json.loads if str). `skill_id=payload.skill_id or "(unknown)"`, model=payload.model_used, cost=payload.cost_estimate_usd. `_accumulate_counters(line_block/skill_bucket, status, duration_ms, cost)`; `skill_bucket["sources"]["envelope"]+=1`; increment `models[model]`; `source_counts["envelope"]+=1`. If `agent_task_id` present → add to `seen_agent_task_ids`.
3. **agent_task fallback**: `SELECT id,task_type,skill_id,status,duration_ms,cost_estimate,model_used FROM agent_task`. GOTCHA dedup: if `id in seen_agent_task_ids` → skip (already counted via envelope). `line_enum = task_type_to_line.get(task_type)` (via `step_mapping.task_type_to_line_map()`); unknown → skip (legacy retired-pipeline rows). `skill_id = skill_id or task_type`. Accumulate; `sources["agent_task"]+=1`; `source_counts["agent_task"]+=1`.
4. Finalize: `_finalize_bucket` on each line and skill bucket (avg_duration_ms=round(sum/n,2) or 0.0; avg_cost_usd=round(total_cost/total_dispatches,6) or 0.0; total_cost_usd rounded 6). Sum into cross-line totals.
5. Return `{"source_breakdown":source_counts, "totals":{total_dispatches,completed,failed,timed_out,total_cost_usd}, "lines":[block...]}`. Each block: assembly_line(display), line_id(kebab), counters, avgs, `skills:[{skill_id, counters, avg_duration_ms, avg_cost_usd, models:{model:count}, sources:{envelope,agent_task}}]` (skills sorted by id).

Helpers: `_accumulate_counters(bucket,status,duration_ms,cost)` (:337) — total_dispatches++; per-status counter; duration into `_duration_sum`/`_duration_n`; cost into total_cost_usd. `_finalize_bucket` (:363). `_line_ids_for(line)` (:286) → `(line.value.lower().replace(" ","-"), line.value)`.

## 4.4 Skill-metrics projection (`services/skill_metrics.py`)

`recompute_skill_metrics(db, skill_id)` (:31) — recompute/upsert projection (git-is-truth: table is derived, disposable). INSERT INTO skill_metrics SELECT from agent_task WHERE skill_id, with `ON CONFLICT (skill_id) DO UPDATE`. `invocations_total=count(*)`; `gate_pass_rate = NULL if terminal(completed+failed+timed_out)==0 else completed/terminal (numeric)`; `avg_quality_score=AVG(quality_score)`. GOTCHA: `CAST(:skill_id AS VARCHAR)` explicit — same bind used as bare SELECT projection (asyncpg deduces `text`) and in WHERE against varchar column; without cast asyncpg raises AmbiguousParameterError → 500 on every task completion carrying a skill_id. Caller owns transaction/commit.

`get_skill_metrics(db, skill_id)` (:88): `SELECT invocations_total, gate_pass_rate, avg_quality_score FROM skill_metrics WHERE skill_id`; missing→`{}`. Return `{skill_id, invocations_total(int, 0 default), gate_pass_rate(float|None), avg_quality_score(float|None)}`.

---

# 5. agents.py — Agent task telemetry ingestion (2 endpoints)

Router: `APIRouter(prefix="/api/v1/agents", tags=["Agents"])` (`agents.py:36`). `SERVICE_ONLY = [RBACRole.SERVICE]` (:34) — only service identities (agent-runtime, worker) POST task telemetry. Former viewer read surface retired in P5-S26 (model-tier telemetry moved to `/api/v1/analytics/model-usage`).

| # | Method | Path | Role | Req | Resp | Status | Line |
|---|--------|------|------|-----|------|--------|------|
| 1 | POST | `/tasks` | SERVICE | AgentTaskStartRequest | AgentTaskRecordResponse | 202 | :39 |
| 2 | POST | `/tasks/{task_id}/complete` | SERVICE | AgentTaskCompleteRequest | AgentTaskRecordResponse | 200/404 | :62 |

Models (`models/agent.py`):
- `AgentTaskStartRequest` (:187): task_id: UUID (dedup key), agent_id, skill_id: str|None, task_type, workflow_id: str|None, application_id: UUID|None, wave_id: UUID|None, model_requested, model_used, started_at: datetime, agent_backend, provider_name, provider_fallback_from.
- `AgentTaskTimingBlock` (:222): llm_ms, tool_ms, tool_call_count (all int|None, ge=0).
- `AgentTaskCompleteRequest` (:239): status: Literal["completed","failed","timed_out"], completed_at: datetime, duration_ms, input_tokens, output_tokens, cache_read_tokens, cache_write_tokens, quality_score(ge=0,le=1), error_code, artifact_id: UUID|None, cost_estimate, model_used, timing: AgentTaskTimingBlock|None.
- `AgentTaskRecordResponse` (:266): task_id: UUID, status: str, recorded: bool=True.

**1. record_task_start** (:39) — `agents_svc.record_task_start(db, body)`; return `AgentTaskRecordResponse(task_id=body.task_id, status="running")`. Idempotent.

**2. record_task_complete** (:62) — `updated = agents_svc.record_task_complete(db, task_id, body)`; `not updated` → `OlympusHTTPException(404,"TASK_NOT_FOUND", f"Agent task '{task_id}' was not recorded at start")`; return `AgentTaskRecordResponse(task_id, status=body.status)`.

## 5.1 Agents ingestion service (`services/agents.py`)

`record_task_start(db, req)` (:26): GOTCHA scope check — `has_app == has_wave` (both or neither) → `OlympusHTTPException(400,"INVALID_TASK_SCOPE")` (agent_task enforces exactly-one via `agent_task_application_or_wave_ck`, migration 044; caught here to avoid unhandled 500 + dropped telemetry). INSERT INTO agent_task (id, task_type, application_id, wave_id, agent_id, skill_id, workflow_id, status='running', agent_backend, model_requested, model_used, provider_name, provider_fallback_from, dispatched_at=started_at, started_at) `ON CONFLICT (id) DO NOTHING`. commit.

`record_task_complete(db, task_id, req)` (:89) → bool. `timing_json = json.dumps(req.timing.model_dump(exclude_none=True))` if timing else None. UPDATE agent_task SET status, completed_at, duration_ms, input/output/cache_read/cache_write_tokens, quality_score, error_code, artifact_id, `cost_estimate=COALESCE(:cost_estimate, cost_estimate)`, `model_used=COALESCE(:model_used, model_used)`, `token_usage = CASE WHEN CAST(:timing_json AS jsonb) IS NOT NULL THEN jsonb_set(COALESCE(token_usage,'{}'::jsonb),'{timing}',CAST(:timing_json AS jsonb),true) ELSE token_usage END` WHERE id RETURNING skill_id. GOTCHA: `RETURNING skill_id` both detects unknown-task (no row → `rollback()`, return False → 404) and keys the projection refresh. If skill_id → `skill_metrics_svc.recompute_skill_metrics(db, skill_id)` in the SAME transaction (atomic with terminal update, P5-S30.9). commit; return True.

---

# 6. agent_roles.py — Declared agent roles (1 endpoint)

Router: `APIRouter(prefix="/api/v1/agent-roles", tags=["Agent Roles"])` (`agent_roles.py:43`). `VIEWER_PLUS` (:31, INCLUDES SERVICE). Distinct from agents.py (which was model-tiers).

| # | Method | Path | Role | Req | Resp | Line |
|---|--------|------|------|-----|------|------|
| 1 | GET | `""` | VIEWER_PLUS (+get_current_user) | q:`portfolio_id`,`since` | AgentRoleListResponse | :46 |

`since` query: `str="30d"` pattern `^(7d|30d|all)$` — RESERVED/no-op (`# noqa: ARG001`); implementation always uses fixed 30-day window.

Logic (:69): if portfolio_id → `verify_portfolio_access`; `member_ids=filter_portfolio_ids_by_membership`; `roles = agent_roles_svc.get_agent_roles(db, portfolio_id, portfolio_ids=member_ids)`; return `AgentRoleListResponse(data=roles)`.

Models: `AgentRoleSummary` (`models/agent_role.py:27`): name, description="", model_tier: str|None, preferred_model_tier: str|None, assembly_lines/skill_ids/capabilities: list[str], version="0.0.0", tasks_total=0, tasks_last_30d=0, success_rate_30d: float|None(ge=0,le=1), last_active_at: datetime|None, status: AgentRoleStatus="declared-inactive". `AgentRoleListResponse(:56)`: data: list[AgentRoleSummary].

## 6.1 Agent-roles service (`services/agent_roles.py`)

Feeds Agent Registry page: declared roles from `olympus-worker/config/agents.yaml` joined with per-role activity from `agent_task`.

`_worker_config_dir()` (:49) — locate dir holding agents.yaml, or None (graceful empty-list degrade). Search: (1) `OLYMPUS_WORKER_CONFIG_DIR` env if `is_dir`; (2) walk up from this module for `olympus-worker/config/`; (3) walk up from CWD; (4) container candidates `/app/repo/olympus-worker/config`, `/app/olympus-worker/config`.

`load_agent_roles_config(path=None)` (:101) — resolve target (path or `<dir>/agents.yaml`); non-file→`[]`+warn; `yaml.safe_load`, YAMLError→`[]`; non-dict→`[]`; `entries=raw.get("agents") or []`; non-list→`[]`; keep dict entries with `name`.

`_aggregate_per_skill(db, *, since_30d, portfolio_id, portfolio_ids=None)` (:178) → `{skill_id: {tasks_total, tasks_30d, success_30d, terminal_30d, last_active_at}}`. `has_filter = portfolio_id is not None or portfolio_ids is not None`. If portfolio_ids empty→`{}`. GOTCHA: filtered branch uses `INNER JOIN application a ON a.id=at.application_id` — intentionally EXCLUDES wave-scoped agent_task rows (application_id NULL). Unfiltered branch selects from agent_task directly with `skill_id IS NOT NULL`; filtered uses `at.skill_id IS NOT NULL`. Counters via `FILTER (WHERE ...)`: tasks_30d (started_at>=since_30d), success_30d (+status='completed'), terminal_30d (+status IN completed/failed/timed_out), MAX(started_at) last_active_at. `_safe_execute` tolerates missing relation/column.

`_combine_per_role(role, per_skill)` (:274) — sum per-skill aggregates over `role["skill_ids"]`; `success_rate_30d = success_30d/terminal_30d` if terminal else None; last_active = max.

`_resolve_model_tier(role)` (:310) — pref=`role.preferred_model_tier`; tier=`role.get("model_tier", pref)`; return `(str(tier)|None, str(pref)|None)`.

`get_agent_roles(db, portfolio_id=None, portfolio_ids=None, *, config_path=None)` (:331) — `role_entries=load_agent_roles_config`; empty→`[]`. `since_30d = now - 30d`. `per_skill=_aggregate_per_skill(...)`. Per role: `(tier,preferred)=_resolve_model_tier`; `aggregates=_combine_per_role`; `status = "active" if tasks_last_30d>0 else "declared-inactive"`; append AgentRoleSummary with all fields.

---

# 7. agent_runs.py — Cross-app recent errors (1 endpoint)

Router: `APIRouter(prefix="/api/v1/agent-runs", tags=["Agent Runs"])` (`agent_runs.py:23`).

| # | Method | Path | Role | Req | Resp | Line |
|---|--------|------|------|-----|------|------|
| 1 | GET | `/recent-errors` | (get_current_user only) | q:`limit`(1-100,def20),`portfolio_id` | AgentRunErrorListResponse | :26 |

Logic (:27): if portfolio_id → `verify_portfolio_access`; `member_ids=filter_portfolio_ids_by_membership`; `agent_runs.list_recent_errors(db, limit, portfolio_id, portfolio_ids=member_ids)`.

Models: `AgentRunError` (`models/agent_run.py:20`): task_id: UUID, task_type, status: AgentRunStatus, app_id: UUID|None, app_name, module_name, agent_backend, model_used, last_error, failed_at: datetime|None, duration_ms: int|None, retry_count=0. `AgentRunErrorListResponse` (:37): errors: list[AgentRunError], limit: int.

## 7.1 Service `list_recent_errors(db, *, limit=20, portfolio_id=None, portfolio_ids=None)` (`services/agent_runs.py:18`)

`clauses=["at.status IN ('failed','timed_out')"]`; `join_app="LEFT"`. If portfolio_ids not None: empty→`AgentRunErrorListResponse(errors=[])`; else clause `a.portfolio_id = ANY(:pf_ids)`, `join_app="INNER"`. If portfolio_id: clause `a.portfolio_id=:portfolio_id`, `join_app="INNER"`. GOTCHA: scoping switches the JOIN to INNER (drops rows with NULL application_id / no matching app). Query: `SELECT at.id,task_type,status,application_id, a.name app_name, module_name, agent_backend, model_used, last_error, completed_at, duration_ms, COALESCE(at.retry_count,0) retry_count FROM agent_task at {join_app} JOIN application a ON a.id=at.application_id {where} ORDER BY at.completed_at DESC NULLS LAST, at.dispatched_at DESC NULLS LAST LIMIT :limit`. Map each → `AgentRunError(task_id=id, ..., failed_at=completed_at, retry_count or 0)`. Return `AgentRunErrorListResponse(errors, limit)`.

---

## Cross-cutting notes / gotchas summary

- registries writes are IN-PROCESS only (no YAML persistence); profile activation is authoritative.
- `_json_safe_metadata` filters non-JSON `selection_table` → `has_selection_table: True`.
- governance endpoints tolerate pre-migration-025 missing tables via `_safe_execute_*` (empty list/None).
- cATO endpoint control catalog is profile-driven (`active_compliance_pack`), never hardcoded FAA.
- Gate approve/batch-approve fire the Temporal signal ONLY when the gate actually advances (quorum met) — pending-quorum gates never signal the workflow.
- G-DA approve fires a SECOND `stakeholder_approved` signal (dual-signal gate).
- Non-overridable gate (`management_override_allowed: false`, e.g. FAA G-V3) cannot be force-advanced by ANY role including portfolio_admin.
- `resolve_escalation` nulls decided_at for re-open (pending) resolutions.
- `record_task_complete` uses `RETURNING skill_id` for both 404-detection and projection-refresh keying; `recompute_skill_metrics` needs `CAST(:skill_id AS VARCHAR)` to avoid asyncpg AmbiguousParameterError.
- `list_line_skill_metrics` dedups envelope vs agent_task by `agent_task_id`/`id` — every terminal dispatch counted exactly once.
- `list_skills` matches `assembly_line` case-insensitively (`LOWER()` both sides).
- `_aggregate_per_skill` filtered branch INNER-joins application → excludes wave-scoped tasks.
- `agent_runs.list_recent_errors` switches to INNER join when portfolio-scoped.
