# Activity group: `ingestion` — legacy reverse-engineering ingestion + drift-enrollment

Atomic regeneration spec for the two activity modules that implement the P8
**legacy-ingestion / reverse-engineering** line:

- `temporal/olympus_workflows/activities/ingestion.py` — the READ-ONLY legacy
  walk that reconstructs a spec + surfaces/routes safety-classifier hits.
- `temporal/olympus_workflows/activities/ingestion_drift.py` — enrolls the
  reconstructed obligations in the existing bidirectional drift engine.

**Activity functions in this group (units = 2):**

| # | Activity (`@foundry_activity`) | Module | Signature |
|---|---|---|---|
| 1 | `ingest_legacy_source(input) -> IngestLegacySourceResult` | ingestion.py | `ingestion.py:620-661` |
| 2 | `enroll_reconstructed_obligations(payload) -> EnrollReconstructedResult` | ingestion_drift.py | `ingestion_drift.py:142-163` |

There are **no** `persist_*`, git, or agent-dispatch activities in this group.
(The one arm that reaches an external service is the safety-classifier routing
inside `ingest_legacy_source`, which lazily imports the agent-runtime FedRAMP
provider-selection surface — documented in full below.) Both activities carry
`ActivityConfig(enable_observability=True)` and delegate to pure, unit-testable
cores; all nondeterminism (filesystem reads, classifier I/O, provider routing)
lives on the activity side (`ingestion.py:5-9`).

---

## 0. What `@foundry_activity` adds over raw `@activity.defn`

Decorator source: `temporal/olympus_workflows/temporal_base/activities.py:79-150`.
Both activities are decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

`foundry_activity(config=None, name=None, **activity_kwargs)` returns a decorator
(`activities.py:79-97`). Inside:

1. `activity_config = config or ActivityConfig()` (`activities.py:98`). `ActivityConfig`
   defaults (`activities.py:41-53`): `retry_policy=None`, all four timeouts `None`,
   `heartbeat_timeout=None`, `enable_observability=True`, `enable_error_wrapping=True`,
   `log_inputs=False`, `log_outputs=False`. **Both ingestion activities pass only
   `enable_observability=True`**, so `enable_error_wrapping` stays `True` (default),
   no retry policy / no timeouts / no heartbeat are set here — those come from the
   worker's per-activity `execute_activity` options at call sites, not from the decorator.
2. The inner function is wrapped `@activity.defn(name=name, **activity_kwargs)` over
   `@wraps(func)` (`activities.py:100-101`). **GOTCHA:** the activity *name* defaults
   to the Python function name and MUST be preserved — Temporal replay keys on it
   (`activities.py:14-16, 103`). So the registered activity names are exactly
   `ingest_legacy_source` and `enroll_reconstructed_obligations`.
3. `wrapper` is `async` and `await`s `func(*args, **kwargs)` (`activities.py:102, 113`).
   Both target functions are `async def`, matching.

**Observability (enabled):**
- On entry, if `enable_observability`: `logger.info("Activity %s starting", activity_name,
  extra={"inputs": args if log_inputs else None})` (`activities.py:105-110`). `log_inputs`
  is `False` here → `extra={"inputs": None}`.
- On success, `logger.info("Activity %s completed", activity_name, extra={"outputs":
  result if log_outputs else None})` (`activities.py:115-120`). `log_outputs` is `False`
  → `extra={"outputs": None}`.
- On any exception, `logger.error("Activity %s failed: %s", activity_name, error,
  extra={"error": str(error)})` (`activities.py:125-131`).
- `logger` is a stdlib `logging.getLogger(__name__)` (`activities.py:38`) — **no
  Prometheus/structlog dependency, safe outside the workflow sandbox** (`activities.py:6-7`).

**Error wrapping (enabled, default `True`):** in the `except Exception as error` block
(`activities.py:124-146`):
- If the escaping error is already a `WorkflowError` or a `temporalio` `ApplicationError`,
  it is `raise`d unchanged (`activities.py:135-136`). **This is the path
  `ReadOnlyViolationError`, `SafetyClassifierError`, and `NonRetryableError` take — they
  subclass `NonRetryableError → WorkflowError → ApplicationError`, so they pass through
  with their `non_retryable=True` flag intact** (see errors below).
- Else if `_is_retryable_error(error)` → re-raise as `RetryableError(f"Retryable error in
  {activity_name}: {error}")` (`activities.py:137-140`).
- Else → re-raise as `NonRetryableError(f"Non-retryable error in {activity_name}: {error}")`
  (`activities.py:141-144`).

`_is_retryable_error(error)` (`activities.py:56-76`) — **type-name substring match, NOT
instance inspection** (`activities.py:59-63`): computes `error_str = str(type(error)).lower()`
and returns `True` iff any of these appear: `timeout, connection, network, temporary,
unavailable, overload, busy, throttle, rate_limit`. **GOTCHA:** this is deliberately
distinct from `errors.is_retryable_error` (which inspects httpx/OSError/ApplicationError
instances) — the decorator path keys ONLY on the type-name string (`activities.py:57-63`).
So an arbitrary `FileNotFoundError` raised inside the walk (type name
`<class 'FileNotFoundError'>`) contains none of the patterns → wrapped `NonRetryableError`.
A `TimeoutError` (name contains "timeout") → wrapped `RetryableError`.

**Error taxonomy** (`temporal_base/errors.py`):
- `WorkflowError(ApplicationError)` — `__init__(message, non_retryable=True)` (`errors.py:16-20`).
- `RetryableError(WorkflowError)` — forces `non_retryable=False` (`errors.py:23-27`).
- `NonRetryableError(WorkflowError)` — forces `non_retryable=True` (`errors.py:30-34`).
- `ReadOnlyViolationError(NonRetryableError)` (`ingestion.py:57-64`) and
  `SafetyClassifierError(NonRetryableError)` (`ingestion.py:67-74`) → both
  `non_retryable=True` and pass through the decorator unchanged.

---

# Activity 1 — `ingest_legacy_source`

`ingestion.py:620-661`. Decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`
(`ingestion.py:620`). `async def ingest_legacy_source(input: IngestLegacySourceInput) ->
IngestLegacySourceResult`.

## 1.1 Input shape — `IngestLegacySourceInput`

`@dataclass` (`ingestion.py:275-293`). Fields, in order, with defaults:

| Field | Type | Default | Meaning (source) |
|---|---|---|---|
| `app_id` | `str` | (required) | application being reverse-engineered (`ingestion.py:288`) |
| `source_root` | `str` | (required) | path to unpacked READ-ONLY legacy tree (`ingestion.py:289`) |
| `confidence_floor` | `float` | `DEFAULT_CONFIDENCE_FLOOR = 0.5` | profile sub-floor, REQ-LI-004 (`ingestion.py:203, 290`) |
| `profile_id` | `str` | `""` | routing facts for the FedRAMP provider resolve (`ingestion.py:291`) |
| `max_files` | `int` | `5000` | cap on ingested files (`ingestion.py:292`) |
| `route_classifier_hits` | `bool` | `True` | drives REQ-LI-006 routing; a unit caller with no agent-runtime sets `False` (`ingestion.py:293`) |

## 1.2 Output shape — `IngestLegacySourceResult`

`@dataclass` (`ingestion.py:296-344`). A **Temporal-SAFE flat projection** — carries only
fully-typed serializable fields because the frozen contract types carry `metadata:
dict[str, object]` that the data converter cannot rehydrate (`ingestion.py:298-313`).

| Field | Type | Default | Written from |
|---|---|---|---|
| `app_id` | `str` | (required) | `spec.app_id` (`ingestion.py:652`) |
| `source_root` | `str` | (required) | `spec.source_root` (`ingestion.py:653`) |
| `obligations` | `tuple[ReconstructedObligation, ...]` | `()` | `tuple(spec.obligations)` (`ingestion.py:654`) |
| `obligations_total` | `int` | `0` | `report.obligations_total` (`ingestion.py:655`) |
| `low_confidence_count` | `int` | `0` | `report.low_confidence_count` (`ingestion.py:656`) |
| `file_count` | `int` | `0` | `int(spec.metadata.get("file_count", 0))` (`ingestion.py:657`) |
| `classifier_domains` | `tuple[str, ...]` | `()` | `tuple(report.classifier_domains)` (`ingestion.py:658`) |
| `write_attempts_refused` | `int` | `0` | `report.write_attempts_refused` (always `0` today, see 1.7) (`ingestion.py:659`) |
| `classifier_routes` | `list[tuple[str, str, str]]` | `field(default_factory=list)` | `routes` from `route_safety_classifier_hits` (`ingestion.py:324, 660`) |

**GOTCHA — `obligations` DO cross the wire but the frozen `ReconstructedSpec`/`IngestionReport`
do NOT.** `ReconstructedObligation` is `@dataclass(frozen=True, slots=True)` with only
`str/float/bool` fields (no `dict[str,object]`), so it rides as-is; the two container
contracts carry `metadata: dict[str, object]` so they are rebuilt off-wire only
(`ingestion.py:301-313, 648-650`).

Rehydration helpers (off the wire, NOT on the activity boundary):
- `to_spec()` (`ingestion.py:326-333`) → `ReconstructedSpec(app_id, source_root,
  obligations=tuple(self.obligations), metadata={"file_count": self.file_count})`.
- `to_report()` (`ingestion.py:335-344`) → `IngestionReport(app_id, obligations_total,
  low_confidence_count, classifier_domains=tuple(...), write_attempts_refused,
  metadata={"file_count": self.file_count})`.

## 1.3 Frozen contract types read/written (`olympus-contracts/olympus_contracts/ingestion_types.py`)

- `REVERSE_ENGINEERED = "reverse_engineered"` (`ingestion_types.py:24`) — the fixed
  provenance marker stamped on every obligation.
- `ReconstructedObligation` `@dataclass(frozen=True, slots=True)` (`ingestion_types.py:27-42`):
  `ref: str`, `statement: str`, `confidence: float`, `provenance: str = REVERSE_ENGINEERED`,
  `needs_confirmation: bool = False`.
- `ReconstructedSpec` `@dataclass(frozen=True, slots=True)` (`ingestion_types.py:45-63`):
  `app_id: str`, `source_root: str`, `obligations: tuple[ReconstructedObligation, ...] = ()`,
  `metadata: dict[str, object] = field(default_factory=dict)`. Property `below_floor`
  returns `tuple(o for o in obligations if o.needs_confirmation)` (`ingestion_types.py:60-63`).
- `IngestionReport` `@dataclass(frozen=True, slots=True)` (`ingestion_types.py:66-82`):
  `app_id: str`, `obligations_total: int = 0`, `low_confidence_count: int = 0`,
  `classifier_domains: tuple[str, ...] = ()`, `write_attempts_refused: int = 0`,
  `metadata: dict[str, object] = field(default_factory=dict)`.

## 1.4 Activity body — exact control flow (`ingestion.py:634-661`)

No branches at the top level; the branching is inside the pure helpers it calls, all
documented below. Sequence:

1. `repo = ReadOnlyLegacyRepo(root=input.source_root)` (`ingestion.py:634`).
2. `spec, domains = walk_and_reconstruct(repo, app_id=input.app_id,
   confidence_floor=input.confidence_floor, max_files=input.max_files)` (`ingestion.py:635-640`).
3. `routes = route_safety_classifier_hits(domains, profile_id=input.profile_id,
   enabled=input.route_classifier_hits)` — **raises `SafetyClassifierError` if a hit cannot
   be routed** (`ingestion.py:641-646`).
4. `report = build_report(spec, domains, write_attempts_refused=0)` (`ingestion.py:647`).
5. Return the flat `IngestLegacySourceResult` (field mapping in §1.2) (`ingestion.py:651-661`).

## 1.5 `ReadOnlyLegacyRepo` — the load-bearing safety boundary (REQ-LI-005)

`@dataclass(frozen=True)` with single field `root: str` (`ingestion.py:77-88`).
`_root_path()` returns `Path(self.root)` (`ingestion.py:90-91`).

**Reads:**
- `iter_files() -> tuple[str, ...]` (`ingestion.py:94-103`):
  - `base = self._root_path()`.
  - If `not base.is_dir()` → return `()` (empty tuple) — early return (`ingestion.py:97-98`).
  - Walk `sorted(base.rglob("*"))`; for each `p`, if `p.is_file() and not p.is_symlink()`
    append `str(p.relative_to(base))` (`ingestion.py:100-102`). **GOTCHA — symlinks are
    skipped** (containment/read-only safety).
  - Return `tuple(sorted(out))` — **sorted twice** (once in rglob iteration, once at return)
    → stable deterministic order (`ingestion.py:100, 103`).
- `read_text(rel_path) -> str` (`ingestion.py:105-116`):
  - `base = self._root_path().resolve()`; `target = (base / rel_path).resolve()`.
  - **Containment guard:** `if base != target and base not in target.parents:` raise
    `ReadOnlyViolationError(f"refusing to read outside the read-only source root:
    {rel_path!r}")` (`ingestion.py:110-113`). **GOTCHA — a `rel_path` that resolves to `base`
    itself passes** (`base != target` is False), and one whose resolved path has `base`
    among its `.parents` passes; everything else (path traversal via `..`, absolute paths)
    raises.
  - `with open(target, encoding="utf-8", errors="replace") as fh: return fh.read()` —
    **read-only mode only**, `errors="replace"` so binary/undecodable bytes never raise
    (`ingestion.py:114-116`).

**Writes — ALL refused, each RAISES `ReadOnlyViolationError` (never a no-op), REQ-LI-005:**
- `write_text(rel_path, _content)` → raise (`ingestion.py:119-125`).
- `delete(rel_path)` → raise (`ingestion.py:127-132`).
- `open_for_write(rel_path)` → raise (`ingestion.py:134-139`).

**GOTCHA:** there is deliberately no `open(..., 'w'/'a'/'x')` anywhere in this class
(`ingestion.py:84-86, 114`). A simulated write must raise, not degrade to a no-op.

## 1.6 `walk_and_reconstruct` — the pure walk (`ingestion.py:362-400`)

`walk_and_reconstruct(repo, *, app_id, confidence_floor, max_files) ->
tuple[ReconstructedSpec, tuple[str, ...]]`. Returns `(spec, classifier_domains)`.

```
obligations: list = []
domains: set = set()
seen = 0
for rel_path in repo.iter_files():        # already sorted
    if seen >= max_files:      break       # cap check BEFORE ingestibility (see gotcha)
    if not _is_ingestible(rel_path):  continue
    seen += 1
    content = repo.read_text(rel_path)
    domains.update(classify_safety_domains(content))
    obligations.append(reconstruct_obligation(rel_path, content, confidence_floor=confidence_floor))
spec = ReconstructedSpec(app_id=app_id, source_root=repo.root,
                         obligations=tuple(obligations),
                         metadata={"file_count": seen})
return spec, tuple(sorted(domains))
```
(`ingestion.py:378-400`).

**GOTCHA — `max_files` counts INGESTIBLE files, not all files.** The `seen >= max_files`
break is checked at the top of the loop, but `seen` is only incremented AFTER the
`_is_ingestible` `continue`; non-ingestible files are skipped without consuming the budget
(`ingestion.py:382-386`). So `max_files=5000` means up to 5000 *ingestible* files.

**GOTCHA — `file_count` metadata == number of INGESTIBLE files ingested (`seen`), not the
total files in the tree** (`ingestion.py:398, 386`).

**`_is_ingestible(rel_path)`** (`ingestion.py:358-359`): `os.path.splitext(rel_path)[1].lower()
in _INGESTIBLE_EXT`. `_INGESTIBLE_EXT` (`ingestion.py:353-355`) = the frozenset of all keys of
`_EXT_CONFIDENCE` UNION `{.cob, .cbl, .nsd, .nsm, .bas, .frm, .vb}`. So the full ingestible set:
`.sql, .cpy, .dbd, .cs, .ts, .java, .py, .jcl, .nsp, .asp, .aspx` (from `_EXT_CONFIDENCE`) plus
`.cob, .cbl, .nsd, .nsm, .bas, .frm, .vb`.

## 1.7 Confidence scoring + provenance (REQ-LI-002/004)

`_EXT_CONFIDENCE` base bands (`ingestion.py:208-220`): `.sql=0.85, .cpy=0.8, .dbd=0.8,
.cs=0.75, .ts=0.75, .java=0.75, .py=0.75, .jcl=0.6, .nsp=0.55, .asp=0.5, .aspx=0.5`.
`_DEFAULT_EXT_CONFIDENCE = 0.4` (`ingestion.py:221`).

**`score_confidence(rel_path, content) -> float`** (`ingestion.py:224-238`) — pure &
deterministic:
1. `ext = os.path.splitext(rel_path)[1].lower()`.
2. `base = _EXT_CONFIDENCE.get(ext, _DEFAULT_EXT_CONFIDENCE)` — note extensions in the
   "extra" ingestible set (`.cob`, `.cbl`, `.nsd`, `.nsm`, `.bas`, `.frm`, `.vb`) have NO
   entry in `_EXT_CONFIDENCE`, so they score against `base = 0.4`.
3. `digest = hashlib.sha256(content.encode("utf-8", errors="replace")).digest()`.
4. `dither = ((digest[0] / 255.0) - 0.5) * 0.1` → range `[-0.05, +0.05]` derived from the
   first digest byte (`ingestion.py:236-237`).
5. return `max(0.0, min(1.0, round(base + dither, 4)))` — clamped to `[0.0, 1.0]`, rounded
   to 4 dp (`ingestion.py:238`). **GOTCHA — identical bytes always score identically; two
   different files of the same extension get a stable per-content dither so they don't
   collide** (`ingestion.py:229-231`).

**`_obligation_statement(rel_path)`** (`ingestion.py:241-244`): `name =
os.path.basename(rel_path)`; returns `f"Preserve the behavior implemented in {name}"`.
CLIENT-BLIND — path basename only.

**`reconstruct_obligation(rel_path, content, *, confidence_floor) ->
ReconstructedObligation`** (`ingestion.py:247-267`):
- `confidence = score_confidence(rel_path, content)`.
- Returns `ReconstructedObligation(ref=f"{rel_path}:module", statement=_obligation_statement(rel_path),
  confidence=confidence, provenance=REVERSE_ENGINEERED,
  needs_confirmation=(confidence < confidence_floor))` (`ingestion.py:261-267`).
- **GOTCHA — `ref` is `{rel_path}:module` (literal suffix `:module`), NOT `{artifact}:{element}`
  with a real element** (`ingestion.py:262`). The strict `<` comparison means a confidence
  EQUAL to the floor is NOT `needs_confirmation` (`ingestion.py:266`).

**`build_report(spec, domains, *, write_attempts_refused=0) -> IngestionReport`**
(`ingestion.py:598-612`):
- `obligations_total = len(spec.obligations)`.
- `low_confidence_count = len(spec.below_floor)` — i.e. count of `needs_confirmation`
  obligations (`ingestion.py:608`, via `ReconstructedSpec.below_floor`).
- `classifier_domains = tuple(domains)`; `write_attempts_refused` passed through;
  `metadata = dict(spec.metadata)` (`ingestion.py:605-612`).
- **GOTCHA — `write_attempts_refused` is always `0` in the current activity** because the
  walk never attempts a write (`ingestion.py:647`, and the field is documented as recording
  refused writes but no code path counts them today).

## 1.8 Safety-classifier — surface + route every hit (REQ-LI-006)

**Classifier (pure, CLIENT-BLIND):**
- `_CRYPTO_TOKENS` (`ingestion.py:149-170`): `aes, rsa, des, blowfish, cipher, encrypt,
  decrypt, hmac, sha1, sha256, md5, x509, rfc2898, pbkdf2, privatekey, private_key,
  secretkey, secret_key, cryptography, cryptoserviceprovider`.
- `_SAFETY_DOMAINS = {"crypto": _CRYPTO_TOKENS}` (`ingestion.py:175-177`) — only the `crypto`
  domain ships today; structure open for profile domains later.
- `classify_safety_domains(text) -> tuple[str, ...]` (`ingestion.py:180-193`): `lowered =
  text.lower()`; `hits = {domain for domain, tokens in _SAFETY_DOMAINS.items() if any(tok
  in lowered for tok in tokens)}`; return `tuple(sorted(hits))`. **GOTCHA — matching is
  case-insensitive plain substring** (`tok in lowered`), NOT whole-word despite the
  docstring's "whole-word-ish" (`ingestion.py:148, 187-192`); e.g. `sha256` matches inside
  a longer token, and `des` matches inside "described".

**`route_safety_classifier_hits(domains, *, profile_id, enabled) ->
list[tuple[str, str, str]]`** (`ingestion.py:559-595`) — records `(domain,
original_provider, fallback_or_human)` for EVERY domain:
```
routes = []
for domain in domains:
    if not enabled:
        routes.append((domain, "", "human"))   # surface-only; never dropped
        continue
    try:
        original, target = _route_classifier_hit(domain, profile_id)
    except SafetyClassifierError:
        raise                                    # already the terminal safety error
    except Exception as exc:                     # noqa: BLE001 — ANY other failure
        raise SafetyClassifierError(...) from exc # fail-closed, never silent
    routes.append((domain, original, target))
return routes
```
(`ingestion.py:574-595`).

**GOTCHA — three routing outcomes, none silent:**
1. `enabled=False` (unit/offline caller) → `(domain, "", "human")` surface-only
   (`ingestion.py:576-579`).
2. `enabled=True` and route succeeds → `(domain, original_provider, fallback_or_human)`
   (`ingestion.py:594`).
3. `enabled=True` and route raises ANY exception → wrapped as `SafetyClassifierError`
   (non-retryable) and re-raised → the whole activity fails loudly (`ingestion.py:581-593`).
   A pre-existing `SafetyClassifierError` is re-raised unchanged (`ingestion.py:583-584`).

## 1.9 `_route_classifier_hit` — the ONE external-service arm (FedRAMP fail-closed)

`_route_classifier_hit(domain, profile_id) -> tuple[str, str]` (`ingestion.py:495-556`).
Returns `(original_provider, fallback_provider_or_'human')`. This is the only part of the
group that reaches outside the platform package — it lazily imports and calls the EXISTING
`olympus-agent-runtime` provider-selection surface (it does NOT reimplement FedRAMP logic).

**Locating + importing the agent-runtime surface (both isolation-heavy — GOTCHA-dense):**

`_agent_runtime_root() -> Path | None` (`ingestion.py:403-423`):
- If env `OLYMPUS_AGENT_RUNTIME_ROOT` is set → `p = Path(override)`; return `p` iff
  `(p / "src" / "services" / "provider_selection.py").is_file()`, else `None`
  (`ingestion.py:414-417`).
- Else walk `Path(__file__).resolve().parents`; for each `parent`, candidate =
  `parent / "olympus-agent-runtime"`; return it iff
  `(candidate / "src" / "services" / "provider_selection.py").is_file()` (`ingestion.py:418-422`).
- Else return `None`.

`_load_provider_selection() -> (resolve_provider_and_tier, select_fallback_provider,
FedRampComplianceError, a2a_module)` (`ingestion.py:426-492`):
- `root = _agent_runtime_root()`; if `None` → raise `ModuleNotFoundError(...)`
  (`ingestion.py:448-454`). **This is caught by `route_safety_classifier_hits`'s generic
  `except` and re-raised as `SafetyClassifierError` — fail-closed** (§1.8, `ingestion.py:585-593`).
- **GOTCHA — sys.modules / sys.path isolation.** The agent-runtime top-level package is
  ALSO named `src`, colliding with olympus-api/olympus-worker's `src` (`ingestion.py:405-412,
  434-439`). Procedure (`ingestion.py:462-492`):
  1. `saved = {name: mod for name, mod in list(sys.modules.items()) if name == "src" or
     name.startswith("src.")}` — snapshot the colliding modules.
  2. `saved_path = list(sys.path)` — snapshot path.
  3. In `try`: `del sys.modules[name]` for each saved name; remove `runtime_dir` from
     `sys.path` if present, then `sys.path.insert(0, runtime_dir)`; `importlib.invalidate_caches()`.
  4. `a2a = importlib.import_module("src.models.a2a")`; `provider_selection =
     importlib.import_module("src.services.provider_selection")`.
  5. Return the two callables + `provider_selection.FedRampComplianceError` + `a2a`.
  6. In `finally`: delete every current `src`/`src.*` module the import added, then
     `sys.modules.update(saved)` and `sys.path[:] = saved_path` — **restore the original
     process state so nothing leaks** (`ingestion.py:485-492`).
- **GOTCHA — loaded lazily (inside the function) so the Temporal workflow sandbox can
  import a workflow referencing this activity without pulling in the agent-runtime package
  at module load; mirrors `drift_control_eval`** (`ingestion.py:515-517`).

**The routing call (`ingestion.py:519-556`):**
- Unpack `(resolve_provider_and_tier, select_fallback_provider, _FedRampComplianceError,
  a2a) = _load_provider_selection()` (`ingestion.py:519-524`).
- `root = _agent_runtime_root()`; `config_dir = str(root / "config") if root is not None
  else ""` (`ingestion.py:526-527`). Config dir supplies `models.yaml` +
  `provider_fallback_order` (`ingestion.py:506-507`).
- `profile_cfg = {"require_fedramp_provider": True}` (`ingestion.py:528`) — **hardcoded to
  require FedRAMP; `profile_id` argument is NOT used to look up a real profile config here**
  (GOTCHA: `profile_id` is passed in but unused in the resolve call).
- Build `request = a2a.A2ATaskRequest(task=f"safety-classifier domain hit: {domain}",
  context=a2a.A2AContext(app_id="reverse-engineering", skill_id="reverse-engineer-spec",
  task_type="ingest", extras={"safety_domain": domain}))` (`ingestion.py:529-537`).
- `original_provider, _tier = resolve_provider_and_tier(None, profile_cfg, "", "", request,
  config_dir=config_dir, skill_id="reverse-engineer-spec")` (`ingestion.py:540-548`). **A
  non-compliant resolution raises `FedRampComplianceError` HERE and propagates — surfaced,
  never downgraded** (`ingestion.py:511-513, 538-539`).
- `fallback = select_fallback_provider(original_provider, profile_cfg, config_dir)`
  (`ingestion.py:551-555`).
- Return `(original_provider, (fallback or "human"))` — **exhausted fallback chain escalates
  to the literal string `"human"`** (`ingestion.py:556`).

## 1.10 Errors / retries / idempotency (activity 1)

- **`ReadOnlyViolationError`** (`ingestion.py:57-64`) — subclass of `NonRetryableError`.
  Raised by `read_text` containment guard and all write methods. Passes through the decorator
  unchanged with `non_retryable=True` (`activities.py:135-136`). **Non-retryable — a
  forbidden write can never succeed on retry** (`ingestion.py:60-64`).
- **`SafetyClassifierError`** (`ingestion.py:67-74`) — subclass of `NonRetryableError`.
  Raised when a classifier hit cannot be routed (see §1.8). **Non-retryable — the block is a
  policy decision, not a transient fault** (`ingestion.py:71-74`).
- **`FedRampComplianceError`** from the resolver propagates unbwrapped through
  `_route_classifier_hit`, but is caught by `route_safety_classifier_hits`'s generic
  `except Exception` and re-wrapped as `SafetyClassifierError` (`ingestion.py:585-593`) —
  so it still surfaces as a non-retryable safety block.
- **No `retry_policy` / timeouts / heartbeat** set on the decorator here — the config passes
  only `enable_observability=True` (`ingestion.py:620`); retry/timeout come from the
  worker's `execute_activity` options. `enable_error_wrapping` defaults `True`.
- **Idempotency:** the walk is pure over the read-only tree + deterministic scoring (hash
  dither), so re-running against an unchanged `source_root` yields byte-identical obligations
  and scores (`ingestion.py:224-238, 229-231`). No DB/git writes occur, so re-execution has
  no external side effect other than the (side-effect-free) provider-resolution reads. **The
  ONLY nondeterminism between runs is the agent-runtime provider resolution** (which depends
  on `models.yaml` / fallback order at call time).

---

# Activity 2 — `enroll_reconstructed_obligations`

`ingestion_drift.py:142-163`. Decorated `@foundry_activity(config=ActivityConfig(
enable_observability=True))` (`ingestion_drift.py:142`). `async def
enroll_reconstructed_obligations(payload: EnrollReconstructedInput) ->
EnrollReconstructedResult`. Enrolls reconstructed obligations in the EXISTING bidirectional
drift engine `olympus_workflows.drift.evaluate_drift` (REQ-LI-003) — the drift logic is never
reimplemented (`ingestion_drift.py:5-8, 146-153`).

## 2.1 Input shape — `EnrollReconstructedInput`

`@dataclass` (`ingestion_drift.py:65-80`):

| Field | Type | Default | Meaning (source) |
|---|---|---|---|
| `app_id` | `str` | (required) | application being reverse-engineered (`ingestion_drift.py:77`) |
| `spec_artifact` | `str` | (required) | reconstructed-spec artifact id all obligations enroll under (`ingestion_drift.py:78`) |
| `obligations` | `list[ReconstructedObligation]` | `field(default_factory=list)` | reconstructed set (provenance + confidence + `needs_confirmation`) (`ingestion_drift.py:79`) |
| `citations` | `list[dict]` | `field(default_factory=list)` | code-side citations to match against; empty at enrollment time — coverage accrues as modernization cites the obligations (`ingestion_drift.py:80`) |

## 2.2 Output shape — `EnrollReconstructedResult`

`@dataclass` (`ingestion_drift.py:93-110`) — **Temporal-SAFE flat projection** because
`DriftReport` carries `metadata: dict[str, object]` the converter cannot rehydrate
(`ingestion_drift.py:96-103`):

| Field | Type | Default | Written from |
|---|---|---|---|
| `app_id` | `str` | (required) | `report.app_id` (`ingestion_drift.py:157`) |
| `obligations_total` | `int` | `0` | `report.obligations_total` (`ingestion_drift.py:158`) |
| `obligations_satisfied` | `int` | `0` | `report.obligations_satisfied` (`ingestion_drift.py:159`) |
| `coverage_gap_count` | `int` | `0` | `len(report.coverage_gaps)` (`ingestion_drift.py:160`) |
| `blocking_count` | `int` | `0` | `report.blocking_count` (`ingestion_drift.py:161`) |
| `verdict` | `str` | `"pass"` | `report.verdict` (`ingestion_drift.py:162`) |

## 2.3 Activity body (`ingestion_drift.py:155-163`)

1. `report = enroll(payload)` (`ingestion_drift.py:155`).
2. Return `EnrollReconstructedResult(app_id=report.app_id,
   obligations_total=report.obligations_total,
   obligations_satisfied=report.obligations_satisfied,
   coverage_gap_count=len(report.coverage_gaps), blocking_count=report.blocking_count,
   verdict=report.verdict)` (`ingestion_drift.py:156-163`).

No branches in the activity itself; branching lives in `evaluate_drift` (§2.6).

## 2.4 `to_drift_obligation` — the REQ-LI-004 ↔ REQ-LI-003 mapping

`to_drift_obligation(obligation, *, spec_artifact) -> DriftObligation` (`ingestion_drift.py:43-62`):
- `REVERSE_ENGINEERED_KIND = "reverse_engineered"` (`ingestion_drift.py:40`).
- Returns `DriftObligation(spec_artifact=spec_artifact, element=obligation.ref,
  kind=REVERSE_ENGINEERED_KIND, optional=obligation.needs_confirmation)`
  (`ingestion_drift.py:57-62`).
- **GOTCHA — `optional` is set directly from `obligation.needs_confirmation`.** A sub-floor
  (needs-confirmation) obligation enrolls as `optional=True` → ADVISORY (non-blocking) in
  drift, so it can NEVER silently become a build-gating obligation before a human confirms
  it (REQ-LI-004). An above-floor obligation enrolls `optional=False` → required/blocking
  (`ingestion_drift.py:52-56, 61`).
- **GOTCHA — the drift `element` is the reconstructed obligation's OWN `ref` (i.e.
  `{rel_path}:module` from §1.7), and ALL of an app's reconstructed obligations share the
  single `spec_artifact`** (`ingestion_drift.py:49-51, 59-60`). The `DriftObligation.ref`
  property therefore becomes `f"{spec_artifact}:{rel_path}:module"` (`drift.py:104-106`).

## 2.5 `enroll` — the pure enrollment core (`ingestion_drift.py:113-139`)

`enroll(payload: EnrollReconstructedInput) -> DriftReport`. Extracted for direct unit testing.
```
drift_obligations = [to_drift_obligation(o, spec_artifact=payload.spec_artifact)
                     for o in payload.obligations]
citations: list[CitationLike] = [
    _Citation(source_artifact=str(c.get("source_artifact", "")),
              target_artifact=str(c.get("target_artifact", "")),
              target_element=c.get("target_element"),
              source_version=c.get("source_version"))
    for c in payload.citations ]
return evaluate_drift(drift_obligations, citations, app_id=payload.app_id)
```
(`ingestion_drift.py:122-139`).

- `_Citation` `@dataclass` (`ingestion_drift.py:83-90`): `source_artifact: str`,
  `target_artifact: str`, `target_element: str | None = None`, `source_version: str | None
  = None` — the structural shape the drift engine's `CitationLike` protocol needs
  (`drift.py:68-81`).
- **GOTCHA — citation dict coercion:** `source_artifact`/`target_artifact` are coerced with
  `str(c.get(..., ""))` (missing → `""`), but `target_element` and `source_version` use
  `c.get(...)` with NO default and NO `str()` → they pass through as `None` when absent
  (`ingestion_drift.py:128-133`).
- **GOTCHA — `spec_versions` is NOT passed to `evaluate_drift`**, so staleness detection
  never fires from this activity (all citations count as fresh) — see §2.6 (`ingestion_drift.py:135-139`
  vs `drift.py:206-212`).

## 2.6 `evaluate_drift` — the existing bidirectional engine consumed (`drift.py:206-315`)

Called with `(drift_obligations, citations, app_id=payload.app_id)`; `spec_versions`
defaults to `{}` (`drift.py:230`). Behavior (reproduced so the enrollment result is exact):

1. Index obligations: `obligation_by_ref = {}`; for each `ob`,
   `obligation_by_ref.setdefault(ob.ref, ob)` — **first-writer-wins on duplicate refs**
   (`drift.py:234-236`).
2. **Backward pass** over citations (`drift.py:248-287`): `target_ref =
   _citation_target_ref(cit)` (= `f"{target_artifact}:{target_element}"` if
   `target_element` truthy, else `target_artifact` — `drift.py:198-203`).
   - If `obligation_by_ref.get(target_ref) is None` → add `DriftFinding(kind="orphan_citation",
     citation=f"{source_artifact} -> {target_ref}", detail=..., blocking=True)`; `continue`
     (`drift.py:251-263`).
   - Else `satisfied_refs.add(target_ref)` (`drift.py:266`).
   - Staleness: `current_version = spec_versions.get(target_ref)`; `source_version =
     getattr(cit, "source_version", None)`; if BOTH non-`None` AND unequal → add
     `DriftFinding(kind="stale_link", ..., blocking=True)` (`drift.py:269-287`). With
     `spec_versions={}` this never fires (current is always `None`).
   - `_add_finding` dedupes on `(kind, citation, detail)` (`drift.py:242-245, 126-127`).
3. **Forward pass** over obligations (`drift.py:290-304`): for each `ref, obligation` not in
   `satisfied_refs`, append `DriftCoverageGap(spec_artifact=..., element=..., detail=...,
   blocking=(not obligation.optional))`. **So a `needs_confirmation`→`optional=True`
   obligation with no citation yields a NON-blocking gap** (`drift.py:302`).
4. Sort findings by `_sort_key` and gaps by `_sort_key` (`drift.py:306-307`).
5. Return `DriftReport(app_id, findings=tuple(...), coverage_gaps=tuple(...),
   obligations_total=len(obligation_by_ref),
   obligations_satisfied=len(satisfied_refs & obligation_by_ref.keys()))` (`drift.py:309-315`).

`DriftReport` derived props used by the result: `blocking_count = (# blocking findings) +
(# blocking coverage gaps)` (`drift.py:181-185`); `verdict = "pass" if blocking_count == 0
else "fail"` (`drift.py:187-190`).

**GOTCHA — at enrollment time `citations` is empty** (`ingestion_drift.py:73`), so: no
orphan findings, `satisfied_refs` empty → EVERY obligation becomes a coverage gap; gaps are
blocking only for above-floor (required) obligations. So `obligations_total == len(payload
.obligations)` (proves enrollment, `ingestion_drift.py:118-120`), `obligations_satisfied ==
0`, `coverage_gap_count == obligations_total`, `blocking_count == count of above-floor
obligations`, and `verdict == "pass"` iff every reconstructed obligation was sub-floor
(all `optional`).

## 2.7 Errors / retries / idempotency (activity 2)

- **No custom exceptions raised.** `enroll`/`evaluate_drift` are pure and total. Any escaping
  exception (e.g. an unexpected non-dict in `citations`) would be wrapped by the decorator:
  `_is_retryable_error` type-name match → `RetryableError` if the type name contains a
  retryable pattern, else `NonRetryableError` (`activities.py:124-146`).
- **No `retry_policy` / timeouts / heartbeat** on the decorator (only
  `enable_observability=True`, `ingestion_drift.py:142`); `enable_error_wrapping` defaults `True`.
- **Idempotency:** fully deterministic and pure — no IO, no DB, no git. Re-running with the
  same `payload` yields an identical `DriftReport` projection (`evaluate_drift` is documented
  order-independent/deterministic, `drift.py:213-216, 306-307`). Safe to retry.

## 2.8 Module exports

`ingestion.py __all__` (`ingestion.py:664-678`): `DEFAULT_CONFIDENCE_FLOOR`,
`IngestLegacySourceInput`, `IngestLegacySourceResult`, `ReadOnlyLegacyRepo`,
`ReadOnlyViolationError`, `SafetyClassifierError`, `build_report`, `classify_safety_domains`,
`ingest_legacy_source`, `reconstruct_obligation`, `route_safety_classifier_hits`,
`score_confidence`, `walk_and_reconstruct`.

`ingestion_drift.py __all__` (`ingestion_drift.py:166-173`): `REVERSE_ENGINEERED_KIND`,
`EnrollReconstructedInput`, `EnrollReconstructedResult`, `enroll`,
`enroll_reconstructed_obligations`, `to_drift_obligation`.
