# Activity Group: scoring / classification / arch_data_registry

Atomic regeneration spec. Source tree: `temporal/olympus_workflows/activities/`.
Every claim cites `path:line` relative to repo root. Behavioral parity is the bar.

Files covered:
- `temporal/olympus_workflows/activities/scoring.py` — 3 activities
- `temporal/olympus_workflows/activities/classification.py` — 2 activities
- `temporal/olympus_workflows/activities/arch_data_registry.py` — 2 activities

**7 activity functions total** (all `@foundry_activity`-decorated).

---

## 0. `@foundry_activity` decorator — what it adds over `activity.defn`

Every activity below is wrapped with
`@foundry_activity(config=ActivityConfig(enable_observability=True))`. Reproduce the
wrapper exactly from `temporal/olympus_workflows/temporal_base/activities.py`.

### `ActivityConfig` dataclass (`temporal_base/activities.py:41-53`)
Fields and defaults:
- `retry_policy: RetryPolicy | None = None`
- `start_to_close_timeout: timedelta | None = None`
- `schedule_to_close_timeout: timedelta | None = None`
- `schedule_to_start_timeout: timedelta | None = None`
- `heartbeat_timeout: timedelta | None = None`
- `enable_observability: bool = True`
- `enable_error_wrapping: bool = True`
- `log_inputs: bool = False`
- `log_outputs: bool = False`

GOTCHA (`temporal_base/activities.py:79-150`): despite the dataclass carrying
`retry_policy`/timeout/`heartbeat_timeout` fields, the decorator **does not read or apply
them**. `decorator()` only reads `enable_observability`, `enable_error_wrapping`,
`log_inputs`, `log_outputs`. Timeouts and retry policies are applied by the **calling
workflow** at `execute_activity(...)` (workflows import `RETRY_POLICIES` from
`olympus_workflows.retry_policies`, e.g. `workflows/rationalization.py:37`). So no
heartbeat is emitted by any activity in this group, and none of the three files sets a
per-activity retry policy.

### Decorator behavior (`temporal_base/activities.py:97-148`)
1. `activity_config = config or ActivityConfig()` (`:98`).
2. Applies `@activity.defn(name=name, **activity_kwargs)` then `@wraps(func)` to an async
   `wrapper` (`:100-102`). The **activity name defaults to the function name** (`name` arg
   is `None` at all call sites in this group) — `activity_name = name or func.__name__`
   (`:103`). Temporal replay keys on this name; preserve it exactly.
3. **Start log** (only if `enable_observability`): `logger.info("Activity %s starting",
   activity_name, extra={"inputs": args if log_inputs else None})` (`:105-110`). Since
   `log_inputs=False`, `extra["inputs"]` is `None`.
4. Calls `result = await func(*args, **kwargs)` (`:113`).
5. **Complete log**: `logger.info("Activity %s completed", activity_name, extra={"outputs":
   result if log_outputs else None})` (`:115-120`). `log_outputs=False` → `None`.
6. `return result` (`:122`).
7. **On any `Exception`** (`:124-146`):
   - If `enable_observability`: `logger.error("Activity %s failed: %s", activity_name,
     error, extra={"error": str(error)})` (`:125-131`).
   - Error wrapping (`enable_error_wrapping=True` by default, `:133`):
     - If `isinstance(error, (WorkflowError, ApplicationError))` → `raise` unchanged
       (`:135-136`). This is why `NonRetryableError` raised inside the activities passes
       through intact.
     - elif `_is_retryable_error(error)` → wrap as
       `RetryableError(f"Retryable error in {activity_name}: {error}")` (`:137-140`).
     - else → wrap as `NonRetryableError(f"Non-retryable error in {activity_name}:
       {error}")` (`:141-144`).
   - If wrapping disabled → bare `raise` (`:146`).

### `_is_retryable_error` heuristic (`temporal_base/activities.py:56-76`)
GOTCHA: classifies by the **type-name string**, not the instance. Computes
`error_str = str(type(error)).lower()` and returns `True` if it contains any of:
`"timeout"`, `"connection"`, `"network"`, `"temporary"`, `"unavailable"`, `"overload"`,
`"busy"`, `"throttle"`, `"rate_limit"`. Intentionally distinct from
`errors.is_retryable_error` (which inspects httpx/OSError/ApplicationError instances,
`errors.py:53-88`). Consequence for this group: an `asyncpg.PostgresError` subclass whose
type name contains none of those substrings wraps to `NonRetryableError`; a
`ConnectionError`/`ConnectionDoesNotExistError` (contains "connection") wraps to
`RetryableError`. But note most DB failures in these files are **caught internally** (see
per-activity idempotency notes) and never reach the wrapper.

### Error taxonomy (`temporal_base/errors.py`)
- `WorkflowError(ApplicationError)` — `__init__(message, non_retryable=True)` (`:16-20`).
- `RetryableError(WorkflowError)` — `non_retryable=False` (`:23-27`).
- `NonRetryableError(WorkflowError)` — `non_retryable=True` (`:30-34`).
Temporal reads the `non_retryable` flag to decide retries.

### Shared `_db_url()` (identical in all three files)
`scoring.py:59-66`, `classification.py:30-36`, `arch_data_registry.py:51-63`:
```
host = os.environ.get("DATABASE_HOST", "localhost")
port = os.environ.get("DATABASE_PORT", "5432")
user = os.environ.get("DATABASE_USER", "olympus")
password = os.environ.get("DATABASE_PASSWORD", "olympus")
db = os.environ.get("DATABASE_NAME", "olympus")
return f"postgresql://{user}:{password}@{host}:{port}/{db}"
```
GOTCHA (`arch_data_registry.py:51-57` docstring): intentionally duplicated per file so each
activity module is self-contained for Temporal worker registration — no cross-activity-file
imports.

---

# FILE 1: scoring.py

Module docstring `scoring.py:1-12`. Scores use 6 dimensions on a 1-5 scale (the readiness
scoring) plus an overall weighted average. The portfolio scorer (bottom half) uses a
separate 6-dim 0-100 scale.

## Module constants

`DEFAULT_DISCOVERY_SCORES` (`scoring.py:39-46`) — fallback 1-5 scores:
```
{"code_quality": 3.0, "test_coverage": 2.5, "security_posture": 3.0,
 "documentation": 2.0, "dependency_currency": 3.0, "architecture_clarity": 2.5}
```
`DIMENSION_NAMES` (`scoring.py:49-56`) — ordered list of the 6 dimension names (order matters
for deterministic output). GOTCHA: this constant is defined but not directly iterated in the
activity code; the ordering that actually matters is the literal dict-construction order in
`ReadinessScoreResult` and in `dimension_scores`.

`_PORTFOLIO_DIMENSIONS` (`scoring.py:283-290`) — tuple, order fixed:
`("technical_readiness", "architectural_readiness", "operational_readiness",
"security_readiness", "user_experience_readiness", "business_readiness")`.

## Helper: `_extract_scores_from_evidence(evidence_data: dict) -> dict[str,float] | None`
(`scoring.py:69-95`)
- `passes = evidence_data.get("passes") or {}` (`:76`).
- `synthesis = passes.get("synthesis") or {}` (`:77`).
- `readiness = synthesis.get("modernization_readiness_score")`; if falsy → return `None`
  (`:79-81`).
- `dimensions = readiness.get("dimensions")`; if falsy → return `None` (`:83-84`).
- For each `dim` in `dimensions`: read `name = dim.get("name")`, `score = dim.get("score")`;
  if `name` truthy AND `score is not None` → `scores[name] = float(score)` (`:88-92`).
- Return `scores if scores else None` — at least one valid dimension required (`:95`).

Expected input JSON shape (the gate `evidence_data` JSONB):
```json
{"passes": {"synthesis": {"modernization_readiness_score": {
  "dimensions": [{"name": "code_quality", "score": 4.0}, ...]}}}}
```

## Helper: `async _fetch_evidence_from_gate(app_id: str) -> dict | None`
(`scoring.py:98-133`)
- Connects `asyncpg.connect(_db_url())` (`:104`).
- Query (`:106-116`):
  ```sql
  SELECT evidence_data FROM gate
  WHERE application_id = $1::uuid AND gate_type = 'G-DC'
  ORDER BY requested_at DESC LIMIT 1
  ```
  with param `uuid.UUID(app_id)`. Reads the **latest G-DC (Discovery Complete) gate**.
- `finally: await conn.close()` (`:117-118`).
- GOTCHA (`:119-124`): `except (OSError, asyncpg.PostgresError)` → logs warning "Could not
  fetch gate evidence; falling back to defaults" and returns `None`. DB errors are swallowed
  here — they never propagate to the decorator wrapper.
- If `row is None` or `row["evidence_data"] is None` → return `None` (`:126-127`).
- GOTCHA (`:129-133`): asyncpg may return JSONB as `str` OR `dict` depending on driver
  version. If `isinstance(evidence, str)` → `json.loads(evidence)`. Reproduce this
  dual-path.

---

## ACTIVITY 1: `calculate_readiness_score`
(`scoring.py:136-193`) — `@foundry_activity(config=ActivityConfig(enable_observability=True))`

**Signature**: `async calculate_readiness_score(input: CalculateReadinessScoreInput) ->
ReadinessScoreResult`.

**Input** `CalculateReadinessScoreInput` (`types.py:1167-1172`):
- `app_id: str`
- `dimensions: list[str] = field(default_factory=list)` — optional dimension filter.

**Output** `ReadinessScoreResult` (`types.py:1175-1187`):
- `app_id: str`
- `overall: float = 0.0`
- `code_quality`, `test_coverage`, `security_posture`, `documentation`,
  `dependency_currency`, `architecture_clarity`: `float = 0.0` each
- `calculated_at: str = ""`

**Logic** (reproduce exactly):
1. `now = datetime.now(timezone.utc).isoformat()` (`:156`).
2. `evidence = await _fetch_evidence_from_gate(input.app_id)` (`:159`).
3. `real_scores = _extract_scores_from_evidence(evidence) if evidence else None` (`:160`).
4. `scores = real_scores if real_scores else dict(DEFAULT_DISCOVERY_SCORES)` (`:163`) —
   fresh copy of the defaults dict.
5. **Dimension filter** (`:166-167`): if `input.dimensions` truthy →
   `scores = {k: v for k, v in scores.items() if k in input.dimensions}`.
6. **Overall** (`:170`): `overall = sum(scores.values()) / len(scores) if scores else 0.0`.
   GOTCHA: equal-weight mean of *whatever survived the filter* — filtering to a subset
   changes `overall`. Division guarded against empty dict.
7. `source = "evidence" if real_scores else "defaults"` (`:172`).
8. `logger.info("Readiness score calculated", extra={app_id, overall, dimensions:
   list(scores.keys()), source})` (`:173-181`).
9. Return `ReadinessScoreResult(app_id=input.app_id, overall=round(overall, 2),
   code_quality=scores.get("code_quality", 0.0), test_coverage=..., security_posture=...,
   documentation=..., dependency_currency=..., architecture_clarity=...,
   calculated_at=now)` (`:183-193`). Each field uses `scores.get(<name>, 0.0)`, so a
   filtered-out dimension reports `0.0` in the result even though it exists in the source.
   `overall` is `round(..., 2)`; per-dimension values are **not** rounded.

**Errors/retries/idempotency**: no explicit raises. DB failures swallowed inside
`_fetch_evidence_from_gate`. Pure/read-only → fully idempotent. Retry policy is
caller-supplied (docstring `:154` recommends `HTTP_RETRY_POLICY` from temporal_base).

---

## ACTIVITY 2: `record_score_snapshot`
(`scoring.py:196-268`) — `@foundry_activity(config=ActivityConfig(enable_observability=True))`

**Signature**: `async record_score_snapshot(input: RecordScoreSnapshotInput) ->
RecordScoreSnapshotResult`.

**Input** `RecordScoreSnapshotInput` (`types.py:1191-1196`):
- `app_id: str`
- `scores: ReadinessScoreResult` (nested dataclass)
- `snapshot_reason: str = ""`

**Output** `RecordScoreSnapshotResult` (`types.py:1200-1205`):
- `app_id: str`, `snapshot_id: str = ""`, `recorded_at: str = ""`

**Logic**:
1. `snapshot_id = f"snap-{uuid.uuid4().hex[:12]}"` (`:211`) — e.g. `snap-a1b2c3d4e5f6`.
2. `now = datetime.now(timezone.utc)`; `now_iso = now.isoformat()` (`:212-213`).
3. Build `dimension_scores` dict in this exact order (`:216-224`):
   `code_quality, test_coverage, security_posture, documentation, dependency_currency,
   architecture_clarity, overall` — each read from `input.scores.<field>`. **7 entries**
   (6 dimensions + overall).

### persist transformation → table `score_history`
(insert loop `:229-244`; table DDL `db/alembic/versions/004_create_analytics_tables.py:56-68`)

One INSERT **per entry** in `dimension_scores` (7 rows). Per row:
```sql
INSERT INTO score_history
  (id, application_id, dimension, score, recorded_at, source_artifact, governance_cycle)
VALUES ($1, $2::uuid, $3, $4, $5, $6, $7)
```
Field-by-field mapping:
| column | value | source |
|---|---|---|
| `id` (UUID PK) | `uuid.uuid4()` (fresh per row) | `scoring.py:237` |
| `application_id` (UUID FK→application, CASCADE) | `uuid.UUID(input.app_id)` | `:238` |
| `dimension` (String(100), NOT NULL) | the dict key (`code_quality`…`overall`) | `:239` |
| `score` (Numeric, NOT NULL) | the dict value (float) | `:240` |
| `recorded_at` (DateTime tz, NOT NULL, default now()) | `now` (single value reused for all 7 rows) | `:241` |
| `source_artifact` (Text, nullable) | `snapshot_id` (the `snap-…` string) | `:242` |
| `governance_cycle` (String(100), nullable) | `input.snapshot_reason` | `:243` |

GOTCHA: `source_artifact` holds the synthetic snapshot id, **not** an artifact path — this
is how all 7 rows of one snapshot are correlated (shared `snapshot_id`). `governance_cycle`
holds the free-text `snapshot_reason`.

GOTCHA (`:247-251`): `except (OSError, asyncpg.PostgresError)` → warn "Could not write score
snapshot to DB; snapshot logged only" and **continue** (no re-raise). So on DB failure the
activity still returns success with the snapshot id; nothing is persisted. Idempotency:
**not idempotent** — a retry inserts another 7 rows with a *new* `snapshot_id` (uuid regen
at `:211`). No dedup key.

4. `logger.info("Score snapshot recorded", extra={app_id, snapshot_id, snapshot_reason,
   overall_score: input.scores.overall, rows_written: len(dimension_scores)})` (`:253-262`).
5. Return `RecordScoreSnapshotResult(app_id=input.app_id, snapshot_id=snapshot_id,
   recorded_at=now_iso)` (`:264-268`).

GOTCHA: `conn.close()` is in `finally` (`:245-246`) inside the `try` guarded by the broad
except; connection is always closed even on insert failure.

---

## Portfolio scoring helpers (P3.5-R3.3)

Docstring block `scoring.py:271-280`: `portfolio-scorer` skill produces a six-dimensional
0-100 vector w/ per-dimension rationale+evidence; `persist_portfolio_score` parses and
writes to `application.portfolio_score` JSONB. Mirrors `persist_classification` — defensive
parse, partial writes land what's valid, unparseable = no-op.

### `_parse_portfolio_score_json(raw: str) -> dict` (`scoring.py:293-307`)
Tolerant parser:
- `if not raw: return {}` (`:295-296`).
- `try: return json.loads(raw) if isinstance(raw, str) else {}` (`:297-298`). GOTCHA:
  non-str `raw` returns `{}` even though the successful path also returns `{}` for non-str —
  effectively only str is parsed.
- On `JSONDecodeError` (`:299`): find first `{` and last `}` (`start = raw.find("{")`,
  `end = raw.rfind("}")`). If `start == -1 or end <= start` → `{}` (`:301-303`). Else
  `json.loads(raw[start:end+1])`; on second `JSONDecodeError` → `{}` (`:304-307`). Extracts
  JSON embedded in agent prose.

### `_sanitize_portfolio_dimension(entry: object) -> dict | None` (`scoring.py:310-334`)
- `if not isinstance(entry, dict): return None` (`:316-317`).
- `score = entry.get("score")`; if not None → `float(score)` in try (`TypeError`/`ValueError`
  → `score = None`) (`:318-323`); then if still not None → **clamp** `max(0.0, min(100.0,
  score))` (`:324-325`).
- `rationale = entry.get("rationale")`; if not None and not str → `str(rationale)`
  (`:326-328`).
- `evidence = entry.get("evidence")`; if not a list → `[]`; else `[str(e) for e in
  evidence]` (`:329-333`).
- Return `{"score": score, "rationale": rationale, "evidence": evidence}` (`:334`). GOTCHA:
  a dim with `score=None` (N/A, e.g. UX for headless archetypes) is still a valid entry —
  it's kept, only excluded from the weighted mean.

### `_compute_portfolio_overall(scores, weights) -> float | None` (`scoring.py:337-357`)
Weighted mean over non-null dimensions:
- `default_w = 1.0 / len(_PORTFOLIO_DIMENSIONS)` = `1/6` (`:346`).
- For each `dim` in `_PORTFOLIO_DIMENSIONS`: `entry = scores.get(dim) or {}`;
  `score = entry.get("score")`; if `None` → skip (`:347-351`). `w = (weights or {}).get(dim,
  default_w)` (`:352`); accumulate `total += score * w`, `total_w += w` (`:353-354`).
- `if total_w <= 0: return None` (`:355-356`). Else `round(total / total_w, 2)` (`:357`).
  GOTCHA: null (UX) dims excluded from both numerator and denominator so headless archetypes
  aren't penalized. Weights need not sum to 1 — the mean normalizes by summed weights.

---

## ACTIVITY 3: `persist_portfolio_score`
(`scoring.py:360-449`) — `@foundry_activity(config=ActivityConfig(enable_observability=True))`

**Signature**: `async persist_portfolio_score(input: PersistPortfolioScoreInput) ->
PersistPortfolioScoreResult`.

**Input** `PersistPortfolioScoreInput` (`types.py:1441-1456`):
- `app_id: str`
- `score_json: str = ""` (raw `portfolio-scorer` skill output)
- `weights: dict[str, float] = field(default_factory=dict)` (optional per-dim overrides,
  looked up by caller from `profiles/*/scoring.yaml`)

**Output** `PersistPortfolioScoreResult` (`types.py:1460-1469`):
- `app_id: str`, `persisted: bool = False`, `overall_weighted: float | None = None`,
  `dimensions_persisted: list[str] = field(default_factory=list)`

Expected input JSON (`score_json`):
```json
{"scores": {"technical_readiness": {"score": 82.0, "rationale": "...", "evidence": ["..."]},
            ...}, "methodology_version": "1.0.0"}
```

**Logic**:
1. `app_uuid = uuid.UUID(input.app_id)` in try; on `(ValueError, TypeError)` → **raise
   `NonRetryableError(f"Invalid app_id: {input.app_id!r}")`** (`:375-378`). This is the only
   hard failure; it passes through the decorator unchanged (isinstance WorkflowError).
2. `parsed = _parse_portfolio_score_json(input.score_json)` (`:380`). If falsy → warn
   "persist_portfolio_score: unparseable skill output" and **return
   `PersistPortfolioScoreResult(app_id, persisted=False)`** (no-op, `:381-386`).
3. `raw_scores = parsed.get("scores") or {}` (`:388`).
4. For each `dim` in `_PORTFOLIO_DIMENSIONS`: `entry = _sanitize_portfolio_dimension(
   raw_scores.get(dim))`; if not None → `sanitized[dim] = entry` (`:390-392`).
5. If `sanitized` empty → warn "no valid dimensions in skill output" (extra: `parsed_keys`)
   and return `persisted=False` (`:395-400`).
6. **Weights** (`:402-407`): `weights=None` default; if `input.weights` truthy → `{k:
   float(v) for k,v in input.weights.items()}` in try; on `(TypeError, ValueError)` →
   `weights = None`.
7. `overall = _compute_portfolio_overall(sanitized, weights)` (`:409`).
8. `methodology_version = str(parsed.get("methodology_version") or "1.0.0")` (`:410`).
9. Build payload (`:412-417`):
   ```python
   {"scores": sanitized, "overall_weighted": overall,
    "methodology_version": methodology_version,
    "computed_at": datetime.now(timezone.utc).isoformat()}
   ```

### persist transformation → `application.portfolio_score` (JSONB)
(`scoring.py:419-433`; column DDL `db/alembic/versions/024_add_application_portfolio_score.py:44-47`,
nullable JSONB)
```sql
UPDATE application
SET portfolio_score = $1::jsonb, updated_at = $2
WHERE id = $3
```
Mapping:
| column | value | source |
|---|---|---|
| `portfolio_score` (JSONB, nullable) | `json.dumps(payload)` | `:428` |
| `updated_at` (DateTime tz, NOT NULL) | `datetime.now(timezone.utc)` (a **second** now() call, distinct from `computed_at` in payload) | `:429` |
| WHERE `id` | `app_uuid` | `:430` |

GOTCHA: no `try/except` around this UPDATE (unlike the two scoring activities above). A DB
error here propagates to the decorator and (since asyncpg errors' type names usually lack
the retryable substrings) wraps to `NonRetryableError`. `conn.close()` in `finally`
(`:432-433`). GOTCHA: whole payload overwrites the column — partial-dimension writes replace
any prior `portfolio_score`, they don't merge into it.

10. `logger.info("Portfolio score persisted", extra={app_id, dimensions_persisted:
    sorted(sanitized.keys()), overall_weighted})` (`:435-442`).
11. Return `PersistPortfolioScoreResult(app_id, persisted=True, overall_weighted=overall,
    dimensions_persisted=sorted(sanitized.keys()))` (`:444-449`). GOTCHA: `dimensions_persisted`
    is **sorted alphabetically**, not in `_PORTFOLIO_DIMENSIONS` order.

**Idempotency**: idempotent by `app_id` — re-running overwrites the same row with a freshly
parsed payload (only `computed_at`/`updated_at` timestamps differ). No agent dispatch inside
this activity; the skill call happens in the caller.

---

# FILE 2: classification.py

Module docstring `classification.py:1-7`. `persist_classification` writes classify-skill
output onto the `application` row with `source="auto"`; `confirm_classification_tier_1`
flips `risk_tier_source` from `"auto"` to `"confirmed"`.

## Module constants
`_ARCHETYPES` (`classification.py:39-45`): `{"web-app","batch-etl","api-service",
"scheduled-job","hybrid"}` — matches `archetype_enum`
(`db/alembic/versions/021_add_application_archetype.py:37-40`).
`_COMPLEXITY` (`classification.py:46`): `{"simple","moderate","complex"}` — matches
`complexity_tier_enum` (`db/alembic/versions/002_create_core_tables.py:29-30`).

## Helper `_parse_classification(raw: str) -> dict` (`classification.py:49-66`)
Identical structure to `_parse_portfolio_score_json`: `if not raw: return {}`; try
`json.loads` (non-str → `{}`); on `JSONDecodeError`, brace-slice `raw[start:end+1]` where
`start=raw.find("{")`, `end=raw.rfind("}")`, guarding `start==-1 or end<=start`; second
failure → `{}`.

---

## ACTIVITY 4: `persist_classification`
(`classification.py:69-171`) — `@foundry_activity(config=ActivityConfig(enable_observability=True))`

**Signature**: `async persist_classification(input: PersistClassificationInput) ->
PersistClassificationResult`.

**Input** `PersistClassificationInput` (`types.py:1393-1408`):
- `app_id: str`
- `classification_artifact_path: str = ""` (unused in the activity body — informational)
- `classification_json: str = ""` (the `classify-application` skill output, already
  committed to Git)

**Output** `PersistClassificationResult` (`types.py:1412-1424`):
- `app_id: str`, `risk_tier: int | None = None`, `complexity_tier: str = ""`,
  `archetype: str = ""`, `tier_1_flag: bool = False`

Expected input JSON (`classification_json`):
```json
{"complexity_tier": "moderate", "risk_tier": 1, "archetype": "web-app",
 "tier_1_flag": true}
```

**Logic**:
1. `app_uuid = uuid.UUID(input.app_id)` in try; on `(ValueError, TypeError)` → **raise
   `NonRetryableError(f"Invalid app_id: {input.app_id!r}")`** (`:88-91`).
2. `parsed = _parse_classification(input.classification_json)` (`:93`). If falsy → warn
   "persist_classification: unparseable skill output" and **return
   `PersistClassificationResult(app_id=input.app_id)`** (all defaults, `:94-99`).
3. Extract raw values (`:101-104`):
   - `complexity = parsed.get("complexity_tier")`
   - `risk = parsed.get("risk_tier")`
   - `archetype = parsed.get("archetype")`
   - `tier_1_flag = bool(parsed.get("tier_1_flag"))`
4. **Validation** (only write what's valid):
   - `validated_complexity = complexity if complexity in _COMPLEXITY else None` (`:107`).
   - Risk (`:108-112`): `risk_int = int(risk) if risk is not None else None` in try; on
     `(TypeError, ValueError)` → `validated_risk = None`. Then `validated_risk = str(risk_int)
     if risk_int in (1,2,3) else None`. GOTCHA: DB column `risk_tier` is `risk_tier_enum`
     with values `'1','2','3'` (**strings**, `002_create_core_tables.py:25,89`), which is why
     the int is converted back to a str before writing.
   - `validated_archetype = archetype if archetype in _ARCHETYPES else None` (`:113`).

### persist transformation → `application` (dynamic partial UPDATE)
(`classification.py:117-152`; columns in `002_create_core_tables.py:89-92` +
`021_add_application_archetype.py:43-67`)

GOTCHA — **dynamic SET-clause with 1-based positional params**. `set_parts: list[str]`,
`params: list[object]`. Each `${len(params)+1}` placeholder is computed **before** the
value is appended, giving 1-based ordering (`:117-133`). Blocks appended conditionally:

- If `validated_risk is not None` (`:119-123`): append `risk_tier = $N`, then
  `risk_tier_source = $N+1` with values `validated_risk` (str '1'/'2'/'3') and `"auto"`.
- If `validated_complexity is not None` (`:124-128`): append `complexity_tier = $N`,
  `complexity_tier_source = $N+1` with values `validated_complexity`, `"auto"`.
- If `validated_archetype is not None` (`:129-133`): append `archetype = $N`,
  `archetype_source = $N+1` with values `validated_archetype`, `"auto"`.

Column types: `risk_tier` (`risk_tier_enum`), `risk_tier_source` (`tier_source_enum`:
`auto|confirmed|overridden`), `complexity_tier` (`complexity_tier_enum`),
`complexity_tier_source` (`tier_source_enum`), `archetype` (`archetype_enum`),
`archetype_source` (`tier_source_enum`).

- **If `set_parts` empty** (`:135-140`): warn "persist_classification: no valid fields to
  write" (extra: `parsed`) and **return `PersistClassificationResult(app_id=input.app_id)`**
  (defaults). No UPDATE issued.
- Else finalize (`:142-146`): append `updated_at = $N` with value
  `datetime.now(timezone.utc)`; then `params.append(app_uuid)`. SQL built as:
  ```python
  sql = f"UPDATE application SET {', '.join(set_parts)} WHERE id = ${len(params)}"
  ```
  GOTCHA: the WHERE bind is `${len(params)}` computed **after** appending both `updated_at`
  value and `app_uuid` — so the app_uuid is the last param and its index equals the current
  `len(params)`. Reproduce this exact index arithmetic or the query breaks.
- Execute: `conn = await asyncpg.connect(_db_url())`; `await conn.execute(sql, *params)` in
  try/`finally: conn.close()` (`:148-152`). GOTCHA: no try/except around execute — DB
  errors propagate to the decorator (→ `NonRetryableError` typically).

5. `logger.info("Classification persisted", extra={app_id, risk_tier: validated_risk,
   complexity_tier, archetype, tier_1_flag})` (`:154-163`).
6. Return `PersistClassificationResult(app_id=input.app_id, risk_tier=int(validated_risk) if
   validated_risk else None, complexity_tier=validated_complexity or "",
   archetype=validated_archetype or "", tier_1_flag=tier_1_flag)` (`:165-171`). GOTCHA:
   `risk_tier` echoed as **int** in the result (converted back from the str that was
   written); `tier_1_flag` is returned from the parsed payload **regardless of whether the
   risk_tier validated/was written** — the calling workflow uses it to decide whether to
   pause for `StakeholderApprovedSignal`.

**Idempotency**: idempotent by `app_id` — same input overwrites the same fields with
`source="auto"`. GOTCHA: re-running after a manual override will **reset** `*_source` back
to `"auto"` (no guard against overwriting `"overridden"` here; only
`confirm_classification_tier_1` has that guard).

---

## ACTIVITY 5: `confirm_classification_tier_1`
(`classification.py:174-211`) — `@foundry_activity(config=ActivityConfig(enable_observability=True))`

**Signature**: `async confirm_classification_tier_1(input: ConfirmClassificationInput) ->
None`.

**Input** `ConfirmClassificationInput` (`types.py:1428-1437`):
- `app_id: str`, `approved_by: str = ""`

**Output**: `None`.

**Logic**:
1. `app_uuid = uuid.UUID(input.app_id)` in try; on `(ValueError, TypeError)` → **raise
   `NonRetryableError(f"Invalid app_id: {input.app_id!r}")`** (`:185-188`).
2. UPDATE (`:192-203`):
   ```sql
   UPDATE application
   SET risk_tier_source = 'confirmed', updated_at = $1
   WHERE id = $2 AND risk_tier = '1' AND risk_tier_source = 'auto'
   ```
   params: `datetime.now(timezone.utc)` ($1), `app_uuid` ($2).
   GOTCHA — **guarded flip**: only rows currently `risk_tier='1'` (string literal, matches
   enum) AND `risk_tier_source='auto'` are updated. Idempotent — a second call is a no-op
   (source already `'confirmed'`). If a human manually set `'overridden'` in the meantime,
   this is a no-op (won't clobber the override). `conn.close()` in `finally` (`:204-205`).
   GOTCHA: no try/except — DB errors propagate.
3. `logger.info("Tier 1 classification confirmed", extra={app_id, approved_by})`
   (`:207-210`). `approved_by` is logged only, not persisted to any column.

---

# FILE 3: arch_data_registry.py

Module docstring `arch_data_registry.py:1-22`: replaces the pre-2026-05-08 Temporal signal
handshake between ArchitectureWorkflow and DataWorkflow (which dropped signals on respawn
due to stale peer workflow ids, and dropped early-delivered signals when `self._app_id` was
still empty). Registry is a single table keyed on `(wave_id, target_app_id, signal_type)`:
publisher upserts, consumer polls then atomically claims.

## Module constants (`arch_data_registry.py:44-48`)
- `SIGNAL_TARGET_PROVISIONED = "target_provisioned"` (Architecture → Data)
- `SIGNAL_DATA_READY_FOR_TARGET = "data_ready_for_target"` (Data → Architecture)
- `_ALLOWED_SIGNAL_TYPES = frozenset({SIGNAL_TARGET_PROVISIONED,
  SIGNAL_DATA_READY_FOR_TARGET})`
These strings match the original Temporal signal handler names verbatim.

## Helper `_require_known_signal_type(signal_type: str) -> None` (`arch_data_registry.py:66-79`)
GOTCHA: if `signal_type not in _ALLOWED_SIGNAL_TYPES` → **raise `ValueError(f"Unknown
arch-data signal_type {signal_type!r}; expected one of {sorted(_ALLOWED_SIGNAL_TYPES)}")`**
(`:75-79`). The DB has no CHECK constraint on `signal_type` (migration comment
`046:...`); a typo would silently stash an unfindable row, so it fails loudly here.
Since `ValueError`'s type-name lacks retryable substrings, the decorator wraps it to
`NonRetryableError`.

Both activities call this guard first (`publish` `:100`, `consume` `:163`).

## Table `arch_data_signal_registry`
(`db/alembic/versions/046_create_arch_data_signal_registry.py:66-104`):
- `id` UUID PK default `gen_random_uuid()`
- `wave_id` UUID NOT NULL
- `target_app_id` UUID NOT NULL
- `signal_type` Text NOT NULL
- `payload` JSONB NOT NULL
- `created_at` TIMESTAMP tz NOT NULL default `now()`
- `consumed_at` TIMESTAMP tz nullable
- `consumed_by_workflow_id` Text nullable
- UniqueConstraint `(wave_id, target_app_id, signal_type)` named
  `arch_data_signal_registry_scope_uk`
- Partial index `idx_arch_data_registry_lookup` on the same tuple `WHERE consumed_at IS
  NULL`.

---

## ACTIVITY 6: `publish_arch_data_signal`
(`arch_data_registry.py:82-134`) — `@foundry_activity(config=ActivityConfig(enable_observability=True))`

**Signature**: `async publish_arch_data_signal(input: PublishArchDataSignalInput) -> None`.

**Input** `PublishArchDataSignalInput` (`types.py:2934-2956`):
- `signal_type: str` (`"target_provisioned"` | `"data_ready_for_target"`)
- `wave_id: str`, `target_app_id: str`
- `payload_json: str` — JSON-serialized `TargetProvisionedSignal` or
  `DataReadyForTargetSignal` (serialized by caller; activity schema is primitive-only).

**Output**: `None`.

**Logic**:
1. `_require_known_signal_type(input.signal_type)` (`:100`).
2. `wave_uuid = uuid.UUID(input.wave_id)`, `target_uuid = uuid.UUID(input.target_app_id)`
   (`:101-102`). GOTCHA: these are **not** wrapped in try/except (unlike the persist
   activities' app_id) — a bad UUID raises `ValueError` → decorator wraps to
   `NonRetryableError`.
3. **Upsert** (`:106-122`):
   ```sql
   INSERT INTO arch_data_signal_registry
       (wave_id, target_app_id, signal_type, payload)
   VALUES ($1, $2, $3, $4::jsonb)
   ON CONFLICT (wave_id, target_app_id, signal_type)
   DO UPDATE SET
       payload = EXCLUDED.payload,
       consumed_at = NULL,
       consumed_by_workflow_id = NULL,
       created_at = now()
   ```
   params: `wave_uuid`, `target_uuid`, `input.signal_type`, `input.payload_json`.
   GOTCHA — **writer-is-source-of-truth**: re-publishing the same key **resets
   `consumed_at`/`consumed_by_workflow_id` to NULL and bumps `created_at` to now()**, so the
   peer re-consumes the fresher payload even if a (dead) prior run already consumed it.
   Handles publisher respawn after worker restart / nondeterministic replay. `conn.close()`
   in `finally` (`:123-124`). No try/except around execute.
4. `logger.info("arch_data_registry.publish", extra={signal_type, wave_id, target_app_id,
   payload_chars: len(input.payload_json or "")})` (`:126-134`).

**Idempotency**: idempotent per key — repeated publish overwrites the same row (and re-arms
it for consumption).

---

## ACTIVITY 7: `consume_arch_data_signal`
(`arch_data_registry.py:137-214`) — `@foundry_activity(config=ActivityConfig(enable_observability=True))`

**Signature**: `async consume_arch_data_signal(input: ConsumeArchDataSignalInput) ->
ConsumeArchDataSignalResult`.

**Input** `ConsumeArchDataSignalInput` (`types.py:2959-2972`):
- `signal_type: str`, `wave_id: str`, `target_app_id: str`, `workflow_id: str`

**Output** `ConsumeArchDataSignalResult` (`types.py:2975-2985`):
- `found: bool = False`, `payload_json: str = ""`

**Logic**:
1. `_require_known_signal_type(input.signal_type)` (`:163`).
2. `wave_uuid = uuid.UUID(input.wave_id)`, `target_uuid = uuid.UUID(input.target_app_id)`
   (`:164-165`).
3. **Atomic claim** — single `UPDATE ... RETURNING` under the unique key (`:174-194`):
   ```sql
   UPDATE arch_data_signal_registry
   SET consumed_at = COALESCE(consumed_at, now()),
       consumed_by_workflow_id = COALESCE(consumed_by_workflow_id, $4)
   WHERE wave_id = $1 AND target_app_id = $2 AND signal_type = $3
     AND (consumed_at IS NULL OR consumed_by_workflow_id = $4)
   RETURNING payload::text AS payload_text
   ```
   params: `wave_uuid` ($1), `target_uuid` ($2), `input.signal_type` ($3),
   `input.workflow_id` ($4).
   GOTCHA — **idempotent claim**: the WHERE `(consumed_at IS NULL OR
   consumed_by_workflow_id = $4)` lets the *same* workflow claim/re-read the row (activity
   retry, workflow replay). The `COALESCE` keeps the original `consumed_at` /
   `consumed_by_workflow_id` on a re-claim so timestamps reflect the **first** claim, not the
   replay. Concurrent different consumers can't both win — first UPDATE sets
   `consumed_by_workflow_id`, the second sees a non-matching row and updates nothing.
   `conn.close()` in `finally` (`:195-196`).
4. **If `row is None`** → `return ConsumeArchDataSignalResult(found=False, payload_json="")`
   (`:198-199`). Two sub-cases fold into this (docstring `:151-161`): (1) no row published
   yet; (2) row exists but claimed by a **different** workflow_id (peer moved on). Both mean
   "wait" — the caller polls on a `workflow.sleep` interval.
5. Else `payload_text = row["payload_text"] or ""` (`:201`); `logger.info(
   "arch_data_registry.consume", extra={signal_type, wave_id, target_app_id, workflow_id,
   payload_chars: len(payload_text)})` (`:202-211`); return
   `ConsumeArchDataSignalResult(found=True, payload_json=payload_text)` (`:212-214`).

GOTCHA: `payload` is returned as **text** (`payload::text`), not re-parsed JSON — the caller
deserializes back into the signal dataclass.

**Idempotency**: idempotent per `(key, workflow_id)` — same workflow re-consuming gets the
same payload with `found=True`, no state mutation on re-claim.

---

# Cross-cutting notes

- **No agent-dispatch activities in this group.** All skill dispatch
  (`portfolio-scorer`, `classify-application`) happens in the *calling workflow*; these
  activities only receive the raw JSON string output and parse/persist it. Hence no skill
  selection / retry-with-feedback logic lives here.
- **No Git activities in this group** — all persistence is direct PostgreSQL via asyncpg;
  Git-as-source-of-truth for these artifacts is handled by other activities/workflows
  (`classification_json` is described as "already committed to Git" at `types.py:1397`).
- **Retry/timeout policies are caller-supplied.** None of the 7 activities declares a
  retry_policy or timeout in its `ActivityConfig` (all use only
  `enable_observability=True`). Workflows set these at `execute_activity` via
  `RETRY_POLICIES` from `olympus_workflows.retry_policies` (e.g.
  `workflows/rationalization.py:37`).
- **DB-error swallow asymmetry** (GOTCHA): the two *scoring* activities that touch
  read/snapshot paths swallow `(OSError, asyncpg.PostgresError)` internally and degrade
  gracefully (`scoring.py:119-124`, `:247-251`); `persist_portfolio_score`,
  `persist_classification`, `confirm_classification_tier_1`, and both arch_data activities
  do **not** — their DB errors propagate to the decorator and typically wrap to
  `NonRetryableError` (asyncpg error type names rarely contain the retryable substrings).
- Registration: all 7 registered in `temporal/olympus_workflows/worker.py` (scoring at
  `:148-150,280-281,309`; classification at `:53-54,307-308`; arch_data at
  `:32-33,312-313`).
