# Disposition Activities — Atomic Regeneration Spec

Activity group covering the terminal Disposition-line artifact + projection layer.

Files (paths relative to repo root, all under `temporal/olympus_workflows/`):

- `activities/disposition_outputs.py` — bundle synthesis helpers + `emit_disposition_output_bundle` (the only `@foundry_activity` in this file).
- `activities/line_transitions/disposition.py` — `persist_disposition_side_effects` and `update_application_line_projection` (`@foundry_activity`s), plus 3 pure extractor helpers.

**Activity functions captured in this doc (units_documented = 3):**
1. `emit_disposition_output_bundle` — `activities/disposition_outputs.py:560`
2. `persist_disposition_side_effects` — `activities/line_transitions/disposition.py:198`
3. `update_application_line_projection` — `activities/line_transitions/disposition.py:331`

The pure helpers (`bundle_pre_gate_evidence`, `bundle_post_gate_evidence`, `_build_payload`, the per-disposition `_*_payload` builders, `_base_envelope`, and the 3 `_extract_*` projection helpers) are NOT Temporal activities — they are called from workflow code steps / from inside the activities — but they are fully load-bearing for behavioral parity and are reproduced below.

---

## 0. What `@foundry_activity` adds over `activity.defn`

Source: `temporal_base/activities.py:79-150`. Every activity below is decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

`foundry_activity(config=None, name=None, **activity_kwargs)` returns a decorator that:

1. Wraps the user function in an async `wrapper` (`activities.py:102`) and applies `@activity.defn(name=name, **activity_kwargs)` to that wrapper, then `@wraps(func)` (`activities.py:100-101`). **GOTCHA: `@activity.defn` is applied to the `@wraps`-wrapped inner function, so the Temporal activity name defaults to `func.__name__`** (via `@wraps`) unless `name=` is passed. None of the 3 activities pass `name=`, so their Temporal names are exactly `emit_disposition_output_bundle`, `persist_disposition_side_effects`, `update_application_line_projection`. Temporal replay keys on this name (`activities.py:14-16`).
2. **Observability** (`ActivityConfig.enable_observability=True`, the default): logs `"Activity %s starting"` before the body (`activities.py:105-110`), `"Activity %s completed"` after success (`activities.py:115-120`), and `"Activity %s failed: %s"` on exception (`activities.py:125-131`). Uses stdlib `logging` — no Prometheus/structlog. `log_inputs`/`log_outputs` default `False`, so the `extra={"inputs": ...}` / `{"outputs": ...}` payloads are `None` (`activities.py:109`, `:119`).
3. **Error wrapping** (`enable_error_wrapping=True`, default) (`activities.py:133-146`):
   - If the escaping exception is already a `WorkflowError` or `temporalio.exceptions.ApplicationError` → re-raised unchanged (`activities.py:135-136`). `NonRetryableError`/`RetryableError` are `WorkflowError` subclasses, so **they pass through untouched with their own `non_retryable` flag**.
   - Else if `_is_retryable_error(error)` is True → wrapped in `RetryableError(f"Retryable error in {name}: {error}")` (`activities.py:137-140`).
   - Else → wrapped in `NonRetryableError(f"Non-retryable error in {name}: {error}")` (`activities.py:141-144`).
   - `_is_retryable_error` (`activities.py:56-76`) **classifies by the lowercased `str(type(error))` containing any of**: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. **GOTCHA: this is a *type-name string match*, not instance inspection** — intentionally distinct from `errors.is_retryable_error` (`activities.py:60-62`). E.g. `ValueError` → non-retryable; a class named `ConnectionResetError` → retryable.
4. **Config defaults** (`ActivityConfig`, `activities.py:41-53`): all timeouts and `retry_policy` default `None` — **the decorator does NOT set any retry policy or timeout on the activity itself**; those come from the workflow's `execute_activity(...)` call. None of the 3 disposition activities carry a `retry_policy` in their `ActivityConfig`.

---

## 1. `emit_disposition_output_bundle` (`disposition_outputs.py:560-600`)

### Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def emit_disposition_output_bundle(
    input: EmitDispositionOutputBundleInput,
) -> EmitDispositionOutputBundleResult
```

### Input — `EmitDispositionOutputBundleInput` (`types.py:2844-2858`)
| field | type | notes |
|---|---|---|
| `repo` | `str` | artifact repo override; passed to `_build_git_service(repo_override=...)` |
| `branch` | `str` | working branch to commit on |
| `portfolio_id` | `str` | used in the committed path |
| `app_id` | `str` | used in path + commit message |
| `bundle` | `dict` | the full disposition-output envelope, must conform to `schemas/dispositions/disposition-output.schema.json` |

### Output — `EmitDispositionOutputBundleResult` (`types.py:2861-2866`)
`path: str`, `commit_sha: str`.

### Behavior, in order (`disposition_outputs.py:571-600`)
1. `bundle = input.bundle` (`:571`).
2. `_validate_bundle(bundle)` (`:572`) — schema validation, raises `NonRetryableError` on failure (see §1.3). **No try/except here** — a validation failure propagates out of the activity body; since `NonRetryableError` is a `WorkflowError`, the decorator re-raises it untouched (non-retryable).
3. `path = _artifact_path(input.portfolio_id, input.app_id)` (`:574`) → **exactly** `f"dispositions/{portfolio_id}/{app_id}/disposition-output.json"` (`disposition_outputs.py:556-557`).
4. `content = json.dumps(bundle, indent=2, sort_keys=True) + "\n"` (`:575`). **GOTCHA: `sort_keys=True` + `indent=2` + trailing newline — the on-disk JSON is key-sorted and pretty-printed; byte-for-byte reproduction requires all three.**
5. `svc = _build_git_service(repo_override=input.repo)` (`:577`) — see §1.4.
6. `result = svc.commit_file(branch=input.branch, path=path, content=content, commit_message=f"{input.app_id}: disposition-output bundle ({bundle.get('disposition', '?')}) [P5-S13 / W12]")` (`:578-586`). **The commit message embeds `bundle["disposition"]` or literal `"?"` if absent.**
7. `logger.info("disposition_output_bundle_emitted", extra={app_id, portfolio_id, disposition, path=result.path, commit_sha=result.commit_sha})` (`:587-596`).
8. Return `EmitDispositionOutputBundleResult(path=result.path, commit_sha=result.commit_sha)` (`:597-600`).

### 1.3 `_validate_bundle` (`disposition_outputs.py:521-553`)
1. `envelope_path = _DISPOSITION_SCHEMAS_DIR / "disposition-output.schema.json"` (`:527`).
2. If `envelope_path` doesn't exist → `raise NonRetryableError("disposition-output schema not found at {envelope_path}. Check your repo layout.")` (`:528-532`).
3. Load `envelope_schema = json.load(open(envelope_path))` (`:533-534`).
4. `store = _load_schema_store()` (`:536`) — see below.
5. `resolver = RefResolver(base_uri=envelope_schema.get("$id", envelope_path.as_uri()), referrer=envelope_schema, store=store)` (`:537-541`). Uses `jsonschema.RefResolver` (`disposition_outputs.py:28`).
6. `validator = Draft202012Validator(envelope_schema, resolver=resolver)` (`:542`).
7. `errors = list(validator.iter_errors(bundle))` (`:543`); if empty → return (`:544-545`).
8. Else build up to 5 lines `f"  {err.json_path}: {err.message}"` (`:547-549`) and `raise NonRetryableError("disposition-output bundle failed schema validation ({N} error(s)):\n" + joined)` (`:550-553`). **GOTCHA: `N` is total error count but only the first 5 are printed** (`errors[:5]`, `:548`).

**`_load_schema_store` (`disposition_outputs.py:506-518`):** builds a `{$id: schema}` dict by globbing `_DISPOSITION_SCHEMAS_DIR.glob("*.schema.json")` (`:512`), loading each, and storing under its `$id` if present (`:515-517`). Returns `{}` if the dir doesn't exist (`:510-511`). This is what lets the envelope's payload `$ref`s resolve against the per-disposition schemas (`retire-output.schema.json`, etc.).

**`_resolve_schemas_dir` (`disposition_outputs.py:489-503`) — schema-dir resolution order (module-load-time, `:503`):**
1. `$OLYMPUS_SCHEMAS_DIR` if set (`:491-493`).
2. `Path(__file__).resolve().parents[3] / "schemas"` (dev source layout) (`:494`).
3. `/app/schemas` (`:495`).
4. `/app/repo/schemas` (`:496`).
Returns first `.is_dir()` match `.resolve()`d (`:497-499`), else falls back to candidate #2 (`:500`, informative). `_DISPOSITION_SCHEMAS_DIR = _resolve_schemas_dir() / "dispositions"` (`:503`). **GOTCHA: computed at import time. `parents[3]` is chosen so the wheel-installed `site-packages/olympus_workflows/activities/disposition_outputs.py` does NOT accidentally point at a `schemas/` under site-packages — container/helm set `$OLYMPUS_SCHEMAS_DIR` (`:478-488`). This is a documented past prod failure.**

**GOTCHA — schema `status` enum mismatch:** the envelope schema (`schemas/dispositions/disposition-output.schema.json`) declares `status` enum `["completed","partial","rolled-back","abandoned"]`. But the bundle builders set `status` to `"in_progress"` / `"plan_approved"` / `"completed"` (`disposition_outputs.py:412`, `:463`, and the workflow's Retain flip to `"plan_approved"`). Only `"completed"` is in the schema enum. Pre-gate (`"in_progress"`) and Retain-terminal (`"plan_approved"`) bundles would FAIL envelope validation IF validated. The workflow commits pre/post-gate bundles via `write_artifact` (not this activity — see the helper docstrings, `:403-405`, `:441-451`); `emit_disposition_output_bundle` validates whatever `input.bundle` it is handed, so it is only schema-safe for `status="completed"` bundles. Reproduce this exactly — do not "fix" the enum.

### 1.4 `_build_git_service` + git config (`git_operations.py:150-165`, `:141-147`)
- `_git_service_config()` reads env: `GITHUB_TOKEN` (default `""`), `GITHUB_REPO` (default `""`), `GITHUB_BASE_URL` (default `"https://api.github.com"`) (`git_operations.py:141-147`).
- `_build_git_service(repo_override)` imports `GitService` at call time (PyGithub only present in worker container, `git_operations.py:153-156`) and constructs `GitService(GitServiceConfig(token, repo=repo_override or cfg["repo"], base_url))` (`:159-165`).

### 1.5 `commit_file` sequence (`olympus-api/src/services/git_service.py:213-253`)
Returns `CommitResult(commit_sha, path, branch)` (`git_service.py:253`; dataclass at `olympus-contracts/olympus_contracts/git_types.py:51-56`).
1. If `branch != "main"` → `self._ensure_branch(branch)` (`git_service.py:226-227`). `_ensure_branch` (`:188-211`): `get_git_ref("heads/{branch}")`; if it exists, return; on 404 create `refs/heads/{branch}` from `heads/main` (base_branch default `"main"`, `:188`); a 422 on create is swallowed as a create race (`:207-208`); other `GithubException` → `GitServiceError`.
2. `existing = self._repo.get_contents(path, ref=branch)` (`:230`). If a directory (`list`) → `GitServiceError("Path '{path}' is a directory, not a file")` (`:231-232`). Else `update_file(path, message, content, sha=existing.sha, branch)` (`:233-239`).
3. On `GithubException` with `status == 404` → `create_file(path, message, content, branch)` (`:241-247`). Any other status → `GitServiceError(f"Failed to commit file: {exc.data}")` (`:248-249`).
4. `commit_sha = result["commit"].sha` (`:251`); return `CommitResult`.

**GOTCHA — no `_reraise_git_error` funnel here.** Unlike the git activities in `git_operations.py` (`git_operations.py:168-` funnels transient TLS/connection faults through `_reraise_git_error` to force retry), `emit_disposition_output_bundle` has NO try/except around `commit_file`. A `GitServiceError` (raised by `commit_file` on non-404 GithubException, `git_service.py:249`) escapes the activity body → the `@foundry_activity` wrapper runs `_is_retryable_error(GitServiceError(...))` → type name `"gitserviceerror"` matches none of the retry patterns → **wrapped `NonRetryableError`.** So a genuinely transient GitHub error during the bundle commit permanently fails the workflow step. This is the exact class of bug `_reraise_git_error` was written to fix in the *other* git activities, and this activity does not use it.

### Idempotency
`commit_file` create-or-update makes re-runs on the same branch/path a no-op-equivalent (re-writes the same content, new commit SHA). Schema validation is deterministic given the same bundle + schemas dir. No DB writes.

---

## Bundle synthesis helpers (pure; called from workflow code steps)

These build the `bundle` dict that the workflow later hands to `emit_disposition_output_bundle` (or commits via `write_artifact`). Pure/side-effect-free so workflow replay is deterministic (`disposition_outputs.py:41-64`, `:394-405`).

### `_step_path(step_committed_paths, step_name)` (`disposition_outputs.py:67-77`)
Returns `step_committed_paths.get(step_name, [])[0]` or `""` if empty. First committed path for a step, else empty string.

### `_base_envelope(...)` (`disposition_outputs.py:80-134`)
Keyword-only. Builds the common envelope. Refs are derived from `wave_id`:
- `disposition_decision_ref` = `f"rationalization/wave-{wave_id}/{app_id}/disposition-recommendation.json"` if `wave_id` else `""` (`:98-103`).
- `baseline_ref` = `f"rationalization/wave-{wave_id}/{app_id}/tco-analysis.json"` if `wave_id` else `""` (`:104-108`).
- `user_impact_ref` = `f"rationalization/wave-{wave_id}/{app_id}/user-impact-analysis.json"` if `wave_id` else `""` (`:109-113`).

Returned dict (`:114-134`):
```json
{
  "application_id": app_id,
  "application_name": app_name or app_id,
  "portfolio_id": portfolio_id,
  "wave_id": wave_id,
  "disposition": disposition,
  "status": status,
  "started_at": started_at,
  "completed_at": completed_at,               // None for pre-gate
  "disposition_decision_ref": disposition_decision_ref,
  "approvals": list(approvals),                // copied
  "realized_net_impact": {
    "tco_delta": {
      "annual_savings_usd": null,
      "one_time_cost_usd": null,
      "baseline_ref": baseline_ref or None     // "" → null
    },
    "users_affected_actual": null,
    "users_affected_estimate_ref": user_impact_ref or None  // "" → null
  }
}
```
`status` docstring (`:94-97`): `"in_progress"` (pre-gate), `"plan_approved"` (post-G-DE-1 Retain), `"completed"` (post-G-DE-2 non-Retain).

### `_build_payload(disposition, step_committed_paths, *, app_id, include_post_gate, now_iso)` (`disposition_outputs.py:343-379`)
Dispatch by label. **Unsupported label (anything not Retire/Retain/Replace/Replatform/Consolidate) → `raise ValueError("Unsupported disposition for bundle helper: ... Refactor/Rearchitect are handled by DeploymentWorkflow, not here.")` (`:376-379`).** Retain ignores `include_post_gate` (`:355`, `:362-363`).

#### `_retire_payload` (`disposition_outputs.py:137-173`)
```json
{
  "disposition": "Retire",
  "decommission_certificate_ref": <if include_post_gate: _step_path("infrastructure-decommission") OR f"disposition/{app_id}/decommission-certificate.json"; else "">,
  "archival": {
    "archive_locations": [],
    "reconstruction_plan_ref": _step_path("data-archival-plan"),
    "data_archival_plan_ref": _step_path("data-archival-plan")
  },
  "consumer_migration": {
    "consumers_notified": 0,
    "consumers_confirmed_migrated": 0,
    "migration_report_ref": <_step_path("consumer-migration") if include_post_gate else "">
  },
  "license_reclamation_ref": <_step_path("license-reclamation") if include_post_gate else "">,
  "infrastructure_torn_down": []
}
```
**GOTCHA (`:146-149`): `decommission_certificate_ref` when post-gate falls back to the synthetic path `disposition/{app_id}/decommission-certificate.json` if the `infrastructure-decommission` step committed nothing.**

#### `_retain_payload` (`disposition_outputs.py:176-206`) — all steps pre-G-DE-1
```json
{
  "disposition": "Retain",
  "retain_reason": "Retained per Rationalization disposition decision",
  "remediation_outcome": {
    "security_findings_closed": 0,
    "security_remediation_ref": _step_path("security-remediation"),
    "documentation_updates_ref": _step_path("documentation-update"),
    "test_coverage_baseline_pct": 0.0,
    "monitoring_setup_ref": _step_path("monitoring-setup")
  },
  "sustainment_handoff": {
    "owner_team": "sustainment",
    "handoff_confirmed_at": now_iso,
    "handoff_ref": _step_path("sustainment-handoff")
  },
  "re_evaluation_triggers": ["annual review"]
}
```

#### `_replace_payload` (`disposition_outputs.py:209-245`)
```json
{
  "disposition": "Replace",
  "selected_vendor": {"name": "TBD", "product_version": "TBD", "vendor_evaluation_ref": _step_path("vendor-evaluation")},
  "integration": {"integration_spec_ref": _step_path("integration-specification"), "cutover_plan_ref": _step_path("integration-specification")},
  "data_migration": {"records_migrated": 0, "reconciliation_pass": false, "migration_ref": <_step_path("data-migration") if include_post_gate else "">},
  "legacy_decommission_ref": <_step_path("legacy-decommission") if include_post_gate else "">
}
```
Note `cutover_plan_ref` reuses the `integration-specification` step path (`:229-231`).

#### `_replatform_payload` (`disposition_outputs.py:248-296`)
```json
{
  "disposition": "Replatform",
  "target_platform": {"name": "TBD", "platform_selection_ref": _step_path("platform-selection")},
  "workflow_mapping_ref": _step_path("workflow-mapping"),
  "component_configuration_ref": <_step_path("component-configuration") if include_post_gate else "">,
  "data_migration": {"records_migrated": 0, "reconciliation_pass": false, "migration_ref": <_step_path("data-migration") if include_post_gate else "">},
  "validation_cutover_ref": <_step_path("validation-cutover") if include_post_gate else "">,
  "legacy_decommission_ref": <_step_path("legacy-decommission") if include_post_gate else "">,
  "perf_delta": {"latency_p95_before_ms": null, "latency_p95_after_ms": null, "source": "parallel-run-monitor"},
  "cost_delta": {"monthly_before_usd": null, "monthly_after_usd": null}
}
```

#### `_consolidate_payload` (`disposition_outputs.py:299-340`)
```json
{
  "disposition": "Consolidate",
  "target_application": {"id": "00000000-0000-0000-0000-000000000000", "name": "TBD", "target_selection_ref": _step_path("target-selection")},
  "feature_gap_analysis_ref": _step_path("feature-gap-analysis"),
  "features_ported": 0,
  "features_dropped": [],
  "enhancement_plan_ref": _step_path("enhancement-planning"),
  "data_reconciliation": {"records_merged": 0, "conflicts_resolved": 0, "reconciliation_ref": <_step_path("data-reconciliation") if include_post_gate else "">},
  "user_migration_ref": <_step_path("user-migration") if include_post_gate else "">,
  "absorbed_decommission_ref": <_step_path("absorbed-decommission") if include_post_gate else "">
}
```
**GOTCHA: `target_application.id` defaults to the all-zeros UUID `"00000000-0000-0000-0000-000000000000"` (`:310`).**

### `bundle_pre_gate_evidence(...)` (`disposition_outputs.py:382-424`)
Keyword-only; `approvals: list | None = None`, `now_iso: str = ""`. Calls `_base_envelope(status="in_progress", completed_at=None, approvals=approvals or [])` (`:406-416`), then `envelope["payload"] = _build_payload(disposition, ..., include_post_gate=False, now_iso=now_iso or started_at)` (`:417-423`). **`now_iso` falls back to `started_at`.**

### `bundle_post_gate_evidence(...)` (`disposition_outputs.py:427-476`)
Keyword-only; requires `completed_at` and `approvals`. **If `disposition == "Retain"` → `raise ValueError(...)` (`:452-457`) — Retain terminates at G-DE-1, never calls this.** Calls `_base_envelope(status="completed", completed_at=completed_at, approvals=approvals)` (`:458-468`), then `envelope["payload"] = _build_payload(..., include_post_gate=True, now_iso=now_iso or completed_at)` (`:469-475`).

---

## 2. `persist_disposition_side_effects` (`line_transitions/disposition.py:198-328`)

### Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_disposition_side_effects(
    input: PersistDispositionSideEffectsInput,
) -> PersistDispositionSideEffectsResult
```

### Input — `PersistDispositionSideEffectsInput` (`types.py:2683-2708`)
| field | type | default | notes |
|---|---|---|---|
| `app_id` | `str` | — | must parse as UUID |
| `disposition` | `str` | — | one of Retire/Retain/Replace/Replatform/Consolidate |
| `disposition_output_ref` | `str` | `""` | committed artifact path of the merged bundle |
| `disposition_output_json` | `str` | `""` | the full envelope JSON as a string (already committed) |
| `disposition_current_status` | `str` | `""` | workflow-authoritative lifecycle: `disposition_complete` / `disposition_plan_approved` / `disposition_failed` |
| `completed_at` | `str` | `""` | ISO-8601 |
| `execution_context` | `StepExecutionContext \| None` | `None` | for `step_execution` emission |

### Output — `PersistDispositionSideEffectsResult` (`types.py:2711-2724`)
`app_id`, `disposition_output_ref_persisted: bool=False`, `disposition_completed_at_persisted: bool=False`, `disposition_current_status: str=""`, `cost_savings_annual_usd_persisted: bool=False`.

### Behavior, in order (`disposition.py:218-328`)
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_disposition_side_effects")` (`:218-221`). If `execution_context is None`, returns `None` and no `step_execution` row is written (`execution.py:295-296`). Otherwise emits a RUNNING `step_execution` record keyed on `portfolio_id/line_id/step_id`, `step_kind=CODE`, `workflow_id`+`attempt` from `activity.info()` (`execution.py:298-321`).
2. Enter `try` (`:222`). Parse `app_uuid = uuid.UUID(input.app_id)` (`:224`). **On `ValueError`/`TypeError`: `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` then `raise NonRetryableError(f"Invalid app_id: {input.app_id!r}")` (`:225-231`).**
3. `disposition = (input.disposition or "").strip()` (`:233`). If truthy and NOT in `_DISPOSITION_LABELS` (`{"Retire","Retain","Replace","Replatform","Consolidate"}`, `disposition.py:53-55`) → `logger.warning("unexpected disposition")` and **continue best-effort** (does NOT raise) (`:234-244`). Refactor/Rearchitect go through Modernization, not here.
4. `envelope = _try_parse_json(input.disposition_output_json)` (`:246`). `_try_parse_json` (`_shared.py:40-56`): returns dict or `None`. Tries `json.loads`; on `JSONDecodeError` finds first `{` … last `}` substring and retries; returns the value only if it's a `dict`, else `None`.
5. Build `projections: dict` by merging three extractors (`:248-262`):
   - `_extract_disposition_output_ref_side_effects(disposition_output_ref=input.disposition_output_ref)`
   - `_extract_cost_savings_side_effects(envelope)`
   - `_extract_disposition_lifecycle_status(envelope=..., workflow_supplied_status=input.disposition_current_status, disposition=disposition, completed_at=input.completed_at)`
6. **If `projections` is empty** (`:264-272`): `logger.info("nothing extractable")`, `emit_code_step_complete(exec_id, columns_written=[])`, return `PersistDispositionSideEffectsResult(app_id=input.app_id)` (all-default result). **Early return — no DB touch.**
7. `sql, params = _build_update_sql(projections)` (`:274`); `params.append(app_uuid)` (`:275`). See §2.4.
8. DB write (`:277-294`): `conn = await asyncpg.connect(_db_url())`; `await conn.execute(sql, *params)`; `await conn.close()` in `finally`. **`_db_url()` reads env** `DATABASE_HOST`/`DATABASE_PORT`/`DATABASE_USER`/`DATABASE_PASSWORD`/`DATABASE_NAME` (defaults `localhost/5432/olympus/olympus/olympus`, `_shared.py:23-29`).
   - **On ANY `Exception` (`except Exception`, `:283`, best-effort — swallows DB blips): `logger.warning("DB write failed; continuing best-effort")`, `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))`, and return `PersistDispositionSideEffectsResult(app_id=input.app_id)` (all-default). Does NOT re-raise.** (`:283-294`) **GOTCHA: this is fully best-effort — the bundle in Git is source of truth; the DB row is a derived cache (`:213-216`). Signal emission to Deployment happens in the workflow after this returns, independent of projection success.**
9. On success: `logger.info("disposition side-effects persisted", columns_written=sorted(projections.keys()))` (`:296-303`); `emit_code_step_complete(exec_id, columns_written=sorted(projections.keys()))` (`:304-306`).
10. Return `PersistDispositionSideEffectsResult(app_id, disposition_output_ref_persisted=("disposition_output_ref" in projections), disposition_completed_at_persisted=("disposition_completed_at" in projections), disposition_current_status=str(projections.get("disposition_current_status","")), cost_savings_annual_usd_persisted=("cost_savings_annual_usd" in projections))` (`:307-321`).
11. Outer `except NonRetryableError: raise` (`:322-323`) — passes NonRetryable through. Outer `except Exception as exc` (`:324-328`): `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` then `raise` — catches failures OUTSIDE the inner DB try (e.g. `_build_update_sql`, extractor bugs) and re-raises them (which the `@foundry_activity` wrapper then classifies).

### 2.1 `_extract_disposition_output_ref_side_effects` (`disposition.py:58-75`)
Pass-through gate on presence. If `disposition_output_ref` is not a `str` → `{}` (`:70-71`). `ref = ref.strip()`; if empty → `{}` (`:73-74`). Else `{"disposition_output_ref": ref}` (`:75`). Does NOT parse anything.

### 2.2 `_extract_cost_savings_side_effects(envelope)` (`disposition.py:78-119`)
- If `envelope` not a dict → `{}` (`:94-95`).
- Preferred source: `envelope["realized_net_impact"]["tco_delta"]["annual_savings_usd"]`; if that value is `int`/`float` → return `{"cost_savings_annual_usd": float(value)}` (`:100-106`).
- Fallback: `envelope["payload"]["cost_savings_cert"]["annual_savings_usd"]`; if `int`/`float` → `{"cost_savings_annual_usd": float(value)}` (`:111-117`).
- Else `{}` (`:119`). **GOTCHA: Retain/Consolidate commonly produce no savings forecast → empty (`:88-93`). `bool` would pass `isinstance(x,(int,float))` in Python but bundles carry numeric values here.**

### 2.3 `_extract_disposition_lifecycle_status(*, envelope, workflow_supplied_status, disposition, completed_at)` (`disposition.py:122-195`)
Builds `out` dict:
1. **Status precedence — workflow-supplied wins.** `status = workflow_supplied_status.strip() if workflow_supplied_status else ""` (`:144`). If `status` is truthy AND in `_DISPOSITION_LIFECYCLE_STATES` (`{"disposition_in_progress","disposition_plan_approved","disposition_complete","disposition_failed"}`, `disposition.py:43-50`) → `out["disposition_current_status"] = status` (`:145-146`).
2. **Else** if `envelope` is a dict, read `envelope["status"]` and map bare-enum → column-level lifecycle (`:147-162`):
   - `"completed"` → `"disposition_complete"` (`:152-156`)
   - `"plan_approved"` → `"disposition_plan_approved"` (`:157-160`)
   - `"in_progress"` → `"disposition_in_progress"` (`:161-162`)
3. **Retain correction (`:169-181`):** if `disposition == "Retain"` AND `out["disposition_current_status"] == "disposition_plan_approved"` AND `not workflow_supplied_status` → override to `"disposition_complete"` (Retain has no G-DE-2). **Only applies when the value came from the envelope, not the workflow (`:180-181`).**
4. **`completed_at` → datetime (`:184-193`):** if truthy, `datetime.fromisoformat(completed_at.replace("Z","+00:00"))` → `out["disposition_completed_at"]`. On `TypeError`/`ValueError` → `logger.warning("completed_at not ISO-8601")` and **skip the column (no raise)**.
5. Return `out`.

### 2.4 `_build_update_sql(projections)` → `(sql, params)` (`_shared.py:506-539`)
Iterates the ordered `_SIDE_EFFECT_COLUMNS` tuple (`_shared.py:70-153`) — **only columns present in `projections` are emitted, in tuple order.** For each present column:
- If in `_JSONB_COLUMNS` (`_shared.py:156-171`) → `value = json.dumps(value)`. **None of the 4 disposition columns are JSONB**, so disposition projections are bound as-is.
- `assignments.append(f"{column} = ${idx}")`, `params.append(value)`, `idx += 1` (`:522-525`).

Then always appends `updated_at = ${idx}` with `datetime.now(timezone.utc)` (`:527-529`), and the WHERE is `id = ${where_idx}` (`:532-538`). The caller appends `app_uuid` last (`disposition.py:275`), matching `${where_idx}`.

The 4 disposition columns (from `_SIDE_EFFECT_COLUMNS`, `_shared.py:145-153`; all TABLE = `application`):
| column | source | native type note |
|---|---|---|
| `disposition_output_ref` | `_extract_disposition_output_ref_side_effects` | text |
| `disposition_completed_at` | `_extract_disposition_lifecycle_status` | `datetime` (`_NATIVE_COLUMNS`, `_shared.py:192`) |
| `disposition_current_status` | `_extract_disposition_lifecycle_status` | text |
| `cost_savings_annual_usd` | `_extract_cost_savings_side_effects` | `Decimal`/numeric column, bound as Python `float` (`_shared.py:193`; value is `float(value)`) |

**GOTCHA: column write order is fixed by the tuple, NOT by dict-insertion order — parity requires iterating `_SIDE_EFFECT_COLUMNS` (`_shared.py:517`).** Final resulting SQL is a single `UPDATE application SET <present cols>, updated_at = $N WHERE id = $N+1`.

### Idempotency / retries
Re-running writes the same projected values (except `updated_at` = wall clock). No `retry_policy` in config; only `NonRetryableError` (invalid app_id) and re-raised outer exceptions are terminal — DB failures are swallowed. **GOTCHA: because DB errors are swallowed and return a default result, a caller cannot distinguish "nothing to project" from "DB down" via the result alone — both yield an all-default `PersistDispositionSideEffectsResult`.**

---

## 3. `update_application_line_projection` (`line_transitions/disposition.py:331-400`)

### Signature
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def update_application_line_projection(
    input: UpdateApplicationLineProjectionInput,
) -> UpdateApplicationLineProjectionResult
```

### Input — `UpdateApplicationLineProjectionInput` (`types.py:1943-1963`)
`app_id: str`, `line: str` (AssemblyLineName e.g. `"Architecture"`/`"Data"`), `workflow_id: str`, `status: str` (`in_progress`|`completed`|`failed`), `step: str | None = None`.

### Output — `UpdateApplicationLineProjectionResult` (`types.py:1966-1970`)
`updated: bool`.

### Behavior, in order (`disposition.py:350-400`)
1. `app_uuid = uuid.UUID(input.app_id)`; on `ValueError`/`TypeError` → `raise NonRetryableError(f"Invalid app_id: {input.app_id!r}")` (`:351-353`).
2. `line_slug = input.line.lower().replace(" ", "-")` (`:355`).
3. `normalized_status = input.status.strip().lower()` (`:356`). **If not in `{"in_progress","completed","failed"}` → `raise NonRetryableError("Unsupported status ... — expected 'in_progress' | 'completed' | 'failed'")` (`:357-361`).**
4. `current_status = f"{line_slug.replace('-', '_')}_{normalized_status}"` (`:362`). **GOTCHA: the slug is lowercased+space→hyphen, then hyphen→underscore for the status token — e.g. line `"Architecture"` → `architecture_in_progress`; a multi-word line `"Foo Bar"` → `foo_bar_completed`.**
5. `conn = await asyncpg.connect(_db_url())` (`:364`); in `try`, run:
   ```sql
   UPDATE application
   SET current_status = $1, current_line = $2, current_step = $3,
       workflow_id = $4, updated_at = $5
   WHERE id = $6
   ```
   with params `(current_status, input.line, input.step, input.workflow_id, datetime.now(timezone.utc), app_uuid)` (`:366-382`). `finally: await conn.close()` (`:383-384`). **`current_line` gets the raw `input.line` (not the slug); `current_step` gets `input.step` (may be `None`).**
6. Parse row count: `updated = int(result.split()[-1]) > 0` where `result` is asyncpg's `"UPDATE N"` string; on `AttributeError`/`ValueError`/`IndexError` → `updated = False` (`:389-392`).
7. If not `updated` → `logger.warning("no row updated")` (`:394-398`) — **does NOT raise; app not existing is surfaced only via `updated=False`.**
8. Return `UpdateApplicationLineProjectionResult(updated=updated)` (`:400`).

**GOTCHA — no `emit_code_step_*` here.** Unlike `persist_disposition_side_effects`, this activity does NOT emit `step_execution` records (no `execution_context` on its input) and does NOT swallow DB errors — a raw `asyncpg` failure escapes the body and is classified by the `@foundry_activity` wrapper (e.g. a `ConnectionError`-named exception → retryable; a generic `PostgresError` → non-retryable by the type-name heuristic).

### Idempotency / retries
Idempotent: repeated UPDATE with same params yields the same row (only `updated_at` moves). No `retry_policy` set in config. Purpose (`disposition.py:335-349`): used by fan-out paths that don't go through `start_next_line_workflow`'s linear hand-off — specifically per-target Architecture/Data fan-out from `WaveRationalizationWorkflow` post-G-DA; the caller passes its own `workflow_id` from `workflow.info()`.

---

## Cross-cutting notes / GOTCHAs summary

- All 3 activities decorated identically: `@foundry_activity(config=ActivityConfig(enable_observability=True))` — no custom retry policy or timeout at the decorator; those are set by the workflow's `execute_activity`.
- `NonRetryableError`/`RetryableError` are `WorkflowError` subclasses → pass through the wrapper's error-wrap untouched (`activities.py:135-136`).
- `emit_disposition_output_bundle` is the only Git-writing activity in the group and is the only one that lacks the `_reraise_git_error` transient-fault funnel → transient GitHub errors become non-retryable (parity-critical bug to reproduce).
- `persist_disposition_side_effects` is fully best-effort on DB; `update_application_line_projection` is not (lets DB errors escape).
- Schema `status` enum vs. the code's `in_progress`/`plan_approved` values: only `completed` is schema-valid; pre/post-gate bundles are committed outside this activity via `write_artifact` (helper docstrings), so validation only bites on `status="completed"` bundles.
- Column write order in `persist_disposition_side_effects` is fixed by the `_SIDE_EFFECT_COLUMNS` tuple order, not dict order.
