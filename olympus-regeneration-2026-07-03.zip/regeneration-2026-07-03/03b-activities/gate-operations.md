# Activity Group: Gate Operations

**Atomic regeneration spec — behavioral parity required.**

Source files (paths relative to repo root):
- `temporal/olympus_workflows/activities/gate_operations.py`
- `temporal/olympus_workflows/activities/gate_pre_review.py`

Verified against live code at HEAD `6c99bb6b` (working tree). Do NOT trust the prior
regeneration spec's facts for this group — re-verify every line here.

This group contains **10** activity functions (all decorated with `@foundry_activity`):

| # | Function | File | DB writes | Kind |
|---|---|---|---|---|
| 1 | `check_gate_criteria` | gate_operations.py:769 | none (pure) | criteria eval |
| 2 | `submit_gate_evidence` | gate_operations.py:935 | `gate` UPDATE (conditional) | persist |
| 3 | `wait_for_gate_decision` | gate_operations.py:995 | none | marker |
| 4 | `create_gate_record` | gate_operations.py:1044 | `gate` INSERT | persist |
| 5 | `set_gate_merge_blocked` | gate_operations.py:1119 | `gate` UPDATE | persist |
| 6 | `mark_gate_ready_for_review` | gate_operations.py:1168 | `gate` UPDATE | persist |
| 7 | `resolve_parallel_run_seconds` | gate_operations.py:1195 | none | env-read |
| 8 | `update_application_status` | gate_operations.py:1231 | `application` UPDATE | persist |
| 9 | `fetch_gate_capability_lineage_rework` | gate_operations.py:1268 | none (SELECT only) | read |
| 10 | `store_gate_pre_review` | gate_pre_review.py:144 | `gate` UPDATE (JSONB merge) | persist |

Plus **6 module-level helper functions** (not activities, but load-bearing): `_resolve_threshold`,
`_find_file_artifact`, `_get_json_path`, `_evaluate_threshold`, `_db_url` (defined twice — once
per file), `_safe_str` (gate_operations.py), and `_parse_pre_review` (gate_pre_review.py).

---

## 0. What `@foundry_activity` adds (applies to ALL 10 functions)

Decorator source: `temporal/olympus_workflows/temporal_base/activities.py:79`. Every function
here is decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`. The
decorator wraps the raw async function; the **wrapper** is what `@activity.defn` registers.

`ActivityConfig` dataclass (activities.py:41-53) fields and defaults:
- `retry_policy: RetryPolicy | None = None`
- `start_to_close_timeout / schedule_to_close_timeout / schedule_to_start_timeout / heartbeat_timeout: timedelta | None = None`
- `enable_observability: bool = True`
- `enable_error_wrapping: bool = True`
- `log_inputs: bool = False`
- `log_outputs: bool = False`

**IMPORTANT:** none of these gate activities pass timeouts or retry_policy through
`ActivityConfig` — they pass only `enable_observability=True` (which is already the default).
Timeouts and retry policies are set **by the caller** at `workflow.execute_activity(...)` time
(e.g. base.py:1085 sets `start_to_close_timeout=timedelta(seconds=30)`,
`retry_policy=RETRY_POLICIES["transient"]` for `store_gate_pre_review`). The decorator's own
timeout fields are effectively unused for this group.

Wrapper behavior (activities.py:100-148), executed on every activity call:

1. **Name**: `activity_name = name or func.__name__` (activities.py:103). `name` is not passed
   here, so the registered Temporal activity name = the Python function name exactly. Temporal
   replay keys on this — renaming a function is a breaking change.
2. **Start log** (if `enable_observability`, which is True): `logger.info("Activity %s starting", activity_name, extra={"inputs": args if log_inputs else None})`. `log_inputs=False` here, so `inputs` is always `None`.
3. Runs `result = await func(*args, **kwargs)`.
4. **Complete log**: `logger.info("Activity %s completed", ..., extra={"outputs": result if log_outputs else None})`. `log_outputs=False`, so `outputs` is always `None`.
5. **On any exception** (activities.py:124-146):
   - Logs `logger.error("Activity %s failed: %s", activity_name, error, extra={"error": str(error)})`.
   - If `enable_error_wrapping` (default True, not overridden → True):
     - If `error` is already a `WorkflowError` or `temporalio` `ApplicationError` → `raise` (re-raise unchanged, preserving its `non_retryable` flag).
     - elif `_is_retryable_error(error)` → wrap in `RetryableError(f"Retryable error in {activity_name}: {error}")`.
     - else → wrap in `NonRetryableError(f"Non-retryable error in {activity_name}: {error}")`.
   - `_is_retryable_error` (activities.py:56-76): matches `str(type(error)).lower()` against
     substrings `["timeout","connection","network","temporary","unavailable","overload","busy","throttle","rate_limit"]`. **GOTCHA:** this is a *type-name string match*, NOT an inspection of the exception instance. It is intentionally distinct from `errors.is_retryable_error`. `asyncpg` connection failures typically surface as types like `ConnectionDoesNotExistError` / `CannotConnectNowError` → contain "connection" → wrapped RETRYABLE. A `ValueError` (e.g. bad UUID) → type name `valueerror` matches none → wrapped NON-retryable.

`RetryableError` / `NonRetryableError` are `WorkflowError` subclasses (errors.py:16-34).
`WorkflowError.__init__(message, non_retryable=True)` calls
`ApplicationError.__init__(message, non_retryable=...)`. `RetryableError` → `non_retryable=False`;
`NonRetryableError` → `non_retryable=True` (errors.py:23-34).

**GOTCHA (idempotency + at-least-once):** Temporal may re-run any of these activities. All DB
writes must tolerate re-execution — see per-activity idempotency notes below. The
`create_gate_record` INSERT generates a fresh `uuid.uuid4()` each call, so a retry after a
successful-but-unacknowledged insert would create a **duplicate gate row** (see §4 GOTCHA).

---

## 1. `check_gate_criteria` — gate_operations.py:769

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def check_gate_criteria(input: CheckGateCriteriaInput) -> CheckGateCriteriaResult
```

Pure function — **no DB, no network**. Evaluates whether a gate's submission satisfies criteria.

### Input `CheckGateCriteriaInput` (types.py:986-1012)
```
gate_id: str
gate_type: GateType            # StrEnum, value e.g. "G-DC"
app_id: str
evidence_paths: list[str] = []
evidence_data: dict | None = None
risk_tier: int | None = None
```

### Output `CheckGateCriteriaResult` (types.py:1016-1021)
```
gate_id: str
all_passed: bool
checks: list[dict[str, str | bool]] = []   # each: {"name": str, "passed": bool, "detail": str}
```

### Exact algorithm (reproduce in order — `all_passed` starts True):

**gate_type normalization** (line 800-804): `gate_type_str = input.gate_type.value if isinstance(input.gate_type, GateType) else str(input.gate_type)`. GOTCHA: Temporal may deserialize the enum as a bare string; both paths must yield the string code (e.g. `"G-DC"`).

**Check 1 — evidence_paths_present** (807-814):
- `has_evidence = len(input.evidence_paths) > 0`.
- Append `{"name":"evidence_paths_present","passed":has_evidence,"detail":f"{len(input.evidence_paths)} evidence paths provided"}`.
- If not `has_evidence`: `all_passed = False`.

**Check 2 — required artifacts** (817-828): `required = GATE_REQUIRED_ARTIFACTS.get(gate_type_str, [])`. For **each** `required_suffix` in `required` (in list order):
- `found = any(path.endswith(required_suffix) for path in input.evidence_paths)`.
- Append `{"name":f"artifact_{required_suffix}","passed":found,"detail":f"Required artifact {required_suffix} {'found' if found else 'missing'}"}`.
- If not `found`: `all_passed = False`.

**Check 3 — minimum_artifact_count** (831-839):
- `min_count = len(required) if required else 1`.
- `has_minimum = len(input.evidence_paths) >= min_count`.
- Append `{"name":"minimum_artifact_count","passed":has_minimum,"detail":f"Expected >= {min_count} artifacts, got {len(input.evidence_paths)}"}`.
- If not `has_minimum`: `all_passed = False`.

**Check 4 — threshold predicates** (842-914): `thresholds = GATE_THRESHOLDS.get(gate_type_str, [])`. For **each** threshold dict `th` (in list order). `check_name = f"threshold_{th['artifact']}_{th['path']}_{th['op']}"`.
- `artifact = _find_file_artifact(input.evidence_data, th["artifact"])`.
- **If `artifact is None`** (848-862) → append `{"name":check_name,"passed":True,"detail":f"Skipped: {th['description']} — {th['artifact']} content not available in evidence_data (add evidence_data to the check_gate_criteria call to enforce)"}`; **`continue`** (does NOT set all_passed False). GOTCHA: missing evidence content = PASS (skip), preserving back-compat for mocked-test callers and pre-F3 submissions.
- Else `content_raw = artifact.get("content") or ""`; try `doc = json.loads(content_raw)`.
  - **On `json.JSONDecodeError | TypeError`** (866-876) → append `{passed:False, detail:f"{th['description']} — could not parse {th['artifact']} as JSON"}`; `all_passed=False`; `continue`.
- `observed = _get_json_path(doc, th["path"])`.
  - **If `observed is None`** (878-888) → append `{passed:False, detail:f"{th['description']} — field {th['path']} missing in {th['artifact']}"}`; `all_passed=False`; `continue`.
- `threshold_value = _resolve_threshold(th["threshold"], input.risk_tier)`.
  - **If `threshold_value is None`** (892-902) → append `{passed:True, detail:f"Skipped: {th['description']} — no threshold configured for risk_tier={input.risk_tier!r}"}`; `continue` (NOT a fail). Happens only for a tier-scoped dict lacking both the tier and `"default"`.
- `passed = _evaluate_threshold(observed, th["op"], threshold_value)` (903).
- Append `{"name":check_name,"passed":passed,"detail":f"{th['description']} — observed {observed!r} {th['op']} {threshold_value!r}: {'pass' if passed else 'fail'}"}`.
- If not `passed`: `all_passed = False`.

**Final** (916-932): `logger.info("Gate criteria check completed", extra={gate_id, gate_type, app_id, all_passed, checks_count, threshold_checks})`. Return `CheckGateCriteriaResult(gate_id=input.gate_id, all_passed=all_passed, checks=checks)`.

### Helper `_find_file_artifact(evidence_data, suffix)` (712-727)
- If `evidence_data` falsy → return None.
- `steps = evidence_data.get("steps") or {}`. For each `step_def` in `steps.values()`: for each `art` in `step_def.get("file_artifacts") or []`: `path = art.get("path") or ""`; if `path.endswith(suffix)` → return `art` (first match wins across all steps, dict iteration order). GOTCHA: matches by *suffix* on the path, so `parity-report.json` matches `foo/bar/parity-report.json`.

### Helper `_get_json_path(doc, path)` (730-742)
Walks dotted path (e.g. `"sast.critical"`). `cur = doc`; for each segment in `path.split(".")`: if `cur` not a dict → return None; `cur = cur.get(segment)`; if `cur is None` → return None. Returns `cur`. GOTCHA: a legitimately-`None`/absent value is indistinguishable → treated as "field missing" (fail).

### Helper `_resolve_threshold(value, risk_tier)` (699-709)
- If `value` not a dict → return `value` (plain number/bool).
- If `risk_tier is not None and risk_tier in value` → return `value[risk_tier]`.
- Else → `value.get("default")` (may be None). GOTCHA: dict keys are **ints** (1/2/3), not strings; a string risk_tier would never match a tier and fall to `"default"`.

### Helper `_evaluate_threshold(observed, op, threshold)` (745-766)
`try:` returns `observed >= threshold` for `">="`, `>` for `">"`, `<=`, `<`, `==`, `!=` accordingly. `except TypeError: return False`. Unknown op → `return False` (defensive). GOTCHA: type mismatch (e.g. comparing str to float with `>=`) returns **False** (recorded as failed check), never raises.

### GATE_REQUIRED_ARTIFACTS table (gate_operations.py:51-116)
Keyed by gate code string. Reproduce EXACTLY:
- `G-DC`: `catalog.json, structural-analysis.json, business-logic.json, quality-risk.json, ux-accessibility.json, synthesis.json`
- `G-RR`: `redundancy-matrix.json, ux-overlap-matrix.json, integration-graph.json, portfolio-redundancy-matrix.json, shared-identity-report.json`
- `G-DA`: `disposition-recommendation.json, disposition-governance.json`
- `G-02`: `cloud-pattern-selection.json, ea-compliance.json, integration-architecture.json, security-architecture.json, design-system.json, architecture-blueprint.json`
- `G-DT`: `data-domains.json, shared-db-analysis.json, decomposition-strategy.json, data-product-design.json`
- `G-04a`: `business-rules.yaml, test-scenarios.yaml, cross-validation-report.json`
- `G-04b`: `module-map.yaml, openapi.yaml, data-model.yaml`
- `G-04c`: `gate-review-package.json`
- `G-V1`: `parity-report.json`
- `G-V2`: `security-compliance.json, accessibility-audit.json`
- `G-V3`: `safety-case.json`
- `G-DP-1`: `parallel-run-report.json, adoption-verification.json`
- `G-DP-2`: `decommission-certificate.json, cost-savings-certification.json`

GOTCHA: **`G-DE-1` and `G-DE-2` are intentionally OMITTED** from GATE_REQUIRED_ARTIFACTS (comment 44-50) — DispositionWorkflow's per-disposition step sequences vary; the `minimum_artifact_count` check (min 1) catches empty submissions. Also **G-NEW-1/2/3** (Build line gates, present in the GateType enum) have NO entry → `required=[]` → only min-1 check applies. So Check-2 produces zero rows for these gates.

### GATE_THRESHOLDS table (gate_operations.py:139-696)
Keyed by gate code. Each entry is a list of dicts `{artifact, path, op, threshold, description}`.
Tier-scoped thresholds are dicts keyed by int tier + `"default"`. Reproduce all entries EXACTLY (verbatim from source):

- **G-V1**: (`parity-report.json`,`parity_pct`,`>=`,`{1:0.995,2:0.99,3:0.99,"default":0.99}`); (`parity-report.json`,`failed`,`==`,`0`).
- **G-V2**: (`security-compliance.json`,`sast.critical`,`==`,`0`); (`security-compliance.json`,`dast.critical`,`==`,`0`); (`accessibility-audit.json`,`critical`,`==`,`0`).
- **G-V3**: (`safety-case.json`,`traceability.forward_coverage`,`>=`,`0.99`); (`safety-case.json`,`traceability.backward_coverage`,`>=`,`0.99`); (`safety-case.json`,`iv_and_v.sign_off`,`==`,`True`).
- **G-DP-1**: (`adoption-verification.json`,`active_user_ratio`,`>=`,`0.80`); (`adoption-verification.json`,`training_completion`,`>=`,`0.70`); (`adoption-verification.json`,`unresolved_critical_issues`,`==`,`0`).
- **G-DP-2**: (`decommission-certificate.json`,`rollback_window_expired`,`==`,`True`); (`decommission-certificate.json`,`data_archival_complete`,`==`,`True`).
- **G-04a**: (`traceability.json`,`forward_coverage`,`>=`,`{1:0.99,2:0.98,3:0.98,"default":0.98}`); (`traceability.json`,`backward_coverage`,`>=`,`{1:0.99,2:0.98,3:0.98,"default":0.98}`).
- **G-DC**: (`synthesis.json`,`module_coverage_pct`,`>=`,`0.95`); (`synthesis.json`,`analysis_passes_complete`,`>=`,`4`); (`synthesis.json`,`dependency_graph_generated`,`==`,`True`); (`synthesis.json`,`tco_baseline_established`,`==`,`True`).
- **G-RR**: (`redundancy-matrix.json`,`matrix_generated`,`==`,`True`); (`redundancy-matrix.json`,`ux_overlap_matrix_complete`,`==`,`True`); (`redundancy-matrix.json`,`consolidation_report_produced`,`==`,`True`).
- **G-DA**: (`disposition-governance.json`,`evidence_traceability_pct`,`>=`,`1.0`); (`disposition-governance.json`,`cost_analysis_complete_pct`,`>=`,`1.0`); (`disposition-governance.json`,`logical_contradictions`,`==`,`0`); (`user-impact-analysis.json`,`user_impact_assessment_complete`,`==`,`True`).
- **G-02**: (`ea-compliance.json`,`block_findings_resolved`,`==`,`True`); (`security-architecture.json`,`security_controls_mapped`,`==`,`True`); (`integration-architecture.json`,`external_interfaces_preserved`,`==`,`True`); (`architecture-blueprint.json`,`user_journeys_preserved`,`==`,`True`).
- **G-DT**: (`data-domains.json`,`domain_ownership_complete`,`==`,`True`); (`shared-db-analysis.json`,`singular_write_ownership`,`==`,`True`); (`decomposition-strategy.json`,`decomposition_validated`,`==`,`True`); (`decomposition-strategy.json`,`co_wave_constraints_generated`,`==`,`True`).
- **G-04b**: (`design-review.json`,`forward_coverage`,`>=`,`{1:0.99,2:0.98,3:0.98,"default":0.98}`); (`design-review.json`,`bounded_contexts_defined`,`==`,`True`); (`design-review.json`,`openapi_valid`,`==`,`True`); (`design-review.json`,`ddd_elements_present`,`==`,`True`); (`design-review.json`,`critical_508_violations`,`==`,`0`); (`design-review.json`,`journey_preservation_pct`,`>=`,`1.0`).
- **G-04c**: (`gate-review-package.json`,`test_coverage`,`>=`,`{1:0.90,2:0.80,3:0.80,"default":0.80}`); (`gate-review-package.json`,`tests_passed_pct`,`>=`,`1.0`); (`gate-review-package.json`,`critical_508_violations`,`==`,`0`); (`gate-review-package.json`,`critical_security_vulnerabilities`,`==`,`0`); (`gate-review-package.json`,`backward_coverage`,`>=`,`{1:0.99,2:0.98,3:0.98,"default":0.98}`).
- **G-DE-1**: all path-prefixed under `g_de1_readiness.` in `disposition-output.json`, all `==True`: `g_de1_readiness.stakeholder_sign_off`, `g_de1_readiness.user_transition_addressed`, `g_de1_readiness.data_archival_defined`, `g_de1_readiness.rollback_documented`. GOTCHA (comment 594-600): under the W19 contract (2026-05-03) the artifact moved from `disposition-plan.json` → `disposition-output.json` and paths gained the `g_de1_readiness.` prefix; readiness key names preserved for back-compat.
- **G-DE-2**: `decommission-certificate.json`, all `==True`: `data_archived`, `reconstruction_capability`, `consumers_migrated`, `user_transition_complete`, `rollback_period_defined`, `security_decommission_docs_prepared`.

GOTCHA: `G-04a` threshold references `traceability.json`, but GATE_REQUIRED_ARTIFACTS["G-04a"] does NOT list `traceability.json` — so the threshold is only enforced when a caller supplies `evidence_data` containing that artifact; otherwise it *skips* (present-but-not-required). Same pattern for `G-04b`/`G-04c`/`G-DC`/`G-RR`/`G-DA`/`G-02`/`G-DT` (threshold artifacts like `design-review.json`, `synthesis.json`, `disposition-governance.json`, `user-impact-analysis.json` are threshold-only, not in the required list).

### Errors / retries / idempotency
- No exceptions raised in the happy path; all bad-data cases become failed/skipped `checks` entries. Only programming errors (impossible here) would bubble to the decorator.
- Docstring (794): intended retry policy is **validation_failure (no retry — fix & resubmit)**, set by the caller.
- Idempotent: pure, deterministic given identical input.

---

## 2. `submit_gate_evidence` — gate_operations.py:935

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def submit_gate_evidence(input: SubmitGateEvidenceInput) -> SubmitGateEvidenceResult
```

### Input `SubmitGateEvidenceInput` (types.py:1025-1033)
```
gate_id: str
gate_type: GateType
app_id: str
artifact_paths: list[str] = []
pr_url: str = ""
evidence_data: dict | None = None
```

### Output `SubmitGateEvidenceResult` (types.py:1037-1042)
```
gate_id: str
evidence_package_url: str
pr_url: str
```

### Behavior
1. `evidence_url = input.pr_url if input.pr_url else f"evidence/{input.gate_id}"` (line 952). GOTCHA: falls back to a relative `evidence/{gate_id}` string when no PR URL — this is stored as-is.
2. **Conditional DB write** (955-970): only if `input.evidence_data` is truthy. Opens `asyncpg.connect(_db_url())`; executes:
   ```sql
   UPDATE gate
   SET evidence_data = $1::jsonb, evidence_package_url = $2
   WHERE id = $3::uuid
   ```
   - `$1 = json.dumps(input.evidence_data)` (whole dict serialized, **replaces** the column — NOT a merge; contrast §10 which merges).
   - `$2 = evidence_url`.
   - `$3 = uuid.UUID(input.gate_id)`.
   - `finally: await conn.close()`.
   - If `evidence_data` is None/empty → **no DB write at all** (only builds URL + logs).
3. `logger.info("Gate evidence submitted", extra={gate_id, gate_type(normalized via .value/str), app_id, artifact_count=len(artifact_paths), pr_url, has_evidence_data=(evidence_data is not None)})` (972-986).
4. Return `SubmitGateEvidenceResult(gate_id=input.gate_id, evidence_package_url=evidence_url, pr_url=input.pr_url)`.

### Errors / retries / idempotency
- Docstring (949): intended **transient retry policy (HTTP_RETRY_POLICY)**, set by caller.
- `uuid.UUID(input.gate_id)` raises `ValueError` on malformed gate_id → decorator wraps NON-retryable.
- asyncpg connection errors → type-name contains "connection" → wrapped RETRYABLE.
- Idempotent: full-column overwrite; re-running with same input yields same row state.

---

## 3. `wait_for_gate_decision` — gate_operations.py:995

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def wait_for_gate_decision(input: WaitForGateDecisionInput) -> GateDecisionResult
```

### Input `WaitForGateDecisionInput` (types.py:1079-1085)
```
gate_id: str
gate_type: GateType
app_id: str
sla_timeout_seconds: int = 172800   # 48h
```

### Output `GateDecisionResult` (types.py:1144-1151)
```
gate_id: str
status: GateStatus
decided_by: str = ""
decided_at: str = ""
feedback: str = ""
```

### Behavior
- **Does NOT wait.** The name is misleading: the actual wait is done in the workflow via `gate_approved`/`gate_rejected` signals (docstring 998-1000). This activity only logs and returns a PENDING marker.
- `logger.info("Gate decision pending", extra={gate_id, gate_type(normalized), app_id, sla_timeout_seconds})` (1011-1023).
- Returns `GateDecisionResult(gate_id=input.gate_id, status=GateStatus.PENDING, decided_by="", decided_at=datetime.now(timezone.utc).isoformat(), feedback="")` (1025-1031).
- GOTCHA: `decided_at` is set to the current UTC ISO timestamp even though nothing was decided — it's really "marked-pending-at".

### Errors / retries / idempotency
- Docstring (1009): intended **timeout policy (max 2 retries, extended timeout on retry)**, set by caller.
- No DB access; fully idempotent (only `decided_at` timestamp differs per call).

---

## 4. `create_gate_record` — gate_operations.py:1044

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def create_gate_record(input: CreateGateRecordInput) -> CreateGateRecordResult
```

Inserts a new `gate` row. Called by workflows after PR creation, before criteria checks, to make the gate visible in the Gate Queue.

### Input `CreateGateRecordInput` (types.py:1046-1061)
```
gate_type: str                    # note: STRING here, not GateType enum
portfolio_id: str
workflow_id: str
app_id: str | None = None
wave_id: str | None = None
evidence_package_url: str = ""
sla_timeout_seconds: int = 172800  # 48h
```

### Output `CreateGateRecordResult` (types.py:1065-1075)
```
gate_id: str        # the generated UUID as str
gate_type: str
app_id: str | None = None
wave_id: str | None = None
```

### Behavior (exactly)
1. **Exactly-one-scope guard** (1060-1064): `if bool(input.app_id) == bool(input.wave_id): raise ValueError("create_gate_record requires exactly one of app_id / wave_id; got app_id=..., wave_id=...")`. GOTCHA: this catches both "both set" and "neither set" (XOR). Raised BEFORE any DB hit so the caller gets a readable error rather than a Postgres CHECK-constraint trace (`gate_application_or_wave_ck`). ValueError → decorator wraps NON-retryable.
2. `gate_id = uuid.uuid4()` (1066). `now = datetime.now(timezone.utc)` (1067). `sla_deadline = now + timedelta(seconds=input.sla_timeout_seconds)` (1068).
3. `app_uuid = uuid.UUID(input.app_id) if input.app_id else None`; `wave_uuid = uuid.UUID(input.wave_id) if input.wave_id else None` (1070-1071).
4. **INSERT** (1080-1096) into `gate`:
   ```sql
   INSERT INTO gate (id, application_id, wave_id, portfolio_id,
                     gate_type, status, workflow_id, requested_at,
                     sla_deadline, evidence_package_url)
   VALUES ($1, $2, $3, $4::uuid, $5, 'preparing', $6, $7, $8, $9)
   ```
   | col | value |
   |---|---|
   | `id` | `gate_id` (uuid.uuid4) |
   | `application_id` | `app_uuid` (or NULL) |
   | `wave_id` | `wave_uuid` (or NULL) |
   | `portfolio_id` | `uuid.UUID(input.portfolio_id)` (cast `$4::uuid`) |
   | `gate_type` | `input.gate_type` (raw string; maps to `gate_type_enum`) |
   | `status` | literal `'preparing'` |
   | `workflow_id` | `input.workflow_id` |
   | `requested_at` | `now` |
   | `sla_deadline` | `sla_deadline` |
   | `evidence_package_url` | `input.evidence_package_url` |
   - Columns NOT set (rely on DB defaults / NULL): `decided_at` (NULL), `decided_by` (NULL), `justification` (NULL), `retry_count` (default 0), `evidence_data` (NULL), `merge_failure_detail` (NULL).
   - GOTCHA (status='preparing'): the gate is inserted **hidden** from the reviewer queue. `mark_gate_ready_for_review` (§6) flips it to `'pending'` after AI pre-review finishes. Queue filters `status='pending'`, preventing the race of a human opening a gate mid-pre-review (comment 1073-1077).
5. `finally: await conn.close()`.
6. `logger.info("Gate record created (preparing)", extra={gate_id=str, gate_type, app_id, wave_id, workflow_id})`.
7. Return `CreateGateRecordResult(gate_id=str(gate_id), gate_type=input.gate_type, app_id=input.app_id, wave_id=input.wave_id)`.

### DB schema reference (`gate` table)
Created in `db/alembic/versions/003_create_workflow_tables.py:62-79`; extended by later migrations:
- `id UUID PK default gen_random_uuid()`, `gate_type gate_type_enum NOT NULL`, `portfolio_id UUID FK portfolio(id) CASCADE NOT NULL`, `application_id UUID FK application(id) CASCADE` (originally NOT NULL; made **nullable** by `042_gate_wave_scoped.py:47`), `status gate_status_enum NOT NULL default 'pending'`, `requested_at timestamptz NOT NULL default now()`, `decided_at timestamptz NULL`, `decided_by varchar(255) NULL`, `justification text NULL`, `retry_count int NOT NULL default 0`.
- `011_add_gate_workflow_columns.py`: adds `workflow_id varchar(255) NULL`, `sla_deadline timestamptz NULL`, `evidence_package_url text NULL`.
- `012_add_gate_evidence_data.py`: adds `evidence_data JSONB NULL`.
- `040_add_gate_merge_blocked.py`: adds `merge_failure_detail JSONB NULL` + extends `gate_status_enum` with `merge_blocked`.
- `042_gate_wave_scoped.py`: `application_id`→nullable; adds `wave_id UUID FK wave(id) CASCADE NULL`; adds CHECK `gate_application_or_wave_ck = (application_id IS NOT NULL AND wave_id IS NULL) OR (application_id IS NULL AND wave_id IS NOT NULL)`; index `ix_gate_wave_id`.

### Errors / retries / idempotency
- **GOTCHA (NOT idempotent):** each call mints a fresh `uuid.uuid4()`. A Temporal retry after a committed-but-unacked INSERT creates a **second gate row**. There is no `ON CONFLICT` / dedupe by workflow_id. Callers must account for this (typically the workflow calls it once and treats it as best-effort-once).
- Bad UUID string (`portfolio_id`/`app_id`/`wave_id`) → `ValueError` → NON-retryable.
- Postgres FK violation (unknown portfolio/app/wave) → asyncpg `ForeignKeyViolationError` → type name has no retryable substring → wrapped NON-retryable.

---

## 5. `set_gate_merge_blocked` — gate_operations.py:1119

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def set_gate_merge_blocked(gate_id: str, failure_detail: dict) -> None
```

**Positional args** (not a dataclass input): `gate_id: str`, `failure_detail: dict`. Returns `None`.

W17 / P5-S17.4. Called by every line workflow after its `reconcile_and_merge_pr` activity raises one of the structured merge errors (`MergeConflict` / `MergeBranchProtectionRejected` / `MergeDivergenceUnresolved`) **after Temporal retries exhaust**. (Those merge-error types are raised in the *git/merge* activity module — NOT this group; here they arrive only as a `failure_detail` dict payload.)

### Behavior
1. `detail_dict = dict(failure_detail) if failure_detail else {}` (1141). GOTCHA: Temporal's payload converter may hand a dict-like proxy; `dict(...)` normalizes so `json.dumps` works. Falsy/empty → `{}`.
2. **UPDATE** (1145-1153):
   ```sql
   UPDATE gate
   SET status = 'merge_blocked', merge_failure_detail = $1::jsonb
   WHERE id = $2::uuid
   ```
   - `$1 = json.dumps(detail_dict)`, `$2 = uuid.UUID(gate_id)`.
   - **Preserves** `decided_at` / `decided_by` (reviewer's approval intact) — only `status` and `merge_failure_detail` change (comment 1132-1134).
   - No WHERE guard on current status → applies regardless of current state.
3. `finally: await conn.close()`.
4. `logger.info("Gate transitioned to merge_blocked", extra={gate_id, failure_type=detail_dict.get("failure_type"), reason=detail_dict.get("reason")})`.

### Errors / retries / idempotency
- **Idempotent** (docstring 1137-1138): re-running overwrites `merge_failure_detail` with the latest payload, matching at-least-once semantics.
- Bad `gate_id` → ValueError → NON-retryable.

---

## 6. `mark_gate_ready_for_review` — gate_operations.py:1168

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def mark_gate_ready_for_review(gate_id: str) -> None
```

Positional arg `gate_id: str`. Returns `None`. Flips `'preparing'` → `'pending'`, making the gate visible in the queue. Called *after* AI pre-review finishes (success OR failure).

### Behavior
1. **UPDATE** (1181-1188):
   ```sql
   UPDATE gate
   SET status = 'pending'
   WHERE id = $1::uuid AND status = 'preparing'
   ```
   - `$1 = uuid.UUID(gate_id)`.
   - GOTCHA: the `AND status = 'preparing'` guard makes it a **no-op** if the gate has already advanced (approved/rejected/escalated/merge_blocked). This is the idempotency mechanism.
2. `finally: await conn.close()`.
3. `logger.info("Gate marked ready for review", extra={gate_id})`.

### Caller context (base.py:1094-1101)
Called in the `finally` of `_run_gate_pre_review`, guarded by `workflow.patched("mark-gate-ready-for-review-v1")`, with `start_to_close_timeout=timedelta(seconds=30)`, `retry_policy=RETRY_POLICIES["transient"]`.

### Errors / retries / idempotency
- Idempotent by construction (status-guarded UPDATE; second call touches 0 rows).
- Bad `gate_id` → ValueError → NON-retryable.

---

## 7. `resolve_parallel_run_seconds` — gate_operations.py:1195

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def resolve_parallel_run_seconds(default_days: int) -> int
```

Positional arg `default_days: int`. Returns `int` (seconds). Resolves the Deployment parallel-run soak duration. **Reads `os.environ` inside an activity** so workflow code stays deterministic (comment 1206-1209).

### Behavior
1. `override = os.environ.get("OLYMPUS_PARALLEL_RUN_OVERRIDE_SECONDS")` (1213).
2. **If `override` truthy**: `try: secs = int(override); if secs >= 0:` → `logger.info("Parallel-run soak overridden for dev/test", extra={override_seconds, default_days})`; `return secs`. GOTCHA: negative override values fall through (the `if secs >= 0` is not satisfied) to the default. `except ValueError:` → `logger.warning("Ignoring non-integer OLYMPUS_PARALLEL_RUN_OVERRIDE_SECONDS", extra={value})` and fall through.
3. **Default**: `return default_days * 86400` (1228).
- GOTCHA: production never sets the override, so it returns real `default_days × 86400` (e.g. 30 days = 2,592,000s). Dev/integration stacks set the env var to collapse a multi-week durable timer so the Deployment line is E2E-drivable (comment 1204-1211).

### Errors / retries / idempotency
- No DB. Idempotent given fixed env. Non-integer/negative override is handled gracefully (never raises).

---

## 8. `update_application_status` — gate_operations.py:1231

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def update_application_status(input: UpdateAppStatusInput) -> None
```

### Input `UpdateAppStatusInput` (types.py:1155-1161)
```
app_id: str
status: str
current_step: str = ""
current_line: str = ""
```
Returns `None`.

### Behavior
1. **UPDATE** (1242-1254) on `application`:
   ```sql
   UPDATE application
   SET current_status = $1, current_step = $2, current_line = $3, updated_at = $4
   WHERE id = $5::uuid
   ```
   | col | value |
   |---|---|
   | `current_status` | `input.status` |
   | `current_step` | `input.current_step` |
   | `current_line` | `input.current_line` |
   | `updated_at` | `datetime.now(timezone.utc)` |
   | (WHERE) `id` | `uuid.UUID(input.app_id)` |
2. `finally: await conn.close()`.
3. `logger.info("Application status updated", extra={app_id, status, current_step})`.
- GOTCHA: unconditionally writes `current_step`/`current_line` even when the caller left them `""` — will overwrite prior non-empty values with empty strings if the caller doesn't populate them.

### Errors / retries / idempotency
- Idempotent (last-writer-wins full overwrite of those 4 columns). Bad `app_id` → ValueError → NON-retryable.

---

## 9. `fetch_gate_capability_lineage_rework` — gate_operations.py:1268

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def fetch_gate_capability_lineage_rework(
    input: FetchGateCapabilityLineageReworkInput,
) -> FetchGateCapabilityLineageReworkResult
```

Phase 5 PR #4. **Read-only** — SELECTs `gate.evidence_data.review.capability_lineage_rework` and marshals it into a typed result. Consumed by `wave_rationalization.py` on G-DA rework so the next disposition-recommender dispatch gets structured row overrides (not just free-text). Written by the gate-decision API endpoint (`gate.py` `_persist_capability_lineage_rework_block`).

GOTCHA (registration): exported from `activities/__init__.py` and used by `workflows/wave_rationalization.py`, but is NOT in the worker's explicit import list at `worker.py:88-95`. Verify it is registered on the worker (via `activities/__init__.py` re-export) before rebuild — a missing registration would make the wave_rationalization G-DA rework activity fail at dispatch.

### Input `FetchGateCapabilityLineageReworkInput` (types.py:1089-1101)
```
gate_id: str
```

### Output `FetchGateCapabilityLineageReworkResult` (types.py:1125-1140)
```
gate_id: str
ratified_count: int = 0
rejected_count: int = 0
rejected_rows: list[CapabilityLineageRowRework] = []
```
`CapabilityLineageRowRework` (types.py:1105-1121): `lineage_id: str, feedback: str, source_capability|target_capability|source_system|target_system|relationship: str|None = None`.

### Behavior (every failure path returns the EMPTY result — never blocks a rework iteration)
1. `try: gate_uuid = uuid.UUID(input.gate_id) except (ValueError, TypeError): return FetchGateCapabilityLineageReworkResult(gate_id=input.gate_id)` (1290-1296). GOTCHA: malformed gate_id → empty result (NOT an exception), so rework falls back to free-text-only feedback.
2. `SELECT evidence_data FROM gate WHERE id = $1::uuid` (1300-1303); `finally close`.
3. `if row is None:` → log "gate not found", return empty (1307-1312).
4. `raw = row["evidence_data"]`. If `raw is None` → return empty (1314-1316).
5. **JSONB shape handling** (1317-1329): if `isinstance(raw, str)` → `json.loads`, on `JSONDecodeError|TypeError` return empty; elif `isinstance(raw, dict)` → use as-is; else return empty. GOTCHA: asyncpg returns JSONB as dict OR JSON-string depending on codec — both handled.
6. `review = evidence.get("review") if isinstance(evidence, dict) else None`; if not a dict → return empty (1331-1333).
7. `block = review.get("capability_lineage_rework")`; if not a dict → return empty (1335-1337).
8. `rejected_rows_raw = block.get("rejected_rows") or []`; if not a list → `[]` (1339-1341).
9. For each `entry` in `rejected_rows_raw` (1344-1363):
   - Skip if not a dict.
   - `lineage_id = entry.get("lineage_id")`, `feedback = entry.get("feedback")`.
   - Skip if `lineage_id` not str OR `feedback` not str.
   - Skip if `not feedback.strip()` (empty/whitespace feedback dropped).
   - Append `CapabilityLineageRowRework(lineage_id, feedback, source_capability=_safe_str(entry.get("source_capability")), target_capability=_safe_str(...), source_system=_safe_str(...), target_system=_safe_str(...), relationship=_safe_str(...))`.
10. `ratified_count = block.get("ratified_count") or 0`; `rejected_count = block.get("rejected_count") or 0`; coerce non-int → 0 (1365-1370).
11. `logger.info("fetch_gate_capability_lineage_rework", extra={gate_id, ratified_count, rejected_count, rejected_rows=len(rejected_rows)})`.
12. Return the populated result.

`_safe_str(value)` (1390-1394): returns `value` if it's a non-empty str, else None.

### Errors / retries / idempotency
- Read-only, fully idempotent. Every corruption path degrades to the empty result — the docstring explicitly wants "a transient corruption never blocks a rework iteration" (1288-1289). Only a genuine asyncpg connection failure would escape → decorator wraps RETRYABLE.

---

## 10. `store_gate_pre_review` — gate_pre_review.py:144

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def store_gate_pre_review(input: StoreGatePreReviewInput) -> StoreGatePreReviewResult
```

Parses the gate-pre-review **skill's markdown output** and merges the extracted recommendation into `gate.evidence_data.ai_recommendation` via an atomic JSONB `||` merge. This makes the AI recommendation available to the dashboard without a schema migration.

### Agent-dispatch context (the dispatch happens in the WORKFLOW, not this activity)
This activity does NOT dispatch the agent — it only stores the parsed output. The dispatch is in `workflows/base.py:1048-1087` (`_run_gate_pre_review`):
- Skill selection: `skill_id="gate-pre-review"`, `task_type="gate-pre-review"` (base.py:1052-1054).
- Inputs/context assembly: `AgentTaskInput(skill_id, app_id=self._app_id, task_type, input_artifacts=evidence_paths, artifact_repo, artifact_ref, context={"gate_id", "gate_type"}, execution_context=self._execution_ctx("ai-pre-review-{gate}", gate_id, input_artifact_paths=evidence_paths))` (1051-1067).
- GOTCHA (base.py:1039-1046): `artifact_repo`+`artifact_ref` MUST be passed or the agent-side `_fetch_input_artifacts` gate (which requires non-empty `artifact_repo`) silently no-ops → skill runs with `input_artifacts_dir=""` → report complains of missing context. Callers default "" for back-compat but real dispatchers pass the active branch.
- Output: `agent_markdown = pre_review_result.output_artifacts[0] if output_artifacts else ""`; `if not agent_markdown: raise ValueError("Gate pre-review produced no output")` (1072-1078).
- Then dispatches `store_gate_pre_review` with `start_to_close_timeout=timedelta(seconds=30)`, `retry_policy=RETRY_POLICIES["transient"]` (1079-1087).
- **Best-effort**: the entire block is wrapped in `try/except Exception` that only warns and continues — a pre-review failure is NEVER fatal to the workflow (1088-1093). No retry-with-feedback loop here (that pattern belongs to the per-step dispatch, not pre-review).

### Input `StoreGatePreReviewInput` (types.py:2870-2874)
```
gate_id: str
agent_output: str    # Raw markdown from gate-pre-review skill
```

### Output `StoreGatePreReviewResult` (types.py:2877-2884)
```
gate_id: str
stored: bool = False
recommendation: str = ""     # "APPROVE" | "REVIEW THOROUGHLY" | "LIKELY REJECT"
confidence_score: int = 0
```

### `_parse_pre_review(markdown)` — gate_pre_review.py:34-141 (reproduce EXACTLY)
Returns a `result` dict seeded (46-53):
```
{"confidence_score":0,"recommendation":"","summary":"","full_markdown":markdown,"score_breakdown":{},"flags":[]}
```

**Confidence score** (60-72): try patterns in order, first match with `0 <= val <= 100` wins (then `break`):
1. `r"[Cc]onfidence[^:]*:\s*\*{0,2}\s*(\d+)\s*/?\s*100\s*\*{0,2}"`
2. `r"(\d+)\s*/\s*100"`
3. `r"(\d+)\s+(?:out\s+)?of\s+100"`
4. `r"[Cc]onfidence[^.]*?(\d{1,3})(?:\s|$|\.|\*)"`
Each: `val = int(match.group(1))`; if `0 <= val <= 100` → `result["confidence_score"] = val; break`.

**Recommendation** (76-82): `re.search(r"(APPROVE|REVIEW\s+THOROUGHLY|LIKELY\s+REJECT)", markdown, re.IGNORECASE)`. If matched: `result["recommendation"] = match.group(1).upper()` then `re.sub(r"\s+", " ", ...)` (collapse whitespace).

**Summary** — two attempts:
- (86-93) If `recommendation` set: `re.search(r"(?:APPROVE|REVIEW\s+THOROUGHLY|LIKELY\s+REJECT).*?\n\n(.+?)(?:\n\n|\n#)", markdown, re.DOTALL|re.IGNORECASE)` → `summary = group(1).strip()`.
- (96-112) If still empty: `re.search(r"##\s*Recommendation\s*\n+(.+?)(?:\n\n|\n##)", ...)`; split into lines; drop lines matching `r"APPROVE|REJECT|THOROUGHLY|Confidence|\d+/100"` (IGNORECASE); join remaining stripped non-empty lines with spaces.

**Score breakdown** (116-129): `re.findall(r"\|\s*([^|]+?)\s*\|\s*(\d+)\s*\|\s*([^|]+?)\s*\|", markdown)` — table rows `| Dimension | Score | third |`. For each `(dim_name, score, third_col)`: `dim_key = dim_name.strip().lower().replace(" ","_").replace("&","and")`; skip if empty or in `("dimension","---","--------")`; `try: weight = float(third_col.strip()) except ValueError: weight = 0.0`; `result["score_breakdown"][dim_key] = {"score": int(score), "weight": weight}`. GOTCHA: the third column is either a numeric Weight or a "Notes" column — non-numeric → weight 0.0.

**Flags** (133-139): `re.findall(r"[-*]\s*\*{0,2}(BLOCKER|WARNING|INFO(?:RMATIONAL)?|CRITICAL|NOTE)\*{0,2}[:\s—–-]*(.+?)(?:\n|$)", markdown, re.IGNORECASE)`. For each `(severity, description)`: append `f"{severity.upper()}: {description.strip()}"`.

### `store_gate_pre_review` behavior
1. `parsed = _parse_pre_review(input.agent_output)` (159).
2. **If `not parsed["recommendation"]`** (161-188) — parser found no recommendation level:
   - `preview = input.agent_output[:500] if input.agent_output else "(empty)"`; `logger.warning("Could not parse recommendation ... Output preview: %s", gate_id, preview)`.
   - **If `input.agent_output.strip()`** truthy (there IS content, just unparseable):
     - `parsed["recommendation"] = "REVIEW THOROUGHLY"` (safe fallback).
     - `parsed["confidence_score"] = parsed.get("confidence_score") or 50`.
     - If `not parsed["summary"]`: iterate `agent_output.split("\n")`, take first stripped line that is non-empty and does not start with `#` or `|`, set `parsed["summary"] = stripped[:200]`, break.
     - `logger.info("Falling back to REVIEW THOROUGHLY ...", gate_id)`.
   - **Else** (empty/whitespace output): `return StoreGatePreReviewResult(gate_id=input.gate_id, stored=False)` — **no DB write**, `stored=False`.
3. `ai_rec_json = json.dumps({"ai_recommendation": parsed})` (190). Note: `parsed` includes `full_markdown` (the entire input markdown), so the whole report is embedded.
4. **UPDATE — atomic JSONB merge** (194-202):
   ```sql
   UPDATE gate
   SET evidence_data = COALESCE(evidence_data, '{}'::jsonb) || $1::jsonb
   WHERE id = $2
   ```
   - `$1 = ai_rec_json`, `$2 = input.gate_id`.
   - GOTCHA: uses `||` merge (top-level key merge), so existing `evidence_data` keys are preserved; only `ai_recommendation` is added/replaced. Contrast `submit_gate_evidence` (§2) which fully **replaces** the column.
   - GOTCHA: `$2` is the **raw string** `input.gate_id` with **no `::uuid` cast** (unlike every other write in this group). asyncpg binds it against the UUID PK column — Postgres implicitly casts a text literal to uuid, but if the driver sends it as text with a param type that doesn't match, this relies on server-side coercion. All other activities here explicitly cast `$N::uuid`.
5. `finally: await conn.close()`.
6. `logger.info("Stored gate pre-review recommendation", extra={gate_id, recommendation, confidence_score})`.
7. Return `StoreGatePreReviewResult(gate_id=input.gate_id, stored=True, recommendation=parsed["recommendation"], confidence_score=parsed["confidence_score"])`.

### Errors / retries / idempotency
- Caller sets `retry_policy=RETRY_POLICIES["transient"]`, `start_to_close_timeout=30s` (base.py:1085-1086).
- **Idempotent**: the `||` merge overwrites `ai_recommendation` deterministically for identical input.
- Bad `gate_id` (non-uuid text) → Postgres cast error surfaces as an asyncpg error → decorator wraps (type-name dependent; likely NON-retryable).
- Empty agent output → clean `stored=False` return, no exception.

---

## Appendix: `_db_url()` (gate_operations.py:1034-1041 AND gate_pre_review.py:24-31 — identical copies)
Builds DSN from env with defaults: `DATABASE_HOST=localhost`, `DATABASE_PORT=5432`, `DATABASE_USER=olympus`, `DATABASE_PASSWORD=olympus`, `DATABASE_NAME=olympus` → `postgresql://{user}:{password}@{host}:{port}/{db}`. GOTCHA: defined separately in each file (not shared); keep both in sync on rebuild. All DB-touching activities open a **fresh `asyncpg.connect` per call** and close in `finally` — no pooling.
