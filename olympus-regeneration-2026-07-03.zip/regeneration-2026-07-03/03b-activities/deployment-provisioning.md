# Activity Group: Deployment / Provisioning (line_transitions)

Atomic regeneration spec for three activity modules under
`temporal/olympus_workflows/activities/line_transitions/`:

- `target_provisioning.py` — `create_target_app_and_repo`, `terminate_source_app_workflows`
- `target_realization.py` — `realize_target_state_grain`
- `deployment.py` — `persist_deployment_side_effects`

These were split out of an original monolithic `line_transitions` module in
P7-S16.14; behavior is unchanged and the names are re-exported through the
package facade so `olympus_workflows.activities.line_transitions.<name>`
still resolves (`target_provisioning.py:1-6`, `target_realization.py:1-6`,
`deployment.py:1-6`).

**Activity functions captured (4):** `create_target_app_and_repo`,
`terminate_source_app_workflows`, `realize_target_state_grain`,
`persist_deployment_side_effects`. All private helpers that support them are
documented in full because the data-layer transformations depend on them.

---

## 0. What `@foundry_activity` adds over raw `@activity.defn`

Every activity here is decorated
`@foundry_activity(config=ActivityConfig(enable_observability=True))`
(`target_provisioning.py:373,1139`; `target_realization.py:534`;
`deployment.py:218`). The decorator is defined at
`temporal/olympus_workflows/temporal_base/activities.py:79-150`.

`ActivityConfig` dataclass fields and defaults
(`temporal_base/activities.py:41-53`):

| field | default |
|---|---|
| `retry_policy: RetryPolicy \| None` | `None` |
| `start_to_close_timeout: timedelta \| None` | `None` |
| `schedule_to_close_timeout: timedelta \| None` | `None` |
| `schedule_to_start_timeout: timedelta \| None` | `None` |
| `heartbeat_timeout: timedelta \| None` | `None` |
| `enable_observability: bool` | `True` |
| `enable_error_wrapping: bool` | `True` |
| `log_inputs: bool` | `False` |
| `log_outputs: bool` | `False` |

**Note:** none of the four activities pass any timeout, retry_policy, or
heartbeat config — they pass ONLY `enable_observability=True`. So no
heartbeat is emitted, and no per-activity retry policy or timeout is baked
into the definition; timeouts/retries come entirely from the calling
workflow's `execute_activity(...)` options. `ActivityConfig`'s timeout /
retry_policy / heartbeat fields are **declared but never consumed** by the
decorator body — the decorator only reads `enable_observability`,
`enable_error_wrapping`, `log_inputs`, `log_outputs`
(`temporal_base/activities.py:97-146`).

Decorator wrapping behavior (`temporal_base/activities.py:97-148`):

1. `activity_config = config or ActivityConfig()` (line 98).
2. The inner `wrapper` is decorated `@activity.defn(name=name, **activity_kwargs)`
   then `@wraps(func)` (lines 100-101). **GOTCHA:** the activity *name*
   defaults to the wrapped function's `__name__` (line 103,
   `activity_name = name or func.__name__`); Temporal replay keys on this
   name, so renaming a function silently breaks replay of in-flight
   workflows (`temporal_base/activities.py:14-16`).
3. On entry, if `enable_observability`: `logger.info("Activity %s starting", ...)`
   with `extra={"inputs": args if log_inputs else None}` (lines 105-110).
   `log_inputs` is False here → inputs not logged.
4. `result = await func(*args, **kwargs)` (line 113). On success and
   `enable_observability`: `logger.info("Activity %s completed", ...)` with
   `extra={"outputs": result if log_outputs else None}` (lines 115-120).
5. **Error wrapping** (lines 124-146). Any exception:
   - if `enable_observability`: `logger.error("Activity %s failed: %s", ...)`
     (lines 125-131).
   - if `enable_error_wrapping` (True by default):
     - `isinstance(error, (WorkflowError, ApplicationError))` → `raise`
       unchanged (lines 135-136). `NonRetryableError` and `RetryableError`
       are `WorkflowError` subclasses (`errors.py:16-34`) so they pass
       through with their `non_retryable` flag intact.
     - else if `_is_retryable_error(error)` → wrap in
       `RetryableError(f"Retryable error in {activity_name}: {error}")`
       (lines 137-140).
     - else → wrap in
       `NonRetryableError(f"Non-retryable error in {activity_name}: {error}")`
       (lines 141-144).
   - if error-wrapping disabled → bare `raise` (line 146).

`_is_retryable_error` (`temporal_base/activities.py:56-76`): classifies by a
**substring match on `str(type(error)).lower()`** against the patterns
`timeout, connection, network, temporary, unavailable, overload, busy,
throttle, rate_limit`. **GOTCHA:** this keys on the exception *type name
string*, NOT the instance — an `asyncpg.ConnectionDoesNotExistError` matches
`connection` and becomes retryable; a plain `ValueError` matches nothing and
becomes non-retryable. It is deliberately distinct from
`errors.is_retryable_error` (`errors.py:80-85`, which inspects
httpx/OSError/ApplicationError instances).

Error class semantics (`temporal_base/errors.py:16-34`):
`WorkflowError(message, non_retryable=True)` extends `ApplicationError`;
`RetryableError` = `WorkflowError` with `non_retryable=False`;
`NonRetryableError` = `WorkflowError` with `non_retryable=True`.

---

## 1. `create_target_app_and_repo` (`target_provisioning.py:373-971`)

### 1.1 Signature & I/O

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def create_target_app_and_repo(
    input: CreateTargetAppAndRepoInput,
) -> CreateTargetAppAndRepoResult
```

**`CreateTargetAppAndRepoInput`** (`types.py:1979-2036`):

| field | type | default |
|---|---|---|
| `source_app_id` | `str` | (required) |
| `target_app_name` | `str` | (required) |
| `target_repo` | `str` | (required) |
| `wave_id` | `str` | (required) |
| `portfolio_id` | `str` | (required) |
| `disposition` | `str` | (required) |
| `default_branch` | `str` | `"main"` |
| `peer_source_app_ids` | `list[str]` | `[]` |
| `source_app_ids` | `list[str]` | `[]` (v2 full source set) |
| `target_service_id` | `str` | `""` (SF3 catalog id S1..S11/'system') |
| `target_app_slug` | `str` | `""` (decomposition-target discriminator) |

**`CreateTargetAppAndRepoResult`** (`types.py:2039-2055`):

| field | type | default |
|---|---|---|
| `target_app_id` | `str` | (required) |
| `target_repo_url` | `str` | (required) |
| `created_new_app_row` | `bool` | `False` |
| `lineage_rows_inserted` | `int` | `0` |

Called once per non-Retire target by
`WaveRationalizationWorkflow.dispatch_architecture` (`target_provisioning.py:378-382`).

### 1.2 Disposition classification constants

Imported from `target_realization.py`:
- `_TARGET_EQUALS_SOURCE_DISPOSITIONS = frozenset({"Retain","Refactor","Rearchitect","Replatform"})` (`target_realization.py:38-40`)
- `_NEW_TARGET_DISPOSITIONS = frozenset({"Replace","Consolidate"})` (`target_realization.py:43`)

### 1.3 Step-by-step control flow

**A. Parse UUIDs (lines 391-408):**
1. `source_uuid = uuid.UUID(input.source_app_id)`; on `ValueError`/`TypeError`
   → `raise NonRetryableError(f"Invalid source_app_id: {input.source_app_id!r}")` (391-396).
2. `portfolio_uuid = uuid.UUID(input.portfolio_id) if input.portfolio_id else None`;
   on failure → `NonRetryableError(f"Invalid portfolio_id: ...")` (398-403).
3. `wave_uuid = uuid.UUID(input.wave_id) if input.wave_id else None`; on failure
   → set `wave_uuid = None` **silently** (wave_application insert is
   best-effort) (405-408).

**B. Disposition branch selection (lines 410-455):**
- `is_build = (disposition == "Build")` (420).
- `slug = (input.target_app_slug or "").strip()` (433).
- `is_decomposition_target =` all of: `not is_build` AND
  `disposition in _TARGET_EQUALS_SOURCE_DISPOSITIONS` AND `bool(slug)` AND
  `slug != input.source_app_id` (434-439).
- Determine `new_target`:
  - `is_build` → `new_target = False` (440-441).
  - `is_decomposition_target` → `new_target = True` (mint fresh row WITHOUT
    terminating source) (442-446).
  - `disposition in _TARGET_EQUALS_SOURCE_DISPOSITIONS` → `new_target = False` (447-448).
  - `disposition in _NEW_TARGET_DISPOSITIONS` → `new_target = True` (449-450).
  - else → `raise NonRetryableError("...unsupported disposition {disposition!r}")` (451-455).

**GOTCHA (decomposition):** a target-equals-source disposition
(Rearchitect/Refactor/Replatform/Retain) whose `target_app_slug` names a
DISTINCT app (`slug != source_app_id`) mints its OWN new `application` row
(the monolith-to-services 1→N case). Reusing the source id would collapse
every decomposed target onto one id and collide their per-target line
workflows (WORKFLOW_ALREADY_EXISTS) — this is the bug that stranded 18 of 19
targets on the Private Pilot Cert / VBA wave (`target_provisioning.py:421-439`).

**C. Require `target_repo` (lines 465-469):** if falsy →
`raise NonRetryableError("...target_repo is required for disposition {disposition!r} — source {source_app_id!r}")`.
Every dispatched target now requires an operator-supplied repo; source repos
stay frozen as Discovery evidence (`target_provisioning.py:457-469`).

**D. Idempotency probe (lines 477-535)** — opens `asyncpg.connect(_db_url())`,
runs inside try/finally that closes the conn:
- Only when `portfolio_uuid is not None and input.target_repo` (479):
  - if `new_target` (480-505):
    ```sql
    SELECT id, target_repo_url FROM application
    WHERE portfolio_id = $1 AND target_repo_url = $2 LIMIT 1
    ```
    params `(portfolio_uuid, input.target_repo)`. If a row exists → log
    "target already exists" and **return early**:
    `CreateTargetAppAndRepoResult(target_app_id=str(existing["id"]),
    target_repo_url=existing["target_repo_url"] or input.target_repo,
    created_new_app_row=False, lineage_rows_inserted=0)` (500-505).
  - else (target==source, 506-533):
    ```sql
    SELECT target_repo_url FROM application WHERE id = $1
    ```
    param `(source_uuid,)`. If `existing["target_repo_url"] == input.target_repo`
    → log and **return early**:
    `CreateTargetAppAndRepoResult(target_app_id=input.source_app_id,
    target_repo_url=existing["target_repo_url"], created_new_app_row=False,
    lineage_rows_inserted=0)` (528-533).

**E. Provision the repo (lines 542-601):**
- Try to import `GitService`/`GitServiceConfig`: first
  `from src.git_service import ...`; on ImportError fall back to
  `from olympus_api.services.git_service import ...`; on second ImportError
  set both to `None` (545-558).
- `token = os.environ.get("GITHUB_TOKEN", "")`;
  `base_url = os.environ.get("GITHUB_BASE_URL", "https://api.github.com")` (560-561).
- If GitService present AND config present AND `token` truthy (562):
  - build `cfg = GitServiceConfig(token=token, repo=input.target_repo, base_url=base_url)` (563-567).
  - build README string (568-575):
    ```
    # {target_app_name}\n\nOlympus modernization target — disposition: {disposition}.\nSources: {source_app_id}
    ```
    then `+= ", " + ", ".join(peer_source_app_ids)` if peers present (573-574),
    then `+= "\nWave: {wave_id}\n"` (575).
  - `provisioned_url, _ = GitService.provision_repository(cfg,
    repo_slug=input.target_repo, initial_readme=readme, private=True)` (576-582).
  - **on any Exception:** if `_is_already_exists_error(exc)` →
    `raise NonRetryableError("Target repository {target_repo!r} already exists
    and is owned by a different wave or user. Pick a different repo name and
    retry.")` (583-589). Otherwise `raise` (bubbles up for the retry policy) (590-591).
- else (no token / GitService unavailable): `provisioned_url = input.target_repo`
  (pass slug through) and log; production always has a token, unit tests hit
  this branch (592-601).

`_is_already_exists_error(exc)` (`target_provisioning.py:358-370`): returns
True if `str(exc).lower()` contains `"422"` OR `"already exists"` OR
`"name already exists"`; OR if `exc.__cause__` has attribute `status == 422`
(PyGithub `GithubException` carries `.status` on the cause chain).

`GitService.provision_repository` (`olympus-api/src/services/git_service.py:749-853`,
`@staticmethod`): validates `repo_slug` contains `/` (else `GitServiceError`);
splits `owner/name`; short-circuits returning `(existing.html_url, False)` if
the repo already exists (404 means create); resolves org owner via
`get_organization`, falling back to `get_user()` on 404; `create_repo(name,
private, auto_init=True, description=...)`; overwrites the auto-init README
with `initial_readme` if given (best-effort — README overwrite failure logs a
warning and continues); returns `(new_repo.html_url, True)`.

**F. DB writes (lines 606-854)** — new `asyncpg.connect(_db_url())` opened,
`async with conn.transaction():` wraps all writes; `finally: await conn.close()`
(the transaction commits when the `async with` exits, BEFORE conn closes).

**F.1 — `new_target` branch (lines 609-773):**

1. **Target UUID** (619-625):
   - if `is_decomposition_target and input.wave_id`:
     `target_uuid = uuid.uuid5(uuid.NAMESPACE_URL, f"olympus:target:{input.wave_id}:{slug}")`
     (DETERMINISTIC so retries resolve to the same row).
   - else `target_uuid = uuid.uuid4()` (Replace/Consolidate use random UUID).

2. **Resolve `source_ids` list** (636-661):
   - if `input.source_app_ids` (v2): iterate, `uuid.UUID(sid)` each, skip +
     `logger.warning` on invalid entries (636-646). If the resulting list is
     empty → fall back to `source_ids = [source_uuid]` (647-650).
   - else (v1): `source_ids = [source_uuid]` then append each valid
     `uuid.UUID(peer)` from `peer_source_app_ids`, skipping + warning on
     invalid (651-661).

3. `target_service_id = input.target_service_id or None` (666).

4. `disposition_value = disposition or None` (684).

5. **INSERT the target `application` row** (685-720):
   ```sql
   INSERT INTO application (
       id, name, portfolio_id, current_line,
       current_status, target_repo_url, source_app_ids,
       target_service_id, disposition, disposition_source
   )
   VALUES ($1, $2, $3, NULL, 'onboarded', $4, $5, $6, $7, $8)
   ON CONFLICT (id) DO UPDATE SET
       disposition = COALESCE(application.disposition, EXCLUDED.disposition),
       disposition_source = CASE
           WHEN application.disposition IS NULL AND EXCLUDED.disposition IS NOT NULL
               THEN 'provisioning'
           ELSE application.disposition_source
       END
   ```
   Parameter binding (712-719):
   | $ | value |
   |---|---|
   | $1 | `target_uuid` |
   | $2 | `input.target_app_name` |
   | $3 | `portfolio_uuid` |
   | $4 | `provisioned_url or input.target_repo` |
   | $5 | `source_ids` (list[UUID]) |
   | $6 | `target_service_id` (or None) |
   | $7 | `disposition_value` (or None) |
   | $8 | `"provisioning" if disposition_value else None` |

   Fixed literals: `current_line = NULL`, `current_status = 'onboarded'`.
   `created_new = True` (721).

   **GOTCHA (disposition projection):** the disposition is stamped onto the
   new row at provisioning time. Without it the row carries `disposition=NULL`
   and EVERY downstream line 422s on `INVALID_LINE_PREREQS` ("current
   disposition is None") — Modernization gates on {Refactor, Rearchitect},
   Disposition Execution on {Retire, Retain, Replace, Replatform,
   Consolidate}. The `ON CONFLICT DO UPDATE` only backfills disposition when
   still NULL, so a real Rationalization decision is never overwritten
   (`target_provisioning.py:670-711`).

6. **Bind to wave** (725-734): if `wave_uuid is not None`:
   ```sql
   INSERT INTO wave_application (wave_id, application_id)
   VALUES ($1, $2) ON CONFLICT DO NOTHING
   ```
   params `(wave_uuid, target_uuid)`.

7. **Lineage edges — one per source** (741-761):
   - `relationship = _lineage_relationship_for(disposition)` (742,
     see §1.6).
   - `all_sources = list(source_ids)` (743).
   - For each `src`:
     ```sql
     INSERT INTO application_lineage (
         target_app_id, source_app_id, relationship, created_at
     )
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (target_app_id, source_app_id) DO NOTHING
     ```
     params `(target_uuid, src, relationship, datetime.now(timezone.utc))`.
   - `if result.endswith(" 1"): lineage_inserted += 1` (760-761). asyncpg
     returns e.g. `"INSERT 0 1"` for a real insert, `"INSERT 0 0"` for a
     conflict-skip — the `" 1"` suffix discriminates.

8. Build `new_target_result = CreateTargetAppAndRepoResult(
   target_app_id=str(target_uuid), target_repo_url=provisioned_url or input.target_repo,
   created_new_app_row=created_new, lineage_rows_inserted=lineage_inserted)` (763-768).
   Falls through to post-transaction housekeeping (does NOT return here).

**F.2 — target==source branch (`else`, lines 774-852):**

1. `effective_url = provisioned_url or input.target_repo` (793).
2. `disposition_value = disposition or None` (794).
3. **UPDATE the source `application` row** (795-812):
   ```sql
   UPDATE application
   SET target_repo_url = $2,
       disposition = COALESCE(disposition, $4),
       disposition_source = CASE
           WHEN disposition IS NULL AND $4 IS NOT NULL THEN 'provisioning'
           ELSE disposition_source
       END,
       updated_at = $3
   WHERE id = $1
   ```
   params `($1=source_uuid, $2=effective_url, $3=datetime.now(timezone.utc),
   $4=disposition_value)`.
4. Lineage (813-836):
   - if `is_build`: `lineage_inserted = 0` — greenfield has no legacy source,
     a self-edge would be false (813-818).
   - else: `relationship = _lineage_relationship_for(disposition)`;
     ```sql
     INSERT INTO application_lineage (target_app_id, source_app_id, relationship, created_at)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (target_app_id, source_app_id) DO NOTHING
     ```
     params `(source_uuid, source_uuid, relationship, datetime.now(timezone.utc))`
     — a SELF-edge (target==source). `lineage_inserted = 1 if result.endswith(" 1") else 0`
     (819-836).
5. `new_target_result = CreateTargetAppAndRepoResult(
   target_app_id=input.source_app_id, target_repo_url=effective_url,
   created_new_app_row=False, lineage_rows_inserted=lineage_inserted)` (844-849).
   Falls through (except for Build, handled next).

**G. Greenfield Build short-circuit (lines 865-874):** if `is_build` → log
and `return new_target_result` immediately. Net-new build has no sources and
no Discovery outputs, so there is no source-artifacts-index to write and no
source termination to do.

**H. Commit the source-artifacts-index (lines 896-916):** runs for BOTH
new-target and target==source (non-Build) dispositions.
1. `anchor_name, peer_pairs, artifact_repo = await _fetch_source_app_names_and_repo(...)`
   (see §1.5) (897-901).
2. `index_payload = _build_source_artifacts_index(...)` (see §1.4) (902-910).
3. `await _write_target_source_artifacts_index(artifact_repo=..., wave_id=...,
   target_app_id=target_app_id_str, index_payload=...)` (see §1.5) (911-916).

**GOTCHA:** this write is a HARD requirement (raises on failure) since
2026-05-21. It used to be best-effort; the Private Pilot Cert wave had the
index write fail silently → Architecture + Data ran with empty input bundles
and emitted plausible-but-source-context-free output. A missing index is now
fatal so the operator can re-run (`target_provisioning.py:856-895`).

**I. Post-commit source termination (lines 937-971):**
- `if not new_target or is_decomposition_target: return new_target_result`
  (937-938). So source termination ONLY runs for TRUE Replace / Consolidate
  (new_target=True AND not a decomposition).
- `reason = f"source app consolidated into {target_app_id_str}; work transitioned to target"` (940-943).
- `source_ids_for_cleanup = [input.source_app_id]` + each peer not already
  present (944-947).
- For each `src_id`: call `_cancel_running_source_line_workflows(src_id, reason)`
  and `_set_application_consolidated_status(src_id)`; on any Exception →
  `logger.warning(...)` and continue (best-effort — housekeeping must not
  block) (948-969).
- `return new_target_result` (971).

### 1.4 `_build_source_artifacts_index` — exact JSON shape (`target_provisioning.py:157-225`)

`TARGET_SOURCE_ARTIFACTS_INDEX_SCHEMA_VERSION = "1.0"` (line 141).

`peer_role` (177-182): `"consolidate-source"` if disposition=="Consolidate",
`"replace-source"` if =="Replace", else `f"{disposition.lower()}-source"`.
Anchor always has `role="anchor"`.

`_artifacts_for_source(source_id)` (184-194) returns:
```json
{
  "discovery": ["discovery/{source_id}/{name}" for name in _SOURCE_DISCOVERY_ARTIFACTS],
  "rationalization": ["rationalization/wave-{wave_id}/{source_id}/{name}" for name in _SOURCE_RATIONALIZATION_ARTIFACTS]
}
```

Returned dict (214-225):
```json
{
  "schema_version": "1.0",
  "target_app_id": <target_app_id>,
  "target_app_name": <target_app_name>,
  "wave_id": <wave_id>,
  "disposition": <disposition>,
  "source_apps": [
    {"app_id": <anchor_source_app_id>, "app_name": <anchor_source_app_name>,
     "role": "anchor", "artifacts": {...}},
    {"app_id": <peer_id>, "app_name": <peer_name>, "role": <peer_role>, "artifacts": {...}},
    ...
  ],
  "shared_artifacts": ["rationalization/wave-{wave_id}/{name}" for name in _WAVE_SHARED_RATIONALIZATION_ARTIFACTS]
}
```

**Artifact-filename resolution (import-time)** — `_artifact_filenames_for_steps`
(`target_provisioning.py:47-84`): reads `olympus_contracts.get_line(line_name)`,
for each `step_id` pulls `step.artifact_filename`, else the basename
(`.rsplit("/",1)[-1]`) of `step.outputs.artifacts[0]`; if neither resolves →
`raise RuntimeError("Line contract drift: ...")`. **GOTCHA:** this runs at
MODULE IMPORT (lines 100-102, 118-125, 134-138) so contract drift is a
worker-startup failure, not a runtime 404.

Step-id tuples driving the filenames:
- `_SOURCE_DISCOVERY_STEP_IDS` (87-97): catalog, structural-analysis,
  business-logic-extraction, quality-risk-assessment,
  ux-accessibility-assessment, data-domain-discovery, shared-database-analysis,
  synthesis, tco-baseline. → `_SOURCE_DISCOVERY_ARTIFACTS` via line "Discovery".
- `_SOURCE_RATIONALIZATION_ARTIFACTS` (118-125): `disposition-recommendation`
  first, then classification, portfolio-scoring, intra-app-redundancy,
  disposition-governance (line "Rationalization").
- `_WAVE_SHARED_RATIONALIZATION_ARTIFACTS` (128-138): cross-app-redundancy,
  compare-ux-overlap (line "Rationalization").

`_target_source_artifacts_index_path(wave_id, target_app_id)` (144-154):
`f"rationalization/wave-{wave_id}/targets/{target_app_id}/source-artifacts-index.json"`.

### 1.5 Source-name fetch & index git write

`_fetch_source_app_names_and_repo` (`target_provisioning.py:228-282`) returns
`(anchor_name, [(peer_id, peer_name), ...], artifact_repo_url)`:
1. Collect UUIDs: try `uuid.UUID(source_app_id)` (skip on failure), then each
   valid peer UUID (240-249).
2. `conn = await asyncpg.connect(_db_url())`, try/finally close (253-274):
   - if `ids`: `SELECT id, name FROM application WHERE id = ANY($1::uuid[])`
     → build `id_to_name[str(row["id"])] = row["name"] or str(row["id"])`
     (255-263).
   - if `portfolio_uuid is not None`:
     `SELECT artifact_repo_url FROM portfolio WHERE id = $1` →
     `artifact_repo = repo_row["artifact_repo_url"] or ""` (264-272).
3. `anchor_name = id_to_name.get(source_app_id, source_app_id)` (276).
4. `peer_pairs`: for each peer_id, skip if falsy or `== source_app_id`, else
   `(peer_id, id_to_name.get(peer_id, peer_id))` (277-281).
   Falls back to the id itself as name when a row isn't found (id is
   authoritative; name decorative) (234-239).

`_write_target_source_artifacts_index` (`target_provisioning.py:285-355`):
1. if `not artifact_repo` → `raise ValueError("source-artifacts-index:
   artifact_repo unavailable for target_app_id=... — portfolio row missing
   artifact_repo_url")` (303-308).
2. `token = os.environ.get("GITHUB_TOKEN","")`; if empty →
   `raise RuntimeError("...GITHUB_TOKEN unset...")` (310-315).
3. Import GitService/GitServiceConfig (`src.git_service` then
   `olympus_api.services.git_service`); if both fail →
   `raise RuntimeError("...GitService unavailable...")` (317-333).
4. `cfg = GitServiceConfig(token, repo=artifact_repo, base_url=GITHUB_BASE_URL||default)` (335-336).
5. `path = _target_source_artifacts_index_path(wave_id, target_app_id)` (338).
6. `content = json.dumps(index_payload, indent=2, sort_keys=True)` (339).
7. `svc.commit_files(branch="main", files=[(path, content)],
   commit_message=f"rationalization(wave-{wave_id}): source-artifacts-index for target {target_app_id}")`
   (340-347). Then `logger.info("source-artifacts-index committed", ...)`.

`GitService.commit_files` (`git_service.py:255-315`): raises
`GitServiceError` if `files` empty; ensures branch if `branch != "main"`;
walks blob→tree→commit APIs (create_git_blob per file with mode `100644`,
create_git_tree with base_tree, create_git_commit with parent=base_commit,
`base_ref.edit(new_commit.sha)`); on `GithubException` →
`raise GitServiceError(f"Batch commit on '{branch}' failed: {exc.data}")`;
returns `CommitResult(commit_sha, path=first_path, branch)`.

### 1.6 `_lineage_relationship_for` (`target_realization.py:837-850`)

- `"Replace"` → `"replace"`
- `"Consolidate"` → `"consolidate"`
- else → `f"{disposition.lower()}-of"` (e.g. `"refactor-of"`, `"rearchitect-of"`).

### 1.7 Errors / retries / idempotency (create_target_app_and_repo)

- **Non-retryable (typed):** invalid source_app_id / portfolio_id (391-403);
  unsupported disposition (451-455); missing target_repo (465-469);
  repo-already-exists 422 (583-589).
- **Bubbles for retry:** any non-422 exception from `provision_repository`
  (590-591) — the decorator will classify it (retryable if its type name
  matches a pattern, else non-retryable).
- **Idempotency:** repo-url probe (§D) short-circuits both new-target and
  target==source paths; deterministic uuid5 for decomposition targets (§F.1.1);
  all lineage/wave inserts use `ON CONFLICT ... DO NOTHING`; the target
  application INSERT uses `ON CONFLICT (id) DO UPDATE` (COALESCE-backfill).
- **Best-effort (never blocks):** wave_uuid parse (405-408); source
  termination (§I, 961-969).

---

## 2. `terminate_source_app_workflows` (`target_provisioning.py:1139-1188`)

### 2.1 Signature & I/O

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def terminate_source_app_workflows(
    input: TerminateSourceAppWorkflowsInput,
) -> TerminateSourceAppWorkflowsResult
```

**`TerminateSourceAppWorkflowsInput`** (`types.py:2064-2091`): `source_app_id: str`,
`target_app_id: str = ""`, `target_app_name: str = ""`, `reason: str = ""`.

**`TerminateSourceAppWorkflowsResult`** (`types.py:2094-2106`): `source_app_id: str`,
`cancelled_workflow_ids: list[str] = []`, `status_updated: bool = False`.

### 2.2 Body (`target_provisioning.py:1169-1188`)

1. `reason = input.reason or (f"source app consolidated into {input.target_app_id};
   work transitioned" if input.target_app_id else "source app consolidated;
   work transitioned")` (1169-1177).
2. `cancelled = await _cancel_running_source_line_workflows(input.source_app_id, reason)` (1178-1180).
3. `status_updated = await _set_application_consolidated_status(input.source_app_id)` (1181-1183).
4. `return TerminateSourceAppWorkflowsResult(source_app_id=..., cancelled_workflow_ids=cancelled, status_updated=status_updated)` (1184-1188).

Both side effects are best-effort and idempotent.

### 2.3 `_cancel_running_source_line_workflows` (`target_provisioning.py:986-1084`)

- if `not source_app_id`: return `[]` (1008-1009).
- `client = await Client.connect(_temporal_host(), namespace=_temporal_namespace())`;
  on Exception → warn + return `[]` (1011-1021). `_temporal_host()` =
  `TEMPORAL_HOST` env or `"temporal:7233"`; `_temporal_namespace()` =
  `TEMPORAL_NAMESPACE` env or `"default"` (`_shared.py:32-37`).
- `workflow_types = (ArchitectureWorkflow, DataWorkflow, ModernizationWorkflow,
  ValidationWorkflow, DeploymentWorkflow)` (1023-1029).
- Visibility query:
  `f"WorkflowType IN ({workflow_types_clause}) AND ExecutionStatus = 'Running'"`
  where each type is single-quoted (1030-1034).
- `acceptable_prefixes = tuple(f"{slug}-{source_app_id}" for slug in _SOURCE_LINE_SLUGS)`
  where `_SOURCE_LINE_SLUGS = (architecture, data, modernization, validation,
  deployment)` (`target_provisioning.py:974-980`, 1039-1041).
- `async for desc in client.list_workflows(query=query)` (1045):
  - `wf_id = getattr(desc, "id", "") or ""`; skip if empty (1046-1048).
  - skip if `not wf_id.startswith(acceptable_prefixes)` (1049-1050).
  - `handle = client.get_workflow_handle(wf_id)`; `await handle.cancel()` →
    append to `attempted`, log (1051-1062).
  - on Exception (already-terminal / not-found): STILL append to `attempted`,
    log info "cancel no-op (likely already terminal)" — idempotent (1063-1075).
  - `list_workflows` failure Exception → warn + `return attempted` (1076-1082).
- `return attempted` (1084).

**GOTCHA:** filters by workflow-id prefix client-side rather than a search
attribute (which would need a Temporal schema migration). Ids follow
`{line_slug}-{app_id}-{run_ts}`. Best-effort: any Temporal error returns the
ids *attempted*, never raises (`target_provisioning.py:993-1006`).

### 2.4 `_set_application_consolidated_status` (`target_provisioning.py:1087-1136`)

`_CONSOLIDATED_STATUS = "consolidated_into_target"` (line 983).
- `uuid.UUID(source_app_id)`; on failure → warn + return `False` (1097-1103).
- `conn = await asyncpg.connect(_db_url())`, try/finally close:
  ```sql
  UPDATE application SET current_status = $1, updated_at = $2 WHERE id = $3
  ```
  params `(_CONSOLIDATED_STATUS, datetime.now(timezone.utc), app_uuid)` (1108-1118).
- Parses asyncpg `"UPDATE <n>"` → return `count >= 1`; on parse error return
  `False` (1119-1126).
- Any Exception → warn + return `False` (best-effort) (1127-1133).

Idempotent — the UPDATE runs unconditionally; a repeat call re-writes the
same values (at most `updated_at` moves).

---

## 3. `realize_target_state_grain` (`target_realization.py:534-834`)

### 3.1 Signature & I/O

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def realize_target_state_grain(
    input: RealizeTargetStateGrainInput,
) -> RealizeTargetStateGrainResult
```

**`RealizeTargetStateGrainInput`** (`types.py:1857-1895`): `wave_id: str`,
`portfolio_id: str`, `consolidation_plan_artifact_ref: str = ""`,
`consolidation_plan_json: str = ""`, `artifact_repo_root: str = ""`,
`execution_context: StepExecutionContext | None = None`. **One of**
`consolidation_plan_json` (preferred; already-loaded content) **or**
`consolidation_plan_artifact_ref` (disk path resolved via `artifact_repo_root`)
must be supplied.

**`RealizeTargetStateGrainResult`** (`types.py:1898-1916`): `wave_id: str`,
`portfolio_id: str`, then all-int-0-default counters: `plans_processed`,
`plans_skipped_keep_separate`, `target_systems_upserted`,
`target_capabilities_upserted`, `capability_lineage_rows_written`,
`system_lineage_rows_written`, `capability_lineage_rows_skipped`,
`system_lineage_rows_skipped`.

Architecture is the ONLY writer of target-side `system` (kind='target'),
`capability` (kind='derived'/'net_new'), `capability_lineage`, and
`system_lineage` rows (`target_realization.py:538-543`).

### 3.2 Constants (`target_realization.py:46-62`)

- `_AGGREGATE_DISP_TO_SYSTEM_LINEAGE = {"Consolidate":"consolidate",
  "Rearchitect":"rearchitect-of", "Replace":"replace", "Retire":"retire"}`.
- `_CAP_LINEAGE_RELATIONSHIPS = frozenset({"absorbed","partial","transformed","dropped"})`.
- `_TARGET_CAPABILITY_KINDS = frozenset({"derived","net_new"})`.
- `_TARGET_SYSTEM_KINDS = frozenset({"target","mixed"})`.

### 3.3 Control flow

1. `exec_id = await emit_code_step_start(input.execution_context,
   function_name="realize_target_state_grain")` (571-574).
   `emit_code_step_start` returns `None` if `ctx is None`; otherwise emits a
   RUNNING execution record sourcing `workflow_id`/`attempt` from
   `activity.info()` (`utils/execution.py:283-321`).
2. `portfolio_uuid = uuid.UUID(input.portfolio_id)`; on failure →
   `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` then
   `raise NonRetryableError("Invalid portfolio_id: ...")` (575-583).
3. **Load plan** (585-607):
   - if `input.consolidation_plan_json`: `plan = json.loads(...)`; on
     JSON/Value/TypeError → emit FAILED + `raise NonRetryableError(
     "consolidation_plan_json is not valid JSON: "+str(exc))` (586-595).
   - else: `plan = _read_consolidation_plan_from_disk(input.artifact_repo_root,
     input.consolidation_plan_artifact_ref)`; on NonRetryableError → emit
     FAILED("plan read failed") + re-raise (596-607).
4. if `not isinstance(plan, dict)` → emit FAILED + `raise NonRetryableError(
   "consolidation plan must be a JSON object")` (609-616).
5. `_validate_consolidation_plan(plan)`; on NonRetryableError → emit
   FAILED("schema validation failed") + re-raise (618-626).
6. `capability_plans = plan.get("capability_plans") or []` (628).
7. Init eight counters to 0 (630-637).
8. **Empty plan**: if `not capability_plans` → `emit_code_step_complete(exec_id,
   columns_written=[])` + return `RealizeTargetStateGrainResult(wave_id, portfolio_id)`
   (all counters default 0) (639-645).
9. `conn = await asyncpg.connect(_db_url())`; `async with conn.transaction():`;
   `finally: await conn.close()` — ALL writes in one transaction (647-797).
10. **For each `entry` in `capability_plans`** (650-795):
    - skip if `not isinstance(entry, dict)` (651-652).
    - `pattern = entry.get("consolidation_pattern")`; if `== "keep-separate"`
      → `plans_skipped_keep_separate += 1; continue` (653-655).
    - `target_system_block = entry.get("target_system")`;
      `target_capability_block = entry.get("target_capability")`; if either
      not a dict → warn + `continue` (guards a malformed entry) (658-674).
    - **1. Target system** (676-682): `target_system_id = _upsert_target_system(...)`;
      `target_systems_upserted += 1`.
    - **2. Target capability** (684-689): `target_capability_id =
      _upsert_target_capability(...)`; `target_capabilities_upserted += 1`.
    - **3. Capability lineage** (691-747): `lineage_rels =
      target_capability_block.get("lineage_relationships") or []`. For each `rel`:
      - skip + `capability_lineage_rows_skipped += 1` if not a dict (696-698).
      - `relationship = rel.get("relationship")`; if not in
        `_CAP_LINEAGE_RELATIONSHIPS` → skip+count (699-702).
      - `source_ext = rel.get("source_capability_external_id")`.
      - if `relationship == "dropped"`: if `not source_ext` → skip+count
        (no source row to mark); else `target_id_for_lineage = None` (704-714).
      - else: if `not source_ext` → skip+count; else
        `target_id_for_lineage = target_capability_id` (715-719).
      - `source_cap_id = _resolve_source_capability_id(...)`; if None → warn +
        skip+count (721-736).
      - `inserted = _upsert_capability_lineage(...)`; if `inserted`:
        `capability_lineage_rows_written += 1` (738-747).
    - **4. System lineage** (749-793):
      `aggregate_disposition = entry.get("aggregate_disposition") or ""`;
      `sys_lineage_rel = _AGGREGATE_DISP_TO_SYSTEM_LINEAGE.get(aggregate_disposition)`.
      if `sys_lineage_rel` truthy:
      - `seen_sources: set[str] = set()`.
      - For each `app` in `entry.get("participating_apps") or []`:
        - skip if not dict (757-758).
        - `src_sys_ext = app.get("source_system_external_id")`; skip if falsy
          OR already in `seen_sources` (759-761); else add to seen.
        - `src_sys_id = _resolve_source_system_id(...)`; if None → warn +
          `system_lineage_rows_skipped += 1; continue` (763-778).
        - if `src_sys_id == target_system_id` → `system_lineage_rows_skipped += 1;
          continue` (self-edge is meaningless) (779-785).
        - `inserted_sys = _upsert_system_lineage(...)`; if inserted →
          `system_lineage_rows_written += 1` (786-793).
    - `plans_processed += 1` (795).
11. After the transaction: `logger.info("realize_target_state_grain wrote
    target-side rows", extra={... all counters ...})` (799-813).
12. `emit_code_step_complete(exec_id, columns_written=["system","capability",
    "capability_lineage","system_lineage"])` (814-822).
13. Return `RealizeTargetStateGrainResult(...)` with all eight counters
    (823-834).

### 3.4 Plan read + schema validation helpers

`_consolidation_plan_schema_path` (`target_realization.py:65-95`): candidate
dirs = `[OLYMPUS_SCHEMAS_DIR (if set), Path(__file__).resolve().parents[4]/"schemas",
/app/schemas, /app/repo/schemas]`; returns the first
`<c>/rationalization/capability-consolidation-plan.schema.json` that `is_file()`,
else `None`. **GOTCHA:** `parents[4]` — this file is one dir deeper post-split
(`activities/line_transitions/<seg>.py`), so `parents[4]` resolves to the same
repo-root `schemas/` as the pre-split `parents[3]` (85-88).

`_load_consolidation_plan_schema` (98-117): module-level cache
`_CACHED_CONSOLIDATION_PLAN_SCHEMA` (line 120); if path is None →
`raise NonRetryableError("...not found on this worker — set OLYMPUS_SCHEMAS_DIR
or mount the repo schemas directory...")`; else read+cache.

`_validate_consolidation_plan` (123-145): `Draft202012Validator(schema)`;
`errors = list(validator.iter_errors(payload))`; if empty return; else
`raise NonRetryableError` with the first **8** errors formatted as
`f"  {err.json_path or '<root>'}: {err.message}"` (errors capped at 8).

`_read_consolidation_plan_from_disk(artifact_repo_root, artifact_ref)`
(148-182): if `not artifact_ref` → `raise NonRetryableError(
"...consolidation_plan_artifact_ref is empty...")`; `full = Path(artifact_repo_root)/artifact_ref`
if root set else `Path(artifact_ref)`; if `not full.is_file()` →
`raise NonRetryableError("consolidation plan not found at ...")`;
`json.load`; on JSONDecodeError/OSError → `raise NonRetryableError("...not
parseable JSON: ...")`.

### 3.5 `_upsert_target_system` (`target_realization.py:234-325`)

Reads from `target_system` block: `name = block.get("name") or ""`,
`description = block.get("description") or ""`, `external_id = block.get("external_id")`,
`kind = block.get("kind") or "target"`; if `kind not in _TARGET_SYSTEM_KINDS`
→ `kind = "target"` (254-259).

- **If `external_id`** (261-283):
  ```sql
  INSERT INTO system (portfolio_id, name, description, kind, external_id)
  VALUES ($1, $2, $3, $4, $5)
  ON CONFLICT (portfolio_id, external_id) WHERE external_id IS NOT NULL
    DO UPDATE SET name=EXCLUDED.name, description=EXCLUDED.description,
      kind=EXCLUDED.kind, updated_at=now()
  RETURNING id
  ```
  params `(portfolio_id, name, description, kind, external_id)`. Returns `row["id"]`.
- **No external_id** (285-325): SELECT-then-INSERT at natural key
  `(portfolio_id, name, external_id IS NULL)`:
  ```sql
  SELECT id FROM system WHERE portfolio_id=$1 AND name=$2 AND external_id IS NULL LIMIT 1
  ```
  - if exists: `UPDATE system SET description=$1, kind=$2, updated_at=now() WHERE id=$3`
    → return `existing["id"]` (301-313).
  - else: `INSERT INTO system (portfolio_id,name,description,kind,external_id)
    VALUES ($1,$2,$3,$4,NULL) RETURNING id` → return `row["id"]` (314-325).

**GOTCHA (reconciliation):** the external_id-keyed path is the higher-grain
cross-app authority; per-app target-state-mapping writes rows keyed on per-app
name (no external_id). Race-safe only because every caller is inside the
activity's outer transaction (234-253, 285-288).

### 3.6 `_upsert_target_capability` (`target_realization.py:328-408`)

Mirror of `_upsert_target_system` but on `capability` keyed by `system_id`
(not portfolio_id). `kind = block.get("kind") or "derived"`; if not in
`_TARGET_CAPABILITY_KINDS` → `"derived"` (343-346).
- external_id path: `ON CONFLICT (system_id, external_id) WHERE external_id IS
  NOT NULL DO UPDATE SET name/description/kind/updated_at RETURNING id` (348-370).
- no-external_id path: SELECT `(system_id, name, external_id IS NULL)` then
  UPDATE-or-INSERT (`... VALUES ($1,$2,$3,$4,NULL) RETURNING id`) (372-408).

### 3.7 `_upsert_capability_lineage` (`target_realization.py:411-501`)

`confidence_decimal = Decimal(str(confidence)).quantize(Decimal("0.01"))` if
confidence not None, else `None` (427-431).

- **`target_capability_id is None`** (dropped) (432-474): Postgres treats NULL
  distinct in UNIQUE so ON CONFLICT won't match — SELECT-then-INSERT at
  `(target_capability_id IS NULL, source_capability_id=$1, relationship='dropped')`:
  - if exists: `UPDATE capability_lineage SET notes=$1, confidence=$2,
    agent_emitted=TRUE WHERE id=$3` → return `False` (448-461).
  - else: `INSERT ... VALUES (NULL, $1, 'dropped', $2, $3, TRUE)` → return
    `True` (462-474).
- **Else** (476-501):
  ```sql
  INSERT INTO capability_lineage (
    target_capability_id, source_capability_id, relationship, notes, confidence, agent_emitted
  ) VALUES ($1, $2, $3, $4, $5, TRUE)
  ON CONFLICT (target_capability_id, source_capability_id) DO UPDATE SET
    relationship=EXCLUDED.relationship, notes=EXCLUDED.notes,
    confidence=EXCLUDED.confidence, agent_emitted=TRUE
  RETURNING (xmax = 0) AS inserted
  ```
  params `(target_capability_id, source_capability_id, relationship, notes,
  confidence_decimal)`. Return `bool(row and row["inserted"])`.

**GOTCHA (`xmax=0`):** `xmax` is 0 only for a true INSERT; on `ON CONFLICT DO
UPDATE` the conflicting row's `xmax` is non-zero. `RETURNING (xmax=0)` is the
INSERT-vs-UPDATE discriminator that keeps the written-vs-skipped counter
accurate (476-479). `agent_emitted` is always forced TRUE. Honors
`capability_lineage_target_chk`: `target_capability_id IS NULL` iff
`relationship == 'dropped'` (420-423).

### 3.8 `_upsert_system_lineage` (`target_realization.py:504-531`)

```sql
INSERT INTO system_lineage (target_system_id, source_system_id, relationship)
VALUES ($1, $2, $3)
ON CONFLICT (target_system_id, source_system_id) DO UPDATE SET relationship=EXCLUDED.relationship
RETURNING (xmax = 0) AS inserted
```
Return `bool(row and row["inserted"])`. Relationship overwritten on conflict.

### 3.9 Resolvers

`_resolve_source_capability_id` (185-210):
```sql
SELECT c.id FROM capability c JOIN system s ON s.id = c.system_id
WHERE s.portfolio_id = $1 AND c.external_id = $2 LIMIT 1
```
params `(portfolio_id, source_external_id)` → `row["id"]` or `None`.

`_resolve_source_system_id` (213-231):
```sql
SELECT id FROM system WHERE portfolio_id = $1 AND external_id = $2 LIMIT 1
```
→ `row["id"]` or `None`.

### 3.10 Errors / retries / idempotency (realize_target_state_grain)

- **Non-retryable (typed), each preceded by `emit_code_step_complete(FAILED)`:**
  invalid portfolio_id (575-583); bad plan JSON (586-595); plan read failure
  (596-607); plan not an object (609-616); schema validation failure (618-626).
- Schema missing / not-parseable / ref empty all raise `NonRetryableError`
  (deployment bugs, not data conditions) (108-113, 162-182).
- **Idempotency:** every write is a natural-key UPSERT (external_id or
  name/id), so a rerun of the same plan does not double rows; counters return
  0 written on a no-op rerun (the `xmax=0`/`endswith(" 1")` discriminators
  count only true INSERTs). All writes are in ONE transaction — partial
  realization is never committed (568-570, 647-649).
- Skipped-not-fatal conditions (increment `*_skipped`, log-and-continue):
  non-dict lineage entry, unknown relationship, missing source_ext,
  unresolved source capability/system, self-edge.

---

## 4. `persist_deployment_side_effects` (`deployment.py:218-311`)

### 4.1 Signature & I/O

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_deployment_side_effects(
    input: PersistDeploymentSideEffectsInput,
) -> PersistDeploymentSideEffectsResult
```

**`PersistDeploymentSideEffectsInput`** (`types.py:2635-2662`): `target_app_id: str`,
`deployment_manifest_json: str = ""`, `decommission_certificate_json: str = ""`,
`license_reclamation_json: str = ""`, `cost_savings_certification_json: str = ""`,
`deployment_current_status: str = ""`, `execution_context: StepExecutionContext|None = None`.

**`PersistDeploymentSideEffectsResult`** (`types.py:2665-2679`): `target_app_id: str`,
`deployed_at_persisted: bool = False`, `legacy_decommissioned_at_persisted: bool = False`,
`cost_savings_realized_persisted: bool = False`, `license_reclamation_persisted: bool = False`,
`deployment_current_status: str = ""`.

Runs once per target app at Deployment Step 17 after G-DP-2 merges. **Failures
are observability-only** — the workflow continues to the Sustainment handoff
even when this raises (`deployment.py:222-233`). (The activity itself DOES
re-raise on error, line 306-310; the "best-effort" behavior is enforced by the
CALLING workflow, not swallowed here.)

### 4.2 Control flow (`deployment.py:234-310`)

1. `exec_id = await emit_code_step_start(input.execution_context,
   function_name="persist_deployment_side_effects")` (234-237).
2. All inside `try: ... except Exception as exc: emit_code_step_complete(exec_id,
   status=FAILED, error=str(exc)); raise` (238, 306-310).
3. `target_uuid = uuid.UUID(input.target_app_id)`; on failure → `raise
   NonRetryableError("Invalid target_app_id: ...")` (239-244).
4. Parse the four JSON strings via `_try_parse_json` (best-effort dict-or-None,
   `_shared.py:40-56`): `manifest`, `certificate`, `reclamation`,
   `certification` (246-249).
5. Build `projections: dict` (251-259) by `.update()` with each extractor:
   - `_extract_deployment_lifecycle_side_effects(manifest)`
   - `_extract_decommission_side_effects(certificate, reclamation)`
   - `_extract_realized_savings_side_effects(certification)`
   - `_extract_deployment_status(input.deployment_current_status)`
6. **Empty projections**: if `not projections` → log "nothing extractable",
   `emit_code_step_complete(exec_id, columns_written=[])`, return
   `PersistDeploymentSideEffectsResult(target_app_id=...)` (all-default) (261-269).
7. `sql, params = _build_update_sql(projections)`; `params.append(target_uuid)` (271-272).
8. `conn = await asyncpg.connect(_db_url())`; `await conn.execute(sql, *params)`;
   `finally: await conn.close()` (274-278).
9. `logger.info("deployment side-effects persisted", ...)` +
   `emit_code_step_complete(exec_id, columns_written=sorted(projections.keys()))`
   (280-289).
10. Return result with the per-field `*_persisted` booleans set by
    `"<col>" in projections`, and `deployment_current_status = str(
    projections.get("deployment_current_status", ""))` (290-305).

### 4.3 `_build_update_sql` (`_shared.py:506-539`) — artifact → DB row transform

Iterates `_SIDE_EFFECT_COLUMNS` (`_shared.py:70-153`, a fixed ordered tuple of
all projectable columns across every line) in ORDER; for each column present
in `projections`:
- `value = json.dumps(value)` if column in `_JSONB_COLUMNS` (`_shared.py:156-171`);
- append `f"{column} = ${idx}"` to assignments, append value to params, `idx += 1`.
Then ALWAYS append `updated_at = ${idx}` with `datetime.now(timezone.utc)`.
Final SQL: `"UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${where_idx}"`.
Only touched columns are written; unset fields keep existing values.

**GOTCHA:** the caller appends `target_uuid` as the LAST param AFTER
`_build_update_sql` returns (`deployment.py:271-272`), matching the `$where_idx`
placeholder. The deployment columns among `_SIDE_EFFECT_COLUMNS` (none in
`_JSONB_COLUMNS`) are: `deployed_at, deployment_env, cutover_strategy,
parallel_run_duration_days, cost_savings_realized_usd, license_reclamation_usd,
legacy_decommissioned_at, deployment_current_status` (`_shared.py:133-144`).
Several are in `_NATIVE_COLUMNS` (datetime/Decimal/int passed natively, NOT
json-dumped): `deployed_at`, `legacy_decommissioned_at`,
`cost_savings_realized_usd`, `license_reclamation_usd`,
`parallel_run_duration_days` (`_shared.py:174-195`).

### 4.4 Extractor field-mapping detail

**`_extract_deployment_lifecycle_side_effects(manifest)`** (`deployment.py:61-119`):
returns `{}` if manifest not a dict. Maps:
- `deployed_at`: from `manifest["deployed_at"]` if non-empty str →
  `datetime.fromisoformat(v.replace("Z","+00:00"))`; on TypeError/ValueError
  logs warning, field omitted (81-91).
- `deployment_env`: from `manifest["environment"]` or `manifest["deployment_env"]`
  if non-empty str → `v.strip()[:64]` (cap at VARCHAR(64), truncate not fail) (93-97).
- `cutover_strategy`: from `manifest["strategy"]` or `manifest["cutover_strategy"]`
  ONLY if in `_CUTOVER_STRATEGIES = frozenset({canary, blue-green, instant,
  vendor-swap, platform-switch, source-redirect})` (`deployment.py:39-42`); a
  non-whitelisted truthy value logs a warning and DROPS the column (99-106).
- `parallel_run_duration_days`: if `manifest["parallel_run"]` is a dict and its
  `observed_duration_days` is int/float → `int(duration)`; ELSE (legacy) from
  top-level `manifest["parallel_run_duration_days"]` if int/float → `int(...)`
  (108-117).

**`_extract_decommission_side_effects(certificate, reclamation)`** (`deployment.py:122-166`):
- `legacy_decommissioned_at`: if certificate is a dict, from
  `certificate["decommissioned_at"]` or `certificate["completed_at"]`; if
  non-empty str → `datetime.fromisoformat(v.replace("Z","+00:00"))`; TypeError/
  ValueError logs warning, omit (139-155).
- `license_reclamation_usd`: if reclamation is a dict, from `total_reclaimed_usd`
  or `total_usd` or `license_reclamation_usd` (first truthy); if int/float →
  `Decimal(str(round(float(total),2)))` (157-164).
- Missing/malformed payloads → field simply absent (partial write) (134-137).

**`_extract_realized_savings_side_effects(certification)`** (`deployment.py:169-195`):
returns `{}` if not a dict. `cost_savings_realized_usd`: from
`cost_savings_realized_usd` or `annual_savings_usd` or
`realized_annual_savings_usd` (first truthy); if int/float →
`Decimal(str(round(float(realized),2)))` (185-193).

**`_extract_deployment_status(status)`** (`deployment.py:198-215`): returns `{}`
if not a non-empty str, OR if `status not in _DEPLOYMENT_STATUSES` (warns and
drops). `_DEPLOYMENT_STATUSES = frozenset({orchestrating, shifting,
parallel_running, verifying_adoption, awaiting_g_dp1, decommissioning,
certifying, awaiting_g_dp2, completed, failed})` (`deployment.py:45-58`). Else
returns `{"deployment_current_status": status}`.

### 4.5 Errors / retries / idempotency (persist_deployment_side_effects)

- **Non-retryable:** invalid `target_app_id` (241-244). All other exceptions
  (DB, etc.) propagate through the `except` (306-310) which emits FAILED then
  re-raises → classified by the decorator (`connection`-type-name errors
  become RetryableError).
- **Idempotency:** the UPDATE is a plain overwrite of the projected columns +
  `updated_at`; rerunning with the same artifacts re-writes identical values
  (only `updated_at` moves). No conflict handling needed (single-row UPDATE by id).
- Whitelists on `cutover_strategy`, `deployment_current_status` mean bad enum
  values are dropped, never poison the column.

---

## Appendix: shared `_db_url` (`_shared.py:23-29`)

`postgresql://{DATABASE_USER|olympus}:{DATABASE_PASSWORD|olympus}@{DATABASE_HOST|localhost}:{DATABASE_PORT|5432}/{DATABASE_NAME|olympus}`.
Every DB call in this group opens a fresh `asyncpg.connect(_db_url())` and
closes it in `finally` (no pooling).
