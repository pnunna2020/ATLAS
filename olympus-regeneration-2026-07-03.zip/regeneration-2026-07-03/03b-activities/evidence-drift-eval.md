# Activity group: `evidence_emit` + `drift_control_eval`

Atomic regeneration spec for two Temporal activity modules under
`temporal/olympus_workflows/activities/`:

- `evidence_emit.py` — activity `emit_evidence` (P8 evidence-layer-delta).
- `drift_control_eval.py` — activity `drift_control_eval` (P8 drift-as-control-delta),
  plus the pure verdict core reused by both offline callers and the workflow.

Both activities are decorated with the custom `@foundry_activity` wrapper. Both write
into the SAME data layer (`EvidenceEmitService`), so the persistence transformation is
documented once (in the `emit_evidence` section) and referenced from
`drift_control_eval`.

**Units documented (activity functions): 2** — `emit_evidence`, `drift_control_eval`.
The module-level pure helpers (`evaluate_drift_control`, `compute_verdict`,
`classify_report`, gate-state fold, `_config_from_input`, `_report_from_input`,
`_result`, `_emit_for_verdict`, `_emit_on_session`) are fully reproduced because the
activity behavior depends on them byte-for-byte.

---

## 0. `@foundry_activity` — what the wrapper adds over raw `activity.defn`

Source: `temporal/olympus_workflows/temporal_base/activities.py`.

Both activities are declared exactly as
`@foundry_activity(config=ActivityConfig(enable_observability=True))`
(`evidence_emit.py:87`, `drift_control_eval.py:367`).

### `ActivityConfig` fields (`activities.py:41-53`)

```
retry_policy: RetryPolicy | None = None
start_to_close_timeout: timedelta | None = None
schedule_to_close_timeout: timedelta | None = None
schedule_to_start_timeout: timedelta | None = None
heartbeat_timeout: timedelta | None = None
enable_observability: bool = True
enable_error_wrapping: bool = True
log_inputs: bool = False
log_outputs: bool = False
```

GOTCHA: for BOTH activities the ONLY field set is `enable_observability=True`.
Everything else takes the default. In particular **`retry_policy=None`, all timeouts
`None`, `heartbeat_timeout=None`, `enable_error_wrapping=True` (default),
`log_inputs=False`, `log_outputs=False`.** The decorator does NOT pass `retry_policy`
or the timeouts through to `@activity.defn` at all (see below) — those `ActivityConfig`
fields are inert unless the workflow's `execute_activity(...)` call sets them. So retry
behavior is governed entirely by (a) whatever `RetryPolicy`/timeout the *workflow* passes
when scheduling, and (b) the `non_retryable` flag on the error type the wrapper raises.

### Decorator mechanics (`activities.py:97-148`)

`foundry_activity(config, name=None, **activity_kwargs)` returns `decorator(func)`:

1. `activity_config = config or ActivityConfig()` (`:98`).
2. Wraps `func` in an `async def wrapper(*args, **kwargs)` that is itself decorated with
   `@activity.defn(name=name, **activity_kwargs)` then `@wraps(func)`
   (`:100-101`). GOTCHA: only `name` and `**activity_kwargs` reach `@activity.defn` —
   `config` (retry/timeout/heartbeat) is NOT forwarded. Neither activity passes
   `name=` or extra `activity_kwargs`, so **the Temporal activity name defaults to the
   Python function name** (`emit_evidence`, `drift_control_eval`). Replay keys on this
   name (`:14-16` docstring) — renaming the function is a breaking change.
3. `activity_name = name or func.__name__` (`:103`).
4. **Start log** (only if `enable_observability`): `logger.info("Activity %s starting", activity_name, extra={"inputs": args if log_inputs else None})` (`:105-110`). `log_inputs` is False → `extra["inputs"]=None`.
5. `result = await func(*args, **kwargs)` (`:113`).
6. **Complete log**: `logger.info("Activity %s completed", ...)` with `extra["outputs"]=None` (log_outputs False) (`:115-120`).
7. Returns `result` (`:122`).
8. **Except block** (`:124-146`): on ANY `Exception`:
   - If `enable_observability`: `logger.error("Activity %s failed: %s", activity_name, error, extra={"error": str(error)})` (`:125-131`).
   - If `enable_error_wrapping` (default True):
     - `if isinstance(error, (WorkflowError, ApplicationError)): raise` — **already-typed Temporal errors pass through unchanged, preserving their own `non_retryable` flag** (`:135-136`).
     - `elif _is_retryable_error(error): raise RetryableError(f"Retryable error in {activity_name}: {error}") from error` (`:137-140`).
     - `else: raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error` (`:141-144`).
   - else (`enable_error_wrapping` False — not used here): `raise` (`:146`).

### `_is_retryable_error` heuristic (`activities.py:56-76`)

Classifies by the **error TYPE NAME string**, NOT the instance:
```
error_str = str(type(error)).lower()
retryable_patterns = ["timeout","connection","network","temporary",
                      "unavailable","overload","busy","throttle","rate_limit"]
return any(pattern in error_str for pattern in retryable_patterns)
```
GOTCHA: this is a substring match on `str(type(error))` (e.g.
`"<class 'httpx.ConnectTimeout'>"`). It is DELIBERATELY DIFFERENT from
`errors.is_retryable_error` which inspects instances (`activities.py:59-63` docstring).
Consequence for these two activities: a plain `ValueError`/`KeyError`/SQLAlchemy error
(type name has none of those substrings) becomes a **`NonRetryableError`**. A wrapped
`asyncpg`/httpx connection/timeout error whose type name contains `connection`/`timeout`
becomes a **`RetryableError`**.

### Error type flags (`temporal_base/errors.py`)

- `WorkflowError(ApplicationError)` — `__init__(message, non_retryable=True)` default terminal (`errors.py:16-20`).
- `RetryableError(WorkflowError)` — `super().__init__(message, non_retryable=False)` (`errors.py:23-27`).
- `NonRetryableError(WorkflowError)` — `super().__init__(message, non_retryable=True)` (`errors.py:30-34`).

GOTCHA (fail-closed hinge): `EvidenceWriteError` (defined in
`olympus-api/src/services/evidence_emit.py:58`, a **plain `Exception`**, NOT a
`WorkflowError`) has NO `connection/timeout/...` substring in its type name, so when it
escapes the activity body the wrapper takes the `else` branch and raises a
`NonRetryableError` (`non_retryable=True`). That is the mechanism that makes evidence
durability failures **non-retryable → the verdict's workflow path fails and the verdict
never commits without its evidence** (REQ-EV-009; `evidence_emit.py:11-14`,
`drift_control_eval.py:499-503`).

### Heartbeat / observability summary
- **Heartbeat:** none. `heartbeat_timeout=None`; neither activity body calls
  `activity.heartbeat(...)`. These are short single-transaction DB writes.
- **Observability:** stdlib `logging` only (`logger = logging.getLogger(__name__)`,
  `activities.py:38`) — no Prometheus/structlog at the wrapper level (`activities.py:6-7`).
  The *service layer* it calls uses structlog (`evidence_emit.py:53` service).

---

## 1. Activity `emit_evidence`

File: `temporal/olympus_workflows/activities/evidence_emit.py`.

### 1.1 Signature
```
@foundry_activity(config=ActivityConfig(enable_observability=True))          # :87
async def emit_evidence(payload: EmitEvidenceInput) -> EmitEvidenceResult:   # :88
```

### 1.2 Input dataclass `EmitEvidenceInput` (`:42-72`)

Plain `@dataclass`, serializable, NOT added to frozen `olympus_contracts` (`:19-21`).
Fields with EXACT names, types, defaults:

| field | type | default |
|---|---|---|
| `portfolio_id` | `str` | (required) |
| `control_id` | `str` | (required) |
| `family` | `str` | (required) |
| `status` | `str` | `"unknown"` |
| `application_id` | `str \| None` | `None` |
| `implementation_statement` | `str` | `""` |
| `evidence_refs` | `list[dict]` | `field(default_factory=list)` |
| `assessed_at_gate` | `str \| None` | `None` |
| `assessed_by_skill` | `str \| None` | `None` |
| `risk_tier` | `int \| None` | `None` |
| `run_id` | `str \| None` | `None` |
| `subject_kind` | `str` | `"gate"` |
| `subject_id` | `str \| None` | `None` |
| `classification` | `str` | `"unclassified"` |
| `owner_scope` | `str \| None` | `None` |
| `owner_scope_type` | `str` | `"portfolio"` |
| `retention_policy` | `str` | `"standard"` |
| `profile_id` | `str \| None` | `None` |
| `profile_schema_version` | `str \| None` | `None` |
| `mappings` | `list[ControlMappingInput]` | `field(default_factory=list)` |

`ControlMappingInput` (`:34-39`): `catalog_id: str`, `control_id: str`.

GOTCHA: `run_id` is carried on the input but **never used** in the activity body — it is
plumbed for traceability but not passed to the service.

### 1.3 Output dataclass `EmitEvidenceResult` (`:75-84`)
```
emitted: bool
content_hash: str | None = None
record_id: str | None = None
outbox_id: str | None = None
dangling: list[str] = field(default_factory=list)     # ["catalog_id:control_id", ...]
suppressed: bool = False
```

### 1.4 Body, step by step (`:88-186`)

1. `import uuid as _uuid` (`:97`). LAZY imports of the API service + models
   (`:99-115`) — done INSIDE the body so the Temporal workflow sandbox can import a
   workflow referencing this activity without loading SQLAlchemy/asyncpg (`:16-19`,
   `:99`). Lazily imported: `src.database.get_db`;
   `src.models.control_mapping.{ControlMapping, DanglingControlMapping}`;
   `src.models.evidence_envelope.{Classification, CtEnvelope, OwnerScopeType, RetentionPolicy}`;
   `src.models.evidence_record.EvidenceRecordInput`;
   `src.services.evidence_emit.{EvidenceEmitService, EvidenceWriteError}`.

2. **`captured_at = datetime.now(timezone.utc)`** (`:117`). REQ-TEMP-001: the timestamp
   is read HERE in the activity (workflow code stays deterministic). This `captured_at`
   becomes `record.last_assessed`, which is a **hash-payload field** (§1.6) — so the
   content hash embeds the activity-side clock.

3. Build `EvidenceRecordInput` (`:119-135`), field mapping from `payload`:
   - `portfolio_id = _uuid.UUID(payload.portfolio_id)` — GOTCHA: parses the string to
     `UUID`; a malformed string raises `ValueError` → wrapper → `NonRetryableError`.
   - `application_id = _uuid.UUID(payload.application_id) if payload.application_id else None`
     (`:121-125`). Empty string / None → `None`.
   - `control_id = payload.control_id`; `family = payload.family`;
     `status = payload.status` (cast-ignored to `ControlStatus` literal);
     `implementation_statement`, `evidence_refs`, `assessed_at_gate`,
     `assessed_by_skill`, `risk_tier` — passed through 1:1.
   - `last_assessed = captured_at`.
   - NOTE: `EvidenceRecordInput.inherited_from` is left at its default `None` (not on the
     activity input).

4. Build `CtEnvelope` (`:136-143`):
   - `classification = Classification(payload.classification)` — GOTCHA: enum coercion; a
     value outside `{unclassified,cui,confidential,secret}` raises `ValueError` →
     `NonRetryableError`.
   - `owner_scope = payload.owner_scope`.
   - `owner_scope_type = OwnerScopeType(payload.owner_scope_type)` (`{portfolio,application,system}`).
   - `retention_policy = RetentionPolicy(payload.retention_policy)` (`{standard,extended,permanent}`).
   - `profile_id = payload.profile_id`; `profile_schema_version = payload.profile_schema_version`.
   - `schema_version` defaults to `ENVELOPE_SCHEMA_VERSION = "1.0"` (`evidence_envelope.py:59,71`).

5. Build mappings: `mappings = [ControlMapping(catalog_id=m.catalog_id, control_id=m.control_id) for m in payload.mappings]` (`:144-147`).

6. **Session acquisition** (`:152-153`): `db_gen = get_db(); session = await db_gen.__anext__()`.
   GOTCHA: drives the request-scoped async generator MANUALLY (`__anext__`), not via
   FastAPI DI, so the activity OWNS the single commit (the whole point: verdict +
   evidence + outbox commit together — `:149-151`, REQ-EV-005).

7. `try:` (`:154-163`) — construct `EvidenceEmitService(session)` and call
   `await svc.emit(record, envelope=envelope, mappings=mappings, subject_kind=payload.subject_kind, subject_id=payload.subject_id, commit=True)`.
   GOTCHA: `commit=True` here (contrast §2, where drift-control also uses `commit=True`
   on a fresh session). The service commits internally on this session.

8. **`except DanglingControlMapping as dangle:`** (`:164-169`) — a dangle is NOT a
   failure. The record + mappings were already persisted (§1.5). Return immediately:
   ```
   EmitEvidenceResult(emitted=True, dangling=[f"{dangle.catalog_id}:{dangle.control_id}"])
   ```
   GOTCHA: `content_hash` / `record_id` / `outbox_id` are all `None` on this branch — the
   dangle short-circuits BEFORE reading the `EmissionResult`, so a caller that hit a
   dangle gets `emitted=True` but no hash/id. Only the FIRST dangle is surfaced
   (`DanglingControlMapping` carries a single `(catalog_id, control_id)` — the service
   raises on `dangling_seen[0]`, evidence_emit service `:344-345`).

9. **`except EvidenceWriteError: raise`** (`:170-172`) — re-raise unchanged. The wrapper
   then converts it to `NonRetryableError` (fail-closed, REQ-EV-009).

10. **`finally: await db_gen.aclose()`** (`:173-174`) — always closes the generator
    (drives its cleanup / session close).

11. If no exception: `result = svc.emit(...)` value.
    - **`if result is None: return EmitEvidenceResult(emitted=False, suppressed=True)`**
      (`:176-177`) — suppression (REQ-EV-EMIT-002): the `(subject_kind, subject_id)` pair
      was in `evidence_suppression`.
    - Else return (`:178-186`):
      ```
      EmitEvidenceResult(
        emitted=True,
        content_hash=result.record.content_hash,
        record_id=str(result.record.id),
        outbox_id=result.outbox_id,
        dangling=[f"{c}:{ct}" for c, ct in ((m.catalog_id, m.control_id) for m in result.dangling)],
      )
      ```
      GOTCHA: this `dangling` list here comes from `result.dangling` (mappings with
      `status=='dangling'`), but in practice the service RAISES `DanglingControlMapping`
      when any dangle exists (evidence_emit service `:341-345`), so the happy-path
      `result.dangling` is normally empty and dangles arrive via branch (8) instead. This
      list is populated only if the service returned an `EmissionResult` with dangling
      rows WITHOUT raising — which the current service does not do.

### 1.5 `EvidenceEmitService.emit` — the persistence transformation (artifact-JSON → DB rows)

Source: `olympus-api/src/services/evidence_emit.py`. This is invoked by BOTH activities.
Reproduce fully.

`emit(record: EvidenceRecordInput, *, envelope: CtEnvelope, mappings, subject_kind="gate", subject_id=None, commit=True)` (`emit :181-190`):

**A. Suppression check** (`:205-213`):
- `sid = subject_id if subject_id is not None else (record.assessed_at_gate or "")`.
  GOTCHA: when the caller passes no `subject_id`, the gate id is used; if that's also
  None, `sid=""`.
- `if sid and await self.is_suppressed(subject_kind, sid):` → log
  `evidence_emission_suppressed` and `return None`. Empty `sid` never suppresses.
- `is_suppressed` (`:91-105`): `SELECT 1 FROM evidence_suppression WHERE subject_kind=:k AND subject_id=:s LIMIT 1`; empty table suppresses nothing (emit-by-default).

**B. Delegate to `_emit_unsuppressed`, wrapped in fail-closed handling** (`:215-229`):
- `try: return await self._emit_unsuppressed(...)`.
- `except DanglingControlMapping: raise` (dangle is not a write failure — re-raise).
- `except EvidenceWriteError: raise`.
- `except Exception as exc:` → `await self._safe_rollback()` then
  `raise EvidenceWriteError(f"evidence record could not be durably written: {exc}") from exc`.
  GOTCHA: ANY other exception (asyncpg error, JSON error, etc.) is converted to
  `EvidenceWriteError` AFTER a best-effort rollback. `_safe_rollback` (`:401-405`) calls
  `await self._db.rollback()` and swallows a rollback failure with a
  `evidence_emit_rollback_failed` warning.

**C. `_emit_unsuppressed`** (`:231-346`) — the core transformation:

1. `payload = canonical_payload(record)` (`:239`) — the hash payload (§1.6).
2. `content_hash = compute_content_hash(payload)` (`:240`) → `sha256:<64hex>`.
3. `existing = await self._get_by_hash(content_hash)` (`:242`) —
   `SELECT * FROM evidence_record WHERE content_hash=:ch`, hydrated via `_record_from_row`.
4. **Idempotent short-circuit:** `if existing is not None: stored = existing`
   (`:243-244`). No INSERT — a byte-identical record already exists.
5. Else (`:245-302`): compute chain link then INSERT.
   - `prev_hash = await self._latest_hash_for_chain(record.portfolio_id, record.application_id, record.control_id)` (`:246-248`).
     `_latest_hash_for_chain` (`:108-134`):
     `SELECT content_hash FROM evidence_record WHERE portfolio_id=:pid AND {application_id=:app_id | application_id IS NULL} AND control_id=:cid ORDER BY recorded_at DESC, id DESC LIMIT 1`.
     GOTCHA: the app clause is chosen dynamically — when `application_id is None` the
     clause is literally `application_id IS NULL` and `:app_id` is NOT bound.
   - **INSERT INTO `evidence_record`** (`:249-292`). Columns and value mapping:

     | column | value source |
     |---|---|
     | `portfolio_id` | `record.portfolio_id` |
     | `application_id` | `record.application_id` |
     | `control_id` | `record.control_id` |
     | `family` | `record.family` |
     | `status` | `record.status` |
     | `content_hash` | computed `content_hash` |
     | `evidence_payload` | `CAST(:payload AS JSONB)`, `:payload = json.dumps(payload)` (canonical dict) |
     | `prev_hash` | `prev_hash` (chain link; None for genesis) |
     | `assessed_at_gate` | `record.assessed_at_gate` |
     | `assessed_by_skill` | `record.assessed_by_skill` |
     | `risk_tier` | `record.risk_tier` |
     | `inherited_from` | `record.inherited_from` |
     | `last_assessed` | `record.last_assessed` |
     | `schema_version` | `envelope.schema_version` (`"1.0"`) |
     | `classification` | `envelope.classification.value` |
     | `owner_scope` | `envelope.owner_scope` |
     | `owner_scope_type` | `envelope.owner_scope_type.value` |
     | `retention_policy` | `envelope.retention_policy.value` |
     | `profile_id` | `envelope.profile_id` |
     | `profile_schema_version` | `envelope.profile_schema_version` |

     Clause: `ON CONFLICT (content_hash) DO NOTHING RETURNING *` (`:266-267`).
     GOTCHA: `id`, `recorded_at`, `ratified*`, `superseded_by`, `producing_skill` are
     DB/default-generated (NOT written here). `producing_skill` (evidence_record.py:149)
     is a Phase-10 stored-row projection, never set by this INSERT.
   - **Idempotency race** (`:293-300`): if `ON CONFLICT` fired, `RETURNING *` yields no
     row → `row is None`. Then `raced = await self._get_by_hash(content_hash)`; if still
     `None`, `raise EvidenceWriteError("append failed: row neither inserted nor found by hash")`;
     else `stored = raced`.
   - Else `stored = _record_from_row(dict(row))` (`:302`).
6. **Persist mappings** (`:304-306`):
   `mapping_rows, dangling_seen = await self._persist_mappings(stored.id, mappings or [])`.
7. **Same-txn outbox event** (`:308-325`): `outbox_id = await enqueue_event(...)` with
   `EVIDENCE_CREATED_EVENT = "evidence.created"` and payload dict:
   ```
   {
     "aggregate_id": str(stored.id),
     "content_hash": stored.content_hash,
     "control_id": stored.control_id,
     "profile_id": envelope.profile_id,
     "owner_scope": envelope.owner_scope,
     "idempotency_key": stored.content_hash,
   }
   ```
   plus kwargs `aggregate_type="evidence_record"`, `aggregate_id=str(stored.id)`,
   `profile_id=envelope.profile_id`, `owner_scope=envelope.owner_scope`,
   `idempotency_key=stored.content_hash`.
   GOTCHA: `idempotency_key = content_hash` — a duplicate `evidence.created` is deduped
   downstream by the outbox drain (`:200-203` service docstring). The `content_hash` also
   appears BOTH inside the JSON payload AND as the top-level `idempotency_key` column.
8. `if commit: await self._db.commit()` (`:327-328`). Both activities pass `commit=True`.
9. Log `evidence_emitted` with `content_hash`, `control_id`, `assessed_at_gate`,
   `mapping_count`, `dangling_count`, `outbox_id` (`:330-338`).
10. `result = EmissionResult(stored, mapping_rows, outbox_id)` (`:340`).
    `EmissionResult.dangling = [m for m in mappings if m.status == "dangling"]` (`:79`).
11. **Dangle signaling** (`:341-345`): `if dangling_seen:` →
    `cat, ctrl = dangling_seen[0]; raise DanglingControlMapping(cat, ctrl)`.
    GOTCHA: the record + ALL mapping rows are ALREADY inserted (and committed if
    `commit=True`) BEFORE this raise. The dangle exception is a post-commit signal, not a
    rollback. Only the FIRST dangling pair is reported.
12. Else `return result`.

**D. `_persist_mappings`** (`:348-399`) — one `control_mapping` row per mapping:
For each `m` in `mappings`:
- `known = await self._control_exists(m.catalog_id, m.control_id)` (`:363`).
- `status = "active" if known else "dangling"` (`:364`).
- `ratified = known and await self._is_governed(m.catalog_id, m.control_id)` (`:365`).
- **INSERT INTO `control_mapping`** (`:366-383`):

  | column | value |
  |---|---|
  | `evidence_record_id` | `evidence_record_id` (the stored record's `id`) |
  | `catalog_id` | `m.catalog_id` |
  | `control_id` | `m.control_id` |
  | `status` | `status` (`active`/`dangling`) |
  | `ratified` | `ratified` (bool) |

  `RETURNING *`. If a row is returned → `ControlMappingRow(**dict(inserted))`; else
  (unreachable branch, `pragma: no cover`) build a `ControlMappingRow` with a fresh
  `uuid.uuid4()` id (`:384-396`).
- `if status == "dangling": dangling.append((m.catalog_id, m.control_id))` (`:397-398`).
- Returns `(rows, dangling)`.

`_control_exists` (`:145-166`) — dangling detection is against the **in-memory
compliance pack, NOT a DB table** (`:150-153`):
- `pack = active_compliance_pack()`.
- `if not pack.controls: return True` — GOTCHA: an EMPTY catalog (no active profile,
  e.g. automated test) treats every control as KNOWN, so nothing dangles (avoids false
  dangles, `:154-159`).
- `if catalog_id and catalog_id != pack.framework: return False` — a mapping referencing
  a different catalog than the active framework is dangling.
- `return any(c.id == control_id for c in pack.controls)`.
- `active_compliance_pack()` reads `active_profile()`'s `compliance.security` block
  (`compliance_pack.py:108-110`, `:82-105`); `framework` + `control_catalog` list →
  `ControlSpec(id, family, title)`; no active profile → agency-neutral fallback with
  EMPTY controls (never FAA).

`_is_governed` (`:168-179`):
`SELECT 1 FROM control_ratification WHERE catalog_id=:cat AND control_id=:cid LIMIT 1`.

### 1.6 The EXACT hash payload (content addressing)

Source: `evidence_ledger.py` (reused verbatim by the emit service, `:47-51`).

`_HASH_PAYLOAD_FIELDS` (`evidence_ledger.py:48-61`), in this literal set (order irrelevant
— canonicalizer sorts keys):
```
portfolio_id, application_id, control_id, family, status,
implementation_statement, evidence_refs, inherited_from,
assessed_at_gate, assessed_by_skill, risk_tier, last_assessed
```
- `canonical_payload(record)` (`:83-95`): `raw = record.model_dump()`;
  `return {k: _jsonable(raw.get(k)) for k in _HASH_PAYLOAD_FIELDS}`.
- `_jsonable` (`:64-80`): `UUID → str(value)`; anything with `.isoformat` (datetime/date)
  → `value.isoformat()`; dict → recurse; list/tuple → list of recursed; else passthrough.
- `_canonical_json` (`:98-110`): `json.dumps(payload, sort_keys=True, separators=(",",":"), ensure_ascii=False)`.
- `compute_content_hash` (`:113-127`): `sha256` of the UTF-8 canonical JSON, returns
  `f"sha256:{digest}"` (`HASH_PREFIX="sha256:"`, evidence_record.py:44-45).
- GOTCHA: `envelope.*` fields (classification/owner_scope/retention/profile_*) and the
  surrogate `id`/`recorded_at`/`prev_hash`/`ratified*` are DELIBERATELY OUTSIDE the hash
  payload — adding the envelope never changes the content hash (evidence_envelope.py:11-14).

### 1.7 Errors / retries / idempotency (`emit_evidence`)

- **Idempotency:** byte-identical content → same `content_hash` → `_get_by_hash` returns
  the existing row → NO new INSERT; the outbox event still enqueues with
  `idempotency_key=content_hash` for downstream dedupe (evidence_emit service `:200-203`).
  So re-running the activity with identical input is safe.
- **Retryability:** `EvidenceWriteError` (plain Exception, type name has no retryable
  substring) → wrapper → `NonRetryableError` → verdict path fails, no retry (REQ-EV-009).
  A UUID/enum parse `ValueError` → `NonRetryableError`. A connection/timeout error whose
  TYPE NAME contains a retryable substring → `RetryableError` (Temporal may retry per the
  workflow-set policy).
- **`DanglingControlMapping`** does NOT propagate out of the activity — it's caught at
  `:164` and returned as a successful result.
- No heartbeat, no explicit retry policy or timeout on the activity itself.

---

## 2. Activity `drift_control_eval`

File: `temporal/olympus_workflows/activities/drift_control_eval.py`.

### 2.1 Signature
```
@foundry_activity(config=ActivityConfig(enable_observability=True))     # :367
async def drift_control_eval(payload: DriftControlEvalInput) -> DriftControlEvalResult:  # :368-370
```

### 2.2 Module constants + pure config (`:66-133`)

- `DRIFT_CONTROL_ACTIONS = ("advisory", "at_risk", "block")` (`:66`) — weakest→strongest
  ordering used to pick the strongest action.
- `DEFAULT_CONTROL_ACTION_BY_SEVERITY = (("low","advisory"),("medium","at_risk"),("high","block"),("critical","block"))` (`:72-77`) — fallback ONLY when profile omits the map.
- `DriftControlConfig` (frozen dataclass, `:80-125`):
  - `severity_order: tuple[str,...] = DEFAULT_SEVERITY_ORDER` (drift engine default `("low","medium","high","critical")`).
  - `kind_severity: tuple[tuple[str,str],...] = ()`.
  - `action_by_severity: tuple[tuple[str,str],...] = DEFAULT_CONTROL_ACTION_BY_SEVERITY`.
  - `coverage_floor: float = 0.0`.
  - `_action_map` property → `dict(self.action_by_severity)` (`:100-102`).
  - `threshold_config` property → `DriftThresholdConfig(severity_order=self.severity_order, kind_severity=self.kind_severity)` (`:104-114`). GOTCHA: `reconcile_threshold` is left at its default `"high"` — the drift-control classifier only uses `severity_order`+`kind_severity`, so the threshold field is irrelevant here.
  - `action_for_severity(severity)` (`:116-125`): `action = self._action_map.get(severity); return action if action in DRIFT_CONTROL_ACTIONS else "advisory"`. GOTCHA: unmapped OR out-of-set severity → `"advisory"` (never silently blocks).
- `_action_rank(action)` (`:128-133`): `DRIFT_CONTROL_ACTIONS.index(action)` else `0`. So an unknown action ranks as advisory (0).

### 2.3 Pure verdict `DriftControlVerdict` + `evaluate_drift_control` (`:136-227`)

`DriftControlVerdict` (frozen, `:136-159`): `app_id`, `action`, `blocking`, `at_risk`,
`coverage_regressed`, `triggering_severity: str|None`, `reasons: tuple[str,...]=()`.
`is_clear` property → `self.action == "advisory"` (`:156-159`).

`evaluate_drift_control(report, config, *, coverage_pct=None)` (`:162-227`) — pure, total:
1. `classified = classify_report(report, config.threshold_config)` (`:187`). See §2.9 for
   `classify_report`/`classify_finding` semantics.
2. Init `reasons=[]`, `drift_action="advisory"`, `triggering_severity=None` (`:189-191`).
3. For each classified finding `c` (`:192-202`):
   - `if not c.blocking: continue` — GOTCHA: advisory/optional findings NEVER escalate the action.
   - `action = config.action_for_severity(c.severity)`.
   - `if _action_rank(action) > _action_rank(drift_action): drift_action = action; triggering_severity = c.severity` — keep the STRONGEST action, record the severity that produced it.
   - `if action in ("block","at_risk"): reasons.append(f"{c.kind} at {c.ref} (severity={c.severity}) -> {action}")`.
     GOTCHA: `triggering_severity` is set to whatever severity most-recently RAISED the
     max — with ties (same rank) the first-seen wins because `>` is strict; a later
     equal-rank finding does not overwrite it.
4. Coverage regression (`:204-212`):
   - `coverage_regressed=False`, `coverage_action="advisory"`.
   - `if coverage_pct is not None and coverage_pct < config.coverage_floor:` →
     `coverage_regressed=True; coverage_action="at_risk"; reasons.append(f"automated test coverage {coverage_pct:.4f} below floor {config.coverage_floor:.4f} -> at_risk")`.
     GOTCHA: `coverage_pct is None` = "not measured" → NEVER fabricates a regression.
     Coverage can only escalate UP TO `at_risk`, never to `block`.
5. `final_action = coverage_action if _action_rank(coverage_action) > _action_rank(drift_action) else drift_action` (`:214-218`).
6. Return `DriftControlVerdict(app_id=report.app_id, action=final_action, blocking=final_action=="block", at_risk=final_action=="at_risk", coverage_regressed=coverage_regressed, triggering_severity=triggering_severity, reasons=tuple(sorted(reasons)))` (`:219-227`).
   GOTCHA: `reasons` is SORTED (stable, order-independent output).

### 2.4 Advisory gate state `_gate_state` (`:230-239`)

```
predicates = drift_gate_predicates(report)
return "rejected" if any(not ok for ok in predicates.values()) else "approved"
```
Mirrors the `automated-only` provider's fold WITHOUT importing the provider (`:231-239`).
`drift_gate_predicates(report)` (drift.py:323-344) returns:
- `no_blocking_drift` = `report.blocking_count == 0`
- `no_orphan_citations` = no blocking `orphan_citation` finding
- `no_coverage_gaps` = no blocking coverage gap
GOTCHA: rejected iff ANY predicate is False.

### 2.5 Input `DriftControlEvalInput` (`:265-294`)

| field | type | default |
|---|---|---|
| `app_id` | `str` | (required) |
| `disposition_id` | `str` | (required) |
| `portfolio_id` | `str` | (required) |
| `profile_id` | `str` | (required) |
| `findings` | `list[DriftFindingInput]` | `[]` |
| `severity_order` | `list[str]` | `[]` |
| `kind_severity` | `list[tuple[str,str]]` | `[]` |
| `action_by_severity` | `list[tuple[str,str]]` | `[]` |
| `coverage_floor` | `float` | `0.0` |
| `coverage_pct` | `float \| None` | `None` |
| `application_id` | `str \| None` | `None` |
| `evidence_controls` | `list[ControlMappingInput]` | `[]` |
| `emit_evidence` | `bool` | `True` |

`DriftFindingInput` (`:242-254`): `kind: str`, `citation: str`, `detail: str=""`,
`blocking: bool=True`. `ControlMappingInput` (`:257-262`): `catalog_id`, `control_id`.

### 2.6 Output `DriftControlEvalResult` (`:297-320`)
```
app_id, disposition_id, action, blocking, at_risk, coverage_regressed, gate_state,
triggering_severity: str|None = None,
reasons: list[str] = [],
evidence_content_hash: str|None = None,
evidence_emitted: bool = False,
evaluated_at: str = ""
```

### 2.7 `compute_verdict` + helpers (`:323-364`)

- `_config_from_input(payload)` (`:323-336`):
  - `order = tuple(payload.severity_order) or DEFAULT_SEVERITY_ORDER`.
  - `action_map = tuple((str(k),str(v)) for k,v in payload.action_by_severity) or DEFAULT_CONTROL_ACTION_BY_SEVERITY`.
    GOTCHA: an EMPTY `action_by_severity` list falls back to the default map (empty tuple
    is falsy).
  - `kind_map = tuple((str(k),str(v)) for k,v in payload.kind_severity)`.
  - Returns `DriftControlConfig(severity_order=order, kind_severity=kind_map, action_by_severity=action_map, coverage_floor=float(payload.coverage_floor))`.
- `_report_from_input(payload)` (`:339-355`): builds a `DriftReport(app_id=payload.app_id, findings=tuple(DriftFinding(kind, citation, detail, blocking) for f in payload.findings))`.
  GOTCHA: only `findings` populated — `coverage_gaps` stays empty; coverage gaps are
  carried as `coverage_gap`-kind findings (`:341-345`).
- `compute_verdict(payload)` (`:358-364`): pure — `evaluate_drift_control(_report_from_input(payload), _config_from_input(payload), coverage_pct=payload.coverage_pct)`. Extracted for unit tests (no IO).

### 2.8 Activity body — the branching (`:367-442`)

`evaluated_at = datetime.now(timezone.utc)` (`:380`). REQ-DC: timestamp captured HERE.

**Branch A — inline findings OR no-emit (`:386-402`):**
`if payload.findings or not payload.emit_evidence:`
- `report = _report_from_input(payload)`; `config = _config_from_input(payload)`.
- `verdict = evaluate_drift_control(report, config, coverage_pct=payload.coverage_pct)`.
- `result = _result(payload, verdict, _gate_state(report), evaluated_at)`.
- `if not payload.emit_evidence: return result` (`:393-394`) — pure verdict, NO DB touched.
  GOTCHA: with `emit_evidence=False` the activity never imports/opens a DB — safe in a
  DB-less env.
- Else (inline findings + emit): `return await _emit_for_verdict(payload, verdict, result, evaluated_at, mappings_override=[(m.catalog_id, m.control_id) for m in payload.evidence_controls])` (`:397-402`).
  GOTCHA: the inline path uses the INLINE `evidence_controls` mappings (not a profile
  lookup).

**Branch B — production/resolved path (`:404-442`):** taken when `findings` is empty AND
`emit_evidence` is True.
- LAZY import `src.database.get_db`, `src.services.drift_control.evaluation.{DriftControlEvaluator, evidence_controls, load_drift_control_config}` (`:405-410`).
- `db_gen = get_db(); session = await db_gen.__anext__()` (`:412-413`).
- `try:` (`:414-440`):
  - `config = load_drift_control_config(payload.profile_id)` — loads profile DATA from
    `profiles/<p>/drift.yaml` (§2.10).
  - `evaluator = DriftControlEvaluator(session)`.
  - `verdict = await evaluator.evaluate(app_id=payload.app_id, profile_id=payload.profile_id, coverage_pct=payload.coverage_pct, config=config)` — reads the LATEST persisted `drift_report` findings and runs the pure engine (§2.10). GOTCHA: production IGNORES `payload.findings` (empty here anyway) and `payload.severity_order`/`action_by_severity` — it resolves them from the DB + profile, so it "actually blocks on a real high-severity report" (`:383-385`).
  - `resolved_findings = await evaluator.latest_findings(payload.app_id)` (`:424`) — rebuilt AGAIN so the gate predicates agree with the verdict's finding set.
  - `report = DriftReport(app_id=payload.app_id, findings=tuple(resolved_findings))` (`:425-427`).
  - `result = _result(payload, verdict, _gate_state(report), evaluated_at)` (`:428`).
  - `emission_hash = await _emit_on_session(session, payload, verdict, evaluated_at, mappings=evidence_controls(payload.profile_id))` (`:430-436`) — profile-resolved control mappings.
  - `if emission_hash is not None: result.evidence_content_hash = emission_hash; result.evidence_emitted = True` (`:437-439`).
  - `return result`.
- `finally: await db_gen.aclose()` (`:441-442`).

GOTCHA (double read): `latest_findings` is queried TWICE in Branch B — once inside
`evaluator.evaluate` (via `evaluate`'s own `latest_findings` call, evaluation.py:172) and
once directly at `:424`. Both read the same latest `drift_report`, so verdict and gate
state agree, at the cost of two SELECTs.

### 2.9 `_result` / `_emit_for_verdict` / `_emit_on_session`

`_result(payload, verdict, gate_state, evaluated_at)` (`:445-463`) — flatten:
```
DriftControlEvalResult(
  app_id=verdict.app_id, disposition_id=payload.disposition_id,
  action=verdict.action, blocking=verdict.blocking, at_risk=verdict.at_risk,
  coverage_regressed=verdict.coverage_regressed, gate_state=gate_state,
  triggering_severity=verdict.triggering_severity,
  reasons=list(verdict.reasons),
  evaluated_at=evaluated_at.isoformat(),
)
```
`evidence_content_hash`/`evidence_emitted` left at defaults (None/False) here — set later
if emission succeeds.

`_emit_for_verdict(payload, verdict, result, evaluated_at, *, mappings_override)` (`:466-488`):
opens a FRESH session (`get_db`/`__anext__`), calls
`_emit_on_session(session, payload, verdict, evaluated_at, mappings=mappings_override)` in
a try/`finally: aclose()`, then sets `result.evidence_content_hash`/`evidence_emitted` if
the hash is non-None. Returns `result`.

`_emit_on_session(session, payload, verdict, evaluated_at, *, mappings)` (`:491-560`) —
REQ-DC-006 evidence write:
1. `import uuid as _uuid`; lazy import `ControlMapping`, `CtEnvelope`,
   `EvidenceRecordInput`, `EvidenceEmitService`, `EvidenceWriteError` (`:504-512`).
2. `control_pairs = mappings or []` (`:514`).
3. `primary_control = control_pairs[0][1] if control_pairs else "CA-7"` (`:515`).
   GOTCHA: **hardcoded fallback `"CA-7"`** (NIST continuous-monitoring control) when no
   mapping is supplied — this is the one place a control id is defaulted in code.
4. `control_mappings = [ControlMapping(catalog_id=cat, control_id=ctrl) for cat,ctrl in control_pairs]` (`:516-519`).
5. Build `EvidenceRecordInput` (`:520-546`):

   | field | value |
   |---|---|
   | `portfolio_id` | `_uuid.UUID(payload.portfolio_id)` |
   | `application_id` | `_uuid.UUID(payload.application_id) if payload.application_id else None` |
   | `control_id` | `primary_control` |
   | `family` | `"CA"` (hardcoded) |
   | `status` | `"implemented" if verdict.is_clear else "partial"` |
   | `implementation_statement` | `f"Drift-control verdict for {payload.disposition_id} (app {payload.app_id}): action={verdict.action}, coverage_regressed={verdict.coverage_regressed}."` |
   | `evidence_refs` | `[{"ref_type":"drift_control_verdict","artifact":payload.disposition_id,"finding_id":payload.app_id,"description":"; ".join(verdict.reasons) or "no blocking drift"}]` |
   | `assessed_at_gate` | `DRIFT_GATE_ID` (`"G-DRIFT"`) |
   | `assessed_by_skill` | `"drift-control"` |
   | `last_assessed` | `evaluated_at` |

   GOTCHA: `family` fixed to `"CA"` regardless of the actual `primary_control` family —
   if a profile maps a non-CA control this may mismatch. `status` is derived from
   `verdict.is_clear` (advisory → implemented; at_risk/block → partial).
6. `envelope = CtEnvelope(profile_id=payload.profile_id, owner_scope=payload.app_id)` (`:547`).
   GOTCHA: classification/owner_scope_type/retention default (unclassified / portfolio /
   standard); `owner_scope` is the APP id (a string), while `owner_scope_type` stays
   `portfolio` — a mild inconsistency, but it's what's written.
7. `emitter = EvidenceEmitService(session)` (`:548`).
8. `try: emission = await emitter.emit(record, envelope=envelope, mappings=control_mappings or None, subject_kind="side_effect", subject_id=f"drift-control:{payload.disposition_id}:{verdict.action}", commit=True)` (`:549-557`).
   - `subject_kind="side_effect"` (drift-control is a declared side effect).
   - `subject_id` encodes disposition + action, so suppression can target a specific
     verdict class.
   - `mappings=control_mappings or None` — empty list → `None`.
9. `except EvidenceWriteError: raise` (`:558-559`) — fail-closed (REQ-DC-006 mirrors
   REQ-EV-009).
10. `return emission.record.content_hash if emission is not None else None` (`:560`).
    GOTCHA: `emission is None` means the emit was SUPPRESSED (subject in
    `evidence_suppression`) → returns None → `evidence_emitted` stays False, but the
    verdict result is still returned.
    GOTCHA: `DriftControlEvalResult.evidence_content_hash` is set from THIS hash — note
    the pure verdict is ALWAYS returned regardless of emission outcome; a suppressed or
    disabled emission just leaves `evidence_content_hash=None`, `evidence_emitted=False`.

### 2.10 Production resolution (`DriftControlEvaluator`, `load_drift_control_config`, `evidence_controls`)

Source: `olympus-api/src/services/drift_control/evaluation.py` (Branch B only).

`load_drift_control_config(profile_id, *, profiles_root=None)` (`:63-96`):
- `root = profiles_root or _PROFILES_ROOT` where `_PROFILES_ROOT = _resolve_profiles_root()`.
- `_resolve_profiles_root()` (`:50-57`): env `OLYMPUS_PROFILE_ROOT` first (must contain a
  `profiles/` subdir), else walk `Path(__file__).resolve().parents` for the first dir
  containing `profiles/`, else `Path("/app")/"profiles"`. GOTCHA: replaces a fragile
  fixed `parents[4]` that resolved to `/` in Docker (`:44-49`).
- `thresholds = load_drift_thresholds(profile_id, profiles_root=root)` — reuses FILE-2
  loader for `severity_order` + `kind_severity`.
- Reads `<root>/<profile_id>/drift.yaml` if present (`:79-89`): `block = data["drift"]`;
  `control_action_by_severity` map → `action_map` (tuple of str pairs); `coverage_floor`
  → float if not None. Missing keys → engine defaults (`DEFAULT_CONTROL_ACTION_BY_SEVERITY`,
  floor 0.0).
- Returns `DriftControlConfig(severity_order=thresholds.severity_order or DEFAULT_SEVERITY_ORDER, kind_severity=thresholds.kind_severity, action_by_severity=action_map, coverage_floor=coverage_floor)`.

`DriftControlEvaluator(db)` (`:99-183`):
- `latest_findings(app_id, spec_artifact=None)` (`:111-153`): builds WHERE `app_id=:app_id`
  (+ `spec_artifact=:spec` if given), `SELECT findings FROM drift_report WHERE {where} ORDER BY recorded_at DESC, id DESC LIMIT 1`. `row is None` → `[]` (never-evaluated app is trivially clean). Each persisted finding JSON → `DriftFinding(kind=f.get("kind","coverage_gap"), citation=f.get("ref",""), detail=f.get("detail",""), blocking=bool(f.get("blocking",True)))`. GOTCHA: persisted findings carry a classified `severity`, but the engine finding drops it — severity is RE-DERIVED from `kind` by the same profile ladder, so classification is consistent.
- `evaluate(*, app_id, profile_id, spec_artifact=None, coverage_pct=None, config=None)` (`:155-183`): `cfg = config or load_drift_control_config(profile_id)`; `findings = await latest_findings(app_id, spec_artifact)`; `report = DriftReport(app_id=app_id, findings=tuple(findings))`; `verdict = evaluate_drift_control(report, cfg, coverage_pct=coverage_pct)`; logs `drift_control_evaluated`; returns verdict.

`evidence_controls(profile_id)` (`:186-192`): thin re-export of
`evidence_controls_for_profile(profile_id)` (FILE-2 profile loader) → `list[(catalog_id, control_id)]`. One shared DATA source for the mapping (no second hardcoded id).

### 2.11 `classify_report` / `classify_finding` (drift engine, reused)

Source: `temporal/olympus_workflows/drift.py`.
- `classify_report(report, config)` (`:536-567`): for each `report.findings` →
  `classify_finding(kind=f.kind, ref=f.citation, detail=f.detail, blocking=f.blocking, config=config)`; then for each `report.coverage_gaps` → `classify_finding(kind="coverage_gap", ref=g.ref, detail=g.detail, blocking=g.blocking, config=config)`. Findings first, then gaps.
- `classify_finding(...)` (`:501-533`): `base = config.base_severity_for_kind(kind)`;
  `severity = base`; **if `blocking`**: `base_rank = config.rank(base)`; if `0 <= base_rank < len(order)-1`: `severity = order[base_rank+1]` (escalate one rung, capped at top). `at_or_above_threshold` compared vs `reconcile_threshold`. GOTCHA: a BLOCKING finding is escalated ONE severity rung above its profile base before the drift-control action map is applied — so a `kind` mapped to `medium` that is blocking classifies as `high`, which (with the default map) reaches `block`.
- `base_severity_for_kind(kind)` (`:450-461`): profile `kind_severity` map, else the
  lowest ladder rung `order[0]`.
- `rank(severity)` (`:438-448`): index in `severity_order`, unknown label → `-1`.

### 2.12 Errors / retries / idempotency (`drift_control_eval`)

- **Idempotency:** the emitted evidence record is content-addressed exactly as §1.6, so
  re-running with identical resolved state does not create a duplicate row (the emit
  service short-circuits on `_get_by_hash`). BUT `evaluated_at` (=`last_assessed`, a
  hash-payload field) is a fresh clock read each run — GOTCHA: a re-run at a DIFFERENT
  wall-clock time produces a DIFFERENT `last_assessed` → DIFFERENT `content_hash` → a NEW
  evidence row appended to the chain. So the activity is idempotent only within the same
  captured timestamp; retries by Temporal (which reuse the same activity task) do get a
  fresh `datetime.now` on each attempt.
- **Retryability:** `EvidenceWriteError` → `NonRetryableError` (fail-closed). A UUID parse
  error → `NonRetryableError`. Connection/timeout (type-name match) → `RetryableError`.
- **`emit_evidence=False`**: pure verdict, no DB, always returns a result — cannot fail on
  durability.
- No heartbeat; no activity-level retry policy/timeout (governed by the workflow's
  `execute_activity` and by the error `non_retryable` flags).
- **Determinism:** verdict logic + timestamp live in the activity, never workflow code
  (`:1-9`, `:371-379`). `reasons` sorted for stable output.

---

## 3. Registration note

Neither `emit_evidence` nor `drift_control_eval` appears in the registries under
`temporal/olympus_workflows/registries/` nor is wired with an explicit `RetryPolicy` in
`olympus-worker/` (grep returned nothing). They are plain `@foundry_activity` activities
whose retry/timeout are set by the scheduling workflow's `execute_activity(...)` call and
whose terminal-vs-retryable classification is driven entirely by the wrapper's error
typing described in §0.
