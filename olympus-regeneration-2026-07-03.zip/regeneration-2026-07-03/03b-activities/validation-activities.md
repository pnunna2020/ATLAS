# Validation Activities — Atomic Regeneration Spec

**Group:** `artifact_validation.py`, `devsecops_validation.py`, `profile_devsecops.py`
**Location:** `temporal/olympus_workflows/activities/` (paths below are relative to repo root)
**Baseline:** live code at `/Users/pnunna/Documents/GitHub/olympus`, main, 2026-07-03

This group contains **3 `@foundry_activity`-decorated activity functions**:

| # | Activity name | File | Signature |
|---|---|---|---|
| 1 | `validate_artifact_against_schema` | `artifact_validation.py` | `(ValidateArtifactInput) -> ValidateArtifactResult` |
| 2 | `validate_devsecops_baseline` | `devsecops_validation.py` | `(ValidateDevSecOpsBaselineInput) -> ValidateDevSecOpsBaselineResult` |
| 3 | `resolve_devsecops_profile` | `profile_devsecops.py` | `(ResolveDevSecOpsProfileInput) -> ResolveDevSecOpsProfileResult` |

None of these are `persist_*` activities (no DB writes), no Git activities, and no agent-dispatch activities. They are **pure/read-only validators and a profile resolver**. All three delegate to a pure (no-Temporal-context) helper so the core is unit-testable; the `@foundry_activity` wrapper adds only observability + error wrapping.

---

## 0. `@foundry_activity` wrapper — what it adds over raw `activity.defn`

Source: `temporal/olympus_workflows/temporal_base/activities.py:79-150`.

All three activities are decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`. The decorator (`activities.py:79`) returns a `decorator` that:

1. Resolves `activity_config = config or ActivityConfig()` (`activities.py:98`).
2. Wraps the function in `@activity.defn(name=name, **activity_kwargs)` + `@wraps(func)` (`activities.py:100-101`). Since `name=None` at all three call sites, the Temporal activity **name defaults to the Python function name** (`activities.py:16`, `:103`) — Temporal replay keys on this, so the registered names are exactly `validate_artifact_against_schema`, `validate_devsecops_baseline`, `resolve_devsecops_profile`.
3. **Observability** (`activities.py:105-131`): when `enable_observability=True` (default and explicit here), logs via stdlib `logging` (`activities.py:38`, logger name = `olympus_workflows.temporal_base.activities`):
   - `"Activity %s starting"` before the call, `extra={"inputs": args if log_inputs else None}` (`activities.py:106-110`). `log_inputs` defaults `False` (`activities.py:52`) → inputs are NOT logged.
   - `"Activity %s completed"` after success, `extra={"outputs": result if log_outputs else None}` (`activities.py:115-120`). `log_outputs` defaults `False` → outputs NOT logged.
   - On exception: `logger.error("Activity %s failed: %s", ...)` with `extra={"error": str(error)}` (`activities.py:125-131`).
4. **Error wrapping** (`activities.py:133-146`), when `enable_error_wrapping=True` (default `True`, `activities.py:51`):
   - Already-typed `WorkflowError` / `ApplicationError` → **re-raised unchanged** (`activities.py:135-136`). This is why `validate_artifact_against_schema`'s `NonRetryableError` (schema missing) passes through with its `non_retryable=True` flag intact.
   - Else if `_is_retryable_error(error)` (type-name substring match, `activities.py:56-76`) → wrapped in `RetryableError(f"Retryable error in {name}: {error}")` (`non_retryable=False`, `errors.py:23-27`).
   - Else → wrapped in `NonRetryableError(f"Non-retryable error in {name}: {error}")` (`non_retryable=True`, `errors.py:30-34`).
5. `ActivityConfig` (`activities.py:41-53`) fields NOT set at these call sites (all `None`/default): `retry_policy=None`, all timeouts `None`, `heartbeat_timeout=None`. **GOTCHA:** none of these activities set a `retry_policy`, `start_to_close_timeout`, or `heartbeat_timeout` on the decorator — retry/timeout policy is entirely inherited from whatever the calling workflow passes to `execute_activity(...)`. **No heartbeating** is emitted by any of the three; they are short synchronous CPU/FS work.

`_is_retryable_error` (`activities.py:56-76`) classifies by `str(type(error)).lower()` containing any of: `timeout, connection, network, temporary, unavailable, overload, busy, throttle, rate_limit`. **GOTCHA:** this is a **type-name string match**, distinct from `errors.is_retryable_error` (which inspects httpx/OSError instances) — `activities.py:57-62`. For these validators the practical effect: any stray exception whose class name doesn't contain one of those substrings becomes `NonRetryableError` (i.e. FS/JSON/YAML errors are treated non-retryable by default).

`RetryPolicy` import at `activities.py:33` is unused by these three (no per-activity policy).

---

## 1. `validate_artifact_against_schema`

File: `temporal/olympus_workflows/activities/artifact_validation.py`
Decorator: `artifact_validation.py:379`
Function: `artifact_validation.py:380-432`

### 1.1 Signature & I/O types

```python
async def validate_artifact_against_schema(input: ValidateArtifactInput) -> ValidateArtifactResult
```

**`ValidateArtifactInput`** (`types.py:666-679`):
- `artifact_filename: str` — logical filename key (e.g. `"disposition-recommendation.json"`), looked up in `_SCHEMA_REGISTRY`.
- `raw_content: str` — unparsed string the agent produced (may include markdown fences / preamble).

**`ValidateArtifactResult`** (`types.py:682-705`):
- `validated: bool`
- `parsed_payload: dict | None`
- `errors: list[str] = field(default_factory=list)`

Semantics (`artifact_validation.py:395-408`): `validated=True` iff filename in registry AND payload parsed to dict AND schema loaded. `validated=False` means "nothing to check" or "couldn't parse" — NOT "payload bad". `errors` is human-readable, capped at 8 (see §1.4).

### 1.2 Exact control flow (NEVER collapse)

`artifact_validation.py:410-432`:

1. `filename = input.artifact_filename` (`:410`).
2. **Branch A — unknown filename** (`:411-414`): `if not _known_artifact(filename)` (`_known_artifact` = `filename in _SCHEMA_REGISTRY`, `:349-351`) → return `ValidateArtifactResult(validated=False, parsed_payload=None, errors=[])`. **Early return.** No schema loaded, no parse attempted.
3. `parsed = parse_agent_json(input.raw_content)` (`:416`) — see §1.5.
4. **Branch B — parse failed / not a dict** (`:417-426`): `if not isinstance(parsed, dict)` → return `ValidateArtifactResult(validated=False, parsed_payload=None, errors=[f"{filename}: agent output could not be parsed as a JSON object (even with markdown-fence-stripping and brace-scanning fallbacks)."])`. **Early return.** **GOTCHA:** a top-level JSON *list* returned by `parse_agent_json` (valid but not a dict) also hits this branch — `validated=False` with the parse-error message even though JSON was well-formed.
5. `schema = _load_schema(_SCHEMA_REGISTRY[filename])` (`:428`) — see §1.3. **May raise `NonRetryableError`.**
6. `errors = _validate_payload(parsed, schema)` (`:429`) — see §1.4.
7. **Success path** (`:430-432`): return `ValidateArtifactResult(validated=True, parsed_payload=parsed, errors=errors)`. Note `errors` may be non-empty here (schema violations on a parsed-but-wrong-shape dict) — `validated=True` still, with the violation list.

### 1.3 `_load_schema` (`artifact_validation.py:354-360`)

```python
def _load_schema(schema_path: Path) -> dict:
    if not schema_path.exists():
        raise NonRetryableError(f"schema not found at {schema_path}. Check your repo layout.")
    with schema_path.open() as handle:
        return json.load(handle)
```
- Missing schema file → `NonRetryableError` (`:356-358`). This is the ONLY exception the activity intentionally raises for a validation call; per the module docstring (`:406-408`) it signals an environmental/build bug, not an agent-output problem. It passes through the wrapper unchanged (§0.4, `WorkflowError` subclass).
- Malformed schema JSON → `json.load` raises `json.JSONDecodeError` (a `ValueError` subclass) → **not** a `WorkflowError`/`ApplicationError`, type name `JSONDecodeError` doesn't match retryable substrings → wrapped as `NonRetryableError` by the decorator.

### 1.4 `_validate_payload` (`artifact_validation.py:363-376`)

```python
validator = Draft202012Validator(schema)          # :370
errors = list(validator.iter_errors(payload))      # :371
if not errors: return []                            # :372-373
return [f"  {err.json_path or '<root>'}: {err.message}" for err in errors[:8]]  # :374-376
```
- Uses `jsonschema.Draft202012Validator` (import `artifact_validation.py:70`) — **JSON-Schema 2020-12 draft**.
- Collects ALL errors via `iter_errors`, then **truncates to first 8** (`errors[:8]`, `:375`). **GOTCHA:** if there are >8 violations, only the first 8 are surfaced; the count is not reported.
- Each message: two leading spaces + `err.json_path` (or literal `"<root>"` when json_path is empty/falsy) + `": "` + `err.message` (`:375`).
- Never raises (docstring `:364-368`) — validation errors are data, not exceptions.

### 1.5 `parse_agent_json` (markdown-fence-tolerant parser)

Source: `temporal/olympus_workflows/utils/__init__.py:29-92`. Exact algorithm:
1. `if not raw or not isinstance(raw, str): return None` (`:44`).
2. `s = raw.strip()` (`:46`).
3. **Fast path** (`:48-53`): `json.loads(s)`; on `ValueError/TypeError` → `parsed=None`. If result is `dict` or `list` → return it.
4. **Fence strip** (`:54-62`): regex `_FENCE_RE = re.compile(r"^\s*```(?:json|jsonc)?\s*\n(.*?)\n```\s*$", re.DOTALL)` (`:26`). If it matches, `json.loads(m.group(1))`; if dict/list → return.
5. **Balanced-brace fallback** (`:63-91`): find first `{`; scan tracking `depth`, `in_str`, `esc` so braces inside strings don't miscount; when `depth` returns to 0, `json.loads(s[start:i+1])` and return (or `None` on failure). Only recovers the first `{...}` OBJECT — a top-level array only survives via the fast path / fence path.
6. Return `None` if nothing parseable (`:92`).

**GOTCHA:** `parse_agent_json` can return a `list` (fast/fence path), which then fails the `isinstance(parsed, dict)` check in Branch B (§1.2 step 4).

### 1.6 Schema registry & directory resolution

**`_SCHEMAS_DIR = _resolve_schemas_dir()`** computed at import time (`artifact_validation.py:118`). `_resolve_schemas_dir` (`:85-115`) checks candidates in order and returns first that `.is_dir()`:
1. `$OLYMPUS_SCHEMAS_DIR` if set (`:106-108`).
2. `Path(__file__).resolve().parents[3] / "schemas"` — dev repo layout (`:109`). (`activities/` → `olympus_workflows/` → `temporal/` → repo root, then `/schemas`.)
3. `/app/schemas` (`:110`).
4. `/app/repo/schemas` (`:111`).
- Fallback if none is a dir: returns `candidates[1]` (the `parents[3]/schemas` path) so the downstream `_load_schema` error is informative (`:115`). **GOTCHA:** resolution is at import time; changing env after import has no effect.

**`_SCHEMA_REGISTRY`** (`artifact_validation.py:124-346`) — full `dict[str, Path]` mapping of artifact filename → `_SCHEMAS_DIR / <sub> / <schema file>`. Reproduce EXACTLY:

Rationalization:
- `disposition-recommendation.json` → `rationalization/disposition-recommendation.schema.json` (`:125-127`)
- `classification.json` → `rationalization/classification.schema.json` (`:128-130`)
- `portfolio-score.json` → `rationalization/portfolio-score.schema.json` (`:131-133`)
- `redundancy-matrix.json` → `rationalization/redundancy-matrix.schema.json` (`:134-136`)
- `portfolio-redundancy-matrix.json` → `rationalization/rationalization-clustering-plan.schema.json` (`:145-149`) — **GOTCHA:** filename says "redundancy-matrix" but maps to the *clustering-plan* schema (migration 052 rat-cap clustering replaced the shape; filename preserved for grep stability, docstring `:137-144`).
- `shared-identity-report.json` → `rationalization/shared-identity-report.schema.json` (`:150-152`)
- `wave-outcome-synthesis.json` → `rationalization/wave-outcome-synthesis.schema.json` (`:153-155`)
- `intra-app-redundancy.json` → `rationalization/redundancy-matrix.schema.json` (`:160-162`) — aliases same schema as cross-app redundancy-matrix.
- `ux-overlap-matrix.json` → `rationalization/ux-overlap-matrix.schema.json` (`:166-168`)
- `business-rule-redundancy.json` → `rationalization/business-rule-redundancy.schema.json` (`:173-177`)
- `integration-graph.json` → `rationalization/integration-graph.schema.json` (`:182-184`)
- `disposition-governance.json` → `rationalization/disposition-governance.schema.json` (`:188-192`)
- `user-impact-analysis.json` → `rationalization/user-impact-analysis.schema.json` (`:197-201`)
- `wave-plan.json` → `rationalization/wave-plan.schema.json` (`:206-208`)
- `wave-plan-validation.json` → `rationalization/wave-plan-validation.schema.json` (`:209-213`)

Discovery:
- `application-catalog-entry.json` → `discovery/catalog.schema.json` (`:218-220`)
- `business-logic.json` → `discovery/business-logic.schema.json` (`:224-226`)
- `quality-risk.json` → `discovery/quality-risk.schema.json` (`:229-231`)
- `ux-accessibility.json` → `discovery/ux-accessibility.schema.json` (`:235-237`)
- `discovery-synthesis.json` → `discovery/discovery-synthesis.schema.json` (`:240-242`)
- `capability-catalog.json` → `discovery/capability-catalog.schema.json` (`:246-248`)

Architecture:
- `architecture-blueprint.json` → `architecture/architecture-blueprint.schema.json` (`:256-260`)
- `cloud-pattern.json` → `architecture/cloud-pattern.schema.json` (`:261-263`)
- `target-application-map.json` → `architecture/target-application-map.schema.json` (`:264-268`)
- `architecture-target-plan.json` → `architecture/architecture-target-plan.schema.json` (`:276-280`)
- `cost-estimate.json` → `architecture/cost-estimate.schema.json` (`:281-283`)
- `ea-compliance-report.json` → `architecture/ea-compliance.schema.json` (`:288-290`)
- `ea-compliance.json` → `architecture/ea-compliance.schema.json` (`:291-293`) — **GOTCHA:** both filenames alias the same schema (docstring `:284-287`).
- `api-contract-compliance-report.json` → `architecture/integration-arch.schema.json` (`:294-296`) — **GOTCHA:** aliases the integration-arch schema (not a distinct one).
- `integration-arch.json` → `architecture/integration-arch.schema.json` (`:297-299`)
- `security-arch.json` → `architecture/security-arch.schema.json` (`:300-302`)
- `design-system.json` → `architecture/design-system.schema.json` (`:303-305`)
- `accessibility-review.json` → `architecture/accessibility-review.schema.json` (`:306-310`)
- `ai-ml-integration.json` → `architecture/ai-ml-integration.schema.json` (`:311-315`)
- `well-architected-review.json` → `architecture/well-architected-review.schema.json` (`:316-320`)

Data:
- `data-domains.json` → `data/data-domains.schema.json` (`:322-324`)
- `shared-db-analysis.json` → `data/shared-db-analysis.schema.json` (`:325-327`)
- `decomposition-strategy.json` → `data/decomposition-strategy.schema.json` (`:328-330`)
- `data-migration-plan.json` → `data/data-migration-plan.schema.json` (`:331-333`)
- `data-product-design.json` → `data/data-product-design.schema.json` (`:340-342`)
- `data-architecture.json` → `data/data-architecture.schema.json` (`:343-345`)

**Extending:** adding a `(filename, schema_path)` entry to `_SCHEMA_REGISTRY` enables validation for that artifact automatically (docstring `:55-57`, `:121-123`).

### 1.7 Errors / retries / idempotency (activity 1)

- **Never raises for validation outcomes** — always returns a result (docstring `:388-393`). The only raise is `NonRetryableError` on missing/malformed schema file (§1.3) → `non_retryable=True`, Temporal will not retry.
- **Idempotent & deterministic:** pure function of `input` + on-disk schema files; no side effects, no DB, no network, no Git. Safe to retry/replay.
- No `retry_policy`/`heartbeat` on the decorator (§0.5).

---

## 2. `validate_devsecops_baseline`

File: `temporal/olympus_workflows/activities/devsecops_validation.py`
Decorator: `devsecops_validation.py:284`
Activity: `devsecops_validation.py:285-311`; pure core `validate_baseline` at `:234-281`.

Purpose (module docstring `:1-17`): deterministic confirmation that the **agent-generated** DevSecOps baseline is complete + structurally sound. Authors nothing. Its boolean `passed` **gates G-04c** (`:16`, `:289-292`).

### 2.1 Signature & I/O types

```python
async def validate_devsecops_baseline(input: ValidateDevSecOpsBaselineInput) -> ValidateDevSecOpsBaselineResult
```

**`ValidateDevSecOpsBaselineInput`** (`types.py:734-751`):
- `app_id: str`
- `committed_files: list[tuple[str, str]]` — `(repo_path, content)` pairs the workflow just committed to the target repo root.
- `sast_tool: str = "codeql"` — profile-driven; `ci.yml` must name this SAST tool.

**`ValidateDevSecOpsBaselineResult`** (`types.py:754-768`):
- `app_id: str`
- `passed: bool` (G-04c gating signal)
- `missing: list[str] = []`
- `errors: list[str] = []`
- `files_checked: int = 0`

### 2.2 Activity wrapper flow (`devsecops_validation.py:285-311`)

1. `if isinstance(input, dict): input = ValidateDevSecOpsBaselineInput(**input)` (`:294-295`) — **GOTCHA:** tolerates a raw dict (Temporal payload deserialization edge) by re-hydrating the dataclass.
2. `result = validate_baseline(input)` (`:296`).
3. `if not result.passed:` → `logger.warning("DevSecOps baseline validation failed for app %s: missing=%s errors=%s", app_id, missing, errors)` (`:297-304`); else `logger.info("DevSecOps baseline validated for app %s (%d files)", app_id, files_checked)` (`:305-310`).
4. `return result` (`:311`). **No raising** on failure — `passed=False` is a value, the workflow gates on it.

### 2.3 `validate_baseline` pure core (`devsecops_validation.py:234-281`) — exact steps

1. `by_path = {_normalize(p): c for p, c in (input.committed_files or [])}` (`:241-243`). **GOTCHA:** a duplicate normalized path silently keeps the LAST content (dict-comp overwrite). `input.committed_files or []` guards `None`.
2. `_normalize` (`:52-58`): strip leading `./` repeatedly (`while norm.startswith("./"): norm = norm[2:]`), then `norm.lstrip("/")`. **GOTCHA:** it strips `./` and leading `/` but preserves a leading dot so `.github` stays `.github` (docstring `:53-54`).
3. `missing=[]`, `errors=[]` (`:245-246`).
4. **Required-file presence loop** (`:248-250`): for each `required in REQUIRED_BASELINE_FILES` (§2.4), if `_normalize(required) not in by_path` → append the ORIGINAL `required` string (not normalized) to `missing`.
5. **ci.yml structural check** (`:253-255`): `ci = by_path.get(".github/workflows/ci.yml")`; `if ci is not None: _check_ci_yaml(ci, input.sast_tool, errors)` (§2.5). Only runs if the file was passed.
6. **dependabot.yml** (`:257-259`): `_check_yaml_parses(".github/dependabot.yml", dependabot, errors)` if present.
7. **branch-protection.yml** (`:261-265`): `_check_yaml_parses(".github/branch-protection.yml", branch_protection, errors)` if present.
8. **IaC manifest** (`:270-272`): iterate all `by_path` items; `if path.endswith("iac-manifest.json"): _validate_iac_manifest(content, errors)` (§2.6). **GOTCHA:** matches on basename suffix so either the root or a namespaced evidence path (`modernization/{app}/generate/.../iac-manifest.json`) triggers validation; multiple matches all validate.
9. `passed = not missing and not errors` (`:274`) — passes only when BOTH lists empty.
10. `return ValidateDevSecOpsBaselineResult(app_id=input.app_id, passed=passed, missing=missing, errors=errors, files_checked=len(by_path))` (`:275-281`). `files_checked` = count of distinct normalized paths.

### 2.4 `REQUIRED_BASELINE_FILES` (`devsecops_contract.py:48-64`)

Exact tuple (order preserved; missing loop reports in this order):
```
".github/workflows/ci.yml",
".github/dependabot.yml",
".github/branch-protection.yml",
".github/CODEOWNERS",
"Dockerfile",
"deploy/helm/Chart.yaml",
"infra/terraform/main.tf",
"SECURITY.md",
"README.md",
```
Imported at `devsecops_validation.py:27-29`. **GOTCHA:** SAST is inline in `ci.yml` (single `sast` job) — there is NO separate `codeql.yml` required file (docstring `devsecops_contract.py:44-47`).

### 2.5 `_check_ci_yaml` (`devsecops_validation.py:61-105`)

`REQUIRED_CI_JOBS` (`:41-49`) = `("lint","test","build","sast","sca","secrets-scan","image-scan")` — the 7 jobs (docstring `:38-40`, names stable so branch-protection required-checks don't vary per profile).

Steps:
1. `try: doc = yaml.safe_load(content)` — on `yaml.YAMLError`: append `".github/workflows/ci.yml is not valid YAML: {exc}"` and **return** (`:70-73`).
2. `if not isinstance(doc, dict):` append `".github/workflows/ci.yml did not parse to a mapping"` and return (`:75-77`).
3. `jobs = doc.get("jobs")`; `if not isinstance(jobs, dict):` append `".github/workflows/ci.yml has no 'jobs' mapping"` and return (`:78-81`).
4. `missing_jobs = [j for j in REQUIRED_CI_JOBS if j not in jobs]`; if any → append `"ci.yml missing required job(s): " + ", ".join(missing_jobs)` (`:82-86`).
5. **SAST-tool presence** (`:87-94`): `if sast_tool and sast_tool.lower() not in content.lower():` append `f"ci.yml does not reference the profile SAST tool {sast_tool!r}; the SAST job may be mis-rendered"`. **GOTCHA:** substring match against the whole file text (case-insensitive) — catches an un-rendered `{{sast_tool}}` placeholder or a profile mis-render (e.g. semgrep profile emitting codeql-only pipeline). Skipped when `sast_tool` is falsy/empty.
6. **Un-rendered mustache placeholder scan** (`:95-105`): loop `idx in range(len(content)-1)`; if `content[idx]=="{"` and `content[idx+1]=="{"` and (`idx==0` or `content[idx-1] != "$"`) → append `"ci.yml contains an un-rendered '{{...}}' placeholder"` and **break** (only reports once). **GOTCHA:** deliberately does NOT false-positive on GitHub Actions `${{ ... }}` because those `{{` are preceded by `$` (`:96-98`, `:101`).

### 2.6 `_check_yaml_parses` (`devsecops_validation.py:108-116`)

```python
try: doc = yaml.safe_load(content)
except yaml.YAMLError as exc: errors.append(f"{name} is not valid YAML: {exc}"); return
if doc is None: errors.append(f"{name} parsed to an empty document")
```
Used for `dependabot.yml` and `branch-protection.yml`. Only checks parseability + non-empty; no schema.

### 2.7 `_validate_iac_manifest` (`devsecops_validation.py:136-231`)

1. `try: data = json.loads(content)` — on `(ValueError, TypeError)`: append `"iac-manifest.json is not valid JSON: {exc}"` and **return** (`:141-144`).
2. **Schema stage** (`:146-158`): `schema_path = _iac_schema_path()`. If not None:
   - `import jsonschema` (lazy). Load schema JSON, `Draft202012Validator`, and for each `err in validator.iter_errors(data)` append `f"iac-manifest schema: {err.json_path}: {err.message}"` (`:148-154`). **GOTCHA:** collects ALL schema errors (no cap), then CONTINUES to semantic checks (does not return).
   - `except ImportError:` → `logger.warning("jsonschema not installed; skipping IaC schema check")` (`:155-156`) — schema check silently skipped, semantic checks still run.
   - `except Exception as exc:` (`# noqa BLE001`) → `logger.warning("IaC schema validation skipped: %s", exc)` (`:157-158`) — a malformed schema is non-fatal.
3. `_iac_schema_path()` (`:118-133`): walk up from `Path(__file__).resolve()` through `(here, *here.parents)` looking for `<parent>/cross-cutting/skills/iac-scaffolding-generator/schemas/output.schema.json`; return first `.is_file()` match, else `None`. Reuses the SKILL's own contract, not a copy.
4. **Semantic referential-integrity checks** (`:160-231`, mirror the skill's `validate_output.py`):
   - Inner helper `_dict_items(container, field_name)` (`:171-190`): if `container` is not a list → if truthy, append `f"iac-manifest {field_name!r} must be a list, got {type(container).__name__}"`, return `[]` (absent/empty is fine). Else for each element: dicts kept; non-dicts append `f"iac-manifest {field_name}[{i}] must be a mapping, got {type(elem).__name__}"`. **GOTCHA:** this defensive guarding exists so a malformed list element (`"x"` instead of `{...}`) becomes a structured error rather than an `AttributeError` crash that would fail G-04c for the whole app (docstring `:160-170`).
   - `raw = data if isinstance(data, dict) else {}` (`:192`).
   - `stacks = _dict_items(raw.get("stacks",[]), "stacks")` (`:193`)
   - `lambdas = _dict_items(raw.get("lambda_functions",[]), "lambda_functions")` (`:194`)
   - `routes = _dict_items(raw.get("api_routes",[]), "api_routes")` (`:195`)
   - `event_rules = _dict_items(raw.get("event_rules",[]), "event_rules")` (`:196`)
   - `lambda_names = {fn.get("function_name") for fn in lambdas}` (`:198`).
   - **Route→Lambda integrity** (`:199-205`): for each route, `fn_ref = route.get("lambda_function","")`; `if fn_ref and fn_ref not in lambda_names:` append `f"iac-manifest route {route.get('method')} {route.get('path')} references unknown Lambda: {fn_ref}"`.
   - **EventRule→Lambda integrity** (`:206-212`): for each rule, `target = rule.get("target_lambda","")`; `if target and target not in lambda_names:` append `f"iac-manifest event rule {rule.get('rule_name')} targets unknown Lambda: {target}"`.
   - **Construct id collection** (`:213-216`): `construct_ids = set()`; for each stack, for each construct in `_dict_items(stack.get("constructs",[]), "constructs")`, add `construct.get("id","")`.
   - **Construct connects_to integrity** (`:217-231`): re-iterate stacks/constructs; `connects = construct.get("connects_to",[])`; if not a list → append `f"iac-manifest construct {construct.get('id')} 'connects_to' must be a list, got {type(connects).__name__}"` and `continue`; else for each `ref in connects`, `if ref not in construct_ids:` append `f"iac-manifest construct {construct.get('id')} connects_to unknown: {ref}"`. **GOTCHA:** `construct_ids` is fully built in the first pass before the connects check runs, so forward references between constructs are allowed.

### 2.8 Errors / retries / idempotency (activity 2)

- **Does not raise** on validation failure — returns `passed=False` with `missing`/`errors`. The workflow fails G-04c on `passed=False`.
- Failure modes that CAN raise (then wrapped by decorator §0.4): unexpected exceptions during YAML/JSON parse are caught internally; the lazy `jsonschema` malformed-schema case is caught (`:157`). In practice the activity is exception-free by design.
- **Idempotent & deterministic:** pure function of `committed_files` + on-disk skill schema; no DB/network/Git. `files_checked` reflects the passed set only.
- No `retry_policy`/`heartbeat` on decorator.

---

## 3. `resolve_devsecops_profile`

File: `temporal/olympus_workflows/activities/profile_devsecops.py`
Decorator: `profile_devsecops.py:144`
Activity: `:145-167`; pure core `resolve_baseline_params` at `:97-141`.

Purpose (module docstring `:1-18`): resolve the active client profile's DevSecOps baseline params so the workflow threads them into the generating agent's `context['devsecops_baseline']` and passes `sast_tool` to the validator. No hardcoded FAA — a non-FAA profile with its own `devsecops:` block yields its own values.

### 3.1 Signature & I/O types

```python
async def resolve_devsecops_profile(input: ResolveDevSecOpsProfileInput) -> ResolveDevSecOpsProfileResult
```

**`ResolveDevSecOpsProfileInput`** (`types.py:771-775`): `profile_id: str = ""`.

**`ResolveDevSecOpsProfileResult`** (`types.py:778-797`): `profile_id: str=""`, `sast_tool: str="codeql"`, `sbom_required: bool=True`, `container_base: str="distroless"`, `license: str=""`, `target_cloud: str="aws"`, `primary_ecosystem: str="python"`, `iac: str="terraform"`, `cicd: str="github-actions"`.

### 3.2 Activity wrapper flow (`profile_devsecops.py:145-167`)

1. `if isinstance(input, dict): input = ResolveDevSecOpsProfileInput(**input)` (`:154-155`) — dict re-hydration (as §2.2).
2. `params = resolve_baseline_params(input.profile_id or None)` (`:156`) — **GOTCHA:** empty string `""` (the dataclass default) is coerced to `None` so the resolver uses the active-profile path, not an explicit id.
3. Build the result, coercing each param through its expected type (`:157-167`):
   - `profile_id=input.profile_id` (echoes input, NOT the resolved root),
   - `sast_tool=str(params["sast_tool"])`, `sbom_required=bool(params["sbom_required"])`, `container_base=str(params["container_base"])`, `license=str(params["license"])`, `target_cloud=str(params["target_cloud"])`, `primary_ecosystem=str(params["primary_ecosystem"])`, `iac=str(params["iac"])`, `cicd=str(params["cicd"])`.

### 3.3 `_DEFAULTS` (`profile_devsecops.py:42-51`)

Platform defaults (devsecops-baseline.md §6), used when the profile omits a field:
```
sast_tool: "codeql", sbom_required: True, container_base: "distroless",
license: "", target_cloud: "aws", primary_ecosystem: "python",
iac: "terraform", cicd: "github-actions"
```
**GOTCHA:** `license` has NO real default — empty string means "no license file"; the profile MUST pick one (docstring `:39-41`).

### 3.4 Profile root resolution

`_profile_root_from_env()` (`:54-68`): prefer `$OLYMPUS_PROFILE_ROOT` (resolved, must `.is_dir()`); else `Path(__file__).resolve().parents[3] / "profiles" / "faa"` if a dir, else `None`. Mirrors `context_priors._profile_root_from_env` (docstring `:55-59`).

`_profile_root_for(profile_id)` (`:71-84`):
- If `profile_id` truthy: build `roots` = `[$OLYMPUS_PROFILES_DIR (if set), <repo_root>/profiles]`; return first `<base>/<profile_id>` that `.is_dir()` (`:72-83`).
- If none matched OR `profile_id` falsy → fall through to `_profile_root_from_env()` (`:84`). **GOTCHA:** an unknown profile_id silently falls back to the active/FAA profile rather than erroring.

`_load_yaml(path)` (`:87-94`): `{}` if not a file; `yaml.safe_load(...) or {}`; on `yaml.YAMLError` → `logger.warning("profile_devsecops: %s unparseable: %s", ...)` and return `{}`. **GOTCHA:** an unparseable profile.yaml degrades to defaults, not an error.

### 3.5 `resolve_baseline_params` exact merge order (`profile_devsecops.py:97-141`)

1. `params = dict(_DEFAULTS)` (`:104`) — start from platform defaults (copy).
2. `root = _profile_root_for(profile_id)` (`:106`). If `None`: `logger.info("profile_devsecops: no profile root resolved; using defaults")` and **return `params`** (defaults) (`:107-111`).
3. `profile_doc = _load_yaml(root / "profile.yaml")` (`:113`).
4. Extract `devsecops` block (`:114-119`): `profile_block = profile_doc.get("profile")`; if it's a dict, `maybe = profile_block.get("devsecops")`; if that's a dict, `devsecops = maybe`. Else `devsecops = {}`.
5. **Override loop** (`:120-122`): `for key in _DEFAULTS: if key in devsecops and devsecops[key] is not None: params[key] = devsecops[key]`. **GOTCHA:** only overrides keys that are present AND non-None in the profile's `devsecops:` block; a `null` in YAML keeps the default.
6. **iac/cicd mirror from technology.yaml** (`:126-134`): `tech_doc = _load_yaml(root / "technology.yaml")`; `tech = tech_doc.get("technology")`; if dict, `infra = tech.get("infrastructure")`; if dict:
   - `if "iac" not in devsecops and infra.get("iac"): params["iac"] = str(infra["iac"]).strip().lower()` (`:131-132`).
   - `if "cicd" not in devsecops and infra.get("cicd"): params["cicd"] = str(infra["cicd"]).strip().lower().replace(" ", "-")` (`:133-134`). **GOTCHA:** cicd is lowercased AND spaces→hyphens (e.g. "GitHub Actions" → "github-actions"); the devsecops-block value takes precedence over technology.yaml (the `not in devsecops` guard).
7. **Casing normalization** (`:137-139`): for `key in ("sast_tool","container_base","target_cloud","primary_ecosystem")`: if the current value is a str → `params[key] = params[key].strip().lower()`. **GOTCHA:** this normalizes even values that came from `_DEFAULTS` or the profile block; `license`, `sbom_required`, `iac`, `cicd` are NOT in this loop (iac/cicd already normalized in step 6 only when mirrored — a devsecops-block iac/cicd is NOT re-normalized).
8. `return params` (`:141`).

### 3.6 Errors / retries / idempotency (activity 3)

- **Never raises** by design: missing/unparseable profile files degrade to defaults (`_load_yaml`, `_profile_root_*`). Any stray exception would be wrapped by the decorator (§0.4).
- **Idempotent & deterministic** given the same env + on-disk profile files. Reads FS only (`profile.yaml`, `technology.yaml`); no DB/network/Git.
- **GOTCHA — env-dependence:** resolution depends on `$OLYMPUS_PROFILE_ROOT` / `$OLYMPUS_PROFILES_DIR` at CALL time (unlike activity 1's import-time `_SCHEMAS_DIR`). Different worker env → different resolved params.
- No `retry_policy`/`heartbeat` on decorator.

---

## 4. Cross-cutting notes

- **`__all__` exports:** `artifact_validation.py:80` = `["validate_artifact_against_schema"]`; `profile_devsecops.py:34` = `["resolve_devsecops_profile","resolve_baseline_params"]`; `devsecops_validation.py` has no `__all__` (both `validate_baseline` and `validate_devsecops_baseline` are importable).
- **No `persist_*`, Git, or agent-dispatch behavior in this group** — the task's items 2/3/4 (DB transforms, Git merge sequences, agent retry-with-feedback) do not apply to any of these 3 functions. `validate_artifact_against_schema`'s docstring *describes* the caller's `on_fail` policies (`warn` / `retry-with-feedback` / `raise`, `:16-27`) but those are the WORKFLOW's escalation choices — this activity itself only returns a result and never dispatches or retries.
- **jsonschema draft:** both `validate_artifact_against_schema` and the IaC manifest check use `Draft202012Validator` (2020-12).
- **Two-layer pattern:** activities 2 & 3 expose a pure core (`validate_baseline`, `resolve_baseline_params`) callable without a Temporal context (unit-testable), with the `@foundry_activity` async function as a thin delegating wrapper. Activity 1 inlines its logic in the wrapper but pushes non-raising helpers (`_validate_payload`, `_load_schema`) out.
