# Activity group: `line_transitions` (core) — atomic regeneration spec

All paths are relative to repo root `temporal/olympus_workflows/activities/line_transitions/` unless a full path is given. This group's package modules were split out of a monolithic `line_transitions` module (P7-S16.14); each module re-exports through the package facade so `olympus_workflows.activities.line_transitions.<name>` keeps working (`architecture.py:1-6`).

**Files covered:** `architecture.py`, `data.py`, `validation.py`, `modernization.py`, `orchestration.py`, `_shared.py`.

**7 activity functions total** (all decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`):
- `persist_architecture_side_effects` (`architecture.py:186`)
- `persist_data_side_effects` (`data.py:181`)
- `persist_validation_side_effects` (`validation.py:211`)
- `persist_modernization_side_effects` (`modernization.py:258`)
- `start_next_line_workflow` (`orchestration.py:103`)
- `fetch_application_source_repos` (`orchestration.py:217`)
- `load_app_intake_modes` (`orchestration.py:279`)

**Scope note (important):** There are **NO git/PR/merge activities and NO agent-dispatch activities in this group.** The four `persist_*` activities are DB-projection (artifact-JSON → application/side-table rows). `start_next_line_workflow` starts a Temporal child via the client; the other two orchestration activities are read-only DB lookups. The task's "Git activities" and "Agent-dispatch activities" sections do not apply here; those live in other activity groups.

---

## 0. What `@foundry_activity` adds over raw `activity.defn`

Source: `temporal/olympus_workflows/temporal_base/activities.py`.

`foundry_activity(config=None, name=None, **activity_kwargs)` (`activities.py:79-150`) returns a decorator that:

1. **Wraps in `@activity.defn(name=name, **activity_kwargs)`** (`activities.py:100`). Activity **name defaults to the function name** and is preserved — Temporal replay keys on it (`activities.py:14-16, 103`). All 7 activities here pass only `config=ActivityConfig(enable_observability=True)` — no explicit `name`, so the name is the function name. **GOTCHA:** `persist_modernization_side_effects` passes a dynamic `function_name=f"persist_modernization_side_effects({input.gate_phase})"` **to the execution-record emitter** (`modernization.py:286-288`), NOT to the decorator — the Temporal activity name is still the plain function name.

2. **Observability (default on).** When `config.enable_observability` (default `True`, `activities.py:50`): logs `"Activity %s starting"` before the body (`activities.py:105-110`), `"Activity %s completed"` after success (`activities.py:115-120`), and `"Activity %s failed: %s"` on exception (`activities.py:125-131`). Uses stdlib `logging` (no Prometheus/structlog; safe outside the workflow sandbox — `activities.py:6-7,38`). Inputs are logged only if `config.log_inputs` (default `False`); outputs only if `config.log_outputs` (default `False`) (`activities.py:52-53,109,119`).

3. **Error wrapping (default on).** When `config.enable_error_wrapping` (default `True`, `activities.py:51`), on any exception escaping the body (`activities.py:124-146`):
   - If it is already a `WorkflowError` or `temporalio` `ApplicationError` → **re-raised unchanged** (`activities.py:135-136`). `NonRetryableError`/`RetryableError` are `WorkflowError` subclasses so they pass through with their `non_retryable` flag intact.
   - Else if `_is_retryable_error(error)` → wrapped in `RetryableError` (`activities.py:137-140`).
   - Else → wrapped in `NonRetryableError` (`activities.py:141-144`).
   - `_is_retryable_error(error)` (`activities.py:56-76`): lowercases `str(type(error))` and returns True if it contains ANY of `timeout, connection, network, temporary, unavailable, overload, busy, throttle, rate_limit`. **GOTCHA:** this keys on the **type-name string**, NOT instance inspection; it is intentionally distinct from `errors.is_retryable_error` (`activities.py:57-63`). E.g. `asyncpg.exceptions.ConnectionDoesNotExistError` matches "connection" → RetryableError; a bare `ValueError` → NonRetryableError.

4. **Error taxonomy** (`temporal/olympus_workflows/temporal_base/errors.py`): `WorkflowError(ApplicationError)` defaults `non_retryable=True` (`errors.py:16-20`); `RetryableError` forces `non_retryable=False` (`errors.py:23-27`); `NonRetryableError` forces `non_retryable=True` (`errors.py:30-34`). The `non_retryable` flag is exactly what Temporal reads to decide whether to retry.

**Config defaults NOT set by this group:** `retry_policy`, all four timeouts, and `heartbeat_timeout` are all `None` (`activities.py:45-49`) — **no timeouts and no heartbeat are configured at the decorator level.** These come from the workflow's `execute_activity(...)` call options, not from `@foundry_activity`. **No activity in this group calls `activity.heartbeat()`.**

**Idempotency baseline:** none of these activities are wrapped in a retry-safe transaction guard; idempotency is achieved per-activity via `ON CONFLICT DO NOTHING` inserts and column-level `UPDATE` (re-running overwrites with the same computed values). Detailed per-activity below.

---

## 1. Shared helpers (`_shared.py`)

### 1.1 Connection / config helpers
- `_db_url()` (`_shared.py:23-29`): builds `postgresql://{user}:{password}@{host}:{port}/{db}` from env `DATABASE_HOST` (default `localhost`), `DATABASE_PORT` (`5432`), `DATABASE_USER` (`olympus`), `DATABASE_PASSWORD` (`olympus`), `DATABASE_NAME` (`olympus`).
- `_temporal_host()` (`_shared.py:32-33`): env `TEMPORAL_HOST`, default `temporal:7233`.
- `_temporal_namespace()` (`_shared.py:36-37`): env `TEMPORAL_NAMESPACE`, default `default`.

### 1.2 `_try_parse_json(text) -> dict | None` (`_shared.py:40-56`)
Best-effort agent-output JSON parse:
1. Empty/falsy `text` → `None` (`_shared.py:42-43`).
2. Try `json.loads(text)` (`_shared.py:45`).
3. On `JSONDecodeError`: find first `{` and last `}`; if `start == -1 or end <= start` → `None`; else `json.loads(text[start:end+1])`, on second failure → `None` (`_shared.py:46-55`).
4. Returns the value only if it `isinstance(value, dict)`, else `None` (`_shared.py:56`). **GOTCHA:** a valid JSON list/number/string parses but is discarded → `None`.

### 1.3 `_dedupe_str_list(xs)` (`_shared.py:59-67`)
De-dupes preserving first-seen order via a `seen` set. (Defined here but not used by any activity in *this* group's flow paths.)

### 1.4 `_SIDE_EFFECT_COLUMNS` — the projection allowlist (`_shared.py:70-153`)
An **ordered** tuple. `_build_update_sql` iterates it in order, so the generated SQL column order is fixed by this tuple. Full ordered list (every entry is a valid `application` column a projection may set):
```
description, business_domain, archetype, complexity_tier, safety_tier, risk_tier,
risk_tier_source, tech_stack, size_metrics, architecture, business_logic, quality,
ux_assessment, tco,
portfolio_score, disposition, disposition_source, disposition_rationale_ref,
architecture_blueprint_ref, architecture_pattern, architecture_decided_at, source_app_ids,
target_repo_url, target_service_id,
data_architecture_ref, data_migration_plan_ref, data_decided_at, data_pattern,
data_domains, data_current_status,
extraction_ref, extraction_at, design_ref, design_at, modernization_pattern,
bounded_contexts, generated_module_refs, generate_at, modernization_current_status,
validation_parity_score, validation_critical_vuln_count, validation_accessibility_score,
validation_safety_case_ref, validation_completed_at, validation_current_status,
deployed_at, deployment_env, cutover_strategy, parallel_run_duration_days,
cost_savings_realized_usd, license_reclamation_usd, legacy_decommissioned_at,
deployment_current_status,
disposition_output_ref, disposition_completed_at, disposition_current_status,
cost_savings_annual_usd
```
**GOTCHA:** A projection key NOT in this tuple is silently dropped by `_build_update_sql` (never written). Only allowlisted columns can ever be UPDATEd.

### 1.5 `_JSONB_COLUMNS` (`_shared.py:156-171`)
`frozenset`: `tech_stack, size_metrics, architecture, business_logic, quality, ux_assessment, tco, portfolio_score, data_domains, bounded_contexts, generated_module_refs`. Values for these columns are `json.dumps(...)`-serialized before binding (see 1.7).

### 1.6 `_NATIVE_COLUMNS` (`_shared.py:174-195`)
`frozenset` of columns bound as native asyncpg types (not JSON-serialized): `architecture_decided_at`(datetime), `source_app_ids`(list[UUID]→UUID[]), `data_decided_at`(datetime), `extraction_at`, `design_at`, `generate_at`, `validation_completed_at`, `deployed_at`, `legacy_decommissioned_at`, `cost_savings_realized_usd`(Decimal), `license_reclamation_usd`(Decimal), `parallel_run_duration_days`(int), `disposition_completed_at`, `cost_savings_annual_usd`(Decimal). **GOTCHA:** this set is documentary/reference only — `_build_update_sql` does NOT branch on it; it only branches on `_JSONB_COLUMNS`. Native columns are bound as-is because callers already pass native Python objects (e.g. `datetime`, `list[uuid.UUID]`).

### 1.7 `_build_update_sql(projections) -> (sql, params)` (`_shared.py:506-539`)
Builds the parameterized UPDATE. Exact algorithm:
1. `assignments=[]`, `params=[]`, `idx=1`.
2. For each `column` in `_SIDE_EFFECT_COLUMNS` order: skip if `column not in projections` (`_shared.py:517-519`). Else `value = projections[column]`; if `column in _JSONB_COLUMNS` → `value = json.dumps(value)` (`_shared.py:521-522`); append `f"{column} = ${idx}"` to assignments and `value` to params; `idx += 1` (`_shared.py:523-525`).
3. **Always** append `f"updated_at = ${idx}"` with param `datetime.now(timezone.utc)`; `idx += 1` (`_shared.py:527-530`).
4. `where_idx = idx`; `sql = "UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${where_idx}"` (`_shared.py:532-538`).
5. Returns `(sql, params)`. **Caller appends the target UUID** as the final positional param (matching `$where_idx`) — every `persist_*` does `params.append(target_uuid)` then `conn.execute(sql, *params)`.

**GOTCHA:** `_build_update_sql` only produces the WHERE placeholder; it does NOT append the id — the caller must. If `projections` is empty, callers guard against calling this (they check `if projections:`).

### 1.8 `_merge_application_metadata(conn, app_uuid, namespace, payload)` (`_shared.py:453-503`)
Async, runs on a caller-supplied connection (inside caller's transaction). Merges a per-line block into `application.metadata` JSONB:
1. If `payload` falsy → **return (no-op)** (`_shared.py:483-484`).
2. `payload_with_meta = dict(payload)`; `payload_with_meta.setdefault("last_assessed", datetime.now(timezone.utc).isoformat())` (`_shared.py:485-488`).
3. `namespace_block = json.dumps({namespace: payload_with_meta})` (`_shared.py:489`).
4. SQL (`_shared.py:493-503`):
```sql
UPDATE application
   SET metadata = COALESCE(metadata, '{}'::jsonb) || $1::jsonb,
       updated_at = $2
 WHERE id = $3::uuid
```
params: `namespace_block`, `datetime.now(timezone.utc)`, `app_uuid`.
**GOTCHA — whole-namespace replace:** the JSONB `||` operator replaces the *entire* top-level `namespace` key (shallow merge at top level only). Callers must pass the FULL namespace shape, not partial deltas, or earlier keys under that namespace are lost (`_shared.py:472-477`). `COALESCE(metadata,'{}')` defends against pre-migration-051 NULL metadata rows (`_shared.py:490-492`). Idempotent apart from refreshing nested `last_assessed`.

### 1.9 Compliance-metadata builders (used by the persist activities)

**`_extract_architecture_compliance_metadata(blueprint, ea_compliance, security_arch)`** (`_shared.py:299-335`) — used by `persist_architecture_side_effects`:
- `block = {"source_line": "Architecture"}`.
- If `blueprint` is dict and `blueprint.get("ratified_at")` truthy → `block["cato_state"]="in-progress"` (`_shared.py:317-318`).
- If `ea_compliance` dict has list `findings` → `block["ea_findings_count"]=len(findings)`; `block["ea_alignment_status"] = "compliant" if not findings else "needs-review"` (`_shared.py:320-326`).
- If `security_arch` dict has list `controls` → `block["security_controls_count"]=len(controls)` (`_shared.py:328-331`).
- If `list(block.keys())==["source_line"]` (no real signal) → return `{}` (`_shared.py:333-334`).

**`_extract_validation_cato_metadata(*, cato_target_uuid, cato_stage, ssp_path, sar_path, poam_path, control_evidence_json, risk_tier, decided_at) -> (compliance, security)`** (`_shared.py:345-450`) — used by `persist_validation_side_effects`:
1. If NOT `cato_stage` AND NOT `control_evidence_json` → return `({}, {})` (`_shared.py:364-365`).
2. `now = decided_at or datetime.now(timezone.utc).isoformat()` (`_shared.py:367`).
3. `cato_state = _CATO_STAGE_STATE.get(cato_stage, "in-progress")` where `_CATO_STAGE_STATE = {"G-V1":"in-progress","G-V2":"transition","G-V3":"certified"}` (`_shared.py:338-342, 368`).
4. `compliance = {"source_line":"Validation","cato_state":cato_state,"last_assessed":now}`; `security = {}` (`_shared.py:370-375`).
5. If `ssp_path`: `compliance["ssp_path"]=ssp_path`, `compliance["ssp_emitted_at"]=now` (`_shared.py:376-378`).
6. If `sar_path`: `compliance["sar_path"]=sar_path`, `compliance["sar_emitted_at"]=now`, `security["sar_security_path"]=sar_path` (`_shared.py:379-382`).
7. If `poam_path`: `compliance["poam_path"]=poam_path` (`_shared.py:383-384`).
8. If `cato_stage=="G-V2"`: `compliance["g_v2_approved_at"]=now` (`_shared.py:385-386`).
9. If `cato_stage=="G-V3"`: set `cato_certified=True, certified=True, g_v3_approved_at=now, certified_at=now, status="compliant"` (`_shared.py:387-392`).
10. Per-control records from `control_evidence_json` (`_shared.py:395-409`): `json.loads`; if list, for each entry: if entry is str `json.loads(entry)` else use as-is; keep dict records with truthy `control_id`. On `TypeError/ValueError` → `records=[]`.
11. If `records` (`_shared.py:411-445`): build `controls` dict keyed by `control_id` with `{status, family, title, last_assessed (rec value or now), assessed_at_gate (rec value or cato_stage), evidence_ref (rec["evidence_refs"][0]["artifact"] if evidence_refs else None)}`; `status = str(rec.get("status") or "unknown")`; increment `counts[status]` (buckets `implemented/partial/planned/not-applicable/unknown`, defaulting unknown keys via `counts.get(status,0)+1`); `poam_open += 1` when status in `{partial,planned}`. Then set `compliance["controls"]`, `controls_assessed=len(records)`, `controls_implemented/partial/planned`, and `poam_open_items=poam_open` ONLY if `poam_path` truthy (`_shared.py:439-445`).
12. If `risk_tier`: `compliance["risk_tier"]=risk_tier` (`_shared.py:447-448`).
13. Return `(compliance, security)`.
**GOTCHA:** `cato_target_uuid` parameter is accepted but never used inside the function body.

**Also defined but NOT used by this group's activities** (used by Discovery/Rationalization line transitions in other modules): `_extract_discovery_compliance_metadata` (`_shared.py:198-243`), `_extract_rationalization_compliance_metadata` (`_shared.py:246-296`). Documented in the Discovery/Rationalization line-transition doc.

---

## 2. `persist_architecture_side_effects` (`architecture.py:186-390`)

**Signature:** `async def persist_architecture_side_effects(input: PersistArchitectureSideEffectsInput) -> PersistArchitectureSideEffectsResult`.

**Input** `PersistArchitectureSideEffectsInput` (`types.py:1807-1839`): `target_app_id: str` (required); `target_name=""`, `target_portfolio_id=""`, `target_application_map_json=""`, `blueprint_json=""`, `blueprint_ref=""`, `decided_at=""`, `target_repo_url=""`, `execution_context: StepExecutionContext|None = None`.

**Result** `PersistArchitectureSideEffectsResult` (`types.py:1842-1854`): `target_app_id`, `architecture_pattern=""`, `blueprint_persisted=False`, `new_application_row_created=False`, `lineage_rows_inserted=0`, `target_repo_url_persisted=False`.

**When:** once per target after G-02 approves (`architecture.py:190-201`).

### Module constants
- `_ARCHITECTURE_PATTERNS` (`architecture.py:43-52`): `{modular-monolith, microservices, serverless, event-driven, hybrid, batch}`.
- `_LINEAGE_RELATIONSHIPS` (`architecture.py:55-64`): `{replace, consolidate, refactor-of, rearchitect-of, replatform-of, retain}`.

### Control flow
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_architecture_side_effects")` (`architecture.py:202-205`). This inserts a RUNNING `step_execution` row of kind `code` (see §7); returns `None` if `execution_context` is None or emit fails.
2. Parse target UUID: `uuid.UUID(input.target_app_id)`. On `ValueError/TypeError` → `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` then `raise NonRetryableError(f"Invalid target_app_id: {input.target_app_id!r}")` (`architecture.py:206-214`).
3. `target_map = _try_parse_json(input.target_application_map_json)`; `blueprint = _try_parse_json(input.blueprint_json)` (`architecture.py:216-217`).
4. Build `projections` (`architecture.py:219-260`):
   - `_extract_blueprint_side_effects(blueprint, blueprint_ref=input.blueprint_ref, decided_at=input.decided_at)` (`architecture.py:67-103`): if `blueprint_ref` → `architecture_blueprint_ref`; if `blueprint` dict has `pattern` in `_ARCHITECTURE_PATTERNS` → `architecture_pattern` (else non-empty pattern logs warning, dropped); if `decided_at` → parse ISO-8601 (`decided_at.replace("Z","+00:00")` via `datetime.fromisoformat`) into `architecture_decided_at`, on failure log + skip.
   - If `input.target_repo_url` truthy → `projections["target_repo_url"]=input.target_repo_url` (`architecture.py:232-233`).
   - **#255 description backfill** (`architecture.py:240-243`): if `"description" not in projections` AND `target_map` is dict with a non-blank `rationale` string → `projections["description"]=rationale.strip()`.
   - `lineage_rows, source_ids = _extract_lineage_side_effects(target_map)` (see below). If `source_ids` → `projections["source_app_ids"]=[uuid.UUID(s) for s in source_ids]`; on `ValueError/TypeError` log "lineage source_app_ids include invalid UUIDs; skipping cache" and DON'T set (`architecture.py:244-254`).
5. `new_row = _extract_new_application_row(target_map, target_portfolio_id=..., target_name=...)` (see below).
6. `compliance_metadata = _extract_architecture_compliance_metadata(blueprint=blueprint, ea_compliance=blueprint.get("ea_compliance") if dict else None, security_arch=blueprint.get("security_architecture") if dict else None)` (`architecture.py:267-275`).
7. **Empty guard** (`architecture.py:277-290`): if `not projections and not lineage_rows and new_row is None and not compliance_metadata` → log "nothing extractable", `emit_code_step_complete(exec_id, columns_written=[])`, return `PersistArchitectureSideEffectsResult(target_app_id=input.target_app_id)` (all other fields default).
8. `conn = await asyncpg.connect(_db_url())`; open `async with conn.transaction():` (`architecture.py:292-294`). Inside:
   - **Provision new row** (`architecture.py:296-319`): if `new_row is not None`: parse `portfolio_uuid = uuid.UUID(new_row["portfolio_id"]) if new_row["portfolio_id"] else None` (on error → `None`); then:
     ```sql
     INSERT INTO application (id, name, portfolio_id, current_line, current_status)
     VALUES ($1, $2, $3, 'Architecture', 'architecture_complete')
     ON CONFLICT (id) DO NOTHING
     ```
     params: `target_uuid, new_row["name"], portfolio_uuid`. Set `new_row_created=True`. **GOTCHA:** `new_row_created` is set True even when `ON CONFLICT DO NOTHING` inserted zero rows (idempotent re-run) — the flag reflects "provision attempted", not "row newly created".
   - **UPDATE projections** (`architecture.py:322-325`): if `projections`: `sql, params = _build_update_sql(projections)`; `params.append(target_uuid)`; `conn.execute(sql, *params)`.
   - **Lineage inserts** (`architecture.py:328-351`): `lineage_inserted=0`; for each `row` in `lineage_rows`: parse `source_uuid = uuid.UUID(row["source_app_id"])` (on error → `continue`); execute:
     ```sql
     INSERT INTO application_lineage (target_app_id, source_app_id, relationship, created_at)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (target_app_id, source_app_id) DO NOTHING
     ```
     params `target_uuid, source_uuid, row["relationship"], datetime.now(timezone.utc)`; if `result.endswith(" 1")` → `lineage_inserted += 1` (asyncpg returns `"INSERT 0 N"`, `architecture.py:349-351`).
   - **Compliance merge** (`architecture.py:356-362`): if `compliance_metadata`: `_merge_application_metadata(conn, target_uuid, "compliance", compliance_metadata)` — inside the same transaction so partial lineage failure doesn't leave stale compliance (`architecture.py:353-355`).
9. `finally: await conn.close()` (`architecture.py:363-364`).
10. `columns_written = sorted(projections.keys())`; if `compliance_metadata` → append `"metadata.compliance"` (`architecture.py:366-368`). Log summary (`architecture.py:370-378`).
11. `emit_code_step_complete(exec_id, columns_written=columns_written)` (`architecture.py:380-382`).
12. Return `PersistArchitectureSideEffectsResult(target_app_id, architecture_pattern=str(projections.get("architecture_pattern","")), blueprint_persisted="architecture_blueprint_ref" in projections, new_application_row_created=new_row_created, lineage_rows_inserted=lineage_inserted, target_repo_url_persisted="target_repo_url" in projections)` (`architecture.py:383-390`).

### `_extract_lineage_side_effects(target_map) -> (rows, source_id_strings)` (`architecture.py:106-155`)
- Non-dict target_map → `([],[])`.
- `relationship = target_map.get("relationship")`; if not str or not in `_LINEAGE_RELATIONSHIPS` → `([],[])` (`architecture.py:124-129`).
- **Self-relationship guard:** if relationship in `{refactor-of, rearchitect-of, replatform-of, retain}` → `([],[])` (no lineage for self-edges; recorded only on `application.disposition`) (`architecture.py:130-134`). Only `replace` / `consolidate` produce edges.
- `sources = target_map.get("sources")`; non-list → `([],[])` (`architecture.py:136-138`).
- For each dict `entry`: `source_app_id = entry.get("source_app_id")`; skip non-str/empty; append `{"source_app_id":..., "relationship":relationship}` to rows and the id to `ids` (`architecture.py:140-154`).

### `_extract_new_application_row(target_map, *, target_portfolio_id, target_name) -> dict|None` (`architecture.py:158-183`)
- Non-dict or `not target_map.get("provisioned_new_row")` → `None` (`architecture.py:171-172`).
- `target_app_id = target_map.get("target_app_id")`; non-str/empty → `None` (`architecture.py:174-176`).
- Returns `{"id": target_app_id, "name": target_name or target_map.get("target_name") or target_app_id, "portfolio_id": target_portfolio_id or target_map.get("target_portfolio_id") or ""}` (`architecture.py:177-183`).

**Error handling / idempotency:** UUID parse failure → NonRetryableError (after FAILED emit). Everything else is best-effort in-transaction. Re-runs are idempotent: `application` provision + `application_lineage` inserts use `ON CONFLICT DO NOTHING`; the UPDATE overwrites with the same computed values; compliance merge is idempotent apart from `last_assessed`. **No explicit retry_policy** (decorator default), so a raw DB connection error would be classified by `_is_retryable_error` (contains "connection") → RetryableError → Temporal retries per the workflow's call-site policy.

---

## 3. `persist_data_side_effects` (`data.py:181-301`)

**Signature:** `async def persist_data_side_effects(input: PersistDataSideEffectsInput) -> PersistDataSideEffectsResult`.

**Input** `PersistDataSideEffectsInput` (`types.py:1761-1789`): `target_app_id` (required); `target_name=""`, `target_portfolio_id=""`, `data_architecture_json=""`, `decomposition_strategy_json=""`, `data_architecture_ref=""`, `data_migration_plan_ref=""`, `decided_at=""`, `target_service_id=""`, `execution_context=None`.

**Result** `PersistDataSideEffectsResult` (`types.py:1792-1804`): `target_app_id`, `data_pattern=""`, `data_architecture_persisted=False`, `cluster_rows_inserted=0`, `domains_persisted=0`.

**When:** once per target after G-DT approves (`data.py:185-195`).

### Module constants
- `_DATA_PATTERNS` (`data.py:41-49`): `{database-per-service, strangler-fig, db-facade, dedicated, shared-read-only}`.
- `_CLUSTER_ROLES` (`data.py:52-59`): `{read, write, owner, both}`.

### Control flow
1. `emit_code_step_start(..., function_name="persist_data_side_effects")` → `exec_id` (`data.py:196-199`).
2. Parse `target_uuid` — same NonRetryableError-after-FAILED path (`data.py:200-208`).
3. `architecture = _try_parse_json(input.data_architecture_json)`; `decomposition = _try_parse_json(input.decomposition_strategy_json)` (`data.py:210-211`).
4. Build `projections` (`data.py:213-238`):
   - `_extract_data_architecture_side_effects(architecture, architecture_ref=..., migration_plan_ref=..., decided_at=...)` (`data.py:62-100`): if `architecture_ref`→`data_architecture_ref`; if `migration_plan_ref`→`data_migration_plan_ref`; if `architecture` dict `data_pattern` in `_DATA_PATTERNS`→`data_pattern`, **elif** `pattern` truthy → `logger.warning("data_pattern not in whitelist", extra={"pattern": pattern})` and the pattern is DROPPED (other fields still persist); if `decided_at` → `try: out["data_decided_at"] = datetime.fromisoformat(decided_at.replace("Z","+00:00"))` **except (TypeError, ValueError):** `logger.warning("data decided_at not ISO-8601", extra={"decided_at": decided_at})` and the field is DROPPED, not persisted (`data.py:90-99`) — identical log-and-skip posture to the sibling `_extract_blueprint_side_effects` (line 163 above).
   - `domains = _extract_data_domains_side_effects(architecture)` (`data.py:103-122`): reads `architecture["data_domains"]` flat list, keeps non-empty strings. If `domains` truthy → `projections["data_domains"]=domains` (`data.py:222-224`).
   - `cluster_rows = _extract_shared_db_cluster_rows(decomposition)` (see below) (`data.py:226`).
   - **Status flag:** if `projections or cluster_rows` → `projections["data_current_status"]="data_complete"` (`data.py:230-231`).
   - **target_service_id:** `if getattr(input, "target_service_id", "") or "":` → `projections["target_service_id"]=input.target_service_id` (`data.py:237-238`). **GOTCHA:** the condition `getattr(...) or ""` evaluates truthy only when `target_service_id` is a non-empty string; empty leaves column unchanged (uses `getattr` defensively for older call shapes).
5. **Empty guard** (`data.py:240-248`): if `not projections and not cluster_rows` → log, `emit_code_step_complete(columns_written=[])`, return result with defaults.
6. `conn = asyncpg.connect`; `async with conn.transaction():` (`data.py:250-252`):
   - If `projections`: `_build_update_sql`, append `target_uuid`, execute (`data.py:254-257`).
   - `cluster_inserted=0`; for each `row` in `cluster_rows`:
     ```sql
     INSERT INTO shared_db_cluster (target_app_id, cluster_id, role, pattern, created_at)
     VALUES ($1, $2, $3, $4, $5)
     ON CONFLICT (target_app_id, cluster_id) DO NOTHING
     ```
     params `target_uuid, row["cluster_id"], row["role"], row["pattern"], datetime.now(timezone.utc)`; if `result.endswith(" 1")` → `cluster_inserted += 1` (`data.py:260-278`).
7. `finally: conn.close()`; log; `emit_code_step_complete(exec_id, columns_written=sorted(projections.keys()))` (`data.py:279-294`).
8. Return `PersistDataSideEffectsResult(target_app_id, data_pattern=str(projections.get("data_pattern","")), data_architecture_persisted="data_architecture_ref" in projections, cluster_rows_inserted=cluster_inserted, domains_persisted=len(domains))` (`data.py:295-301`).

### `_extract_shared_db_cluster_rows(decomposition) -> list[dict]` (`data.py:125-178`)
- Non-dict → `[]`. `clusters = decomposition.get("clusters")`; non-list → `[]`.
- For each dict `entry`: `cluster_id/role/pattern` from keys; skip non-str/empty `cluster_id`; if `role` not str or not in `_CLUSTER_ROLES` → log "invalid role" + skip; if `pattern` not str or not in `_DATA_PATTERNS` → log "invalid pattern" + skip; else append `{"cluster_id","role","pattern"}` (`data.py:150-177`).

**Idempotency / errors:** as §2 — UUID parse → NonRetryableError; `shared_db_cluster` inserts idempotent on `(target_app_id, cluster_id)`; UPDATE overwrites; best-effort otherwise.

---

## 4. `persist_validation_side_effects` (`validation.py:211-355`)

**Signature:** `async def persist_validation_side_effects(input: PersistValidationSideEffectsInput) -> PersistValidationSideEffectsResult`.

**Input** `PersistValidationSideEffectsInput` (`types.py:2514-2565`): `target_app_id` (required); `risk_tier=""`, `parity_report_json=""`, `security_report_json=""`, `accessibility_audit_json=""`, `safety_case_json=""`, `safety_case_ref=""`, `decided_at=""`, `execution_context=None`, plus cATO fields `cato_target_uuid=""`, `cato_stage=""`, `cato_ssp_path=""`, `cato_sar_path=""`, `cato_poam_path=""`, `control_evidence_json=""`.

**Result** `PersistValidationSideEffectsResult` (`types.py:2568-2581`): `target_app_id`, `parity_score_persisted=False`, `critical_vuln_count_persisted=False`, `accessibility_score_persisted=False`, `safety_case_persisted=False`, `validation_status=""`.

**When:** once per target after terminal Validation gate approves (G-V2 for Tier-2/3, G-V3 for Tier-1) (`validation.py:215-223`).

### GOTCHA — outer try/except wraps the WHOLE body
Unlike the other persist activities, `persist_validation_side_effects` wraps its entire body (including UUID parse) in a `try:` … `except Exception as exc:` that calls `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` then `raise` (`validation.py:228-354`). So ANY exception marks the step FAILED before propagating. `exec_id` is emitted first (`validation.py:224-227`) outside that try.

### Control flow (inside the outer try)
1. Parse `target_uuid` (nested try) → on error emit FAILED + raise NonRetryableError (`validation.py:229-237`).
2. Parse four artifacts: `parity`, `security_report`, `accessibility_audit`, `safety_case` (`validation.py:239-244`).
3. Build `projections` by merging four extractors (`validation.py:246-274`):
   - `_extract_parity_side_effects(parity)` (`validation.py:54-78`): score from `parity_score` else `score`; must be int/float in `[0.0,100.0]` inclusive else drop (out-of-range logs warning). Sets `validation_parity_score=float(score)`.
   - `_extract_compliance_side_effects(security_report, accessibility_audit)` (`validation.py:81-142`):
     - Critical vulns: `critical_vuln_count` (int≥0) → count; else `vuln_counts.critical` (int≥0); else count `findings` entries with `severity.lower()=="critical"` AND `classification.upper()=="TRUE_POSITIVE"`. If `count is not None` → `validation_critical_vuln_count=count` (`validation.py:105-128`).
     - Accessibility: `accessibility_score` else `wcag_conformance_pct`; if numeric in `[0,100]` → `validation_accessibility_score=float(score)`; else if non-None → warning + drop (`validation.py:130-140`).
   - `_extract_safety_side_effects(safety_case, safety_case_ref=..., risk_tier=...)` (`validation.py:145-168`): if `risk_tier != "1"` → `{}` (Tier-2/3 always empty, column stays NULL). Else if `safety_case_ref` → `{"validation_safety_case_ref": safety_case_ref}`. Payload currently unused.
   - `_extract_lifecycle_status(...)` (`validation.py:171-208`): `required = parity_persisted and security_persisted and accessibility_persisted`; if `risk_tier=="1"` → also `and safety_persisted`. If `required` → `{"validation_current_status":"validation_complete","validation_completed_at":datetime.now(utc)}`. Elif any of parity/security/accessibility persisted → `{"validation_current_status":"validation_compliance_approved"}`. Else → `{}`. **GOTCHA:** `validation_completed_at` is stamped ONLY on `validation_complete`.
4. `cato_compliance, cato_security = _extract_validation_cato_metadata(...)` (see §1.9) — built even when no column projections exist (`validation.py:278-288`).
5. **Empty guard** (`validation.py:290-298`): if `not projections and not cato_compliance and not cato_security` → log, emit complete (`columns_written=[]`), return result defaults.
6. `conn = asyncpg.connect` (`validation.py:300`). **GOTCHA — NO transaction block here:** unlike arch/data/modernization, validation runs its writes *without* `async with conn.transaction()` — the UPDATE and the two metadata merges are separate autocommitted statements (`validation.py:300-315`):
   - If `projections`: `_build_update_sql`, append `target_uuid`, execute.
   - If `cato_compliance`: `_merge_application_metadata(conn, target_uuid, "compliance", cato_compliance)`.
   - If `cato_security`: `_merge_application_metadata(conn, target_uuid, "security", cato_security)`.
   - `finally: conn.close()`.
7. After close: if `cato_compliance` → `projections.setdefault("metadata.compliance", True)`; if `cato_security` → `projections.setdefault("metadata.security", True)` (so they appear in `columns_written`) (`validation.py:317-320`).
8. Log; `emit_code_step_complete(exec_id, columns_written=sorted(projections.keys()))` (`validation.py:322-331`).
9. Return `PersistValidationSideEffectsResult(target_app_id, parity_score_persisted="validation_parity_score" in projections, critical_vuln_count_persisted="validation_critical_vuln_count" in projections, accessibility_score_persisted="validation_accessibility_score" in projections, safety_case_persisted="validation_safety_case_ref" in projections, validation_status=str(projections.get("validation_current_status","")))` (`validation.py:332-349`).

`_VALIDATION_LIFECYCLE_VALUES` frozenset (`validation.py:43-51`) is declared for reference; not enforced in the write path.

---

## 5. `persist_modernization_side_effects` (`modernization.py:258-450`)

**Signature:** `async def persist_modernization_side_effects(input: PersistModernizationSideEffectsInput) -> PersistModernizationSideEffectsResult`.

**Input** `PersistModernizationSideEffectsInput` (`types.py:2453-2493`): `target_app_id` (required); `gate_phase: str` (required, `"extract"|"design"|"generate"`); extract inputs `extraction_report_json=""`, `extraction_ref=""`; design inputs `module_map_json=""`, `design_review_json=""`, `design_ref=""`; generate input `gate_review_package_json=""`; shared `decided_at=""`, `execution_context=None`.

**Result** `PersistModernizationSideEffectsResult` (`types.py:2496-2511`): `target_app_id`, `gate_phase`, `extraction_persisted=False`, `design_persisted=False`, `generate_persisted=False`, `modernization_pattern=""`, `bounded_context_rows_inserted=0`, `bounded_context_rows_updated=0`.

**When:** three times per target run — after each gate G-04a/G-04b/G-04c; `gate_phase` selects the extractor (`modernization.py:262-282`).

### Module constants
- `_MODERNIZATION_PATTERNS` (`modernization.py:42-44`): `{monolith-lift, microservices-decompose, bc-per-service, hybrid}`.
- `_BOUNDED_CONTEXT_STATUSES` (`modernization.py:47-50`): `{design-complete, generate-active, generate-complete, escalated, abandoned}`.
- `_GATE_PHASES` (`modernization.py:53`): `{extract, design, generate}`.

### Control flow
1. `emit_code_step_start(input.execution_context, function_name=f"persist_modernization_side_effects({input.gate_phase})")` → `exec_id` (`modernization.py:284-289`). **Note the dynamic function_name** (per §0).
2. Parse `target_uuid` — NonRetryableError-after-FAILED (`modernization.py:290-298`).
3. **Validate gate_phase:** if `input.gate_phase not in _GATE_PHASES` → `emit_code_step_complete(FAILED, error=f"Invalid gate_phase: {gate_phase!r}")` then `raise NonRetryableError("... Expected one of {sorted(_GATE_PHASES)}.")` (`modernization.py:300-309`).
4. Init `projections={}`, `bc_rows_to_insert=[]`, `bc_rows_to_update=[]`.
5. **Phase dispatch** (`modernization.py:315-342`):
   - `extract`: `report=_try_parse_json(input.extraction_report_json)`; `projections.update(_extract_extract_side_effects(report, extraction_ref=..., decided_at=...))`.
   - `design`: `module_map=_try_parse_json(input.module_map_json)`, `design_review=_try_parse_json(input.design_review_json)`; `projections.update(_extract_design_side_effects(module_map, design_review, design_ref=..., decided_at=...))`; `bc_rows_to_insert=_extract_bounded_context_rows(module_map)`.
   - else (`generate`): `package=_try_parse_json(input.gate_review_package_json)`; `app_out, bc_updates=_extract_generate_side_effects(package, decided_at=...)`; `projections.update(app_out)`; `bc_rows_to_update=bc_updates`.
6. **Empty guard** (`modernization.py:344-356`): if `not projections and not bc_rows_to_insert and not bc_rows_to_update` → log, emit complete `[]`, return result with `target_app_id`, `gate_phase`.
7. `conn = asyncpg.connect`; `bc_inserted=0`, `bc_updated=0`; `async with conn.transaction():` (`modernization.py:358-362`):
   - If `projections`: `_build_update_sql`, append `target_uuid`, execute (`modernization.py:364-367`).
   - **INSERT bounded_context (G-04b)** (`modernization.py:370-385`): for each `row` in `bc_rows_to_insert`:
     ```sql
     INSERT INTO bounded_context (target_app_id, bc_name, status, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $4)
     ON CONFLICT (target_app_id, bc_name) DO NOTHING
     ```
     params `target_uuid, row["bc_name"], row["status"], datetime.now(utc)` (created_at AND updated_at both bind `$4`); if `result.endswith(" 1")` → `bc_inserted += 1`.
   - **UPDATE bounded_context (G-04c)** (`modernization.py:388-416`): for each `update` in `bc_rows_to_update`, build dynamic SQL:
     - Base `assignments=["status = $3","updated_at = $4"]`; `params_list=[target_uuid, update["bc_name"], update["status"], datetime.now(utc)]`; `idx=5`.
     - If `"ralph_iterations" in update`: append `ralph_iterations = $idx`, param value; `idx+=1`.
     - If `"escalations" in update`: append `escalations = $idx`, param `json.dumps(update["escalations"])` (JSONB); `idx+=1`.
     - If `"generated_path" in update`: append `generated_path = $idx`, param value; `idx+=1`.
     - `sql = "UPDATE bounded_context SET " + ", ".join(assignments) + " WHERE target_app_id = $1 AND bc_name = $2"`; execute; if `result.endswith(" 1")` → `bc_updated += 1`.
8. `finally: conn.close()`; log; `emit_code_step_complete(columns_written=sorted(projections.keys()))` (`modernization.py:417-433`).
9. Return `PersistModernizationSideEffectsResult(target_app_id, gate_phase, extraction_persisted=(gate_phase=="extract" and "extraction_ref" in projections), design_persisted=(gate_phase=="design" and "design_ref" in projections), generate_persisted=(gate_phase=="generate" and "generated_module_refs" in projections), modernization_pattern=str(projections.get("modernization_pattern","")), bounded_context_rows_inserted=bc_inserted, bounded_context_rows_updated=bc_updated)` (`modernization.py:434-450`).

### `_extract_extract_side_effects(report, *, extraction_ref, decided_at)` (`modernization.py:56-89`)
- If `extraction_ref` → `extraction_ref`. If `decided_at` → ISO parse into `extraction_at` (log+skip on fail). If `report` dict has list `bounded_contexts` → keep non-empty strings; if `clean` non-empty → `bounded_contexts` (JSONB). Preliminary BC list.

### `_extract_design_side_effects(module_map, design_review, *, design_ref, decided_at)` (`modernization.py:92-148`)
- If `design_ref`→`design_ref`. If `decided_at`→`design_at` (ISO parse). 
- Pattern: prefer `design_review["modernization_pattern"]`, else `module_map["modernization_pattern"]`; if str in `_MODERNIZATION_PATTERNS`→`modernization_pattern`; non-empty-non-whitelisted logs warning + drop (`modernization.py:120-131`).
- Refined BCs: `modules = module_map["modules"] or module_map["bounded_contexts"]`; if list, for each: dict → `name = mod["name"] or mod["bc_name"]`; str → the string; collect non-empty. If `refined_bcs` → `bounded_contexts` (`modernization.py:133-147`).

### `_extract_bounded_context_rows(module_map)` (`modernization.py:151-176`)
- `modules = module_map["modules"] or module_map["bounded_contexts"]`; non-list → `[]`. For each mod: extract `name` (dict `name`/`bc_name` or the str); skip non-str/empty/duplicate (`seen` set); append `{"bc_name":name,"status":"design-complete"}`.

### `_extract_generate_side_effects(package, *, decided_at) -> (app_out, bc_updates)` (`modernization.py:179-255`)
- If `decided_at`→`generate_at` (ISO parse). If package not dict → return `(app_out, [])`.
- `bc_entries = package["bounded_contexts"]`; `paths=[]`, `escalated_count=0`. For each dict `bc`: `name = bc["bc_name"] or bc["name"]` (skip non-str/empty); `status = bc["status"]`; if not str or not in `_BOUNDED_CONTEXT_STATUSES` → default `"generate-complete"` (`modernization.py:223-227`); `update={"bc_name":name,"status":status}`; if status in `{escalated,abandoned}` → `escalated_count+=1`; if int `ralph_iterations` → add; if list `escalations` → add; if non-empty str `generated_path` → add + append to `paths`; append `update` to `bc_updates` (`modernization.py:216-241`).
- If `paths` → `app_out["generated_module_refs"]=paths` (JSONB).
- **Lifecycle status** (`modernization.py:248-254`): if `bc_updates`: `escalated_count==0` → `modernization_complete`; `escalated_count < len(bc_updates)` → `modernization_partial`; else → `modernization_failed`.

**GOTCHA (design→generate coupling):** G-04c UPDATEs `bounded_context` rows that G-04b INSERTed. If a BC in the generate package was never provisioned at design (name mismatch), its UPDATE affects 0 rows and `bc_updated` doesn't increment (no INSERT fallback).

---

## 6. Orchestration activities (`orchestration.py`)

### Module constants / resolvers
- `_BUILD_SOURCE_TYPES` (`orchestration.py:45`): `{requirements_doc, interview}` — marks a net-new greenfield Build app.
- `_REGISTERED_LINE_WORKFLOWS` (`orchestration.py:47-58`): `{DiscoveryWorkflow, RationalizationWorkflow, ArchitectureWorkflow, DataWorkflow, ModernizationWorkflow, ValidationWorkflow, DeploymentWorkflow, DispositionWorkflow}`.
- `_LINE_WORKFLOW_OVERRIDES` (`orchestration.py:61-63`): `{"Disposition Execution": "DispositionWorkflow"}`.
- `_LINE_TO_WORKFLOW` (`orchestration.py:96-100`): legacy 3-entry map `{Discovery→DiscoveryWorkflow, Rationalization→RationalizationWorkflow, Modernization→ModernizationWorkflow}` — **declared but unused** in the resolve path (superseded by registry lookup).
- `_derive_workflow_name(line_name)` (`orchestration.py:66-71`): `f"{line_name.replace(' ','')}Workflow"`.
- `_resolve_line_workflow(line_name) -> str|None` (`orchestration.py:74-93`): returns `None` if `not ASSEMBLY_LINE_REGISTRY.has(line_name)`; else `candidate = _LINE_WORKFLOW_OVERRIDES.get(line_name) or _derive_workflow_name(line_name)`; returns `candidate` only if `candidate in _REGISTERED_LINE_WORKFLOWS`, else `None`. So a line is dispatchable iff registered AND its derived/overridden workflow is worker-registered.

### 6.1 `start_next_line_workflow(input: StartNextLineInput) -> StartNextLineResult` (`orchestration.py:103-214`)
**Input** `StartNextLineInput` (`types.py:1919-1932`): `app_id: str`, `next_line: str` (AssemblyLineName value), `task_queue: str`. **Result** `StartNextLineResult` (`types.py:1934-1939`): `workflow_id`, `line`.

Flow:
1. `workflow_name = _resolve_line_workflow(input.next_line)`; if `None` → `raise NonRetryableError(f"No Temporal workflow registered for line {input.next_line!r}")` (`orchestration.py:113-117`).
2. `app_uuid = uuid.UUID(input.app_id)`; on error → `NonRetryableError(f"Invalid app_id: {input.app_id!r}")` (`orchestration.py:119-122`).
3. **DB lookup 1** — `conn = asyncpg.connect`; `row = await conn.fetchrow(...)` joining `application a JOIN portfolio p ON p.id = a.portfolio_id WHERE a.id = $1`, selecting `a.name, a.portfolio_id, a.repo_url, a.target_repo_url, a.architecture_blueprint_ref, p.artifact_repo_url` (`orchestration.py:124-142`); close conn.
4. If `row is None` → `raise NonRetryableError(f"Application {input.app_id} not found")` (`orchestration.py:144-145`).
5. Build `workflow_id`: `run_ts = int(datetime.now(utc).timestamp())`; `line_slug = input.next_line.lower().replace(" ", "-")`; `workflow_id = f"{line_slug}-{input.app_id}-{run_ts}"` (`orchestration.py:147-149`).
6. `prior_artifacts=[]`; if `row.get("architecture_blueprint_ref")` truthy → append it (carries the Architecture G-02 target-state contract to Modernization; empty → source-only Ralph Loop fallback) (`orchestration.py:158-160`).
7. `client = await Client.connect(_temporal_host(), namespace=_temporal_namespace())` (`orchestration.py:162-164`).
8. `await client.start_workflow(workflow_name, {<arg dict>}, id=workflow_id, task_queue=input.task_queue)` (`orchestration.py:165-179`). Arg dict (single positional dict payload):
   ```
   {"app_id": str(app_uuid), "app_name": row["name"], "wave_id": "",
    "portfolio_id": str(row["portfolio_id"]), "artifact_repo": row["artifact_repo_url"] or "",
    "source_repo": row["repo_url"] or "", "target_repo_url": row.get("target_repo_url") or "",
    "prior_artifacts": prior_artifacts}
   ```
   **GOTCHA:** `wave_id` is hardcoded `""` — this path is single-app handoff, not wave-scoped.
9. **DB update** — new `conn = asyncpg.connect`; `status = f"{line_slug.replace('-', '_')}_in_progress"` (`orchestration.py:182-184`). Executes:
   ```sql
   UPDATE application
   SET current_status = $1, current_line = $2, current_step = NULL,
       workflow_id = $3, updated_at = $4
   WHERE id = $5
   ```
   params `status, input.next_line, workflow_id, datetime.now(utc), app_uuid`; close conn (`orchestration.py:185-202`).
10. Log; return `StartNextLineResult(workflow_id=workflow_id, line=input.next_line)` (`orchestration.py:204-214`).

**GOTCHA — no execution-record emission** here (no `emit_code_step_start`; this is a `git`/orchestration-shaped activity that predates that helper). **GOTCHA — idempotency:** `start_workflow` with a deterministic-*ish* id, but `run_ts` (unix seconds) makes the id time-varying, so a retry within the same second reuses the id (Temporal rejects duplicate running id) while a retry a second later starts a NEW workflow. Not strictly idempotent. **Errors:** unknown line / bad app_id / missing app → NonRetryableError; DB/Temporal transient errors classified by `_is_retryable_error` (`connection`/`unavailable`/`timeout` in type name → RetryableError).

### 6.2 `fetch_application_source_repos(input: FetchSourceReposInput) -> FetchSourceReposResult` (`orchestration.py:217-276`)
**Input** `FetchSourceReposInput` (`types.py:906-921`): `source_app_ids: list[str]`. **Result** `FetchSourceReposResult` (`types.py:924-939`): `anchor_source_repo=""`, `source_repos: dict[str,str]={}`.

Read-only. Flow:
1. If `not input.source_app_ids` → `FetchSourceReposResult()` (empty) (`orchestration.py:240-241`).
2. Build `ids: list[UUID]` and `raw_to_canonical: dict[str,str]` — parse each raw id; on parse error `continue`; else append parsed and set `raw_to_canonical[raw]=str(parsed)` (`orchestration.py:243-251`).
3. If `not ids` → empty result (`orchestration.py:252-253`).
4. `conn = asyncpg.connect`; `rows = await conn.fetch("SELECT id, repo_url FROM application WHERE id = ANY($1::uuid[])", ids)`; for each row `source_repos[str(row["id"])] = row["repo_url"] or ""` (`orchestration.py:255-269`). **GOTCHA:** apps with no DB row are simply omitted from `source_repos`; caller diffs keys to detect misses.
5. `anchor_canonical = raw_to_canonical.get(input.source_app_ids[0], "")`; `anchor_source_repo = source_repos.get(anchor_canonical, "")` (`orchestration.py:271-272`).
6. Return `FetchSourceReposResult(anchor_source_repo=anchor_source_repo, source_repos=source_repos)` (`orchestration.py:273-276`). **GOTCHA:** anchor is the FIRST source_app_id; if it failed to parse or has no row, anchor_source_repo is `""` but the dict may still contain other apps. Idempotent + read-only; safe to retry.

### 6.3 `load_app_intake_modes(input: LoadAppIntakeModesInput) -> LoadAppIntakeModesResult` (`orchestration.py:279-333`)
**Input** `LoadAppIntakeModesInput` (`types.py:942-954`): `app_ids: list[str]`. **Result** `LoadAppIntakeModesResult` (`types.py:975-979`): `modes: dict[str, AppIntakeMode] = {}`. **`AppIntakeMode`** (`types.py:957-972`): `app_id=""`, `source_type=""`, `is_build=False`, `disposition=""`.

Read-only. Flow:
1. If `not input.app_ids` → empty result (`orchestration.py:296-297`).
2. Parse `ids: list[UUID]` (skip unparseable via `continue`); if `not ids` → empty result (`orchestration.py:299-306`).
3. `conn = asyncpg.connect`; `rows = await conn.fetch(...)`:
   ```sql
   SELECT id,
          COALESCE(metadata->>'source_type', '') AS source_type,
          COALESCE(disposition::text, '') AS disposition
   FROM application
   WHERE id = ANY($1::uuid[])
   ```
   (`orchestration.py:311-320`).
4. For each row: `app_id=str(row["id"])`; `source_type=row["source_type"] or ""`; `modes[app_id]=AppIntakeMode(app_id=app_id, source_type=source_type, is_build=(source_type in _BUILD_SOURCE_TYPES), disposition=row["disposition"] or "")` (`orchestration.py:321-329`).
5. Return `LoadAppIntakeModesResult(modes=modes)` (`orchestration.py:333`). **GOTCHA:** missing rows / unparseable ids omitted — caller treats an absent entry as a legacy (non-build) app. Idempotent + read-only.

---

## 7. Execution-record emission (used by the four `persist_*` activities)

Source: `temporal/olympus_workflows/utils/execution.py`.

- `emit_code_step_start(ctx, *, function_name, columns_writable=None) -> uuid|None` (`execution.py:283-321`): if `ctx is None` → `None`. Reads `activity.info().workflow_id` + `.attempt` (on any exception → `""`,`1`). Builds `payload={"function": function_name}` (+ `columns_written` if `columns_writable`). Calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.CODE, workflow_id, app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt, payload, status=RUNNING))`.
- `emit_execution_record(input) -> uuid|None` (`execution.py:150-219`): `execution_id=uuid4()`; parses UUIDs; **if `portfolio_uuid is None` → warns + returns None (skips insert)** (`execution.py:167-174`). Else INSERTs a `step_execution` row (columns `execution_id, app_id, wave_id, portfolio_id, line_id, step_id, step_kind, status, started_at, attempt, input_artifacts::jsonb, payload::jsonb, workflow_id, agent_task_id, gate_id`); **best-effort — any exception → warn + return None** (`execution.py:176-219`).
- `emit_code_step_complete(execution_id, *, status=COMPLETED, columns_written=None, error=None)` (`execution.py:324-345`): builds `payload_merge={"columns_written": columns_written}` if provided; calls `update_execution_record(execution_id, status, payload_merge, last_error=error)`.
- `update_execution_record(...)` (`execution.py:222-275`): no-op if `execution_id is None`. UPDATEs `step_execution` setting `status`, `completed_at`, `duration_ms = EXTRACT(EPOCH FROM ($3 - started_at))*1000`, `output_artifacts = COALESCE($4, output_artifacts)`, `payload = payload || COALESCE($5,'{}')` (shallow JSONB merge), `last_error = COALESCE($6, last_error)` WHERE `execution_id = $1`. **Best-effort** — swallows exceptions.

**StepKind/ExecutionStatus enums** (`execution.py:58-74`): `StepKind ∈ {agent, git, gate, code, terminal}` (persist activities emit `code`); `ExecutionStatus ∈ {queued, running, completed, failed, timed_out, skipped, escalated, abandoned}`.

**GOTCHA:** because emission is best-effort and returns `None` on any failure (or when `portfolio_id` invalid / `execution_context` None), the persist activities tolerate `exec_id is None` throughout — `emit_code_step_complete(None, ...)` is a no-op. Emission never affects the activity's DB projection outcome.

---

## 8. Cross-cutting GOTCHAs summary

1. **Connection-per-write, no pooling.** Every activity opens a fresh `asyncpg.connect(_db_url())` and closes in `finally`. `start_next_line_workflow` opens TWO connections (lookup, then update) — the workflow start happens BETWEEN them, so a Temporal failure after start_workflow but before the UPDATE leaves a started child with the app row NOT flipped (`orchestration.py:124-202`).
2. **`validation` has NO transaction; arch/data/modernization DO.** In validation, the UPDATE and the two metadata merges are independent autocommits — a crash between them can leave columns updated but compliance metadata unmerged (`validation.py:300-315`).
3. **`_build_update_sql` column order is fixed** by `_SIDE_EFFECT_COLUMNS` tuple order, and unknown keys are silently dropped (`_shared.py:517-539`).
4. **`_merge_application_metadata` replaces the whole namespace** (top-level JSONB `||`), so callers must pass full namespace shapes (`_shared.py:472-503`).
5. **`asyncpg` INSERT tag parsing** (`result.endswith(" 1")`) is how every insert/update counts affected rows; `ON CONFLICT DO NOTHING` yields `"INSERT 0 0"` so `*_inserted` stays 0 on idempotent re-runs (`architecture.py:349-351`, `data.py:277`, `modernization.py:384,415`).
6. **All UUID-parse failures raise NonRetryableError** after marking the step FAILED; but Temporal-decorator wrapping only re-wraps non-`WorkflowError` exceptions — `NonRetryableError` (a `WorkflowError`) passes through with `non_retryable=True` (`activities.py:135-136`).
7. **ISO-8601 parse across all persist activities** uses `datetime.fromisoformat(decided_at.replace("Z","+00:00"))` — a bare `Z` is handled, but other tz suffixes rely on Python's `fromisoformat` (3.11+ tolerant) (`architecture.py:96-98`, `data.py:92-94`, `modernization.py:73-77,110-114,198-202`).
8. **`load_app_intake_modes` reads `metadata->>'source_type'`** — the JSONB text extraction; a non-string JSON value there would coerce to text via `->>` (`orchestration.py:314`).
