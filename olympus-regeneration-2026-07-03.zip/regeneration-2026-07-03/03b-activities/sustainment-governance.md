# Activities — Sustainment / Governance projection group

**Atomic regeneration spec.** Bar: behavioral parity. Reproduce HOW, not what.

All paths relative to repo root `/Users/pnunna/Documents/GitHub/olympus`.

Files covered (all under `temporal/olympus_workflows/activities/`):

| File | Activity functions (`@foundry_activity`) |
|---|---|
| `line_transitions/sustainment.py` | `persist_sustainment_sweep_side_effects` |
| `line_transitions/governance.py` | `persist_governance_sweep_side_effects` |
| `governance_operations.py` | `list_active_modernization_workflows` |

**units_documented = 3** (three activity functions). Plus every module-private extractor helper that shapes the DB writes is reproduced in full, since the persist activities' correctness depends entirely on them.

These three files were split out of the original monolithic `line_transitions` module (P7-S16.14); `sustainment.py:1-6`, `governance.py:1-6` state "behavior is unchanged. Imported back through the package facade so `olympus_workflows.activities.line_transitions.<name>` keeps working." The facade re-export is `line_transitions/__init__.py` (referenced but not required for behavior).

---

## 0. `@foundry_activity` — what it adds over raw `activity.defn`

Source: `temporal/olympus_workflows/temporal_base/activities.py`.

`@foundry_activity(config=..., name=None, **activity_kwargs)` returns a decorator (`activities.py:79-150`). Behavior:

1. **Config resolution** — `activity_config = config or ActivityConfig()` (`activities.py:98`). `ActivityConfig` (`activities.py:41-53`) is a dataclass with fields: `retry_policy: RetryPolicy|None=None`, `start_to_close_timeout`, `schedule_to_close_timeout`, `schedule_to_start_timeout`, `heartbeat_timeout` (all `timedelta|None=None`), `enable_observability: bool=True`, `enable_error_wrapping: bool=True`, `log_inputs: bool=False`, `log_outputs: bool=False`.
   - **GOTCHA:** the timeout/retry_policy/heartbeat_timeout fields on `ActivityConfig` are **declared but NOT applied** by the decorator. The decorator body never reads them; only `enable_observability`, `enable_error_wrapping`, `log_inputs`, `log_outputs` are consulted. Timeouts and retry policy are supplied at the *workflow call site* (`workflow.execute_activity(...)`), not here. All three activities in this group are decorated with `config=ActivityConfig(enable_observability=True)` (`sustainment.py:413`, `governance.py:323`, `governance_operations.py:51`) — observability on, error-wrapping on (default), no input/output logging.

2. **Decoration order** — inner function wrapped as `@activity.defn(name=name, **activity_kwargs)` over `@wraps(func)` (`activities.py:100-101`). Activity name defaults to the function name and is preserved (Temporal replay keys on it; `activities.py:15-16, 103`). `name=None` for all three ⇒ names are exactly `persist_sustainment_sweep_side_effects`, `persist_governance_sweep_side_effects`, `list_active_modernization_workflows`.

3. **Observability (start/complete/fail log lines)** — stdlib `logging` on module logger `temporal_base.activities` (`activities.py:38`):
   - On entry, if `enable_observability`: `logger.info("Activity %s starting", activity_name, extra={"inputs": args if log_inputs else None})` (`activities.py:105-110`). `log_inputs=False` ⇒ `inputs=None`.
   - On success: `logger.info("Activity %s completed", ..., extra={"outputs": result if log_outputs else None})` (`activities.py:115-120`).
   - On exception: `logger.error("Activity %s failed: %s", activity_name, error, extra={"error": str(error)})` (`activities.py:125-131`).

4. **Error wrapping** (`activities.py:133-146`), only if `enable_error_wrapping` (default True):
   - `isinstance(error, (WorkflowError, ApplicationError))` → **re-raised unchanged** (`raise`) (`activities.py:135-136`). So `NonRetryableError` raised inside the body (e.g. governance's invalid-portfolio guard) passes through with its `non_retryable=True` flag intact.
   - else if `_is_retryable_error(error)` → wrapped in `RetryableError(f"Retryable error in {activity_name}: {error}")` (`activities.py:137-140`).
   - else → wrapped in `NonRetryableError(f"Non-retryable error in {activity_name}: {error}")` (`activities.py:141-144`).
   - If `enable_error_wrapping` is False, `raise` bare — not the case here.

5. **`_is_retryable_error(error)`** (`activities.py:56-76`): classifies by the **error type-name string** (`str(type(error)).lower()`), returning True if it contains any of: `timeout, connection, network, temporary, unavailable, overload, busy, throttle, rate_limit`. **GOTCHA:** this is a *type-name substring* heuristic, intentionally distinct from `errors.is_retryable_error` (which inspects httpx/OSError/ApplicationError instances) — `activities.py:57-63`. E.g. `asyncpg.PostgresConnectionError` → type name contains "connection" → RetryableError. A bare `ValueError`/`KeyError` from a projection bug → no match → NonRetryableError. Parity pinned by `tests/test_temporal_base_characterization.py` (`activities.py:20`).

6. **Error taxonomy** (`temporal_base/errors.py`): all subclass `temporalio.exceptions.ApplicationError`. `WorkflowError(msg, non_retryable=True)` (`errors.py:16-20`); `RetryableError` → `non_retryable=False` (`errors.py:23-27`); `NonRetryableError` → `non_retryable=True` (`errors.py:30-34`). The `non_retryable` flag is what Temporal reads to decide retry.

**Heartbeat:** none of these three activities call `activity.heartbeat()`; `heartbeat_timeout` is unset. No heartbeating.

---

## 1. Shared helpers (`line_transitions/_shared.py`)

Used by both persist activities.

### `_db_url()` — `_shared.py:23-29`
Builds `postgresql://{user}:{password}@{host}:{port}/{db}` from env with defaults: `DATABASE_HOST=localhost`, `DATABASE_PORT=5432`, `DATABASE_USER=olympus`, `DATABASE_PASSWORD=olympus`, `DATABASE_NAME=olympus`. Both persist activities connect via `asyncpg.connect(_db_url())`.

### `_try_parse_json(text) -> dict | None` — `_shared.py:40-56`
Best-effort parse of agent output that may include prose wrappers:
1. If `not text` (empty/None) → return `None`.
2. `json.loads(text)`; on `JSONDecodeError` → find first `{` and last `}` (`text.find("{")`, `text.rfind("}")`); if `start == -1 or end <= start` → `None`; else `json.loads(text[start:end+1])`; on second `JSONDecodeError` → `None`.
3. Return the value **only if `isinstance(value, dict)`**, else `None`. **GOTCHA:** a top-level JSON array or scalar parses successfully but returns `None` (dict-only gate).

`logger` for both persist modules = `_shared.py:20` module logger `...line_transitions._shared`.

`governance_operations.py` has its **own** logger (`logging.getLogger(__name__)`, `governance_operations.py:40`) and its **own** `_temporal_host()`/`_temporal_namespace()` (`governance_operations.py:43-48`) — duplicated from `_shared.py:32-37` (defaults `TEMPORAL_HOST=temporal:7233`, `TEMPORAL_NAMESPACE=default`).

---

## 2. `persist_sustainment_sweep_side_effects`

`sustainment.py:413-725`. Decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

### 2.1 Signature / IO

```python
async def persist_sustainment_sweep_side_effects(
    input: PersistSustainmentSweepSideEffectsInput,
) -> PersistSustainmentSweepSideEffectsResult
```

**Input dataclass** (`types.py:2744-2777`):
- `portfolio_id: str` (required)
- `schedule_id: str` (required)
- `sweep_completed_at: str = ""` (ISO-8601, `"Z"` suffix tolerated)
- `cve_triage_json: str = ""`
- `incident_response_json: str = ""`
- `sla_monitoring_json: str = ""`
- `change_conflict_json: str = ""`
- `cost_anomaly_json: str = ""`
- `override_decisions: list[dict] = field(default_factory=list)` — `override_approved` signal payloads
- `execution_context: StepExecutionContext | None = None`

**Result dataclass** (`types.py:2780-2797`): `portfolio_id`, `schedule_id`, `patching_compliance_rows=0`, `incident_log_rows=0`, `sla_compliance_rows=0`, `do_not_modify_flag_rows=0`, `cost_anomaly_rows=0`, `override_log_rows=0`, `application_rows_updated=0`.

### 2.2 Control flow (`sustainment.py:431-725`)

1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_sustainment_sweep_side_effects")` (`sustainment.py:431-434`). See §5 for `emit_code_step_start` semantics (returns `None` if `execution_context is None`).
2. Whole remainder wrapped in `try/except Exception as exc:` — on any exception, `emit_code_step_complete(exec_id, status=ExecutionStatus.FAILED, error=str(exc))` then `raise` (`sustainment.py:721-725`). The re-raised exception then hits `@foundry_activity`'s error wrapper.
3. Parse the five artifact JSON strings with `_try_parse_json` (`sustainment.py:436-440`): `cve_triage`, `incident_resp`, `sla_mon`, `change_conflict`, `cost_anomaly`. Each is `dict|None`.
4. **`sweep_completed_at` timestamp** (`sustainment.py:442-448`): if `input.sweep_completed_at` truthy → `datetime.fromisoformat(input.sweep_completed_at.replace("Z", "+00:00"))`; else `datetime.now(timezone.utc)`. This single value feeds every extractor's `evaluated_at`/`recorded_at`. **GOTCHA:** a malformed `sweep_completed_at` raises `ValueError` from `fromisoformat` → caught by the outer `except` → FAILED record + re-raise → NonRetryableError.
5. Run the six extractors (§2.3): `patching_row` (dict|None), `incident_rows`, `sla_rows`, `do_not_modify_rows`, `cost_rows` (lists), `override_rows` (list), then `lifecycle_updates` = list of `(app_id, updates)` (§2.4).
6. Build `counts` dict (`sustainment.py:492-500`): `patching_compliance_rows = 1 if patching_row else 0`, then `len(...)` of each list, `application_rows_updated=0` (filled later).
7. **Empty short-circuit** (`sustainment.py:502-522`): if `not any([patching_row, incident_rows, sla_rows, do_not_modify_rows, cost_rows, override_rows, lifecycle_updates])` → `logger.info("... nothing extractable", extra={portfolio_id, schedule_id})`; `emit_code_step_complete(exec_id, columns_written=[])`; **return** a Result carrying only `portfolio_id`/`schedule_id` (all counts default 0). No DB connection is opened.
8. Else: `conn = await asyncpg.connect(_db_url())` (`sustainment.py:524`); `app_updates_applied = 0`; `try: async with conn.transaction(): ...` — **all writes in one transaction**; `finally: await conn.close()` (`sustainment.py:526-695`). **GOTCHA:** the connection is opened *outside* the try that closes it? No — `conn` assigned at 524, `try` at 526, `finally: conn.close()` at 694. A connect failure at 524 (e.g. `asyncpg` connection error) propagates to the outer except; the inner `finally` is not reached because `conn` was never bound past connect. Connection-typed errors → `_is_retryable_error` matches "connection" → RetryableError (Temporal retries).
9. After transaction commits, `counts["application_rows_updated"] = app_updates_applied` (`sustainment.py:697`).
10. `logger.info("sustainment sweep side-effects persisted", extra={portfolio_id, **counts})` (`sustainment.py:699-702`).
11. `emit_code_step_complete(exec_id, columns_written=[...8 entries...])` (`sustainment.py:703-715`) — the fixed list: `patching_compliance`, `incident_log`, `sla_compliance_record`, `do_not_modify_flag`, `cost_anomaly_record`, `sustainment_override_log`, `application.sustainment_current_status`, `application.sustainment_last_sweep_at`.
12. Return `PersistSustainmentSweepSideEffectsResult(portfolio_id, schedule_id, **counts)` (`sustainment.py:716-720`).

**Idempotency:** NOT idempotent for the append tables — `patching_compliance`, `incident_log`, `sla_compliance_record`, `cost_anomaly_record`, `sustainment_override_log` are plain INSERTs (no dedup key), so a Temporal retry re-inserts duplicate rows. Only `do_not_modify_flag` is upsert-idempotent (ON CONFLICT). `application` UPDATEs are idempotent (last-write-wins on status/timestamp).

### 2.3 Extractors (all module-private, `sustainment.py`)

Two module-level constant sets: `_INCIDENT_SEVERITIES = frozenset({"P1","P2","P3","P4","critical","high","medium","low"})` (`sustainment.py:39-41`); `_CVE_SEVERITY_KEYS = ("critical","high","medium","low")` (`sustainment.py:44-46`, declared but unused in extraction).

#### `_extract_patching_compliance_row(artifact, *, portfolio_id, schedule_id, evaluated_at) -> dict|None` — `sustainment.py:49-111`
Projects `cve-triage.json` → one `patching_compliance` row.
- If `not isinstance(artifact, dict)` → `None` (`:63-64`).
- `summary = artifact.get("summary") or artifact.get("compliance") or artifact` (`:65`); if `summary` not dict → `{}` (`:66-67`).
- Local `_count(key)`: reads `summary[f"{key}_open_count"] or summary[f"{key}_open"] or summary[f"open_{key}"] or 0`, `int(...)` with `(TypeError,ValueError)→0` (`:69-79`).
- `crit=_count("critical")`, `high`, `med`, `low` (`:81-84`).
- `sla_pct_raw = summary["sla_compliance_pct"] or summary["sla_compliance"] or summary["compliance_pct"]` (`:86-90`); `sla_pct = float(sla_pct_raw) if not None else None`, `(TypeError,ValueError)→None` (`:91-96`).
- **Skip rule** (`:98-100`): if `(crit+high+med+low)==0 and sla_pct is None` → `None`.
- Row (`:102-111`): `{portfolio_id, sweep_id: schedule_id, critical_open_count, high_open_count, medium_open_count, low_open_count, sla_compliance_pct, evaluated_at}`.
- **GOTCHA:** the `or`-chain uses falsy semantics: an explicit `0` count under `critical_open_count` is treated as absent and falls through to the aliases / default 0 (harmless here since default is 0). But a real `sla_compliance_pct` of `0.0` is falsy → falls through to aliases, and if all absent → `None`.

#### `_extract_incident_log_rows(artifact, *, portfolio_id, schedule_id, recorded_at) -> list[dict]` — `sustainment.py:114-157`
Projects `incident-response.json` → one row per incident.
- Non-dict artifact → `[]`.
- `incidents = artifact.get("incidents") or artifact.get("processed_incidents") or []` (`:124-128`); if not list → `[]`.
- Per `inc` (skip non-dict): `app_id = inc["app_id"] or inc["application_id"] or ""`; `severity = str(inc["severity"] or "").strip()`; (severity-whitelist check exists but is a no-op `pass` — comment: "Keep whatever the agent emitted; DB column is VARCHAR(16)" `:137-139`); `symptom = str(inc["symptom"] or inc["category"] or "")`; `status = str(inc["status"] or "open")`; `resolution = str(inc["resolution_summary"] or inc["resolution"] or "")`.
- Row (`:147-156`): `{portfolio_id, sweep_id: schedule_id, app_id: str(app_id) if app_id else None, severity: severity[:16] if severity else "unknown", symptom, status, resolution_summary: resolution, recorded_at}`.
- **GOTCHA:** severity truncated to 16 chars only when truthy; when empty → literal `"unknown"`. `app_id` becomes `None` when falsy — but the INSERT passes `row["app_id"] or ""` and uses `NULLIF($3,'')::uuid` (see §2.5).

#### `_extract_sla_compliance_rows(artifact, *, portfolio_id, schedule_id, recorded_at) -> list[dict]` — `sustainment.py:160-222`
Projects `sla-monitoring.json` → one row per app.
- Non-dict → `[]`. `apps = artifact.get("apps") or artifact.get("measurements") or artifact.get("sla_records") or []` (`:170-175`); non-list → `[]`.
- Per `m` (skip non-dict): `app_id = m["app_id"] or m["application_id"] or ""`; **if not app_id → `continue`** (skip) (`:182-184`).
- Nested helpers: `_f(keys)` returns first `float`-castable value across the key tuple (else `None`) (`:186-195`); `_i(keys)` first `int`-castable (else `0`) (`:197-206`).
- Row (`:208-221`): `{portfolio_id, sweep_id: schedule_id, app_id: str(app_id), availability_pct: _f(("availability_pct","availability")), response_time_p95_ms: _f(("response_time_p95_ms","p95_ms","latency_p95_ms")), incident_resolution_mean_hours: _f(("incident_resolution_mean_hours","mttr_hours")), breach_count: _i(("breach_count","breaches")), recorded_at}`.

#### `_extract_do_not_modify_rows(artifact, *, portfolio_id, recorded_at) -> list[dict]` — `sustainment.py:225-270`
Projects `change-conflict.json` → upsert rows (one per flagged app). Note: no `schedule_id`/`sweep_id` on this table.
- Non-dict → `[]`. `flags = artifact.get("do_not_modify_flags") or artifact.get("flags") or []` (`:240-244`); non-list → `[]`.
- Per `f` (skip non-dict): `app_id = f["app_id"] or f["application_id"] or ""`; **if not app_id → `continue`**.
- Row (`:256-269`): `{portfolio_id, app_id: str(app_id), flagged_at: (f["flagged_at"] if isinstance str else recorded_at.isoformat()), wave_id: str(f["wave_id"] or "") or None, expires_at: (f["expires_at"] if isinstance str else None), active: bool(f.get("active", True)), override_count: int(f.get("override_count",0) or 0)}`.
- **GOTCHA:** `active` defaults **True** when absent; `override_count` extracted from the artifact each sweep — but the DB upsert sets `override_count = EXCLUDED.override_count`, so a sweep artifact that omits it (→0) **overwrites** an accumulated count to 0. The migration docstring claims override_count "must be preserved" (`037...py:41`); the actual ON CONFLICT clobbers it with the incoming value. Preservation only holds if the change-conflict activity re-declares the current count each sweep.

#### `_extract_cost_anomaly_rows(artifact, *, portfolio_id, schedule_id, recorded_at) -> list[dict]` — `sustainment.py:273-320`
Projects `cost-anomaly.json` → one row per app.
- Non-dict → `[]`. `anomalies = artifact.get("anomalies") or artifact.get("apps") or artifact.get("findings") or []` (`:283-288`); non-list → `[]`.
- Per `a` (skip non-dict): `app_id = a["app_id"] or a["application_id"] or ""`; **if not app_id → `continue`**.
- Nested `_f(keys)` (float-or-None). Row (`:310-319`): `{portfolio_id, sweep_id: schedule_id, app_id: str(app_id), baseline_usd: _f(("baseline_usd","baseline")), observed_usd: _f(("observed_usd","observed","actual_usd")), variance_pct: _f(("variance_pct","variance")), flagged: bool(a.get("flagged", False)), recorded_at}`.

#### `_extract_sustainment_override_log_rows(override_decisions, *, portfolio_id, recorded_at) -> list[dict]` — `sustainment.py:323-346`
Projects the input's `override_decisions` list (NOT an artifact JSON) → log rows.
- `if not isinstance(override_decisions, list)` → `[]`.
- Per `dec` (skip non-dict): `gate_id = dec["gate_id"] or ""`. Row (`:337-345`): `{portfolio_id, app_id: str(dec["app_id"] or "") or None, gate_id: str(gate_id), override_by: str(dec["override_by"] or ""), justification: str(dec["justification"] or ""), override_type: str(dec["override_type"] or ""), recorded_at}`.
- **GOTCHA:** no skip on empty app_id (unlike sla/cost/do-not-modify) — every dict decision emits a row; app_id becomes `None` when falsy.

### 2.4 `_extract_application_lifecycle_updates(...)` — `sustainment.py:349-410`
Computes per-app `sustainment_current_status` + `sustainment_last_sweep_at`. Signature: keyword-only `do_not_modify_rows, incident_rows, sla_rows, cost_rows, sweep_completed_at`. Returns `list[(app_id, updates_dict)]`.

- `per_app: dict[str, dict]`. Local `_mark(app_id, status=None)` (`:373-384`):
  - if not `app_id` → return.
  - `entry = per_app.setdefault(app_id, {"sustainment_last_sweep_at": sweep_completed_at})` — every touched app gets the timestamp.
  - Status ladder (attention-required wins): if `status=="attention-required"` → set it; elif `status=="monitoring" and current != "attention-required"` → set monitoring. (No status → only timestamp.)
- Passes (order matters for which rows are visited, but ladder is order-independent for the final winner):
  1. incidents (`:386-393`): `sev = str(inc["severity"] or "").lower()`; status = `"attention-required"` if `sev in {"p1","critical"}` else `"monitoring"`; `_mark(str(inc["app_id"] or ""), status)`. **GOTCHA:** incident rows store severity possibly truncated/`"unknown"`; here lowercased and matched against `{"p1","critical"}` only (note P2/P3/high etc → monitoring). Empty app_id (incident rows can have None app_id) → `_mark("")` → no-op.
  2. do_not_modify (`:395-397`): if `flag["active"]` → `_mark(app_id, "attention-required")`.
  3. sla (`:399-402`): `breach = int(sla["breach_count"] or 0)`; attention-required if `breach>0` else monitoring.
  4. cost (`:404-408`): if `cost["flagged"]` → attention-required, else monitoring.
- Returns `list(per_app.items())`.
- **GOTCHA:** patching_compliance and override rows do NOT feed lifecycle status. Only incident/do-not-modify/sla/cost do.

### 2.5 DB writes — table by table (inside `async with conn.transaction()`)

All SQL uses asyncpg positional `$n`. Order of writes: patching → incident → sla → do_not_modify → cost → override → application.

**patching_compliance** (`sustainment.py:528-546`), only if `patching_row`:
```
INSERT INTO patching_compliance (portfolio_id, sweep_id, critical_open_count,
  high_open_count, medium_open_count, low_open_count, sla_compliance_pct, evaluated_at)
VALUES ($1::uuid, $2, $3, $4, $5, $6, $7, $8)
```
params: portfolio_id, sweep_id(=schedule_id), 4 counts (int), sla_compliance_pct (float|None → NUMERIC(5,2)), evaluated_at (datetime → TIMESTAMPTZ). Schema `037...py:63-108`.

**incident_log** (`sustainment.py:548-568`), per row:
```
INSERT INTO incident_log (portfolio_id, sweep_id, app_id, severity, symptom,
  status, resolution_summary, recorded_at)
VALUES ($1::uuid, $2, NULLIF($3, '')::uuid, $4, $5, $6, $7, $8)
```
params: portfolio_id, sweep_id, **`row["app_id"] or ""`** (so a `None`/empty → `''` → `NULLIF→NULL::uuid`), severity (VARCHAR(16), NOT NULL — always non-empty because `"unknown"` fallback), symptom (VARCHAR(255) nullable), status (VARCHAR(32) NOT NULL), resolution_summary (Text nullable), recorded_at. Schema `037...py:116-142`; `app_id` FK `ON DELETE SET NULL`.

**sla_compliance_record** (`sustainment.py:570-592`), per row:
```
INSERT INTO sla_compliance_record (portfolio_id, sweep_id, app_id, availability_pct,
  response_time_p95_ms, incident_resolution_mean_hours, breach_count, recorded_at)
VALUES ($1::uuid, $2, $3::uuid, $4, $5, $6, $7, $8)
```
params: portfolio_id, sweep_id, app_id (`str(app_id)`, cast `::uuid` — **NOT NULLIF'd**, and rows always have truthy app_id due to extractor skip), availability_pct (NUMERIC(5,3)), response_time_p95_ms (NUMERIC(10,2)), incident_resolution_mean_hours (NUMERIC(10,2)), breach_count (int, NOT NULL default 0), recorded_at. Schema `037...py:156-199`; FK `ON DELETE CASCADE`, NOT NULL. **GOTCHA:** a non-UUID app_id here raises inside the transaction → whole projection rolls back → outer except → FAILED. Extractors do not UUID-validate.

**do_not_modify_flag** (`sustainment.py:594-619`), per row, UPSERT:
```
INSERT INTO do_not_modify_flag (portfolio_id, app_id, flagged_at, wave_id,
  expires_at, active, override_count)
VALUES ($1::uuid, $2::uuid, $3::timestamptz, NULLIF($4,'')::uuid, $5::timestamptz, $6, $7)
ON CONFLICT (portfolio_id, app_id) DO UPDATE SET
  wave_id = EXCLUDED.wave_id, expires_at = EXCLUDED.expires_at,
  active = EXCLUDED.active, override_count = EXCLUDED.override_count
```
params: portfolio_id, app_id (`str`), flagged_at (str ISO or recorded_at.isoformat()), **`row["wave_id"] or ""`** (NULLIF), expires_at (str|None), active (bool), override_count (int). Conflict target = unique constraint `uq_do_not_modify_flag_portfolio_app` (`037...py:255-257`). Note `flagged_at` is **NOT** updated on conflict (preserves original flag time); wave_id/expires_at/active/override_count are overwritten. Schema `037...py:212-258`.

**cost_anomaly_record** (`sustainment.py:621-641`), per row:
```
INSERT INTO cost_anomaly_record (portfolio_id, sweep_id, app_id, baseline_usd,
  observed_usd, variance_pct, flagged, recorded_at)
VALUES ($1::uuid, $2, $3::uuid, $4, $5, $6, $7, $8)
```
params: portfolio_id, sweep_id, app_id(str,::uuid), baseline_usd (NUMERIC(14,2)), observed_usd (NUMERIC(14,2)), variance_pct (NUMERIC(7,2)), flagged (bool), recorded_at. Schema `037...py:267-298`; FK CASCADE.

**sustainment_override_log** (`sustainment.py:643-663`), per row:
```
INSERT INTO sustainment_override_log (portfolio_id, app_id, gate_id, override_by,
  justification, override_type, recorded_at)
VALUES ($1::uuid, NULLIF($2,'')::uuid, $3, $4, $5, $6, $7)
```
params: portfolio_id, **`row["app_id"] or ""`** (NULLIF), gate_id (VARCHAR(255) nullable), override_by (VARCHAR(255) NOT NULL), justification (Text nullable), override_type (VARCHAR(64) NOT NULL), recorded_at. Schema `037...py:312-337`; app_id FK SET NULL.

**application lifecycle UPDATE** (`sustainment.py:665-693`), per `(app_id, updates)`:
- `try: target_uuid = uuid.UUID(app_id) except (ValueError,TypeError): continue` (`:666-669`) — **invalid app_id silently skipped** (does NOT abort txn, unlike sla/cost inserts).
- Dynamic SQL build: `assignments=[]`, `params=[]`, `idx=1`.
  - If `"sustainment_current_status" in updates`: append `sustainment_current_status = ${idx}`, param = the status; idx++.
  - Always: `sustainment_last_sweep_at = ${idx}`, param = `updates["sustainment_last_sweep_at"]` (= sweep_completed_at); idx++.
  - Always: `updated_at = ${idx}`, param = `datetime.now(timezone.utc)`; idx++.
  - `sql = "UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${idx}"`; append `target_uuid`.
- `result = await conn.execute(sql, *params)`; if `result.endswith(" 1")` → `app_updates_applied += 1` (`:691-693`). **GOTCHA:** counts only rows that actually matched (asyncpg returns `"UPDATE 1"` / `"UPDATE 0"`); a status-only-absent app still updates `sustainment_last_sweep_at`. Columns `sustainment_current_status VARCHAR(64) NULL`, `sustainment_last_sweep_at TIMESTAMPTZ NULL` from `037...py:344-360`.

---

## 3. `persist_governance_sweep_side_effects`

`governance.py:323-600`. `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

### 3.1 Signature / IO
```python
async def persist_governance_sweep_side_effects(
    input: PersistGovernanceSweepSideEffectsInput,
) -> PersistGovernanceSweepSideEffectsResult
```
**Input** (`types.py:2584-2614`): `portfolio_id`, `schedule_id`, `cadence: str="weekly"` (`"weekly"|"quarterly"`), `drift_detection_json=""`, `pattern_extraction_json=""`, `health_report_json=""`, `factory_capacity_json=""`, `model_evaluation_json=""` (empty on weekly), `pattern_reuse_acks: list[dict]=[]`, `execution_context: StepExecutionContext|None=None`.
**Result** (`types.py:2617-2631`): `portfolio_id`, `schedule_id`, `drift_alerts_inserted=0`, `patterns_inserted=0`, `patterns_reuse_count_updated=0`, `health_checks_inserted=0`, `factory_capacity_plans_inserted=0`, `model_benchmark_results_inserted=0`.

Constant sets: `_DRIFT_TYPES = frozenset({"architecture","compliance","performance","cost","adoption"})` (`governance.py:41-43`); `_DRIFT_SEVERITIES = frozenset({"critical","high","medium","low"})` (`:46-48`); `_MODEL_TIERS = frozenset({"Tier-1","Tier-2","Tier-3"})` (`:51`).

### 3.2 Control flow (`governance.py:340-600`)
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_governance_sweep_side_effects")` (`:340-343`).
2. `try:` ... `except Exception as exc: emit_code_step_complete(exec_id, status=FAILED, error=str(exc)); raise` (`:596-600`).
3. **Portfolio validation** (`:345-350`): `try: portfolio_uuid = uuid.UUID(input.portfolio_id) except (ValueError,TypeError) as exc: raise NonRetryableError(f"Invalid portfolio_id: {input.portfolio_id!r}") from exc`. **GOTCHA:** this `NonRetryableError` is caught by the outer `except`, emits a FAILED record, re-raises; `@foundry_activity` sees it's a `WorkflowError` subclass → passes through unchanged → Temporal treats as non-retryable. Unlike sustainment (which never UUID-validates portfolio up front), governance fails fast on a bad portfolio_id.
4. Extract per-artifact rows (§3.3): `drift_alert_rows`, `pattern_rows`, `health_row` (dict|None), `capacity_row` (dict|None).
5. **Model benchmark — quarterly gate** (`:365-370`): `model_rows = []`; `if input.cadence == "quarterly" and input.model_evaluation_json: model_rows = _extract_model_benchmark_side_effects(_try_parse_json(input.model_evaluation_json))`. On weekly cadence (or empty json) → skipped entirely.
6. `reuse_updates = _apply_pattern_reuse_count_updates(input.pattern_reuse_acks)` (`:372-374`).
7. **Empty short-circuit** (`:376-395`): if all of `not drift_alert_rows and not pattern_rows and health_row is None and capacity_row is None and not model_rows and not reuse_updates` → log "nothing extractable", `emit_code_step_complete(exec_id, columns_written=[])`, return Result with just portfolio_id/schedule_id. No DB connection.
8. `now_ts = datetime.now(timezone.utc)` (`:397`).
9. `conn = await asyncpg.connect(_db_url())`; counters `drift_inserted/patterns_inserted/reuse_updated/health_inserted/capacity_inserted/model_inserted = 0`; `try: async with conn.transaction(): <writes>; finally: conn.close()` (`:399-560`).
10. `logger.info("governance sweep side-effects persisted", extra={portfolio_id, schedule_id, cadence, drift_alerts, patterns, patterns_reuse_updated, health_checks, factory_capacity_plans, model_benchmark_results})` (`:562-575`).
11. `emit_code_step_complete(exec_id, columns_written=["drift_alert","pattern","health_check","factory_capacity_plan","model_benchmark_result"])` (`:576-585`).
12. Return `PersistGovernanceSweepSideEffectsResult(portfolio_id, schedule_id, drift_alerts_inserted=..., patterns_inserted=..., patterns_reuse_count_updated=..., health_checks_inserted=..., factory_capacity_plans_inserted=..., model_benchmark_results_inserted=...)` (`:586-595`).

**Idempotency:** drift_alert, pattern, health_check, factory_capacity_plan, model_benchmark_result are all plain INSERTs (no unique/upsert key) → retries duplicate. The `pattern.reuse_count` UPDATE is additive (`reuse_count + $delta`) → a retry double-counts. NOT idempotent.

### 3.3 Extractors (`governance.py`)

#### `_extract_drift_alert_side_effects(artifact) -> list[dict]` — `governance.py:54-106`
`drift-detection.json` shape `{"alerts":[{app_id, drift_type, severity, details, acknowledged}]}`.
- Non-dict → `[]`; `alerts = artifact.get("alerts")`; non-list → `[]`.
- Per `entry` (skip non-dict): validate `drift_type` — if not `str` or not in `_DRIFT_TYPES` → `logger.warning("drift_alert row skipped — invalid drift_type", extra={drift_type})` + `continue` (`:80-85`). Validate `severity` similarly against `_DRIFT_SEVERITIES` (`:86-91`).
- `app_id`, `details`, `acknowledged` read. Row (`:95-105`): `{app_id: app_id if (isinstance str and truthy) else None, drift_type, severity, details: details if isinstance(details,dict) else {}, acknowledged: bool(acknowledged) if isinstance(acknowledged,bool) else False}`.

#### `_extract_pattern_side_effects(artifact) -> list[dict]` — `governance.py:109-155`
`pattern-extraction.json` shape `{"patterns":[{name, category, wave_id, source_apps, content, description}]}`.
- Non-dict → `[]`; `patterns = artifact.get("patterns")`; non-list → `[]`.
- Per `entry` (skip non-dict): `name`, `category` — **if either not a non-empty str → `continue`** (`:131-136`). `source_apps` → `[]` if not list; `content` → `{}` if not dict; `wave_id`; `description`.
- Row (`:145-154`): `{name, category, wave_id: wave_id if (str and truthy) else None, source_apps, content, description: description if isinstance str else None}`.

#### `_extract_health_check_side_effects(artifact) -> dict|None` — `governance.py:158-190`
`health-report.json` shape `{portfolio_health_index, per_dimension_findings, sweep_date}`.
- Non-dict → `None`. `idx = artifact.get("portfolio_health_index") or artifact.get("health_index")` (`:174-177`); **if not `isinstance(idx,(int,float))` → `None`** (column is NOT NULL, skip rather than sentinel) (`:178-179`). **GOTCHA:** `or`-chain: a health_index of `0` or `0.0` is falsy → falls through to `health_index` alias, and if both 0/absent → treated as missing → None.
- `checks = artifact.get("per_dimension_findings") or artifact.get("checks") or []`; non-list → `[]`.
- Return `{"health_index": float(idx), "checks": checks}` (`:187-190`).

#### `_extract_factory_capacity_side_effects(artifact) -> dict|None` — `governance.py:193-222`
`factory-capacity.json`.
- Non-dict → `None`. `out={}`. `scalar_fields` tuple (`:205-215`): `concurrent_wave_max, throughput_apps_per_month, cost_per_app_usd, gate_first_pass_rate, ralph_loop_iteration_avg, escalation_rate, pattern_reuse_rate, automation_ratio, time_to_modernize_days`.
- Per field: if `isinstance(val,(int,float))` → `out[field] = int(val) if field=="concurrent_wave_max" else float(val)` (`:216-219`). **GOTCHA:** `concurrent_wave_max` is stored as `int`, all others `float`. Missing/non-numeric fields simply absent from `out` (→ INSERT sends `None` via `.get`).
- If `not out` → `None` (`:220-221`).

#### `_extract_model_benchmark_side_effects(artifact) -> list[dict]` — `governance.py:225-294`
`model-evaluation.json` shape `{"results":[{model_id, tier, task_suite, pass_rate, cost_per_call_usd, latency_p95_ms, regression_flag, refresh_recommended, benchmarked_at}]}`.
- Non-dict → `[]`; `results = artifact.get("results")`; non-list → `[]`.
- Per `entry` (skip non-dict): `model_id`, `task_suite` must be non-empty str else `continue` (`:255-258`); `tier` must be str in `_MODEL_TIERS` else `logger.warning("... invalid tier", extra={model_id, tier})` + `continue` (`:259-264`).
- Row base `{model_id, tier, task_suite}`. Optional fields added only when correctly typed:
  - `pass_rate`, `cost_per_call_usd`: added if `isinstance(val,(int,float))` → `float(val)` (`:271-274`).
  - `latency_p95_ms`: added if numeric → `int(latency)` (`:275-277`).
  - `regression_flag`, `refresh_recommended`: added if `isinstance(val,bool)` (`:278-281`).
  - `benchmarked_at`: if non-empty str → `datetime.fromisoformat(benchmarked_at.replace("Z","+00:00"))`; on `(TypeError,ValueError)` → `logger.warning("... benchmarked_at not ISO-8601", ...)` and the key is **omitted** (`:282-292`).

#### `_apply_pattern_reuse_count_updates(acks) -> list[(str,int)]` — `governance.py:297-320`
Flatten `wave_patterns_ready` acks → `(pattern_name, delta)`.
- Non-list → `[]`. `totals: dict[str,int]`.
- Per `entry` (skip non-dict): `name = entry.get("pattern_name")`; must be non-empty str else `continue`; `delta = entry.get("delta") if isinstance(entry.get("delta"),int) else 1` (`:316-318`); `totals[name] += int(delta)` (collapses dup names by sum).
- Return `[(name, delta) for name, delta in totals.items() if delta > 0]`. **GOTCHA:** non-int delta defaults to **1**; only positive totals emitted (a net-zero/negative total is dropped).

### 3.4 DB writes (inside `async with conn.transaction()`)
Order: drift_alert → pattern (INSERT) → pattern.reuse_count UPDATE → health_check → factory_capacity_plan → model_benchmark_result.

**drift_alert** (`governance.py:409-433`), per row:
- `app_uuid=None`; if `row["app_id"]`: `try uuid.UUID(row["app_id"]) except (ValueError,TypeError): app_uuid=None` (invalid → NULL, no abort).
```
INSERT INTO drift_alert (type, application_id, details, acknowledged, created_at)
VALUES ($1, $2, $3::jsonb, $4, $5)
```
params: `row["drift_type"]` → `type` (VARCHAR(100) NOT NULL), app_uuid → `application_id` (UUID nullable, FK CASCADE), **`json.dumps({"severity": row["severity"], **(row.get("details") or {})})`** → `details` JSONB (severity merged INTO details as a key — there is no dedicated severity column on the table), `row["acknowledged"]` (bool), `now_ts`. `drift_inserted += 1`. Schema `025...py:55-85`. **GOTCHA:** severity lives only inside `details.severity`; if the artifact's `details` also has a `severity` key, the explicit one is placed first and then overwritten by the spread `**details`.

**pattern** (`governance.py:436-460`), per row:
- `wave_uuid` = `uuid.UUID(row["wave_id"])` if present else None (invalid → None).
```
INSERT INTO pattern (name, category, description, wave_id, source_apps, reuse_count, content, created_at)
VALUES ($1, $2, $3, $4, $5::jsonb, 0, $6::jsonb, $7)
```
params: name, category, `row.get("description")` (nullable), wave_uuid, `json.dumps(row["source_apps"])`::jsonb, `reuse_count` hardcoded literal **0** in SQL, `json.dumps(row["content"])`::jsonb, now_ts. `patterns_inserted += 1`. Schema `025...py:94-120` (source_apps NOT NULL default `[]`, content nullable).

**pattern.reuse_count bulk UPDATE** (`governance.py:463-478`), per `(name, delta)`:
```
UPDATE pattern SET reuse_count = reuse_count + $1 WHERE name = $2
```
params: delta, name. asyncpg returns `"UPDATE N"`; `try: count = int(result.rsplit(" ",1)[-1]) except (ValueError,IndexError): count = 0`; `reuse_updated += count` (`:474-478`). **GOTCHA:** matches by `name` (not unique) → all patterns sharing a name get incremented; `reuse_updated` counts total matched rows across all deltas, not distinct patterns.

**health_check** (`governance.py:481-496`), only if `health_row is not None`:
```
INSERT INTO health_check (portfolio_id, date, health_index, checks, created_at)
VALUES ($1, $2, $3, $4::jsonb, $5)
```
params: portfolio_uuid, **`now_ts.date()`** (DATE — the sweep's own date, NOT the artifact's sweep_date), `health_row["health_index"]` (NUMERIC(4,3) NOT NULL), `json.dumps(health_row["checks"])`::jsonb, now_ts. `health_inserted = 1`. Schema `025...py:28-46`.

**factory_capacity_plan** (`governance.py:499-531`), only if `capacity_row is not None`:
```
INSERT INTO factory_capacity_plan (portfolio_id, sweep_id, concurrent_wave_max,
  throughput_apps_per_month, cost_per_app_usd, gate_first_pass_rate,
  ralph_loop_iteration_avg, escalation_rate, pattern_reuse_rate, automation_ratio,
  time_to_modernize_days, computed_at)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
```
params: portfolio_uuid, `input.schedule_id` (sweep_id VARCHAR(255) NOT NULL), then `capacity_row.get(<field>)` for each of the 9 scalar fields (**None when absent** — all columns nullable), computed_at=now_ts. `capacity_inserted = 1`. Schema `038...py:47-76`.

**model_benchmark_result** (`governance.py:534-558`), per row (only populated on quarterly):
```
INSERT INTO model_benchmark_result (portfolio_id, sweep_id, model_id, tier,
  task_suite, pass_rate, cost_per_call_usd, latency_p95_ms, regression_flag,
  refresh_recommended, benchmarked_at)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
```
params: portfolio_uuid, input.schedule_id, model_id, tier, task_suite, `row.get("pass_rate")`, `row.get("cost_per_call_usd")`, `row.get("latency_p95_ms")`, `row.get("regression_flag", False)`, `row.get("refresh_recommended", False)`, **`row.get("benchmarked_at") or now_ts`**. `model_inserted += 1`. Schema `038...py:91-125` (regression_flag/refresh_recommended NOT NULL default false; benchmarked_at NOT NULL). **GOTCHA:** `benchmarked_at` falls back to `now_ts` if the extractor omitted it (unparseable/absent).

---

## 4. `list_active_modernization_workflows`

`governance_operations.py:51-117`. `@foundry_activity(config=ActivityConfig(enable_observability=True))`. Part of the F5 compound-growth flywheel: Governance extracts patterns and needs to enumerate in-flight Modernization workflows so it can (in the *workflow*, not here) signal each with `wave_patterns_ready` (`governance_operations.py:1-25`). This activity does only the I/O of listing candidate workflow IDs.

### 4.1 Signature / IO
```python
async def list_active_modernization_workflows(
    input: ListActiveModernizationWorkflowsInput,
) -> ListActiveModernizationWorkflowsResult
```
**Input** (`types.py:2890-2901`): `portfolio_id: str`. **Result** (`types.py:2904-2915`): `workflow_ids: list[str] = []`.

### 4.2 Control flow (`governance_operations.py:66-117`)
1. `portfolio_id = (input.portfolio_id or "").strip()`; **if empty → return `Result(workflow_ids=[])`** immediately (`:66-68`).
2. **Connect** (`:70-80`): `try: client = await Client.connect(_temporal_host(), namespace=_temporal_namespace())`; `except Exception as exc: logger.warning("governance propagation: failed to connect to Temporal: %s", exc, extra={portfolio_id}); return Result([])`. Best-effort — connect failure returns empty, does NOT raise.
3. **Query** (`:82-85`): `query = "WorkflowType = 'ModernizationWorkflow' AND ExecutionStatus = 'Running'"` — Temporal Visibility list filter.
4. **List loop** (`:87-110`): `matched=[]`; `try: async for desc in client.list_workflows(query=query): wf_id = getattr(desc, "id", "") or ""; if wf_id: matched.append(wf_id)`. On `except Exception as exc:` → `logger.warning("governance propagation: list_workflows failed: %s", exc, extra={portfolio_id})`; **return `Result(workflow_ids=matched)`** — returns whatever was collected before the error, still no raise.
5. On success: `logger.info("governance propagation: found %d active Modernization workflows", len(matched), extra={portfolio_id})`; return `Result(workflow_ids=matched)` (`:112-117`).

### 4.3 Key behaviors / GOTCHAs
- **Best-effort by design** (`governance_operations.py:16-24`): Temporal unreachable, DB unreachable, or no active workflows all collapse to an empty list, never an exception — the compound-growth loop is a learning aid, not a correctness invariant. All `except` blocks use `# noqa: BLE001` broad catches.
- **GOTCHA — portfolio filter is NOT applied.** Despite docstrings (`governance_operations.py:22-24`, `types.py:2894-2899`) implying per-portfolio scoping, the implementation returns **every** running `ModernizationWorkflow` regardless of portfolio (`:87-101`). The inline comment explains: current workflow-ID conventions embed `app_id` but NOT `portfolio_id`, so visibility-level portfolio filtering isn't feasible without a search-attribute deploy migration; filtering is deferred to the signal consumer (`:90-98`). The `portfolio_id` input is used **only** for the empty-string guard and log `extra` — it never filters results.
- Because every branch returns (or the decorator would wrap a raised error), and all bodies catch broadly, this activity effectively never surfaces an error to Temporal. The `@foundry_activity` error-wrapping path is unreachable in practice here.
- Uses its own `_temporal_host()`/`_temporal_namespace()` (`governance_operations.py:43-48`), env `TEMPORAL_HOST` (default `temporal:7233`) / `TEMPORAL_NAMESPACE` (default `default`).

---

## 5. Execution-record emission (`utils/execution.py`) — shared by both persist activities

Both persist activities bracket their body with `emit_code_step_start` / `emit_code_step_complete`.

### `emit_code_step_start(ctx, *, function_name, columns_writable=None) -> uuid.UUID | None` — `execution.py:283-321`
- **If `ctx is None` → return `None`** (`:295-296`). Legacy call sites without `execution_context` skip emission entirely; both persist activities then pass `None` to `emit_code_step_complete` (which no-ops).
- Sources `workflow_id` + `attempt` from `activity.info()`; on any exception (e.g. called outside activity context in tests) → `workflow_id=""`, `attempt=1` (`:297-303`).
- `payload = {"function": function_name}`; if `columns_writable` given, add `payload["columns_written"]` (persist activities don't pass it at start).
- Calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.CODE, workflow_id=..., app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=..., payload=payload, status=ExecutionStatus.RUNNING))` (`:308-321`).

### `emit_code_step_complete(execution_id, *, status=COMPLETED, columns_written=None, error=None)` — `execution.py:324-345`
- `payload_merge = {"columns_written": columns_written}` if `columns_written is not None` else None. Calls `update_execution_record(execution_id, status=status, payload_merge=payload_merge, last_error=error)`.

### `emit_execution_record` / `update_execution_record` — `execution.py:150-276`
- **Best-effort:** both wrap DB I/O in `try/except Exception` → `logger.warning(...)`, return `None`/no-op (`:212-219`, `:270-275`). A `step_execution` write failure NEVER propagates into the activity result — module docstring `:32-34`.
- `emit_execution_record` (`:150-219`): generates `execution_id = uuid.uuid4()`; parses app/wave/portfolio/agent_task/gate UUIDs via `_parse_uuid` (`""`/None/invalid → None, `:136-142`). **If `portfolio_uuid is None` → log warning + return None** (skip). INSERT into `step_execution` (`:179-208`) with `step_kind.value`/`status.value` strings, `input_artifacts`/`payload` as `::jsonb`. Returns `execution_id`.
- `update_execution_record` (`:222-276`): if `execution_id is None` → return. Computes `duration_ms = EXTRACT(EPOCH FROM ($completed - started_at)) * 1000`; `output_artifacts = COALESCE($4, existing)`; `payload = payload || COALESCE($5,'{}')` (shallow JSONB merge); `last_error = COALESCE($6, existing)` (`:250-267`).

**GOTCHA:** the persist activities' `except` path calls `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` BEFORE re-raising — but if `exec_id` is None (no execution_context) this is a silent no-op, and if the DB is down the emit itself is swallowed. The FAILED step_execution record is thus best-effort and may be absent.

`StepExecutionContext` (`types.py:538-561`): `portfolio_id` (required), `line_id`, `step_id`, `app_id=""`, `wave_id=""`, `input_artifact_paths=[]`, `gate_id=""`.

---

## 6. Cross-cutting summary of failure → retry mapping

| Failure | Where | Result |
|---|---|---|
| Unparseable artifact JSON | `_try_parse_json` → None | Extractor returns empty; no raise; may hit empty short-circuit |
| `sweep_completed_at` not ISO | `sustainment.py:443` `fromisoformat` | ValueError → outer except → FAILED record + re-raise → NonRetryableError (type-name has no retryable token) |
| Invalid `portfolio_id` (governance) | `governance.py:346-350` | Explicit `NonRetryableError` → passes through decorator unchanged (non_retryable) |
| Invalid `portfolio_id` (sustainment) | not validated up front | Used only as `$1::uuid` in INSERTs; a bad value raises inside txn → rollback → outer except → NonRetryableError |
| Non-UUID app_id in sla/cost/drift-required INSERT | inside txn | asyncpg raises → txn rollback → FAILED + re-raise (drift/pattern app_id are pre-validated to None; sla/cost are NOT) |
| Non-UUID app_id in application UPDATE (sustainment) | `sustainment.py:667-669` | Silently `continue` — no abort |
| `asyncpg.connect` failure | connect line | Connection-typed error name → RetryableError → Temporal retries (re-inserts risk: NOT idempotent) |
| Temporal client connect / list failure | `governance_operations` | Swallowed → empty list, never raises |

**Retry-safety warning:** none of the INSERT-only tables carry a dedup key, and `pattern.reuse_count`/lifecycle updates are additive/last-write. A Temporal retry after a partial-then-connection-error will duplicate append rows. Callers treat these projections as best-effort and (per docstrings) the workflow swallows failures at the call site so the sweep-summary commit is not blocked.
