# Activity group: `autonomy_eval` (autonomy-level resolution + decision recording)

Source file: `temporal/olympus_workflows/activities/autonomy_eval.py` (P10-S18.1, autonomy-gating-delta).
All three activities are `@foundry_activity`-decorated (they are Temporal activities). This module
delegates every *decision* to the pure engine `temporal/olympus_workflows/autonomy.py`; the activity
layer owns only: (a) capturing the timestamp, (b) reading `os.environ` (the evidence flag + profile
env vars), (c) loading profile DATA from disk, and (d) the lazy evidence-emission seam. Reproduce
the engine's branch logic too — the activity is a thin wrapper and its behavior is defined by the
engine functions it calls.

This module contains **NO** `persist_*` activities (no direct DB writes), **NO** git activities, and
**NO** direct agent-dispatch. The only I/O beyond env/disk-reads is the flag-ON evidence path, which
*calls another activity* (`emit_evidence`, documented under the evidence activity group). The default
(flag-OFF) path imports NOTHING from the evidence layer (proven by `tests/autonomy/test_no_evidence_import.py`;
`autonomy_eval.py:16-17`).

---

## What `@foundry_activity` adds over raw `activity.defn`

Decorator: `temporal/olympus_workflows/temporal_base/activities.py:79-150`. Called as
`@foundry_activity(config=ActivityConfig(enable_observability=True))` at all three definitions
(`autonomy_eval.py:213, 336, 371`).

- **Registration**: wraps the user function with `@activity.defn(name=name, **activity_kwargs)`
  (`activities.py:100`). `name` defaults to `None` → Temporal uses the function name; the activity name
  Temporal replays on is `name or func.__name__` (`activities.py:103`). None of the three pass an explicit
  `name`, so registered names are `evaluate_autonomy`, `record_attempt`, `acquire_acting_on_lock`.
- **Observability** (enabled here): on entry logs `logger.info("Activity %s starting", activity_name, extra={"inputs": args if log_inputs else None})` (`activities.py:105-110`); on success logs
  `"Activity %s completed"` with `extra={"outputs": result if log_outputs else None}` (`activities.py:115-120`);
  on exception logs `logger.error("Activity %s failed: %s", activity_name, error, extra={"error": str(error)})`
  (`activities.py:125-131`). Uses stdlib `logging` (`activities.py:38`), NOT structlog/Prometheus — sandbox-safe.
  `ActivityConfig` defaults `log_inputs=False`, `log_outputs=False` (`activities.py:53-54`), so inputs/outputs
  are NOT logged unless overridden (none of the three override).
- **Error wrapping** (`enable_error_wrapping` defaults True — `activities.py:51`; not overridden). Any raw
  exception escaping the body (`activities.py:124`):
  - if already a `WorkflowError` or `temporalio` `ApplicationError` → re-raised untouched (`activities.py:135-136`);
  - else if `_is_retryable_error(error)` → wrapped `RetryableError(f"Retryable error in {activity_name}: {error}")`
    (`activities.py:137-140`), which sets `non_retryable=False` (`errors.py:23-27`);
  - else → wrapped `NonRetryableError(f"Non-retryable error in {activity_name}: {error}")`
    (`activities.py:141-144`), `non_retryable=True` (`errors.py:30-34`).
  - `_is_retryable_error` (`activities.py:56-76`) is a **type-name string match**: it lowercases
    `str(type(error))` and returns True iff it contains any of `timeout, connection, network, temporary,
    unavailable, overload, busy, throttle, rate_limit`. GOTCHA: this is intentionally DISTINCT from
    `errors.is_retryable_error` (which inspects httpx/OSError/ApplicationError instances) — the decorator
    keys on the *type-name string only* (`activities.py:59-63`). So a `TimeoutError` classifies retryable
    by its name; a `ValueError` classifies non-retryable.
- **Config knobs available but UNSET here**: `retry_policy`, `start_to_close_timeout`,
  `schedule_to_close_timeout`, `schedule_to_start_timeout`, `heartbeat_timeout` (`activities.py:45-49`).
  GOTCHA: none of the three activities set a `retry_policy` or any timeout, and the decorator does NOT
  forward `config.retry_policy` to `activity.defn` (only `**activity_kwargs` is forwarded — `activities.py:100`).
  So retry policy / timeouts are governed by whatever the *worker registration* or the calling *workflow's*
  `execute_activity` options specify, not by `ActivityConfig`. **No heartbeating** is emitted by these
  activities (all are fast, pure-CPU + one disk read; no `activity.heartbeat()` calls anywhere in
  `autonomy_eval.py`).
- **Idempotency**: all three activities are pure functions of their input plus (for `evaluate_autonomy`)
  a wall-clock timestamp and profile files on disk. They perform NO durable writes themselves. Re-execution
  (Temporal retry) recomputes the same decision; only `recorded_at` differs across retries (fresh
  `datetime.now`). The docstring says the activity "owns the durable lock/attempt table" (`autonomy_eval.py:25-27`,
  `337-338`, `372`) — but in THIS code the durability is delegated to the caller: the activity returns the
  decision, it does not write a table. GOTCHA: despite the docstrings ("the activity owns the durable
  attempt count"/"durable lock table"), no table write exists in this module; persistence is the caller's job.

---

## Module-level helpers (used by `evaluate_autonomy`)

### `EVIDENCE_EMIT_FLAG` / `evidence_emit_enabled()` — `autonomy_eval.py:57, 60-72`
- `EVIDENCE_EMIT_FLAG = "AUTONOMY_EVIDENCE_EMIT"`.
- `evidence_emit_enabled()` returns True iff `os.environ.get("AUTONOMY_EVIDENCE_EMIT", "").strip().lower()`
  is in `{"1", "true", "yes", "on"}`. Anything else — including unset/empty — is OFF (conservative default =
  Task-8-independent decision-log path). Case-insensitive; surrounding whitespace stripped.

### `_DEFAULTS_FILE` — `autonomy_eval.py:79-84`
- `Path(__file__).resolve().parents[1] / "registries" / "defaults" / "autonomy.yaml"`. From
  `.../olympus_workflows/activities/autonomy_eval.py`, `parents[1]` = `.../olympus_workflows`, so the file is
  `temporal/olympus_workflows/registries/defaults/autonomy.yaml`.

### `_repo_root()` — `autonomy_eval.py:87-89`
- `Path(__file__).resolve().parents[3]` → from `temporal/olympus_workflows/activities/autonomy_eval.py`,
  `parents[3]` = repo root.

### `_profile_root_for(profile_id)` — `autonomy_eval.py:92-114`
Resolves the directory holding a profile's `autonomy.yaml`. Mirrors `profile_devsecops._profile_root_for`.
Branch-by-branch:
1. If `profile_id` truthy (`:99`):
   - build `roots: list[Path]` (`:100`);
   - if env `OLYMPUS_PROFILES_DIR` set and truthy → append `Path(OLYMPUS_PROFILES_DIR)` FIRST (`:101-103`);
   - always append `_repo_root() / "profiles"` (`:104`);
   - for each `base` in order, if `base / profile_id` is a directory → return it immediately (`:105-108`).
     (So an explicit `OLYMPUS_PROFILES_DIR/<id>` wins over `repo/profiles/<id>`.)
2. Fallback regardless of `profile_id` (`:109-113`): read `OLYMPUS_PROFILE_ROOT` (the bootstrap-written
   worker-active profile); if set and `Path(env).resolve()` is a directory → return it.
3. Else return `None` (`:114`).

### `_load_yaml(path)` — `autonomy_eval.py:117-125`
- If `not path.is_file()` → return `{}` (`:118-119`).
- Else lazily `import yaml` (local import — keeps module import-light; `:121`) and return
  `yaml.safe_load(path.read_text(encoding="utf-8")) or {}` (`:123`).
- GOTCHA: any exception (unparseable YAML, missing pyyaml) is swallowed → returns `{}` (`:124-125`, bare
  `except Exception`). Unparseable profile data is non-fatal and falls back to defaults — never fails the gate.

### `_default_policy()` — `autonomy_eval.py:128-138`
- `data = _load_yaml(_DEFAULTS_FILE)`.
- If `not data` (missing/empty/unparseable) → return in-code `AutonomyPolicy()` — the fully fail-closed
  default (`autonomy.py:119-143`; `profile_id="_defaults"`, empty tier_caps/denylist/allowlist,
  `attempt_cap=3`, `default_level="report_only"`, `deny_by_default=True`). GOTCHA: a missing defaults file can
  NEVER fail the gate open (`:129-137`).
- Else `policy_from_mapping(data)` (`:138`).

### `load_autonomy_policy(profile_id)` — `autonomy_eval.py:141-157`
Builds the effective policy. Steps:
1. `defaults = _default_policy()` (`:149`).
2. `root = _profile_root_for(profile_id)`; if `None` → return `defaults` verbatim (`:150-151`).
3. `profile_doc = _load_yaml(root / "autonomy.yaml")`; if empty/falsy → return `defaults` (`:153-154`).
4. Else `profile_policy = policy_from_mapping(profile_doc)` then
   `merge_policy_over_defaults(profile_policy, defaults)` (`:155-157`).
Pure-ish: reads only profile DATA files, no DB. A profile omitting a field inherits the fail-closed default.

**Engine detail — `policy_from_mapping(data)`** (`autonomy.py:661-705`) — the exact YAML→policy mapping:
- `not data` → `AutonomyPolicy()` (`:670-671`).
- `block = data.get("autonomy", data) if isinstance(data, dict) else {}` — accepts either the full doc
  (`{"autonomy": {...}}`) or the inner block directly (`:672`). If `block` not a dict → `AutonomyPolicy()` (`:673-674`).
- `tier_caps`: `raw_caps = block.get("tier_caps") or {}`; if a dict → `tuple((str(k), str(v)) for k,v in raw_caps.items())`, else `()` (`:676-679`).
- `_str_tuple(key)`: `val = block.get(key) or []`; if list/tuple → `tuple(str(x) for x in val)`, else `()` (`:681-685`). Used for `denylist` and `auto_merge_allowlist`.
- `attempt_cap = int(block.get("attempt_cap", 3))`; on TypeError/ValueError → `3` (`:687-691`).
- `default_level = str(block.get("default_level", "report_only"))`; if off-ladder (`_ladder_rank<0`) → forced to `"report_only"` (`:693-695`).
- Returns `AutonomyPolicy(profile_id=str(block.get("profile","_defaults")), tier_caps, denylist, auto_merge_allowlist, attempt_cap, default_level, deny_by_default=bool(block.get("deny_by_default", True)))` (`:697-705`).

**Engine detail — `merge_policy_over_defaults(profile, defaults)`** (`autonomy.py:708-729`): `replace(defaults, ...)` where each field is `profile.X or defaults.X` — profile's non-empty value wins, else inherit default. Fields merged: `profile_id`, `tier_caps`, `denylist`, `auto_merge_allowlist`, `attempt_cap`, `default_level`; `deny_by_default` takes the profile's value directly (`:718-728`). GOTCHA: `attempt_cap` uses `profile.attempt_cap or defaults.attempt_cap`, so a profile `attempt_cap=0` inherits the default 3 (0 is falsy).

**Defaults file content** (`registries/defaults/autonomy.yaml`): `default_level: report_only`,
`deny_by_default: true`, `attempt_cap: 3`, `tier_caps: {tier_1: report_only, tier_2: assisted, tier_3: unattended}`,
`denylist` = 17 globs (`**/secrets/**`, `**/secret/**`, `**/auth/**`, `**/authn/**`, `**/authz/**`,
`**/payments/**`, `**/billing/**`, `infra/**`, `**/infrastructure/**`, `**/terraform/**`, `*.tfstate`,
`**/migrations/**`, `**/alembic/**`, `**/compliance/**`, `**/*secret*`, `**/*.pem`, `**/*.key`;
`autonomy.yaml:45-62`), `auto_merge_allowlist: []` (empty → nothing auto-merges). GOTCHA: the file also
carries a sibling `triage:` block (`:78-87`) consumed by the error-triage sweep, NOT by this module — this
module reads only the `autonomy:` block via `policy_from_mapping`'s `data.get("autonomy", data)`.

---

## Activity 1 — `evaluate_autonomy` — `autonomy_eval.py:213-262`

### Signature
`async def evaluate_autonomy(payload: EvaluateAutonomyInput) -> EvaluateAutonomyResult`
Decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))` (`:213`). Registered name:
`evaluate_autonomy`.

### Input — `EvaluateAutonomyInput` (`autonomy_eval.py:165-191`, plain serialisable dataclass, NOT a frozen contract)
| field | type | default | meaning |
|---|---|---|---|
| `loop_id` | `str` | (req) | loop item id |
| `application_id` | `str` | (req) | touched application |
| `requested_level` | `str` | (req) | rung the loop pattern's `default_autonomy_level` asks for |
| `risk_tier` | `str \| int \| None` | (req) | touched app tier; `"tier_1"`/`1`/`"1"` all accepted |
| `profile_id` | `str \| None` | `None` | selects profile DATA |
| `paths` | `tuple[str, ...]` | `()` | paths the proposed action would modify (denylist/allowlist matched) |
| `attempts` | `int` | `0` | failure count so far (for attempt cap) |
| `control_ids` | `tuple[str, ...]` | `()` | continuous-monitoring controls; recorded in log always, mapped in evidence when flag ON |
| `policy_override` | `AutonomyPolicy \| None` | `None` | inject a policy directly (bypass disk load) |
| `portfolio_id` | `str \| None` | `None` | portfolio scope; REQUIRED for flag-ON evidence emission |

### Output — `EvaluateAutonomyResult` (`autonomy_eval.py:194-210`)
| field | type | default | meaning |
|---|---|---|---|
| `decision` | `AutonomyDecision` | (req) | resolved verdict (frozen dataclass, see below) |
| `decision_log` | `dict[str, object]` | (req) | `AutonomyDecisionLogRecord.to_dict()` — always populated |
| `recorded_at` | `str` | (req) | ISO8601 UTC timestamp captured in the activity |
| `emitted` | `bool` | `False` | evidence emitted (flag-ON path only) |
| `evidence_content_hash` | `str \| None` | `None` | content hash from `emit_evidence` (flag-ON) |
| `evidence_skipped` | `bool` | `False` | flag ON but backbone/portfolio unavailable → clean skip |

### Body flow (`autonomy_eval.py:225-262`), step by step:
1. `captured_at = datetime.now(timezone.utc)` — timestamp captured HERE (REQ-TEMP-001; `:225`). GOTCHA: this is the
   only non-determinism; on Temporal retry a new timestamp is produced, so `recorded_at` and the log
   `recorded_at` differ per attempt.
2. `policy = payload.policy_override or load_autonomy_policy(payload.profile_id)` (`:227`). GOTCHA: `policy_override`
   short-circuits disk load — used by tests/direct callers.
3. `decision = resolve_autonomy_level(requested_level=payload.requested_level, risk_tier=payload.risk_tier, policy=policy, paths=tuple(payload.paths), attempts=payload.attempts)` (`:228-234`).
4. `record = build_decision_log_record(decision=decision, loop_id=..., application_id=..., recorded_at=captured_at.isoformat(), profile_id=policy.profile_id, control_ids=tuple(payload.control_ids))` (`:236-243`). GOTCHA: `profile_id` in the log comes from `policy.profile_id` (the *resolved/merged* policy), NOT `payload.profile_id`.
5. `result = EvaluateAutonomyResult(decision=decision, decision_log=record.to_dict(), recorded_at=captured_at.isoformat())` (`:245-249`) — default path complete; `emitted`/`hash`/`skipped` stay at defaults.
6. **Evidence seam (REQ-AG-006, `:251-260`)**: `if evidence_emit_enabled():` → call `_emit_evidence_for_decision(...)`, then set `result.emitted`, `result.evidence_content_hash`, `result.evidence_skipped` from the returned tuple. If the flag is OFF this block is skipped entirely and NOTHING from the evidence layer is imported.
7. `return result` (`:262`).

### Engine: `resolve_autonomy_level` (`autonomy.py:264-330`) — the actual decision logic (reproduce fully)
Precondition normalisation: `tier_key = _normalise_tier_key(risk_tier) or "unknown"` (`:289`); `tier_max = policy.tier_max(risk_tier)` (`:290`).

Ordered branches (FIRST match wins):
1. **Denylist beats tier (REQ-AG-003)** — `if paths and policy.is_denylisted(paths):` (`:293`) → returns
   `AutonomyDecision(permitted_level="report_only", requested_level=payload.requested_level, risk_tier=tier_key,
   escalate=True, reason="denylist_match", denylisted=True, paths=paths, metadata={"tier_max": tier_max})`
   (`:294-303`). GOTCHA: checked FIRST so a denylisted path can never slip through even on a Tier-3 app;
   `permitted_level` is pinned to `report_only` regardless of tier.
2. **Attempt cap (REQ-AG-004)** — `cap = policy.attempt_cap if policy.attempt_cap > 0 else 3` (`:306`);
   `if attempts >= cap:` (`:307`) → returns `AutonomyDecision(permitted_level="report_only",
   requested_level=..., risk_tier=tier_key, escalate=True, reason="attempt_cap_exceeded", attempt_capped=True,
   paths=paths, metadata={"tier_max": tier_max, "attempts": attempts, "attempt_cap": cap})` (`:308-317`).
   GOTCHA: this uses `attempts >= cap` (the cap-th attempt escalates here) — DIFFERENT from
   `evaluate_attempt_cap` in `record_attempt`, which uses `attempts > cap`. Two different thresholds coexist.
3. **Per-tier cap (REQ-AG-002, fail-closed REQ-AG-008)** — `permitted = cap_level(requested_level, tier_max)` (`:320`);
   `capped = _ladder_rank(permitted) < _ladder_rank(requested_level)` (`:321`) → returns
   `AutonomyDecision(permitted_level=permitted, requested_level=..., risk_tier=tier_key, escalate=False,
   reason="capped_to_tier" if capped else "within_tier_cap", paths=paths, metadata={"tier_max": tier_max})`
   (`:322-330`).

**`AutonomyDecision`** (frozen; `autonomy.py:232-261`): fields `permitted_level, requested_level, risk_tier,
escalate, reason, denylisted=False, attempt_capped=False, paths=(), metadata={}`. Property `capped`
(`:256-261`) = `_ladder_rank(permitted_level) < _ladder_rank(requested_level)`.

**`cap_level(requested, tier_max)`** (`autonomy.py:95-111`): `cap_rank = _ladder_rank(tier_max)`; if `<0`
(bogus profile cap) → `"report_only"` (`:103-106`); `req_rank = _ladder_rank(requested)`; if `<0` (off-ladder
request) → return `tier_max` (`:107-110`); else `AUTONOMY_LADDER[min(req_rank, cap_rank)]` (`:111`).
`AUTONOMY_LADDER = ("report_only", "assisted", "unattended")` (`autonomy.py:72`); `_ladder_rank` returns index
or `-1` for unknown (`:83-92`).

**`policy.tier_max(tier)`** (`autonomy.py:149-162`): `key = _normalise_tier_key(tier)`; if `None` → `default_level`
(`:157-158`); `mapped = tier_cap_map.get(key)`; if `None` or off-ladder → `default_level` (`:160-161`); else `mapped`.

**`_normalise_tier_key(tier)`** (`autonomy.py:189-204`): `None`→`None`; `int`→`f"tier_{tier}"`; else lowercase-strip;
empty→`None`; `"tier_..."`→unchanged; `"tier-..."`→`"tier_"+suffix`; all-digits→`f"tier_{text}"`; else the text itself.

**`policy.is_denylisted(paths)`** (`autonomy.py:164-172`): `any(path_matches_any(p, denylist) for p in paths)`.
**`path_matches_any(path, globs)`** (`autonomy.py:207-224`): `norm = path.lstrip("./")`; for each non-empty glob,
try `fnmatch.fnmatch(norm, g)`, then also a `**`-collapsed form (`g.replace("**/","*").replace("/**","*").replace("**","*")`)
so `**/secrets/**` matches `a/b/secrets/c.txt`. GOTCHA: `lstrip("./")` strips ANY leading `.`/`/` chars (character
set, not prefix) — e.g. `"..foo"` → `"foo"`.

### Evidence seam — `_emit_evidence_for_decision` (`autonomy_eval.py:265-322`) — flag-ON path (NOT itself an activity)
Helper coroutine; returns `(emitted: bool, content_hash: str|None, skipped: bool)`.
1. `if not payload.portfolio_id:` → `return (False, None, True)` — no portfolio scope, clean skip; decision log already captured (`:281-284`).
2. Lazy import INSIDE the body: `from olympus_workflows.activities.evidence_emit import ControlMappingInput, EmitEvidenceInput, emit_evidence` (`:285-290`). GOTCHA: import is inside a `try/except Exception` (`:285-292`) — if the backbone is not importable → `return (False, None, True)` (clean skip, never fails the gate; keeps the default path sandbox-safe and Task-8-independent).
3. `control_ids = tuple(payload.control_ids) or ("CA-7",)` (`:294`) — default control is CA-7 (Continuous Monitoring) when caller supplies none.
4. `primary = control_ids[0]` (`:295`); `family = primary.split("-")[0] if "-" in primary else primary` (`:296`) — e.g. `"CA-7"`→`"CA"`, `"AC"`→`"AC"`.
5. `status = "non-compliant" if decision.escalate else "compliant"` (`:297`).
6. `statement = f"Autonomy decision for loop {payload.loop_id} on {payload.application_id}: requested {decision.requested_level!r}, permitted {decision.permitted_level!r} ({decision.reason})."` (`:298-302`). GOTCHA: uses `!r` (repr) on the level strings → they render quoted.
7. Build `EmitEvidenceInput` (`:304-320`) with exactly: `portfolio_id=payload.portfolio_id`, `control_id=primary`,
   `family=family`, `status=status`, `application_id=payload.application_id`, `implementation_statement=statement`,
   `assessed_at_gate="autonomy_level"`, `run_id=payload.loop_id`, `subject_kind="gate"`, `subject_id="autonomy_level"`,
   `profile_id=payload.profile_id`, `mappings=[ControlMappingInput(catalog_id="nist-800-53", control_id=c) for c in control_ids]`.
   GOTCHA: here `profile_id` is `payload.profile_id` (the raw input), NOT the resolved `policy.profile_id` used in the
   decision log — the two records can carry different profile ids. All other `EmitEvidenceInput` fields
   (`evidence_refs`, `assessed_by_skill`, `risk_tier`, `classification="unclassified"`, `owner_scope`,
   `owner_scope_type="portfolio"`, `retention_policy="standard"`, `profile_schema_version`) take their dataclass
   defaults (`evidence_emit.py:42-72`).
8. `emit_result = await emit_evidence(emit_input)` (`:321`) — invokes the emit activity (documented separately).
9. `return (bool(emit_result.emitted), emit_result.content_hash, False)` (`:322`) — `skipped=False`. GOTCHA: if
   `emit_evidence` suppressed the record (`emitted=False, suppressed=True`; `evidence_emit.py:76-84,177`), this still
   returns `skipped=False` and `emitted=False` — a *suppressed* emission is reported as not-emitted-not-skipped.

### Decision-log record (default path) — `AutonomyDecisionLogRecord.to_dict()` (`autonomy.py:604-621`)
`build_decision_log_record` (`autonomy.py:624-653`) projects the decision + activity-supplied `recorded_at`/
`profile_id`/`control_ids`. The emitted `decision_log` dict is EXACTLY:
```json
{
  "kind": "autonomy_decision",
  "loop_id": "<loop_id>",
  "application_id": "<application_id>",
  "permitted_level": "<decision.permitted_level>",
  "requested_level": "<decision.requested_level>",
  "risk_tier": "<decision.risk_tier>",       // normalized key or "unknown"
  "escalate": <bool>,
  "reason": "<denylist_match|attempt_cap_exceeded|capped_to_tier|within_tier_cap>",
  "recorded_at": "<ISO8601 UTC>",
  "profile_id": "<policy.profile_id>",
  "denylisted": <bool>,
  "attempt_capped": <bool>,
  "paths": [ ... ],                            // list(tuple)
  "control_ids": [ ... ]                       // list(tuple)
}
```
GOTCHA: `paths` and `control_ids` are serialised as JSON lists (`list(self.paths)`, `list(self.control_ids)`;
`autonomy.py:619-620`); the `decision.metadata` dict (carrying `tier_max`/`attempts`/`attempt_cap`) is NOT
included in the decision-log dict — it lives only on the `AutonomyDecision` object returned in `result.decision`.

### Errors / retries / idempotency
- No explicit `retry_policy`/timeouts (see decorator section). A YAML parse failure does NOT raise (swallowed to
  `{}` → defaults). The only realistic raise is inside `emit_evidence` on the flag-ON path; a raise there is
  NOT caught by `_emit_evidence_for_decision` (only the *import* is guarded, `:285-292`; the `await emit_evidence`
  at `:321` is outside the try), so it propagates out of `evaluate_autonomy` and is wrapped by `@foundry_activity`.
  GOTCHA: the import is guarded but the call is not — a backbone that imports fine but fails at emit time will
  fail the whole `evaluate_autonomy` activity rather than skipping cleanly.
- Idempotent modulo the timestamp: recomputes the same decision on retry; performs no durable writes on the default path.

---

## Activity 2 — `record_attempt` — `autonomy_eval.py:336-359`

### Signature
`async def record_attempt(payload: AttemptCapInput) -> dict[str, object]`
`@foundry_activity(config=ActivityConfig(enable_observability=True))` (`:336`). Registered name: `record_attempt`.

### Input — `AttemptCapInput` (`autonomy_eval.py:325-333`)
| field | type | default |
|---|---|---|
| `item_id` | `str` | (req) |
| `attempts` | `int` | (req) — count of failures INCLUDING the one just observed |
| `attempt_cap` | `int` | `3` |
| `last_output` | `str` | `""` |
| `diagnosis` | `str` | `""` |

### Body (`:345-359`)
Calls the pure engine `evaluate_attempt_cap(item_id=..., attempts=..., attempt_cap=..., last_output=..., diagnosis=...)`
(`:345-351`) and returns the plain dict:
```json
{ "item_id", "attempts", "attempt_cap", "escalated", "should_retry", "context": {...} }
```
(`:352-359`; `context` is `dict(result.context)`).

### Engine: `evaluate_attempt_cap` (`autonomy.py:356-389`)
- `cap = attempt_cap if attempt_cap > 0 else 3` (`:372`).
- `escalated = attempts > cap` (`:373`). GOTCHA: strictly `>`. With default cap 3, the 4th consecutive failure
  (`attempts=4`) escalates; `attempts=3` does NOT. (Contrast: `resolve_autonomy_level` uses `attempts >= cap`.)
- If `escalated`: `context = {"attempts": attempts, "attempt_cap": cap, "last_output": last_output, "diagnosis": diagnosis}` (`:374-381`); otherwise `context = {}` — the diagnostic bag is only populated on escalation.
- Returns `AttemptCapResult(item_id, attempts, attempt_cap=cap, escalated, should_retry=not escalated, context)` (`:382-389`).
- Note `attempt_cap` in the output is the *effective* `cap` (post `>0` guard), not the raw input.

### Errors / idempotency
Pure; no I/O; no durable write despite the docstring "the activity owns the durable attempt count" (`:337-338`).
Fully idempotent. No custom retry policy/timeout.

---

## Activity 3 — `acquire_acting_on_lock` — `autonomy_eval.py:371-390`

### Signature
`async def acquire_acting_on_lock(payload: AcquireLockInput) -> dict[str, object]`
`@foundry_activity(config=ActivityConfig(enable_observability=True))` (`:371`). Registered name: `acquire_acting_on_lock`.

### Input — `AcquireLockInput` (`autonomy_eval.py:362-369`)
| field | type | default |
|---|---|---|
| `target` | `str` | (req) — application/branch key, e.g. `"APP-7@feature/x"` |
| `loop_id` | `str` | (req) |
| `current_holder` | `str \| None` | `None` — the loop already holding the lock, or None/empty if free |

### Body (`:379-390`)
Calls `evaluate_acting_on_lock(target=..., loop_id=..., current_holder=...)` (`:379-383`) and returns:
```json
{ "target", "acquired", "skipped", "holder", "reason" }
```
(`:384-390`).

### Engine: `evaluate_acting_on_lock` (`autonomy.py:413-443`)
- `holder = (current_holder or "").strip()` (`:428`).
- **Branch A** — `if not holder or holder == loop_id:` (`:429`) → `LockOutcome(target, acquired=True, skipped=False,
  holder=loop_id, reason="acquired" if not holder else "reentrant")` (`:430-436`). GOTCHA: a loop RE-acquiring its
  own lock is idempotent (`acquired=True, skipped=False, reason="reentrant"`) — a retry of the same loop is never
  blocked; `holder` is set to `loop_id` (this loop). `reason` distinguishes a fresh acquire (`"acquired"`, empty
  prior holder) from re-entrancy (`"reentrant"`, same loop already holds it).
- **Branch B** — a different loop holds it (`:437-443`) → `LockOutcome(target, acquired=False, skipped=True,
  holder=holder, reason=f"acting_on lock held by {holder!r}")`. GOTCHA: `!r` → the reason quotes the holder id.

### Errors / idempotency
Pure; no durable write despite docstring "the activity owns the durable lock table" (`:372`). Idempotent.
No custom retry policy/timeout.

---

## Cross-cutting GOTCHAs
- **Two distinct attempt-cap thresholds**: `resolve_autonomy_level` escalates at `attempts >= cap`
  (`autonomy.py:307`) while `evaluate_attempt_cap` escalates at `attempts > cap` (`autonomy.py:373`). A rebuild
  MUST preserve both exactly — they are not the same off-by-one.
- **Two profile_id sources in `evaluate_autonomy`**: decision log uses `policy.profile_id` (resolved/merged);
  the flag-ON evidence record uses `payload.profile_id` (raw input) (`autonomy_eval.py:242` vs `:315`).
- **Fail-closed everywhere**: missing/unparseable YAML → `{}` → defaults; unknown/absent tier → `default_level`
  (`report_only`); off-ladder cap → `report_only`; off-ladder request → capped to tier_max; empty allowlist →
  nothing auto-merges. The resolver NEVER fails open (REQ-AG-008).
- **Import isolation**: the module imports NOTHING from the evidence layer at module scope; the ONLY evidence
  import is inside `_emit_evidence_for_decision` under a try/except (`autonomy_eval.py:285-292`). This is the
  Task-8-independence invariant, guarded by `tests/autonomy/test_no_evidence_import.py`.
- **`@foundry_activity` does NOT forward `config.retry_policy`/timeouts to `activity.defn`** — only `**activity_kwargs`
  (`activities.py:100`). Retry/timeout for these three activities is set by the worker registration or the calling
  workflow, not by `ActivityConfig`.
