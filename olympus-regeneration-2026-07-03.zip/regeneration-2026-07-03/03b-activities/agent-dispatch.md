# Activity group: `agent_dispatch` — atomic regeneration spec

Scope: two modules under `temporal/olympus_workflows/activities/`:

- `agent_dispatch.py` — agent-task dispatch via A2A, its persistence (`agent_task`, `ai_work_log`, `step_execution` rows), the work-log disposition gate, and `output_artifact_ref` back-fill.
- `context_priors.py` — loads human-reviewed markdown priors for a skill from the active client profile.

There are **3 `@foundry_activity`-decorated activity functions** in this group (the units documented):

1. `update_agent_task_output_ref` (`agent_dispatch.py:658`)
2. `dispatch_agent_task` (`agent_dispatch.py:755`)
3. `load_context_priors` (`context_priors.py:107`)

Everything else in these modules is a **module-level helper** (not a Temporal activity) invoked by those three. This spec reproduces the helpers fully because the activities' behavior IS the helpers.

`verify_work_log_disposition` (`agent_dispatch.py:534`) is a **public non-activity function** exported for workflows to call in-process; documented in §5.

---

## 0. What `@foundry_activity` adds over `activity.defn`

Source: `temporal/olympus_workflows/temporal_base/activities.py`. Decorator applied as `@foundry_activity(config=ActivityConfig(enable_observability=True))` at all three call sites in this group.

`ActivityConfig` (dataclass, `activities.py:41-53`) fields + defaults:

| field | default |
|---|---|
| `retry_policy` | `None` |
| `start_to_close_timeout` | `None` |
| `schedule_to_close_timeout` | `None` |
| `schedule_to_start_timeout` | `None` |
| `heartbeat_timeout` | `None` |
| `enable_observability` | `True` |
| `enable_error_wrapping` | `True` |
| `log_inputs` | `False` |
| `log_outputs` | `False` |

GOTCHA: `ActivityConfig`'s timeout/retry fields are **declared but never read by the decorator** (`activities.py:97-148` only reads `enable_observability`, `enable_error_wrapping`, `log_inputs`, `log_outputs`). Timeouts and retry policy are set by the **workflow** at each `execute_activity(...)` call, NOT here. Passing `retry_policy=...` into `ActivityConfig` has no effect.

Decorator behavior (`activities.py:97-148`), in order per invocation:

1. `activity_config = config or ActivityConfig()` (`:98`).
2. Wrap `func` with `@activity.defn(name=name, **activity_kwargs)` over `@wraps(func)` (`:100-101`). Activity **name** = the `name` arg or falls back to `func.__name__` at runtime (`:103`). Temporal replay keys on this name — preserve it exactly (`update_agent_task_output_ref`, `dispatch_agent_task`, `load_context_priors`).
3. If `enable_observability`: log `"Activity %s starting"` at INFO with `extra={"inputs": args if log_inputs else None}` (`:105-110`). `log_inputs` is `False` here → inputs never logged.
4. `result = await func(*args, **kwargs)` (`:113`).
5. On success + observability: log `"Activity %s completed"` at INFO, `extra={"outputs": result if log_outputs else None}` (`:115-120`). `log_outputs` False → outputs never logged.
6. Return `result` (`:122`).
7. On `except Exception as error` (`:124`):
   - If observability: log `"Activity %s failed: %s"` at ERROR with `extra={"error": str(error)}` (`:125-131`).
   - If `enable_error_wrapping` (default True, `:133`):
     - If `error` is already `WorkflowError` or `temporalio...ApplicationError` → **re-raise unchanged** (`:135-136`). This is why `RetryableError`/`NonRetryableError` raised inside the body pass through with their `non_retryable` flag intact.
     - elif `_is_retryable_error(error)` → raise `RetryableError(f"Retryable error in {activity_name}: {error}") from error` (`:137-140`).
     - else → raise `NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error` (`:141-144`).
   - Else (wrapping disabled): bare `raise` (`:146`).

`_is_retryable_error(error)` (`activities.py:56-76`): classifies by the **string of the exception's type name** (`str(type(error)).lower()`), matching substrings: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. GOTCHA: this is deliberately a *different* heuristic from `errors.is_retryable_error` (which inspects httpx/OSError/ApplicationError instances) — the decorator path keys on the **type-name string only** (`activities.py:56-63`). E.g. a `ConnectionError` matches (`connection`), a `ValueError` does not.

Error taxonomy (`temporal_base/errors.py`):
- `WorkflowError(ApplicationError)` — `non_retryable=True` default (`errors.py:16-20`).
- `RetryableError(WorkflowError)` — forces `non_retryable=False` (`errors.py:23-27`).
- `NonRetryableError(WorkflowError)` — forces `non_retryable=True` (`errors.py:30-34`).

**No heartbeat is emitted by the decorator.** Heartbeating in `dispatch_agent_task` is done manually by `_heartbeat_loop` (see §4).

---

## 1. Shared input/output/DB shapes

### `AgentTaskInput` (`types.py:470-515`)

```
task_type: str
app_id: str                       # UUID of application row; "" for wave-scoped
skill_id: str
input_artifacts: list[str] = []
optional_input_artifacts: list[str] = []   # 404 => "not present yet", not fatal (agent-runtime semantics)
source_repo: str = ""
artifact_repo: str = ""
artifact_ref: str = ""
model_preference: str = ""        # tier/alias forwarded to runtime; runtime picks concrete model
workspace_key: str = ""
timeout_seconds: int = AGENT_HTTP_READ_TIMEOUT_SECONDS   # httpx read ceiling (timeout ladder layer 3)
context: dict = {}
execution_context: StepExecutionContext | None = None
wave_id: str = ""                 # UUID of wave row; set iff app_id == ""
```
Scope invariant: **exactly one** of `app_id` / `wave_id` populated (DB CHECK `agent_task_application_or_wave_ck`; validated early in `_insert_agent_task_row`).

### `AgentTaskResult` (`types.py:518-531`)

```
task_id: str
status: TaskStatus = COMPLETED
output_artifacts: list[str] = []   # agent SDK final summary PROSE at [0], NOT a file ref
output_files: list[OutputFile] = []
model_used: str = ""
duration_ms: int = 0
token_usage_input: int = 0
token_usage_output: int = 0
cost_estimate_usd: float = 0.0
error: str = ""
```

`OutputFile` (`types.py:461-467`): `path: str`, `content: str`, `encoding: str = "utf-8"` ("utf-8" or "base64").

`TaskStatus` enum (`types.py:49-57`): `queued`, `dispatched`, `running`, `completed`, `failed`, `timed_out` (str-valued lowercase).

### `StepExecutionContext` (`types.py:537-560`)

```
portfolio_id: str    # only strictly-required field
line_id: str
step_id: str
app_id: str = ""     # nullable for wave-scoped
wave_id: str = ""    # nullable for per-app
input_artifact_paths: list[str] = []
gate_id: str = ""
```

### `_db_url()` (`agent_dispatch.py:144-151`)

Builds DSN `postgresql://{user}:{password}@{host}:{port}/{db}` from env `DATABASE_HOST` (default `localhost`), `DATABASE_PORT` (`5432`), `DATABASE_USER` (`olympus`), `DATABASE_PASSWORD` (`olympus`), `DATABASE_NAME` (`olympus`). `utils/execution._db_url` (`execution.py:127-133`) is byte-identical.

GOTCHA: every DB helper opens a **fresh `asyncpg.connect(_db_url())`** and closes it in a `finally` — no pooling. One connect+close per row write.

---

## 2. `update_agent_task_output_ref` — activity #1

Signature (`agent_dispatch.py:658-663`):
```
async def update_agent_task_output_ref(app_id: str, task_type: str, artifact_ref: str) -> None
```
Purpose: after a workflow's `_commit_step_artifacts` writes the canonical file, set `agent_task.output_artifact_ref` on the **most recent** matching row so the UI Artifacts tab shows a real path instead of the agent's free-form summary.

Body:
1. If `not artifact_ref or not task_type` → `return` (no-op) (`:670-671`).
2. `app_uuid = uuid.UUID(app_id)`; on `ValueError | TypeError` → `return` (no-op, malformed id swallowed) (`:672-675`).
3. `conn = await asyncpg.connect(_db_url())`; run inside try/`finally: conn.close()` (`:676-695`):
   ```sql
   UPDATE agent_task
   SET output_artifact_ref = $3
   WHERE id = (
       SELECT id FROM agent_task
       WHERE application_id = $1 AND task_type = $2
       ORDER BY dispatched_at DESC NULLS LAST
       LIMIT 1
   )
   ```
   params: `$1=app_uuid`, `$2=task_type`, `$3=artifact_ref` (`:679-693`).
4. Any exception → `logger.warning("Failed to update output_artifact_ref (%s/%s): %s", task_type, app_id, exc)` and swallow (`:696-700`).

Idempotency: idempotent — repeated calls set the same subselect's row to the same value. GOTCHA: it targets **only the single most-recent** matching `agent_task` by `dispatched_at DESC NULLS LAST` — if multiple tasks share `(application_id, task_type)`, older ones are not touched. `NULLS LAST` means a row with `dispatched_at IS NULL` is only chosen if it's the only match.

Error handling: best-effort observability write — **never raises** (all failure paths are `return` or swallowed warning). Wave-scoped tasks (`app_id == ""` → UUID parse fails on empty string → early return) are never updated by this path.

---

## 3. `dispatch_agent_task` — activity #2 (the core)

Signature (`agent_dispatch.py:755-756`): `async def dispatch_agent_task(input: AgentTaskInput) -> AgentTaskResult`.

Structure: an **outer heartbeat wrapper** (`:755-807`) delegating to `_dispatch_agent_task_inner` (`:810-1025`). The split exists so the heartbeat cleanup covers every exit path uniformly (`:811-815`).

### 3.1 Heartbeat wrapper (`dispatch_agent_task`, `:755-807`)

1. `_heartbeat_task: asyncio.Task | None = None` (`:779`).
2. Try to `asyncio.create_task(_heartbeat_loop(task_type=input.task_type, app_id=input.app_id, skill_id=input.skill_id, started_monotonic=time.monotonic()))` (`:781-788`). On any exception → `logger.debug("Heartbeat loop did not start (%s)", exc)` and continue without heartbeats (`:789-792`).
3. `try: return await _dispatch_agent_task_inner(input)` (`:794-795`).
4. `finally`: if `_heartbeat_task is not None and not _heartbeat_task.done()`: `_heartbeat_task.cancel()`, then `await asyncio.sleep(0)` (single event-loop tick to propagate the cancel) wrapped in try/except-swallow (`:796-807`). GOTCHA: it deliberately does **not** `await _heartbeat_task` — awaiting would re-raise `CancelledError` from the finally and mask the real exit path (`:799-803`).

### 3.2 `_heartbeat_loop` (`:706-752`)

Constant `_HEARTBEAT_INTERVAL_SECONDS = 30.0` (`:703`).

Loop forever:
1. `await asyncio.sleep(30.0)`; on `asyncio.CancelledError` → `return` (`:730-734`).
2. Then `elapsed_s = int(time.monotonic() - started_monotonic)` and call:
   ```python
   activity.heartbeat({
       "phase": "agent_streaming",
       "task_type": task_type,
       "app_id": app_id,
       "skill_id": skill_id,
       "elapsed_s": elapsed_s,
   })
   ```
   (`:735-743`).
3. On **any** exception from `activity.heartbeat` (no activity context in mock/tests, or machinery not wired) → `logger.debug("Heartbeat skipped (%s); stopping heartbeat loop", exc)` and `return` (stop the loop, don't spin) (`:744-752`).

Rationale (`:713-728`): synthesis-class skills (data-migration-planning, data-data-synthesis, architecture-blueprint-assembly) can run >1h; heartbeats let the workflow rely on `heartbeat_timeout` (e.g. 2m) rather than `start_to_close_timeout` to detect a true hang. GOTCHA: heartbeats fire only every ~30s AFTER the first sleep — a call finishing in <30s emits zero heartbeats.

### 3.3 `_dispatch_agent_task_inner` (`:810-1025`) — full branch tree

**Lazy imports** at body top (`:816-817`): `from src.agent_registry import olympus_agent_registry` and `from src.fallback_adapter import dispatch_via_subprocess`. (These are worker-service modules, imported at call time to avoid workflow-sandbox import issues.)

**Step A — log + persist start** (`:819-834`):
1. `logger.info("Dispatching agent task", extra={task_type, app_id, wave_id (via getattr), skill_id, model_preference})`.
2. `dispatched_at = datetime.now(timezone.utc)` (`:830`).
3. `task_row_id = await _insert_agent_task_row(input, dispatched_at)` (see §3.4) — may be `None`.
4. `exec_id = await _emit_agent_start(input.execution_context, input, task_row_id)` (see §3.5) — may be `None`.

**Step B — agent resolution** (`:837`): `agent_card = olympus_agent_registry.find_agent_for_skill(input.skill_id)`.

#### Branch B1: `agent_card is not None` — A2A primary path (`:839-954`)

Inside a `try`:
1. **Dispatcher selection** (`:846-856`):
   - If `os.environ.get("AGENT_RUNTIME_MODE", "live").strip().lower() == "mock"` → `from src.testing.mock_agent_runtime import dispatch_via_mock`; `dispatcher = dispatch_via_mock` (`:846-848`). GOTCHA: mock mode is for automated tests only; production refuses mock at worker startup (`src/config.py:WorkerConfig.validate_agent_runtime_mode`, DECISION-018). Default `"live"`.
   - Else, try `from olympus_api.src.services.agent_client import dispatch_via_a2a as dispatcher`; on `ImportError` fall back to `from src.agent_client import dispatch_via_a2a as dispatcher` (`:850-856`).
2. `result = await dispatcher(agent_url=agent_card.url, task_input=input)` (`:858-861`). **Model selection is delegated to the runtime** — the input forwards `model_preference`; the runtime returns actual `model_used`.

3. **Terminal-failure sub-branch**: `if result.status in (TaskStatus.FAILED, TaskStatus.TIMED_OUT)` (`:871`):
   - `_err = result.error or ("agent execution timed out" if TIMED_OUT else "unknown error")` (`:872-876`).
   - `await _update_agent_task_row(task_row_id, result, now_utc, error=_err)` (§3.6).
   - `await _insert_work_log_row(task_row_id, input, result, outcome=_outcome_for(result.status), error=_err)` (§3.7-3.8). `_outcome_for`: TIMED_OUT→`"timed_out"`, COMPLETED→`"completed"`, else→`"failed"` (`:305-316`).
   - `await _emit_agent_complete(exec_id, result, status=ExecutionStatus.FAILED, error=_err, artifact_repo=input.artifact_repo, artifact_ref=input.artifact_ref)` (§3.9).
   - `raise RetryableError(f"Agent task {result.status.value}: {_err}")` (`:893-895`).
   GOTCHA (`:863-870`): `TIMED_OUT` **must** raise `RetryableError` (not fall through as success) — a timed-out run returns no `output_files`; treating it as COMPLETED would surface empty output to the workflow and trip a non-retryable empty-output guard (e.g. PRA's `EmptyPortfolioRedundancyPlan`), failing the whole wave instead of retrying.

4. **Success sub-branch** (`:896-917`) — reached only when status is neither FAILED nor TIMED_OUT:
   - `await _update_agent_task_row(task_row_id, result, now_utc)` (no error).
   - `await _insert_work_log_row(task_row_id, input, result, outcome="completed")`.
   - `_gate_work_log_disposition(input)` (§5) — **synchronous**, AFTER the non-blocking telemetry insert; may `raise NonRetryableError` to BLOCK the disposition (`:902-909`).
   - `await _emit_agent_complete(exec_id, result, status=ExecutionStatus.COMPLETED, artifact_repo=input.artifact_repo, artifact_ref=input.artifact_ref)`.
   - `return result` (`:917`).

5. **Except handlers** on the B1 try (order matters):
   - `except ImportError:` (`:919-923`) → `logger.warning("agent_client not available, attempting direct A2A dispatch")`, **fall through** past the try to the subprocess fallback (Branch B2 region). GOTCHA: this catches an ImportError from the dispatcher-import block or dispatcher call; it does NOT re-dispatch inside B1 — control falls to the fallback block at `:956`.
   - `except RetryableError: raise` (`:924-925`) — re-raise the RetryableError from sub-branch 3 unchanged (so it isn't reclassified by the generic handler). GOTCHA: this MUST precede the generic `except Exception` or the RetryableError would be recaught and re-wrapped.
   - `except Exception as e:` (`:926-954`): `error_str = str(e)`; build `failed_result = AgentTaskResult(task_id="", status=FAILED, error=error_str)`; `_update_agent_task_row(..., error=error_str)`; `_insert_work_log_row(..., outcome="failed", error=error_str)`; `_emit_agent_complete(exec_id, failed_result, status=FAILED, error=error_str)` (note: **no** artifact_repo/ref passed here → defaults `""`). Then classify:
     - `if _is_retryable(error_str): raise RetryableError(f"A2A dispatch failed (retryable): {error_str}") from e` (`:948-951`).
     - else `raise NonRetryableError(f"A2A dispatch failed (non-retryable): {error_str}") from e` (`:952-954`).

   `_is_retryable(error_msg)` (`:1028-1039`): lowercases the message; returns `False` (non-retryable) if it contains ANY of `"not found"`, `"invalid input"`, `"bad request"`, `"unauthorized"`, `"forbidden"`, `"capability"`; otherwise `True` (retryable). GOTCHA: this is a **message-substring** classifier, distinct from both `_is_retryable_error` (type-name) and `errors.is_retryable_error` (instance-type).

#### Branch B2: subprocess fallback (`:956-1025`)

Reached when `agent_card is None` OR B1 raised `ImportError` and fell through.
1. `logger.warning("No agent found for skill_id=%s or A2A unavailable, using subprocess fallback", input.skill_id)` (`:957-960`).
2. `fallback_module = f"agents.{input.skill_id.lower().replace('-', '_')}"` (`:962`).
3. `try: result = await dispatch_via_subprocess(module_name=fallback_module, task_input=input)` (`:963-967`).
4. `except Exception as e:` (`:968-991`): `logger.error("Subprocess fallback also failed: %s", e)`; `failed_result = AgentTaskResult(task_id="", status=FAILED, error=str(e))`; `_update_agent_task_row(..., error=str(e))`; `_insert_work_log_row(..., outcome="failed", error=str(e))`; `_emit_agent_complete(exec_id, failed_result, status=FAILED, error=str(e))` (no artifact_repo/ref); then **always** `raise RetryableError(f"Both A2A and subprocess dispatch failed: {e}") from e` (`:989-991`). GOTCHA: the subprocess-failure path is UNCONDITIONALLY retryable — unlike B1 it does not consult `_is_retryable`.
5. **Post-subprocess status check** (`:993-1010`): `if result.status == TaskStatus.FAILED:` (note: subprocess path checks only FAILED, **not** TIMED_OUT): `_update_agent_task_row(..., error=result.error or "unknown error")`; `_insert_work_log_row(..., outcome="failed", error=result.error or "unknown error")`; `_emit_agent_complete(exec_id, result, status=FAILED, error=result.error or "unknown error", artifact_repo=input.artifact_repo, artifact_ref=input.artifact_ref)`; `raise RetryableError(f"Agent task failed: {result.error}")`.
6. **Success** (`:1012-1025`): `_update_agent_task_row(task_row_id, result, now_utc)`; `_insert_work_log_row(..., outcome="completed")`; `_emit_agent_complete(exec_id, result, status=COMPLETED, artifact_repo=input.artifact_repo, artifact_ref=input.artifact_ref)`; `return result`. GOTCHA: subprocess success path does **NOT** call `_gate_work_log_disposition` — the work-log gate only guards the A2A success path (`:902-909`).

### 3.4 `_insert_agent_task_row` (`:154-216`) — persist queued task, returns `uuid | None`

Purpose: insert a `dispatched` `agent_task` row (observability only). Exactly-one scope validation.

1. `app_id = input.app_id or ""`; `wave_id = getattr(input, "wave_id", "") or ""` (`:170-171`).
2. `if bool(app_id) == bool(wave_id): raise ValueError("agent_task dispatch requires exactly one of app_id / wave_id; got app_id=..., wave_id=...")` (`:172-176`). GOTCHA: this raise is NOT swallowed — it escapes the helper and the activity (a genuine caller error → surfaced), unlike DB errors below. Both-empty and both-set both fail.
3. Parse: `app_uuid = uuid.UUID(app_id) if app_id else None`; `wave_uuid = uuid.UUID(wave_id) if wave_id else None`; on `(ValueError, TypeError)` → `raise ValueError(f"agent_task dispatch got malformed scope id: {exc}") from exc` (`:178-184`). Also NOT swallowed.
4. `task_id = uuid.uuid4()` (`:186`).
5. `try:` connect, then INSERT (`:187-212`):
   ```sql
   INSERT INTO agent_task (
       id, task_type, application_id, wave_id, module_name,
       skill_id, status, model_requested, dispatched_at,
       input_artifact_refs
   ) VALUES (
       $1, $2, $3, $4, $5, $6, 'dispatched', $7, $8, $9::jsonb
   )
   ```
   param mapping:
   | col | value | source |
   |---|---|---|
   | `id` `$1` | `task_id` (fresh uuid4) | `:186` |
   | `task_type` `$2` | `input.task_type` | |
   | `application_id` `$3` | `app_uuid` (or NULL) | |
   | `wave_id` `$4` | `wave_uuid` (or NULL) | |
   | `module_name` `$5` | `input.skill_id` | GOTCHA: `module_name` is populated from **`skill_id`**, same value as `skill_id` col |
   | `skill_id` `$6` | `input.skill_id` | |
   | `status` | literal `'dispatched'` | `:197` |
   | `model_requested` `$7` | `input.model_preference or None` | |
   | `dispatched_at` `$8` | `dispatched_at` arg | |
   | `input_artifact_refs` `$9::jsonb` | `json.dumps(list(input.input_artifacts or []))` | JSON array of strings; **note: `optional_input_artifacts` is NOT persisted** |
6. `finally: conn.close()`; return `task_id` (`:210-212`).
7. `except Exception as exc:` (DB layer) → `logger.warning("Failed to insert agent_task row: %s", exc)`; `return None` (`:213-216`). GOTCHA: only the DB write is best-effort/swallowed; the ValueErrors in steps 2-3 are hard.

Migration lineage cited in-code: exactly-one scope mirrors `create_gate_record` in `gate_operations.py` (commit 3666227); wave scope persistence added by migration 043; CHECK constraint `agent_task_application_or_wave_ck` (`:161-168`).

### 3.5 `_emit_agent_start` (`:51-97`) — initial RUNNING `step_execution` row

1. `if ctx is None or agent_task_id is None: return None` (`:57-61`). GOTCHA: agent-kind `step_execution` records require a non-null `agent_task_id` (DB CHECK); if `_insert_agent_task_row` returned None, emission is skipped.
2. `workflow_id = activity.info().workflow_id`, `attempt = activity.info().attempt`; on any exception (no activity ctx) → `workflow_id=""`, `attempt=1` (`:62-66`).
3. `input_artifacts = resolve_input_artifacts(ctx.input_artifact_paths or input.input_artifacts, repo=input.artifact_repo or "", ref=input.artifact_ref or "main")` (`:68-72`). `resolve_input_artifacts` (`execution.py:348-373`) maps each declaration string to `StepArtifactRef(repo, ref, path)` (no substitutions passed → placeholders left verbatim).
4. `payload =` (`:73-81`):
   ```json
   {
     "task_type": input.task_type,
     "skill_id": input.skill_id,
     "agent_role": input.skill_id,
     "model_used": input.model_preference or "",
     "token_usage": {"input": 0, "output": 0, "total": 0},
     "cost_estimate_usd": 0.0,
     "mcp_servers_used": []
   }
   ```
   GOTCHA: `agent_role` and `skill_id` are both set to `input.skill_id`; `model_used` at start holds the *requested* preference (later overwritten by `_emit_agent_complete` merge with actual).
5. `return await emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.AGENT, workflow_id=workflow_id, app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=attempt, input_artifacts=input_artifacts, payload=payload, agent_task_id=str(agent_task_id), status=ExecutionStatus.RUNNING))` (`:82-97`).

`emit_execution_record` (`execution.py:150-219`): `execution_id = uuid.uuid4()`; `started_at = input.started_at or now_utc`; parse app/wave/portfolio/agent_task/gate UUIDs via `_parse_uuid` (empty/None→None, bad→None). If `portfolio_uuid is None` → warn + `return None` (portfolio_id is required). Else INSERT into `step_execution`:
```sql
INSERT INTO step_execution (
  execution_id, app_id, wave_id, portfolio_id,
  line_id, step_id, step_kind, status,
  started_at, attempt, input_artifacts, payload,
  workflow_id, agent_task_id, gate_id
) VALUES ($1..$15)
```
with `input_artifacts` = `json.dumps([a.to_dict() for a in input_artifacts])` (`StepArtifactRef.to_dict` = `{repo, ref, path}` plus `content_hash` only if non-None, `execution.py:91-99`), `payload` = `json.dumps(payload or {})`, `step_kind`/`status` = enum `.value`. Return `execution_id`; any exception → warn + `return None` (`execution.py:212-219`).

### 3.6 `_update_agent_task_row` (`:240-285`) — terminal `agent_task` UPDATE

1. `if task_id is None: return` (`:247-248`).
2. `status = "failed" if error else result.status.value.lower()` (`:249`). GOTCHA: presence of an `error` arg **forces** the persisted status to `"failed"` regardless of `result.status`.
3. `output_ref = _pick_output_ref(result)` (§3.6a).
4. `token_usage = {"input": int(token_usage_input or 0), "output": int(token_usage_output or 0), "total": int((input)+(output))}` (`:251-255`).
5. connect + UPDATE (`:256-283`):
   ```sql
   UPDATE agent_task
   SET status = $2::task_status_enum,
       completed_at = $3,
       duration_ms = $4,
       model_used = $5,
       output_artifact_ref = $6,
       token_usage = $7::jsonb,
       cost_estimate = $8,
       last_error = $9
   WHERE id = $1
   ```
   | col | value |
   |---|---|
   | `$2 status::task_status_enum` | `status` (see step 2) |
   | `$3 completed_at` | `completed_at` arg |
   | `$4 duration_ms` | `int(result.duration_ms or 0)` |
   | `$5 model_used` | `result.model_used or None` |
   | `$6 output_artifact_ref` | `output_ref` (may be None) |
   | `$7 token_usage::jsonb` | `json.dumps(token_usage)` |
   | `$8 cost_estimate` | `float(result.cost_estimate_usd or 0.0) or None` — GOTCHA: `0.0 or None` → `None`, so a zero cost stores SQL NULL, not 0 |
   | `$9 last_error` | `error` (may be None) |
6. `except Exception as exc:` → `logger.warning("Failed to update agent_task row %s: %s", task_id, exc)`; swallow (`:284-285`).

#### 3.6a `_pick_output_ref` (`:219-237`) — choose safe `output_artifact_ref`

1. `if result.output_files: return result.output_files[0].path or None` (`:229-230`).
2. `if not result.output_artifacts: return None` (`:231-232`).
3. `candidate = str(result.output_artifacts[0])` (`:233`).
4. `if "\n" in candidate or len(candidate) > 512: return None` (`:234-236`). GOTCHA: guards against storing the agent's prose summary (which lands in `output_artifacts[0]`) as a file ref — only a short single-line token is accepted.
5. `return candidate or None` (`:237`).

### 3.7 `_insert_work_log_row` (`:393-442`) — append-only `ai_work_log`

1. `if agent_task_id is None: return` (`:414-415`). GOTCHA: a work-log row annotates an `agent_task` row, so if the agent_task couldn't persist, skip the log (REQ-006).
2. `payload = _build_work_log_entry(input, result, outcome=outcome, error=error)` (§3.8).
3. connect + INSERT (`:419-436`):
   ```sql
   INSERT INTO ai_work_log (agent_task_id, skill_id, outcome, payload)
   VALUES ($1, $2, $3, $4::jsonb)
   ```
   `$1=agent_task_id`, `$2=input.skill_id or None`, `$3=outcome`, `$4::jsonb=json.dumps(payload)`.
4. `except Exception as exc:` → `logger.warning("Failed to append ai_work_log row for agent_task %s: %s", agent_task_id, exc)`; swallow (`:437-442`).

INSERT-only — `ai_work_log` is append-only (REQ-009), no UPDATE path (`:411-413`).

### 3.8 `_build_work_log_entry` (`:334-390`) — pure payload builder

Pure (no I/O/clock/env). `_WORK_LOG_MAX_FIELD = 1024` (`:302`).

`_bounded(text)` (`:319-331`): if falsy → `""`; else `collapsed = " ".join(str(text).split())` (collapses all whitespace/newlines to single spaces); if `len<=1024` return collapsed; else `collapsed[:1023] + "…"`.

Builds:
```json
{
  "planned": {
    "task_type": input.task_type,
    "skill_id": input.skill_id,
    "model_requested": input.model_preference or "",
    "input_artifact_count": len(input.input_artifacts or [])
  },
  "did": {
    "model_used": result.model_used or "",
    "output_file_count": len(result.output_files or []),
    "output_summary": <_bounded(str(result.output_artifacts[0])) if output_artifacts else "">,
    "token_usage": {"input": token_input, "output": token_output, "total": token_input+token_output},
    "cost_estimate_usd": float(result.cost_estimate_usd or 0.0),
    "duration_ms": int(result.duration_ms or 0)
  },
  "checked": {
    "status": result.status.value.lower(),
    "outcome": outcome,
    "produced_output": bool(result.output_files) or bool(result.output_artifacts),
    "error_summary": _bounded(error)
  }
}
```
`token_input=int(result.token_usage_input or 0)`, `token_output=int(result.token_usage_output or 0)` (`:353-354`). GOTCHA: `output_summary` is the agent's prose `output_artifacts[0]`, bounded — this is intentional (the "what the AI did" narrative), distinct from `_pick_output_ref` which rejects prose.

`_outcome_for` (`:305-316`): `TIMED_OUT`→`"timed_out"`, `COMPLETED`→`"completed"`, else→`"failed"`.

### 3.9 `_emit_agent_complete` (`:100-141`) — terminal `step_execution` UPDATE

1. `if execution_id is None: return` (`:110-111`).
2. `token_usage = {"input": int(result.token_usage_input or 0), "output": int(result.token_usage_output or 0), "total": int((input)+(output))}` (`:112-118`).
3. `payload_merge = {"model_used": result.model_used or "", "token_usage": token_usage, "cost_estimate_usd": float(result.cost_estimate_usd or 0.0)}` (`:119-123`).
4. `output_artifacts = None`; `if result.output_files and artifact_repo:` build `[StepArtifactRef(repo=artifact_repo, ref=artifact_ref or "main", path=f.path) for f in result.output_files if f.path]` (`:124-134`). GOTCHA: output artifacts only recorded when BOTH `output_files` present AND `artifact_repo` truthy — the error paths that call this without `artifact_repo`/`artifact_ref` (`:941`, `:983`) never record output artifacts.
5. `await update_execution_record(execution_id, status=status, output_artifacts=output_artifacts, payload_merge=payload_merge, last_error=error)` (`:135-141`).

`update_execution_record` (`execution.py:222-275`): if `execution_id is None` return; `completed = completed_at or now_utc`; UPDATE:
```sql
UPDATE step_execution
 SET status=$2, completed_at=$3,
     duration_ms = EXTRACT(EPOCH FROM ($3 - started_at)) * 1000,
     output_artifacts = COALESCE($4::jsonb, output_artifacts),
     payload = payload || COALESCE($5::jsonb, '{}'::jsonb),
     last_error = COALESCE($6, last_error)
 WHERE execution_id = $1
```
GOTCHA: `payload` is JSONB-**merged** (shallow `||`), not replaced — the start payload's fields survive unless overwritten by `payload_merge` keys. `output_artifacts`/`last_error` use `COALESCE` so a `None` arg leaves the existing value. `duration_ms` computed server-side from `started_at`. Any exception → warn + swallow (`execution.py:270-275`).

### 3.10 `dispatch_agent_task` — idempotency / retries summary

- **Not idempotent**: each attempt inserts a NEW `agent_task` row (fresh `uuid4`) and a NEW `step_execution` row and appends a NEW `ai_work_log` row. A Temporal retry produces multiple rows per logical dispatch. The `attempt` number is captured on `step_execution` (`_emit_agent_start`) but `agent_task` rows are not deduped.
- **Retries** are driven by the raised error type: `RetryableError` (FAILED/TIMED_OUT agent result, retryable A2A error, any subprocess failure/FAILED) → Temporal retries; `NonRetryableError` (non-retryable A2A error message, or a blocked work-log gate) → terminal.
- The `@foundry_activity` wrapper passes these typed errors through unchanged (§0 step 7 first branch), so the body's classification is authoritative.

---

## 4. `dispatch_agent_task` — Git operations

**None.** This group performs no branch/commit/PR/merge sequence and defines no typed merge errors. Git operations (`mergeable_state`, PR merge, typed merge errors) live in other activity modules (e.g. `git_operations.py`), not here. The only "artifact ref" handling is `_pick_output_ref` / `update_agent_task_output_ref` (path selection for a DB column), covered above. The task's Git-activity requirement is N/A for this group.

---

## 5. Work-log disposition gate & `verify_work_log_disposition`

This is the maker/verifier verdict gate (P8, REQ-WL-007), SEPARATE from the best-effort `_insert_work_log_row` telemetry. A missing/non-conformant log yields **`blocked=True`** — the OPPOSITE of the telemetry's swallow-and-proceed (`:445-457`).

### Constants (`:483-486`, `:607`)
- `_WORK_LOG_FILENAME = "work_log.json"` — must match runtime writer `worklog.WORK_LOG_FILENAME` (`olympus-agent-runtime/src/services/worklog.py:93`).
- `_WORK_LOG_SIG_KEY = "review_sig"` — matches runtime `_META_REVIEW_SIG` (`worklog.py:129`).
- `_WORK_LOG_SIGNING_KEY_ENV = "OLYMPUS_WORKLOG_SIGNING_KEY"`.
- `_WORK_LOG_DEFAULT_SIGNING_KEY = "olympus-worklog-verifier-provenance-v1"` — matches runtime `_DEFAULT_SIGNING_KEY` (`worklog.py:133`).
- `_WORKSPACE_DIR = os.environ.get("OLYMPUS_WORKSPACE_DIR", "/workspace")`.
GOTCHA: these are duplicated literals (NOT imported) so the Temporal worker verifies the artifact WITHOUT importing the agent-runtime service (disjoint import paths in production) (`:479-482`). The runtime MINTS the HMAC; the worker RE-DERIVES and checks it.

### `WorkLogDispositionVerdict` (`:460-476`)
`@dataclass(frozen=True)`: `blocked: bool`, `reason: str`, property `may_proceed = not self.blocked`.

### `_work_log_artifact_path(workspace_dir, workspace_key, task_type)` (`:489-498`)
`parts=[workspace_dir]`; append `workspace_key` if truthy; append `task_type` if truthy; `return os.path.join(*parts, "work_log.json")`. Matches runtime writer path triple (REQ-WL-002; `worklog.py:222-232`).

### `_work_log_review_signed(data)` (`:501-531`)
1. `outcomes = list(data.get("outcomes") or [])`; if empty → `return False` (`:512-514`).
2. `stored = (data.get("metadata") or {}).get("review_sig")`; if not a non-empty str → `return False` (`:515-517`).
3. `key = os.environ.get("OLYMPUS_WORKLOG_SIGNING_KEY", "olympus-worklog-verifier-provenance-v1").encode("utf-8")` (`:518-520`).
4. `payload = json.dumps({"run_id": str(data.get("run_id","")), "skill": str(data.get("skill","")), "outcomes": outcomes}, sort_keys=True, separators=(",", ":")).encode("utf-8")` (`:521-529`). GOTCHA: canonicalization (`sort_keys=True`, `separators=(",",":")`) MUST match the runtime's `author_review` mint (`worklog.py:149-150`) byte-for-byte or the HMAC won't match.
5. `expected = hmac.new(key, payload, hashlib.sha256).hexdigest()`; `return hmac.compare_digest(stored, expected)` (`:530-531`, constant-time compare).

### `verify_work_log_disposition(workspace_dir, workspace_key, task_type) -> WorkLogDispositionVerdict` (`:534-600`) — PUBLIC, non-activity
1. `path = _work_log_artifact_path(...)`; if `not os.path.exists(path)` → `blocked=True, reason="no WorkLog artifact at the deterministic path {path} — failed-to-verify (REQ-WL-007)"` (`:553-561`).
2. `open(path, utf-8); data = json.load(fh)`; on `(OSError, ValueError)` → `blocked=True, reason="unreadable WorkLog artifact at {path}: {exc} (REQ-WL-007)"` (`:562-569`).
3. `missing = [name for (name, present) in (("plan", bool(data.get("plan"))), ("checklist", ...), ("decisions", ...), ("outcomes", ...)) if not present]`; if any missing → `blocked=True, reason="non-conformant WorkLog — missing section(s): {...} (REQ-WL-007)"` (`:570-587`). Four required sections: `plan`, `checklist`, `decisions`, `outcomes`.
4. `if not _work_log_review_signed(data):` → `blocked=True, reason="WorkLog review_log (outcomes) is not verifier-authored — no valid verifier-provenance signature; a maker cannot grade its own work (REQ-WL-005, maker != verifier)"` (`:588-596`).
5. else → `blocked=False, reason="conformant, verifier-authored four-section WorkLog present"` (`:597-600`).

Self-contained, stdlib only. Never raises for content errors (all failures → a `blocked` verdict). No DB, no retries — a pure function.

### `_work_log_gate_enabled()` (`:610-621`)
`return os.environ.get("OLYMPUS_WORKLOG_GATE","").strip().lower() in ("1","true","yes","on")`. Default OFF. GOTCHA: the in-process `execute_skill` gate is the primary/always-on enforcement; this workflow-level gate is opt-in for shared-volume deployments (`:610-618`).

### `_gate_work_log_disposition(input)` (`:624-655`) — called on A2A success path only
1. `if not _work_log_gate_enabled(): return` (`:635-636`).
2. `try: verdict = verify_work_log_disposition(_WORKSPACE_DIR, input.workspace_key, input.task_type)` (`:637-640`).
3. `except Exception as exc:` → `logger.warning("work-log gate verdict unavailable (%s/%s): %s — allowing", input.task_type, input.app_id, exc)`; `return` (allow) (`:641-646`). GOTCHA: a verdict-read error never masks a genuine completion — the in-process executor gate is authoritative and already ran.
4. `if verdict.blocked:` → `logger.error("Disposition BLOCKED by work-log gate (%s/%s): %s", ...)`; `raise NonRetryableError("work-log verification failed — disposition blocked (REQ-WL-007): {verdict.reason}")` (`:647-655`). This escapes `dispatch_agent_task` as a terminal error (passes through the `@foundry_activity` wrapper untouched — it's a `WorkflowError`).

---

## 6. `load_context_priors` — activity #3 (`context_priors.py:107-165`)

Signature: `async def load_context_priors(input: LoadContextPriorsInput) -> LoadContextPriorsResult`.

Inputs: `LoadContextPriorsInput.skill_id: str` (`types.py:2994-3004`). Output: `LoadContextPriorsResult.priors: list[dict]` (`types.py:3022-3027`). Each returned dict shape: `{"id": str, "path": str, "purpose": str, "content": str}` (`:156-163`). The `ContextPrior` dataclass (`types.py:3007-3019`) documents the same four fields, but the activity returns **plain dicts**, not `ContextPrior` instances.

Purpose: read human-authored markdown priors from the active client profile and return those matching `skill_id`. The workflow folds these into `AgentTaskInput.context['context_priors']` (module docstring `:1-13`). Priors are advisory, NOT authoritative inputs.

Constant: `_MAX_PRIOR_BYTES = 128 * 1024` (128 KiB per prior) (`:38`), to stay under Temporal's ~2MB activity-payload limit; per-prior cap (not shared budget) (`:34-38`).

### Body (`:122-165`)
1. `profile_root = _profile_root_from_env()`; if `None` → `return LoadContextPriorsResult(priors=[])` (`:122-124`).
2. `priors_dir = profile_root / "context-priors"`; if `not priors_dir.is_dir()` → `return priors=[]` (`:126-128`).
3. `manifest = _load_manifest(priors_dir / "manifest.yaml")`; if empty → `return priors=[]` (`:130-132`).
4. `matched = []`; for each `entry` in manifest (`:134-163`):
   - `skills = entry.get("skills") or []`; if `not isinstance(skills, list) or input.skill_id not in skills: continue` (`:136-138`).
   - `rel_path = entry.get("path") or ""`; if `not isinstance(rel_path, str): continue` (`:139-141`).
   - `file_path = (priors_dir / rel_path).resolve()` (`:142`).
   - **Path traversal guard**: `try: file_path.relative_to(priors_dir.resolve())` — on `ValueError` (escapes dir, e.g. `../`) → `logger.warning("context_priors: manifest path escapes priors dir: %s", rel_path)`; `continue` (`:143-152`).
   - `content = _read_prior_content(file_path)`; if falsy → `continue` (`:153-155`).
   - append `{"id": str(entry.get("id")), "path": str(rel_path), "purpose": str(entry.get("purpose") or ""), "content": content}` (`:156-163`).
5. `return LoadContextPriorsResult(priors=matched)` (`:165`).

### `_profile_root_from_env()` (`:41-59`)
1. `env = os.environ.get("OLYMPUS_PROFILE_ROOT")`; if set: `p = Path(env).resolve()`; if `p.is_dir()` → `return p` (`:49-53`). Set by `worker_bootstrap.py` (compose + helm wire it).
2. Fallback (local dev): `repo_root = Path(__file__).resolve().parents[3]` (module is at `temporal/olympus_workflows/activities/context_priors.py` → repo root is 3 parents up); `candidate = repo_root / "profiles" / "faa"`; `return candidate if candidate.is_dir() else None` (`:54-59`). GOTCHA: fallback is hardcoded to the **FAA** profile.

### `_load_manifest(manifest_path)` (`:62-84`)
1. `if not manifest_path.exists(): return []` (`:63-64`).
2. `try: data = yaml.safe_load(manifest_path.read_text()) or {}`; on `yaml.YAMLError` → `logger.warning("context_priors: manifest YAML unparseable at %s: %s", ...)`; `return []` (`:65-73`).
3. `priors = data.get("priors")`; if `not isinstance(priors, list): return []` (`:74-76`).
4. `out = []`; for each `entry` in priors: skip if `not isinstance(entry, dict)`; skip if `not entry.get("id") or not entry.get("path")`; else append (`:77-83`). Returns only entries with both `id` and `path`.

### `_read_prior_content(path)` (`:87-104`)
1. `try: raw = path.read_bytes()`; on `OSError` → `logger.warning("context_priors: could not read %s: %s", ...)`; `return ""` (`:88-92`).
2. If `len(raw) > _MAX_PRIOR_BYTES`: `truncated = raw[:_MAX_PRIOR_BYTES].decode("utf-8", errors="replace")`; return `truncated + "\n\n[TRUNCATED: prior exceeded 128 KiB; full text at " + str(path.relative_to(path.parents[2])) + "]\n"` (`:93-103`). GOTCHA: `128` is computed as `_MAX_PRIOR_BYTES // 1024`; the "full text at" path is relative to `path.parents[2]`.
3. else `return raw.decode("utf-8", errors="replace")` (`:104`).

### Error handling / retries / idempotency
- **Never raises for content errors** — missing profile root, missing dir, unparseable YAML, unreadable file, path escape all resolve to skip/empty (docstring `:113-121`). Best-effort; workflow tolerates empty return (`types.py:3024-3025` — callers do not branch on it).
- Fully **idempotent** and **read-only** — no DB, no writes, no clock/random. Same inputs + same filesystem → same output.
- No explicit retry policy in the activity; a raised exception (only from truly unexpected code, since content errors are caught) would be wrapped by `@foundry_activity` per §0.

GOTCHA (manifest matching): `skills` matching is exact string membership (`input.skill_id in skills`) — no normalization/case-fold. An entry with no `skills` key (`or []`) never matches any skill.
