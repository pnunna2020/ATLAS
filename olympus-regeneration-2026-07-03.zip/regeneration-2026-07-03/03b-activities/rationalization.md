# Activity group: `line_transitions/rationalization.py`

Atomic regeneration spec. Source module:
`temporal/olympus_workflows/activities/line_transitions/rationalization.py`
(the "rationalization segment" split out of the original monolithic
`line_transitions` module in P7-S16.14; behavior is byte-for-byte unchanged and
it is re-exported through the package facade so
`olympus_workflows.activities.line_transitions.<name>` keeps working —
rationalization.py:1-6).

Reproduce every function to behavioral parity. All four public activities are
**load / persist** activities. There are **no git activities** and **no
agent-dispatch activities** in this module (the agent-dispatch happens in the
workflow; these activities only load context for it and persist its output).

## Units documented

Four `@foundry_activity`-decorated activity functions:

1. `load_wave_rationalization_capabilities` (rationalization.py:134-297)
2. `persist_rationalization_capabilities` (rationalization.py:324-1015)
3. `persist_rationalization_capability_dispositions` (rationalization.py:1102-1350)
4. `persist_rationalization_side_effects` (rationalization.py:1470-1573)

Plus the private helpers they depend on (schema loaders, slug minting, the four
`_extract_*` projection functions in `_shared.py`) — all reproduced in full
because the persist behavior depends on them.

---

## 0. What `@foundry_activity` adds over raw `activity.defn`

Decorator: `temporal_base/activities.py:79-150`. Every activity below is
declared `@foundry_activity(config=ActivityConfig(enable_observability=True))`.

`ActivityConfig` dataclass (`activities.py:41-53`) fields + defaults:
`retry_policy=None`, `start_to_close_timeout=None`,
`schedule_to_close_timeout=None`, `schedule_to_start_timeout=None`,
`heartbeat_timeout=None`, `enable_observability=True`,
`enable_error_wrapping=True`, `log_inputs=False`, `log_outputs=False`.

The decorator (`activities.py:97-148`):

- Wraps the coroutine in `@activity.defn(name=name, **activity_kwargs)` +
  `@functools.wraps(func)` (`activities.py:100-102`). Activity **name defaults
  to `func.__name__`** (`activities.py:103`) and is preserved — Temporal replay
  keys on it (module docstring line 14-16). None of these four pass an explicit
  `name`, so the Temporal task names are exactly the function names.
- **Observability** (only when `enable_observability=True`, which it is): a
  stdlib `logging.getLogger(__name__)` `INFO` line `"Activity %s starting"`
  before the body (`activities.py:105-110`), `"Activity %s completed"` after
  (`activities.py:115-120`), and on any exception a `logger.error` `"Activity %s
  failed: %s"` (`activities.py:124-131`). `inputs`/`outputs` are only attached to
  the `extra` dict when `log_inputs`/`log_outputs` are True (both default False),
  so args/results are NOT logged by default. **GOTCHA:** this is stdlib
  `logging`, deliberately NOT structlog/Prometheus, so it is safe outside the
  workflow sandbox (module docstring line 5-6).
- **Error wrapping** (only when `enable_error_wrapping=True`, the default;
  `activities.py:133-146`): any exception escaping the body is classified —
  - If it is already a `WorkflowError` OR `temporalio` `ApplicationError`, it is
    re-raised unchanged (`activities.py:135-136`). This is why the activities
    below deliberately raise `NonRetryableError` for bad workflow inputs: those
    pass straight through with `non_retryable=True`.
  - Else `_is_retryable_error(error)` (`activities.py:56-76`) does a
    **type-name substring match**: it lowercases `str(type(error))` and returns
    True if it contains any of `timeout`, `connection`, `network`, `temporary`,
    `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. Retryable →
    wrapped in `RetryableError` (`non_retryable=False`); otherwise wrapped in
    `NonRetryableError` (`non_retryable=True`) (`activities.py:137-144`).
  - **GOTCHA:** this heuristic keys on the *type-name string*, distinct from
    `errors.is_retryable_error` which inspects httpx/OSError/ApplicationError
    instances (`activities.py:56-63`). E.g. `asyncpg.exceptions.ConnectionDoesNotExistError`
    contains `"connection"` → wrapped RETRYABLE; a generic
    `asyncpg.PostgresError` (name contains none of the patterns) → wrapped
    NON-retryable. Temporal reads `non_retryable` off the resulting
    `ApplicationError` to decide whether to retry.
- **No timeouts/heartbeat/retry_policy are set by these activities** — all
  `ActivityConfig` timeout fields are `None` and `foundry_activity` does not
  forward them into `@activity.defn` (it only forwards `name` + `**activity_kwargs`).
  Timeouts + `RetryPolicy` are therefore whatever the **workflow-side
  `execute_activity(...)` call** specifies (out of scope for this module). No
  activity here calls `activity.heartbeat()`.

### `NonRetryableError` semantics (`temporal_base/errors.py`)

`WorkflowError(ApplicationError)` sets `non_retryable=True` by default
(errors.py:16-20). `RetryableError` → `non_retryable=False` (errors.py:23-27).
`NonRetryableError` → `non_retryable=True` (errors.py:30-34). When these
activities `raise NonRetryableError(...)`, the decorator's pass-through branch
(`activities.py:135-136`) re-raises it verbatim, so Temporal will **not** retry.

### Execution-record observability (`utils/execution.py`)

Every activity calls `emit_code_step_start(...)` at entry and
`emit_code_step_complete(...)` at exit. These are separate from the decorator's
stdlib logging — they write a Layer-B `step_execution` row for the stepper UI.

- `emit_code_step_start(ctx, *, function_name, columns_writable=None)`
  (execution.py:283-321): **returns `None` immediately if `ctx is None`**
  (execution.py:295-296) — legacy call sites that don't pass
  `execution_context` skip emission entirely. Otherwise it reads
  `activity.info().workflow_id` + `.attempt` inside a try/except that defaults
  to `workflow_id=""`, `attempt=1` on failure (execution.py:297-304), builds
  payload `{"function": function_name}` (+ `columns_written` when
  `columns_writable` given), and emits an `EmitExecutionRecordInput` with
  `step_kind=StepKind.CODE`, `status=ExecutionStatus.RUNNING`, sourcing
  `portfolio_id`/`line_id`/`step_id`/`app_id`/`wave_id` from the
  `StepExecutionContext` (execution.py:305-321). Returns the new record's
  `uuid.UUID` (or `None`).
- `emit_code_step_complete(execution_id, *, status=COMPLETED, columns_written=None, error=None)`
  (execution.py:324-345): updates that record; if `execution_id is None` the
  downstream `update_execution_record` is a no-op for that record.
- `StepExecutionContext` (types.py:538-561): fields `portfolio_id`, `line_id`,
  `step_id`, `app_id=""`, `wave_id=""`, `input_artifact_paths=[]`, `gate_id=""`.

---

## Shared helpers used by this module

From `line_transitions/_shared.py`:

- `_db_url()` (_shared.py:23-29): builds
  `postgresql://{user}:{password}@{host}:{port}/{db}` from env vars
  `DATABASE_USER` (default `olympus`), `DATABASE_PASSWORD` (`olympus`),
  `DATABASE_HOST` (`localhost`), `DATABASE_PORT` (`5432`), `DATABASE_NAME`
  (`olympus`). Used for every `asyncpg.connect`.
- `_try_parse_json(text)` (_shared.py:40-56): returns `None` when `text` is
  falsy; tries `json.loads`; on `JSONDecodeError` finds the first `{` and last
  `}` and re-parses that slice; returns the value only if it is a `dict`, else
  `None`. **GOTCHA:** a top-level JSON array or scalar parses fine but is
  returned as `None` because the `isinstance(value, dict)` gate at line 56
  rejects non-dicts.
- `_build_update_sql(projections)` (_shared.py:506-539) — see §4.
- `_merge_application_metadata(conn, app_uuid, namespace, payload)`
  (_shared.py:453-503) — see §4.
- `_extract_rationalization_compliance_metadata(...)` (_shared.py:246-296) —
  see §4.
- `logger` (_shared.py:20) — the module `logging.getLogger(__name__)` used by
  every `logger.info`/`logger.error` call in the activities.

---

## Schema loading + validation helpers (module-private)

Two independent schema-cache subsystems in this module, one per persist activity.

### Rat-cap clustering plan schema (rationalization.py:50-131)

`_rat_cap_clustering_plan_schema_path()` (rationalization.py:50-79): builds a
candidate list of directories and returns the first that holds
`<dir>/rationalization/rationalization-clustering-plan.schema.json` (`.is_file()`),
resolved to absolute string; else `None`. Candidate order:
1. `os.environ["OLYMPUS_SCHEMAS_DIR"]` if set (rationalization.py:61-63).
2. `Path(__file__).resolve().parents[4] / "schemas"` (rationalization.py:64-70).
   **GOTCHA:** `parents[4]` (not `[3]`) — the P7-S16.14 split moved the file one
   directory deeper (`activities/line_transitions/<seg>.py`), so `parents[4]`
   resolves to the same repo-root `schemas/` the original `parents[3]` did.
3. `Path("/app/schemas")` (rationalization.py:71).
4. `Path("/app/repo/schemas")` (rationalization.py:72).

`_CACHED_RAT_CAP_PLAN_SCHEMA: dict | None = None` (rationalization.py:82) —
module-global cache.

`_load_rat_cap_clustering_plan_schema()` (rationalization.py:85-105): returns
the cached schema if set; else resolves path (returns `None` if unreachable),
`json.load`s it, returns `None` on `JSONDecodeError`/`OSError`, otherwise caches
and returns. **GOTCHA:** the cache is only written on success (line 104), so a
transient read failure is retried on next call; but a successfully loaded schema
is never re-read (persists for the worker's lifetime).

`_validate_rat_cap_clustering_plan(payload)` (rationalization.py:108-131):
returns `list[str]` of human-readable errors; **empty list == valid**.
- If `payload` is not a `dict` → `["clustering plan is not a JSON object"]`.
- If schema unavailable → a single error string
  `"rationalization-clustering-plan.schema.json not found on worker — set
  OLYMPUS_SCHEMAS_DIR or mount the repo schemas directory"`.
- Else runs `jsonschema.Draft202012Validator(schema).iter_errors(payload)`;
  formats each error as `f"{err.json_path or '<root>'}: {err.message}"`,
  **capped at the first 8** (`errors[:8]`, line 130).

### Disposition-recommendation schema (rationalization.py:1018-1099)

`_disposition_recommendation_schema_path()` (rationalization.py:1018-1050):
identical structure, target file
`<dir>/rationalization/disposition-recommendation.schema.json`, same
`parents[4]` + `/app/schemas` + `/app/repo/schemas` candidates + env override.

`_CACHED_DISPOSITION_RECOMMENDATION_SCHEMA` (rationalization.py:1053),
`_load_disposition_recommendation_schema()` (rationalization.py:1056-1070),
`_validate_disposition_recommendation(payload)` (rationalization.py:1073-1099) —
same shape as the rat-cap variants; the not-a-dict message is
`"disposition recommendation is not a JSON object"` and the missing-schema
message names `disposition-recommendation.schema.json`. Errors capped at 8.

The full JSON schemas live at
`schemas/rationalization/rationalization-clustering-plan.schema.json` (200 lines)
and `schemas/rationalization/disposition-recommendation.schema.json` (184 lines);
the shapes are reproduced inline where the persist logic consumes them (below).

### External-id slug minting (rationalization.py:300-321)

`_mint_rat_cap_external_id(name: str) -> str` (rationalization.py:300-321):
1. `base = re.sub(r"[^a-z0-9]+", "-", (name or "").strip().lower()).strip("-")`
   — lowercases, replaces any run of non-alphanumerics with a single `-`, strips
   leading/trailing `-` (line 318).
2. `base = base[:48].strip("-") or "capability"` — truncate to 48 chars,
   re-strip trailing `-`, fall back to literal `"capability"` if empty (line 319).
3. `digest = hashlib.sha1((name or "").encode("utf-8")).hexdigest()[:6]`
   — first 6 hex chars of SHA-1 of the raw name (line 320).
4. Returns `f"ratcap-{base}-{digest}"` (line 321).

**GOTCHA:** deterministic (no randomness/clock) so the same name always yields
the same slug → re-runs UPSERT the same row via `(portfolio_id, external_id)`
rather than duplicating. The SHA-1 suffix disambiguates two different names that
slugify to the same token. **GOTCHA:** the slug pattern `^ratcap-...` does NOT
match the schema's `external_id` pattern `^[A-Z][A-Z0-9_-]{0,63}$` — but that
schema constraint only applies to agent-supplied external_ids; a minted one
never re-enters schema validation (it is minted after validation, at persist
time), and the DB column is `String(64)` with no CHECK (migration 052:96-105).

---

## 1. `load_wave_rationalization_capabilities`

`@foundry_activity(config=ActivityConfig(enable_observability=True))`
(rationalization.py:134). Read-only.

**Signature:** `async def load_wave_rationalization_capabilities(input:
LoadWaveRationalizationCapabilitiesInput) -> LoadWaveRationalizationCapabilitiesOutput`.

**Input** (`LoadWaveRationalizationCapabilitiesInput`, types.py:1660-1686):
- `portfolio_id: str`, `wave_id: str`, `execution_context: StepExecutionContext | None = None`.

**Output** (`LoadWaveRationalizationCapabilitiesOutput`, types.py:1690-1700):
- `prior_rat_caps: list[dict] = []`, `wave_capabilities: list[dict] = []`.

**Flow:**
1. `exec_id = await emit_code_step_start(input.execution_context,
   function_name="load_wave_rationalization_capabilities")` (rationalization.py:166-169).
2. `out = LoadWaveRationalizationCapabilitiesOutput()` (line 170).
3. Inside a `try` (whose `except` calls `emit_code_step_complete(exec_id,
   status=FAILED, error=str(exc))` then `raise` — rationalization.py:282-286):
   - Parse `portfolio_id` → `uuid.UUID`; on `ValueError`/`TypeError` raise
     `NonRetryableError(f"Invalid portfolio_id: {input.portfolio_id!r}")`
     (rationalization.py:173-178). Same for `wave_id`
     (`NonRetryableError(f"Invalid wave_id: ...")`, lines 179-184).
   - `conn = await asyncpg.connect(_db_url())` (line 186). `try/finally` closes
     the conn (`await conn.close()`, lines 272-273). **No transaction** (read-only).
4. **Query 1 — `prior_rat_caps`** (rationalization.py:194-212). EXACT SQL:
   ```sql
   SELECT id, name, external_id, description
   FROM rationalization_capability
   WHERE portfolio_id = $1
     AND retired_at IS NULL
   ORDER BY name
   ```
   with `$1 = portfolio_uuid`. **GOTCHA:** scoped by **portfolio, NOT wave** —
   the row-reuse contract spans waves (a rat-cap minted in wave 1 must be
   reusable when wave 2 of the same portfolio clusters). Excludes rows the
   disposition stage soft-retired (`retired_at IS NULL`). Each row →
   ```json
   {"id": "<str(id)>", "name": <name>, "external_id": <external_id>,
    "description": <description or "">}
   ```
   (rationalization.py:204-212). `description` NULL → `""`.
5. **Query 2 — `wave_capabilities`** (rationalization.py:225-257). EXACT SQL:
   ```sql
   SELECT
       c.id              AS capability_id,
       c.name            AS name,
       c.description     AS description,
       c.external_id     AS external_id,
       c.system_id       AS system_id,
       sa.application_id AS application_id,
       a.name            AS application_name,
       s.name            AS system_name,
       (
           SELECT bd.name
           FROM capability_business_domain cbd
           JOIN business_domain bd ON bd.id = cbd.business_domain_id
           WHERE cbd.capability_id = c.id
           ORDER BY bd.name
           LIMIT 1
       ) AS business_domain
   FROM wave_application wa
   JOIN application a ON a.id = wa.application_id
   JOIN system_application sa ON sa.application_id = a.id
   JOIN system s ON s.id = sa.system_id
   JOIN capability c ON c.system_id = s.id
   WHERE wa.wave_id = $1
     AND a.portfolio_id = $2
   ORDER BY a.name, c.name
   ```
   with `$1 = wave_uuid`, `$2 = portfolio_uuid`. **GOTCHA (join chain):** wave
   membership goes through the `wave_application` join table (apps can move
   waves; `application` has no wave FK). Chain:
   `wave_application → application → system_application → system → capability`.
   **GOTCHA (business_domain):** a capability can attach to multiple
   `business_domain` rows via `capability_business_domain`; the correlated
   subquery collapses to the **FIRST domain by name** (`ORDER BY bd.name LIMIT 1`)
   to keep the payload bounded. Each row →
   ```json
   {"capability_id": "<str>", "application_id": "<str>",
    "application_name": <str>, "name": <str>, "description": <desc or "">,
    "external_id": <external_id>, "system_id": "<str>",
    "system_name": <str>, "business_domain": <domain or "">}
   ```
   (rationalization.py:258-271). NULL description/business_domain → `""`.
6. On success: `emit_code_step_complete(exec_id,
   columns_written=[f"prior_rat_caps={len(...)}",
   f"wave_capabilities={len(...)}"])` (rationalization.py:275-281).
7. `logger.info("load_wave_rationalization_capabilities: returning context",
   extra={portfolio_id, wave_id, prior_rat_caps=len, wave_capabilities=len})`
   (rationalization.py:288-296), then `return out`.

**Best-effort semantics:** an empty `wave_capabilities` is valid (no apps in the
wave have Discovered capabilities yet); the persist contract accepts an empty
plan, so the wave continues (docstring lines 162-164).

**Idempotency:** fully idempotent — read-only, no writes.

**Retries:** only the two `NonRetryableError`s are terminal. Any other
exception (e.g. asyncpg connection error) escapes to the decorator, which
type-name-classifies it (§0) — a connection error name (`"connection"`) →
`RetryableError` → Temporal retries per the workflow's RetryPolicy.

---

## 2. `persist_rationalization_capabilities`

`@foundry_activity(config=ActivityConfig(enable_observability=True))`
(rationalization.py:324). The heaviest activity — the rat-cap layer's writer.

**Signature:** `async def persist_rationalization_capabilities(input:
PersistRationalizationCapabilitiesInput) -> PersistRationalizationCapabilitiesOutput`.

**Input** (`PersistRationalizationCapabilitiesInput`, types.py:1572-1594):
- `portfolio_id: str`, `wave_id: str`, `clustering_plan_json: str = ""`,
  `clustering_plan_artifact_ref: str = ""`,
  `execution_context: StepExecutionContext | None = None`.

**Output** (`PersistRationalizationCapabilitiesOutput`, types.py:1598-1614):
- `portfolio_id: str`, `wave_id: str`, `rat_caps_inserted=0`,
  `rat_caps_updated=0`, `rat_caps_retired=0`, `capability_fk_assignments=0`,
  `capability_splits_created=0`, `validation_errors: list[str] = []`.

`out` is pre-populated with `portfolio_id`+`wave_id` at construction
(rationalization.py:356-359).

### Clustering plan JSON shape (consumed)

Validated against `rationalization-clustering-plan.schema.json`. Top-level keys
consumed by persist:
- `rationalization_capabilities: [ {existing_id?, name, external_id?,
  description, rationale, evidence_refs, confidence} ]` (schema lines 46-128).
- `capability_assignments: [ {capability_id, rationalization_capability_index} ]`
  (schema lines 130-149).
- `capability_splits: [ {parent_capability_id,
  child_assignments: [{name, description, rationalization_capability_index}]} ]`
  (schema lines 151-190).
- `metadata` + `open_questions` exist in the schema but are NOT read by persist.

### Flow (all inside the outer `try` whose `except` at lines 997-1001 emits FAILED + re-raises)

**Step A — validate workflow-input UUIDs (loud):**
- `portfolio_uuid = uuid.UUID(input.portfolio_id)`; on error raise
  `NonRetryableError(f"Invalid portfolio_id: ...")` (rationalization.py:364-369).
- `wave_uuid = uuid.UUID(input.wave_id)`; on error raise
  `NonRetryableError(f"Invalid wave_id: ...")` (rationalization.py:370-375).

**Step B — parse + schema-validate the plan BEFORE any DB write:**
- `plan = _try_parse_json(input.clustering_plan_json)` (line 378). If `None`:
  append `"clustering plan JSON is empty or unparseable"` to
  `out.validation_errors`, `logger.info(... "unparseable plan" ...)`, call
  `emit_code_step_complete(exec_id, columns_written=[])`, **`return out`**
  (rationalization.py:379-393). No DB connection is opened.
- `validation_errors = _validate_rat_cap_clustering_plan(plan)` (line 395). If
  non-empty: `out.validation_errors = validation_errors` (replaces the list),
  `logger.info(... "plan failed schema validation" ...)`, emit complete with
  `columns_written=[]`, **`return out`** (rationalization.py:396-408). No DB
  writes.

**Step C — pull the three arrays:**
```python
rat_caps    = plan.get("rationalization_capabilities") or []
assignments = plan.get("capability_assignments") or []
splits      = plan.get("capability_splits") or []
```
(rationalization.py:410-412).

**Step D — precompute the "keep" natural-key sets** (rationalization.py:417-434),
used by Step 0 to decide which prior rows the new roster converges onto vs drops:
- `keep_external_ids`, `keep_names`, `keep_existing_ids` — all `set[str]`.
- For each `rat_cap` dict: `_name = str(rat_cap.get("name") or "").strip()`;
  `_ext` = the stripped `external_id` if it is a str else `None`;
  **if `_ext` is falsy and `_name` truthy → `_ext = _mint_rat_cap_external_id(_name)`**
  (applies the SAME minting the Step-1 UPSERT loop does, line 427). Add `_ext`
  to `keep_external_ids` if truthy; add `_name` to `keep_names` if truthy; add
  stripped `existing_id` to `keep_existing_ids` if it's a non-blank str.
- **GOTCHA:** non-dict entries in `rat_caps` are skipped (`continue`, line 422).

**Step E — open connection** `conn = await asyncpg.connect(_db_url())` (line
437), `try/finally` closes it (lines 985-986).

**Step F — PRE-FLIGHT fabricated-capability-id check, BEFORE any write and
BEFORE the transaction** (rationalization.py:439-521):
- Collect `referenced_cap_ids: set[uuid.UUID]` from every
  `assignments[].capability_id` and every `splits[].parent_capability_id` that
  parses as a UUID (malformed UUIDs are silently skipped here — they are caught
  later in Step 2/Step 3; rationalization.py:459-475).
- If the set is non-empty, run:
  ```sql
  SELECT c.id
  FROM capability c
  JOIN system s ON s.id = c.system_id
  WHERE s.portfolio_id = $1
    AND c.id = ANY($2::uuid[])
  ```
  `$1=portfolio_uuid`, `$2=list(referenced_cap_ids)` (rationalization.py:477-487).
- `existing_cap_ids = {r["id"] for r in existing_rows}`;
  `fabricated = sorted(str(cid) for cid in referenced_cap_ids if cid not in
  existing_cap_ids)` (lines 488-493).
- If `fabricated` non-empty: append a single `validation_errors` message
  `f"{n} capability_id(s) referenced in capability_assignments / capability_splits
  do NOT exist in this portfolio's capability table: {preview}{more}. These were
  fabricated by the agent — every capability_id MUST be copied verbatim from
  wave_capability_grain in _dispatch-context.json. Writing nothing."` where
  `preview` = first 5 ids joined by `", "` and `more` = `f" (+{n-5} more)"` when
  `n>5` else `""` (rationalization.py:494-509). `logger.error(...)`, emit
  complete with `columns_written=[]`, **`return out`** (lines 510-521). **No
  transaction is opened; nothing is written.**
- **GOTCHA (why this exists):** the 2026-06-16 Wave-1 run fabricated sequential
  placeholder ids that didn't exist → per-row UPDATEs matched nothing and every
  assignment silently dropped, leaving the roster persisted but the fine-cap
  rollup unbound. This makes that a loud write-nothing failure
  (rationalization.py:439-458).

**Step G — the transaction** `async with conn.transaction():` (line 523).
Everything below is atomic; any raise rolls back.

#### Step 0 — LATEST-RUN-WINS retire (rationalization.py:523-599)

- Load prior live wave rows:
  ```sql
  SELECT id, name, external_id
  FROM rationalization_capability
  WHERE portfolio_id = $1 AND wave_id = $2 AND retired_at IS NULL
  ```
  `$1=portfolio_uuid`, `$2=wave_uuid` (rationalization.py:562-572).
- `dropped_ids = [r["id"] for r in prior_live if str(r["id"]) not in
  keep_existing_ids and (r["external_id"] or "") not in keep_external_ids and
  (r["name"] or "") not in keep_names]` (rationalization.py:573-579). I.e. a
  prior row is dropped iff its id, external_id, AND name are ALL absent from the
  keep sets.
- If `dropped_ids`:
  1. NULL the FK on fine caps pointing at dropped rat-caps:
     ```sql
     UPDATE capability
     SET rationalization_capability_id = NULL, updated_at = now()
     WHERE rationalization_capability_id = ANY($1::uuid[])
     ```
     `$1=dropped_ids` (rationalization.py:581-589).
  2. Soft-retire the dropped rat-caps:
     ```sql
     UPDATE rationalization_capability
     SET retired_at = now(), updated_at = now()
     WHERE id = ANY($1::uuid[])
     ```
     (rationalization.py:590-598).
  3. `out.rat_caps_retired = len(dropped_ids)` (line 599).
- **GOTCHA (why Step 0 runs first, in-txn, after validation):** (a) stale rows
  not in the new roster would otherwise survive as orphan live rows; (b) a prior
  NULL-external row sharing a NAME with a new minted-external row would collide
  on `ix_rat_cap_portfolio_name` — the 2026-06-15 Wave-1 unique-violation
  failure (rationalization.py:524-561). Rows the new roster CONVERGES onto (same
  external_id / name / referenced by existing_id) are KEPT so the UPSERT loop
  updates them in place — UUID stability is a downstream contract. Soft-retire
  (not delete) preserves history; the unique indexes are partial on
  `retired_at IS NULL`. The only FK into rat-caps
  (`capability.rationalization_capability_id`) is `ON DELETE SET NULL`, and the
  code proactively NULLs it on dropped rows.

#### Step 1 — UPSERT each rat-cap (rationalization.py:601-838)

`rat_cap_id_by_index: dict[int, uuid.UUID] = {}` maps the plan array index → the
resulting rat-cap UUID (used by Steps 2/3 to resolve FKs).

For `idx, rat_cap in enumerate(rat_caps)` (skip non-dict entries, line 605-606):
- Extract + normalize fields (rationalization.py:607-628):
  - `name = str(rat_cap.get("name") or "").strip()`
  - `description = str(rat_cap.get("description") or "")`
  - `rationale = str(rat_cap.get("rationale") or "")`
  - `evidence_refs = rat_cap.get("evidence_refs") or []`
  - `confidence = rat_cap.get("confidence")` (passed through as-is — number or None)
  - `external_id`: stripped-or-None if str, else None (lines 612-616); **if
    `external_id is None and name` → `external_id = _mint_rat_cap_external_id(name)`**
    (lines 622-623).
  - `existing_id`: stripped-or-None if str, else None (lines 624-628).
  - `evidence_refs_json = json.dumps(evidence_refs)` (line 630).

Then three mutually-exclusive branches, resolved in order:

**Branch 1 — `existing_id` set (direct UPDATE on the supplied UUID):**
(rationalization.py:632-687)
- `existing_uuid = uuid.UUID(existing_id)`; on error append
  `f"rat-cap[{idx}].existing_id is not a valid UUID"` and `continue`
  (lines 636-642).
- Fetch owner: `SELECT portfolio_id FROM rationalization_capability WHERE id=$1`
  (lines 643-649). If `None` → append `f"rat-cap[{idx}].existing_id {existing_id}
  not found"`, `continue` (lines 650-655). If `owner != portfolio_uuid` → append
  `f"rat-cap[{idx}].existing_id {existing_id} belongs to another portfolio"`,
  `continue` (lines 656-661) — cross-portfolio poisoning defense.
- Otherwise UPDATE (rationalization.py:662-684):
  ```sql
  UPDATE rationalization_capability
  SET name=$2, description=$3, rationale=$4, evidence_refs=$5::jsonb,
      confidence=$6, wave_id=$7, external_id=$8,
      retired_at=NULL, updated_at=now()
  WHERE id=$1
  ```
  params `($1=existing_uuid, name, description, rationale, evidence_refs_json,
  confidence, wave_uuid, external_id)`. **Note `retired_at=NULL`** — reviving a
  previously-retired row. `rat_cap_id_by_index[idx] = existing_uuid`;
  `out.rat_caps_updated += 1`; `continue` (lines 685-687).

**Branch 2 — no `existing_id` but `external_id` truthy** (rationalization.py:689-771):
- *Adopt-by-name first:* find a live row with the same name but a DIFFERENT
  external_id:
  ```sql
  SELECT id FROM rationalization_capability
  WHERE portfolio_id=$1 AND name=$2 AND retired_at IS NULL
    AND external_id IS DISTINCT FROM $3
  LIMIT 1
  ```
  `$1=portfolio_uuid, $2=name, $3=external_id` (rationalization.py:701-713).
  - If `adopt_id` found → UPDATE that row in place (keeping its UUID):
    ```sql
    UPDATE rationalization_capability
    SET external_id=$2, description=$3, rationale=$4, evidence_refs=$5::jsonb,
        confidence=$6, wave_id=$7, updated_at=now()
    WHERE id=$1
    ```
    params `($1=adopt_id, external_id, description, rationale,
    evidence_refs_json, confidence, wave_uuid)`; then `row = {"id": adopt_id,
    "inserted": False}` (rationalization.py:714-735). **GOTCHA:** this is the fix
    for the 2026-06-15 collision — a NULL→minted-external transition on a kept
    row must UPDATE in place, never blind-INSERT (would trip
    `ix_rat_cap_portfolio_name`).
  - Else INSERT ... ON CONFLICT on the external_id partial unique index:
    ```sql
    INSERT INTO rationalization_capability (
        portfolio_id, wave_id, external_id, name, description, rationale,
        evidence_refs, confidence)
    VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8)
    ON CONFLICT (portfolio_id, external_id)
        WHERE external_id IS NOT NULL AND retired_at IS NULL
    DO UPDATE SET name=EXCLUDED.name, description=EXCLUDED.description,
        rationale=EXCLUDED.rationale, evidence_refs=EXCLUDED.evidence_refs,
        confidence=EXCLUDED.confidence, wave_id=EXCLUDED.wave_id,
        updated_at=now()
    RETURNING id, (xmax = 0) AS inserted
    ```
    params `($1=portfolio_uuid, wave_uuid, external_id, name, description,
    rationale, evidence_refs_json, confidence)` (rationalization.py:740-771).
    **GOTCHA:** `(xmax = 0)` is the Postgres trick to distinguish INSERT
    (`xmax=0`, `inserted=True`) from ON-CONFLICT UPDATE (`inserted=False`).

**Branch 3 — no `existing_id`, no `external_id`** (fallback `(portfolio_id,
name)` natural key; rationalization.py:772-832):
- **GOTCHA:** ON CONFLICT can't be used because the `(portfolio_id, name)` index
  is PARTIAL (`WHERE retired_at IS NULL`), so the code does explicit
  SELECT-then-INSERT-or-UPDATE inside the txn:
  ```sql
  SELECT id FROM rationalization_capability
  WHERE portfolio_id=$1 AND name=$2 AND retired_at IS NULL LIMIT 1
  ```
  (lines 778-788).
  - If none: INSERT with `external_id=NULL`:
    ```sql
    INSERT INTO rationalization_capability (
        portfolio_id, wave_id, external_id, name, description, rationale,
        evidence_refs, confidence)
    VALUES ($1, $2, NULL, $3, $4, $5, $6::jsonb, $7)
    RETURNING id, true AS inserted
    ```
    params `($1=portfolio_uuid, wave_uuid, name, description, rationale,
    evidence_refs_json, confidence)` (lines 790-809).
  - If found: UPDATE (does NOT touch name or external_id):
    ```sql
    UPDATE rationalization_capability
    SET description=$2, rationale=$3, evidence_refs=$4::jsonb,
        confidence=$5, wave_id=$6, updated_at=now()
    WHERE id=$1
    ```
    params `($1=existing_row["id"], description, rationale, evidence_refs_json,
    confidence, wave_uuid)`; `row = {"id": existing_row["id"], "inserted": False}`
    (lines 810-832).

**After the branch** (only reached by Branch 2 & 3 — Branch 1 `continue`d):
`rat_cap_id_by_index[idx] = row["id"]`; if `row.get("inserted")` →
`out.rat_caps_inserted += 1` else `out.rat_caps_updated += 1`
(rationalization.py:834-838).

#### Step 2 — capability_assignments → set FK (rationalization.py:840-891)

`seen_capability_ids: set[uuid.UUID] = set()`.
For each `asn` in `assignments` (skip non-dict):
- `raw_cap_id = asn.get("capability_id")`; `rat_cap_idx =
  asn.get("rationalization_capability_index")`. **If `raw_cap_id` not a str OR
  `rat_cap_idx` not an int → `continue` silently** (rationalization.py:848-851).
- `cap_uuid = uuid.UUID(raw_cap_id)`; on error append
  `f"assignment.capability_id {raw_cap_id!r} is not a valid UUID"`, `continue`
  (lines 852-859).
- If `cap_uuid in seen_capability_ids` → append `f"capability_id {raw_cap_id}
  appears more than once in capability_assignments"`, `continue` (lines
  860-865). Add to `seen_capability_ids`.
- `rat_cap_uuid = rat_cap_id_by_index.get(rat_cap_idx)`. If `None` → append
  `f"assignment references rationalization_capability_index {rat_cap_idx} which
  has no resolved row"`, `continue` (lines 867-874). **GOTCHA:** the index must
  point at a rat-cap that was successfully upserted in Step 1; a plan that
  references an index whose Step-1 branch `continue`d (e.g. bad existing_id)
  will fail here.
- Run:
  ```sql
  UPDATE capability
  SET rationalization_capability_id=$1, updated_at=now()
  WHERE id=$2
  ```
  `$1=rat_cap_uuid, $2=cap_uuid` (lines 875-884). If `result` ends with `" 1"`
  (i.e. asyncpg status `"UPDATE 1"`) → `out.capability_fk_assignments += 1`; else
  append `f"assignment.capability_id {raw_cap_id} not found in capability table"`
  (lines 885-891). **GOTCHA:** the pre-flight (Step F) already rejected
  fabricated ids portfolio-wide, so a not-found here would only occur for a cap
  id in another portfolio — but Step F's existence query is portfolio-scoped, so
  a cross-portfolio id is caught as fabricated first.

#### Step 3 — capability_splits → mint child rows (rationalization.py:893-984)

For each `split` in `splits` (skip non-dict):
- `raw_parent_id = split.get("parent_capability_id")`; `child_assignments =
  split.get("child_assignments") or []`. If `raw_parent_id` not a str →
  `continue` (lines 900-903).
- `parent_uuid = uuid.UUID(raw_parent_id)`; on error append
  `f"split.parent_capability_id {raw_parent_id!r} is not a valid UUID"`,
  `continue` (lines 904-911).
- If `parent_uuid in seen_capability_ids` → append `f"capability_id
  {raw_parent_id} appears in both capability_assignments and
  capability_splits"`, `continue` (lines 912-917). Add to `seen_capability_ids`.
- Fetch parent: `SELECT id, system_id, kind, external_id FROM capability WHERE
  id=$1` (lines 919-926). If `None` → append `f"split.parent_capability_id
  {raw_parent_id} not found in capability table"`, `continue` (lines 927-932).
- Read `parent_system_id`, `parent_kind`, `parent_external_id` (lines 933-935).
- For each `child` in `child_assignments` (skip non-dict):
  - `child_name = str(child.get("name") or "").strip()`;
    `child_desc = str(child.get("description") or "")`;
    `child_rat_cap_idx = child.get("rationalization_capability_index")`.
    **If not `child_name` OR `child_rat_cap_idx` not an int → `continue`**
    (rationalization.py:940-948).
  - `rat_cap_uuid = rat_cap_id_by_index.get(child_rat_cap_idx)`. If `None` →
    append `f"split.child references rationalization_capability_index
    {child_rat_cap_idx} which has no resolved row"`, `continue` (lines 949-959).
  - INSERT a NEW capability row (child):
    ```sql
    INSERT INTO capability (
        system_id, name, description, kind, external_id,
        parent_capability_id, split_at, rationalization_capability_id)
    VALUES ($1, $2, $3, $4, $5, $6, now(), $7)
    ```
    params `($1=parent_system_id, $2=child_name, $3=child_desc,
    $4=parent_kind, $5=parent_external_id, $6=parent_uuid, $7=rat_cap_uuid)`
    (rationalization.py:965-983). `out.capability_splits_created += 1` (line 984).
  - **GOTCHA:** children INHERIT the parent's `system_id`, `kind`, `external_id`
    (system-scope preserved), carry their OWN name/description, get
    `parent_capability_id` = the parent + `split_at=now()`, and the rat-cap FK.
    **The parent row is left completely untouched** — Discovery's record is
    preserved verbatim and the parent keeps NULL `rationalization_capability_id`
    (docstring lines 344-346, 893-896, 960-964).

**Step H — after txn commits + conn closes:** `emit_code_step_complete(exec_id,
columns_written=[f"rat_caps_inserted=...", f"rat_caps_updated=...",
f"capability_fk_assignments=...", f"capability_splits_created=..."])`
(rationalization.py:988-996). Note `rat_caps_retired` is NOT in this list.
Then `logger.info("rat-cap clustering plan persisted", extra={...all counters +
validation_errors...})` (lines 1003-1014) and `return out`.

**Best-effort:** malformed/failed-validation plans return zero-row output with
`validation_errors`, never raise (docstring lines 348-350). **BUT** per-row
problems discovered inside the transaction (bad existing_id, duplicate cap id,
unresolved index, not-found parent) accumulate in `validation_errors` while the
transaction still COMMITS the rows that DID succeed — the txn only rolls back on
an actual raised exception, and these are all `continue`, not raise. **GOTCHA:**
so a partially-bad plan yields a partial write PLUS a populated
`validation_errors` — the wave workflow's post-persist readback treats
`validation_errors` (or zero rows) as the G-RR "did NOT persist — fix + re-run"
signal.

**Idempotency:** designed idempotent across re-runs — deterministic external_id
minting + adopt-by-name + Step-0 latest-run-wins retire keep rat-cap UUIDs
stable and prevent duplicate rows. **GOTCHA:** splits are NOT idempotent — Step 3
INSERTs new child rows unconditionally (no dedupe on parent+name), so re-running
the same plan mints duplicate children each time. Assignments ARE idempotent
(UPDATE by id).

**Retries:** only the two input-UUID `NonRetryableError`s are terminal by
design. A DB exception inside the txn rolls back and propagates to the decorator
for type-name classification (§0).

---

## 3. `persist_rationalization_capability_dispositions`

`@foundry_activity(config=ActivityConfig(enable_observability=True))`
(rationalization.py:1102).

**Signature:** `async def persist_rationalization_capability_dispositions(input:
PersistRationalizationCapabilityDispositionsInput) ->
PersistRationalizationCapabilityDispositionsOutput`.

**Input** (types.py:1618-1638): `portfolio_id: str`, `wave_id: str`,
`disposition_recommendation_json: str = ""`,
`disposition_recommendation_artifact_ref: str = ""`,
`execution_context: StepExecutionContext | None = None`.

**Output** (types.py:1642-1656): `portfolio_id`, `wave_id`,
`rat_caps_disposition_set=0`, `rat_caps_target_service_set=0`,
`rat_caps_not_found=0`, `validation_errors: list[str] = []`. `out` pre-set with
`portfolio_id`+`wave_id` (rationalization.py:1135-1138).

**Disposition constants:**
- `_DISPOSITION_VALUES = frozenset({"Retire", "Retain", "Refactor",
  "Rearchitect", "Replace", "Replatform", "Consolidate"})` (rationalization.py:1360-1363)
  — the seven capability-level 5R outcomes; `"Build"` is intentionally NOT here
  (it is app-level only, rationalization.py:1356-1359).

**Flow (inside outer try; except at 1333-1337 emits FAILED + re-raises):**

**Step A — validate UUIDs:** `portfolio_uuid = uuid.UUID(input.portfolio_id)`
(raise `NonRetryableError` on bad, lines 1141-1146); `uuid.UUID(input.wave_id)`
validated but the value is discarded (raise `NonRetryableError` on bad, lines
1147-1152). **GOTCHA:** wave_id is validated for shape only — it is never used in
any query in this activity (dispositions are matched by rat-cap id/external_id
scoped to portfolio).

**Step B — parse + schema-validate:**
- `payload = _try_parse_json(input.disposition_recommendation_json)`. If `None`:
  append `"disposition recommendation JSON is empty or unparseable"`,
  `logger.info`, emit complete `columns_written=[]`, **`return out`**
  (rationalization.py:1154-1171).
- `validation_errors = _validate_disposition_recommendation(payload)`. If
  non-empty: `out.validation_errors = validation_errors`, `logger.info`, emit
  complete, **`return out`** (lines 1173-1186).

**Step C — pull entries:**
`entries = payload.get("rationalization_capability_dispositions") or []`
(rationalization.py:1188-1190).

Disposition-recommendation JSON entry shape (schema `$defs/rat-cap-disposition`,
lines 63-141; consumed fields):
`{rationalization_capability_id?, rationalization_capability_external_id?,
primary_disposition, target_service_external_id?, ...}`.

**Step D — connection + transaction** `conn = await asyncpg.connect(_db_url())`
(line 1192); `async with conn.transaction():` (line 1194); `try/finally` closes
conn (lines 1319-1320).

`seen_ids: set[uuid.UUID] = set()`. For `idx, entry in enumerate(entries)` (skip
non-dict, line 1197):

1. **primary_disposition guard:** `primary = entry.get("primary_disposition")`.
   If not a str OR not in `_DISPOSITION_VALUES` → append
   `f"entry[{idx}].primary_disposition {primary!r} is not a valid 5R outcome"`,
   `continue` (rationalization.py:1199-1208).
2. **Resolve target row.** `raw_id = entry.get("rationalization_capability_id")`;
   `raw_external_id = entry.get("rationalization_capability_external_id")`;
   `target_uuid = None`.
   - **By id first:** if `raw_id` is a non-blank str:
     - `target_uuid = uuid.UUID(raw_id.strip())`; on error append
       `f"entry[{idx}].rationalization_capability_id {raw_id!r} is not a valid
       UUID"`, `continue` (lines 1216-1224).
     - `owner = SELECT portfolio_id FROM rationalization_capability WHERE id=$1
       AND retired_at IS NULL` (lines 1225-1232). If `owner is None` →
       `out.rat_caps_not_found += 1`; `target_uuid = None` (fall through to
       external_id fallback) (lines 1233-1235). If `owner != portfolio_uuid` →
       append `f"entry[{idx}].rationalization_capability_id {raw_id} belongs to
       another portfolio"`, `continue` (lines 1236-1241). **GOTCHA:** a retired
       row's id resolves to `owner=None` (the `retired_at IS NULL` filter),
       counting as not-found and triggering the external fallback.
   - **By external_id fallback:** if `target_uuid is None` AND `raw_external_id`
     is a non-blank str:
     ```sql
     SELECT id FROM rationalization_capability
     WHERE portfolio_id=$1 AND external_id=$2 AND retired_at IS NULL LIMIT 1
     ```
     `$1=portfolio_uuid, $2=raw_external_id.strip()` (lines 1249-1260). If still
     `None` → `out.rat_caps_not_found += 1` (lines 1261-1262).
     **GOTCHA:** if the id path already counted a not-found and the external path
     also fails, `rat_caps_not_found` is incremented **twice** for the same
     entry (once at line 1234, once at line 1262).
   - If `target_uuid is None` after both → `continue` (already counted; lines
     1264-1267).
3. **Duplicate guard:** if `target_uuid in seen_ids` → append
   `f"rationalization_capability_id {target_uuid} appears more than once in
   rationalization_capability_dispositions"`, `continue` (lines 1269-1275). Add
   to `seen_ids`.
4. **target_service:** `target_service = entry.get("target_service_external_id")`;
   `= target_service.strip() or None` if str else `None` (lines 1278-1286).
5. **UPDATE** (rationalization.py:1288-1318):
   - If `target_service is not None`:
     ```sql
     UPDATE rationalization_capability
     SET disposition=$2, target_service_external_id=$3, updated_at=now()
     WHERE id=$1
     ```
     `$1=target_uuid, $2=primary, $3=target_service`;
     `out.rat_caps_target_service_set += 1` (lines 1293-1306).
   - Else:
     ```sql
     UPDATE rationalization_capability
     SET disposition=$2, updated_at=now()
     WHERE id=$1
     ```
     `$1=target_uuid, $2=primary` (lines 1308-1317). **GOTCHA:** a NULL
     target_service leaves the column UNTOUCHED (not set to NULL) — Retire/Retain
     always have NULL, and capability-consolidation-advisor at G-DA may set it
     later; don't clobber its work (docstring lines 1122-1126; code 1288-1292).
   - Always: `out.rat_caps_disposition_set += 1` (line 1318).

**Step E — after txn:** `emit_code_step_complete(exec_id,
columns_written=[f"rat_caps_disposition_set=...",
f"rat_caps_target_service_set=...", f"rat_caps_not_found=..."])`
(rationalization.py:1322-1332); `logger.info("rat-cap dispositions persisted",
extra={...})` (lines 1339-1349); `return out`.

**GOTCHA (disposition validated against `_DISPOSITION_VALUES`, DB has its own
CHECK):** the persisted `disposition` string must also satisfy migration 052's
`rationalization_capability_disposition_chk` (same 7 values; migration
052:179-184). The Python guard and DB CHECK are in sync, so a valid
`primary_disposition` never trips the CHECK.

**Idempotency:** fully idempotent — every write is an UPDATE keyed by resolved
UUID; re-running writes the same values (and target_service only when present).

**Retries:** two input-UUID `NonRetryableError`s terminal; other exceptions →
decorator classification. Best-effort per docstring lines 1128-1129.

---

## 4. `persist_rationalization_side_effects`

`@foundry_activity(config=ActivityConfig(enable_observability=True))`
(rationalization.py:1470). Runs **once per app** in the wave after G-DA approves.

**Signature:** `async def persist_rationalization_side_effects(input:
PersistRationalizationSideEffectsInput) -> PersistRationalizationSideEffectsResult`.

**Input** (types.py:1704-1721): `app_id: str`, `classification_json: str = ""`,
`portfolio_score_json: str = ""`, `disposition_recommendation_json: str = ""`,
`disposition_rationale_ref: str = ""`, `tier_1_approved: bool = False`,
`execution_context: StepExecutionContext | None = None`.

**Output** (types.py:1725-1736): `app_id`, `risk_tier=""`,
`risk_tier_source=""`, `disposition=""`, `disposition_source=""`,
`portfolio_score_persisted=False`.

**Flow (inside outer try; except 1569-1573 emits FAILED + re-raises):**
1. `app_uuid = uuid.UUID(input.app_id)`; on error raise
   `NonRetryableError(f"Invalid app_id: {input.app_id!r}")` (rationalization.py:1487-1492).
2. Parse the three inputs best-effort with `_try_parse_json`:
   `classification`, `portfolio_score`, `recommendation`
   (rationalization.py:1494-1498).
3. Build `projections: dict[str, Any]` by `.update()`-ing three extractors
   (rationalization.py:1500-1514):
   - `_extract_classification_side_effects(classification,
     tier_1_approved=input.tier_1_approved)`
   - `_extract_portfolio_score_side_effects(portfolio_score)`
   - `_extract_disposition_side_effects(recommendation,
     rationale_ref=input.disposition_rationale_ref)`
4. `compliance_metadata = _extract_rationalization_compliance_metadata(
   classification, recommendation)` (rationalization.py:1520-1522).
5. **If `not projections and not compliance_metadata`:**
   `logger.info("... nothing extractable")`, emit complete `columns_written=[]`,
   **return `PersistRationalizationSideEffectsResult(app_id=input.app_id)`**
   (all-default) (rationalization.py:1524-1532). No DB connection opened.
6. Else `conn = await asyncpg.connect(_db_url())` (line 1534), `try/finally`
   closes (lines 1544-1545):
   - If `projections`: `sql, params = _build_update_sql(projections)`;
     `params.append(app_uuid)`; `await conn.execute(sql, *params)`
     (rationalization.py:1536-1539). **GOTCHA:** `_build_update_sql` appends the
     `updated_at` param BEFORE this activity appends `app_uuid`, so `app_uuid` is
     the final positional param matching the trailing `WHERE id=$N` — order
     is load-bearing (_shared.py:527-538).
   - If `compliance_metadata`: `await _merge_application_metadata(conn, app_uuid,
     "compliance", compliance_metadata)` (rationalization.py:1540-1542).
   - **GOTCHA:** these are TWO separate `conn.execute`s NOT wrapped in a
     transaction — the column UPDATE and the metadata JSONB merge can partially
     apply if the second fails.
7. `columns_written = sorted(projections.keys())`; append `"metadata.compliance"`
   when `compliance_metadata` truthy (rationalization.py:1547-1549).
   `logger.info("rationalization side-effects persisted", extra={app_id,
   columns_written})` (lines 1551-1557); emit complete with `columns_written`
   (lines 1558-1560).
8. Return `PersistRationalizationSideEffectsResult(app_id, risk_tier,
   risk_tier_source, disposition, disposition_source,
   portfolio_score_persisted="portfolio_score" in projections)` — each string
   field is `str(projections.get(<key>, ""))` (rationalization.py:1561-1568).

### `_build_update_sql(projections)` (_shared.py:506-539)

- Iterates `_SIDE_EFFECT_COLUMNS` (the fixed ordered tuple, _shared.py:70-153) —
  **only** columns present in `projections` are emitted, in that tuple's order.
- For each present column: if in `_JSONB_COLUMNS` (_shared.py:156-171; includes
  `portfolio_score`) → `value = json.dumps(value)`. Append `f"{column} = ${idx}"`
  + the value; increment `idx`.
- Always appends `updated_at = ${idx}` with `datetime.now(timezone.utc)`.
- Final `WHERE id = ${where_idx}` — the app_id param is NOT added here (the
  caller appends it). Returns `(sql, params)`.
- **GOTCHA:** for Rationalization the only possible projection columns are
  `risk_tier`, `risk_tier_source`, `portfolio_score` (JSONB), `disposition`,
  `disposition_source`, `disposition_rationale_ref` — driven by the three
  extractors below.

### `_extract_classification_side_effects(classification, *, tier_1_approved)` (_shared? no — rationalization.py:1379-1414)

- Returns `{}` if `classification` not a dict.
- `risk = classification.get("risk_tier")`; coerce to int
  (`int(risk) if risk is not None else None`), catching `TypeError`/`ValueError`
  → `risk_int=None` (accepts int OR string shapes; lines 1404-1407).
- If `risk_int in (1,2,3)`: set `out["risk_tier"] = str(risk_int)`; and
  `out["risk_tier_source"] = "confirmed"` **iff `risk_int == 1 and
  tier_1_approved`**, else `"auto"` (rationalization.py:1408-1413).
- **GOTCHA:** archetype + complexity_tier are deliberately NOT written here —
  the `classify-application` skill was narrowed to only risk-tier; Discovery owns
  those (docstring 1388-1391).

### `_extract_portfolio_score_side_effects(score)` (rationalization.py:1417-1433)

- Returns `{}` unless `score` is a dict AND `score.get("scores")` is a non-empty
  dict (lines 1427-1431).
- Otherwise returns `{"portfolio_score": score}` — the ENTIRE payload is stored
  as-is (persisted as JSONB; partial payloads tolerated downstream; line 1433).

### `_extract_disposition_side_effects(recommendation, *, rationale_ref)` (rationalization.py:1436-1467)

- Returns `{}` if `recommendation` not a dict.
- `disposition = recommendation.get("recommended_disposition") or
  recommendation.get("disposition")` (accepts either key; lines 1454-1455).
- **If not a str OR not in `_APP_DISPOSITION_VALUES` → return `{}`** (lines
  1456-1460). `_APP_DISPOSITION_VALUES = _DISPOSITION_VALUES | {"Build"}` (the 8
  app-level dispositions; rationalization.py:1373). **GOTCHA:** this is the
  app-level set — `"Build"` IS accepted here (unlike the capability-level
  disposition persist in §3). Before `"Build"` was added a Build-dispositioned
  app silently lost its disposition at G-DA persist (rationalization.py:1365-1373).
- Returns `{"disposition": disposition, "disposition_source": "auto"}` plus
  `"disposition_rationale_ref": rationale_ref` when `rationale_ref` truthy
  (lines 1461-1467). Source is always `"auto"` — override/confirmed wiring not
  yet done (docstring 1444-1451).

### `_extract_rationalization_compliance_metadata(classification, recommendation)` (_shared.py:246-296)

Builds `block = {"source_line": "Rationalization"}`.
- If `classification` is a dict: `tier = classification.get("risk_tier") or
  classification.get("tier")`; if `tier` is a str in `{"1","2","3"}` →
  `block["risk_tier"] = tier`, and if `tier == "1"` → `block["status"] =
  "needs-review"` (_shared.py:266-273).
- If `recommendation` is a dict: `disposition =
  recommendation.get("recommended_disposition") or ""`; if in
  `{"Replace","Consolidate","Rearchitect","Build"}` → `block["cato_state"] =
  "transition"`; elif `== "Retain"` → `block["cato_state"] = "inheriting"`
  (_shared.py:275-289).
- **If `block` ended up as ONLY `{"source_line": ...}` (no real signal) → return
  `{}`** so it doesn't overwrite a richer Discovery block (_shared.py:291-296).

### `_merge_application_metadata(conn, app_uuid, namespace, payload)` (_shared.py:453-503)

- No-op when `payload` empty (line 483-484).
- `payload_with_meta = dict(payload)`;
  `payload_with_meta.setdefault("last_assessed",
  datetime.now(timezone.utc).isoformat())` (lines 485-488) — adds a timestamp
  only if the payload doesn't already carry one.
- `namespace_block = json.dumps({namespace: payload_with_meta})` (line 489).
- UPDATE:
  ```sql
  UPDATE application
     SET metadata = COALESCE(metadata, '{}'::jsonb) || $1::jsonb,
         updated_at = $2
   WHERE id = $3::uuid
  ```
  `$1=namespace_block, $2=datetime.now(timezone.utc), $3=app_uuid`
  (_shared.py:493-503). **GOTCHA:** the JSONB `||` merge REPLACES the entire
  `compliance` namespace block (not a deep merge) — callers must pass the full
  namespace shape or lose sibling keys. Other top-level namespaces (e.g.
  `security`) are preserved. `COALESCE(metadata, '{}')` defends pre-051 NULL rows.

**Idempotency:** the column UPDATE is idempotent (same projections → same
values, `updated_at` refreshed). The metadata merge is idempotent apart from
refreshing nested `last_assessed` (docstring _shared.py:472-473). **GOTCHA:** not
atomic across the two writes (no txn wrapper here) — see step 6 gotcha.

**Retries / best-effort:** the only terminal error is the `app_id`
`NonRetryableError`. All other failures are observability-only and the wave
workflow continues even if projection raises for one app (docstring 1479-1481) —
though a raise still propagates through the decorator (wrapped) to the workflow,
which the wave loop is expected to swallow per-app.

---

## Cross-cutting GOTCHAs

- **No transactions in load or side-effects; explicit txns in the two rat-cap
  persist activities.** `load_*` (read-only) and `persist_rationalization_side_effects`
  (two independent writes) run without `conn.transaction()`; only
  `persist_rationalization_capabilities` and
  `persist_rationalization_capability_dispositions` wrap their mutations in
  `async with conn.transaction()`.
- **Schema caches are module-global and never invalidated** — swapping the schema
  file on disk after first successful load has no effect until worker restart
  (rationalization.py:82-105, 1053-1070).
- **`validation_errors` is set two different ways:** replaced wholesale on
  schema failure (`out.validation_errors = validation_errors`), but appended-to
  for per-row problems (`out.validation_errors.append(...)`). A schema-valid plan
  with per-row issues still commits partial work.
- **`rat_caps_retired` is tracked in the output but omitted from the
  `emit_code_step_complete` columns_written list** in
  `persist_rationalization_capabilities` (rationalization.py:988-996) — it only
  appears in the final `logger.info`.
- **Migration 052 authority:** table DDL, the three partial unique indexes
  (`ix_rat_cap_portfolio_external_id` WHERE `external_id IS NOT NULL AND
  retired_at IS NULL`; `ix_rat_cap_portfolio_name` WHERE `retired_at IS NULL`),
  the `disposition` CHECK (7 values), `confidence` CHECK (0..1), and the
  `capability.rationalization_capability_id` FK `ON DELETE SET NULL` /
  `parent_capability_id` FK `ON DELETE CASCADE` all live in
  `db/alembic/versions/052_rationalization_capability.py` — the persist SQL above
  depends on every one of these.
