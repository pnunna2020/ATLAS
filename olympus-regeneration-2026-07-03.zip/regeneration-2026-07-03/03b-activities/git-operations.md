# Activity group: `git_operations.py`

**Source of truth:** `temporal/olympus_workflows/activities/git_operations.py` (670 lines).

This group holds **7 `@foundry_activity`-decorated activities** plus 4 module-private
helpers. All git *logic* is delegated to `GitService`
(`olympus-api/src/services/git_service.py`, imported at runtime as `src.git_service` —
see [§0.3](#03-runtime-import-of-gitservice)). The activities themselves are thin: they
(a) emit a `step_execution` telemetry row at start, (b) call one `GitService` method,
(c) emit a terminal `step_execution` row, (d) funnel every exception through
`_reraise_git_error` to re-classify transient TLS/network faults as retryable, and
(e) map the `GitService` result dataclass into a `types.py` result dataclass.

> **There are NO `persist_*` activities in this group.** The only DB writes are the
> best-effort `step_execution` rows via `emit_execution_record` / `update_execution_record`
> ([§4](#4-step_execution-persistence-the-only-db-writes-in-this-group)). The
> `application_lineage` rows hinted at by `ProvisionTargetRepoInput.source_app_ids` /
> `ProvisionTargetRepoResult.lineage_rows_inserted` (`types.py:875-903`) are **declared but
> NOT written** by `provision_target_repo` — the activity body never touches them and always
> returns the default `lineage_rows_inserted=0` (`git_operations.py:664-669`). GOTCHA below.

The 7 activities:

| Activity | GitService method | Result type | Call-site retry policy |
|---|---|---|---|
| `read_artifact` | `read_file` | `ReadArtifactResult` | `transient` |
| `write_artifact` | `commit_file` | `WriteArtifactResult` | `transient` |
| `write_artifacts_batch` | `commit_files` | `WriteArtifactsBatchResult` | `transient` |
| `create_pr` | `create_pull_request` | `CreatePRResult` | `transient` |
| `merge_pr` | `merge_pull_request` | `MergePRResult` | `transient` |
| `reconcile_and_merge_pr` | `reconcile_and_merge` | `MergePRResult` | `git_merge` |
| `provision_target_repo` | `GitService.provision_repository` (staticmethod) | `ProvisionTargetRepoResult` | `transient` |

Call-site retry policies observed in `workflows/base.py`: `write_artifacts_batch`,
`create_pr` → `RETRY_POLICIES["transient"]` (`base.py:834,864,887,919`); `reconcile_and_merge_pr`
→ `RETRY_POLICIES["git_merge"]` (`base.py:1217`). Activity docstrings claim `transient`
(HTTP) for the rest.

---

## 0. Cross-cutting mechanics

### 0.1 What `@foundry_activity` adds over `activity.defn`

`git_operations.py` decorates all 7 with `@foundry_activity(config=ActivityConfig(enable_observability=True))`
(`git_operations.py:237,286,337,392,446,493,612`). The decorator
(`temporal/olympus_workflows/temporal_base/activities.py:79-150`) wraps
`temporalio.activity.defn` and adds, verbatim:

1. **Observability** (`activities.py:105-131`) — stdlib `logging` (`logger = logging.getLogger("olympus_workflows.temporal_base.activities")`, `activities.py:38`):
   - on entry: `logger.info("Activity %s starting", activity_name, extra={"inputs": args if log_inputs else None})`. With default config `log_inputs=False`, so `inputs=None`.
   - on success: `logger.info("Activity %s completed", ..., extra={"outputs": result if log_outputs else None})`. `log_outputs=False` → `outputs=None`.
   - on exception: `logger.error("Activity %s failed: %s", activity_name, error, extra={"error": str(error)})`.
   - `activity_name = name or func.__name__` (`activities.py:103`); Temporal replay keys on this — **the activity registration name equals the Python function name** (no `name=` override at any of the 7 defs).

2. **Error wrapping** (`activities.py:133-146`) — after the log:
   - if the escaping exception is already a `WorkflowError` **or** `temporalio` `ApplicationError` → `raise` unchanged (`activities.py:135-136`).
   - else if `_is_retryable_error(error)` is True → wrap in `RetryableError(f"Retryable error in {activity_name}: {error}")` (`non_retryable=False`).
   - else → wrap in `NonRetryableError(f"Non-retryable error in {activity_name}: {error}")` (`non_retryable=True`).
   - `_is_retryable_error` (`activities.py:56-76`) classifies **by the lowercased `str(type(error))` string**, matching any of: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. This is a TYPE-NAME string match, distinct from `errors.is_retryable_error` (instance inspection).

3. **No heartbeat / timeouts set here.** `ActivityConfig` (`activities.py:41-53`) *can* carry
   `heartbeat_timeout` / `*_timeout` / `retry_policy`, but the git group passes **only**
   `enable_observability=True`; all timeout + retry-policy config is applied at the workflow
   `execute_activity` call site, not baked into the decorator. So `@foundry_activity` here adds
   observability + error-wrapping only — no heartbeat.

**GOTCHA (interaction with `_reraise_git_error`):** the whole reason `_reraise_git_error` exists
is that `@foundry_activity`'s classifier keys on the TYPE-NAME string. A `requests.exceptions.SSLError`
has type name `sslerror` — matches none of the patterns → wrapped `NonRetryableError` → a single
transient TLS blip permanently fails the workflow. `_reraise_git_error` pre-empts this by raising
its own `RetryableError` for known-transient types, which the decorator passes through untouched
(step 2, first branch). See [§0.4](#04-_reraise_git_error--transient-fault-reclassification).

### 0.2 GitService config from env (`_git_service_config`, `git_operations.py:141-165`)

`_git_service_config()` returns a dict from env:
- `token` ← `GITHUB_TOKEN` (default `""`)
- `repo` ← `GITHUB_REPO` (default `""`)
- `base_url` ← `GITHUB_BASE_URL` (default `"https://api.github.com"`)

`_build_git_service(repo_override="")` (`git_operations.py:150-165`): imports `from src.git_service import GitService`
**at call time** (deferred because PyGithub is only present in the worker container,
`git_operations.py:154-156`), then constructs
`GitService(GitServiceConfig(token=cfg["token"], repo=repo_override or cfg["repo"], base_url=cfg["base_url"]))`.
So **`input.repo` (or `input.repo_slug`) overrides `GITHUB_REPO`** for every activity — the
per-portfolio/per-target repo is driven by the activity input, not the env default.

### 0.3 Runtime import of GitService

`GitService` lives at `olympus-api/src/services/git_service.py` but is imported as
`src.git_service` (`git_operations.py:156`, `git_operations.py:639`). The worker container
copies it onto the path at Docker build time (`git_types.py:1-6` docstring: "The `GitService`
class itself lives in olympus-api ... and is copied into the worker container at Docker build
time"). The pure-stdlib contract types (`GitServiceConfig`, `PRResult`, `FileReadResult`,
`CommitResult`, `GitServiceError`, `BRANCH_PATTERN`) live in `olympus_contracts` and are importable
anywhere (`olympus-contracts/olympus_contracts/git_types.py`).

### 0.4 `_reraise_git_error` — transient-fault reclassification (`git_operations.py:168-234`)

Every activity's `except Exception as exc:` block calls `_reraise_git_error(exc)` **after**
emitting the FAILED telemetry row. Logic:

1. Lazy `import requests`. Set `transient = True` if `exc` is an instance of any of:
   - `requests.exceptions.ConnectionError` (covers `SSLError`, `ProxyError`, bare drops), `git_operations.py:199-207`
   - `requests.exceptions.Timeout`
   - `requests.exceptions.ChunkedEncodingError`
   - `requests.exceptions.RetryError` (`git_operations.py:221-222`) — urllib3 Retry budget exhausted on 503/502/429/resets; type name `retryerror`, a direct `RequestException`/`OSError` but NOT a `ConnectionError` subclass, so it slips past both the isinstance checks above AND the foundry string classifier.
   - `except ImportError: pass` (`git_operations.py:223-224`) if requests absent.
2. Also set `transient = True` if `exc` is a builtin `ConnectionError` or `TimeoutError` (`git_operations.py:227-228`).
3. If `transient`: `raise RetryableError(f"transient git network error (forcing retry): {exc}") from exc` (`git_operations.py:230-233`). `RetryableError` (from `temporal_base.errors`) is a `WorkflowError` with `non_retryable=False`; `@foundry_activity` passes it through untouched.
4. Else: `raise exc` — re-raises the ORIGINAL exception unchanged (so a `GitServiceError`/`MergeConflict`/etc. reaches the decorator's classifier, which re-wraps by type-name string — but `GitServiceError` is not an `ApplicationError`, so it hits the decorator's `NonRetryableError` branch unless its type name matches a pattern).

**GOTCHA — control never returns after `_reraise_git_error`.** Every activity calls
`_reraise_git_error(exc)` which ALWAYS raises. So the lines after the `except` block that read
`result.*` (e.g. `read_artifact` `git_operations.py:272-283`) execute only on the success path;
the `except` never "falls through" despite `_reraise_git_error` being typed `-> None`. Static
analyzers may flag `result` as possibly-unbound — it is not, at runtime, because the except
always raises.

### 0.5 `_emit_git_start` / `_emit_git_complete` (telemetry, `git_operations.py:54-138`)

See [§4](#4-step_execution-persistence-the-only-db-writes-in-this-group) for the full DB
transformation. Both are best-effort no-ops when `execution_context is None` (`git_operations.py:67-68`,
`git_operations.py:117-118`).

---

## 1. `read_artifact` (`git_operations.py:237-283`)

**Signature:** `async def read_artifact(input: ReadArtifactInput) -> ReadArtifactResult`

**Input `ReadArtifactInput`** (`types.py:563-571`):
```
repo: str
branch: str
path: str
commit_sha: str = ""
execution_context: StepExecutionContext | None = None
```

**Output `ReadArtifactResult`** (`types.py:574-580`): `content: str`, `commit_sha: str`, `path: str`.

**Body:**
1. `execution_id = await _emit_git_start(input.execution_context, repo=input.repo, operation="read_artifact", branch=input.branch, paths=[input.path])` (`git_operations.py:249-255`).
2. `try:` build `GitService(repo_override=input.repo)`; call `svc.read_file(path=input.path, branch=input.branch, commit_sha=input.commit_sha)` (`git_operations.py:257-262`).
3. `except Exception as exc:` → `_emit_git_complete(execution_id, repo=input.repo, branch=input.branch, status=FAILED, error=str(exc))` then `_reraise_git_error(exc)` (`git_operations.py:263-271`).
4. Success: `_emit_git_complete(execution_id, repo=input.repo, branch=input.branch, commit_sha=result.commit_sha, output_paths=[result.path])` (`git_operations.py:272-278`).
5. Return `ReadArtifactResult(content=result.content, commit_sha=result.commit_sha, path=result.path)`.

**`GitService.read_file(path, branch="main", commit_sha="")`** (`git_service.py:317-347`):
- `ref = commit_sha if commit_sha else branch` (`git_service.py:328`).
- `contents = self._repo.get_contents(path, ref=ref)`; on `GithubException` → `GitServiceError(f"File '{path}' not found on ref '{ref}': {exc.data}")` (`git_service.py:329-334`).
- if `isinstance(contents, list)` (path is a directory) → `GitServiceError(f"Path '{path}' is a directory, not a file")` (`git_service.py:336-337`).
- `decoded = contents.decoded_content.decode("utf-8")` (`git_service.py:339`).
- if `commit_sha`: `ref_sha = commit_sha`; else re-fetch `ref_sha = self._repo.get_branch(branch).commit.sha` (`git_service.py:341-345`) — an EXTRA GitHub round-trip to resolve HEAD when no explicit SHA.
- Returns `FileReadResult(content=decoded, commit_sha=ref_sha, path=path)`.

**Idempotency:** pure read; safe to retry. **Retries:** `transient` HTTP policy (docstring `git_operations.py:247`).

---

## 2. `write_artifact` (`git_operations.py:286-334`)

**Signature:** `async def write_artifact(input: WriteArtifactInput) -> WriteArtifactResult`

**Input `WriteArtifactInput`** (`types.py:645-654`): `repo`, `branch`, `path`, `content`, `commit_message`, `execution_context=None`.
**Output `WriteArtifactResult`** (`types.py:657-663`): `commit_sha`, `path`, `branch`.

**Body:** emit start (`operation="write_artifact"`, `paths=[input.path]`); `svc.commit_file(branch, path, content, commit_message)`; on except → FAILED emit + `_reraise_git_error`; on success → `_emit_git_complete(..., branch=result.branch, commit_sha=result.commit_sha, output_paths=[result.path])`; return `WriteArtifactResult(commit_sha=result.commit_sha, path=result.path, branch=result.branch)` (`git_operations.py:299-334`).

**`GitService.commit_file(branch, path, content, commit_message)`** (`git_service.py:213-253`):
1. If `branch != "main"` → `self._ensure_branch(branch)` (create from `main` if missing).
2. `try:` `existing = self._repo.get_contents(path, ref=branch)`:
   - if `isinstance(existing, list)` → `GitServiceError("Path ... is a directory, not a file")` (`git_service.py:231-232`).
   - else `result = self._repo.update_file(path, message=commit_message, content=content, sha=existing.sha, branch=branch)` (`git_service.py:233-239`).
3. `except GithubException as exc:`:
   - if `exc.status == 404` (file doesn't exist) → `result = self._repo.create_file(path, message=commit_message, content=content, branch=branch)` (`git_service.py:241-247`).
   - else → `GitServiceError(f"Failed to commit file: {exc.data}")` (`git_service.py:248-249`).
4. `commit_sha = result["commit"].sha`; return `CommitResult(commit_sha, path, branch)`.

**`_ensure_branch(branch, base_branch="main")`** (`git_service.py:188-211`):
- `get_git_ref(f"heads/{branch}")` → return (exists). On `GithubException` where `status != 404` → re-raise raw (`git_service.py:198-200`).
- else create: `base_ref = get_git_ref("heads/main")`; `create_git_ref(f"refs/heads/{branch}", base_ref.object.sha)`. On `GithubException status==422` → **return silently** (race: branch created between check and create, `git_service.py:207-208`); other statuses → `GitServiceError(f"Failed to create branch '{branch}' from '{base_branch}': {exc.data}")`.

**Idempotency:** docstring (`git_operations.py:296-297`) declares "All writes are idempotent -- safe to retry." A retry re-runs the get/update-or-create dance; committing identical content produces a new commit SHA but no content divergence. **Retries:** `transient`.

---

## 3. `write_artifacts_batch` (`git_operations.py:337-389`)

**Signature:** `async def write_artifacts_batch(input: WriteArtifactsBatchInput) -> WriteArtifactsBatchResult`

**Input `WriteArtifactsBatchInput`** (`types.py:708-721`): `repo`, `branch`, `files: list[tuple[str, str]]` (`(path, content)`), `commit_message`, `execution_context=None`.
**Output `WriteArtifactsBatchResult`** (`types.py:724-730`): `commit_sha`, `paths: list[str]`, `branch`.

**Body:**
1. `paths = [p for p, _ in input.files]` (`git_operations.py:354`) — extract the path list up front.
2. emit start (`operation="write_artifacts_batch"`, `paths=paths`).
3. `svc.commit_files(branch=input.branch, files=input.files, commit_message=input.commit_message)`.
4. except → FAILED emit + `_reraise_git_error`. (This is the exact activity that killed live Deployment/Build runs on a TLS/503 blip — see `_reraise_git_error` docstring `git_operations.py:180-181,217-219`.)
5. success → `_emit_git_complete(..., branch=result.branch, commit_sha=result.commit_sha, output_paths=paths)`; return `WriteArtifactsBatchResult(commit_sha=result.commit_sha, paths=paths, branch=result.branch)`.

**`GitService.commit_files(branch, files, commit_message)`** — the ONE-COMMIT-FOR-N-FILES dance (`git_service.py:255-315`):
1. if `not files` → `GitServiceError("commit_files requires at least one file")` (`git_service.py:274-275`).
2. if `branch != "main"` → `_ensure_branch(branch)`.
3. `try:` (all wrapped, on `GithubException` → `GitServiceError(f"Batch commit on '{branch}' failed: {exc.data}")`, `git_service.py:303-306`):
   - `base_ref = get_git_ref(f"heads/{branch}")`; `base_commit = get_git_commit(base_ref.object.sha)`; `base_tree = base_commit.tree`.
   - `from github.InputGitTreeElement import InputGitTreeElement` (inline import, `git_service.py:285`).
   - for each `(path, content)`: `blob = create_git_blob(content, "utf-8")`; append `InputGitTreeElement(path=path, mode="100644", type="blob", sha=blob.sha)` (`git_service.py:288-294`). **All files are mode `100644` (regular file); no executable/symlink modes.**
   - `new_tree = create_git_tree(elements, base_tree=base_tree)`.
   - `new_commit = create_git_commit(message=commit_message, tree=new_tree, parents=[base_commit])`.
   - `base_ref.edit(new_commit.sha)` — advance the branch ref (`git_service.py:302`).
4. `first_path = files[0][0]`; return `CommitResult(commit_sha=new_commit.sha, path=first_path, branch=branch)`.
   > **Note:** `CommitResult.path` is only the FIRST file's path (for log symmetry), but the activity returns the full `paths` list independently (from step 1), so no path is lost.

**GOTCHA — call count is ~3+N, not fixed 3-4 as the docstring claims.** One `create_git_blob`
call **per file** (`git_service.py:289`) plus `get_git_ref` + `get_git_commit` + `create_git_tree`
+ `create_git_commit` + `ref.edit` (+ possible `_ensure_branch` calls). Still far cheaper than the
Contents-API path's N+1 commits, but it is O(N) HTTP calls, not O(1).

**Idempotency:** retry re-does blob/tree/commit and advances the ref again (`git_operations.py:352-353` docstring). New commit SHA each time; content converges. **Retries:** `transient`.

---

## 4. `create_pr` (`git_operations.py:392-443`)

**Signature:** `async def create_pr(input: CreatePRInput) -> CreatePRResult`

**Input `CreatePRInput`** (`types.py:800-811`): `repo`, `source_branch`, `target_branch`, `title`, `body`, `reviewers: list[str]=[]`, `labels: list[str]=[]`, `execution_context=None`.
**Output `CreatePRResult`** (`types.py:814-821`): `pr_number: int`, `pr_url: str`, `source_branch`, `target_branch`.

**Body:** emit start (`operation="create_pr"`, `branch=input.source_branch`, no paths); call
`svc.create_pull_request(source_branch, target_branch, title, body, reviewers=input.reviewers or None, labels=input.labels or None)` (`git_operations.py:414-421`) — **empty lists become `None`** so GitService's `if reviewers:` / `if labels:` guards short-circuit; on except → FAILED emit + `_reraise_git_error`; on success → `_emit_git_complete(..., branch=result.source_branch, pr_number=result.pr_number, pr_url=result.pr_url)`; return `CreatePRResult(pr_number, pr_url, source_branch, target_branch)` (all from `result`).

**`GitService.create_pull_request(source_branch, target_branch, title, body, reviewers=None, labels=None)`** (`git_service.py:353-426`) — **idempotent on the head→base pair:**
1. `try:` `pr = self._repo.create_pull(title=title, body=body, head=source_branch, base=target_branch)`; `created = True` (`git_service.py:373-380`).
2. `except GithubException as exc:`:
   - if `_is_pr_already_exists(exc)` (`git_service.py:38-58`: `exc.status == 422` AND some `exc.data["errors"][].message` contains case-insensitive `"already exists"`):
     - `existing = self._find_open_pr(source_branch, target_branch)` (`git_service.py:428-449`: `get_pulls(state="open", head=f"{owner.login}:{source_branch}", base=target_branch)`, returns the first PR or `None`; `GithubException` → `None`).
     - if `existing is None` → `GitServiceError(f"Failed to create PR: {exc.data}")` (`git_service.py:384-387`).
     - else refresh: `try: existing.edit(title=title, body=body)` — on `GithubException` just `logger.warning` (`git_service.py:390-396`). `pr = existing`; `created = False`.
   - else → `GitServiceError(f"Failed to create PR: {exc.data}")` (`git_service.py:399-400`).
3. if `reviewers`: `try: pr.create_review_request(reviewers=reviewers)` — on `GithubException` → `logger.warning` (NON-fatal, `git_service.py:402-406`).
4. if `labels`: `try: pr.set_labels(*labels)` — on `GithubException` → `logger.warning` (NON-fatal, `git_service.py:408-412`).
5. Return `PRResult(pr_number=pr.number, pr_url=pr.html_url, source_branch=source_branch, target_branch=target_branch)`.

**GOTCHA — reviewer/label failures are swallowed.** If reviewer assignment or labeling fails,
the PR is still created and returned successfully; only a warning log is emitted. A PR can come
back with no reviewers/labels even though the caller requested them.

**Idempotency:** re-running against an existing open PR reuses it and refreshes title/body
(`created=False`), so the UI Retry path does not error. **Retries:** `transient`.

---

## 5. `merge_pr` (`git_operations.py:446-490`)

**Signature:** `async def merge_pr(input: MergePRInput) -> MergePRResult`

**Input `MergePRInput`** (`types.py:824-831`): `repo`, `pr_number: int`, `merge_method: str = "merge"` (one of `merge|squash|rebase`), `execution_context=None`.
**Output `MergePRResult`** (`types.py:834-840`): `pr_number: int`, `merged: bool`, `merge_sha: str = ""`.

**Body:** emit start (`operation="merge_pr"`, no branch, no paths); `svc.merge_pull_request(pr_number=input.pr_number, merge_method=input.merge_method)` returns a **dict**; on except → FAILED emit + `_reraise_git_error`; on success → `_emit_git_complete(..., pr_number=input.pr_number, commit_sha=result.get("merge_sha", ""))`; return `MergePRResult(pr_number=input.pr_number, merged=result["merged"], merge_sha=result.get("merge_sha", ""))` (`git_operations.py:461-490`).
> Note: `merged` uses `result["merged"]` (hard key — KeyError if absent), `merge_sha` uses `.get(..., "")`.

**`GitService.merge_pull_request(pr_number, merge_method="merge") -> dict`** (`git_service.py:451-495`):
1. `pr = self._await_mergeability(pr_number)` — poll loop (§7).
2. if `pr.merged` → `logger.info("... already merged")`; return `{"merged": True, "merge_sha": pr.merge_commit_sha or ""}` (idempotent, `git_service.py:478-480`).
3. if `not pr.mergeable`:
   - `state = pr.mergeable_state or "unknown"`.
   - `error_cls = _UNMERGEABLE_STATE_TO_ERROR.get(state, GitServiceError)` where the map (`git_service.py:106-110`) is: `"dirty"→MergeConflict`, `"behind"→MergeDivergenceUnresolved`, `"blocked"→MergeBranchProtectionRejected`; anything else → base `GitServiceError`.
   - `raise error_cls(f"PR #{pr_number} is not mergeable (state: {state})")` (`git_service.py:482-487`).
4. else `try: result = pr.merge(merge_method=merge_method)`; on `GithubException` → `GitServiceError(f"Failed to merge PR #{pr_number}: {exc.data}")` (`git_service.py:489-492`).
5. return `{"merged": result.merged, "merge_sha": result.sha or ""}`.

**State → typed error mapping (merge_pr path):**

| `mergeable_state` | error raised | retryable (via `git_merge` policy)? |
|---|---|---|
| `dirty` | `MergeConflict` | NO (in non_retryable list) |
| `behind` | `MergeDivergenceUnresolved` | NO |
| `blocked` | `MergeBranchProtectionRejected` | NO |
| anything else falsy-mergeable | `GitServiceError` | (not on `git_merge` list) |

> **`merge_pr` does NOT rebase.** A `behind` PR raises `MergeDivergenceUnresolved` immediately.
> The rebase-then-merge behavior lives only in `reconcile_and_merge_pr` (§6). Docstring
> (`git_operations.py:493-500`) notes `reconcile_and_merge_pr` "Replaces bare `merge_pr` for
> artifact-repo merges."

**Idempotency:** an already-merged PR short-circuits to success. **Retries (declared):** `transient`
(`git_operations.py:459`) — but see the note: callers wanting the structured-error non-retry
semantics use `reconcile_and_merge_pr` with `git_merge`.

---

## 6. `reconcile_and_merge_pr` (`git_operations.py:493-609`)

**Signature:** `async def reconcile_and_merge_pr(input: MergePRInput) -> MergePRResult`
(same `MergePRInput` / `MergePRResult` as `merge_pr`).

Introduced W17 / P5-S17.3c (2026-05-04). **Call-site retry policy: `RETRY_POLICIES["git_merge"]`**
(`base.py:1217`), whose `non_retryable_error_types = ["MergeConflict", "MergeDivergenceUnresolved",
"MergeBranchProtectionRejected"]` (`retry_policies.py:100-104`), `maximum_attempts=3`,
`initial_interval=5s`, `backoff_coefficient=2.0`, `maximum_interval=30s` (`retry_policies.py:95-105`).

**Body (`git_operations.py:533-609`):**
1. `import time` (inline, `git_operations.py:533`).
2. `execution_id = await _emit_git_start(..., operation="reconcile_and_merge_pr")` (no branch/paths).
3. `try: attempt = activity.info().attempt` else `attempt = 1` (test context, `git_operations.py:545-548`) — the OUTER Temporal retry attempt, captured for telemetry.
4. `start_wall = time.monotonic()`.
5. `try:` build svc; `result = svc.reconcile_and_merge(pr_number=input.pr_number, merge_method=input.merge_method)`.
6. `except Exception as exc:`:
   - `duration_ms = int((time.monotonic() - start_wall) * 1000)`; `failure_type = type(exc).__name__`.
   - `logger.warning("reconcile_and_merge_pr failed", extra={"pr_number", "failure_type", "attempt", "duration_ms"})` (`git_operations.py:565-573`).
   - `_emit_git_complete(execution_id, repo=input.repo, status=FAILED, error=f"{failure_type}: {exc}")` — NOTE error string is `"{ClassName}: {message}"`, not bare `str(exc)`.
   - `_reraise_git_error(exc)`.
7. Success:
   - `duration_ms = int((time.monotonic() - start_wall) * 1000)`.
   - `_emit_git_complete(execution_id, repo=input.repo, pr_number=input.pr_number, commit_sha=result.merge_sha)`.
   - `logger.info("reconcile_and_merge_pr succeeded", extra={"pr_number", "initial_mergeable_state": result.initial_mergeable_state, "rebase_ran": result.rebase_performed, "final_mergeable_state": result.final_mergeable_state, "merge_sha": result.merge_sha, "attempt", "duration_ms"})` (`git_operations.py:593-604`).
   - return `MergePRResult(pr_number=input.pr_number, merged=result.merged, merge_sha=result.merge_sha)`.

**Telemetry fields (strategy doc §3.8), success log uses `rebase_ran` key but reads `result.rebase_performed`.** GOTCHA: log-field name (`rebase_ran`) ≠ dataclass attr (`rebase_performed`).

**`GitService.reconcile_and_merge(pr_number, merge_method="merge") -> ReconcileMergeResult`** (`git_service.py:606-693`):
1. `pr = self._await_mergeability(pr_number)` (poll, §7).
2. if `pr.merged` → return `ReconcileMergeResult(merged=True, merge_sha=pr.merge_commit_sha or "", initial_mergeable_state=pr.mergeable_state or "unknown", rebase_performed=False, final_mergeable_state=pr.mergeable_state or "unknown")` (idempotent no-op, `git_service.py:638-646`).
3. `initial_state = pr.mergeable_state or "unknown"`; `rebase_performed = False`; `final_state = initial_state`.
4. if `initial_state == "dirty"` → `raise MergeConflict(f"PR #{pr_number} is not mergeable (state: dirty)")` (`git_service.py:652-655`).
5. if `initial_state == "blocked"` → `raise MergeBranchProtectionRejected(f"... (state: blocked)")` (`git_service.py:656-659`).
6. if `initial_state == "behind"` (`git_service.py:661-679`):
   - `rebase = self.rebase_pr_onto_base(pr_number)` (§7.2).
   - `rebase_performed = rebase.rebase_ran`; `final_state = rebase.final_mergeable_state`.
   - if `final_state == "behind"` → `raise MergeDivergenceUnresolved(f"PR #{pr_number} still behind base after rebase (state: {final_state})")` (racing merge — retryable-ish but on the non_retryable list, so escalates to `merge_blocked`).
   - if `final_state == "dirty"` → `raise MergeConflict(f"... conflicts after rebase (state: dirty)")`.
   - if `final_state == "blocked"` → `raise MergeBranchProtectionRejected(f"... blocked after rebase (state: blocked)")`.
7. Fall through (state should be `clean` or optimistic `unknown`): `merge_result = self.merge_pull_request(pr_number, merge_method=merge_method)` — reuses §5's mergeability poll + unmergeable classification (`git_service.py:685`).
8. return `ReconcileMergeResult(merged=merge_result["merged"], merge_sha=merge_result.get("merge_sha", ""), initial_mergeable_state=initial_state, rebase_performed=rebase_performed, final_mergeable_state=final_state)`.

**State → typed error mapping (reconcile path):**

| initial `mergeable_state` | action | terminal outcome |
|---|---|---|
| merged | — | idempotent success |
| `clean` (or optimistic `unknown`) | delegate to `merge_pull_request` | merged, or that path's classification |
| `dirty` | none | `MergeConflict` (non-retryable) |
| `blocked` | none | `MergeBranchProtectionRejected` (non-retryable) |
| `behind` | `rebase_pr_onto_base` (update-branch), re-check `final_state` | `clean`→merge; `behind`→`MergeDivergenceUnresolved`; `dirty`→`MergeConflict`; `blocked`→`MergeBranchProtectionRejected` |

**GOTCHA — `final_state` on the log/result may lie for the `clean` path.** When `initial_state`
is `clean`, `final_state` is never updated past its `= initial_state` seed (`git_service.py:650`),
so the result reflects the pre-merge read, not a post-merge re-fetch. Fine for telemetry, but do
not treat `final_mergeable_state` as a post-merge assertion.

**Workflow-level `merge_blocked` loop (`base.py:1167+`):** the three structured errors are on the
`git_merge` non_retryable list, so Temporal does NOT retry them; instead they surface to the
workflow, which transitions the gate to `merge_blocked` and waits for a reviewer `merge_retry`
signal (retry_policies.py:82-93 commentary; base.py:1209-1217 dispatch).

---

## 7. Mergeability polling & rebase internals (GitService)

### 7.1 `_await_mergeability(pr_number)` (`git_service.py:510-547`)
- `pr = self._repo.get_pull(pr_number)`; `GithubException` → `GitServiceError(f"PR #{pr_number} not found: {exc.data}")`.
- if `pr.merged` → return immediately (short-circuit).
- loop `for attempt in range(_MERGEABILITY_POLL_ATTEMPTS)` where `_MERGEABILITY_POLL_ATTEMPTS = 8`, `_MERGEABILITY_POLL_DELAY_SECONDS = 1.5` (`git_service.py:507-508`):
  - `state = pr.mergeable_state or "unknown"`.
  - if `pr.mergeable is not None and state != "unknown"` → return `pr`.
  - else `logger.info("... sleeping")`, `time.sleep(1.5)`, re-fetch `pr = get_pull(pr_number)` (`GithubException` → `GitServiceError(... during mergeability poll ...)`); if `pr.merged` → return.
- After 8 polls still unknown → return the last `pr` (caller raises with the real state).

**GOTCHA — `time.sleep` inside an activity.** Up to 8 × 1.5s = **12s of blocking sleep** happens
inside the merge activities. This is a synchronous `GitService` call from an async activity;
it blocks the activity's thread. Reason (`git_service.py:501-506`): GitHub computes mergeability
async; treating fresh `unknown` as terminal caused the 2026-05-05 Mezzanine merge bug. Activity
`start_to_close_timeout` at the call site must exceed ~12s + network.

### 7.2 `rebase_pr_onto_base(pr_number) -> RebaseResult` (`git_service.py:549-604`)
- `pr = get_pull(pr_number)`; not-found → `GitServiceError`.
- `rebase_ran = False`; `try: rebase_ran = bool(pr.update_branch())` (PUT /pulls/{n}/update-branch, HTTP 202).
- `except GithubException as exc:` — extract `message = exc.data.get("message","")`; if `exc.status == 422 and "up to date" in message.lower()` → treat as benign no-op (`rebase_ran = False`); else → `GitServiceError(f"Failed to rebase PR #{pr_number}: {exc.data}")` (`git_service.py:576-587`).
- re-fetch `refreshed = get_pull(pr_number)` (not-found → `GitServiceError`); `final_state = refreshed.mergeable_state or "unknown"`.
- return `RebaseResult(rebase_ran=rebase_ran, final_mergeable_state=final_state)` (`RebaseResult` dataclass `git_service.py:61-77`).

---

## 8. `provision_target_repo` (`git_operations.py:612-669`)

**Signature:** `async def provision_target_repo(input: ProvisionTargetRepoInput) -> ProvisionTargetRepoResult`

**Input `ProvisionTargetRepoInput`** (`types.py:846-885`): `target_app_id`, `repo_slug` (`owner/name`), `initial_readme: str=""`, `private: bool=True`, `execution_context=None`, plus v2 fields `source_app_ids: list[str]=[]`, `target_service_id=""`, `portfolio_id=""`, `relationship=""`.
**Output `ProvisionTargetRepoResult`** (`types.py:888-903`): `target_app_id`, `target_repo_url`, `repo_slug`, `created: bool=False`, `lineage_rows_inserted: int=0`.

**Body (`git_operations.py:633-669`):**
1. `execution_id = await _emit_git_start(..., repo=input.repo_slug, operation="provision_target_repo")`.
2. `try:` `from src.git_service import GitService` (inline import); `cfg = _git_service_config()`; call the **staticmethod** `GitService.provision_repository(GitServiceConfig(token=cfg["token"], repo=cfg["repo"], base_url=cfg["base_url"]), repo_slug=input.repo_slug, initial_readme=input.initial_readme, private=input.private)` → `(url, created)`.
   > Note: the config's `repo=cfg["repo"]` (env `GITHUB_REPO`) is "unused for provisioning; required by ctor" (`git_operations.py:645`). It does NOT go through `_build_git_service` — it builds `GitServiceConfig` directly and calls the staticmethod (which builds its own `Github` client, never constructing a `GitService` instance / never calling `__init__`'s `get_repo`).
3. `except Exception as exc:` → FAILED emit + `_reraise_git_error`.
4. success → `_emit_git_complete(execution_id, repo=input.repo_slug)` (no commit_sha, no pr, no output_paths).
5. return `ProvisionTargetRepoResult(target_app_id=input.target_app_id, target_repo_url=url, repo_slug=input.repo_slug, created=created)`.

**`GitService.provision_repository(config, repo_slug, initial_readme="", private=True) -> tuple[str, bool]`** (staticmethod, `git_service.py:748-853`):
1. if `"/" not in repo_slug` → `GitServiceError(f"repo_slug must be 'owner/name', got {repo_slug!r}")`.
2. `owner, name = repo_slug.split("/", 1)`.
3. Build `gh = Github(auth=Auth.Token(config.token)[, base_url])` (base_url passed only if set and != `https://api.github.com`, `git_service.py:783-787`).
4. Short-circuit: `try: existing = gh.get_repo(repo_slug); return existing.html_url, False` (idempotent reuse, `git_service.py:790-793`). On `GithubException status != 404` → `GitServiceError(f"Cannot check repository ...")`; a 404 falls through to create.
5. Resolve owner: `try: org = gh.get_organization(owner); target = org` else on 404 `target = gh.get_user()` (user fallback); other statuses → `GitServiceError(f"Cannot resolve owner ...")` (`git_service.py:803-811`).
6. `try: new_repo = target.create_repo(name=name, private=private, auto_init=True, description="Olympus modernization target repo — provisioned by Architecture's target-state-mapping step.")`; on `GithubException` → `GitServiceError(f"Failed to create repository ...")` (`git_service.py:813-826`).
7. if `initial_readme`: `try:` fetch `new_repo.get_contents("README.md", ref="main")` → `sha`; if `sha`, `new_repo.update_file(path="README.md", message="Olympus: initial target-repo README", content=initial_readme, sha=sha, branch="main")`. On `GithubException` → just `logger.warning` (NON-fatal, `git_service.py:830-850`).
8. return `new_repo.html_url, True`.

**GOTCHA — `lineage_rows_inserted` and the v2 lineage fields are dead.** `types.py:875-903`
documents that when `source_app_ids` is populated the activity "writes one `application_lineage`
row per source→target edge." **The activity body never reads `source_app_ids`, `target_service_id`,
`portfolio_id`, or `relationship`, and never writes `application_lineage`.** It always returns the
default `lineage_rows_inserted=0`. Lineage projection happens elsewhere (docstring points to
`persist_architecture_side_effects`, `git_operations.py:626-628`).

**Idempotency:** idempotent on `repo_slug` — existing repo returns `(url, False)` without raising
(`git_operations.py:625-631`). No DB write of its own. **Retries:** `transient`.

---

## 9. `step_execution` persistence (the only DB writes in this group)

Backed by `utils/execution.py`; envelope defined by
`olympus-contracts/schemas/pipeline-execution/step-execution-record.schema.json` + migration 033
(execution.py:1-8 docstring). **Persistence is best-effort — a DB failure NEVER propagates into the
activity result** (execution.py:32-34, try/except returns None / swallows).

### 9.1 `_emit_git_start` → `emit_execution_record` (INSERT)
`_emit_git_start(ctx, *, repo, operation, branch="", paths=None)` (`git_operations.py:54-101`):
- if `ctx is None` → return `None` (no row).
- `workflow_id, attempt` from `activity.info()`; on exception (unit-test) → `workflow_id="", attempt=1` (`git_operations.py:69-74`).
- `input_artifacts = resolve_input_artifacts(ctx.input_artifact_paths, repo=repo, ref=branch or "main")` — binds each Layer A declaration string to `StepArtifactRef(repo, ref, path)` with `{placeholder}` substitution (no subs passed here, so placeholders remain, execution.py:348-373).
- `payload = {"operation": operation, "repo": repo, "branch": branch, "paths": paths or []}`.
- calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.GIT, workflow_id, app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt, input_artifacts, payload, status=ExecutionStatus.RUNNING))`.

**`emit_execution_record`** (execution.py:150-219) — INSERT into `step_execution`, column → value:

| column | value | note |
|---|---|---|
| `execution_id` | `uuid.uuid4()` (generated here) | returned to caller |
| `app_id` | `_parse_uuid(input.app_id)` | `None` if empty/invalid UUID |
| `wave_id` | `_parse_uuid(input.wave_id)` | `None` if empty/invalid |
| `portfolio_id` | `_parse_uuid(input.portfolio_id)` | **if None → skip entire insert, return None** (execution.py:167-174) |
| `line_id` | `input.line_id` | text |
| `step_id` | `input.step_id` | text |
| `step_kind` | `input.step_kind.value` = `"git"` | enum value |
| `status` | `input.status.value` = `"running"` | enum value |
| `started_at` | `input.started_at or datetime.now(timezone.utc)` | tz-aware |
| `attempt` | `input.attempt` | int |
| `input_artifacts` | `json.dumps([a.to_dict() for a in input_artifacts])::jsonb` | each `{repo, ref, path[, content_hash]}` (execution.py:91-99) |
| `payload` | `json.dumps(input.payload or {})::jsonb` | `{operation, repo, branch, paths}` |
| `workflow_id` | `input.workflow_id` | text |
| `agent_task_id` | `_parse_uuid(input.agent_task_id)` = None here | not set by git |
| `gate_id` | `_parse_uuid(input.gate_id)` = None here | not set by git |

Connection: `asyncpg.connect(_db_url())` where `_db_url()` reads `DATABASE_HOST` (localhost),
`DATABASE_PORT` (5432), `DATABASE_USER`/`DATABASE_PASSWORD` (olympus/olympus), `DATABASE_NAME`
(olympus) → `postgresql://...` (execution.py:127-133). Connection closed in `finally`. Any
exception → `logger.warning` + return `None` (execution.py:212-219).

**GOTCHA — a non-UUID `portfolio_id` silently drops the whole row.** `emit_execution_record`
returns `None` when `portfolio_id` isn't a valid UUID (execution.py:167-174); the git activity then
gets `execution_id=None` and `_emit_git_complete` becomes a no-op — no error, no telemetry.

### 9.2 `_emit_git_complete` → `update_execution_record` (UPDATE)
`_emit_git_complete(execution_id, *, output_paths=None, repo="", commit_sha="", pr_number=None, pr_url="", branch="", status=COMPLETED, error=None)` (`git_operations.py:104-138`):
- if `execution_id is None` → return.
- build `payload_merge`: add `"commit_sha"` if truthy, `"pr_number"` if not None, `"pr_url"` if truthy (`git_operations.py:119-125`).
- `output_artifacts`: only if BOTH `output_paths` AND `repo` truthy → `[StepArtifactRef(repo=repo, ref=branch or commit_sha or "main", path=p) for p in output_paths]` (`git_operations.py:126-131`). **Ref precedence: branch, else commit_sha, else "main".**
- `update_execution_record(execution_id, status=status, output_artifacts=..., payload_merge=payload_merge or None, last_error=error)`.

**`update_execution_record`** (execution.py:222-275) — UPDATE `step_execution` WHERE `execution_id=$1`:
- `status = $2` (enum value).
- `completed_at = $3` (`completed_at or now(utc)`).
- `duration_ms = EXTRACT(EPOCH FROM ($3 - started_at)) * 1000` — computed in-DB from stored `started_at`.
- `output_artifacts = COALESCE($4::jsonb, output_artifacts)` — only overwrites when non-None.
- `payload = payload || COALESCE($5::jsonb, '{}'::jsonb)` — **shallow JSONB merge** of `payload_merge` into existing payload.
- `last_error = COALESCE($6, last_error)`.
- exceptions swallowed with `logger.warning` (execution.py:270-275).

**Per-activity terminal-emit values:**

| activity | FAILED emit args | success emit args |
|---|---|---|
| `read_artifact` | repo, branch, error=str(exc) | repo, branch, commit_sha=result.commit_sha, output_paths=[result.path] |
| `write_artifact` | repo, branch, error | repo, branch=result.branch, commit_sha=result.commit_sha, output_paths=[result.path] |
| `write_artifacts_batch` | repo, branch, error | repo, branch=result.branch, commit_sha=result.commit_sha, output_paths=paths |
| `create_pr` | repo, branch=source_branch, error | repo, branch=result.source_branch, pr_number, pr_url |
| `merge_pr` | repo, error | repo, pr_number, commit_sha=result.get("merge_sha","") |
| `reconcile_and_merge_pr` | repo, error=`"{ClassName}: {exc}"` | repo, pr_number, commit_sha=result.merge_sha |
| `provision_target_repo` | repo=repo_slug, error | repo=repo_slug (nothing else) |

---

## 10. Error / retry / idempotency summary

| activity | idempotent? | typed errors it can surface | retry policy (call site) |
|---|---|---|---|
| `read_artifact` | yes (pure read) | `GitServiceError` (not found / dir); transient→RetryableError | transient |
| `write_artifact` | yes (content-idempotent) | `GitServiceError`; transient→Retryable | transient |
| `write_artifacts_batch` | yes | `GitServiceError`; transient→Retryable | transient |
| `create_pr` | yes (reuses open PR) | `GitServiceError`; transient→Retryable | transient |
| `merge_pr` | yes (already-merged short-circuit) | `MergeConflict`/`MergeDivergenceUnresolved`/`MergeBranchProtectionRejected`/`GitServiceError` | transient (declared) |
| `reconcile_and_merge_pr` | yes | same 3 structured merge errors (on `git_merge` non_retryable list) + `GitServiceError` | **git_merge** |
| `provision_target_repo` | yes (slug short-circuit) | `GitServiceError`; transient→Retryable | transient |

Retry policy field values:
- `transient` = `HTTP_RETRY_POLICY`: initial 1s, max 15s, 3 attempts, backoff 2.0 (temporal_base/retry_policies.py:35-40).
- `git_merge`: initial 5s, max 30s, 3 attempts, backoff 2.0, non_retryable=[MergeConflict, MergeDivergenceUnresolved, MergeBranchProtectionRejected] (retry_policies.py:95-105).
- Docstrings also reference `FILE_RETRY_POLICY` (initial 1s, max 5s, 3 attempts, backoff 2.0) for git I/O (temporal_base/retry_policies.py:19-24), though observed call sites use `transient`.

**Non-obvious error-classification chain for any git activity failure:**
1. `GitService` raises `GitServiceError`/subclass or `requests`/builtin network error.
2. Activity `except` → FAILED telemetry → `_reraise_git_error`.
3. `_reraise_git_error`: transient network type → `RetryableError` (non_retryable=False); else re-raise original.
4. `@foundry_activity` wrapper: `WorkflowError`/`ApplicationError` (incl. our RetryableError/NonRetryableError) → pass through; else type-name-string classify → Retryable/NonRetryableError.
   - **`GitServiceError`/`MergeConflict`/etc. are plain `Exception`s (not `ApplicationError`)**, so if `_reraise_git_error` re-raises them unchanged, the decorator re-wraps: their type names (`gitserviceerror`, `mergeconflict`, `mergedivergenceunresolved`, `mergebranchprotectionrejected`) match NONE of the retryable patterns → wrapped `NonRetryableError`.
   - **GOTCHA:** this means the structured merge errors reach Temporal as `NonRetryableError`, and separately their bare class names appear in `git_merge`'s `non_retryable_error_types`. Either way they do not retry. But because the decorator renames them to `NonRetryableError`, a workflow catching `MergeConflict` by type from the raised `ApplicationError` must inspect the message / `non_retryable_error_types` matching by original class name — Temporal's `ApplicationError.type` preserves the original class name for the policy match, but the Python exception object seen on the worker side is `NonRetryableError`.
