# Discovery Line-Transition Activities — Atomic Regeneration Spec

**Source module:** `temporal/olympus_workflows/activities/line_transitions/discovery.py`
**Shared helpers:** `temporal/olympus_workflows/activities/line_transitions/_shared.py`
**Types:** `temporal/olympus_workflows/types.py`
**Execution envelope utils:** `temporal/olympus_workflows/utils/execution.py`
**Decorator:** `temporal/olympus_workflows/temporal_base/activities.py`
**Errors:** `temporal/olympus_workflows/temporal_base/errors.py`

This module was split out of the original monolithic `line_transitions` module under P7-S16.14; behavior is unchanged and it is re-exported through the package facade so `olympus_workflows.activities.line_transitions.<name>` still resolves (`discovery.py:1-6`).

The module exposes **3 activity functions** (all decorated `@foundry_activity`) plus a suite of pure module-level extraction helpers:

1. `persist_decomposition_map` — `discovery.py:144`
2. `persist_discovery_side_effects` — `discovery.py:513`
3. `persist_capability_catalog` — `discovery.py:637`

Helpers (pure, no `@foundry_activity`): `_extract_decomposition` (`:48`), `_extract_catalog_side_effects` (`:211`), `_extract_structural_side_effects` (`:262`), `_extract_business_logic_side_effects` (`:289`), `_extract_quality_side_effects` (`:332`), `_extract_ux_side_effects` (`:416`), `_extract_tco_side_effects` (`:472`), `_validate_capability_catalog` (`:615`). Shared: `_try_parse_json`, `_dedupe_str_list`, `_db_url`, `_build_update_sql`, `_merge_application_metadata`, `_extract_discovery_compliance_metadata` (all in `_shared.py`).

None of these three activities dispatch to an agent, do Git operations, or perform gate merges. They are all **DB-projection (persist_*) activities** that take already-committed artifact JSON (as strings) and write derived rows/columns into Postgres via `asyncpg`. There are no agent-dispatch or Git-merge activities in this group.

---

## 0. Cross-cutting infrastructure

### 0.1 `@foundry_activity` — what it adds over raw `activity.defn`

Decorator at `temporal_base/activities.py:79-150`. All three activities use `@foundry_activity(config=ActivityConfig(enable_observability=True))` (`discovery.py:144,513,637`).

`ActivityConfig` dataclass (`activities.py:41-53`) fields and defaults:
- `retry_policy: RetryPolicy | None = None`
- `start_to_close_timeout / schedule_to_close_timeout / schedule_to_start_timeout / heartbeat_timeout: timedelta | None = None`
- `enable_observability: bool = True`
- `enable_error_wrapping: bool = True`
- `log_inputs: bool = False`
- `log_outputs: bool = False`

**GOTCHA:** `ActivityConfig` carries timeout/retry-policy/heartbeat fields, but `foundry_activity` **never reads them** to configure the Temporal activity. The decorator only forwards `name` and `**activity_kwargs` to `@activity.defn(name=name, **activity_kwargs)` (`activities.py:100`); `config.retry_policy`, all timeouts, and `heartbeat_timeout` are ignored at decoration time. Retry policy and timeouts are therefore controlled entirely by the **caller** (the workflow's `execute_activity(...)` options), not by this decorator. There is no automatic heartbeat. (`activities.py:97-148`.)

Wrapper behavior (`activities.py:100-148`), in order per invocation:
1. `activity_name = name or func.__name__` (`:103`). Since these three are decorated with no `name=`, the activity name is the function name — Temporal replay keys on it (`:14-15`).
2. If `enable_observability` (true here): `logger.info("Activity %s starting", activity_name, extra={"inputs": args if log_inputs else None})` (`:105-110`). `log_inputs` is false → `inputs=None`.
3. `result = await func(*args, **kwargs)` (`:113`).
4. On success + observability: `logger.info("Activity %s completed", ..., extra={"outputs": result if log_outputs else None})` (`:115-120`); `log_outputs` false → `outputs=None`. Returns `result`.
5. On any `Exception` (`:124`): if observability, `logger.error("Activity %s failed: %s", activity_name, error, extra={"error": str(error)})` (`:125-131`).
6. Error wrapping (`enable_error_wrapping` defaults True) `:133-144`:
   - If `error` is already a `WorkflowError` or `temporalio` `ApplicationError` → `raise` unchanged (`:135-136`). (So `NonRetryableError` raised inside the body passes through with `non_retryable=True` intact.)
   - Else if `_is_retryable_error(error)` → wrap in `RetryableError(f"Retryable error in {activity_name}: {error}")` (`:137-140`) → `non_retryable=False`.
   - Else → wrap in `NonRetryableError(f"Non-retryable error in {activity_name}: {error}")` (`:141-144`) → `non_retryable=True`.

`_is_retryable_error(error)` (`activities.py:56-76`): lowercases `str(type(error))` and returns True if it contains any of: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`.

**GOTCHA:** classification is by **type-name substring**, not instance inspection. E.g. `asyncpg` raising `ConnectionDoesNotExistError` matches `"connection"` → RetryableError; a `TimeoutError` matches `"timeout"`. But a bare `KeyError`/`ValueError` from parsing matches nothing → NonRetryableError. This is intentionally distinct from `errors.is_retryable_error` which inspects httpx/OSError/ApplicationError instances (`activities.py:56-63`, `errors.py:53`).

Error class hierarchy (`errors.py:16-34`): `WorkflowError(ApplicationError)` with `__init__(message, non_retryable=True)`; `RetryableError(WorkflowError)` forces `non_retryable=False`; `NonRetryableError(WorkflowError)` forces `non_retryable=True`.

### 0.2 Execution envelope: `emit_code_step_start` / `emit_code_step_complete`

Every activity brackets its body with these (best-effort observability records into the `step_execution` table).

`emit_code_step_start(ctx, *, function_name, columns_writable=None)` (`execution.py:283-321`):
- If `ctx` (the `execution_context`, a `StepExecutionContext | None`) is `None` → returns `None` immediately (`:295-296`). All three activities call it with `input.execution_context`, which may be None.
- Reads `workflow_id` + `attempt` from `activity.info()` inside try/except; on failure defaults `workflow_id=""`, `attempt=1` (`:297-304`).
- Builds `payload = {"function": function_name}`; adds `columns_written` only if `columns_writable` passed (these callers pass none) (`:305-307`).
- Calls `emit_execution_record(EmitExecutionRecordInput(portfolio_id=ctx.portfolio_id, line_id=ctx.line_id, step_id=ctx.step_id, step_kind=StepKind.CODE, workflow_id=..., app_id=ctx.app_id or None, wave_id=ctx.wave_id or None, attempt=..., payload=..., status=ExecutionStatus.RUNNING))` (`:308-320`). Returns the new `step_execution` id (a `uuid.UUID`) or `None`.
- `emit_execution_record` itself is best-effort: returns `None` on any persistence failure or invalid portfolio_id (`execution.py:150-174`), logging a warning; the activity MUST continue regardless.

`emit_code_step_complete(execution_id, *, status=ExecutionStatus.COMPLETED, columns_written=None, error=None)` (`execution.py:324-345`): builds `payload_merge={"columns_written": columns_written}` if provided, then `update_execution_record(execution_id, status=..., payload_merge=..., last_error=error)`.

`ExecutionStatus` enum members used: `COMPLETED` (default), `FAILED` (`execution.py:66-74`).

**GOTCHA:** these envelope calls are pre/post the real work but are **not** in a `finally`; instead each activity has an explicit `except Exception as exc:` that calls `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` then re-raises (`discovery.py:204-208`, `:595-599`, `:976-980`). If the failure record write itself raises, that would mask the original — but envelope writes are best-effort and swallow their own errors upstream.

### 0.3 DB connection

`_db_url()` (`_shared.py:23-29`) builds `postgresql://{user}:{password}@{host}:{port}/{db}` from env: `DATABASE_HOST` (default `localhost`), `DATABASE_PORT` (`5432`), `DATABASE_USER` (`olympus`), `DATABASE_PASSWORD` (`olympus`), `DATABASE_NAME` (`olympus`).

**Connection pattern for all three activities:** `conn = await asyncpg.connect(_db_url())` then `try: ... finally: await conn.close()` (raw connection, no SQLAlchemy). `persist_capability_catalog` additionally wraps its writes in `async with conn.transaction():` for atomicity (`discovery.py:705`); the other two run bare `execute` calls without an explicit transaction.

### 0.4 `_try_parse_json` (shared) — `_shared.py:40-56`

Best-effort parse of agent output strings that may include prose:
- If `text` is empty/falsy → `None`.
- `json.loads(text)`; on `JSONDecodeError`, find first `{` (`text.find("{")`) and last `}` (`text.rfind("}")`); if `start == -1 or end <= start` → `None`; else re-parse the substring `text[start:end+1]`; on second failure → `None`.
- Returns the parsed value **only if it is a `dict`**, else `None`. (Lists/scalars parse but are discarded as None.)

### 0.5 `_dedupe_str_list` (shared) — `_shared.py:59-67`

De-dupes preserving first-seen order via a `seen` set. Used by `_extract_decomposition` for integrations/tech_stack.

---

## 1. `persist_decomposition_map` — `discovery.py:144-208`

### 1.1 Signature & I/O
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_decomposition_map(input: PersistDecompositionMapInput) -> None
```
Returns `None`. Writes `application.decomposition_map` (JSONB) + `updated_at`.

**Input** `PersistDecompositionMapInput` (`types.py:1472-1487`):
- `app_id: str` (required)
- `catalog_json: str = ""` — raw JSON from Discovery catalog pass (already committed to Git)
- `synthesis_json: str = ""` — raw JSON from synthesis pass
- `execution_context: StepExecutionContext | None = None`

Purpose: without this the `decomposition_map` column stays NULL and the Insights tab shows "Run Discovery to extract architecture..." placeholders forever (`discovery.py:146-151`).

### 1.2 Control flow
1. `exec_id = await emit_code_step_start(input.execution_context, function_name="persist_decomposition_map")` (`:152-155`).
2. Parse `app_id`: `app_uuid = uuid.UUID(input.app_id)`; on `(ValueError, TypeError)` raise `NonRetryableError(f"Invalid app_id: {input.app_id!r}")` (`:157-162`). **This is inside the outer try** so it also triggers the FAILED envelope write + re-raise.
3. `catalog = _try_parse_json(input.catalog_json)`; `synthesis = _try_parse_json(input.synthesis_json)` (`:164-165`).
4. `decomposition = _extract_decomposition(catalog, synthesis)` (`:166`).
5. **Early return if empty** (`:168-174`): if `not decomposition` → log info `"persist_decomposition_map: nothing extractable from agent output"` with `extra={"app_id": ...}`, call `emit_code_step_complete(exec_id, columns_written=[])`, `return`. No DB write.
6. Else connect, run the UPDATE (`:176-190`):
   ```sql
   UPDATE application
   SET decomposition_map = $1, updated_at = $2
   WHERE id = $3
   ```
   params: `json.dumps(decomposition)`, `datetime.now(timezone.utc)`, `app_uuid`. `finally: await conn.close()`.
7. `logger.info("decomposition_map persisted", extra={app_id, module_count, integration_count, tech_stack_count})` — counts are `len(decomposition.get(k, []))` (`:192-200`).
8. `emit_code_step_complete(exec_id, columns_written=["decomposition_map", "updated_at"])` (`:201-203`).
9. `except Exception as exc:` → `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))` then `raise` (`:204-208`).

### 1.3 `_extract_decomposition(catalog, synthesis)` — `discovery.py:48-141`

Produces a dict with up to three keys `modules`, `integrations`, `tech_stack` that the Insights API reads as `decomposition_map.modules[*].name`, `decomposition_map.integrations` (list[str]), `decomposition_map.tech_stack` (list[str]) (`:51-57`).

Iterates `for source in (catalog or {}, synthesis or {})` (`:70`) — i.e. accumulates across BOTH inputs. Per source:

**Modules** (accumulated into `modules: list[dict]`):
- From `source["architecture"]` if dict (`:74-82`): `mods = arch.get("major_components") or arch.get("components")`; if list, for each `m`: dict with `.name` → append `{"name": str(m["name"])}`; str → append `{"name": m}`.
- From top-level `source.get("modules") or source.get("components")` (`:92-98`): same dict/str handling.

**Integrations** (accumulated into `integrations: list[str]`):
- From `arch.get("integrations")` (`:84-90`): str → append; dict with `.name` → append `str(i["name"])`.
- From top-level `source.get("integrations") or source.get("external_systems")` (`:100-106`): same.

**Tech stack** (accumulated into `tech_stack: list[str]`) `:111-133`:
- `ts = source.get("tech_stack") or source.get("technologies") or source.get("stack")`.
- If `ts` is a list: each str appended; each dict with `.name` → `str(t["name"])`.
- If `ts` is a dict (new catalog-application shape, e.g. `{languages:[...], frameworks:[...]}`) `:122-133`: for each `key,value`: if `value` is a list, each str item appended / dict-with-name appended; elif `value` truthy → append `f"{key}: {value}"`.

**Output assembly** `:135-140`: `out["modules"] = modules` only if non-empty; `out["integrations"] = _dedupe_str_list(integrations)` if non-empty; `out["tech_stack"] = _dedupe_str_list(tech_stack)` if non-empty. Note `modules` is NOT deduped. Returns `out`.

**GOTCHA:** modules can contain duplicates (no dedupe) whereas integrations/tech_stack are deduped. **GOTCHA:** both catalog-shape (`architecture.major_components`) AND legacy top-level (`modules`/`components`) are read from the same source in the same pass, so a source carrying both would double-count modules.

### 1.4 Idempotency & retries
Idempotent: the UPDATE overwrites `decomposition_map` wholesale from the (deterministic) parse of the inputs. Re-running with the same inputs produces the same row (only `updated_at` changes). No retry policy set by the decorator (caller-controlled). Invalid `app_id` → NonRetryableError (terminal).

---

## 2. `persist_discovery_side_effects` — `discovery.py:513-607`

### 2.1 Signature & I/O
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_discovery_side_effects(input: PersistDiscoverySideEffectsInput) -> None
```
Returns `None`. Projects Discovery pass artifacts onto scalar/JSONB columns of `application` + merges a compliance metadata block into `application.metadata`.

**Input** `PersistDiscoverySideEffectsInput` (`types.py:1490-1520`):
- `app_id: str`
- `catalog_json: str = ""` → catalog-application fields
- `structural_json: str = ""` → architecture.major_components / integrations
- `business_logic_json: str = ""` → business_logic.rule_count etc.
- `quality_risk_json: str = ""` → quality.* + risk_tier
- `ux_accessibility_json: str = ""` → ux_assessment.*
- `synthesis_json: str = ""` → **no projected side effects** (artifact only)
- `tco_json: str = ""` → tco.*
- `execution_context: StepExecutionContext | None = None`

Called after every Discovery pass has committed its artifact to Git. **Failures are observability-only per the workflow** (the workflow continues even if this raises), but note the activity itself DOES raise on failure (`:595-599`); the "advisory" behavior is enforced by the caller's activity options, not here (`:517-525`).

### 2.2 Control flow
1. `exec_id = emit_code_step_start(..., function_name="persist_discovery_side_effects")` (`:526-529`).
2. Parse `app_id` → `app_uuid`; on `(ValueError, TypeError)` → `NonRetryableError(f"Invalid app_id: {input.app_id!r}")` (`:531-536`).
3. Build `parsed` dict: `_try_parse_json` of each of the 6 inputs keyed `catalog`, `structural`, `business_logic`, `quality_risk`, `ux_accessibility`, `tco` (`:538-545`). **Note:** `synthesis_json` is intentionally NOT parsed/used.
4. `projections: dict = {}` then `.update(...)` in this order (later keys would win on collision, but the extractors own disjoint keys) (`:547-557`):
   - `_extract_catalog_side_effects(parsed["catalog"])`
   - `_extract_structural_side_effects(parsed["structural"])`
   - `_extract_business_logic_side_effects(parsed["business_logic"])`
   - `_extract_quality_side_effects(parsed["quality_risk"])`
   - `_extract_ux_side_effects(parsed["ux_accessibility"])`
   - `_extract_tco_side_effects(parsed["tco"])`
5. `compliance_metadata = _extract_discovery_compliance_metadata(parsed["quality_risk"], parsed["ux_accessibility"])` (`:564-566`).
6. **Early return** (`:568-574`): if `not projections and not compliance_metadata` → log info, `emit_code_step_complete(exec_id, columns_written=[])`, `return`.
7. Connect (`:577`), then (`:578-588`):
   - If `projections`: `sql, params = _build_update_sql(projections)`; `params.append(app_uuid)`; `await conn.execute(sql, *params)`.
   - If `compliance_metadata`: `await _merge_application_metadata(conn, app_uuid, "compliance", compliance_metadata)`.
   - `finally: await conn.close()`.
8. `columns_written = sorted(projections.keys())`; if compliance_metadata, append `"metadata.compliance"` (`:589-591`).
9. `emit_code_step_complete(exec_id, columns_written=columns_written)` (`:592-594`).
10. `except Exception as exc:` → `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))`; `raise` (`:595-599`).
11. **After the try/except (unconditionally reached on success)**: `logger.info("discovery side-effects persisted", extra={app_id, columns_written: sorted(projections.keys())})` (`:601-607`).

**GOTCHA:** the final success `logger.info` at `:601` sits *outside* the try/except block but *inside* the function; it only runs on the success path (the except re-raises). On the empty-projections early return (step 6) it does NOT run.

**GOTCHA (ordering):** the `_build_update_sql` UPDATE and the `_merge_application_metadata` UPDATE are two separate statements on the same `application` row, run sequentially on the same connection with **no explicit transaction**. If the process dies between them, the row can have projected columns updated but metadata unmerged (or vice versa if only compliance existed). Both are individually idempotent so a retry converges.

### 2.3 `_build_update_sql(projections)` — `_shared.py:506-539`

Builds a single dynamic UPDATE touching only present columns.
- Iterates `_SIDE_EFFECT_COLUMNS` (the ordered allow-list, `_shared.py:70-153`) and skips any column not in `projections` (`:517-519`). **GOTCHA:** iteration is over the fixed tuple, so only columns in `_SIDE_EFFECT_COLUMNS` can ever be written — a projection key not in that tuple is silently dropped. The Discovery extractors only emit keys that are in the tuple.
- For each present column: if it's in `_JSONB_COLUMNS` (`_shared.py:156-171`: `tech_stack`, `size_metrics`, `architecture`, `business_logic`, `quality`, `ux_assessment`, `tco`, `portfolio_score`, `data_domains`, `bounded_contexts`, `generated_module_refs`) the value is `json.dumps(value)` before binding (`:521-522`); otherwise bound raw.
- Appends `column = $idx` assignment + param, `idx += 1`.
- Always appends `updated_at = $idx` with `datetime.now(timezone.utc)` (`:527-529`).
- Final param slot is the WHERE id: `sql = "UPDATE application SET " + ", ".join(assignments) + f" WHERE id = ${where_idx}"` (`:532-538`). The caller appends `app_uuid` as that last param (`discovery.py:581`).

Discovery-relevant columns from this tuple (scalar unless noted): `description`, `business_domain`, `archetype`, `complexity_tier`, `safety_tier`, `risk_tier`, `tech_stack`(JSONB), `size_metrics`(JSONB), `architecture`(JSONB), `business_logic`(JSONB), `quality`(JSONB), `ux_assessment`(JSONB), `tco`(JSONB).

### 2.4 Per-pass extraction (artifact-JSON → column mapping)

#### `_extract_catalog_side_effects(catalog)` — `discovery.py:211-259`
Returns `{}` if `catalog` not a dict. Owns per the contract: `description`, `business_domain`, `tech_stack`, `size_metrics`, `complexity_tier`, `safety_tier`, and `architecture.archetype` → top-level `archetype` enum column (added migration 021) (`:212-219`).

| out key | source key | condition |
|---|---|---|
| `description` | `catalog["description"]` | str and `.strip()` truthy → stored `.strip()` (`:225-227`) |
| `business_domain` | `catalog["business_domain"]` | str and `.strip()` truthy → `.strip()` (`:229-231`) |
| `tech_stack` | `catalog["tech_stack"]` | dict and non-empty → stored **as-is (dict)** (`:233-235`) |
| `size_metrics` | `catalog["size_metrics"]` | dict and non-empty → as-is (`:237-239`) |
| `complexity_tier` | `catalog["complexity_tier"]` | str **in `{"simple","moderate","complex"}`** (`:241-245`) |
| `safety_tier` | `catalog["safety_tier"]` | str **in `{"T1","T2","T3"}`** (`:247-249`) |
| `archetype` | `catalog["architecture"]["archetype"]` | architecture is dict, archetype str **in `{"web-app","batch","api","scheduled-job","hybrid"}`** (`:251-257`) |

**GOTCHA:** values outside the allowed enum sets are silently dropped, not written. **GOTCHA:** `tech_stack` here is written as an object (dict) into the `tech_stack` JSONB column — distinct from the flattened list built by `_extract_decomposition` for `decomposition_map`.

#### `_extract_structural_side_effects(structural)` — `discovery.py:262-286`
Returns `{}` if not dict. Builds `architecture` dict:
- `major_components`: `structural.get("major_components") or structural.get("modules")` — set only if a non-empty list (`:276-278`). Stored verbatim (list of whatever shape).
- `integrations`: `structural.get("integrations") or structural.get("external_systems")` — set only if non-empty list (`:280-284`).
- Returns `{"architecture": architecture}` only if architecture non-empty, else `{}` (`:286`).

**GOTCHA:** the `architecture` column is JSONB and this extractor writes `major_components`+`integrations`, while `_extract_catalog_side_effects` writes `archetype` as a **separate top-level enum column** (NOT into `architecture`). If both catalog and structural run, `archetype` and `architecture{}` land in different columns — no collision.

#### `_extract_business_logic_side_effects(bl)` — `discovery.py:289-329`
Returns `{}` if not dict. Column: `business_logic` (JSONB) with `{rule_count, critical_rules_count}`.
- `rules = bl.get("rules") or bl.get("business_rules")` (`:301`).
- If `rules` is a list (`:305-311`): `rule_count = len(rules)`; `critical_count = sum(1 for r in rules if isinstance(r,dict) and r.get("severity") == "critical")`.
- Else (pre-computed summary path, `:312-319`): `rc = bl.get("rule_count")`, `cc = bl.get("critical_rules_count")`; `rule_count = rc` if int; `critical_count = cc` if int.
- If `rule_count is None` → return `{}` (`:321-322`).
- Else return `{"business_logic": {"rule_count": rule_count, "critical_rules_count": critical_count or 0}}` (`:324-329`).

#### `_extract_quality_side_effects(qr)` — `discovery.py:332-413`
Returns `{}` if not dict. Builds `quality` JSONB + top-level `risk_tier` enum column.
- `technical_debt_score`: `qr["technical_debt_score"]` if int/float → `float(debt)` (`:350-352`).
- `test_coverage` (`:354-374`):
  - scalar int/float → `float(coverage)`.
  - dict: prefer `coverage.get("overall") or coverage.get("average")` (int/float) → float.
  - else derive from `per_module = coverage.get("per_module") or coverage`: iterate values; int/float → append; dict → `v.get("line") or v.get("percent")` if int/float. If any scores → `sum(scores)/len(scores)` (unweighted mean, despite docstring saying "weighted"). **GOTCHA:** docstring at `:342-343` claims "weighted average" but the code computes a simple arithmetic mean.
- `vulnerabilities_summary` (`:376-387`): if `qr["vulnerabilities"]` is a list, count by lowercased `severity` (default `"unknown"`); if any → `{"total": len(vulns), "by_severity": severity_counts}`.
- `code_smells_summary` (`:389-400`): if `qr["code_smells"]` is a list, count by `str(s.get("type") or s.get("kind") or "unknown")`; if any → `{"total": len(smells), "by_type": type_counts}`.
- `out["quality"] = quality` only if `quality` non-empty (`:402-404`).
- `risk_tier` (`:406-411`): from `qr["risk_summary"]["tier"]` if `risk_summary` is dict and `tier` str in `{"1","2","3"}` → `out["risk_tier"] = tier`.

#### `_extract_ux_side_effects(ux)` — `discovery.py:416-469`
Returns `{}` if not dict. Column: `ux_assessment` (JSONB, reuses existing column, not a new `ux` twin).
- `personas_count`: `len(ux["personas"])` if list (`:430-432`).
- `adoption_baseline_summary` (`:434-445`): if `ux["adoption_baseline"]` dict non-empty → `total_users = sum(v.get("active_users",0) for v in adoption.values() if isinstance(v,dict))`; store `{"persona_count": len(adoption), "total_active_users": total_users}`.
- `accessibility_score` (`:447-459`): if `ux["accessibility_findings"]` is a list, count by lowercased severity; `critical = severities.get("critical",0)`, `serious = severities.get("serious",0)`; `accessibility_score = max(0, 100 - critical*10 - serious*5)`.
- `ui_inventory_summary`: if `ux["ui_inventory"]` list → `{"screen_count": len(ui_inventory)}` (`:461-463`).
- `ui_complexity_score`: `ux["ui_complexity_score"]` if int/float → float (`:465-467`).
- Returns `{"ux_assessment": assessment}` only if assessment non-empty (`:469`).

**GOTCHA:** `accessibility_score` derived here is 0–100 (from findings). This is distinct from the compliance-block `accessibility_score` at `_shared.py:236` which is read straight from `ux["accessibility_score"]` (a 0–1 fractional score) — two different sources for a similarly-named field.

#### `_extract_tco_side_effects(tco)` — `discovery.py:472-510`
Returns `{}` if not dict. Column: `tco` (JSONB).
- `annual_total`: `tco.get("annual_total") or tco.get("baseline_annual_usd")` if int/float → float (`:485-487`).
- `breakdown`: `tco.get("breakdown") or tco.get("cost_breakdown")` if dict non-empty → verbatim (`:489-491`).
- `formula_applied`: `tco.get("formula_applied") or tco.get("formula")` if str `.strip()` truthy → `.strip()` (`:493-495`).
- `confidence` (`:497-502`): if str in `{"high","medium","low"}` → stored; **elif `projected` already non-empty → default `"low"`** (best-effort). So confidence is only defaulted when other tco fields exist.
- `data_sources`: if `tco["data_sources"]` is a list → `[str(ds) for ds in data_sources if isinstance(ds,(str,int))]` (`:504-508`). Non-str/int members dropped; ints coerced to str.
- Returns `{"tco": projected}` only if projected non-empty (`:510`).

### 2.5 `_extract_discovery_compliance_metadata(quality_risk, ux_accessibility)` — `_shared.py:198-243`

**Always returns a non-empty block** (baseline seeded). Base block (`:214-218`):
```json
{"status": "pending-ato", "cato_state": "not-started", "source_line": "Discovery"}
```
- If `quality_risk` is dict and `quality_risk["vulnerabilities"]` is a list (`:220-230`): `critical = count of vulns whose severity (lowercased) in {"critical","high"}`; sets `sast_findings_count = len(vulns)`, `sast_critical_count = critical`.
- If `ux_accessibility` is dict and `ux_accessibility["accessibility_score"]` is int/float (`:233-241`): `accessibility_score = float(score)`; **if `float(score) < 0.85` → `status = "needs-review"`** (508-flavor, fractional 0–1 scale). Governance overwrites later.

**GOTCHA:** this block is always truthy, so `persist_discovery_side_effects` reaches step 7 (DB write) even when every column projection is empty — the compliance metadata alone guarantees a `metadata.compliance` merge on any invocation with a valid artifact set (unless BOTH projections and compliance were empty, which only happens if the base block itself is somehow falsy — it never is, so in practice the empty-return at `:568` triggers only when `parsed` yields empty AND... actually the base block is always non-empty, so the early return is effectively only reachable if `_extract_discovery_compliance_metadata` were to return `{}`, which it cannot given the unconditional base block). Re-reading: the early return requires `not compliance_metadata`; since the base block is unconditional, `compliance_metadata` is always truthy → **the early-return branch at `:568-574` is effectively dead in normal operation**; the activity always merges the compliance block.

### 2.6 `_merge_application_metadata(conn, app_uuid, namespace, payload)` — `_shared.py:453-503`

- No-op if `payload` empty (`:483-484`).
- `payload_with_meta = dict(payload)`; `setdefault("last_assessed", now-iso)` (`:485-488`) — so `last_assessed` is added only if the payload didn't already set it.
- `namespace_block = json.dumps({namespace: payload_with_meta})` (`:489`) — namespace is `"compliance"` here.
- UPDATE (`:493-502`):
  ```sql
  UPDATE application
     SET metadata = COALESCE(metadata, '{}'::jsonb) || $1::jsonb,
         updated_at = $2
   WHERE id = $3::uuid
  ```
  params: `namespace_block`, `datetime.now(timezone.utc)`, `app_uuid`.

**GOTCHA:** JSONB `||` merge is shallow at the top level — it **replaces the entire `compliance` namespace block**, not a deep merge. Callers must pass the full namespace shape; partial deltas would drop keys earlier writers set (`:474-477`). Other namespaces (e.g. `security`) are preserved because `||` only touches the `compliance` key. `COALESCE(metadata, '{}')` guards pre-051 NULL-metadata rows (`:490-492`).

### 2.7 Idempotency & retries
Idempotent: both the projection UPDATE and metadata merge are deterministic from inputs and overwrite in place. Re-running converges (only timestamps refresh). No decorator-level retry policy. Invalid `app_id` → NonRetryableError.

---

## 3. `persist_capability_catalog` — `discovery.py:637-993`

### 3.1 Signature & I/O
```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_capability_catalog(input: PersistCapabilityCatalogInput) -> PersistCapabilityCatalogOutput
```
UPSERTs the capability + system grain emitted by the `capability-extraction` skill (Discovery Pass-3) that Rationalization's consolidation recommender consumes. Replaces the one-shot `seed_capability_system_backfill.py` script (`types.py:1527-1533`).

**Input** `PersistCapabilityCatalogInput` (`types.py:1523-1551`):
- `app_id: str`
- `portfolio_id: str`
- `capability_catalog_json: str = ""`
- `capability_catalog_artifact_ref: str = ""` (logged for provenance only)
- `execution_context: StepExecutionContext | None = None`

**Output** `PersistCapabilityCatalogOutput` (`types.py:1554-1568`):
- `app_id: str`, `portfolio_id: str` (echoed from input)
- `system_persisted: bool = False`
- `system_application_persisted: bool = False`
- `business_domain_rows: int = 0` (count of NEW inserts only)
- `capability_rows: int = 0` (count of NEW inserts only)
- `capability_business_domain_rows: int = 0` (count of NEW edge inserts only)

Best-effort: malformed/missing-keys → logs and returns the zero-row `out` **without writing** (`:641-647`).

### 3.2 Control flow
1. `exec_id = emit_code_step_start(..., function_name="persist_capability_catalog")` (`:648-651`).
2. Construct `out = PersistCapabilityCatalogOutput(app_id=input.app_id, portfolio_id=input.portfolio_id)` (all row counts 0) (`:652-655`).
3. Parse `app_uuid = uuid.UUID(input.app_id)` → on `(ValueError,TypeError)` `NonRetryableError(f"Invalid app_id: ...")` (`:658-663`).
4. Parse `portfolio_uuid = uuid.UUID(input.portfolio_id)` → on error `NonRetryableError(f"Invalid portfolio_id: ...")` (`:664-669`).
5. `catalog = _try_parse_json(input.capability_catalog_json)` (`:671`).
6. `reason = _validate_capability_catalog(catalog)` (`:672`). If `reason` truthy (validation failed) (`:673-684`): `logger.info("persist_capability_catalog: skipping — %s", reason, extra={app_id, portfolio_id, artifact_ref})`; `emit_code_step_complete(exec_id, columns_written=[])`; `return out` (zero counts). **No DB connection opened.**
7. Extract legacy-system + role scalars (`:686-696`, see 3.4).
8. `conn = await asyncpg.connect(_db_url())`; `try: async with conn.transaction(): ...` (`:703-705`) — all writes atomic; `finally: await conn.close()` (`:962-963`).
9. On success: `emit_code_step_complete(exec_id, columns_written=[...])` (`:965-975`, see 3.9).
10. `except Exception as exc:` → `emit_code_step_complete(exec_id, status=FAILED, error=str(exc))`; `raise` (`:976-980`).
11. After try/except (success path): `logger.info("capability-catalog persisted", extra={...})` (`:982-992`); `return out` (`:993`).

### 3.3 `_validate_capability_catalog(catalog)` — `discovery.py:615-634`
Returns empty string when well-formed, else a human-readable reason:
- Not a dict → `"capability-catalog JSON did not parse to an object"` (`:620-621`).
- Required keys `_CAPABILITY_CATALOG_REQUIRED_KEYS = {"application_id","legacy_system","business_domains","capabilities"}` (`:610-612`); missing any → `f"capability-catalog missing required keys: {sorted(missing)}"` (`:622-624`).
- `legacy_system` must be a dict with truthy `name` else `"...requires a non-empty name"` (`:625-627`).
- `business_domains` must be a non-empty list (`:628-630`).
- `capabilities` must be a non-empty list (`:631-633`).

**GOTCHA:** `application_id` is a required key for validation but is never actually read/used — the `app_id`/`portfolio_id` come from the input dataclass, not the catalog.

### 3.4 Legacy-system + role scalars (`discovery.py:686-696`)
- `legacy = catalog["legacy_system"]`; `legacy_name = str(legacy["name"]).strip()`.
- `legacy_external_id = legacy.get("external_id")`; if str → `.strip() or None`; else `None` (`:688-692`).
- `legacy_description = legacy.get("description") or ""` (`:693`).
- `role_value = catalog.get("system_application_role") or "primary"`; if not in `("primary","contributing","deprecated")` → coerce to `"primary"` (`:694-696`).

### 3.5 `system` row (kind='legacy') — `discovery.py:706-775`

**Path A — external_id present** (`:707-729`): UPSERT keyed on `(portfolio_id, external_id)`:
```sql
INSERT INTO system (portfolio_id, name, kind, description, external_id)
VALUES ($1, $2, 'legacy', $3, $4)
ON CONFLICT (portfolio_id, external_id) WHERE external_id IS NOT NULL
DO UPDATE SET
    name = EXCLUDED.name,
    description = COALESCE(NULLIF(EXCLUDED.description, ''), system.description),
    updated_at = now()
RETURNING id
```
params: `portfolio_uuid, legacy_name, legacy_description, legacy_external_id`. On conflict, name is always refreshed; description only if new one non-empty (else keep existing).

**Path B — no external_id** (`:730-774`): the only unique index is the partial one on external_id, so it does a SELECT-then-INSERT on `(portfolio_id, name)`:
- SELECT `id FROM system WHERE portfolio_id=$1 AND name=$2 AND external_id IS NULL LIMIT 1` (`:735-745`).
- If `None` → INSERT `(portfolio_id, name, kind='legacy', description)` RETURNING id (`:746-758`).
- Else (found) → if `legacy_description` truthy, UPDATE `description = COALESCE(NULLIF($2,''), description), updated_at = now()` (`:759-774`); the found row id is reused.

`system_id = system_row["id"]`; `out.system_persisted = True` (`:775-776`).

**GOTCHA:** Path B is not atomic against concurrent inserts at the DB level (no unique constraint on `(portfolio_id, name)`), but the surrounding `conn.transaction()` + single-connection execution makes concurrent duplicate-name inserts from *this* activity unlikely; two concurrent activity runs could still both SELECT-miss and both INSERT, creating duplicate name rows.

### 3.6 `system_application` row — `discovery.py:778-792`
```sql
INSERT INTO system_application (system_id, application_id, role)
VALUES ($1, $2, $3)
ON CONFLICT (system_id, application_id) DO UPDATE SET role = EXCLUDED.role
```
params: `system_id, app_uuid, role_value`. `out.system_application_persisted = True` (`:792`).

### 3.7 `business_domain` rows — `discovery.py:794-852`
Builds `domain_id_by_name: dict[str, id]`. For each `domain` in `catalog["business_domains"]`:
- Skip if not a dict (`:797-798`); `name = str(domain.get("name") or "").strip()`; skip if empty (`:799-801`).
- `description = domain.get("description") or ""`; `external_id = domain.get("external_id")` str→`.strip() or None` else None (`:802-807`).
- SELECT `id FROM business_domain WHERE system_id=$1 AND name=$2 LIMIT 1` (`:809-817`).
- If `None` → INSERT `(system_id, name, description, external_id)` RETURNING id; `out.business_domain_rows += 1` (`:818-832`).
- Else → UPDATE `description = COALESCE(NULLIF($2,''),description), external_id = COALESCE($3,external_id), updated_at = now()` (`:834-850`); reuse existing row; **does NOT increment `business_domain_rows`** (count = new inserts only).
- `domain_id_by_name[name] = row["id"]` (`:852`).

**GOTCHA:** the natural key for `business_domain` is `(system_id, name)` via SELECT-then-INSERT (no ON CONFLICT), same non-atomicity caveat as system Path B.

### 3.8 `capability` rows + `capability_business_domain` edges — `discovery.py:854-961`
For each `cap` in `catalog["capabilities"]`:
- Skip if not dict; `cap_name = str(cap.get("name") or "").strip()`; skip if empty (`:856-860`).
- `cap_description = cap.get("description") or ""`; `cap_external_id` str→`.strip() or None` else None (`:861-866`).

**Path A — cap_external_id present** (`:868-890`): UPSERT keyed on `(system_id, external_id)`:
```sql
INSERT INTO capability (system_id, name, description, external_id, kind)
VALUES ($1, $2, $3, $4, 'legacy')
ON CONFLICT (system_id, external_id) WHERE external_id IS NOT NULL
DO UPDATE SET name = EXCLUDED.name,
             description = COALESCE(NULLIF(EXCLUDED.description,''), capability.description),
             updated_at = now()
RETURNING id, (xmax = 0) AS inserted
```
**GOTCHA:** `(xmax = 0) AS inserted` is the Postgres trick to distinguish a fresh INSERT (`xmax=0` → true) from an ON CONFLICT UPDATE (`xmax != 0` → false). Used to only count NEW capability rows.

**Path B — no cap_external_id** (`:891-930`): SELECT `id FROM capability WHERE system_id=$1 AND name=$2 AND external_id IS NULL LIMIT 1`:
- If `None` → INSERT `(system_id, name, description, kind='legacy')` RETURNING `id, true AS inserted` (`:903-915`).
- Else → if `cap_description` truthy, UPDATE `description = COALESCE(NULLIF($2,''),description), updated_at=now()` (`:916-929`); `cap_row = {"id": existing_cap["id"], "inserted": False}` (`:930`).

Then (`:932-934`): `if cap_row.get("inserted"): out.capability_rows += 1`; `cap_id = cap_row["id"]`.

**Edges** (`:936-961`): for each `domain_name` in `cap.get("business_domain_names") or []`:
- Skip if not str (`:941-942`); `domain_id = domain_id_by_name.get(domain_name.strip())`; if `None` → skip (`:943-945`). **GOTCHA:** referenced domain names not present in this catalog's `business_domains[]` are silently ignored (defensive; SKILL.md contract requires the reference to exist).
- INSERT edge:
  ```sql
  INSERT INTO capability_business_domain (capability_id, business_domain_id)
  VALUES ($1, $2)
  ON CONFLICT (capability_id, business_domain_id) DO NOTHING
  ```
- `result` is asyncpg command tag; **`if result and result.endswith(" 1"): out.capability_business_domain_rows += 1`** (`:946-961`). **GOTCHA:** asyncpg returns `"INSERT 0 1"` for a new edge, `"INSERT 0 0"` for a conflict-skip; the code keys on the trailing `" 1"` string to detect a genuine insert.

### 3.9 Success envelope + logging
`emit_code_step_complete(exec_id, columns_written=[...])` where the list is stringly-encoded counts (`:965-975`):
```
[f"system={int(out.system_persisted)}",
 f"system_application={int(out.system_application_persisted)}",
 f"business_domain={out.business_domain_rows}",
 f"capability={out.capability_rows}",
 f"capability_business_domain={out.capability_business_domain_rows}"]
```
Then `logger.info("capability-catalog persisted", extra={app_id, portfolio_id, system_persisted, business_domain_rows, capability_rows, capability_business_domain_rows})` (`:982-992`) and `return out`.

### 3.10 Idempotency & retries
Fully idempotent per the input contract (`types.py:1535-1544`): every table UPSERTed on its natural key (external_id-based partial index when present, else name-based). Re-running the same catalog produces the same rows and reports `0` new-insert counts on the second run (row counts reflect *this run's* new inserts only, not cumulative). The entire body runs inside a single `conn.transaction()`, so a mid-run failure rolls back all five table writes atomically. Invalid `app_id`/`portfolio_id` → NonRetryableError (terminal); validation failure → best-effort skip, returns zero-count `out`, no raise. No decorator-level retry policy — caller controls retries.

**GOTCHA (retry semantics):** because writes are transactional and idempotent, a Temporal retry of the whole activity is safe; but on a retry the returned `out` counts reflect only rows the retry newly inserted (typically all zero), so downstream consumers must not treat the counts as authoritative row totals.

---

## 4. Summary of what could be lost if not captured

- The exact enum allow-lists that gate scalar column writes (`complexity_tier`, `safety_tier`, `archetype`, `risk_tier`, `role`, `confidence`) — values outside the sets are silently dropped.
- The two distinct `accessibility_score` computations (0–100 findings-derived for `ux_assessment` vs 0–1 raw for the compliance block) and the `< 0.85` needs-review threshold.
- The `(xmax = 0)` insert-detection and asyncpg `" 1"` command-tag parsing for row-count reporting.
- The SELECT-then-INSERT natural-key upserts (system Path B, business_domain, capability Path B) that exist because the schema's only unique indexes are the partial external_id ones.
- The unconditional Discovery compliance baseline block (`pending-ato`/`not-started`) that makes `persist_discovery_side_effects` always merge `metadata.compliance`.
- `@foundry_activity` ignoring its own `ActivityConfig` timeout/retry/heartbeat fields — retry/timeout is caller-owned.
