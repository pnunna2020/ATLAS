# Activity group: `bundle_activities.py`

**Source of truth:** `temporal/olympus_workflows/activities/bundle_activities.py` (834 lines).
Companion service/model/schema layers this group calls into (all lazy-imported at call time):
- `olympus-api/src/services/bundle.py`
- `olympus-api/src/services/bundle_contract.py`
- `olympus-api/src/models/bundle.py`
- Migration DDL: `db/alembic/versions/057_create_delegated_bundle.py`, `063_bundle_dispatching_workflow.py`

This is Phase 5 W20 / Phase 6 W1 — the **delegated-bundles** feature: the workflow-side bridge into the bundle service layer. The design reference cited throughout the code is `specifications/phase-5/delegated-bundles-design.md` (§2.2, §3.3–§3.7, §4.1, §4.3, §5.3, §7.2, §9.0, §10, §12.2).

There are **6 `@foundry_activity`-decorated activity functions** in this module:

1. `load_portfolio_delegation_activity` — `bundle_activities.py:323`
2. `dispatch_delegated_bundle` — `bundle_activities.py:348`
3. `persist_bundle_gate_evidence` — `bundle_activities.py:537` *(persist\_\* activity)*
4. `resolve_dispatch_mode` — `bundle_activities.py:700`
5. `expire_due_bundles_activity` — `bundle_activities.py:765`

That is 5 decorated activities. The module also contains a set of **module-level helper functions** that are NOT activities but ARE load-bearing behavior called from inside the activities (`_build_async_database_url`, `_bundle_session`, `_profiles_root`, `load_fallback_policy_for_portfolio`, `_read_delegation_yaml`, `load_delegation_policy_for_portfolio`, `log_internal_fallback_stub`, `_build_bundle_evidence_data`). They are documented in full because the activities are meaningless without them.

> This module has **no Git activities** and **no agent-dispatch activities** (skill selection / retry-with-feedback). Those requirements (task items 3 and 4) are N/A for this group — bundles delegate work to *external human/agent pairs* via a DB-persisted contract, not via the internal agent-runtime. The dispatch here is "persist an `offered` bundle row"; there is no A2A call.

---

## 0. What `@foundry_activity` adds over raw `@activity.defn`

Decorator: `temporal/olympus_workflows/temporal_base/activities.py:79`. Every activity in this group is decorated exactly `@foundry_activity(config=ActivityConfig(enable_observability=True))` — no name override, no custom timeouts, no heartbeat set at the decorator (`bundle_activities.py:323,348,537,700,765`).

`ActivityConfig` defaults (`activities.py:41-53`):
- `retry_policy=None`, all 4 timeouts `None`, `heartbeat_timeout=None`
- `enable_observability=True`, `enable_error_wrapping=True`
- `log_inputs=False`, `log_outputs=False`

Wrapper behavior (`activities.py:97-148`):
1. Applies `@activity.defn(name=name, **activity_kwargs)` — **name defaults to `func.__name__`** and is preserved (Temporal replay keys on it). `activity_name = name or func.__name__` (`activities.py:103`).
2. **Observability** — stdlib `logging` (not structlog/Prometheus, safe outside sandbox):
   - Before body: `logger.info("Activity %s starting", ...)` with `extra={"inputs": args if log_inputs else None}` (`activities.py:106-110`). Since `log_inputs=False` for this whole group → `inputs=None`.
   - After success: `logger.info("Activity %s completed", ...)` with `extra={"outputs": result if log_outputs else None}` → `outputs=None` here (`activities.py:115-120`).
   - On exception: `logger.error("Activity %s failed: %s", activity_name, error, extra={"error": str(error)})` (`activities.py:126-131`).
3. **Error wrapping** (`enable_error_wrapping=True`, `activities.py:133-146`):
   - If the escaping error is already a `WorkflowError` or `temporalio` `ApplicationError` → `raise` unchanged (pass-through). **This is the path `HTTPException` DOES NOT take** — see GOTCHA below.
   - Else if `_is_retryable_error(error)` is True → wrap in `RetryableError(f"Retryable error in {activity_name}: {error}")`.
   - Else → wrap in `NonRetryableError(f"Non-retryable error in {activity_name}: {error}")`.
4. `_is_retryable_error` (`activities.py:56-76`): lowercases `str(type(error))` and returns True if it contains any of: `timeout`, `connection`, `network`, `temporary`, `unavailable`, `overload`, `busy`, `throttle`, `rate_limit`. **This is a type-NAME string match, not an instance check.**

**GOTCHA (error classification):** The service layer raises `fastapi.HTTPException` for domain errors (404 `BUNDLE_NOT_FOUND`, 400 `BUNDLE_UNKNOWN_GATE`, etc.). `HTTPException` is neither `WorkflowError` nor `ApplicationError`, and its type-name string `<class 'fastapi.exceptions.HTTPException'>` contains none of the retryable substrings → it gets wrapped as **`NonRetryableError`**. So a "gate not found" / "app not found" from a bundle activity is permanently non-retryable, which is correct (retrying won't create the missing row) but is an emergent property of the string heuristic, not an explicit decision.

**GOTCHA (retryable false-positives):** any exception whose *class name* happens to contain e.g. "connection" is auto-classified retryable regardless of true cause; `sqlalchemy`/`asyncpg` `ConnectionError`-family and `TimeoutError` correctly map retryable by name.

No heartbeat is configured, so **`persist_bundle_gate_evidence` and `expire_due_bundles_activity` must complete within the worker/registration default `start_to_close_timeout`** — they hold no heartbeat and cannot be canceled mid-loop cleanly. Retries are governed entirely by the workflow's per-activity `retry_policy` at the call site (not set here).

---

## 1. Database session factory (shared infra — used by every DB-touching activity)

### `_build_async_database_url() -> str` (`bundle_activities.py:70-83`)

Composes `postgresql+asyncpg://{user}:{encoded}@{host}:{port}/{name}` from component env vars (mirrors `olympus-api/src/config.py:get_async_database_url` — the worker NEVER reads a monolithic `DATABASE_URL`):
- `DATABASE_HOST` default `"localhost"` (`:77`)
- `DATABASE_PORT` default `"5432"` (`:78`)
- `DATABASE_NAME` default `"olympus"` (`:79`)
- `DATABASE_USER` default `"olympus"` (`:80`)
- `DATABASE_PASSWORD` default `"olympus"` (`:81`)
- Password is `urllib.parse.quote_plus(password)` URL-encoded (`:82`) per the database-connection-string-composition rule.

### `_bundle_session()` — async context manager (`bundle_activities.py:86-109`)

`@asynccontextmanager`, yields one `AsyncSession`. **Engine is created AND disposed per activity invocation** (`create_async_engine` at `:96`, `await engine.dispose()` in `finally` at `:108-109`). Engine args (`:98-103`): `pool_pre_ping=True`, `pool_recycle=300`, `pool_timeout=30`, `pool_size=2`, `max_overflow=2`. Factory: `async_sessionmaker(engine, expire_on_commit=False)` (`:104`). Session yielded via `async with factory() as session` (`:106-107`).

**GOTCHA (per-call engine):** Deliberately NOT pooled across activities — Temporal activities are short/infrequent and pool settings don't help across the activity boundary. Each activity call pays connection setup+teardown. The `async with` guarantees no session leak on exception; the `finally` guarantees engine disposal even if the body raises. Worker processes do NOT run `init_db`, so this cannot reuse the API's process-global `_async_session_factory` (`bundle_activities.py:33-39` docstring).

---

## 2. Delegation-policy loaders (helpers backing `load_portfolio_delegation_activity` and `resolve_dispatch_mode`)

### Constants
- `_DEFAULT_FALLBACK_POLICY = "internal_fallback"` (`:117`)
- `_VALID_FALLBACK_POLICIES = frozenset({"internal_fallback", "escalate", "fail", "redispatch"})` (`:118-120`)
- `_DEFAULT_DELEGATION_POLICY` (`:223-228`):
  ```python
  {"default_delegation": "disabled", "delegated_steps": [], "default_expires_hours": 168, "bundle_scope_kind": "gate_packet"}
  ```

### `_profiles_root() -> Path | None` (`:123-140`)
Locate the monorepo `profiles/` dir. Order: (1) if `OLYMPUS_PROFILES_DIR` env is set and `Path(it).is_dir()` → return it (`:130-134`); (2) else walk up from `Path(__file__).resolve()` through `(here, *here.parents)` returning the first `parent/"profiles"` that `.is_dir()` (`:135-139`); (3) else `None` (`:140`).

### `_read_delegation_yaml(profile_id: str | None) -> dict | None` (`:187-216`)
- `profile_id` falsy → `None` (`:194-195`).
- `_profiles_root()` is `None` → `None` (`:196-198`).
- `yaml_path = root / profile_id / "delegation.yaml"`; if not `.is_file()` → `None` (`:199-201`).
- `import yaml` (local import; pyyaml is a runtime dep), `yaml.safe_load(f) or {}` (`:203-206`).
- Any exception during load → `logger.warning("delegation.yaml load failed for profile %s: %s", ...)` then `None` (`:207-213`).
- If parsed value is not a `dict` → `None` (`:214-215`); else return the dict.

### `load_fallback_policy_for_portfolio(profile_id) -> str` (`:143-184`)
Reads `_read_delegation_yaml`. Resolution:
- `data is None` → `_DEFAULT_FALLBACK_POLICY` (`:169-170`).
- `policy = data.get("fallback_policy")`; if not a `str` → default (`:171-173`).
- `policy = policy.strip()` (`:174`).
- If `policy not in _VALID_FALLBACK_POLICIES` → `logger.warning("Unknown fallback_policy %r ...")` and return default (`:175-183`).
- Else return `policy` (`:184`).

Reads only the **top-level** `fallback_policy` key (backward-compat); the `delegation:` block is parsed separately.

### `load_delegation_policy_for_portfolio(profile_id) -> dict` (`:231-272`)
Returns a fully-normalized dict (starts from a copy of `_DEFAULT_DELEGATION_POLICY` so every key is always present — callers never `.get(default)`):
- `resolved = dict(_DEFAULT_DELEGATION_POLICY)` (`:248`).
- `data = _read_delegation_yaml(profile_id)`; `None` → return `resolved` (`:249-251`).
- `block = data.get("delegation")`; not a `dict` → return `resolved` (`:252-253`).
- `default_delegation`: overwritten **only if** value in `("enabled","disabled")` (`:256-258`).
- `delegated_steps`: if the value is a `list`, becomes `[str(s) for s in steps if s]` (drops falsy, stringifies each) (`:260-262`).
- `default_expires_hours`: overwritten only if `isinstance(int)` and `>= 1` (`:264-266`).
- `bundle_scope_kind`: overwritten only if value in `("gate_packet","line_step")` (`:268-269`).
- return `resolved` (`:272`).

The documented YAML shape (`:151-166`):
```yaml
fallback_policy: internal_fallback   # | escalate | fail | redispatch
delegation:
  default_delegation: disabled       # 'enabled' | 'disabled'
  delegated_steps: []                # explicit step_id list
  default_expires_hours: 168
  bundle_scope_kind: gate_packet     # 'gate_packet' | 'line_step'
```

### `log_internal_fallback_stub(*, bundle_id, scope_kind, target_id, portfolio_id, application_id, wave_id, fallback_policy, reason) -> None` (`:275-315`)
**STUB** (design §3.7): the real internal-fallback dispatcher is deferred to a follow-on PR. Emits a single `logger.warning("delegated-bundle.fallback.stub", extra={...})` with keys: `bundle_id, scope_kind, target_id, portfolio_id, application_id, wave_id, fallback_policy, reason, stub=True, todo="internal_fallback dispatcher not yet implemented; ..."` (`:298-315`). No dispatch, no DB write — operators hand-rerun the equivalent task.

---

## 3. Activity: `load_portfolio_delegation_activity` (`:323-340`)

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def load_portfolio_delegation_activity(profile_id: str | None) -> dict[str, Any]
```

**Input:** `profile_id` (nullable string).
**Reads:** `profiles/<profile_id>/delegation.yaml` from disk (via the two loaders).
**Writes:** none.
**Output** (`:337-340`):
```json
{"fallback_policy": "<str>", "delegation": { ... normalized delegation dict ... }}
```
Where `fallback_policy = load_fallback_policy_for_portfolio(profile_id)` and `delegation = load_delegation_policy_for_portfolio(profile_id)`.

**Why an activity:** file I/O must not live in workflow code (Temporal determinism); a line workflow calls this once at run start and caches the result (`:329-333` docstring).

**Idempotency:** pure read; fully idempotent, deterministic given the on-disk file.
**Errors/retries:** No explicit raises; a filesystem error inside the loaders is swallowed to `None`/default (they never raise). No custom retry_policy.

---

## 4. Activity: `dispatch_delegated_bundle` (`:348-453`)

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def dispatch_delegated_bundle(
    scope_kind: str, target_id: str, app_id: str | None, wave_id: str | None,
    expires_in_hours: int, fallback_policy: str, created_by_user_id: str,
) -> str
```

**Returns:** the new bundle id as a **`str`** (so it round-trips through Temporal payloads — `uuid.UUID` is not natively serializable; `:453`). Workflows use this id as the match key for `BundleCompletedSignal` / `BundleExpiredSignal`.

### Step-by-step (exact order — all validation is up-front so contract errors surface as activity-level `ValueError`):

1. **Lazy imports** (`:373-378`): `BundleFallbackPolicy`, `BundleScopeKind` from `src.models.bundle`; `bundle as bundle_svc` and `bundle_contract` from `src.services`. (Kept lazy to avoid eager FastAPI/structlog/models import at worker start — `:370-372`.)

2. **Scope validation** (`:382-388`): `scope = BundleScopeKind(scope_kind)`; on `ValueError` re-raise `ValueError(f"Unknown bundle scope_kind {scope_kind!r}; expected one of {[k.value for k in BundleScopeKind]}")`. Valid values: `gate_packet`, `line_step`.

3. **target_id validation** (`:390-391`): must be a non-empty (post-`.strip()`) string else `ValueError("target_id must be a non-empty string")`.

4. **Exactly-one-of app/wave** (`:393-397`): `if bool(app_id) == bool(wave_id): raise ValueError(...)`. **GOTCHA:** uses truthiness — passing `app_id=""` (empty string) counts as falsy, so `""` + a real `wave_id` is accepted; both set OR both empty → error.

5. **UUID coercion** (`:399-400`): `application_id_uuid = uuid.UUID(app_id) if app_id else None`; `wave_id_uuid = uuid.UUID(wave_id) if wave_id else None`. A malformed uuid string raises `ValueError` here → wrapped `NonRetryableError`.

6. **fallback_policy normalization** (`:402-410`): if `fallback_policy not in _VALID_FALLBACK_POLICIES` → warn + reset to `_DEFAULT_FALLBACK_POLICY` (`"internal_fallback"`). Then `fallback_enum = BundleFallbackPolicy(fallback_policy)`.

7. **Capture dispatching workflow_id** (`:417-420`, Phase 6 W1 §7.2.B):
   ```python
   try:
       dispatching_workflow_id = activity.info().workflow_id
   except RuntimeError:
       dispatching_workflow_id = None
   ```
   **GOTCHA:** `activity.info()` raises `RuntimeError` outside a Temporal activity context (e.g. direct integration test) → recorded as `None`, and the reaper then treats the bundle as admin-created (no signal, structured log only).

8. **DB work in one `_bundle_session()`** (`:422-437`):
   - `contract = await bundle_contract.resolve(db, scope_kind=scope, target_id=target_id, application_id=application_id_uuid, wave_id=wave_id_uuid)` — see §7 below.
   - `bundle_id = await bundle_svc.dispatch(db, contract=contract, fallback_policy=fallback_enum, expires_in_hours=expires_in_hours, created_by_user_id=created_by_user_id, dispatching_workflow_id=dispatching_workflow_id)` — see §6 below. `dispatch` commits internally.

9. **Structured log** `"delegated-bundle.dispatched"` with `extra={bundle_id, scope_kind, target_id, app_id, wave_id, expires_in_hours, fallback_policy, created_by_user_id, dispatching_workflow_id}` (`:439-452`).

10. **Return** `str(bundle_id)` (`:453`).

**Idempotency:** NOT idempotent — each call INSERTs a new bundle with a fresh `uuid.uuid4()`. A retry after a committed dispatch creates a *second* `offered` bundle, unless it collides with the `ux_bundle_one_open_per_scope` partial unique index (see §6/GOTCHA). Callers rely on the resolver's `active_bundle_exists`/Layer-(a) check (via `resolve_dispatch_mode`) to avoid double-dispatch, not on this activity being idempotent.

---

## 5. `bundle_contract.resolve` — the deterministic contract materializer (called by activity §4)

`olympus-api/src/services/bundle_contract.py:466-522`. Signature:
```python
async def resolve(db, *, scope_kind: BundleScopeKind, target_id: str,
                  application_id: uuid.UUID | None, wave_id: uuid.UUID | None) -> BundleContract
```

1. If both `application_id` and `wave_id` are None → `HTTPException(400, {"code":"BUNDLE_SCOPE_REQUIRED", ...})` (`:480-490`).
2. If `application_id` set: `portfolio_id, risk_tier = _resolve_app_metadata(db, application_id)` (reads `SELECT portfolio_id, risk_tier FROM application WHERE id = :aid`; 404 "Application not found" if missing — `:355-371`); `inputs = _default_inputs_for_app(...)`.
3. Else (`wave_id` set): `portfolio_id = _resolve_wave_metadata(db, wave_id)` (`SELECT portfolio_id FROM wave WHERE id = :wid`; 404 "Wave not found" — `:374-387`); `inputs = _default_inputs_for_wave(...)`; `risk_tier` stays None.
4. `outputs = _outputs_for(scope_kind, target_id)` (`:503`, see registry below).
5. Returns `BundleContract(scope_kind, target_id, inputs, outputs, metadata=BundleContractMetadata(portfolio_id, application_id, wave_id, risk_tier, gate_id=target_id if GATE_PACKET else None, step_id=target_id if LINE_STEP else None))` (`:505-522`).

### `_default_inputs_for_app` / `_default_inputs_for_wave` (`:390-463`)
Both run `SELECT p.artifact_repo_url AS portfolio_repo FROM application a JOIN portfolio p ON p.id=a.portfolio_id WHERE a.id=:aid` (app) or the wave analogue. If no row → `[]`. If `portfolio_repo` present → one `BundleArtifactRef(artifact_kind="artifact-repo", artifact_ref=<repo url>, description=<read-only handle text>)`. Otherwise `[]`. (Richer enumeration is roadmap; a single repo pointer is the whole input set today.)

### `_outputs_for(scope, target_id)` — the hardcoded gate/step → outputs registry (`:323-352`)
Data-driven Python dicts (NOT parsed from markdown). Each entry is a list of `BundleOutputRequirement(artifact_kind, schema_ref, required, description)`; `.model_copy()` is returned so callers can't mutate the registry (`:339,:352`).

- `GATE_PACKET`: if `target_id not in _GATE_OUTPUTS` → `HTTPException(400, {"code":"BUNDLE_UNKNOWN_GATE", "message": "... Known gates: {known_gate_targets()}"})` (`:325-337`).
- else (`LINE_STEP`): if `target_id not in _LINE_STEP_OUTPUTS` → `HTTPException(400, {"code":"BUNDLE_UNKNOWN_STEP", ...})` (`:340-351`).

**`_GATE_OUTPUTS` full contents** (`bundle_contract.py:66-257`) — every gate → its required output kinds (all `required=True`):

| Gate | Output kinds (schema_ref under `schemas/discovery/`) |
|---|---|
| `G-DC` | `application-catalog-entry`, `tech-fingerprint`, `analysis-report`, `discovery-synthesis` |
| `G-RR` | `capability-catalog` (`schemas/discovery/capability-catalog.schema.json`), `discovery-synthesis` |
| `G-DA` | `analysis-report`, `discovery-synthesis` |
| `G-DT` | `business-logic`, `business-rule-inventory` |
| `G-04a` | `business-rule-inventory`, `quality-risk` |
| `G-04b` | `analysis-report` |
| `G-04c` | `analysis-report` |
| `G-V1` | `analysis-report` |
| `G-V2` | `ux-accessibility`, `quality-risk` |
| `G-V3` | `quality-risk` |
| `G-DP-1` | `analysis-report` |
| `G-DP-2` | `analysis-report` |

**GOTCHA (intentionally omitted gates):** `G-02`, `G-DE-1`, `G-DE-2` are internal-only and **NOT** in the registry — dispatching a bundle against them raises 400 `BUNDLE_UNKNOWN_GATE` (`bundle_contract.py:55-60`). `G-DC`/`G-RR` are wave-scoped; the rest are app-scoped.

**`_LINE_STEP_OUTPUTS` full contents** (`bundle_contract.py:260-305`), all `required=True`:

| step_id | output kind |
|---|---|
| `discovery.catalog` | `application-catalog-entry` |
| `discovery.tech-fingerprint` | `tech-fingerprint` |
| `discovery.analysis` | `analysis-report` |
| `discovery.synthesis` | `discovery-synthesis` |
| `modernization.extract` | `business-rule-inventory` |
| `modernization.design` | `analysis-report` |

`known_gate_targets()` / `known_step_targets()` = `sorted(...keys())` (`:313-320`).

---

## 6. `bundle_svc.dispatch` — the persist path for §4 (artifact-JSON → DB rows)

`olympus-api/src/services/bundle.py:376-472`. Signature:
```python
async def dispatch(db, *, contract: BundleContract, fallback_policy: BundleFallbackPolicy,
                   expires_in_hours: int | None, created_by_user_id: str,
                   dispatching_workflow_id: str | None = None) -> uuid.UUID
```

`bundle_id = uuid.uuid4()` (`:400`). Then, table by table:

### Table `delegated_bundle` — one INSERT (`:403-430`)
Explicit columns inserted; `status` hardcoded `'offered'` in SQL text (`:412`). Field mapping:

| Column | Source | Notes |
|---|---|---|
| `id` | `bundle_id` (fresh uuid4) | |
| `portfolio_id` | `contract.metadata.portfolio_id` | NOT NULL |
| `application_id` | `contract.metadata.application_id` | nullable |
| `wave_id` | `contract.metadata.wave_id` | nullable |
| `scope_kind` | `contract.scope_kind.value` | `'gate_packet'`\|`'line_step'` |
| `target_id` | `contract.target_id` | |
| `status` | literal `'offered'` | (`:412`) |
| `fallback_policy` | `fallback_policy.value` | |
| `created_by_user_id` | `created_by_user_id` | NOT NULL |
| `dispatching_workflow_id` | `dispatching_workflow_id or None` | `""`→`None` (`:428`) |

Columns NOT written here (rely on DDL server defaults / nullability, migration 057): `claimed_by_user_id`=NULL, `claimed_at`=NULL, `expires_at`=NULL, `submitted_at`=NULL, `accepted_at`=NULL, `local_agent_descriptor`=NULL (until TTL stash below), `created_at`=`now()`, `updated_at`=`now()`.

### Table `delegated_bundle_input_ref` — one INSERT per `contract.inputs` (`:431-444`)
Columns `(bundle_id, artifact_kind, artifact_ref, description)` ← `inp.artifact_kind`, `inp.artifact_ref`, `inp.description`. (`id`, uniqueness `(bundle_id, artifact_ref)` from DDL.)

### Table `delegated_bundle_output_ref` — one INSERT per `contract.outputs` (`:445-459`)
Columns `(bundle_id, artifact_kind, schema_ref, required, description)` ← `out.artifact_kind`, `out.schema_ref`, `out.required`, `out.description`. `submitted_artifact_ref`/`submitted_at` left NULL until submit. Uniqueness `(bundle_id, artifact_kind)` from DDL.

### TTL stash (conditional) (`:462-470`)
If `expires_in_hours is not None`:
```sql
UPDATE delegated_bundle SET local_agent_descriptor =
  jsonb_build_object('_expires_in_hours', :hours) WHERE id = :id
```
**GOTCHA:** The dispatch-time TTL is stashed inside the `local_agent_descriptor` JSONB under key `_expires_in_hours` because `expires_at` is only computed at *claim* time. At claim, `bundle.claim` reads `descriptor.get("_expires_in_hours") or (24*7)` (`bundle.py:614`), computes `expires_at = _naive_utc_now() + timedelta(hours=...)`, and strips all `_`-prefixed keys when merging the claimer's descriptor (`bundle.py:618-620`). So the TTL travels in-band and never persists past claim.

`await db.commit()` (`:471`), return `bundle_id`.

**GOTCHA (`ux_bundle_one_open_per_scope`):** migration 057 (`db/alembic/versions/057_create_delegated_bundle.py:165-179`) creates a partial UNIQUE index on `(scope_kind, target_id, COALESCE(application_id, 0-uuid), COALESCE(wave_id, 0-uuid))` WHERE `status NOT IN ('expired','released','rejected','accepted')`. At most ONE open bundle per scope. A second `dispatch` for the same open scope raises a unique-violation (an `IntegrityError`) → propagates through the activity → `_is_retryable_error` sees no matching substring in `IntegrityError` → wrapped `NonRetryableError`.

`_naive_utc_now()` (`bundle.py:61-75`) — returns `datetime.now(timezone.utc).replace(tzinfo=None)`. **GOTCHA:** all lifecycle timestamps are `TIMESTAMP WITHOUT TIME ZONE` (migration 057) — asyncpg rejects tz-aware datetimes bound to naive columns, so UTC-then-drop-tzinfo is mandatory.

---

## 7. Activity: `persist_bundle_gate_evidence` (`:537-685`) — the `persist_*` activity

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def persist_bundle_gate_evidence(bundle_id: str, gate_type: str, app_id: str) -> dict[str, Any]
```

Bridges an **accepted** `gate_packet`-scoped bundle's outputs into the gate's `evidence_data` JSONB so the gate-review UI + W8 `CompliancePosture`/`CatoEvidence` surfaces render them identically to internal agent evidence (design §12.2, §10 Q5).

### Step-by-step (`:570-685`):

1. **Lazy imports:** `import json`; `from sqlalchemy import text`; `from src.services import bundle as bundle_svc` (`:570-573`).

2. `bundle_uuid = uuid.UUID(bundle_id)` (`:575`).

3. Open `_bundle_session()` (`:577`).

4. `detail = await bundle_svc.get_bundle(db, bundle_uuid)` (`:578`) — full envelope; raises `HTTPException(404, BUNDLE_NOT_FOUND)` if missing (`bundle.py:180-187`).

5. **Normalize outputs to plain dicts** (`:583-591`): for each `o in detail.outputs` (a `BundleOutputRefView`):
   ```python
   {"artifact_kind": o.artifact_kind,
    "submitted_artifact_ref": o.submitted_artifact_ref,
    "schema_ref": getattr(o, "schema_ref", None),
    "description": getattr(o, "description", None)}
   ```

6. `evidence_data = _build_bundle_evidence_data(bundle_id, gate_type, app_id, outputs)` (`:592-597`) — see §7a.

7. `output_count = len(evidence_data["steps"])` (`:598`) — number of *submitted* steps (only outputs with both `artifact_kind` and `submitted_artifact_ref` populate `steps`).

8. **Resolve the open gate row** (`:604-619`):
   ```sql
   SELECT id FROM gate
   WHERE application_id = :app_id AND gate_type = :gate_type
     AND status NOT IN ('approved','rejected','overridden')
   ORDER BY requested_at DESC LIMIT 1
   ```
   Params: `{"app_id": uuid.UUID(app_id), "gate_type": gate_type}`. **Targets the most-recently-requested non-terminal gate** so a stale closed gate from a prior rework cycle isn't hit.

9. **No open gate** (`gate_row is None`, `:621-638`): `logger.warning("delegated-bundle.gate-evidence.no-open-gate", ...)` and **return early**:
   ```json
   {"bundle_id": bundle_id, "gate_id": null, "gate_type": gate_type,
    "app_id": app_id, "output_count": output_count, "persisted": false}
   ```
   No DB write, no commit.

10. `gate_id = gate_row["id"]` (`:640`).

11. **Atomic JSONB merge UPDATE** (`:647-665`):
    ```sql
    UPDATE gate
    SET evidence_data = jsonb_set(
        COALESCE(evidence_data, '{}'::jsonb) || CAST(:ev AS jsonb),
        '{steps}',
        COALESCE(evidence_data -> 'steps', '{}'::jsonb) || CAST(:steps AS jsonb)
    )
    WHERE id = :gate_id
    ```
    Params: `{"ev": json.dumps(evidence_data), "steps": json.dumps(evidence_data["steps"]), "gate_id": gate_id}`.
    **Two-level merge:** the top-level `||` layers the full projected `evidence_data` over any existing keys (pre-review recommendation, criteria) — this would *replace* `steps` wholesale; so `jsonb_set` then re-writes `{steps}` to the union of the pre-existing `steps` object and the new bundle steps, making the merge additive *within* `steps`. Mirrors `store_gate_pre_review`.

12. `await db.commit()` (`:666`).

13. `logger.info("delegated-bundle.gate-evidence.persisted", extra={bundle_id, gate_id=str, gate_type, app_id, output_count})` (`:668-677`).

14. **Return** (`:678-685`):
    ```json
    {"bundle_id": bundle_id, "gate_id": "<uuid str>", "gate_type": gate_type,
     "app_id": app_id, "output_count": output_count, "persisted": true}
    ```

**Idempotency:** "Idempotent-ish" (`:566-568`) — re-running merges the same projected steps over the existing payload; `||` overwrites matching keys so a retry converges rather than duplicating (step keys are `bundle:<kind>`, deterministic per output kind).

**Errors/retries:** `get_bundle` 404 → `HTTPException` → wrapped `NonRetryableError`. `uuid.UUID(app_id)` on malformed input → `ValueError` → `NonRetryableError`. A transient DB error (name matches "connection"/"timeout") → `RetryableError`. No custom retry_policy at decorator.

### 7a. `_build_bundle_evidence_data(bundle_id, gate_type, app_id, outputs) -> dict` (`:461-534`)

Projects accepted outputs into the canonical `evidence_data.steps[*].file_artifacts` shape that every non-Discovery line emits via `_build_evidence_data` in `workflows/base.py`.

- `steps: dict[str, dict] = {}`, `submitted_kinds: list[str] = []` (`:487-488`).
- For each `out` in `outputs` (`:489-519`):
  - `kind = out.get("artifact_kind")`, `ref = out.get("submitted_artifact_ref")`.
  - **`if not kind or not ref: continue`** (`:492-493`) — skip optional/unsubmitted slots. An accepted bundle always has every *required* output filled; empties are skipped, not rendered as empty cards.
  - `submitted_kinds.append(kind)`.
  - `step_name = f"bundle:{kind}"` (`:495`).
  - `steps[step_name]` = (`:496-519`):
    ```json
    {
      "title": "<kind>",
      "description": "<out.description or ''>",
      "output": "Delegated-bundle output (<kind>)",
      "metadata": {"source": "delegated_bundle", "bundle_id": "<bundle_id>",
                   "artifact_kind": "<kind>", "schema_ref": "<out.schema_ref or ''>"},
      "file_artifacts": [{"path": "<ref>", "encoding": "utf-8", "size": 0}]
    }
    ```
    `path` is the submitted ref (slim — API hydrates content on demand, matching internal agent evidence). `size: 0` is the deliberate slim placeholder.
- Returns (`:521-534`):
  ```json
  {
    "assembly_line": "delegated-bundle",
    "app_id": "<app_id>",
    "current_step": "<gate_type>",
    "steps": { ... },
    "bundle": {"bundle_id": "<bundle_id>", "gate_type": "<gate_type>",
               "submitted_output_kinds": [ ...submitted_kinds... ]}
  }
  ```
  The `bundle` provenance block (design §12.2) lets compliance/gate surfaces badge evidence as pair-sourced and link back to the bundle.

---

## 8. Activity: `resolve_dispatch_mode` (`:700-757`) — the §2.2 layered trigger evaluator

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def resolve_dispatch_mode(
    scope_kind: str, target_id: str, app_id: str | None, wave_id: str | None,
    profile_id: str | None, is_delegatable: bool) -> str
```

Returns one of the plain-string constants (`:696-697`, kept as strings not an enum to round-trip cleanly through Temporal payloads):
- `DISPATCH_MODE_INTERNAL_AGENT = "internal_agent"`
- `DISPATCH_MODE_DELEGATED_BUNDLE = "delegated_bundle"`

Deterministic, observable, no ML routing. Layered evaluation in this exact order:

1. **Layer (b) — eligibility gate** (`:730-731`): `if not is_delegatable: return "internal_agent"`. A non-delegatable step is NEVER delegated regardless of higher layers.

2. **Lazy import** `from src.services import bundle as bundle_svc` (`:733`); coerce `application_id_uuid`/`wave_id_uuid` from the string args (`:735-736`).

3. **Layer (a) — open bundle wins** (`:738-748`): open `_bundle_session()`, call
   ```python
   exists = await bundle_svc.active_bundle_exists(db, scope_kind=scope_kind, target_id=target_id,
                                                  application_id=application_id_uuid, wave_id=wave_id_uuid)
   ```
   if `exists: return "delegated_bundle"`.

   `active_bundle_exists` (`bundle.py:321-368`): SQL `SELECT 1 FROM delegated_bundle WHERE scope_kind=:sk AND target_id=:tid AND status NOT IN ('expired','released','rejected','accepted')` plus **exactly one** of `application_id = :app_id AND wave_id IS NULL` or `wave_id = :wave_id AND application_id IS NULL`; if BOTH ids are None → returns `False` immediately (`:359-360`). This is the same predicate as `ux_bundle_one_open_per_scope`. **GOTCHA:** an app-scoped open bundle never matches a wave-scoped query for the same `target_id` (the `IS NULL` on the other id enforces disjointness).

4. **Layer (c) — portfolio default policy** (`:750-755`): `policy = load_delegation_policy_for_portfolio(profile_id)` (reads `delegation.yaml`; degrades to all-disabled default).
   - `if policy.get("default_delegation") == "enabled": return "delegated_bundle"` (delegate every eligible step).
   - `if target_id in (policy.get("delegated_steps") or []): return "delegated_bundle"`.

5. **Default** (`:757`): `return "internal_agent"`.

**Why an activity:** Layer (a) needs a DB read and Layer (c) reads disk — both I/O, so it can't be a pure workflow helper (`:726-728`).

**Idempotency:** pure read; idempotent/deterministic given DB + on-disk config state.

---

## 9. Activity: `expire_due_bundles_activity` (`:765-833`) — the reaper sweep

```python
@foundry_activity(config=ActivityConfig(enable_observability=True))
async def expire_due_bundles_activity() -> list[dict[str, str]]
```

No inputs. Used by the bundle-reaper cron workflow (15-min cadence, design §3.6). Returns a list of `{"bundle_id": str, "workflow_id": str}` rows so the cron workflow can fire `BundleExpiredSignal` at each dispatching workflow.

### Step-by-step (`:784-833`):

1. Lazy imports: `from sqlalchemy import text`; `from src.services import bundle as bundle_svc` (`:784-785`).

2. `expired: list[dict[str,str]] = []`; open ONE `_bundle_session()` for the whole sweep (both queries share the session for a consistent view — `:787-788`, `:781-782` docstring).

3. `bundle_ids = await bundle_svc.expire_due_bundles(db)` (`:789`).
   `expire_due_bundles` (`bundle.py:1005-1025`): `UPDATE delegated_bundle SET status='expired', updated_at=:now WHERE status='claimed' AND expires_at < :now RETURNING id`, then `db.commit()`, returns the list of expired ids. **Only `claimed` bundles past `expires_at` transition** — `offered`/`submitted` are untouched. `now = _naive_utc_now()`.

4. **For each expired `bid`** (`:790-827`):
   - Post-fetch metadata (`:791-801`):
     ```sql
     SELECT scope_kind, target_id, portfolio_id, application_id, wave_id,
            fallback_policy, dispatching_workflow_id
     FROM delegated_bundle WHERE id = :bid
     ```
   - `if row is None: continue` (`:802-803`).
   - `workflow_id = row.get("dispatching_workflow_id") or ""` (`:804`).
   - **If no workflow_id** (admin-created / pre-063 bundle, `:805-821`): call `log_internal_fallback_stub(bundle_id=str(bid), scope_kind=row["scope_kind"], target_id=row["target_id"], portfolio_id=str(row["portfolio_id"]) if row.get("portfolio_id") else None, application_id=str(row["application_id"]) if row.get("application_id") else None, wave_id=str(row["wave_id"]) if row.get("wave_id") else None, fallback_policy=row["fallback_policy"], reason="expired")`. There's no parent workflow to signal, so the structured operator log is the only fallback behavior.
   - Always append `{"bundle_id": str(bid), "workflow_id": workflow_id}` to `expired` (`:822-827`) — **including** the empty-workflow_id case (the reaper *workflow* skips empty ids when signaling — `:808-809` docstring).

5. If `expired`: `logger.info("delegated-bundle.reaper.expired-batch", extra={"count": len(expired)})` (`:828-832`).

6. Return `expired` (`:833`).

**GOTCHA (`dispatching_workflow_id` provenance):** column added in migration 063 (`db/alembic/versions/063_bundle_dispatching_workflow.py`). Bundles created before 063, or via manual admin dispatch (`dispatch_from_kickoff` passes `dispatching_workflow_id=None` — `bundle.py:543`), have NULL here → `""` → structured-log path instead of a Temporal signal.

**Idempotency:** idempotent across retries by construction — `expire_due_bundles` only transitions `status='claimed'` rows, so a re-run after a partial failure re-selects only bundles still `claimed`+expired; already-`expired` bundles are excluded by the WHERE clause. The per-bundle stub log CAN re-fire on retry (double log), but that's benign (no state).

**Errors/retries:** transient DB errors → name-matched to `RetryableError` where applicable, else `NonRetryableError`. No custom retry_policy at the decorator; the reaper cron workflow controls retry via its call-site `retry_policy`.

---

## 10. Cross-cutting GOTCHAs summary

- **No agent-dispatch / no Git activities in this group.** Delegation targets external human/agent pairs through DB-persisted contracts + signals, not the internal agent-runtime or Git PR machinery.
- **`HTTPException` → `NonRetryableError`.** Domain 4xx from the service layer never reaches the workflow as an `HTTPException`; it is wrapped non-retryable by the decorator (§0). Workflow code must not `except HTTPException`.
- **Per-call engine.** Every DB-touching activity spins up and disposes its own asyncpg engine (§1). High connection churn is intentional and acceptable given low activity frequency.
- **TTL travels in `local_agent_descriptor._expires_in_hours`** at dispatch and is consumed+stripped at claim (§6).
- **Naive UTC timestamps** everywhere for the bundle lifecycle columns (§6).
- **`activity.info()` may raise `RuntimeError`** outside a workflow context; `dispatch_delegated_bundle` swallows it to `None` (§4 step 7).
- **`bool(app_id) == bool(wave_id)` truthiness check** treats `""` as "unset" (§4 step 4).
- **Registry-omitted internal gates** (`G-02`, `G-DE-1`, `G-DE-2`) raise 400 on dispatch (§5).
- **Open-scope unique index** (`ux_bundle_one_open_per_scope`) makes a duplicate dispatch a hard integrity error, not a silent second row (§6).
