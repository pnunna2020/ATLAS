# Activity group: misc-activities

Atomic regeneration spec for the activity group:

- `temporal/olympus_workflows/activities/renditions.py`
- `temporal/olympus_workflows/activities/wave_operations.py`
- `temporal/olympus_workflows/activities/human_task_activities.py`
- `temporal/olympus_workflows/activities/drift_detection.py`
- `temporal/olympus_workflows/activities/traceability.py`

All activities are decorated with `@foundry_activity` — see §0 for the exact wrapper behavior every activity in this group inherits.

Bar: **behavioral parity**. Every SQL statement, field mapping, default, guard, and typed-error mapping below is reproduced from live code; rebuild to match exactly.

---

## 0. `@foundry_activity` wrapper — inherited by EVERY activity in this group

Source: `temporal/olympus_workflows/temporal_base/activities.py:79-150`. All 7 activities in this group are decorated `@foundry_activity(config=ActivityConfig(enable_observability=True))` — the identical call shape (`renditions.py:287`, `wave_operations.py:48,130,236`, `human_task_activities.py:85`, `drift_detection.py:64,123`).

### 0.1 `ActivityConfig` dataclass (`activities.py:41-53`)
Fields, all defaulting as shown:
- `retry_policy: RetryPolicy | None = None`
- `start_to_close_timeout: timedelta | None = None`
- `schedule_to_close_timeout: timedelta | None = None`
- `schedule_to_start_timeout: timedelta | None = None`
- `heartbeat_timeout: timedelta | None = None`
- `enable_observability: bool = True`
- `enable_error_wrapping: bool = True`
- `log_inputs: bool = False`
- `log_outputs: bool = False`

**GOTCHA:** the timeout/retry_policy/heartbeat fields on `ActivityConfig` are declared but the wrapper (`activities.py:97-148`) does **NOT** forward any of them to `@activity.defn` — it only passes `name` and `**activity_kwargs` (line 100). None of the 7 activities in this group set a retry_policy or timeout via config; those are set by the *caller* workflow's `execute_activity(...)` options, not here. The `ActivityConfig(enable_observability=True)` call therefore configures ONLY the observability + error-wrapping behavior.

### 0.2 What the wrapper does at runtime (`activities.py:97-148`)
1. Computes `activity_config = config or ActivityConfig()` (line 98).
2. Applies `@activity.defn(name=name, **activity_kwargs)` then `@wraps(func)` (lines 100-101). Since all callers pass `name=None`, the activity name is the wrapped function's `__name__` (Temporal replay keys on this — do NOT rename functions without breaking replay).
3. `activity_name = name or func.__name__` (line 103).
4. If `enable_observability`: `logger.info("Activity %s starting", activity_name, extra={"inputs": args if log_inputs else None})` (lines 105-110). Since `log_inputs=False` default, `inputs` is `None`.
5. `result = await func(*args, **kwargs)` (line 113).
6. On success + observability: `logger.info("Activity %s completed", ... extra={"outputs": result if log_outputs else None})` (lines 115-120). `log_outputs=False` default → `outputs` is `None`.
7. Returns `result` (line 122).
8. On any `Exception` (lines 124-146):
   - If observability: `logger.error("Activity %s failed: %s", activity_name, error, extra={"error": str(error)})` (lines 125-131).
   - If `enable_error_wrapping` (default True):
     - `isinstance(error, (WorkflowError, ApplicationError))` → `raise` unchanged (line 135-136). (Already-typed Temporal errors pass through.)
     - elif `_is_retryable_error(error)` → `raise RetryableError(f"Retryable error in {activity_name}: {error}") from error` (lines 137-140).
     - else → `raise NonRetryableError(f"Non-retryable error in {activity_name}: {error}") from error` (lines 141-144).
   - else (`enable_error_wrapping=False`, not used here): bare `raise` (line 146).

### 0.3 `_is_retryable_error` heuristic (`activities.py:56-76`)
**GOTCHA (fragile, string-match on TYPE name):** classifies by `str(type(error)).lower()` substring match against: `"timeout"`, `"connection"`, `"network"`, `"temporary"`, `"unavailable"`, `"overload"`, `"busy"`, `"throttle"`, `"rate_limit"` (lines 65-75). This is *distinct* from `errors.is_retryable_error` (which inspects instances). Implications for this group:
- `asyncpg` connection failures whose exception class name contains "connection"/"timeout" → wrapped as `RetryableError`.
- A raw `ValueError` (e.g. `uuid.UUID(bad)` deep in a body, or `dispatch_human_task`'s validation) → type name is `"<class 'ValueError'>"`, matches none → wrapped as `NonRetryableError`.
- `NonRetryableError`/`RetryableError` are `ApplicationError` subclasses (`errors.py`), so if a body itself raises them they pass through via the `ApplicationError` branch unchanged.

`RetryableError` / `NonRetryableError` / `WorkflowError` imported from `.errors` (`activities.py:36`).

### 0.4 Heartbeat
No activity in this group calls `activity.heartbeat(...)`. No heartbeat_timeout is configured. All are single-shot short DB writes / pure computations.

---

## 1. `renditions.py`

Module purpose (`renditions.py:1-25`): renders a stakeholder-facing markdown doc (requirements doc / architecture deck / test report) from an app's committed factory artifacts (read from Git `main`) and persists to the `rendition` table. Replaces a prior stub that hardcoded `status="completed"` and rendered nothing.

### 1.1 `_db_url()` (`renditions.py:49-56`)
Returns `postgresql://{user}:{password}@{host}:{port}/{db}` from env vars with defaults: `DATABASE_HOST=localhost`, `DATABASE_PORT=5432`, `DATABASE_USER=olympus`, `DATABASE_PASSWORD=olympus`, `DATABASE_NAME=olympus`. **No password URL-encoding** here (contrast with human_task_activities §3.1 which uses `quote_plus`).

### 1.2 Helper functions (pure, no I/O — unit-testable)

**`_read_json_artifact(repo, app_id, path) -> dict | None`** (`renditions.py:59-78`):
- If `not repo` → return `None` (line 65-66). (Empty repo string → no read.)
- Calls `await read_artifact(ReadArtifactInput(repo=repo, branch="main", path=path))` (lines 68-70) — imported from `activities.git_operations` (line 37).
- **GOTCHA:** any exception from `read_artifact` (missing file expected) is caught, logged `INFO "rendition: artifact %s not available: %s"`, returns `None` (lines 71-73). A missing artifact is NON-fatal by design (partially-analyzed app still renders).
- Parses `json.loads(result.content)` (line 75). On `(ValueError, TypeError)` → logs `WARNING "rendition: artifact %s is not valid JSON"`, returns `None` (lines 76-78).
- Note `app_id` param is accepted but unused inside the body (path already carries it).

**`_as_list(value) -> list`** (`renditions.py:81-82`): returns `value` if `isinstance(value, list)` else `[]`.

**`_as_dict(value) -> dict`** (`renditions.py:85-86`): returns `value` if `isinstance(value, dict)` else `{}`.

**`_cell(value) -> str`** (`renditions.py:89-100`): markdown-table cell sanitiser. `text = "" if value is None else str(value)`; then `" ".join(text.split())` (collapses all whitespace/newlines to single spaces); then `.replace("|", "\\|")` (escapes pipes). **GOTCHA:** without this, free-form business-rule prose containing `|` or newlines corrupts the GFM table.

**`_source_ref(rule) -> str`** (`renditions.py:103-119`): builds a `file:line` ref.
- `trace = _as_dict(rule.get("source_traceability"))`; `primary = trace.get("primary_file")`.
- If `primary` is a non-empty str: `line_range = trace.get("line_range")`; return `f"{primary}:{line_range}"` if `line_range` truthy else `primary` (lines 111-114).
- Else, for `key in ("source_ref", "source")`: if `rule.get(key)` is a non-empty str, return it (lines 115-118).
- Else return `"—"` (em-dash, line 119).

**`_map_requirements_doc(*, application_name, generated_at, synthesis, business_logic) -> dict`** (`renditions.py:122-220`): maps Discovery artifacts → `requirements_doc` template data. EXACT output shape (line 212-220):
```
{
  "application_name": application_name or "Unknown Application",
  "generated_at": generated_at,
  "version": "1.0",
  "executive_summary": <str>,
  "business_rules": [ {id, domain, description, source_ref, confidence}, ... ],
  "test_scenarios": [ {category, scenarios:[{id,name,type,priority,expected_outcome},...]}, ... ],
  "cross_validation": {total_findings, coverage, conflicts, notes:[str,...]},
}
```
Field-by-field derivation:
- `syn = _as_dict(synthesis)`; `bl = _as_dict(business_logic)`; `syn_summary = _as_dict(syn.get("summary"))` (lines 148-150).
- `executive_summary = syn_summary.get("system_classification") or "No analysis summary available yet for this application."` (lines 152-154).
- `rules = _as_list(bl.get("rules"))` (line 156). For each `r` (re-wrapped `r = _as_dict(r)`, line 160):
  - `category = r.get("category") or "Uncategorized"` (line 161).
  - Append to `rules_out` (lines 162-170): `id = _cell(r.get("id","—"))`, `domain = _cell(category)`, `description = _cell(r.get("description") or r.get("name","—"))`, `source_ref = _cell(_source_ref(r))`, `confidence = _cell(r.get("severity") or r.get("complexity","—"))`.
  - `hints = _as_dict(r.get("test_hints"))`; `happy = hints.get("happy_path")` (lines 174-175). If `happy` is a non-empty (stripped) str → append to `scenarios_by_category[category]` (lines 176-185): `id=_cell(r.get("id","—"))`, `name=_cell(r.get("name") or r.get("description","—"))`, `type="happy_path"` (literal), `priority=_cell(r.get("severity","—"))`, `expected_outcome=_cell(happy)`.
  - `test_scenarios = [{"category": cat, "scenarios": scs} for cat, scs in scenarios_by_category.items()]` (lines 186-189). **GOTCHA (ordering):** iterates dict insertion order — category order follows first-seen rule order.
- Cross-validation rollup (lines 193-210):
  - `totals = _as_dict(bl.get("totals"))`; `contradictions = _as_list(syn.get("contradictions"))`; `key_findings = _as_list(syn_summary.get("key_findings"))`.
  - `notes = [_cell(f) for f in key_findings if isinstance(f, str) and f.strip()]` (line 196). **GOTCHA:** `notes` MUST be a list — template iterates it; a bare string would render one char per line (comment lines 191-192).
  - `covered = totals.get("packages_covered")`; `total_pkgs = totals.get("packages_total")`.
  - `coverage = f"{covered}/{total_pkgs} packages analyzed"` if BOTH are not None, else `f"{len(rules_out)} rule(s) extracted"` (lines 200-204).
  - `cross_validation = {"total_findings": totals.get("total_rules", len(rules_out)), "coverage": coverage, "conflicts": len(contradictions), "notes": notes}` (lines 205-210).

**`_build_template_data(rendition_type, *, application_name, generated_at, artifacts) -> dict`** (`renditions.py:223-251`): dispatch.
- If `rendition_type == "requirements_doc"` → `_map_requirements_doc(...)` with `synthesis=artifacts.get("synthesis")`, `business_logic=artifacts.get("business_logic")` (lines 235-241).
- Else (architecture_deck / test_report — generic fallback, lines 245-251): `syn_summary = _as_dict(_as_dict(artifacts.get("synthesis")).get("summary"))`; returns `{"application_name": application_name or "Unknown Application", "generated_at": generated_at, "version": "1.0", "executive_summary": syn_summary.get("system_classification", "")}`.

**`_artifact_paths(app_id) -> dict[str,str]`** (`renditions.py:260-265`): `base = f"discovery/{app_id}/files"`; returns:
```
{
  "synthesis": f"{base}/synthesis/discovery-synthesis.json",
  "business_logic": f"{base}/business-logic-extraction/business-logic.json",
}
```
**GOTCHA (docstring lines 254-259):** the committed top-level `discovery/{app_id}/<pass>.json` are agent *envelopes* (prose); the schema-shaped data lives under `discovery/{app_id}/files/{pass_id}/{file}`; the synthesis DATA file is `discovery-synthesis.json`, NOT `synthesis.json`.

**`_render(input) -> str`** (`renditions.py:268-284`, no DB write):
- Builds `artifacts = {name: await _read_json_artifact(input.artifact_repo, input.app_id, path)}` for each `(name, path)` in `_artifact_paths(input.app_id)` (lines 270-274). Sequential (not gathered).
- `generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")` (line 276). **GOTCHA (non-determinism):** wall clock captured in the activity (fine — activity side, not workflow). Format is minute-precision UTC.
- `data = _build_template_data(input.rendition_type, application_name=input.application_name, generated_at=generated_at, artifacts=artifacts)` (lines 277-282).
- `engine = RenditionEngine()`; return `engine.render_markdown(input.template_name, data)` (lines 283-284).

### 1.3 `RenditionEngine` (`temporal/olympus_workflows/renditions/engine.py`)
- `TEMPLATES_DIR = Path(__file__).parent / "templates"` (engine.py:9).
- `__init__(templates_dir=None)`: Jinja2 `Environment(loader=FileSystemLoader(str(templates_dir or TEMPLATES_DIR)), autoescape=False, trim_blocks=True, lstrip_blocks=True, keep_trailing_newline=True)` (engine.py:20-28). **GOTCHA:** `autoescape=False` (markdown output, not HTML); `trim_blocks`+`lstrip_blocks`+`keep_trailing_newline` all True — reproduce exactly for byte-identical output.
- `list_templates()`: `sorted(self._env.list_templates(extensions=["j2"]))` (engine.py:30-32).
- `render_markdown(template_name, data)`: `self._env.get_template(template_name).render(data=data)` (engine.py:34-48). **GOTCHA:** template variable is `data` (single dict) — templates reference `data.foo`. Raises `jinja2.TemplateNotFound` if missing.

### 1.4 `render_rendition(input: RenderRenditionInput) -> RenderRenditionResult` — ACTIVITY (`renditions.py:287-332`)
Signature: `async def render_rendition(input: RenderRenditionInput) -> RenderRenditionResult`.

`RenderRenditionInput` (`types.py:583-601`): `rendition_id: str`, `app_id: str`, `rendition_type: str` (requirements_doc|architecture_deck|test_report), `template_name: str`, `artifact_repo: str`, `application_name: str = ""`.

`RenderRenditionResult` (`types.py:603-610`): `rendition_id: str`, `status: str` (completed|failed), `content_length: int = 0`, `error: str = ""`.

Body:
1. **Dict coercion:** `if isinstance(input, dict): input = RenderRenditionInput(**input)` (lines 296-297). Handles Temporal deserializing to dict.
2. `now = datetime.now(timezone.utc)` (line 299).
3. `try: content = await _render(input); status, error = "completed", ""` (lines 300-302).
4. **GOTCHA (best-effort render):** `except Exception as exc:` → `logger.exception(...)`; `content, status, error = "", "failed", str(exc)[:1000]` (lines 303-305). Error truncated to 1000 chars. The activity does NOT re-raise render failures — it records `failed` and returns normally, so the UI flow never crashes. This means render failures are NOT surfaced to Temporal retry; only DB-write failures (below) are.
5. **DB write** (lines 307-325): `conn = await asyncpg.connect(_db_url())`; then in `try/finally` (finally: `await conn.close()`):
   ```sql
   UPDATE rendition
      SET status = $2, content = $3, error = $4, completed_at = $5
    WHERE id = $1
   ```
   Params: `$1 = uuid.UUID(input.rendition_id)`, `$2 = status`, `$3 = content or None` (empty string → SQL NULL), `$4 = error or None` (empty → NULL), `$5 = now`.
   **GOTCHA:** if the DB connection/write fails, that exception escapes the activity (not caught) → `@foundry_activity` wraps it (RetryableError if class name matches connection/timeout, else NonRetryableError). Only the *render* step is best-effort; the *persist* step is not.
6. Returns `RenderRenditionResult(rendition_id=input.rendition_id, status=status, content_length=len(content), error=error)` (lines 327-332). Note `content_length = len(content)` (0 on failure).

**Idempotency:** UPDATE keyed on `id`; re-running overwrites the same row (idempotent). No row created here — the `rendition` row must pre-exist (created by API/workflow before dispatch).

---

## 2. `wave_operations.py`

Module purpose (`wave_operations.py:1-11`): wave-scoped DB projections (task #104), writing to `wave` (not `application`). Separate from `line_transitions` per-app pattern.

`_db_url()` (`wave_operations.py:33-45`): identical to renditions §1.1 (same env defaults, no URL-encoding). Duplicated deliberately so the module has no cross-activity-file imports (comment lines 34-39).

### 2.1 `persist_wave_failure(input: PersistWaveFailureInput) -> None` — ACTIVITY (`wave_operations.py:48-122`)
`PersistWaveFailureInput` (`types.py:1740-1758`): `wave_id: str`, `reason: str = ""`, `workflow_id: str = ""`.

Purpose: transition a wave to `status='failed'` + record failure metadata. Called from `WaveRationalizationWorkflow` outer `try/except` on non-retryable unwind. Migration 042 (`wave_failed_status`) added `'failed'` to the wave CHECK constraint plus `failed_at` + `failure_reason` columns.

Body:
1. `if not input.wave_id:` → `logger.warning("persist_wave_failure called with empty wave_id — skipping")`; **return** (lines 79-81). No-op.
2. `try: wave_uuid = uuid.UUID(input.wave_id)` except `(ValueError, TypeError):` → `logger.warning("... non-UUID wave_id — skipping", extra={"wave_id": ...})`; **return** (lines 83-90). **GOTCHA:** a bad UUID does NOT raise — it silently returns (best-effort by contract; the workflow's outer try/except swallows persist errors anyway, docstring lines 74-77).
3. `now = datetime.now(timezone.utc)` (line 92).
4. `reason = (input.reason or "")[:500]` (line 95). **GOTCHA:** belt-and-braces re-truncation to 500 chars; the *caller* is also expected to truncate (docstring lines 62-66, 93-94).
5. `conn = await asyncpg.connect(_db_url())`; try/finally (finally `await conn.close()`):
   ```sql
   UPDATE wave
   SET status = 'failed', failed_at = $2, failure_reason = $3, updated_at = $2
   WHERE id = $1
   ```
   Params: `$1 = wave_uuid`, `$2 = now`, `$3 = reason`. Note `failed_at` and `updated_at` both set to `now` ($2). `status` hardcoded `'failed'`.
6. `logger.info("wave.persist_failure", extra={"wave_id", "workflow_id", "reason_chars": len(reason)})` (lines 115-122).

**GOTCHA (idempotency, lines 67-72):** no `WHERE status != 'failed'` guard — calling twice overwrites `failed_at` with a later timestamp + rewrites same reason. Deliberately idempotent on happy path over racy on retry. **`workflow_id` is deliberately NOT written to the DB** (lines 60-61, 116-121 only log it) — kept as an audit breadcrumb, not cleared/persisted here. If the wave row is missing, the UPDATE affects 0 rows and no error is raised (result unchecked).

### 2.2 `update_wave_status(input: UpdateWaveStatusInput) -> UpdateWaveStatusResult` — ACTIVITY (`wave_operations.py:130-233`)
`UpdateWaveStatusInput` (`types.py:2110-2127`): `wave_id: str`, `new_status: str`, `reason: str = ""`.
`UpdateWaveStatusResult` (`types.py:2130-2141`): `wave_id: str`, `new_status: str`, `updated: bool = False`.

Purpose: flip `wave.status`. Used by Architecture+Data fan-out to walk `awaiting-architecture-dispatch → architecture-in-flight → data-in-flight → completed` (migration 045 statuses). CHECK constraint on `wave.status` is the authoritative guardrail — this activity does NOT re-validate the string (docstring lines 142-146).

Body:
1. `if not input.wave_id:` → `logger.warning("update_wave_status: empty wave_id — skipping")`; **return** `UpdateWaveStatusResult(wave_id="", new_status=input.new_status, updated=False)` (lines 147-151). **GOTCHA:** returns empty `wave_id` here (not the input's).
2. `try: wave_uuid = uuid.UUID(input.wave_id)` except `(ValueError, TypeError):` → warning + **return** `UpdateWaveStatusResult(wave_id=input.wave_id, new_status=input.new_status, updated=False)` (lines 152-161). (Here returns the input wave_id.)
3. `_FAILURE_STATUSES = {"failed", "stuck-awaiting-recovery"}` (line 170).
4. `persist_reason = bool(input.reason) and input.new_status in _FAILURE_STATUSES` (lines 171-173). **GOTCHA (task #88, lines 163-169):** `reason` is written to `wave.failure_reason` ONLY for terminal/recoverable failure statuses. Every other transition leaves `failure_reason` untouched so a prior failure narrative is preserved until `/reset`.
5. `reason_truncated = (input.reason or "")[:500]`; `now = datetime.now(timezone.utc)` (lines 174-175).
6. `conn = await asyncpg.connect(_db_url())`; try/finally (finally close):
   - If `persist_reason` (lines 179-193):
     ```sql
     UPDATE wave
     SET status = $2, updated_at = $3,
         failure_reason = COALESCE(NULLIF($4, ''), failure_reason),
         failed_at = COALESCE(failed_at, $3)
     WHERE id = $1
     ```
     Params: `$1=wave_uuid, $2=new_status, $3=now, $4=reason_truncated`. **GOTCHA:** `NULLIF($4,'')` keeps existing `failure_reason` if the truncated reason is empty; `failed_at = COALESCE(failed_at, $3)` sets `failed_at` only if currently NULL (first failure timestamp wins — does NOT overwrite an earlier failed_at).
   - Else (lines 195-205):
     ```sql
     UPDATE wave
     SET status = $2, updated_at = $3
     WHERE id = $1
     ```
     Params: `$1=wave_uuid, $2=new_status, $3=now`.
7. `try: updated = int(result.split()[-1]) > 0` except `(AttributeError, ValueError, IndexError): updated = False` (lines 209-212). **GOTCHA:** parses asyncpg's command tag (e.g. `"UPDATE 1"`) — last token is affected-row count.
8. If `not updated`: `logger.warning("update_wave_status: no row updated", extra={"wave_id","new_status"})` (lines 214-218).
9. `logger.info("wave.update_status", extra={"wave_id","new_status","reason": input.reason})` (lines 220-227).
10. Returns `UpdateWaveStatusResult(wave_id=input.wave_id, new_status=input.new_status, updated=updated)` (lines 229-233).

**Idempotency:** re-running with same status re-writes the row (row count still 1 → `updated=True`); `failed_at` COALESCE protects the first-failure timestamp.

### 2.3 `update_wave_architecture_workflow_id(input) -> None` — ACTIVITY (`wave_operations.py:236-310`)
`UpdateWaveArchitectureWorkflowIdInput` (`types.py:2376-2388`): `wave_id: str`, `architecture_workflow_id: str`. Column added by migration 054.

Purpose: persist the WaveArchitectureWorkflow handle to `wave.architecture_workflow_id` right after spawning the architecture coordinator child, so API/UI route signals (`pre_dispatch_confirmed`, `cancel_all_children`) to the coordinator.

Body:
1. `if not input.wave_id or not input.architecture_workflow_id:` → `logger.warning("... empty wave_id or workflow_id — skipping", extra={both})`; **return** (lines 253-261).
2. `try: wave_uuid = uuid.UUID(input.wave_id)` except `(ValueError, TypeError):` → warning + **return** (lines 262-269).
3. `now = datetime.now(timezone.utc)` (line 271).
4. `conn = await asyncpg.connect(_db_url())`; try/finally:
   ```sql
   UPDATE wave
   SET architecture_workflow_id = $2, updated_at = $3
   WHERE id = $1
   ```
   Params: `$1=wave_uuid, $2=input.architecture_workflow_id, $3=now`.
5. `updated` parsed from command tag (same guard as §2.2, lines 288-291).
6. If `not updated`: `logger.warning("... no row updated", extra={both})`; **return** early (lines 293-301). (Skips the success log.)
7. Else `logger.info("wave.update_architecture_workflow_id", extra={"wave_id","architecture_workflow_id"})` (lines 303-309).

**Idempotency:** UPDATE keyed on id; re-runnable. Best-effort — missing row logs + returns, never raises (architecture coordinator runs regardless, docstring lines 248-251).

**Cross-group note:** none of the three wave activities perform any Git/branch/commit/PR/merge operations, and none dispatch agents. They are pure Postgres projection writers.

---

## 3. `human_task_activities.py`

Module purpose (`human_task_activities.py:1-22`): a **human-task** assigns one skill execution to one named human (optionally human-with-local-agent). Row lands in `agent_task` with `actor_kind ∈ {human, human_with_agent}` and surfaces in `GET /api/v1/me/tasks`. Migration 050 (`capability_system_grain`) added `actor_kind`/`human_user_id`/`local_agent_descriptor` columns + check constraints; migration 044 made `application_id` nullable and added a wave-scoped XOR constraint. Before this activity, no code created human rows (`dispatch_agent_task` always writes `actor_kind='olympus_agent'`).

`_VALID_HUMAN_ACTOR_KINDS = frozenset({"human", "human_with_agent"})` (line 47).

### 3.1 `_build_async_database_url() -> str` (`human_task_activities.py:50-63`)
Composes `postgresql+asyncpg://{user}:{encoded}@{host}:{port}/{name}` from env vars (same defaults as §1.1) but **password URL-encoded via `quote_plus`** (lines 62-63). Uses SQLAlchemy async engine (contrast asyncpg-direct in renditions/wave_operations). Never reads a monolithic `DATABASE_URL` (docstring lines 51-56).

### 3.2 `_human_task_session()` async contextmanager (`human_task_activities.py:66-82`)
- `create_async_engine(_build_async_database_url(), pool_pre_ping=True, pool_recycle=300, pool_timeout=30, pool_size=2, max_overflow=2)` (lines 69-76).
- `factory = async_sessionmaker(engine, expire_on_commit=False)` (line 77).
- `async with factory() as session: yield session` (lines 78-80); `finally: await engine.dispose()` (lines 81-82). **GOTCHA:** one-shot engine per activity call — created + disposed each invocation (worker can't reuse FastAPI's request-scoped session).

### 3.3 `dispatch_human_task(...) -> str` — ACTIVITY (`human_task_activities.py:85-200`)
**Signature (positional, NOT a dataclass input):**
```python
async def dispatch_human_task(
    task_type: str,
    app_id: str | None,
    wave_id: str | None,
    skill_id: str,
    human_user_id: str,
    actor_kind: str,
    local_agent_descriptor: dict | None,
    input_artifacts: list[str],
    portfolio_id: str,
) -> str
```
Returns the new `agent_task` id as a string.

Validation (raises `ValueError` → wrapped `NonRetryableError` by `@foundry_activity`, since "ValueError" matches no retryable pattern):
1. `actor_kind = (actor_kind or "").strip()`; if `actor_kind not in _VALID_HUMAN_ACTOR_KINDS` → `raise ValueError("dispatch_human_task actor_kind must be one of {sorted(...)}; got {actor_kind!r}")` (lines 122-127).
2. `if not human_user_id or not str(human_user_id).strip():` → `raise ValueError("dispatch_human_task requires a non-empty human_user_id for actor_kind=...")` (lines 128-132).
3. **XOR:** `if bool(app_id) == bool(wave_id):` → `raise ValueError("... requires exactly one of app_id / wave_id; got app_id=..., wave_id=...")` (lines 133-137). Exactly one of app_id/wave_id must be set (matches DB constraint `agent_task_application_or_wave_ck`).

Field assembly:
4. `application_id_uuid = uuid.UUID(app_id) if app_id else None`; `wave_id_uuid = uuid.UUID(wave_id) if wave_id else None` (lines 139-140).
5. **Descriptor normalization** (lines 145-149): `descriptor_json: str | None = None`; `if actor_kind == "human_with_agent" and isinstance(local_agent_descriptor, dict): descriptor_json = json.dumps(local_agent_descriptor)`. **GOTCHA:** for plain `human`, `local_agent_descriptor` is ALWAYS dropped to NULL even if supplied (mirrors human_paired_agent structural rule, docstring lines 142-144). Descriptor `{tool, version, model}` shape.
6. `refs_json = json.dumps(list(input_artifacts or []))` (line 151). Empty/None → `"[]"`.
7. `task_id = uuid.uuid4()`; `dispatched_at = datetime.now(timezone.utc)` (lines 152-153).

DB write (lines 155-185): `async with _human_task_session() as db:` then:
```sql
INSERT INTO agent_task (
    id, task_type, application_id, wave_id, skill_id,
    status, actor_kind, human_user_id,
    local_agent_descriptor, input_artifact_refs, dispatched_at
) VALUES (
    :id, :task_type, :application_id, :wave_id, :skill_id,
    'queued', :actor_kind, :human_user_id,
    CAST(:descriptor AS JSONB), CAST(:refs AS JSONB), :dispatched_at
)
```
Param bindings (lines 172-183): `id=task_id`, `task_type`, `application_id=application_id_uuid`, `wave_id=wave_id_uuid`, `skill_id`, `actor_kind`, `human_user_id`, `descriptor=descriptor_json` (JSONB cast, NULL for plain human), `refs=refs_json` (JSONB cast), `dispatched_at`. **`status` hardcoded `'queued'`.** Then `await db.commit()` (line 185).

Then `logger.info("human-task.dispatched", extra={task_id, task_type, skill_id, actor_kind, human_user_id, app_id, wave_id, portfolio_id})` (lines 187-199) and `return str(task_id)` (line 200).

**GOTCHA:** `portfolio_id` is a positional arg but is recorded ONLY in the log line — it is NOT written to the DB (docstring lines 116-117: portfolio is derived from the app/wave join).

**No skill selection / agent dispatch / output validation / retry-with-feedback** — this is a pure DB insert of a human-assigned task. It does NOT call any agent runtime. (This is a "human task", not an agent-dispatch activity.)

**Idempotency:** NOT idempotent — each call generates a fresh `uuid.uuid4()` id + inserts a new row. A Temporal retry after a committed-but-lost-ack would insert a DUPLICATE `agent_task` row. No dedupe key. (Callers rely on Temporal's activity-completion recording to avoid double-dispatch in normal operation.)

---

## 4. `drift_detection.py`

Module purpose (`drift_detection.py:1-17`): drift **evaluation logic** lives in activities (not workflow code) to keep workflows deterministic. `detect_drift` is a thin delegator to the pure `evaluate_drift` engine (replay-safe, fixture-pinned). Phase-10 W1 removed the former always-pass traceability stubs (REQ-PS-008 option b).

### 4.1 Input dataclasses
**`DriftCitationInput`** (`drift_detection.py:32-46`): `source_artifact: str`, `target_artifact: str`, `target_element: str | None = None`, `source_version: str | None = None`. Mirrors traceability `Citation` structural surface; satisfies `drift.CitationLike` by attribute name.

**`DetectDriftInput`** (`drift_detection.py:48-61`): `app_id: str`, `obligations: list[DriftObligation] = field(default_factory=list)`, `citations: list[DriftCitationInput] = field(default_factory=list)`, `spec_versions: dict[str, str] = field(default_factory=dict)`. (`DriftObligation`, `DriftReport` imported from `olympus_workflows.drift`, line 24-28.)

### 4.2 `detect_drift(input: DetectDriftInput) -> DriftReport` — ACTIVITY (`drift_detection.py:64-77`)
Body (entire): `return evaluate_drift(list(input.obligations), list(input.citations), app_id=input.app_id, spec_versions=dict(input.spec_versions))` (lines 72-77). **Deterministic** — identical input → identical `DriftReport` (replay-safe). No I/O, no DB. (Bidirectional spec↔code drift engine details are in the drift-engine doc, not here — this activity is a pure delegator.)

### 4.3 `PersistDriftInput` (`drift_detection.py:80-107`)
Fields: `app_id: str`, `spec_artifact: str`, `profile_id: str`, `portfolio_id: str`, `spec_source: str`, `source_kind: str = "python"`, `citations: list[DriftCitationInput] = field(default_factory=list)`, `spec_versions: dict[str, str] = field(default_factory=dict)`, `application_id: str | None = None`.
Semantics (docstring lines 81-107): fed by CI drift triggers (`drift-backward.yml`/`drift-forward.yml`). Unlike `detect_drift`, this DERIVES obligations from the registered spec's `spec_source` (REQ-DR-001). `spec_source`+`source_kind` drive derivation; failure → coverage gap (REQ-DR-007), not silent in-sync. `profile_id` selects severity thresholds + evidence controls as DATA (REQ-DR-010). `portfolio_id`/`application_id` scope the evidence record (REQ-DR-009).

### 4.4 `PersistDriftResult` (`drift_detection.py:109-120`)
`persisted: bool`, `in_sync: bool`, `verdict: str`, `blocking_count: int`, `content_digest: str`, `reconcile_items: int`, `evidence_content_hash: str | None = None`, `coverage_gap: bool = False`.

### 4.5 `persist_drift_report(payload: PersistDriftInput) -> PersistDriftResult` — ACTIVITY (`drift_detection.py:123-213`)
THE production trigger path (derive → evaluate → PERSIST + reconcile + emit evidence). Docstring lines 124-149.

**GOTCHA (lazy import inside body, lines 151-159):** imports are inside the function so the Temporal workflow sandbox can reference this activity without loading SQLAlchemy/asyncpg at definition time (mirrors `evidence_emit.emit_evidence`):
```python
import uuid as _uuid
from src.database import get_db
from src.services.drift import (DriftPersistService, SpecObligationError, derive_obligations, load_drift_thresholds)
```

Body sequence:
1. `captured_at = datetime.now(timezone.utc)` (line 161). **GOTCHA (REQ-TEMP-001, docstring lines 144-146):** the timestamp is captured HERE in the activity (not in the workflow) so the workflow stays deterministic; it is passed into the service as `recorded_at`.
2. **Obligation derivation (REQ-DR-001/007, lines 165-174):**
   ```python
   derivation_error: SpecObligationError | None = None
   obligations: list[DriftObligation] = []
   try:
       obligations = derive_obligations(payload.spec_artifact, payload.spec_source, source_kind=payload.source_kind)
   except SpecObligationError as exc:
       derivation_error = exc
   ```
   **GOTCHA:** a `SpecObligationError` is CAUGHT and stashed as `derivation_error` — NOT re-raised. It becomes a coverage-gap finding downstream, never drops the report or produces a silent in-sync.
3. `config = load_drift_thresholds(payload.profile_id)` (line 177) — REQ-DR-010 profile DATA.
4. **DB session (lines 179-202):**
   ```python
   db_gen = get_db()
   session = await db_gen.__anext__()
   try:
       svc = DriftPersistService(session)
       result = await svc.persist_report(
           app_id=payload.app_id,
           spec_artifact=payload.spec_artifact,
           profile_id=payload.profile_id,
           obligations=obligations,
           citations=list(payload.citations),
           config=config,
           portfolio_id=_uuid.UUID(payload.portfolio_id),
           application_id=(_uuid.UUID(payload.application_id) if payload.application_id else None),
           spec_versions=dict(payload.spec_versions),
           derivation_error=derivation_error,
           recorded_at=captured_at,
           commit=True,
       )
   finally:
       await db_gen.aclose()
   ```
   **GOTCHA:** obtains the session by manually driving the `get_db()` async generator (`__anext__()` to enter, `aclose()` in finally to run its teardown). `commit=True` is passed to the service (the service owns the commit). `portfolio_id` is REQUIRED (unconditional `_uuid.UUID(...)`); `application_id` optional. All persistence/reconcile/evidence-emit logic lives in the API-layer `DriftPersistService.persist_report` — in ONE flow it: persists the directional+severity-scored `drift_report` row (REQ-DR-003/004), toggles per-spec `in_sync` (REQ-DR-006), opens a human reconciliation item per at-or-above-threshold finding (REQ-DR-005), and emits an `evidence_record` mapped to the profile's continuous-monitoring control(s) (REQ-DR-009). REQ-DR-008: the only reconciliation artifact is a `proposed_diff` — NO apply path (docstring lines 140-143).
5. **Return (lines 204-213):**
   ```python
   return PersistDriftResult(
       persisted=True,
       in_sync=result.report.in_sync,
       verdict=result.report.verdict,
       blocking_count=result.report.blocking_count,
       content_digest=result.report.content_digest,
       reconcile_items=len(result.reconcile_items),
       evidence_content_hash=result.evidence_content_hash,
       coverage_gap=derivation_error is not None,
   )
   ```
   `persisted` hardcoded `True`; `coverage_gap = (derivation_error is not None)`.

**Error handling / retries:** if `derive_obligations`/`persist_report`/DB fails with anything OTHER than `SpecObligationError`, it escapes → `@foundry_activity` wraps (Retryable if class-name matches, else NonRetryable). `_uuid.UUID(payload.portfolio_id)` on a bad UUID → `ValueError` → wrapped NonRetryableError.

**Idempotency:** delegated to `DriftPersistService.persist_report` (content_digest suggests dedupe by digest — verify in the drift-service doc; this activity itself always sets `persisted=True`).

---

## 5. `traceability.py` — NO ACTIVITIES (module intentionally empty)

`temporal/olympus_workflows/activities/traceability.py` (25 lines total, all docstring + `from __future__ import annotations`). Phase-10 W1 `provenance-substrate-delta` (REQ-PS-008, option **b**).

- Previously held two UNCALLED activity stubs: a citation-indexing activity (always reported zero citations indexed) and a gate-traceability activity (always reported full coverage + passing). Both were always-pass stubs registered/invoked by nothing (verified by grep across the temporal tree) — docstring lines 4-11.
- Per REQ-PS-008 the stubs were **removed** (option b) rather than wired to real HTTP (option a), because nothing called them; wiring them would be net-new behavior which the recording-only spec avoids (lines 12-16).
- Single traceability source of truth remains `olympus-api/src/services/traceability.py` (`GATE_TRACEABILITY_THRESHOLDS` + `validate_gate_traceability(..., risk_tier)`, REQ-PS-007) — lines 16-20.
- Future note (lines 20-21): any new traceability activity should call that service over HTTP (not a stub) and be worker-registered at that time.

**Regeneration action:** recreate this file as a module docstring only + `from __future__ import annotations` (`traceability.py:23`). It defines ZERO callable symbols and ZERO activities. Do NOT re-add the removed stubs.

---

## 6. Group summary

| Activity | File | Input | Output | I/O | Idempotent? |
|---|---|---|---|---|---|
| `render_rendition` | renditions.py:287 | `RenderRenditionInput` | `RenderRenditionResult` | Git read + asyncpg UPDATE `rendition` | Yes (UPDATE by id) |
| `persist_wave_failure` | wave_operations.py:48 | `PersistWaveFailureInput` | `None` | asyncpg UPDATE `wave` | Yes (overwrites) |
| `update_wave_status` | wave_operations.py:130 | `UpdateWaveStatusInput` | `UpdateWaveStatusResult` | asyncpg UPDATE `wave` | Yes (COALESCE guards failed_at) |
| `update_wave_architecture_workflow_id` | wave_operations.py:236 | `UpdateWaveArchitectureWorkflowIdInput` | `None` | asyncpg UPDATE `wave` | Yes |
| `dispatch_human_task` | human_task_activities.py:85 | 9 positional args | `str` (task id) | SQLAlchemy INSERT `agent_task` | **NO** (fresh uuid4 per call) |
| `detect_drift` | drift_detection.py:64 | `DetectDriftInput` | `DriftReport` | none (pure) | Yes (deterministic) |
| `persist_drift_report` | drift_detection.py:123 | `PersistDriftInput` | `PersistDriftResult` | `DriftPersistService` (DB) | delegated to service |

**7 activity functions total** across the group (traceability.py contributes 0).

**Common gotchas across the group:**
- Three distinct DB-access patterns: renditions + wave_operations use raw `asyncpg.connect(_db_url())` with `postgresql://` (no password encoding); human_task uses SQLAlchemy async engine with `postgresql+asyncpg://` and `quote_plus`-encoded password; drift_detection drives `get_db()` (the API's own generator).
- Best-effort vs strict: wave activities + `render_rendition`'s *render* step swallow errors and return; `render_rendition`'s *persist* step and all validation `ValueError`s escape to Temporal.
- All timestamps captured on the activity side (`datetime.now(timezone.utc)`), never in workflow code, preserving workflow determinism.
