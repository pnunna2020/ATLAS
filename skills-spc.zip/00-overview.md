# 00 — Skill Forge: Repo Map & Capability Overview 【CAPTURE】

> **Orientation (read first).** There is **no separate "Skill Forge" repository.** "Skill Forge"
> is the name this spec gives to the **skill-build-and-certify capability that lives inside the
> Olympus monorepo** at `/Users/pnunna/Documents/GitHub/Olympus_Claude`. The sibling tree
> `chatbot-phase-0-2026-05-31/` is a byte-frozen mirror of the same repo (dated 2026-05-31), not a
> second app — ignore it.
>
> The runbook's framing — *"two apps that should be one capability with two front doors"* — maps
> onto this repo as **two capability surfaces over one shared core:**
>
> | Front door | What it is | Where it lives |
> |---|---|---|
> | **Olympus** (delivery engine) | The gated, client-facing modernization pipeline that *runs* skills over real apps | `olympus/`, `assembly-lines/`, `profiles/` |
> | **Skill Forge** (build-and-certify) | The developer-facing capability to *author, run, and eval* skills | `cross-cutting/skills/` (the library), `olympus/olympus/skills/` (loader+registry), `eval-harness/` (cert), `scripts/*skill*` (authoring) |
>
> They share — **by construction, because they're the same repo** — the skill library, the JSON
> schemas, and the Anthropic-SDK agent runtime. ⚠️ **That shared-by-construction contract is
> unenforced.** Nothing prevents the two surfaces from drifting the moment they're split into two
> deployables, because there is no package boundary, no published contract version, and the eval
> harness and the delivery runtime already resolve schemas from *different roots* (see
> `03-validation-contract.md`). Holding that drift risk is the job of this spec.

---

## 1. What Skill Forge does that Olympus does NOT

| Capability | Skill Forge (build/certify) | Olympus (deliver) |
|---|---|---|
| **Author a skill** | ✅ `scripts/bootstrap_skill.sh` scaffolds a `SKILL.md`; developer edits markdown | ❌ consumes skills, never creates them |
| **Validate skill structure** | ✅ `scripts/validate_skills.py` (frontmatter + section + reference checks) | ❌ |
| **Lock/track skill content** | ✅ `scripts/generate_skills_lock.py` + `verify_skills_lock.py` (content-addressed SHA-256) | ❌ |
| **Eval a skill's output quality** | ✅ `eval-harness/` (deterministic + LLM-judge + golden-corpus) | ❌ — the harness is a *separate, standalone* tree not imported by the runtime |
| **Run a skill over a real app** | ⚠️ via the *same* runtime Olympus uses (`olympus run-phase`) — Skill Forge has no isolated runner | ✅ this is Olympus's whole job |
| **Gate / approve / deploy** | ❌ | ✅ 15 gates, FSM, waves, deployment |

**The asymmetry that matters:** Skill Forge can *author* and *score* skills but **cannot run a skill in isolation** — to exercise a skill it must invoke Olympus's full phase runner, which loads *all* skills registered for that phase against a DB-resident app record. There is no "test this one skill with this one context" path. This is the central capability gap the TARGET docs (Phases 4–6) address.

## 2. What they share

1. **The skill library** — `cross-cutting/skills/<name>/SKILL.md` (+ optional `references/`, `scripts/`, `assets/`, `config.json`). ~181 skill dirs on disk.
2. **The skill loader/registry** — `olympus/olympus/skills/{loader,frontmatter,registry}.py` + `registry.yaml`. Used by the delivery runtime; *also* the only structured reader of skills that Skill Forge tooling shares.
3. **The JSON schemas** — top-level `schemas/` (67 `*.schema.json`). ⚠️ Forked/duplicated in 3+ other locations (§5).
4. **The Anthropic-SDK agent runtime** — `olympus/olympus/agents/base.py` (`BaseAgent.run()` tool-use loop). Skills are injected as the agent's system prompt.

---

## 3. Full repo map (modules that constitute the capability)

```
Olympus_Claude/
├── cross-cutting/skills/            ★ THE SKILL LIBRARY (the core asset)
│   └── <name>/SKILL.md (+references/ scripts/ assets/ config.json)   ~181 dirs
│   └── skill-builder/SKILL.md       ← the meta-skill for authoring skills
│
├── olympus/                         ★ THE SDK RUNTIME + CLI + API (delivery engine)
│   ├── pyproject.toml               console_scripts: olympus = olympus.cli:cli
│   └── olympus/
│       ├── cli.py                   29 CLI commands (incl. run-phase, replay, promote)
│       ├── config.py                OlympusConfig (pydantic-settings); ~40 env vars
│       ├── skills/                  ★ SKILL LOADER + REGISTRY (shared core)
│       │   ├── loader.py            load_skill / load_skills_for_phase (budget-aware)
│       │   ├── frontmatter.py       SkillFrontmatter dataclass (CI-8 typed fields)
│       │   ├── registry.py          resolve_skills(phase, app_context)
│       │   ├── registry.yaml        phase → primary/conditional/supplementary (12 phase keys)
│       │   └── skills-lock.json     content-addressed lock (169 skills)
│       ├── agents/                  per-phase agent factories + base.py (the SDK loop)
│       │   ├── base.py              BaseAgent.run() — Anthropic Messages tool-use loop
│       │   └── {discovery,rationalization,architecture,extraction,design,
│       │        generation,review,classifier,compliance,...}.py
│       ├── fsm/                     ★ THE ORCHESTRATOR (no Temporal)
│       │   ├── worker.py            poll loop; _STAGE_ARTIFACT_MAP; _process_app
│       │   ├── states.py            AppState (56 states) + TRANSITIONS + ACTIONABLE_STATES
│       │   ├── machine.py           FSM / PipelineStateMachine (DB-backed transitions)
│       │   ├── phase_runner.py      run a single phase (used by CLI/API)
│       │   ├── ralph_loop.py        TDD generate cycle (per-module iteration)
│       │   ├── ledger.py            PhaseRunLedger (append-only run audit)
│       │   ├── checkpoints.py       PhaseCheckpoint (intra-phase; partly unmerged)
│       │   ├── {resume,rerun,replay,promote}.py   recovery modes
│       │   └── {parallel_worker,wave_runner}.py   concurrency / portfolio waves
│       ├── validators/              schema_validator.py (Draft202012), citation, business_rules
│       ├── contracts/phase_io.py    pydantic Inputs/Outputs per phase (hand-off contract)
│       ├── artifacts/git_store.py   Git-backed artifact store
│       ├── api/                     FastAPI app (create_app factory) + routes/ (27 modules)
│       ├── dashboard/               static HTML/JS delivery-monitoring dashboard
│       ├── chat/                    conversational analytics over pipeline state
│       └── db/                      SQLAlchemy models (Application, Gate, Artifact, AgentRun…)
│
├── eval-harness/                    ★ THE CERTIFICATION HARNESS (standalone; CRITIQUE target)
│   ├── config.yaml                  thresholds, corpus registry, rubric map, llm model
│   ├── run-baselines.py             corpus self-check / compare actual-vs-expected
│   ├── compare-baselines.py         regression diff between two baseline versions
│   ├── rubrics/*.yaml               6 category rubrics (LLM-judge dimensions)
│   ├── evals/
│   │   ├── deterministic/           schema_validator(Draft7), traceability, coverage, format, xref
│   │   ├── non-deterministic/       llm_judge.py, golden_comparison.py
│   │   └── skill-evals/*.eval.yaml  per-skill eval declarations (22 files)
│   ├── golden-corpus/               ground-truth expected-output JSON per app×phase
│   ├── baselines/v0.1/manifest.yaml all 26 skills "not-yet-baselined"
│   └── tools/                       run-benchmark-suite (stub), report_generator, skill_filter
│
├── schemas/                         ★ 67 canonical JSON Schemas (the bridge to Olympus)
│   └── {common,discovery*,rationalization,data,modernization,disposition,
│        sustainment,governance}/*.schema.json
│
├── mcp-server/                      MCP JSON-RPC server (own copy of resource schemas) ⚠️ drift
│   └── schemas/{tools,resources}/*.schema.json
│
├── scripts/                         ★ SKILL-AUTHORING TOOLCHAIN
│   ├── bootstrap_skill.sh           scaffold a new SKILL.md (9-section stub)
│   ├── validate_skills.py           frontmatter + reference validator (pre-commit)
│   ├── generate_skills_lock.py      compute content-addressed lock
│   └── verify_skills_lock.py        verify lock vs disk (CI/observability)
│
├── temporal/                        ⚠️ DEFERRED target architecture (foundry-temporal). NOT the
│                                       active runtime. Present but not imported by olympus/.
├── prototype/                       ⚠️ ATLAS Phase-3 client demo app (React+Express+Temporal,
│                                       Node). NOT a skill-authoring UI. Out of scope for Forge.
├── docs/                            skill-template.md, specs, phase-3 material
└── .pre-commit-config.yaml          runs validate_skills.py on SKILL.md changes
```

### Dependency graph (module level)

```
                         cross-cutting/skills/*  (SKILL.md files — data, not code)
                                   ▲                         ▲
                                   │ reads (OLYMPUS_SKILLS_PATH)   │ reads (skills_root)
                                   │                         │
   olympus.skills.registry ──► olympus.skills.loader ──► olympus.skills.frontmatter
            ▲                                                   ▲
            │ load_phase_skills()                               │ load_frontmatter()
            │                                                   │
   olympus.agents.* (factories) ──► olympus.agents.base.BaseAgent.run()  ──►  Anthropic SDK
            ▲                                                                  (direct or Bedrock)
            │ create_*_agent()
   olympus.fsm.{worker,phase_runner,ralph_loop} ──► olympus.contracts.phase_io (validate)
            │                                  └────► olympus.validators.schema_validator ──► schemas/
            │ persists
   olympus.db.models  ◄──►  PostgreSQL / SQLite        olympus.artifacts.git_store ──► Git repo

   eval-harness/*  ── STANDALONE ── imports NOTHING from olympus/  (only `anthropic`, `jsonschema`,
        │            `pyyaml`, and — via tools/skill_filter.py — olympus.skills.frontmatter)
        └── resolves schemas from  config.yaml: schemas_dir: ../specifications/schemas  ⚠️ MISSING PATH
```

**Key edges & the drift they imply:**
- `eval-harness/` is an island: it grades **pre-existing output artifacts on disk**, never imports the runtime, never invokes a skill. So the function it tests is *"did this JSON file score well against a rubric,"* not *"does this skill behave correctly when Olympus runs it."* (Critiqued in `04-eval-harness-TARGET.md`.)
- The **only** code coupling from harness→runtime is `eval-harness/tools/skill_filter.py` importing `olympus.skills.frontmatter.load_frontmatter` to read `benchmark_tags`. Everything else is duplicated or path-resolved.
- Skills are **data, not modules** — found by filesystem scan + frontmatter parse, never imported. This is what makes "many contributors add skills easily" *physically* possible (drop a folder) but also *unguarded* (no load-time contract).

---

## 4. The interface / "developer version" front end

There is **no dedicated Skill-Forge UI.** The developer's front end today is **file edits + the `olympus` CLI + the eval-harness Python CLI** (full treatment in `06-interface.md`). Summary:

- **Author:** create/edit `cross-cutting/skills/<name>/SKILL.md` (scaffold via `scripts/bootstrap_skill.sh`).
- **Validate:** `python scripts/validate_skills.py <dir>` (also a pre-commit hook).
- **Register:** hand-edit `olympus/olympus/skills/registry.yaml`.
- **Run/exercise:** `olympus run-phase <app_id> <phase>` (loads *all* phase skills; not isolated).
- **Eval:** `cd eval-harness && python run-baselines.py …` (compares output JSON vs golden corpus).
- **Quality metrics:** `GET /insights/skills/{name}` (API exists; no frontend).

The `olympus/olympus/dashboard/` and `prototype/apps/web/` UIs are **delivery/monitoring surfaces**, not authoring tools.

---

## 5. ⚠️ Schema drift surface (the #1 risk, summarized; detailed in Phase 3)

Schemas exist in **four** live locations with **no single source of truth**:

| Location | Count | Draft | Consumed by |
|---|---|---|---|
| `schemas/` (repo root) | 67 | `Draft202012` (via `olympus/olympus/validators/schema_validator.py:25`) | Olympus runtime |
| `docs/discovery-rationalization-bundle/schemas/` | ~10 | — | a doc bundle (forked copy) |
| `mcp-server/schemas/{tools,resources}/` | ~17 | — | MCP server |
| `olympus/olympus/api/schemas/` | (pydantic `_base.py`) | n/a | API request/response |
| **eval-harness target** `config.yaml → ../specifications/schemas` | **0 — PATH DOES NOT EXIST** | `Draft7` (`eval-harness/evals/deterministic/schema_validator.py:23`) | the cert harness |

So the **certifier (Draft7, missing schema root)** and the **runtime (Draft202012, `schemas/`)** validate against *different drafts and different roots*. A skill output certified by the harness is not guaranteed valid to the runtime, and vice versa. This is captured in `03-validation-contract.md` and `DRIFT-AND-GOTCHAS.md`.

---

## 6. Tech stack (as actually used by the capability)

| Concern | Choice | Evidence |
|---|---|---|
| Agent runtime | **Anthropic SDK** (`anthropic>=0.40`), direct API **or** AWS Bedrock | `olympus/pyproject.toml`; `agents/base.py:11,44-64` |
| Models | Sonnet (`claude-sonnet-4-6`) default per phase; Haiku for classify; Opus 4.7 advisor | `config.py:101-108`; `base.py:26-41` |
| Orchestration | **Custom FSM poller** (NOT Temporal) | `fsm/worker.py`; CLAUDE.md pivot note |
| Schema validation | `jsonschema` — Draft202012 (runtime) / Draft7 (harness) ⚠️ | both `schema_validator.py` |
| Config | `pydantic` / `pydantic-settings` | `config.py` |
| API | `FastAPI` + `uvicorn` + `sse-starlette` | `pyproject.toml`; `api/app.py` |
| Persistence | `SQLAlchemy 2.0` + `alembic`; PostgreSQL (prod) / SQLite (dev) | `pyproject.toml`; `README.md` |
| Artifact store | Git (`gitpython`) | `artifacts/git_store.py` |
| Eval harness | stdlib + `jsonschema` + `pyyaml` + `anthropic` (no pyproject) | `eval-harness/README.md` |

⚠️ **Spec-vs-code drift:** `CONTRIBUTING.md` principle #3 says *"Temporal is the backbone — all orchestration through Temporal,"* and a `temporal/` dir exists. **The active runtime does not import `temporalio`** (`olympus/pyproject.toml` has no such dep; `agents/base.py` is a hand-rolled Anthropic loop). Trust the code: orchestration is the FSM poller. See `memory/project_anthropic_pivot.md` and `02-orchestration.md`.
