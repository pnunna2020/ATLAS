# 03 — The Output / Validation Contract 【CAPTURE】 ← the bridge to Olympus

The contract a skill's output must satisfy, how it's validated, and **the drift surface between Skill
Forge's certifier and Olympus's runtime.** `path:line` throughout.

---

## 1. How a skill's output is validated — there are TWO independent validators

A skill output is validated by **two code paths that do not share a schema root, a JSON-Schema draft, or
a resolution key.** This is the core drift.

### 1a. The RUNTIME validator (`olympus/olympus/validators/schema_validator.py`) — what Olympus enforces

```python
# schema_validator.py:30-31, 138-252  (reproduced)
_SCHEMAS_ROOT = <repo>/schemas                                  # hard-anchored, 4 parents up
_ARTIFACT_SCHEMAS: dict[filename → (schema_rel_path, policy)]   # :35-117, ~26 entries

validate_artifact(artifact_name, artifact_content, *, disposition=None, risk_tier=None):
    entry = _ARTIFACT_SCHEMAS.get(artifact_name)
    if entry is None: report.status="skip"; return report      # ← UNREGISTERED artifact = silently skipped
    schema_rel, policy = entry
    effective_policy = policy
    if policy == "conditional-fail":                            # :176-183
        effective_policy = "fail" if _conditional_fail_escalates(...) else "warn"
    schema_path = _SCHEMAS_ROOT / schema_rel
    if not schema_path.exists(): report.status="skip"; return   # ← missing schema = skip, not fail (:186-192)
    schema = json.load(schema_path)                             # OSError/JSON err → skip (:196-199)
    payload = json.loads(artifact_content)                     # parse err → warn|fail per policy (:202-212)
    errors = sorted(Draft202012Validator(schema).iter_errors(payload), key=absolute_path)   # :214-215
    # business rule: T1 disposition-governance must be 'approved' even if schema-valid (:221-235)
    report.status = "pass" if no errors else ("fail" if effective_policy=="fail" else "warn")  # :237-251
    return report   # NEVER raises — caller inspects .status
```

**Policy model** (`schema_validator.py:35-117`) — three policies per artifact:
- **`warn`** — emit report, never block (catalog, data-flow, db-archaeology, complexity, scorecard, wave-plan…)
- **`fail`** — caller should block the gate (`disposition-validation.json`; all 7 disposition `*-plan.json`)
- **`conditional-fail`** — escalates to `fail` per artifact-specific rule (`schema_validator.py:268-300`):
  - `user-impact-analysis.json` → fail when disposition ∈ {Retire, Replace, Consolidate}
  - `disposition-governance.json` → fail when `risk_tier=T1` and `governance_status != "approved"`

Report is written as a sibling `{stem}-schema-validation.json` (`schema_validator.py:255-265`). ⚠️ Per
`validators/__init__.py:1-9`, validators are **warn-only by default; hard-fail is reserved for explicit
audit gates** — so most schema violations are advisory, not blocking, in the runtime.

### 1b. The HARNESS validator (`eval-harness/evals/deterministic/schema_validator.py`) — what Skill Forge certifies with

```python
# eval-harness/.../schema_validator.py:23, 57-100  (reproduced)
from jsonschema import Draft7Validator                          # ← DRAFT 7, not 2020-12
validate(output_path, schema_path):                             # both passed as CLI --args
    data   = load_file(output_path)    # JSON or YAML by extension (:34-54)
    schema = load_file(schema_path)
    errors = sorted(Draft7Validator(schema).iter_errors(data), key=absolute_path)   # :87-88
    return {"eval_name":"schema_validator","status": "FAIL" if violations else "PASS",
            "violations":[{"path": "$.foo.bar", "message": …}]}   # :90-100
# missing output OR schema file → status FAIL with a violation, exit 0 (:120-136)
```

Invoked per-skill via `skill-evals/*.eval.yaml` with an explicit `schema_path` arg.

---

## 2. ⚠️ THE DRIFT SURFACE — enumerated (the #1 risk the runbook protects)

### 2a. Schemas live in 4+ locations; none is the declared single source of truth

| Location | Files | Draft | Resolution key | Consumed by |
|---|---|---|---|---|
| `schemas/` (repo root) | **68** `*.schema.json`, namespaced by line | **2020-12** (all 68; verified) | artifact **filename** → `_ARTIFACT_SCHEMAS` map | **Olympus runtime** |
| `docs/discovery-rationalization-bundle/schemas/` | ~10 | 2020-12 | — | a doc bundle (a **fork**; byte-identical to root *today* for sampled files, but unmanaged) |
| `mcp-server/schemas/{tools,resources}/` | ~17 | (own) | MCP method | MCP server (`analysis.schema.json` lives **only** here) |
| `olympus/olympus/api/schemas/` | pydantic `_base.py` | n/a | API model | FastAPI request/response |
| **`eval-harness` declared root** | **0 — `config.yaml:6` → `../specifications/schemas` DOES NOT EXIST** | Draft **7** | explicit `--schema-path` | **Skill Forge certifier** |

### 2b. The certifier references PHANTOM schemas (verified)

Every `skill-evals/*.eval.yaml` passes a `schema_path` like `schemas/analysis.schema.json`,
`schemas/generation-manifest.schema.json`, `schemas/parity-report.schema.json`. **These files do not
exist anywhere** that the harness can resolve:

- `eval-harness/schemas/` — **does not exist** (verified: 0 `*.schema.json` under `eval-harness/`).
- repo-root `schemas/analysis.schema.json` — **does not exist**; the real file is
  `schemas/discovery/analysis-report.schema.json` (different name **and** different namespaced path).
- `generation-manifest.schema.json`, `parity-report.schema.json` — **found nowhere in the repo.**
- `analysis.schema.json` exists **only** at `mcp-server/schemas/resources/analysis.schema.json` — a
  *different* schema for a *different* purpose.

**Consequence:** when run from `eval-harness/`, the deterministic `schema_validator` is handed a
`schema_path` that doesn't resolve → it returns `status: FAIL` with *"Schema file not found"*
(`eval-harness/.../schema_validator.py:129-136`). **Every schema-validation eval fails for a
file-not-found reason, not a real schema violation** — i.e. the certifier's shape-check layer is
effectively dead. This is masked today only because **no skill is actually baselined** (all 26
`not-yet-baselined`, `baselines/v0.1/manifest.yaml`), so the broken evals have never gated anything.

### 2c. The draft-version mismatch (latent, not yet biting)

Runtime uses **Draft 2020-12**; harness uses **Draft 7**. The two drafts differ in array tuple
validation (`items`/`additionalItems` vs `prefixItems`), `$ref` resolution, and `unevaluatedProperties`.
**Today this is latent**: all 68 repo schemas avoid 2020-12-only keywords (verified: 0 use
`prefixItems`/`unevaluated*`), so a schema that *did* resolve would mostly validate identically under
both. **But** `format` assertions (e.g. `"format": "date"` in `tech-fingerprint.schema.json:86-87`)
behave differently across draft validators, and any future schema using 2020-12 tuple syntax would pass
the runtime and *error* in the harness (or vice-versa). The mismatch is a **time bomb**, defused only by
discipline that isn't enforced.

### 2d. Two `_STAGE_ARTIFACT_MAP` copies (from `02`)

`fsm/worker.py:41-61` and `fsm/phase_runner.py:49-95` keep parallel copies "in lock-step." Divergence
would feed different prior-artifact context to worker-run vs CLI-run phases — a second, intra-runtime
drift.

---

## 3. The EXACT contract a skill output must satisfy (standalone — author against this with zero app access)

A skill author/contributor — or the sibling platform — can target the contract using **only** this
section. Three layers, in order of how the runtime applies them:

### Layer A — Structural shape (JSON Schema, repo-root `schemas/`)

1. Output is **valid JSON** (a parse failure is a violation at `$`).
2. Output validates against its declared schema under **JSON Schema Draft 2020-12**.
3. The schema is resolved by **artifact filename**, not by the path your `SKILL.md` cites. The
   filename→schema mapping the runtime honors (`schema_validator.py:35-117`):

   | If your skill writes… | …it is validated against (under `schemas/`) | policy |
   |---|---|---|
   | `application-catalog-entry.json` | `discovery/application-catalog-entry.schema.json` | warn |
   | `structural-analysis.json` / `business-logic.json` / `quality-risk.json` | `discovery/*.schema.json` | warn |
   | `data-flow-trace.json`, `db-archaeology.json`, `identity-landscape.json`, `tiff-corpus-assessment.json`, `ux-accessibility.json`, `business-rule-inventory.json`, `shared-db-clusters.json` | `discovery/*.schema.json` | warn |
   | `complexity-classification.json`, `portfolio-scorecard.json`, `wave-plan.json`, `capability-consolidation-plan.json` | `rationalization/*.schema.json` | warn |
   | `user-impact-analysis.json` | `rationalization/user-impact-analysis.schema.json` | **conditional-fail** (Retire/Replace/Consolidate) |
   | `disposition-governance.json` | `rationalization/disposition-governance.schema.json` | **conditional-fail** (T1 + not approved) |
   | `disposition-validation.json` | `rationalization/disposition-validation.schema.json` | **fail** |
   | `{retire,retain,refactor,rearchitect,replace,replatform,consolidate}-plan.json` | `disposition/*-plan.schema.json` | **fail** |

   ⚠️ An artifact filename **not** in this map is **silently skipped** (`status="skip"`) — it is *not*
   validated at all. Writing `analysis.json` instead of the registered name = zero validation.

### Layer B — Phase hand-off contract (pydantic, `contracts/phase_io.py`)

Each phase's outputs must satisfy a pydantic model with `extra="forbid"` (`phase_io.py:113-116`). The
binding rules a contributor must honor (`phase_io.py:134-405`):
- **Discovery** → `analysis_report` + `tech_fingerprint` (both `ArtifactRef`); optional `complexity_score` ∈ [0,10].
- **Rationalization** → `disposition_recommendation` (`ArtifactRef`); `disposition` ∈ the **7 exact verbs**
  `{Retire, Retain, Refactor, Rearchitect, Replace, Replatform, Consolidate}` (validator at
  `phase_io.py:189-201`); `risk_tier` matches `^T[123]$` (`phase_io.py:186`).
- `ArtifactRef` requires non-empty `path` + `artifact_type`; optional `sha256` must be 64-char hex
  (`phase_io.py:28-59`).
- ⚠️ Several declared outputs are **aspirational** — `GenerationOutputs.generated_code`/`parity_report`
  and `ReviewOutputs.quality_scorecard` are Optional and *"not currently produced"* (`phase_io.py:325-389`).
  Author to what the worker actually consumes, per `_STAGE_ARTIFACT_MAP` (`02 §6`).

### Layer C — Traceability & content rules (other validators)

- **Citations** (`validators/citation_validator.py`) — findings must carry `{file}:{line}` (skill Quality
  Rules; mirrors harness `traceability_checker`).
- **Business rules** (`validators/business_rules_validator.py`) — domain-specific content checks.
- The canonical citation format (per CLAUDE.md): `{artifact}:{section}:{finding-id}` or `{repo}:{file}:{line}`,
  schema `schemas/common/traceability-citation.schema.json` (Draft 2020-12).

**A contributor can satisfy the full contract by:** writing valid JSON, to a **registered artifact
filename**, conforming to the namespaced **Draft 2020-12** schema, that also satisfies the phase's
pydantic output model and carries file:line citations. Nothing else is required and nothing app-internal
must be read.

---

## 4. Pass / fail / retry behavior

- **Runtime**: `validate_artifact` **never raises**; returns `status ∈ {pass, warn, fail, skip}`. Only
  `fail` (or escalated `conditional-fail`) is intended to block a gate, and only at explicit audit gates
  (`validators/__init__.py`). There is **no retry-with-feedback loop** in the schema validator itself —
  the only feedback loop in the system is the **Ralph Loop** for *Generation* (re-generate on test
  failure, `02 §7`), which is test-driven, not schema-driven.
- **Harness**: each eval prints a JSON verdict to stdout; `run-baselines.py` aggregates; non-zero exit on
  any failure. No retry — it's a one-shot grade of a pre-existing file (`04-eval-harness-AS-IS.md`).

⚠️ **There is no schema-driven retry anywhere.** If a skill emits a schema-invalid artifact, the runtime
logs a warn/fail and moves on; the harness (if its schema resolved) would mark FAIL. Neither feeds the
failure back to the skill. The TARGET harness adds this (`04-eval-harness-TARGET.md`).

---

## 5. Recommended single-source-of-truth mechanism

The runbook asks for the SSOT fix if schemas aren't already shared. Concrete proposal (buildable):

1. **Designate `schemas/` (repo root) as the ONLY schema source.** Delete the
   `docs/discovery-rationalization-bundle/schemas/` fork; if the doc bundle needs schemas, symlink or
   build-copy from `schemas/` with a CI check that the copy is byte-identical.
2. **Publish `schemas/` as a versioned package** (e.g. `olympus-contracts` wheel + npm) with a single
   `CONTRACT_VERSION`. Both the runtime and the harness import the package, never a path. When Skill
   Forge and Olympus split into two deployables, both depend on the *same pinned version* — drift becomes
   a dependency bump, not a silent divergence.
3. **Pin one JSON-Schema draft.** Make the harness use `Draft202012Validator` to match the runtime
   (`eval-harness/.../schema_validator.py:23,87`). One-line change; removes the latent draft bomb.
4. **Fix the harness schema resolution.** Either point `config.yaml:schemas_dir` at the real
   `../schemas` (repo root) **and** rewrite every `skill-evals/*.eval.yaml` `schema_path` to the
   **namespaced** real filename (`schemas/discovery/analysis-report.schema.json`, not
   `schemas/analysis.schema.json`), or — better — resolve schemas via the runtime's filename→schema map
   so the certifier and runtime agree by construction.
5. **Make schema resolution share one function.** Extract `_ARTIFACT_SCHEMAS` + resolution into the
   published package; both validators call it. The harness then validates the *same artifact against the
   same schema by the same key* as the runtime — eval-before-trust finally means what it says.
6. **CI guard:** a test that asserts every `skill-evals/*.eval.yaml schema_path` resolves to a real file,
   and every `_ARTIFACT_SCHEMAS` target exists. This single test would have caught the phantom-schema bug.

---

## GATE 3 — Is the contract complete enough to author a new skill with zero app-internal access?

**Yes, via §3** — a contributor needs: (a) write valid JSON to a **registered artifact filename**
(§3 Layer A table — *gap I filled*: the runtime keys on filename, not the SKILL.md-cited path, which is
non-obvious and undocumented elsewhere); (b) conform to the **namespaced Draft 2020-12** schema under
`schemas/` (*gap I filled*: the eval YAMLs' `schemas/<flat>.schema.json` names are **wrong/phantom** — the
real names are namespaced — so a contributor copying an eval YAML's path authors against a nonexistent
schema); (c) satisfy the phase **pydantic output model** (§3 Layer B, with the 7-disposition + `^T[123]$`
constraints); (d) carry `{file}:{line}` citations.

**Gaps found and filled here:** (1) filename-keyed schema resolution; (2) phantom schema names in eval
YAMLs; (3) the 7 exact disposition verbs + risk-tier regex; (4) "unregistered filename ⇒ silently
unvalidated"; (5) draft-version + missing-root mismatch between certifier and runtime. With §3+§5 a
contributor can author against the contract without reading app internals — **GATE 3 passes**, and the
SSOT fix (§5) is the prerequisite for the contract to actually be *one* contract rather than two.
