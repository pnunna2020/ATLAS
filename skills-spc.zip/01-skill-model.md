# 01 — The Skill Model & Authoring Flow 【CAPTURE】 ← the core asset

This is the heart of Skill Forge. Captured exhaustively, with `path:line`.

---

## 1. What IS a skill, concretely

A skill is a **directory on disk** under `cross-cutting/skills/<name>/`, not a code object. It is
**data discovered by filesystem scan**, never imported. Canonical layout (`docs/skill-template.md:169-179`):

```
cross-cutting/skills/<name>/
├── SKILL.md              # REQUIRED — YAML frontmatter + 9 markdown sections
├── config.json           # optional — FLAT scalar key/value settings (str|int|float|bool)
├── references/           # optional — *.md pattern files; up to 4 auto-loaded, ≤4000 chars each
├── scripts/              # optional — executable helpers (*.sh|*.py|*.sql)
└── assets/               # optional — output templates (*.md|*.yaml|*.json)
```

### 1a. The `SKILL.md` file = frontmatter + body

**YAML frontmatter** — the only machine-read part. Two layers of field definition exist:

**(i) The required + documented set** (`docs/skill-template.md:11-34`; enforced by `validate_skills.py:26`):

| Field | Required? | Meaning | Evidence |
|---|---|---|---|
| `name` | ✅ | kebab-case; **must equal folder name** | template:28; `validate_skills.py:26` |
| `description` | ✅ | when-to-load text; "Triggers on … or @<name>" | template:14-17,29 |
| `agent` | ✅ | `opus` or `sonnet` — ⚠️ **advisory only, does NOT pick the model at runtime** (see `00b §4`) | template:18,30 |
| `allowed-tools` | (template shows it; **not** enforced by validator) | positive tool allowlist | template:19-23,31 |
| `disable-model-invocation` | optional | `true` → never auto-load; explicit invocation only | template:32 |
| `deprecated` + `replaced_by` | optional | redirect stub; loader emits WARN | template:33; `loader.py:263-296` |

**(ii) The typed CI-8 dataclass** (`olympus/olympus/skills/frontmatter.py:33-55`) — `SkillFrontmatter`,
a `@dataclass(frozen=True)`. It captures the three **required legacy** fields (`name`, `description`,
`agent`) plus optional CI-8 fields:

```python
# frontmatter.py:43-55  (reproduced)
name: str                            # required at dataclass layer
description: str                     # required
agent: str                           # required
enrichment_level: str | None = None
phase: str | None = None
deprecated: bool = False
redirect_to: str | None = None
validation_commands: list[str] | None = None   # ┐
supported_stacks: list[str] | None = None       # │ the 5 CI-8 "new-skill"
anti_target_stacks: list[str] | None = None      # │ list fields — see §3 enforcement
failure_classes: list[str] | None = None         # │
benchmark_tags: list[str] | None = None          # ┘  (used by eval skill_filter)
raw: dict[str, Any]                  # the full parsed mapping
```

⚠️ **Two-source field drift:** the *template/validator* treats `name/description/agent` as required and
the 5 CI-8 fields as required **only for new skills** (`validate_skills.py:33-39,161-186`), while the
*dataclass* requires `name/description/agent` and leaves everything else optional. `allowed-tools` is in
the template but **enforced by neither**. `redirect_to` (dataclass) vs `replaced_by` (template/loader)
are two different names for "the successor skill" — the loader reads `replaced_by` (`loader.py:287`),
the dataclass reads `redirect_to` (`frontmatter.py:99`). A skill using `replaced_by` will deprecate
correctly at load but show `redirect_to=None` in the typed view. **Flagged in `DRIFT-AND-GOTCHAS.md`.**

**Body** — 9 mandatory markdown sections (`docs/skill-template.md:37-161`):
`Purpose · Inputs · Outputs · Methodology · [Tech-Stack Dispatch — optional] · Gotchas · Quality Rules
· Common Failure Modes · Handoff Summary`. The body is the **agent's system prompt** (with frontmatter
stripped — §3). It is prose methodology, not executable.

### 1b. `config.json` — flat scalar runtime settings

Read by `loader._load_skill_config` (`loader.py:145-193`). **Only `str|int|float|bool` values are
kept**; dict/list values are dropped with a warning and counted as `had_complex` (`loader.py:177-192`).
Example (`cross-cutting/skills/design-system/config.json`):

```json
{ "app_name": "", "app_type": "web", "user_persona": "", "citizen_dev": false }
```

Exposed to callers via `get_skill_configs()` → `{skill_id: {key: scalar}}` (`loader.py:134-142`).
⚠️ `isinstance(bool, int)` is `True` in Python — the loader orders the check so bools survive
(`loader.py:178-181`); a deliberate, commented subtlety.

---

## 2. The authoring flow — step by step (the real ergonomics)

```
┌─ 1. SCAFFOLD ───────────────────────────────────────────────────────────────┐
│  scripts/bootstrap_skill.sh <name> [--agent opus|sonnet] [--description "…"]  │
│    • validates name is kebab-case  ^[a-z][a-z0-9-]*$        (bootstrap:76-79) │
│    • validates --agent ∈ {opus,sonnet}                      (bootstrap:81-84) │
│    • IDEMPOTENT: if dir exists, prints path & exit 0         (bootstrap:88-91) │
│    • creates  <name>/SKILL.md  (frontmatter + all 9 sections stubbed w/ TODO) │
│                <name>/references/.gitkeep  <name>/assets/.gitkeep             │
│    • does NOT create config.json or scripts/ (add only when needed)  (b:14-16)│
└──────────────────────────────────────────────────────────────────────────────┘
┌─ 2. AUTHOR ──────────────────────────────────────────────────────────────────┐
│  Edit SKILL.md: fill frontmatter + 9 sections per docs/skill-template.md.     │
│  Add references/*.md (patterns), assets/*.md|yaml|json (output templates),    │
│  scripts/*.sh (set -euo pipefail), config.json (flat scalars) as needed.      │
└──────────────────────────────────────────────────────────────────────────────┘
┌─ 3. VALIDATE ────────────────────────────────────────────────────────────────┐
│  python scripts/validate_skills.py cross-cutting/skills/<name>                │
│    • frontmatter has name/description/agent, each non-empty str (vs:82-97)    │
│    • new skills (not in skills-lock.json) require 5 CI-8 list fields (vs:161) │
│    • every references/|scripts/|assets/ mention in body resolves on disk      │
│                                                              (vs:100-122)      │
│    • exit 1 if any error; prints `path: error` lines        (vs:222-243)      │
│  ALSO runs automatically as a pre-commit hook (.pre-commit-config.yaml)       │
└──────────────────────────────────────────────────────────────────────────────┘
┌─ 4. REGISTER ────────────────────────────────────────────────────────────────┐
│  Hand-edit olympus/olympus/skills/registry.yaml — add <name> to a phase's     │
│  primary | supplementary | conditional list (with a filter for conditional).  │
│  ⚠️ NO tool does this; pure manual YAML edit.                                 │
└──────────────────────────────────────────────────────────────────────────────┘
┌─ 5. LOCK (optional / observability) ─────────────────────────────────────────┐
│  python scripts/generate_skills_lock.py    → writes skills-lock.json          │
│  python scripts/verify_skills_lock.py       → diff lock vs disk; exit 1 on drift│
└──────────────────────────────────────────────────────────────────────────────┘
┌─ 6. EXERCISE (needs creds+DB; not isolated) ─────────────────────────────────┐
│  olympus run-phase <app_id> <phase> [--dry-run]                              │
│    → loads ALL phase skills (not just yours), runs the agent, writes artifacts│
└──────────────────────────────────────────────────────────────────────────────┘
┌─ 7. CERTIFY (separate tree) ─────────────────────────────────────────────────┐
│  cd eval-harness && python run-baselines.py --results-dir … --app … --phase … │
└──────────────────────────────────────────────────────────────────────────────┘
```

⚠️ **The authoring loop is not closed.** Steps 1-3 are skill-local and tool-supported. Steps 4-7 cross
into the delivery runtime and the eval island. There is no single command that takes a draft skill to a
certified, registered skill — and step 6 cannot run *just* your skill. (This is the contribution-framework
gap; see `05-contribution-TARGET.md` and `06-interface.md`.)

---

## 3. How a skill is loaded, parsed, and validated structurally before it can run

### 3a. Frontmatter parse (`frontmatter.py` / `loader.py`)

Two parsers exist — both find the block between the first two `---` fences:

- `parse_frontmatter_text(text)` (`frontmatter.py:67-81`): returns `{}` if no leading `---`; finds the
  closing `---` via `text.index("---", 3)`; `yaml.safe_load`s the slice; returns `{}` if the result
  isn't a dict. **Raises `yaml.YAMLError` on malformed YAML** (caller decides).
- `loader.parse_frontmatter(skill_name, …)` (`loader.py:442-466`): file-level wrapper; returns `{}` on
  missing file / OSError / **any** parse exception (swallows errors — `loader.py:465-466`).

`from_dict` (`frontmatter.py:84-106`) builds the typed dataclass; `_extract_list` coerces non-list values
in list-fields to `None` rather than raising (`frontmatter.py:58-64`) — robust to half-filled frontmatter.

### 3b. Body load + frontmatter strip (`load_skill`, `loader.py:196-236`)

```
load_skill(skill_name, skills_path=None):
    base = skills_path or _default_skills_path()          # config.skills_path, env fallback
    skill_file = base/<name>/SKILL.md
    if not exists: return ""                              # ← silent miss (loader.py:209-211)
    content = read_text                                   # OSError → WARN + return ""  (215-217)
    _warn_if_deprecated(name, content)                    # see 3d
    if content.startswith("---"):                         # strip frontmatter (222-227)
        content = content[ index("---",3)+3 : ].strip()   #   ValueError → leave as-is
    if <name>/references/ is dir:                          # append refs (230-234)
        content += "\n\n---\n\n## Reference Material\n\n" + join(_load_references(...))
    return content
```

`_load_references` (`loader.py:239-256`): globs `references/*.md` **sorted**, takes first
`MAX_REFERENCE_FILES = 4` (`loader.py:42`), truncates each to `MAX_REFERENCE_CHARS = 4000` with a
`[...truncated]` marker (`loader.py:43,251-252`).

### 3c. Budget-aware multi-skill load (`load_skills_for_phase`, `loader.py:335-439`) — the real entry path

This is what agent factories call (via `registry.load_phase_skills`). Reproduced logic:

```
load_skills_for_phase(skill_names, char_budget=40000, include_references=True, phase=""):
    base = skills_path or _default_skills_path()
    running_total = 0
    for idx, name in enumerate(skill_names):
        cfg, had_complex = _load_skill_config(base/name)      # config.json INDEPENDENT of char budget
        if cfg: configs[name] = cfg
        content = _load_skill_content(name, base, include_references)   # body+refs, frontmatter stripped
        if not content: continue                              # missing skill silently skipped
        formatted = f"# Skill: {name}\n\n{content}"
        if idx == 0:                                          # PRIMARY skill — always included
            if len(formatted) > char_budget:                  #   truncated to fit if needed
                formatted = formatted[:char_budget-30] + "\n\n[...truncated]"
                record truncated[]; WARN skill_loader.truncated
            append; running_total += len
        elif running_total + len(formatted) <= char_budget:   # SUBSEQUENT skills — only if they fit
            append; running_total += len
        else:
            skipped_due_to_budget.append(name); WARN skill_loader.skipped_for_budget
    # persist module-level summary + configs (loader.py:418-421)
    _last_load_summary = {phase, budget_total, budget_used, loaded_names, truncated, skipped_due_to_budget}
    return "\n\n---\n\n".join(parts)
```

**Invariants & gotchas:**
- ⚠️ **Order is destiny.** The first skill in the list is *always* loaded (truncated if oversized); later
  skills are dropped tail-first when the budget is exhausted (`loader.py:379-407`). So `registry.yaml`
  ordering (primary → conditional → supplementary) directly controls what guidance the agent sees under
  budget pressure. A misordered registry silently starves a skill.
- ⚠️ **Silent degradation.** A skill that doesn't fit is *skipped without error*; the only signal is a WARN
  log + the `_last_load_summary` slot (`get_last_load_summary()`, `loader.py:62-76`) and the human-readable
  `format_load_summary_for_report()` (`loader.py:79-131`). If a caller doesn't surface the summary, an agent
  can run with less guidance than intended and nobody knows.
- Default budgets differ by caller: `load_skills_for_phase` default `40000` (`loader.py:338`),
  `load_phase_skills` default `40000` (`registry.py:178`), `load_phase_skills_by_name` default `12000`
  (`registry.py:216`), but the discovery/generation factories pass `char_budget=300000` (per agent recon).
  ⚠️ No single constant — budgets are scattered literals.

### 3d. Deprecation handling (`_warn_if_deprecated`, `loader.py:263-296`)

Parses frontmatter *without* a YAML dep (line-by-line, `loader.py:281-288`) looking for `deprecated:` and
`replaced_by:`. If deprecated, logs a WARN naming the replacement but **still loads the stub** for
backward-compat (`loader.py:289-296`). There is no hard block on running a deprecated skill.

### 3e. There is **no structural gate before a skill can run**

`validate_skills.py` is a *pre-commit / manual* check, not a load-time guard. The loader will happily
load a `SKILL.md` with missing sections, a broken reference, or a non-matching `name`. The only thing
that stops a malformed skill is a developer running the validator or the pre-commit hook firing. **This
is the eval-before-trust gap** the runbook flags — captured fully in `04`/`05`.

---

## 4. Versioning & the iteration/refinement loop

**There is no semantic version field on a skill.** Versioning is *content-addressed* via the lockfile:

### 4a. `skills-lock.json` (`olympus/olympus/skills/skills-lock.json`)

```json
{ "schema_version": 1, "generated_at": "2026-05-09T02:32:50Z",
  "skills": { "acceptable-divergences": {
      "path": "cross-cutting/skills/acceptable-divergences",
      "sha256": "1301ba94…915f", "file_count": 1, "last_modified": "2026-05-05T22:05:57Z" }, … } }
```

169 skills tracked. Per-skill: `path`, `sha256`, `file_count`, `last_modified`.

### 4b. How the hash is computed (`generate_skills_lock.py:100-127`) — reproduced

```
hash_skill(skill_dir):
    hasher = sha256()
    for file in _iter_skill_files(skill_dir):       # DETERMINISTIC ORDER:
        #   1. SKILL.md  2. references/* (sorted)  3. scripts/* (sorted)
        #   4. assets/* (sorted)  5. config.json        (generate:82-97)
        rel = file.relative_to(skill_dir).as_posix()
        hasher.update(rel.utf8); hasher.update(NUL)   # path-sensitive (rename flips hash)
        hasher.update(file.read_bytes()); hasher.update(NUL)
    return hexdigest, file_count, newest_mtime
```

Ignores `.DS_Store`, dotfiles, `__pycache__` (`generate:40-63`). NUL separators make it sensitive to
both **content and filename** and stable across OSes (`generate:13-16`). ⚠️ **The lock is
observability-only — it does NOT influence loader behavior** (`generate:18-20`). It cannot prevent a
drifted skill from running; it can only *report* drift after the fact.

### 4c. Verify (`verify_skills_lock.py`) — recomputes via `build_lockfile()`, diffs into
**added / removed / modified** (skills on disk not in lock / in lock not on disk / different sha256),
exit 1 on any drift, `--json` for CI. (Per recon; same hashing module as generation.)

### 4d. The iteration loop, as it actually works today

```
edit SKILL.md  →  validate_skills.py  →  (commit, pre-commit re-validates)
            →  olympus run-phase <app> <phase>  (exercise — but loads ALL phase skills)
            →  inspect written artifacts (DB / filesystem)
            →  cd eval-harness; run-baselines.py compare vs golden corpus
            →  (manually) regenerate skills-lock.json
            →  repeat
```

⚠️ **The loop is open and slow:** no isolated single-skill runner, no command that ties an edit to its
eval score, no automatic lock refresh, no "diff my skill's output vs last run." The app's *entire stated
purpose* is rapid skill iteration, yet the iteration loop is the least-tooled part. This is the central
finding feeding the TARGET designs.

---

## 5. ⚠️ Schema linkage — the #1 drift risk (Phase 1 view; full treatment in `03`)

A skill declares its outputs in **Section 3 (Outputs)** of `SKILL.md` as prose that *cites* a schema path,
e.g. (`docs/skill-template.md:65-68`):

```
- Architecture fingerprint → `schemas/discovery/tech-fingerprint.schema.json`
- Module/component map → `assets/module-map-template.md`
```

**How that citation resolves — and where it drifts:**

| Question | Answer | Evidence |
|---|---|---|
| Is the schema path machine-resolved from the SKILL.md? | **No.** It's prose. `validate_skills.py` only checks `references/|scripts/|assets/` mentions resolve (`validate_skills.py:48-50,115-122`) — it does **not** validate `schemas/…` citations. A wrong schema path in a skill is never caught. | `validate_skills.py:48` |
| Where does the *runtime* find the schema? | `olympus/olympus/validators/schema_validator.py` hard-anchors `_SCHEMAS_ROOT = <repo>/schemas` (`schema_validator.py:30-31`) and maps **artifact filename → schema** via a hardcoded `_ARTIFACT_SCHEMAS` dict (`schema_validator.py:35-117`), using **`Draft202012Validator`** (`:25,214`). | runtime validator |
| Where does the *eval harness* find the schema? | `eval-harness/config.yaml:6` → `schemas_dir: ../specifications/schemas` **(path does not exist)**, and `eval-harness/evals/deterministic/schema_validator.py` uses **`Draft7Validator`** (`:23`) against whatever `--schema-path` it's handed. | harness validator |
| Are these the SAME schema files Olympus uses? | **Partly — and that's the danger.** The runtime reads repo-root `schemas/`. The harness's config default points at a non-existent `../specifications/schemas`. Schemas are *also* forked into `docs/discovery-rationalization-bundle/schemas/` and `mcp-server/schemas/`. **No single source of truth, two JSON-Schema drafts, one dead path.** | §00 §5 |

**Verdict for GATE 1:** A skill's output schema is declared by *convention in prose* and resolved by the
runtime from `schemas/` under Draft 2012-12, while the certifier resolves from a *different (missing) root*
under Draft 7. A skill can be authored citing a schema the certifier can't load and the runtime maps by a
*different key* (artifact filename, not the cited path). **This is the drift the whole runbook is
protecting against** — recommended single-source-of-truth fix in `03-validation-contract.md`.

---

## 6. Inventory (from recon)

- **~181** skill directories on disk under `cross-cutting/skills/`.
- **169** tracked in `skills-lock.json`; **~143** referenced in `registry.yaml` (incl. 4 `pending:true`).
- **12 unregistered** skills on disk (in neither lock nor registry), e.g. `temporal-workflow-scaffolder`,
  `xstate-fsm-generator`, `oscal-fragment-emitter`, `sse-broadcaster-scaffolder` — these load fine if named
  but are invisible to the registry's phase resolution.
- **0 dangling** registry→disk refs that error: the loader **silently skips** registry entries whose
  `SKILL.md` doesn't exist (`registry.yaml:18-22` note; `loader.py:372-373`), so a typo'd skill name in the
  registry is a silent no-op, not an error. ⚠️ Captured in `DRIFT-AND-GOTCHAS.md`.

---

## GATE 1 — Walk through creating one real skill end-to-end using only this spec

**Scenario: author `cobol-copybook-extractor` (a new extraction skill for COBOL copybooks).**

1. `scripts/bootstrap_skill.sh cobol-copybook-extractor --agent opus --description "Extract record layouts and field-level business meaning from COBOL copybooks. Triggers on copybook extraction, COBOL data layout, or @cobol-copybook-extractor."` → creates dir + stubbed SKILL.md + references/ + assets/ (§2 step 1).
2. Edit `SKILL.md`: fill all 9 sections (§1a / template). In **Outputs**, cite the schema, e.g.
   `→ schemas/modernization/business-rules.schema.json` (must be a real file under repo-root `schemas/` — §5).
3. Because it's a **new** skill (not yet in `skills-lock.json`), add the 5 CI-8 frontmatter list fields —
   `validation_commands, supported_stacks, anti_target_stacks, failure_classes, benchmark_tags` — or
   `validate_skills.py` fails (`validate_skills.py:161-186`). **Gap I had to fill:** the template
   (`docs/skill-template.md`) does **not** mention these 5 fields; only `validate_skills.py` and
   `frontmatter.py` do. A contributor following the template alone will fail validation on a new skill.
4. `python scripts/validate_skills.py cross-cutting/skills/cobol-copybook-extractor` → fix until exit 0.
5. Register: hand-edit `registry.yaml`, add under `extraction:` as a **conditional** with filter
   `{ primary_language: ["cobol"] }` (so it loads only for COBOL apps — `registry.py:113-114,_MEMBERSHIP_KEYS`).
   **Gap I had to fill:** there is no doc enumerating valid filter keys for a contributor — they are in
   code only (`registry.py:47-59`: `_MEMBERSHIP_KEYS` + `_BOOLEAN_KEYS` + the special `tech_stack_contains`/
   `risk_tier`/`disposition`). Listed here so the spec is self-sufficient:
   - membership keys: `primary_language, database, target_language, target_database, target_framework, archetype, identity_model`
   - boolean key: `has_source_available`
   - special: `tech_stack_contains` (substring), `risk_tier` (T1/T2/T3), `disposition` (one of the 7)
6. `python scripts/generate_skills_lock.py` to add it to the lock (optional but keeps `verify` green).
7. Exercise: `olympus run-phase <cobol_app_id> EXTRACTION --dry-run` to confirm the skill loads (check the
   skill-load summary), then without `--dry-run` to produce artifacts.
8. Certify: there is **no golden-corpus entry** for a COBOL app (corpus is cfwheels/dotnet/java/php/plsql/
   tsql + 4 ATLAS mocks — `config.yaml:28-164`). **Gap I had to fill / cannot fill from spec:** to eval a
   new-stack skill, a contributor must hand-author a `golden-corpus/<stack>/<archetype>/<app>/` with a
   `benchmark.yaml` + `<phase>-expected.json`. There is no tool to scaffold this. This is a hard blocker on
   "eval-before-trust" for any skill outside the 7 corpus stacks — the central Phase 4/5 finding.

**Remaining questions a contributor would still have to ask (now answered above, so the spec is
self-sufficient):** (a) the 5 required new-skill frontmatter fields aren't in the template → §1a(ii)/step 3;
(b) the legal registry filter keys aren't documented → step 5; (c) how to add golden-corpus ground truth →
step 8 (and `04-eval-harness-AS-IS.md §corpus`). With those filled, GATE 1 passes for an in-corpus stack;
for a new stack, the eval step is blocked by missing corpus tooling — a TARGET item, not a capture gap.
