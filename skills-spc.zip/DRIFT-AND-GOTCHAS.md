# DRIFT-AND-GOTCHAS — Skill Forge

Everything a rebuild must know: every ⚠️ GOTCHA from the spec, every place Skill Forge and Olympus can
diverge (especially schemas), and every TODO/FIXME/stub. All with `path:line`.

---

## A. The fidelity + design audit (FINAL gate)

### A1. CAPTURE fidelity — sampled functions reproduce logic, not summaries

| # | Function | Where reproduced | Verified against source |
|---|---|---|---|
| Orchestration 1 | `worker._process_app` dispatch + commit/rollback | `02 §3` | ✅ `worker.py:797-866` — 41-handler dict, single-transaction boundary, rollback path all match |
| Orchestration 2 | `BaseAgent.run` tool-use loop + `_trim_conversation` ledger | `02 §4,4a` | ✅ `base.py:108-202,244-321` — turn loop, stop_reason check, ledger reconstruction match |
| Orchestration 3 | `RalphLoop.record_iteration` exit logic + iter-cap precedence | `02 §7` | ✅ `ralph_loop.py:30-76,139-163` — PASSED/ESCALATED/RUNNING branches + 5-level precedence match |
| Harness 1 | `llm_judge.run_eval` scoring + scale bug | `04-AS-IS §4a` | ✅ `llm_judge.py:69-196` — 0–1 prompt vs 3.5 threshold, weighted avg, parse fallback match |
| Harness 2 | `golden_comparison.compute_metrics` P/R/F1 | `04-AS-IS §4b` | ✅ `golden_comparison.py:101-134` — tp/fp/fn set math, /0 guards match |
| Harness 3 | `run-baselines.run_comparison` tolerance application | `04-AS-IS §4d` | ✅ `run-baselines.py:252-291` — exact/numeric/set_contains + score formula match |

Spot-checks during audit also confirmed `traceability_checker` (`line_num < 1 or > total_lines`, `:87`)
and `coverage_auditor` (`covered = repo_files & analyzed_files; pct = len(covered)/len(repo_files)`,
`:140-146`) are reproduced as logic, not prose. **Fidelity audit passes** — the CAPTURE docs preserve
branches, loops, and error paths with citations.

### A2. CRITIQUE rigor — each weakness has code evidence, each target is concrete

| Critique weakness | Code evidence | Target concrete enough to build? |
|---|---|---|
| Harness grades output, not skill-as-run | `run-benchmark-suite.py:172` stub; `llm_judge.py:89` reads file only | ✅ fixture-capture via runtime envelope (`04-TARGET §5a`) |
| LLM-judge scale broken | `llm_judge.py:82` (0–1) vs rubric `pass_threshold:3.5`/`scale:"1-5"` (all 7) | ✅ `scale:{min,max}` + same-unit threshold (`04-TARGET §2`) |
| Phantom schemas/rubrics | `eval YAMLs schema_path: schemas/analysis.schema.json` (nonexistent); 3 missing rubrics | ✅ SSOT package + namespaced repoint (`03 §5`) |
| Judge not independent | maker `claude-sonnet-4-6` (`config.py:101`) vs judge `claude-sonnet-4-20250514` (`config.yaml:191`) | ✅ Opus grader + `must_not_equal_maker` (`04-TARGET §2`) |
| No self-improvement | full-tree search, none (`04-AS-IS §8`) | ✅ regression-capture loop (`04-TARGET §4`) |
| No certification gate | no CI skill validation; no CODEOWNERS (verified) | ✅ CI gate = harness verdict (`05-TARGET §2`) |
| No isolated skill run | `run-phase` loads all phase skills (`registry.resolve_skills`) | ✅ `olympus skill test --fixture` (`06 §4`) |

**Design audit passes** — every critique is evidenced; every target is buildable with a named seam.

---

## B. ⚠️ Skill Forge ↔ Olympus divergence points (the contract drift surface)

The whole reason for "two apps, one capability" is the shared contract. These are the places it can (and
already does) drift:

| # | Drift point | Today | Risk | Fix |
|---|---|---|---|---|
| **B1** | **JSON-Schema draft** | runtime `Draft202012` (`validators/schema_validator.py:25`); harness `Draft7` (`eval-harness/.../schema_validator.py:23`) | a 2020-12-only schema passes runtime, errors in harness | pin one draft (`03 §5`) |
| **B2** | **Schema root** | runtime `<repo>/schemas` (`:30-31`); harness `config.yaml:6 → ../specifications/schemas` (**does not exist**) | certifier resolves nothing | one SSOT package (`03 §5`) |
| **B3** | **Phantom schema paths** | eval YAMLs cite `schemas/analysis.schema.json` etc.; real files are namespaced `schemas/discovery/analysis-report.schema.json`; some (`generation-manifest`, `parity-report`) exist **nowhere** | every schema eval FAILs file-not-found | repoint to real namespaced names (`03 §2b`) |
| **B4** | **Schema forks** | `schemas/` + `docs/discovery-rationalization-bundle/schemas/` + `mcp-server/schemas/` (`analysis.schema.json` lives **only** in mcp-server) | 3 copies, no SSOT | delete fork, package, symlink-with-CI-check (`03 §5`) |
| **B5** | **Resolution key** | runtime resolves by **artifact filename** (`_ARTIFACT_SCHEMAS`, `:35-117`); harness by **explicit `--schema-path`** | the two validate by different keys | shared resolver fn (`03 §5`) |
| **B6** | **Skill `agent:` vs runtime model** | `SKILL.md agent: opus` is metadata; model comes from `OLYMPUS_<PHASE>_MODEL` (`config.py:101-108`) | author expects Opus, gets Sonnet | honor `agent:` or document clearly (`00b §4`) |
| **B7** | **Two `_STAGE_ARTIFACT_MAP` copies** | `worker.py:41-61` + `phase_runner.py:49-95` "in lock-step" | divergence ⇒ CLI-run vs worker-run get different context | single source |
| **B8** | **`phase_io` contract vs runtime** | contracts declare outputs the worker doesn't produce (`GenerationOutputs.generated_code/parity_report` "not currently produced", `phase_io.py:325-347`) | contract lies about behavior | reconcile or mark aspirational (already self-documented) |
| **B9** | **Skill membership has 3 sets** | on-disk (181) ⊋ locked (169) ⊋ registered (~143); 12 unregistered, registry typos silently skipped | "the library" is ambiguous | `status:` + single membership source (`05-TARGET §3`) |
| **B10** | **Temporal in docs vs SDK in code** | `CONTRIBUTING.md:13` "Temporal is the backbone"; `pyproject.toml` has no `temporalio`; `temporal/` dir is deferred | rebuilder trusts docs, builds wrong runtime | trust code; `02` provenance note; `memory/project_anthropic_pivot.md` |

---

## C. ⚠️ All GOTCHAs (consolidated from the spec)

**Skill model / loader (`01`):**
1. `agent:` field is **advisory only** — does not select the runtime model (`00b §4`, B6).
2. **Order is destiny** in budget loading — first skill always loaded (truncated if oversized), rest
   dropped tail-first; `registry.yaml` ordering silently controls guidance under budget (`loader.py:379-407`).
3. **Silent degradation** — a skill that doesn't fit the char budget is skipped with only a WARN +
   `get_last_load_summary()` slot; if unsurfaced, an agent runs under-guided (`loader.py:401-407`).
4. **Silent miss** — a registry entry naming a nonexistent skill is skipped, not errored
   (`registry.yaml:18-22`; `loader.py:372-373`).
5. **`redirect_to` (dataclass) vs `replaced_by` (loader/template)** — two names for the successor; loader
   reads `replaced_by` (`loader.py:287`), dataclass reads `redirect_to` (`frontmatter.py:99`).
6. **Template-vs-validator drift** — template (`docs/skill-template.md`) omits the 5 CI-8 fields the
   validator *requires* for new skills (`validate_skills.py:161-186`); validator does **not** check the 9
   sections the template claims it does (`docs/skill-template.md:209-215`).
7. **`config.json` bool-vs-int ordering** — `isinstance(bool,int)` is True; loader orders the check so
   bools survive (`loader.py:178-181`).
8. **Char budgets are scattered literals** — 40000 / 12000 / 300000 across loader/registry/factories; no
   single constant.

**Orchestration (`02`):**
9. **No sub-phase durability** — crash mid-agent re-runs the whole phase; Ralph Loop restarts from
   iteration 0 (in-memory, `ralph_loop.py:120-128`). Phase-level durability only.
10. **No cross-process work claims** — two pollers can grab the same app; safety relies on artifact upsert
    + last-writer-wins, not leasing (`02 §2`).
11. **Prior-artifact truncation** — `_gather_prior_artifacts` clips to ~120k chars (`worker.py:87-131`); a
    large upstream artifact can silently lose fields a downstream skill needs.
12. **`PhaseCheckpoint` import-guarded to `None`** until branch A17-P0-17 merges (`checkpoints.py:38-47`);
    intra-phase resume only works if/when merged.
13. **Budget breaker is a halt, not rollback** — mid-phase halt can leave partial artifacts
    (`worker.py:1177+`).
14. **Ralph T1=10/T2=5 by tier default** without a per-app override (`ralph_loop.py:23-27`) — slightly
    stronger than CLAUDE.md's "opt-in to 5-10" wording.

**Validation (`03`):** B1–B5 above.

**Harness (`04-AS-IS`):**
15. **Nothing loads `skill-evals/*.eval.yaml`** — the per-skill declarations + `consistency` eval type are
    dead config (grep: 0 `.py` references).
16. **`consistency` eval unimplemented** despite 8+ YAML declarations.
17. **LLM judge scale-broken** (1–5 vs 0–1, §A2/B-table).
18. **Judge calls direct Anthropic only** — `llm_judge.py:112` uses `anthropic.Anthropic`, **no Bedrock
    path** (unlike the runtime's `base.py:54-58`); a Bedrock-only environment cannot run the judge.
19. **All 26 skills `not-yet-baselined`** (`baselines/v0.1/manifest.yaml`); harness has never scored a
    skill end-to-end through the declared path.
20. **Golden corpus "not yet validated against a live pipeline run"** — multiple `*-expected.json`
    `source_of_truth` fields say so (e.g. `tsql/.../rationalization-expected.json:15`); ground truth is
    hand-authored, MP9-pending.

**Contribution (`05-AS-IS`):**
21. **Pre-commit lint is bypassable** (`--no-verify`); **CI does not validate skills** (only golden-corpus
    files — `eval-harness.yml` header); **no CODEOWNERS**. Merged = trusted.

**Interface (`06`):** no isolated single-skill run; no edit→score; headless `/insights/skills`.

---

## D. All TODO / FIXME / stub / "not yet" markers (verified)

| File:line | Marker | Impact |
|---|---|---|
| `eval-harness/tools/run-benchmark-suite.py:160,170,172` | "real run is a TODO stub" / `status:not_implemented` / "Live benchmark execution is not yet wired. TODO." | the only skill-running path is a stub |
| `eval-harness/evals/skill-evals/tdd-generation.eval.yaml:77` | `enabled: false` (+ `script: null`) | `test_first_order` eval planned, unbuilt |
| `eval-harness/baselines/v0.1/manifest.yaml:22,44,60,…` | `not-yet-baselined` ×26 | no skill baselined |
| `eval-harness/baselines/v0.1/README.md:5` | "skill execution pipeline is not yet operational against the golden corpus" | harness never run end-to-end |
| `eval-harness/golden-corpus/*/rationalization-expected.json:15` | "not yet validated against a live pipeline run (MP9-pending)" | ground truth unverified |
| `eval-harness/golden-corpus/README.md:113` | "Actually run (stubbed today, returns not_implemented)" | confirms stub |
| `olympus/olympus/fsm/checkpoints.py:38-47,204,249` | `PhaseCheckpoint = None` until A17-P0-17 | intra-phase resume unmerged |
| `eval-harness/config.yaml:6` | `schemas_dir: ../specifications/schemas` (path absent) | dead schema root (B2) |

*(`scripts/bootstrap_skill.sh` emits TODO placeholders by design — those are scaffold stubs, not code debt.)*

---

## E. The five defects that, together, make certification non-functional today

For the rebuilder's attention — these compound. The harness *appears* complete but **cannot certify a
skill end-to-end** because:
1. Nothing runs the per-skill eval declarations (C-15).
2. Schema evals reference phantom files (B3).
3. The LLM judge scale is broken (C-17).
4. Three referenced rubrics don't exist (`04-AS-IS §6.4`).
5. No skill is baselined and the corpus is pipeline-unvalidated (C-19, C-20).

Fixing these (R0 + R4 in `07-rebuild-order.md`) is the prerequisite for the entire eval-before-trust and
self-improvement story. **This is the single most important thing a rebuild must know.**
