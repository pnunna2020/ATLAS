# 04 — The Eval Harness 【CRITIQUE + TARGET】

Critique of the current harness against the three north-star goals, every weakness backed by code
evidence from `04-eval-harness-AS-IS.md`, then a concrete, buildable target architecture. The author built
this *unsure it was right* — so this is direct about what's wrong.

> **Headline critique.** Today's harness tests the **wrong function** (a static output file, not the
> skill-as-run), checks **shape it can't even load** (phantom schemas), scores **semantics on a broken
> scale** (1–5 rubrics graded as 0–1), uses a judge that is **not independent** of the maker, and has
> **no memory** — it cannot get sharper as failures accumulate. Four of these are *defects* (fixable
> wiring); the last two are *design gaps* (the redesign). The good news: the bones — deterministic +
> golden + LLM-judge layers, a corpus, a baseline/regression differ — are the right bones. They just
> aren't connected to the skill, to real context, or to a feedback loop.

---

## 1. Critique against requirement 1 — Does it eval with the REAL context envelope?

**No. It evaluates clean, isolated output text — testing a different function than the one that runs.**

**Evidence:**
- `llm_judge.py:89` feeds the judge only `output_text[:50000]` — the artifact, truncated, **with no
  inputs, no profile context, no prior artifacts.** But in production a skill's behavior is a function of
  the full envelope: system-prompt skills (budget-loaded, possibly *truncated* — `loader.py:379-407`),
  the user message (source path + context docs + **inlined prior artifacts**, themselves truncated to
  ~120k — `worker.py:87-131`), and the app_context platform keys (`02 §5`).
- `golden_comparison.py` and the deterministic evals likewise read only a finished file.
- The harness **never runs the skill** (`run-benchmark-suite.py` stub, `04-AS-IS §3`) — so it cannot
  observe context-dependent behavior at all.

**Why this is fatal:** a skill can score 5/5 on a hand-placed `analysis.json` and *fail in production*
because, under real budget pressure, its `SKILL.md` was truncated, or a prior artifact it depends on was
clipped at 120k and the field it needed was dropped. The harness is blind to exactly the failure modes
the orchestration introduces. **Schema-valid, rubric-passing output ≠ correct skill.**

**Target:** evaluate the skill **as Olympus runs it**, through a *real-context fixture* — see §5's
fixture model. The eval must reconstruct the exact envelope (skills loaded + budget + prior artifacts +
app_context) and **invoke the skill via the runtime**, then grade the produced artifact. Anything less
tests a function that doesn't ship.

---

## 2. Critique against requirement 2 — Shape vs Semantics

**It attempts both, but the semantic layer is broken and the shape layer is dead.**

**Evidence (shape):** schema validation references phantom files (`03 §2b`, `04-AS-IS §6.3`) → every
schema eval FAILs "file not found." Even when pointed at a real schema, it's Draft 7 vs the runtime's
Draft 2020-12 (`03 §2c`). So the shape layer doesn't run.

**Evidence (semantics):** two semantic signals exist —
- `golden_comparison.py` is **set-membership precision/recall** over entity *names* (`:101-119`). It
  measures *"did you find the same class/table/rule names,"* not *"is the business-rule description
  correct,"* *"is the disposition justified,"* or *"would this extraction actually preserve behavior."*
  Name-overlap is necessary but nowhere near sufficient for semantic correctness.
- `llm_judge.py` is the real semantic check — but it's **mechanically broken**: 1–5 rubrics scored as
  0–1 against a 3.5 threshold (`04-AS-IS §6.4`) ⇒ universal FAIL; and it's **not wired to a runner**
  (`04-AS-IS §6.1`).

**Judge independence (the bias requirement):** the runbook demands the grader **not** be the maker.
Today the maker is `claude-sonnet-4-6` (`config.py:101`) and the judge is `claude-sonnet-4-20250514`
(`config.yaml:191`) — a *different dated snapshot of the same model family.* That is **not** an
independent grader; same-family self-grading is known to be lenient on its own failure modes, and nothing
in the rubric or harness *enforces* maker≠judge. ⚠️ Self-grading bias is unaddressed.

**Target — the semantic layer (independent LLM-as-judge):**

```yaml
# rubric schema (TARGET) — versioned, scale-explicit, grader-pinned
rubric_id: discovery.v3
scale: { min: 1, max: 5 }          # ← explicit; the runner asserts emitted scores ∈ [min,max]
pass_threshold: 3.5                 # ← in the SAME units as scale (fixes the 1–5 vs 0–1 bug)
grader:
  model: claude-opus-4-8            # ← DIFFERENT, STRONGER family than makers (Sonnet) — independence
  must_not_equal_maker: true        # ← runner refuses to grade if grader model == maker model
  temperature: 0
prompt_template_ref: prompts/discovery-judge.v3.md   # ← versioned file, hashed into the result
dimensions:
  accuracy:      { weight: 1.2, criteria: [...] }
  completeness:  { weight: 1.2, criteria: [...] }
  traceability:  { weight: 1.0, criteria: [...] }
  ...
```

Rules the target judge enforces (each closes a named AS-IS gap):
1. **Scale coherence** — `scale` + `pass_threshold` are in the same units; the runner validates the
   model's returned scores are within `[min,max]` and **rejects/retries** out-of-range scores
   (fixes `04-AS-IS §6.4`).
2. **Grader ≠ maker** — `must_not_equal_maker` makes self-grading a hard error; default grader is a
   *stronger* tier (Opus) than the Sonnet makers (closes the bias gap).
3. **Real-context grading** — the judge prompt receives the **same envelope** the maker saw (inputs +
   profile + prior artifacts) so it grades the actual function (ties to §1).
4. **Structured, schema-validated verdict** — the judge returns `{dimensions, rationale, evidence_refs}`
   where every score must cite `file:line` or artifact evidence; a score with no evidence is rejected
   (raises the bar from "vibes" to "substantiated," matching the rubrics' own `criteria`).

---

## 3. Critique against requirement 3 — Determinism & reproducibility

**Scoring is only weakly deterministic, and judge prompts are unversioned.**

**Evidence:**
- `temperature=0.0` (`config.yaml:193`, `llm_judge.py:117`) reduces but does **not eliminate** variance —
  LLM judges drift across model snapshots and over time even at temp 0.
- **No seed, no multi-run aggregation** in the working path. The `consistency` eval (3 runs, min kappa)
  that *would* measure drift is **declared but unimplemented** (`04-AS-IS §6.2`).
- **The judge prompt is a hardcoded f-string** (`llm_judge.py:80-98`) and rubrics carry **no `version`
  field** (verified across all 7). So a rubric edit silently changes scores with no record of which
  prompt produced a given baseline — baselines become incomparable across edits.
- The pinned model is a **literal string in two places** (`config.yaml:191` + `llm_judge.py:101,166`) —
  they can drift from each other.

**Target — determinism & versioning:**
1. **Version everything that affects a score:** `rubric_id` + `prompt_template_ref` + `grader.model` are
   recorded in **every** result row. A result is `{score, rubric_id, prompt_sha256, grader_model,
   harness_version}`. Baselines are only compared within the same `(rubric_id, prompt_sha, grader_model)`
   tuple; a mismatch forces an explicit *re-baseline*, never a silent comparison.
2. **Multi-run + agreement metric:** run the judge **N=3** times (or N independent graders), report
   median score + inter-run agreement (Cohen's/Fleiss' kappa). Finally *implement* the `consistency`
   eval. A skill whose judge scores swing > tolerance is flagged "non-reproducible eval" — a signal the
   *rubric* is ambiguous, not just the skill.
3. **Anchor with deterministic checks first:** the binary deterministic evals (schema, traceability,
   coverage, format, xref) are fully reproducible — make them the *gate* and the LLM judge the *grade*.
   A skill must pass deterministic gates before its (noisier) semantic score counts. This bounds where
   non-determinism can affect the verdict.

---

## 4. ★ Critique against requirement 4 — SELF-IMPROVEMENT (the most important)

**It does not exist. The harness is static and cannot compound.** (`04-AS-IS §8`, definitive.)

**Evidence:** no failure capture, no case accumulation, no ratchet, no feedback into skill or rubric.
Corpus changes only by hand; baselines are frozen snapshots; tolerances are static literals
(`config.yaml:170-174`). When a skill fails *in production* (a real Olympus run), nothing flows back.

**This is the gap that makes the difference between a test suite and a compounding harness.** Design the
concrete loop:

### 4a. The regression-capture loop — `fail → capture case → add to eval set → re-run → ratchet`

```
                        ┌──────────────────────── PRODUCTION (Olympus runtime) ─────────────────────────┐
                        │  An Olympus run produces an artifact that is WRONG. The "wrong" signal is one  │
                        │  of:  (a) a gate REJECTED by a human reviewer (fsm GATE_REJECTED),             │
                        │       (b) a downstream phase fails because an upstream artifact was malformed,  │
                        │       (c) a parity/test failure in Generation,                                  │
                        │       (d) a schema validate_artifact 'fail' at an audit gate.                   │
                        └───────────────────────────────────┬───────────────────────────────────────────┘
                                                             │  emit FailureEvent {skill, app, phase,
                                                             │     envelope_ref, artifact_ref, signal,
                                                             │     reviewer_note, run_id, commit_sha}
                                                             ▼
        ┌──────────────────────── CASE MINTER (new component) ──────────────────────────────┐
        │ 1. Capture the FULL ENVELOPE (skills+budget+prior artifacts+app_context+source ref) │
        │    that produced the failure — frozen as a fixture (see §5).                        │
        │ 2. Mint a regression case:  golden-corpus/regressions/<skill>/<case_id>/            │
        │       envelope.json   (the real-context fixture, content-addressed)                 │
        │       expected.json   (corrected output — authored from the reviewer's fix)         │
        │       provenance.json (run_id, signal, who corrected it, date, linked prod failure) │
        │ 3. The corrected output is the new ground truth: "this case must never regress."    │
        └───────────────────────────────────┬───────────────────────────────────────────────┘
                                             │  case added to the skill's eval set
                                             ▼
        ┌──────────────────────── EVAL SET (grows monotonically) ─────────────────────────────┐
        │  base corpus  +  Σ captured regression cases (per skill).                            │
        │  Each skill's bar = (deterministic gates) ∧ (semantic ≥ threshold) ∧ (ALL regression │
        │  cases pass).  Adding a case RAISES the bar permanently — the ratchet.               │
        └───────────────────────────────────┬───────────────────────────────────────────────┘
                                             │  re-run on every skill edit + nightly
                                             ▼
        ┌──────────────────────── LESSON DISTILLER (new component) ───────────────────────────┐
        │  Periodically cluster captured failures for a skill. For a recurring class, distill  │
        │  a "lesson": EITHER (a) a new Quality-Rule / Gotcha appended to the SKILL.md (so the  │
        │  MAKER avoids it), OR (b) a new rubric criterion / a new deterministic check (so the  │
        │  GRADER catches it). Lessons are PRs, reviewed, then merged — closing the loop into   │
        │  both the skill AND the harness.                                                      │
        └──────────────────────────────────────────────────────────────────────────────────────┘
```

### 4b. Why this compounds (and doesn't just grow)

The runbook warns to prove the loop *compounds* rather than merely *grows*. The mechanism:
- **Monotonic ratchet:** a captured case can only ever *raise* a skill's bar (a fixed regression must
  keep passing). A skill's quality is therefore non-decreasing across edits.
- **Distillation prevents linear bloat:** without §4a-step-3 (Lesson Distiller), the eval set grows
  O(failures) forever and runtime explodes. Distillation collapses a *cluster* of similar failures into
  **one** rule/criterion that prevents the whole class — so the eval set grows with *distinct failure
  classes* (sub-linear), not raw incidents. Old cases that are now subsumed by a deterministic rule can
  be **retired to a sampled regression tier** (run a representative subset + full set weekly), keeping
  per-edit eval cost bounded. ⚠️ **Log every retirement/sampling** so coverage reduction is never silent
  (a `completeness-critic` invariant).
- **The bar sharpens the maker, not just the grader:** because lessons feed back into `SKILL.md` Quality
  Rules/Gotchas (step 3a), the *next* generation of that skill starts higher. The harness getting sharper
  and the skill getting better are the same loop.

### 4c. Guard against the loop's failure mode

The dangerous degenerate is **judge-rejected cases re-entering forever** (the loop never converges). Fix
(borrowed from adversarial-verify patterns): a minted case requires a **human-or-independent-grader
confirmed correction** before entering the eval set; cases that fail confirmation are quarantined, not
re-queued. Dedup minted cases by `(skill, envelope_hash)` so the same failure isn't captured twice.

---

## 5. Target harness architecture — end to end

```
┌─ CASE FORMAT ────────────────────────────────────────────────────────────────────────────┐
│ eval-set/<skill>/<case_id>/                                                                │
│   envelope.json   real-context fixture (§5a) — content-addressed, the EXACT maker input    │
│   expected.json   ground truth (corpus seed OR captured-and-corrected regression)          │
│   rubric_ref      → rubrics/<category>.<ver>.yaml                                           │
│   provenance.json origin (seed|regression), run_id, corrector, date, failure signal        │
└────────────────────────────────────────────────────────────────────────────────────────┘
┌─ 5a. REAL-CONTEXT FIXTURE MODEL ──────────────────────────────────────────────────────────┐
│ A fixture is the serialized prompt envelope (02 §5) the skill actually receives:           │
│   { skills_loaded:[…], skill_budget, truncations:[…],   ← from loader.get_last_load_summary │
│     app_context:{primary_language, database, target_*, archetype, risk_tier, disposition},  │
│     prior_artifacts:{name→content (post-120k-truncation, as the runtime would feed)},        │
│     source_ref: git-sha+path, profile_ref }                                                 │
│ Captured by instrumenting the runtime to dump the envelope on any run (prod or eval).       │
│ ⇒ evaluating the fixture == evaluating the function that ships (closes §1).                 │
└────────────────────────────────────────────────────────────────────────────────────────┘
┌─ 5b. SCORING (gate then grade) ───────────────────────────────────────────────────────────┐
│ STAGE 1 — DETERMINISTIC GATES (binary, reproducible, must all pass):                       │
│    schema(Draft2020-12, resolved via the runtime's filename→schema map — 03 §5),           │
│    traceability (file:line resolve), coverage ≥ θ, format, cross-ref integrity.             │
│ STAGE 2 — SEMANTIC GRADE (only if Stage 1 passes):                                          │
│    independent LLM judge (Opus grader ≠ Sonnet maker), N=3 runs, median score + kappa,      │
│    versioned rubric+prompt, real-context envelope, evidence-cited scores.                   │
│ STAGE 3 — REGRESSION SET: ALL captured cases for the skill must pass (the ratchet).         │
│ VERDICT: CERTIFIED iff Stage1 ∧ (Stage2 median ≥ pass_threshold) ∧ Stage3 ∧ kappa ≥ θ_k.    │
└────────────────────────────────────────────────────────────────────────────────────────┘
┌─ 5c. RESULT STORAGE & METRICS (per skill, per run) ───────────────────────────────────────┐
│ Persist to a results store (DB table, not loose JSON) keyed by                             │
│   (skill, skill_content_sha256 [from skills-lock!], rubric_id, prompt_sha, grader_model,    │
│    harness_version, run_id, date). Metrics emitted per skill:                               │
│      pass_rate, semantic_score (median+kappa), schema_pass, traceability_pass,              │
│      regression_cases_passing/total, cost_usd, latency_s, tokens.                           │
│ ⇒ trend over time; a skill's trust = f(these). Wire to /insights/skills (06).               │
└────────────────────────────────────────────────────────────────────────────────────────┘
┌─ 5d. REGRESSION-CAPTURE LOOP (§4) ── fail → mint case → add → re-run → distill → ratchet ──┐
└────────────────────────────────────────────────────────────────────────────────────────┘
```

**Concrete build deltas from AS-IS (each is small and points at real code):**
1. Fix the 5 wiring defects first (`04-AS-IS §6`): connect a runner to `skill-evals/*.eval.yaml`; fix
   rubric scale (`scale:{min,max}` + same-unit threshold); create the 3 missing rubrics or repoint the
   YAMLs; repoint schema paths to namespaced real files (`03 §5`); implement `consistency`.
2. Add the **fixture capture** by instrumenting the runtime envelope (`get_last_load_summary` already
   exists — `loader.py:62-76` — extend it to dump the full envelope).
3. Add the **case minter** as a hook on `GATE_REJECTED` / parity-fail / schema-fail-at-gate
   (`fsm/hooks/gates.py` is the natural seam).
4. Move results from loose `baselines/vX/*.json` to a **results table** (`olympus/db` already has
   `AgentRun`; add `SkillEvalResult`).
5. Make the **grader Opus, makers Sonnet**, enforce `must_not_equal_maker`.

---

## GATE 4 — Does the TARGET satisfy all three app goals? Point to the mechanism for each.

| Goal | Delivered by | Mechanism (named) |
|---|---|---|
| **Eval-before-trust** | §5b VERDICT + §5c trust=f(metrics) | A skill is `CERTIFIED` only after Stage1∧Stage2∧Stage3 pass; trust status is computed from the results store and gates registry entry (tie-in: `05-contribution-TARGET §quality-gate`). No green eval ⇒ no trust. |
| **Real-context evaluation** | §5a fixture model + §1 | The eval runs the skill on the **serialized production envelope** (skills+budget+truncations+prior artifacts+app_context), not clean text — same function that ships. |
| **Self-improvement over time** | §4 regression-capture loop | `fail → mint case → add to eval set → re-run → ratchet`, with §4b distillation feeding lessons into both `SKILL.md` (maker) and rubric/checks (grader), and §4c convergence guards. The bar is monotonic; distillation keeps it sub-linear. |

All three have a specific delivering mechanism. ⚠️ The one piece that is *organizational, not code* —
producing the **corrected `expected.json`** for a minted regression case (§4a step 2) — requires a human
or independent-grader correction. That's by design (§4c), but it means the loop's compounding rate is
bounded by review throughput; the Lesson Distiller (§4a step 3) is what keeps that bounded cost from
capping total quality. **GATE 4 passes**, with that dependency flagged for the author's pressure-test.
