# 04 — The Eval Harness 【CAPTURE】 (AS-IS)

Faithful reproduction of the eval harness *as it exists today*. The critique and target design are in
`04-eval-harness-TARGET.md`. `path:line` throughout. Be precise about what it does and does **not** check.

> **One-sentence verdict (capture, not opinion):** the harness is a **static, output-grading framework**
> that compares pre-existing artifact files to a frozen golden corpus — and three wiring defects + zero
> baselined skills mean **most of its scoring paths do not currently execute end-to-end.** Evidence below.

---

## 1. What the harness IS — architecture

`eval-harness/` is a **standalone tree** that imports nothing from the runtime (sole exception:
`tools/skill_filter.py` imports `olympus.skills.frontmatter`). It has **no `pyproject.toml`** — it's run
as loose scripts (`README.md`, `00b §2f`). Pieces:

```
config.yaml          global thresholds, corpus registry, rubric map, pinned LLM model
run-baselines.py     ★ the actual entry point: corpus self-check / actual-vs-expected compare
compare-baselines.py regression diff between two baseline versions
rubrics/*.yaml       7 category rubrics (LLM-judge dimensions, 1-5 scale)
evals/
  deterministic/     schema_validator(Draft7), traceability_checker, coverage_auditor,
                     format_compliance, cross_reference_integrity
  non-deterministic/ llm_judge.py, golden_comparison.py
  skill-evals/*.eval.yaml   22 per-skill declarations  ← ⚠️ NOTHING LOADS THESE (§6)
golden-corpus/       ground-truth *-expected.json per app×phase
baselines/v0.1/manifest.yaml   all 26 skills "not-yet-baselined"
tools/               run-benchmark-suite.py (STUB), report_generator, skill_filter, validate-expected-files
```

**Output convention** (`README.md:110-122`): every eval prints one JSON object to stdout with at least
`{"status": "PASS"|"FAIL", "eval_name": …}`; non-zero exit = execution error, not eval failure.

---

## 2. How a test case is defined

Two parallel, **non-interoperating** definitions exist:

### 2a. Golden-corpus expected-output files (what `run-baselines.py` actually uses)

On disk: `golden-corpus/{stack}/{archetype}/{app}/{phase}-expected.json` (+ `benchmark.yaml`). Structure
(`run-baselines.py:87-105` validates required top-level keys):

```json
{ "skill": "analyze-application", "phase": "discovery", "app": "cfwheels-test-app",
  "version": "1.0", "created": "2026-04-09",
  "expected": { "language": "ColdFusion", "framework": "CFWheels", "file_count": 85, "modules": [...] },
  "tolerances": {
    "exact_match": ["language","framework"],
    "numeric_tolerance": {"file_count": 0.15, "loc_estimate": 0.25},
    "set_contains": ["entry_points","modules"],
    "set_minimum_coverage": {"entry_points": 0.75, "modules": 0.80}
  } }
```

Required keys enforced: `skill, app, version, created, expected, tolerances`
(`run-baselines.py:90-94`). Allowed tolerance keys: `exact_match, fuzzy_match, numeric_tolerance,
set_contains, set_minimum_coverage` (`run-baselines.py:97-104`) — unknown keys flagged.

### 2b. Per-skill eval declarations (`skill-evals/*.eval.yaml`) — ⚠️ orphaned config

22 files declaring, per skill: `golden_corpus.{repo,ground_truth}`, an `evals:` list (each with
`type: deterministic|non-deterministic|custom`, `script:`, `args:`), `thresholds:`, and
`pass_criteria: {deterministic: all_pass, non_deterministic: average_above_threshold}`. Example
(`analyze-application.eval.yaml`): 4 deterministic evals (schema, traceability, coverage, format) + 2
non-deterministic (llm_judge, golden_comparison). **⚠️ No code loads these files** — see §6. They are an
*intended* wiring that was never connected to a runner.

---

## 3. How the harness runs a skill against cases

**It does not run skills at all.** Every eval consumes a **pre-existing output file** via `--output-path`.

- `llm_judge.py`, `golden_comparison.py`, `schema_validator.py`, `traceability_checker.py`,
  `coverage_auditor.py`, `format_compliance.py`, `cross_reference_integrity.py` all take an
  `--output-path` to an artifact already on disk.
- `tools/run-benchmark-suite.py` is the only thing that *could* run skills, and it is a **stub**:
  real execution returns `{"status": "not_implemented"}` with a "Live benchmark execution is not yet
  wired. TODO." comment (`run-benchmark-suite.py:~160-172`).

So the function under test is **"does this output file score well against a rubric/ground-truth,"** not
**"does this skill behave correctly when Olympus runs it."** The harness is an **output grader, not a
skill runner.** (This is the single most important fact for the TARGET critique.)

---

## 4. How it SCORES — reproduced logic per eval

### 4a. LLM-as-judge (`evals/non-deterministic/llm_judge.py`) — the semantic check

```python
build_eval_prompt(output_text, rubric):           # :69-98
    # interpolates rubric dimensions+criteria, then:
    "Score the following output on each dimension from 0.0 to 1.0."   # ← :82  PROMPTS 0–1 SCALE
    "OUTPUT TO EVALUATE:\n{output_text[:50000]}"   # ← :89  TRUNCATED to 50k chars, NO inputs/context
    # demands strict JSON: {"dimensions": {...}, "rationale": "..."}

call_claude(prompt, model="claude-sonnet-4-20250514"):   # :101-120
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])   # ← DIRECT API ONLY (no Bedrock)
    message = client.messages.create(model=model, max_tokens=4096, temperature=0.0,
                                     messages=[{"role":"user","content":prompt}])  # :113-118

run_eval(output_path, rubric_path):                # :145-196
    rubric = load_yaml(rubric_path)
    result["pass_threshold"] = rubric.get("pass_threshold", 0.7)   # ← :162 reads 3.5 from rubric!
    response = call_claude(build_eval_prompt(load_file(output_path), rubric), model=rubric.get("model", default))
    dimensions = parse_scores(response)            # strips ```fences, json.loads, fallback brace-extract :123-142
    weighted_sum = Σ score[d]*weight[d];  average = weighted_sum/total_weight    # :180-191
    result["pass"] = average >= result["pass_threshold"]    # ← :193  0–1 average vs 3.5 threshold
    result["status"] = "PASS" if pass else "FAIL"
```

### 4b. Golden comparison (`evals/non-deterministic/golden_comparison.py`) — precision/recall

```python
extract_entities(data):                            # :52-93
    # pulls names from {"entities":[...]} and category keys
    # (classes, functions, methods, tables, views, rules, findings, components,
    #  modules, services, endpoints, stored_procedures, triggers, business_rules)
compute_metrics(output_set, truth_set):            # :101-134
    norm = lowercase+strip                          # :96-98
    tp = out & truth;  fp = out - truth;  fn = truth - out
    precision = tp/(tp+fp);  recall = tp/(tp+fn)
    f1 = 2*p*r/(p+r)                                # :117-119, all guarded /0 → 0.0
run_comparison(...): status = "FAIL" if f1 < threshold (default 0.85)    # :180-181
```

### 4c. Deterministic evals (reproduced from recon + direct read)

- **schema_validator** (`Draft7Validator`): `iter_errors`; FAIL on any violation; FAIL if output or
  schema file missing (`eval-harness/.../schema_validator.py:87-100,120-136`). ⚠️ Draft 7 vs runtime's
  2020-12 (`03 §2c`).
- **traceability_checker**: regex-extracts `path:line` refs, requires file to exist + `1 ≤ line ≤
  total_lines`; PASS iff zero broken refs.
- **coverage_auditor**: walks repo (skipping vendor dirs), `coverage = |repo ∩ analyzed| / |repo|`;
  PASS iff `coverage ≥ threshold` (default 0.95).
- **format_compliance**: extracts `#`-headers from a template, fuzzy-matches against output headers;
  FAIL if any required section missing OR `{{PLACEHOLDER}}` remains.
- **cross_reference_integrity**: builds forward ref graph, FAIL on orphan refs or missing back-references.

### 4d. `run-baselines.py` comparison (the path that actually runs end-to-end)

`run_comparison` (`run-baselines.py:252-291`) applies the tolerances from §2a:
- `compare_exact_match` — case-insensitive string eq (`:108-122`)
- `compare_numeric_tolerance` — `deviation = |act-exp|/|exp|` ≤ tolerance; exp=0 ⇒ `deviation=|act|` (`:125-174`)
- `compare_set_contains` — extracts names from str/dict items, `coverage = |matched|/|expected|`, PASS iff
  `≥ set_minimum_coverage[field]` (`:177-249`)
- overall: `score = pass/(pass+fail)`; `overall_status = PASS iff fail_count==0` (`:275-291`)

Two modes (`run-baselines.py:294-475`): **self-check** (validate corpus files well-formed) and
**comparison** (actual results dir vs expected). It enumerates a **hardcoded** `APPS` (11) × `PHASES` (7)
grid with its own `SKILL_MAP` (`run-baselines.py:37-74`) — **independent of `skill-evals/*.eval.yaml`.**

---

## 5. What pass/fail MEANS, and what happens to a failing skill

- **Pass/fail** is per-eval, per-file, against frozen ground truth or a rubric threshold.
- Results: `run-baselines.py --save-baseline vX` writes per-app/phase result JSON + `summary.json` under
  `baselines/vX/` (`run-baselines.py:478-498`). `compare-baselines.py` diffs two versions with tolerances
  `{deterministic:0.0, llm_judge:0.05, golden_f1:0.03, consistency_kappa:0.05}` (`config.yaml:170-174`),
  classifying STABLE/IMPROVED/REGRESSED and exiting 1 on regression.
- **What happens to a failing skill: nothing automatic.** No code path quarantines a skill, blocks its
  registry entry, opens an issue, or captures the failing case. The harness produces a report; a human
  reads it. ⚠️ **There is no link between a harness FAIL and the skill's trust status** — a failing skill
  remains live in `registry.yaml` (confirmed in `05-contribution-AS-IS.md`).

---

## 6. ⚠️ Four wiring defects — what the harness does NOT currently do (verified by direct read)

These are *capture* facts (with evidence), not yet critique:

1. **Nothing executes the per-skill eval declarations.** Grep for any `.py` loading `*.eval.yaml` /
   `skill-evals` returns **zero matches**. The 22 `skill-evals/*.eval.yaml` files — the entire
   skill→evals→thresholds mapping, including the `consistency` (3-run kappa) eval type — are **dead
   config.** `run-baselines.py` uses its own hardcoded grid and never reads them.

2. **The `consistency` eval type has no implementation.** It's declared in 8+ skill-eval YAMLs
   (`cato-compliance:89`, `module-design:97`, `parity-verifier`, …) with `runs: 3, minimum_kappa: …`, but
   no script computes kappa across runs. (`README.md` lists no consistency script; no `.py` references
   kappa.) It is aspirational.

3. **Schema-validation evals reference phantom schemas** (full proof in `03 §2b`): `schema_path:
   schemas/analysis.schema.json` etc. resolve to **nothing** (real schemas are namespaced under
   `schemas/discovery/…`), and `config.yaml:6 schemas_dir: ../specifications/schemas` **does not exist.**
   Run as wired, every schema eval returns FAIL "Schema file not found."

4. **The LLM-judge scale is internally contradictory.** All 7 rubrics declare `scale: "1-5"` +
   `pass_threshold: 3.5` (verified across all 7), but `llm_judge.py:82` prompts the model to score
   *"0.0 to 1.0"* and computes `pass = average >= pass_threshold` reading **3.5** from the rubric
   (`llm_judge.py:162,193`). A 0–1 average **cannot reach 3.5 ⇒ deterministic FAIL for every skill.**
   (Its own docstring/default assumes 0.7 — `llm_judge.py:17,22,162` — so the *default* path is coherent
   but the *rubrics on disk* break it.) Additionally, three referenced rubrics —
   `rubrics/{analysis-accuracy,code-quality,extraction-quality}.yaml` — **do not exist** (only 7
   `*-rubric.yaml` do).

5. **Nothing is baselined.** `baselines/v0.1/manifest.yaml`: **all 26 skills `status:
   not-yet-baselined`**, every eval `not-run`/`null`, blocked on "cfwheels-test-app ground truth
   annotation." v0.1 is an empty template. So defects #3 and #4 have **never gated a real run** — they're
   latent because the harness has never actually scored a skill end-to-end through the declared path.

6. **`tools/run-benchmark-suite.py` is a stub** — live execution returns `not_implemented`
   (`run-benchmark-suite.py:~172`).

**What DOES work end-to-end today:** `run-baselines.py` self-check (corpus well-formedness) and the
actual-vs-expected tolerance comparison (§4d) when given a results dir; and any *individual* eval script
run by hand with valid `--output-path`/`--schema-path`/`--rubric-path`. The orchestration that would tie
skills to their evals, run the LLM judge against the on-disk rubrics, and validate schemas — does not.

---

## 7. What the harness does NOT check (the gaps the TARGET must close)

| Dimension | Checked today? | Evidence |
|---|---|---|
| **Real production context** (inputs + profile + prior artifacts) | ❌ judges output text only, truncated 50k, no envelope | `llm_judge.py:89` |
| **Live skill behavior** (run the skill, grade the run) | ❌ grades pre-written files; runner is a stub | §3; `run-benchmark-suite.py:172` |
| **Semantics** (right answer) beyond entity precision/recall | ⚠️ partial — LLM judge *would* if it ran; golden_comparison is set-membership only | §4a (broken), §4b |
| **Determinism / reproducibility** of judge | ⚠️ `temperature=0.0` only; no seed, no multi-run; consistency type unimplemented | `config.yaml:193`; §6.2 |
| **Judge ≠ maker** (independent grader) | ⚠️ judge is `claude-sonnet-4-20250514`, maker is `claude-sonnet-4-6` — *different snapshot, same family*; not an independent model, and the rubric doesn't enforce it | `config.yaml:191` vs `config.py:101` |
| **Judge-prompt versioning** | ❌ prompt is a hardcoded f-string; rubrics have no `version` field | `llm_judge.py:80-98`; rubrics |
| **Self-improvement / regression capture** | ❌ **entirely absent** — definitive | §8 |
| **Failing-skill consequence** | ❌ no quarantine, no trust gate, no case capture | §5 |

---

## 8. ⚠️ The self-improvement loop — definitive finding: IT DOES NOT EXIST

A full-tree search for `regression / capture / failure / feedback / lesson / production / incident /
accumulate / ratchet` found **no mechanism** that:
- captures a production failure and adds it to the eval set,
- converts a false negative / missed case into new ground truth,
- ratchets a threshold upward as skills improve,
- accumulates "lessons" that feed back into a skill or rubric.

What exists is **manual, static**: hand-authored golden corpus, hand-frozen baselines, and a
two-version `compare-baselines.py` diff with **static** tolerances (`config.yaml:170-174`). The corpus
only changes when a human writes a new `*-expected.json`. **The harness cannot get sharper over time on
its own** — it is a fixed test suite, not a compounding one. This is the gap the runbook calls *"the
difference between a static test suite and a compounding harness,"* and the entire focus of
`04-eval-harness-TARGET.md`.

---

## 9. TODO/FIXME/stub markers found

| File | Marker | Meaning |
|---|---|---|
| `tools/run-benchmark-suite.py:~160,172` | "not yet wired. TODO" | live skill execution unimplemented |
| `skill-evals/tdd-generation.eval.yaml:~70-77` | `script: null, enabled: false` | `test_first_order` custom eval planned, not built |
| `baselines/v0.1/manifest.yaml:~22-24` | "pending golden corpus annotation" | all 26 skills unbaselined |
| `golden-corpus/COVERAGE-AUDIT.md:~99-101` | "Deferred … MP9" | natural-adabas baseline deferred |
| 8× `skill-evals/*.eval.yaml` | `name: consistency` | eval type with no implementation |
