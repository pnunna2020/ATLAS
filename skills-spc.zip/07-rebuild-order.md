# 07 — Rebuild Order 【CAPTURE + CRITIQUE】

Dependency-correct order to rebuild Skill Forge from these specs. Each phase has a **proof check**. Phases
are marked **[AS-IS]** (rebuild faithfully) or **[→TARGET]** (build to the redesign, not today's code).
The harness (Phase 4) and contribution framework (Phase 5) build to TARGET; everything else is AS-IS.

> **Critical-path insight.** The schema SSOT fix (`03 §5`) and the harness wiring fixes (`04-AS-IS §6`)
> are **prerequisites**, not enhancements — the certification gate (`05-TARGET §2`) cannot exist until the
> harness can actually produce a verdict, which it can't today (phantom schemas, broken scale, no runner).
> So the build order front-loads "make the contract one contract" and "make the harness run."

---

## Dependency graph of the rebuild

```
R0 schemas (SSOT)  ──┬─────────────────────────────────────────────┐
   [→TARGET: 03 §5]  │                                              │
                     ▼                                              ▼
R1 skill model     R2 SDK orchestration runtime            (both depend on R0 schemas)
   [AS-IS: 01]  ──▶    [AS-IS: 02]  ──────────┐
   loader/registry     BaseAgent + FSM        │
        │              + phase_io contracts    │
        │                       │              │
        ▼                       ▼              ▼
R3 validation contract   (R2 produces artifacts R3 validates)
   [AS-IS+TARGET: 03]  ◀────────┘
        │
        ▼
R4 EVAL HARNESS  ── depends on R0(schemas), R1(skill), R2(runtime, for real-context fixtures), R3(contract)
   [→TARGET: 04-TARGET]   ★ must build the fixture-capture + scoring + regression loop
        │
        ▼
R5 CONTRIBUTION FRAMEWORK ── depends on R4 (certification gate IS the harness verdict)
   [→TARGET: 05-TARGET]   ★ graduation/status + CI gate + namespacing
        │
        ▼
R6 INTERFACE (olympus skill group) ── depends on R1,R2,R4,R5 (wraps all of them)
   [AS-IS surfaces + →TARGET group: 06]
```

---

## Phase-by-phase rebuild with proof checks

### R0 — Schema single source of truth  **[→TARGET, `03 §5`]**
Build first; everything validates against it. Publish `schemas/` as one versioned package
(`olympus-contracts`), pin **Draft 2020-12**, delete the `docs/.../schemas` fork, expose the
filename→schema resolution as a shared function.
**Proof:** a test asserts (a) every `_ARTIFACT_SCHEMAS` target resolves, (b) every
`skill-evals/*.eval.yaml schema_path` resolves to a real namespaced file, (c) one draft only. *(This test
would fail on today's code — `03 §2b` — which is the point.)*

### R1 — Skill model & loader  **[AS-IS, `01`]**
Rebuild `cross-cutting/skills/<name>/` convention + `loader.py`/`frontmatter.py`/`registry.py` +
`validate_skills.py` + `bootstrap_skill.sh` + the content lock. Faithful reproduction — this is settled.
**Proof:** `01 GATE 1` — scaffold→validate→register→lock a real skill; loader returns its body
(frontmatter stripped, refs appended, budget honored, order-preserving).

### R2 — SDK orchestration runtime  **[AS-IS, `02`]**
Rebuild `BaseAgent.run()` (Anthropic streaming tool-use loop + context-trim ledger), the FSM poller
(`worker.py` dispatch + `states.py` + `machine.py`), `phase_runner`, the Ralph Loop, ledger/checkpoints,
and `phase_io` contracts. **Not Temporal** (`02` provenance note).
**Proof:** `02 GATE 2` — a full Discovery→Generation run hits every state with its documented
state-handling + failure behavior; artifacts persist mid-run; a phase re-runs cleanly after a kill
(phase-level durability).

### R3 — Validation contract  **[AS-IS capture + TARGET fix, `03`]**
Rebuild the runtime `validate_artifact` (filename→schema, Draft2020-12, warn/fail/conditional-fail
policy) **and** apply the SSOT so the harness validator (R4) shares R0's resolution.
**Proof:** `03 GATE 3` — a new skill authored against §3 alone (no app internals) produces an artifact
the runtime validates; the same schema/draft/key is used by R4.

### R4 — Eval harness  **[→TARGET, `04-TARGET`]** ★ build to TARGET, not AS-IS
Build, in order: (1) fix the 5 wiring defects so a verdict is producible (`04-AS-IS §6`); (2) real-context
**fixture capture** (instrument the R2 envelope); (3) **gate-then-grade** scoring (deterministic gates →
independent Opus judge, N-run + kappa, versioned rubric/prompt → regression set); (4) results store;
(5) the **regression-capture loop** (fail→mint→add→re-run→distill→ratchet) with convergence guards.
**Proof:** `04 GATE 4` — eval-before-trust + real-context + self-improvement each demonstrably delivered
by a named mechanism; a seeded production failure becomes a regression case that permanently raises the
bar. ⚠️ Depends on R2 (to run skills for fixtures) and R0/R3 (schema resolution).

### R5 — Contribution framework  **[→TARGET, `05-TARGET`]** ★ build to TARGET
Build: `status:` graduation (draft→tested→trusted→deprecated) in loader+registry; CI gate
(`validate_skills` server-side + lock verify + `olympus skill eval` certification + CODEOWNERS);
namespacing + collision checks; semver + ownership; self-improvement tie-in (inherit eval cases, owner
notified on production failure).
**Proof:** `05 GATE 5` — a brand-new contributor ships a `CERTIFIED` skill end-to-end without a maintainer
deriving quality; `draft` skills cannot enter production resolution; the certification gate = the R4
verdict. ⚠️ Depends on R4 (no certification gate without a working harness verdict).

### R6 — Interface  **[AS-IS surfaces + →TARGET `olympus skill` group, `06`]**
Rebuild the AS-IS surfaces (authoring scripts, `olympus` CLI, eval CLI) and add the cohesive
`olympus skill {new,list,info,test,eval,register,lint,diff}` group that wraps R1/R2/R4/R5, plus a thin web
view over `/insights/skills`.
**Proof:** `06 GATE 6` — every missing action (isolated single-skill test, edit→score, register-by-command,
determinism check) is delivered; `olympus skill test` runs one skill against a real-context fixture.

---

## GATE 7 — Could an engineer rebuild the app (with improved harness + contribution) end to end?

**Walk the dependency chain — is anything depended on before it's built?**

| Phase | Depends on | Built earlier? | OK? |
|---|---|---|---|
| R0 schemas | — | (first) | ✅ |
| R1 skill model | R0 (schema citations resolve) | yes | ✅ |
| R2 runtime | R0 (artifact validation), R1 (skills as prompts) | yes | ✅ |
| R3 contract | R0, R2 (artifacts to validate) | yes | ✅ |
| R4 harness →TARGET | R0, R1, R2 (run skills for **real-context fixtures**), R3 | yes | ✅ |
| R5 contribution →TARGET | R4 (**certification gate = harness verdict**) | yes | ✅ |
| R6 interface | R1,R2,R4,R5 (wraps them) | yes | ✅ |

**Flagged ordering risks (resolved by this order):**
- ⚠️ R4's real-context fixture model **requires R2** to serialize the envelope. If someone tries to build
  the harness before the runtime (as the *current* standalone `eval-harness/` was), they get exactly
  today's defect: an output-grader that can't see the function it grades. **R4 after R2 is mandatory.**
- ⚠️ R5's certification gate **requires R4 to actually produce a verdict.** Today R5 (such as it is) sits
  on a harness that can't score (`04-AS-IS §6`) — which is why "merged = trusted" is the de-facto gate.
  **R5 after a *working* R4 is mandatory.**
- ⚠️ R0 is the hidden critical path: the phantom-schema + draft-mismatch defects (`03 §2`) mean the
  contract isn't one contract today. **Build R0 first or every downstream validation inherits the drift.**

No phase depends on something not yet built at its point in the order. **GATE 7 passes.**
