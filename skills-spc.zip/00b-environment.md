# 00b — Environment & Clean-Machine Bring-Up 【CAPTURE】

How to stand up the Skill Forge capability (skill authoring + the `olympus` runtime that exercises
skills + the eval-harness that certifies them) from zero. Values are **redacted**; names + purpose
are given with `path:line`.

---

## 1. Prerequisites

| Tool | Version | Why |
|---|---|---|
| Python | **3.9+** (3.11 used in Docker) | `olympus/pyproject.toml:9` (`requires-python=">=3.9"`); `Dockerfile` base `python:3.11-slim` |
| pip / venv | recent | install `olympus` editable + harness deps |
| Git | any | artifact store (`gitpython`), branch-per-task workflow |
| PostgreSQL | 15 | prod DB profile (`docker-compose.yml` `postgres:15-alpine`). **Optional for dev** — SQLite works |
| Anthropic access | API key **or** AWS Bedrock creds | the agent runtime calls Claude (`agents/base.py:44-64`) |
| Docker (optional) | recent | `docker-compose.yml` for postgres + api + worker |

Skill **authoring + validation** needs only Python + `pyyaml`. Running/eval’ing a skill needs Claude access.

---

## 2. Environment variables

### 2a. Required to run any agent (the runtime that exercises a skill)

The config requires credentials unless Bedrock is on (`config.py:309-318`):

| Var | Default | Purpose | Evidence |
|---|---|---|---|
| `ANTHROPIC_API_KEY` | `""` | Direct Anthropic API key. **Required unless `OLYMPUS_USE_BEDROCK=true`** | `config.py:97,168-172,314-317` |
| `OLYMPUS_USE_BEDROCK` | `false` | Use AWS Bedrock instead of direct API; creds via boto3 chain | `config.py:98`; `base.py:54-58` |
| `OLYMPUS_AWS_REGION` | `us-east-1` | Bedrock region | `config.py:99` |
| `OLYMPUS_AWS_PROFILE` | `""` | Named AWS profile for `aws sso login` | `config.py:100`; `base.py:56-57` |

> ⚠️ **Bedrock model-id mapping.** When `OLYMPUS_USE_BEDROCK=true`, friendly model names are
> rewritten to `us.anthropic.*` inference-profile IDs via `BEDROCK_MODEL_MAP` (`base.py:35-41`).
> A model not in that map is passed through verbatim (`base.py:104-106`) — a new model name will
> silently 404 at Bedrock until added. **GOTCHA for skill authors testing new models.**

### 2b. Model selection (per phase; a skill's `agent:` hint does NOT pick the model — see §4)

| Var | Default | Evidence |
|---|---|---|
| `OLYMPUS_DISCOVERY_MODEL` | `claude-sonnet-4-6` | `config.py:101` |
| `OLYMPUS_RATIONALIZATION_MODEL` | `claude-sonnet-4-6` | `config.py:102` |
| `OLYMPUS_EXTRACTION_MODEL` | `claude-sonnet-4-6` | `config.py:103` |
| `OLYMPUS_DESIGN_MODEL` | `claude-sonnet-4-6` | `config.py:104` |
| `OLYMPUS_GENERATION_MODEL` | `claude-sonnet-4-6` | `config.py:105` |
| `OLYMPUS_REVIEW_MODEL` | `claude-sonnet-4-6` | `config.py:106` |
| `OLYMPUS_CLASSIFIER_MODEL` | `claude-haiku-4-5-20251001` | `config.py:223` |
| `OLYMPUS_COMPLIANCE_MODEL` | `claude-sonnet-4-6` | `config.py:225` |
| `OLYMPUS_SCORING_MODEL` | `claude-haiku-4-5-20251001` | `config.py:231` |
| `OLYMPUS_ADVISOR_MODEL` | `claude-opus-4-7` | `config.py:108,232` |
| `OLYMPUS_USE_ADVISOR` | `true` | enable Opus advisor (higher cost) | `config.py:107,233` |
| `OLYMPUS_USE_CODEX_ADVISOR` | `false` | cross-vendor Opus+Codex advisor | `config.py:109,234` |
| `OLYMPUS_CODEX_MODEL` / `OPENAI_API_KEY` | `codex-mini-latest` / `""` | OpenAI Codex advisor | `config.py:110-111,235-236` |

### 2c. Paths — where skills, schemas, artifacts live

| Var | Default | Purpose | Evidence |
|---|---|---|---|
| `OLYMPUS_SKILLS_PATH` | `<repo>/cross-cutting/skills` (resolved absolute) | **where the skill library is read from** — the core path for Skill Forge | `config.py:207-210,281`; `loader.py:24,27-39` |
| `OLYMPUS_ARTIFACT_DIR` | `<pkg>/.olympus/artifacts` | per-app artifact output dir | `config.py:125,203-206` |
| `OLYMPUS_WORKSPACE_PATH` | `<pkg>/workspace` | acquired source trees | `config.py:137,213-216` |
| (no env) `schemas/` | `<repo>/schemas` | runtime schema root, hard-anchored | `validators/schema_validator.py:30-31` |

> ⚠️ **Skills-path resolution has a fallback that bypasses validation.** `loader._default_skills_path()`
> first tries `get_config().skills_path`; if `OlympusConfig` raises (e.g. no creds in a unit-test
> context) it reads `OLYMPUS_SKILLS_PATH` directly, defaulting to the **relative** literal
> `"../cross-cutting/skills"` (`loader.py:21-39`). So skill loading can succeed in CWDs where the
> relative path happens to resolve, and silently return `""` (skill not found) where it doesn't.

### 2d. Database

| Var | Default | Evidence |
|---|---|---|
| `OLYMPUS_DB_PROFILE` | `postgres` (`test` → SQLite for unit tests) | `config.py:119-123,186-189,292-306` |
| `OLYMPUS_DB_URL` | derived from profile; overrides it | `config.py:124,190,299-306` |
| `OLYMPUS_POSTGRES_{HOST,PORT,DB,USER,PASSWORD}` | `localhost`/`5432`/`olympus`/`olympus`/`""` | `config.py:191-195`; assembled in `entrypoint.sh` |

For local dev, `export OLYMPUS_DB_PROFILE=test` → `sqlite:///test_olympus.db` (WAL auto-enabled per README).

### 2e. Worker / cost / rate-limit knobs (affect skill runs)

| Var | Default | Purpose | Evidence |
|---|---|---|---|
| `OLYMPUS_RALPH_MAX_ITERATIONS` | `3` | Ralph Loop global cap (apps override via column) | `config.py:116,243` |
| `OLYMPUS_COVERAGE_THRESHOLD_T1` / `_T2` | `90.0` / `80.0` | TDD coverage gates | `config.py:117-118` |
| `OLYMPUS_MAX_AGENT_ITERATIONS` | `50` | max tool-use turns per agent (`BaseAgent.max_turns`) | `config.py:244`; `base.py:92` |
| `OLYMPUS_APP_COST_CEILING_USD` | `50.0` | per-app budget circuit breaker | `config.py:132,259-262` |
| `OLYMPUS_API_CALL_DELAY` | `2.0` | sleep between API calls | `config.py:127,250` |
| `OLYMPUS_POLL_INTERVAL` | `5` | worker poll interval (s) | `config.py:126,239` |
| `OLYMPUS_GENERATION_CONCURRENCY` | `3` | parallel modules in Generation | `config.py:128,255` |
| `OLYMPUS_ENV` / `OLYMPUS_STRICT_ENV` | `dev` / `false` | staging/prod `.env` guard | `config.py:38,49,28-53` |
| `OLYMPUS_LOG_LEVEL` | `INFO` | logging | `config.py:269` |

(Email/SMTP vars `OLYMPUS_SMTP_*`, `OLYMPUS_EMAIL_*`: `config.py:147-154` — notifications, not skill-critical.)

### 2f. Eval-harness env

| Var | Default | Purpose | Evidence |
|---|---|---|---|
| `ANTHROPIC_API_KEY` | (required) | LLM judge calls Claude directly | `eval-harness/evals/non-deterministic/llm_judge.py:107-112` |

Harness LLM settings are **config-file**, not env: `llm_model: claude-sonnet-4-20250514`,
`llm_temperature: 0.0`, `llm_max_tokens: 4096` (`config.yaml:191-193`).

> ⚠️ **Harness model is pinned to a dated snapshot** (`claude-sonnet-4-20250514`) that differs from the
> runtime default (`claude-sonnet-4-6`). The judge is therefore a *different* model family than the
> maker — but pinned by literal string in two places (`config.yaml:191` and a hardcoded default in
> `llm_judge.py:101,166`). See `04-eval-harness-AS-IS.md`.

---

## 3. Local services (`docker-compose.yml`, repo root)

| Service | Image | Port | Role |
|---|---|---|---|
| `db` | `postgres:15-alpine` | 5432 | primary DB (user/db `olympus`, pwd `changeme`) |
| `api` | built from `olympus/Dockerfile` | 8000 | `uvicorn olympus.api.app:create_app --factory` |
| `worker` | built from `olympus/Dockerfile` | — | `olympus run --parallel 3` (the FSM poller) |

`olympus/Dockerfile` sets `OLYMPUS_SKILLS_PATH=/app/skills`, `OLYMPUS_ARTIFACT_DIR=/app/artifacts`,
`OLYMPUS_DB_PROFILE=postgres`; `entrypoint.sh` assembles `OLYMPUS_DB_URL` from the `POSTGRES_*` parts.
Mounts `${HOME}/.aws` read-only for Bedrock creds.

> Note: `temporal/` and `prototype/` bring their own stacks (Temporal, Keycloak, MinIO, OTEL via
> `scripts/dev-stack.sh`). **Not required for Skill Forge** — they serve the deferred Temporal target
> and the ATLAS client demo, respectively.

---

## 4. ⚠️ GOTCHA: a skill's `agent:` field does not select the model

A `SKILL.md` declares `agent: opus|sonnet` (`bootstrap_skill.sh:103`), but the runtime picks the
model from the **phase env var** (`OLYMPUS_<PHASE>_MODEL`), passed to the agent factory
(`agents/discovery.py` etc. → `BaseAgent(model=OLYMPUS_DISCOVERY_MODEL)`). The skill's `agent:` hint is
**advisory metadata only** — it is parsed into `SkillFrontmatter.agent` (`frontmatter.py:45`) and
validated as required (`validate_skills.py:26`) but **not consulted at dispatch.** A skill author who
sets `agent: opus` expecting Opus will still run on Sonnet unless the phase env var is changed. This is
a real authoring-vs-execution mismatch; captured in `01-skill-model.md` and `DRIFT-AND-GOTCHAS.md`.

---

## 5. Clean-machine bring-up runbook

```bash
# ── 0. Clone ──────────────────────────────────────────────────────────────
git clone <repo> Olympus_Claude && cd Olympus_Claude

# ── 1. Python env ─────────────────────────────────────────────────────────
python3 -m venv .venv && source .venv/bin/activate
pip install -e "olympus/[dev]"             # installs `olympus` CLI + pytest/ruff
pip install jsonschema pyyaml anthropic     # eval-harness deps (no pyproject of its own)
# optional: pip install tree-sitter tree-sitter-languages   # for tools/tree_sitter_inventory.py

# ── 2. Credentials (pick ONE) ─────────────────────────────────────────────
export ANTHROPIC_API_KEY=sk-ant-...                 # direct API
#   …or Bedrock:
export OLYMPUS_USE_BEDROCK=true OLYMPUS_AWS_PROFILE=<profile> OLYMPUS_AWS_REGION=us-east-1
#   (then: aws sso login --profile <profile>)

# ── 3. Dev database (SQLite — no server needed) ───────────────────────────
export OLYMPUS_DB_PROFILE=test               # → sqlite:///test_olympus.db

# ── 4. Verify config resolves (no LLM call) ───────────────────────────────
olympus config                               # prints models, DB, skills path, thresholds

# ── 5. SKILL FORGE: author + validate a skill (no LLM, no DB) ─────────────
scripts/bootstrap_skill.sh my-new-skill --agent sonnet --description "..."
python scripts/validate_skills.py cross-cutting/skills/my-new-skill   # exit 0 = valid
python scripts/generate_skills_lock.py        # refresh content lock (optional)
python scripts/verify_skills_lock.py          # confirm lock matches disk

# ── 6. Exercise a skill via the runtime (needs creds + DB) ────────────────
olympus init --project demo
olympus add-app <pipeline_id> demo-app        # then config-app with source path
olympus run-phase <app_id> DISCOVERY --dry-run   # preview skills loaded + est cost, NO LLM
olympus run-phase <app_id> DISCOVERY             # real run → writes artifacts

# ── 7. CERTIFY a skill's output (eval-harness) ────────────────────────────
cd eval-harness
python run-baselines.py                       # self-check golden corpus is well-formed
python run-baselines.py --results-dir results/<run>/ --app cfwheels-test-app --phase discovery
python evals/non-deterministic/llm_judge.py \
   --output-path <artifact.json> --rubric-path rubrics/discovery-rubric.yaml

# ── 8. (optional) Full stack via Docker ───────────────────────────────────
docker compose up         # db + api(:8000) + worker
```

> ⚠️ **Step 7 path bug.** `eval-harness/config.yaml:6` sets `schemas_dir: ../specifications/schemas`,
> **which does not exist** in the repo. Any harness path that resolves a schema via that key will fail
> to find it. The per-eval `schema_validator.py` is usually given an explicit `--schema-path`, so it
> works when pointed at a real file, but the config default is dead. Fix tracked in
> `03-validation-contract.md` / `DRIFT-AND-GOTCHAS.md`.

---

## 6. GATE 0 — Every runnable entry point, and where it's documented here

| # | Entry point | Invocation | In this doc |
|---|---|---|---|
| 1 | **`olympus` CLI** (29 cmds) | `olympus <cmd>` — console_script `olympus.cli:cli` (`pyproject.toml:48-49`) | §5 steps 4,6 |
| 2 | **`olympus run`** (FSM worker/poller) | `olympus run [--parallel N] [--max-ticks N] [--auto-approve]` | §3 (worker svc), `02-orchestration.md` |
| 3 | **`olympus run-phase`** (single phase — the skill-dev runner) | `olympus run-phase <app_id> <phase> [--dry-run] [--input-dir] [--resume-from-checkpoint]` | §5 step 6, `06-interface.md` |
| 4 | **`olympus replay` / `replay-historical`** | `olympus replay <run_id> --mode …` | `06-interface.md` |
| 5 | **`olympus resume` / `resume-phase` / `rerun` / `promote`** | per-app recovery / blessing | `06-interface.md` |
| 6 | **`olympus batch …`** | submit/status/results (Anthropic Batch API) | (delivery) |
| 7 | **FastAPI server** | `uvicorn olympus.api.app:create_app --factory` (`start-server.sh`; default `:8001` per `OLYMPUS_REPORT_BASE_URL`, `:8000` in Docker) | §3 |
| 8 | **MCP server** | `olympus-mcp` / `python -m olympus_mcp.server` (`mcp-server/pyproject.toml`) | `06-interface.md` |
| 9 | **`scripts/bootstrap_skill.sh`** | scaffold a `SKILL.md` | §5 step 5, `01-skill-model.md` |
| 10 | **`scripts/validate_skills.py`** | validate frontmatter+refs (also pre-commit) | §5 step 5 |
| 11 | **`scripts/generate_skills_lock.py` / `verify_skills_lock.py`** | content-lock gen/verify | §5 step 5, `01-skill-model.md` |
| 12 | **`eval-harness/run-baselines.py`** | corpus self-check / compare actual-vs-expected | §5 step 7, `04-eval-harness-AS-IS.md` |
| 13 | **`eval-harness/compare-baselines.py`** | regression diff between two baseline versions | `04-eval-harness-AS-IS.md` |
| 14 | **`eval-harness/evals/**/*.py`** | individual evals run standalone (`--output-path …`) | `04-eval-harness-AS-IS.md` |
| 15 | **`eval-harness/tools/{run-benchmark-suite,report_generator,validate-expected-files,tree_sitter_inventory}.py`** | corpus tooling (run-benchmark-suite is a **stub** — `run-benchmark-suite.py:172`) | `04-eval-harness-AS-IS.md` |
| 16 | **`olympus alembic`** (migrations) | `alembic upgrade head` (`olympus/alembic.ini`) | (DB setup) |
| 17 | **pre-commit** | `pre-commit run` → `validate_skills.py` (`.pre-commit-config.yaml`) | §5 step 5 |
| — | `temporal/olympus_workflows/worker.py`, `prototype/` stack | deferred / client-demo — **out of Skill-Forge scope** | §3 note |

All 15 in-scope runnable things (rows 1–17, excluding the out-of-scope row) appear above with how to start them. **GATE 0 passes.**
