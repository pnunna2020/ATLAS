# Skill Forge — Redesign Summary

One page. What stays, what gets redesigned, and the three target properties with the mechanism that
delivers each. This is the doc to review against the Olympus enhancement plan to keep the two apps aligned.

---

## The framing (confirmed by the code)

**Skill Forge is not a separate app — it is the skill-build-and-certify capability *inside* the Olympus
repo** (`cross-cutting/skills/` + `olympus/olympus/skills/` + `eval-harness/` + `scripts/*skill*`). The
runbook's "two apps, one shared contract" is, today, **one repo sharing the contract by construction.**
That is the strength (no drift *yet*) and the trap (nothing *enforces* the boundary, so the contract
silently drifts the moment the two split — and parts of it already have: `03 §2`). The redesign's job is
to turn "shared by accident" into "shared by enforcement."

---

## What STAYS as-is (the settled core — reproduce faithfully)

| Component | Why it stays |
|---|---|
| **Skill model** — `cross-cutting/skills/<name>/SKILL.md` convention, loader/registry/frontmatter, content-lock, `bootstrap_skill.sh`, `validate_skills.py` | Settled, well-factored, fit for purpose. Skills-as-data (filesystem scan) is what makes easy multi-user contribution physically possible. (`01`) |
| **SDK orchestration** — `BaseAgent.run()` Anthropic tool-use loop, FSM poller, Ralph Loop, ledger, phase_io contracts | Works; phase-level durability is adequate for current scale. **Not** Temporal (deferred). (`02`) |
| **Runtime artifact validation** — `validate_artifact` (filename→schema, policy tiers) | Sound design; just needs the SSOT fix beneath it. (`03 §1a`) |
| **Harness *bones*** — deterministic + golden + LLM-judge layers, corpus, baseline/regression differ | The right structure — just disconnected from the skill, real context, and a feedback loop. (`04-AS-IS §1`) |

## What gets REDESIGNED (the unsettled parts — build to TARGET)

| Component | What's wrong today | Target |
|---|---|---|
| **Schema contract** | 4+ schema locations, no SSOT; certifier uses **Draft 7 + a missing root + phantom schema paths**, runtime uses Draft 2020-12 + `schemas/` | One versioned `olympus-contracts` package, one draft, shared filename→schema resolver; CI proves every reference resolves (`03 §5`, `07 R0`) |
| **Eval harness** | Grades **static output files, not skills-as-run**; LLM judge **scale-broken (1–5 vs 0–1)** + **not wired to a runner**; judge **not independent** of maker; **zero self-improvement**; nothing baselined | Run the skill on a **real-context fixture**; gate-then-grade with an **independent Opus judge** (N-run + kappa, versioned rubric/prompt); **regression-capture loop** that ratchets the bar (`04-TARGET`) |
| **Contribution framework** | No certification gate, **no CI validation of skills**, no CODEOWNERS, no graduation — **merged = trusted** | `draft→tested→trusted` graduation; **certification gate = the harness verdict**; CI-enforced; namespacing + semver + ownership; production failures feed back to the owner (`05-TARGET`) |
| **Developer interface** | 3 disjoint surfaces; **no isolated single-skill run**, no edit→score, headless quality view | One `olympus skill {new,list,info,test,eval,register,lint,diff}` group; `skill test` runs one skill against a fixture; web view over `/insights/skills` (`06 §4`) |

---

## The three target properties and the mechanism that delivers each

| # | Property | Delivering mechanism (named, buildable) | Spec |
|---|---|---|---|
| **1** | **Easy multi-user contribution** | `olympus skill new` scaffolds everything the system requires (CI-8 fields, starter eval case, registry stanza) + `olympus skill test` gives an **isolated single-skill loop against a real-context fixture** — a contributor needs *their* skill, not the whole system. Skills stay filesystem-data so adding one is dropping a folder. | `05-TARGET §1`, `06 §4` |
| **2** | **Eval-before-trust** | A skill is `CERTIFIED` only after **deterministic gates ∧ semantic grade (independent judge) ∧ all regression cases pass**; trust status gates production loading (`draft` skills never enter phase resolution); the **CI certification check = the harness verdict**. No green eval ⇒ no trust. | `04-TARGET §5b`, `05-TARGET §2-3` |
| **3** | **Self-improvement over time** | The **regression-capture loop**: a production failure (gate-rejected / parity-fail / schema-fail) is minted into a real-context regression case with a corrected expected output, added to the skill's eval set (monotonic ratchet), and **distilled** into a SKILL.md Quality-Rule (sharpens the *maker*) or a rubric criterion (sharpens the *grader*). Distillation keeps growth sub-linear; convergence guards prevent re-queue loops. | `04-TARGET §4` |

---

## Alignment with the Olympus enhancement plan (the reconciliation point)

The runbook's closing frame: Skill Forge, matured, **is** the standalone Skills Service + eval harness
the Olympus roadmap calls for (★10–★12). The two specs describe **one shared skills-and-eval layer from
two interfaces** — Olympus (durable, gated, client-facing delivery) and Skill Forge (fast,
developer-facing build-and-certify). For that to be true and stay true:

1. **The schema/skill contract must be genuinely shared** — today it's shared-by-repo but **drifting by
   draft + path** (`03 §2`). The R0 SSOT package is the prerequisite that makes a skill built in Skill
   Forge drop into Olympus without drift. **This is the whole point of two apps; without it you have two
   systems.**
2. **The eval bar must be the same bar** — the certification verdict (`04-TARGET §5b`) is what Olympus
   should consult before loading a skill into a client run. Same harness, same `CERTIFIED` definition,
   consumed by both front doors.
3. **The skill-authoring contract is one contract** — same `SKILL.md` model, same loader, same registry.
   Already true (`01`); keep it true by enforcing the namespacing/SSOT rules (`05-TARGET §4`) so two
   contributors (or two apps) can't fork it.

**Build it once, here, well** — then Skill Forge is the certification front-end for the entire platform.

---

## The author's three follow-ups, pre-answered

1. **Pressure-test the self-improvement loop (does it compound or just grow?):** it compounds via the
   **monotonic ratchet** (a fixed regression must keep passing) + **distillation** (a failure *class*
   collapses to one rule, so the eval set grows with distinct classes, not incidents) + **sampling/retire
   with logged coverage**. The bounded cost is review throughput for minting corrected cases; the Lesson
   Distiller is what keeps that from capping total quality. (`04-TARGET §4b-c`)
2. **Reconcile the two apps' schemas/contract:** they are shared-by-repo but **already drifting** (Draft
   7 vs 2020-12; phantom + missing schema roots). The single fix is R0 (one versioned contract package,
   one draft, one resolver, CI-proven). (`03 §5`, `07 R0`)
3. **Map onto the roadmap:** Skill Forge's eval harness + Skills Service = ★10–★12, matured. The
   certification verdict is the integration seam between the two front doors. (above)
