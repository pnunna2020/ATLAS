# 02 — SDK Orchestration (the workflow, without Temporal) 【CAPTURE】

This app runs the **same logical workflow** as the Temporal-based sibling design, but via the **Anthropic
SDK + a hand-rolled FSM poller**. Captured as pseudocode preserving every branch/loop/error path, with
`path:line`. ⚠️ Where durability is lost vs Temporal is called out explicitly — that's the key
architectural difference.

> **Provenance note.** `CONTRIBUTING.md:13` claims *"Temporal is the backbone."* The running code
> contradicts this: `olympus/pyproject.toml` has **no `temporalio` dependency**, and `agents/base.py`
> is a direct Anthropic Messages loop. A `temporal/` dir exists but is the **deferred target**
> (`CLAUDE.md` pivot note; `memory/project_anthropic_pivot.md`). **Trust the code.** This doc captures
> the FSM poller — the thing that actually runs skills.

---

## 1. The orchestration pattern — precisely characterized

**It is a single-threaded, DB-polling FSM coordinator that dispatches one agent per phase.** Not a
sub-agent tree, not an in-process pipeline of function calls — a **poll → load state → dispatch handler →
run agent → commit new state** loop. Concretely, three nested levels:

```
LEVEL 1 — POLLER (fsm/worker.py)          "which app needs work?"
   run_loop()  →  tick()  →  for each actionable app: _process_app()
        │
LEVEL 2 — FSM DISPATCH (fsm/worker.py)    "what does this app's state need?"
   _process_app() looks up app.current_state in a 41-entry handler dict,
   invokes one handler (_run_discovery, _run_generation, _advance_to_gate, …),
   then commits app.current_state = fsm.state.value
        │
LEVEL 3 — AGENT LOOP (agents/base.py)     "do the actual work"
   handler builds a BaseAgent (skills-as-system-prompt + tools), calls
   agent.run(user_message) → Anthropic Messages streaming tool-use loop
```

The "coordinator" is **stateless between ticks** — all durable state lives in the DB. Each tick opens a
fresh `Session` (`worker.py:768`) and closes it in `finally` (`worker.py:782-783`).

---

## 2. LEVEL 1 — the poll loop (`fsm/worker.py:766-795`) — reproduced

```python
# tick() — worker.py:766-783
def tick() -> int:
    session = get_session(db_url)
    try:
        apps = session.query(Application).filter(
            Application.current_state.in_([s.value for s in ACTIONABLE_STATES])  # 44 actionable states
        )
        if pipeline_id: apps = apps.filter(Application.pipeline_id == pipeline_id)
        processed = 0
        for app in apps.all():
            if _process_app(session, app):   # ← LEVEL 2
                processed += 1
        return processed
    finally:
        session.close()

# run_loop() — worker.py:785-795
def run_loop(poll_interval=5, max_ticks=None):
    tick_count = 0
    while True:
        count = tick()                    # one round over ALL actionable apps
        tick_count += 1
        if max_ticks is not None and tick_count >= max_ticks: break
        time.sleep(poll_interval)         # default 5s (OLYMPUS_POLL_INTERVAL)
```

- Invoked by `olympus run [--parallel N] [--max-ticks N] [--auto-approve]`.
- ⚠️ **No leasing / no locking of apps across workers.** Two pollers querying the same DB will both pick
  up the same actionable app. Concurrency safety relies on the **artifact upsert's unique constraint**
  (`_persist_artifact_to_db` ON CONFLICT) and last-writer-wins on `current_state`, not on work claims.
  Temporal would give each workflow a single owner; here, parallelism is via `parallel_worker.py`
  (asyncio + semaphore over `max_concurrent`, default 5) within *one* process, not cross-process safety.

---

## 3. LEVEL 2 — FSM dispatch (`fsm/worker.py:797-866`) — reproduced verbatim logic

```python
def _process_app(session, app) -> bool:
    state = AppState(app.current_state)

    # (1) BUDGET CIRCUIT BREAKER — inline, before any work  (worker.py:803-806)
    if _halt_if_over_budget(session, app, state):
        app.updated_at = now(); session.commit(); return True

    fsm = FSM(state)                                   # in-memory transition validator

    handlers = {                                        # 41 entries (worker.py:810-851)
        REGISTERED|PENDING|INTAKE          : _start_discovery,
        DISCOVERY_RUNNING                  : _run_discovery,
        DISCOVERY_COMPLETE                 : _advance_to_gate,
        DISCOVERY_GATE_PENDING             : _auto_approve_gate,
        DISCOVERY_FAILED                   : _retry_stage,
        DISCOVERY_GATE_APPROVED            : _advance_after_gate,
        DISCOVERY_GATE_REJECTED            : _rework_stage,
        # … identical 6-row pattern for RATIONALIZATION, ARCHITECTURE,
        #     EXTRACTION, DESIGN, GENERATION …
        MODERNIZATION_COMPLETE             : _finalize_pipeline,
    }

    handler = handlers.get(state)
    if handler is None: return False                    # non-actionable / terminal → no-op

    try:                                                # (2) THE ONLY TRANSACTION BOUNDARY
        handler(fsm, session, app)                      #   run the phase (may call an agent)
        app.current_state = fsm.state.value             #   persist new FSM state
        app.updated_at = now()
        session.commit()                                #   ← durability point
        return True
    except Exception:
        session.rollback()                              # (3) ANY failure → roll back the whole tick
        logger.exception("Error processing app %s in state %s", app.name, state.value)
        return False
```

**Branch/error analysis:**
- The handler dict is a **flat state→function map**; every phase repeats the same 6-state sub-pattern
  (`_RUNNING → _COMPLETE → _GATE_PENDING → {_GATE_APPROVED|_GATE_REJECTED} / _FAILED`).
- **`_start_discovery` error path** (`worker.py:870-879`): if `source_path` isn't a directory, it
  transitions `DISCOVERY_RUNNING → DISCOVERY_FAILED` immediately (a deliberate fail-fast, not an
  exception).
- ⚠️ **Transaction granularity = one handler call.** A commit happens *after* the handler returns. If the
  process dies *inside* `handler()` (e.g. mid-agent), the `except` never runs, the commit never happens →
  the app stays in its **pre-handler** state (e.g. `DISCOVERY_RUNNING`) and the next poll **re-runs the
  whole handler from scratch.** Artifacts already written by the agent's tools *are* durable (they upsert
  immediately), but the FSM made no progress.

---

## 4. LEVEL 3 — the agent loop (`agents/base.py:244-321`) — reproduced

This is the actual SDK call. `BaseAgent.run()` is a turn-bounded Messages tool-use loop:

```python
def run(user_message) -> AgentResult:
    client = create_anthropic_client()        # Bedrock or direct (base.py:44-64)
    messages = [{"role":"user","content":user_message}]
    for _turn in range(self.max_turns):        # default 50 (OLYMPUS_MAX_AGENT_ITERATIONS)
        try:
            messages = self._trim_conversation(messages)     # context mgmt — see §4a
            response = self._create_message(client, messages) # STREAMING; retries (§4b)
        except (APIError, RemoteProtocolError, ReadError) as e:
            result.error = str(e); break                      # hard stop, partial result
        result.input_tokens  += response.usage.input_tokens
        result.output_tokens += response.usage.output_tokens
        has_tool_use = any(b.type=="tool_use" for b in response.content)
        if response.stop_reason=="end_turn" or not has_tool_use:
            result.output = "\n".join(b.text for b in response.content if b.type=="text")
            break                                             # NORMAL termination
        # else: dispatch each tool_use through self.tool_handler, append
        #       assistant(tool_use) + user(tool_result) messages, loop
        for block in response.content:
            if block.type=="tool_use":
                tool_output = self.tool_handler(block.name, block.input) if self.tool_handler \
                              else json.dumps({"error":"No tool handler configured"})
                tool_results.append({"type":"tool_result","tool_use_id":block.id,"content":tool_output})
        messages.append({"role":"assistant","content":assistant_content})
        messages.append({"role":"user","content":tool_results})
    else:
        result.error = f"Agent {name} hit max turns ({max_turns})"   # loop exhausted
    result.duration_seconds = time()-start
    result.cost_usd = input*price.in/1e6 + output*price.out/1e6       # MODEL_PRICING (base.py:26-32)
    return result
```

### 4a. Context trimming (`base.py:108-202`) — ⚠️ the "amnesia rewrite loop" guard

When `len(messages) > 1 + max_context_messages` (default 40, raised from 12 — `base.py:97`), the loop
keeps `[messages[0]] + [synthesized ledger summary] + tail`. The summary enumerates every dropped
`tool_use(name(input…))` + `→ result:` (each capped 200 chars, ledger capped 120 entries) so the model
**doesn't re-issue writes it already did** (`base.py:149-202`). The boundary never splits a
`tool_use`/`tool_result` pair (`base.py:130-143`). ⚠️ This is an *in-memory*, per-run mitigation — it is
**not** persisted; on crash the entire message history (and thus this reconstructed awareness) is gone.

### 4b. Streaming + retry (`base.py:204-242`)

`_create_message` uses `client.messages.stream(...).get_final_message()` to dodge the SDK's 10-minute
non-streaming timeout (`base.py:204-220`). Retries: `RateLimitError` → 30s/60s/90s backoff
(`base.py:223-232`); `httpx` connection errors → 5s/10s/15s (`base.py:233-242`); `api_max_retries=3`.
After success, sleeps `api_call_delay` (default 2s). ⚠️ Retries are **within a single `run()`** — they do
not survive a process restart.

---

## 5. How a skill gets invoked inside the loop (input assembly → SDK call → output)

```
_run_<phase>(fsm, session, app):                       # e.g. _run_discovery (worker.py:870+)
   app_context = _build_app_context(app, session)      # platform keys (primary_language, database,
                                                        #   target_*, archetype, identity_model, risk_tier,
                                                        #   disposition) + per-skill config.json scalars
   agent = create_<phase>_agent(app_context)           # agents/<phase>.py factory:
        skill_content = load_phase_skills(<phase>, app_context, char_budget=300000)   # registry → loader
        system_prompt = skill_content + load_summary + SYSTEM_PROMPT                  # SKILLS = SYSTEM PROMPT
        return BaseAgent(model=OLYMPUS_<PHASE>_MODEL, system_prompt=…,
                         tools=get_file_tools()(+code_tools for generation),
                         tool_handler=handle_file_tool, max_context_messages=30)
   result = _execute_agent(session, app, agent, "<PHASE>"):       # worker.py:1295+
        user_msg = f"Analyze application '{app.name}' (id={app.id}). Source at {app.source_path}. " \
                   f"Context docs at {app.context_path}. Metadata: {app.metadata_json}\n\n" \
                   "## Prior Phase Artifacts\n" + _gather_prior_artifacts(app, "<PHASE>")   # see §6
        emit_agent_event("agent.started")
        result = agent.run(user_msg)                    # ← LEVEL 3
        record AgentRun(cost, tokens, status)           # durable
        emit_agent_event("agent.completed" | "agent.failed")
        app.total_cost += result.cost_usd               # accrue for budget breaker
   if result.error: fsm.transition(<PHASE>_FAILED)
   else:            fsm.transition(<PHASE>_COMPLETE)
```

**The "prompt envelope" = three layers:** (1) **system prompt** = budget-loaded skill bodies + a fixed
phase `SYSTEM_PROMPT`; (2) **user message** = app identity + source/context paths + metadata + inlined
prior artifacts; (3) **tool results** appended turn by turn. The skill is *never* a tool — it's injected
as guidance into the system prompt (`agents/<phase>.py`).

---

## 6. How context/inputs/prior outputs are threaded between steps

State between phases is carried by **artifacts on disk + DB**, selected by `_STAGE_ARTIFACT_MAP`
(`worker.py:41-61`) — the equivalent of the runtime's prompt envelope:

```python
_STAGE_ARTIFACT_MAP = {                               # which prior artifacts each phase receives
  "RATIONALIZATION": [analysis-report, tech-fingerprint, integration-graph,
                      disposition-recommendation, capability-consolidation-plan, disposition-governance],
  "ARCHITECTURE":    [analysis-report, tech-fingerprint, disposition-recommendation],
  "EXTRACTION":      [analysis-report, disposition-recommendation],
  "DESIGN":          [business-rules-catalog, test-stubs, disposition-recommendation],
  "GENERATION":      [module-designs, business-rules-catalog, test-stubs],
}
```

`_gather_prior_artifacts(app, stage)` (`worker.py:1256-1293`) reads each listed file from
`artifacts/{app_id}/`, ⚠️ **truncating to ~120K chars** with JSON-preserving logic (`worker.py:87-131`)
— a very large upstream artifact is silently clipped, which can drop fields a downstream skill needs.
`phase_runner.py` keeps a *parallel copy* of `_STAGE_ARTIFACT_MAP` "in lock-step" — ⚠️ **two maps to keep
in sync**; divergence would feed different context to CLI-run vs worker-run phases.

The hand-off is **also** formalized as pydantic contracts in `contracts/phase_io.py` (`PHASE_CONTRACTS`,
`phase_io.py:397-405`) — `DiscoveryInputs/Outputs`, etc. with `extra="forbid"` (`phase_io.py:113-116`).
⚠️ But these contracts document *intent*; the docstrings repeatedly note the worker feeds something
different (e.g. `ExtractionInputs` "Worker currently passes analysis-report + disposition-recommendation,
not architecture-blueprint as the starting map suggested" — `phase_io.py:242-247`; `GenerationOutputs`
`generated_code`/`parity_report` "do NOT currently correspond to artifacts the agent writes" —
`phase_io.py:325-347`). **Contract-vs-runtime drift, self-documented in the contract file.**

---

## 7. The Ralph Loop — the one multi-step sub-orchestration (`fsm/ralph_loop.py`) — reproduced

Generation is special: `_run_generation` runs **N agents, one per module**, each in a test-first loop.

```python
# RalphLoop.should_continue (ralph_loop.py:130-137)
should_continue(module) = (state.iteration < state.max_iterations
                            and state.status not in {"PASSED","ESCALATED"})

# RalphLoop.record_iteration (ralph_loop.py:139-163) — the exit logic
record_iteration(module, tests_passed, coverage, output):
    state.iteration += 1; state.coverage = coverage
    state.test_results.append({iteration, passed, coverage, output})
    if tests_passed and coverage >= state.coverage_threshold:  state.status = "PASSED"
    elif state.iteration >= state.max_iterations:              state.status = "ESCALATED"
    else:                                                       state.status = "RUNNING"
```

**Iteration cap precedence (`resolve_ralph_max_iterations`, `ralph_loop.py:30-76`):**
1. `app.ralph_max_iterations` (per-app column) → 2. `pipeline.ralph_max_iterations` →
3. tier default `TIER_DEFAULTS = {T1:10, T2:5, T3:3}` (`ralph_loop.py:23-27`) →
4. `OLYMPUS_RALPH_MAX_ITERATIONS` env (re-read at call time) → 5. hard default **3** (`config.py:116`).

**Coverage threshold (`ralph_loop.py:111-116`):** explicit arg → else `T1`→`OLYMPUS_COVERAGE_THRESHOLD_T1`
(90.0) → else `OLYMPUS_COVERAGE_THRESHOLD_T2` (80.0).

> ⚠️ The CLAUDE.md guidance ("Ralph default 3 iterations; T1 may opt into 5-10 via per-app override")
> is *consistent* with this code, **but** `TIER_DEFAULTS` already gives T1=10/T2=5 **without** a per-app
> override — so a T1 app gets 10 iterations by tier default, not only by opting in. Minor doc nuance;
> noted in `DRIFT-AND-GOTCHAS.md`.

⚠️ **`RalphLoop` is pure in-memory state** (a dict of `RalphLoopState` dataclasses guarded by a
`threading.Lock`, `ralph_loop.py:120-128`). It is serialized to `ralph-loop-log.json` only at the **end**.
On crash mid-generation, **all iteration progress is lost** — the next poll restarts Generation from
iteration 0 for every module. This is the single largest durability gap (see §9).

---

## 8. How output becomes a validated artifact

Inside the agent loop, the `write_artifact` tool → `file_tools.handle_file_tool` →
`_persist_artifact_to_db` (dialect-aware INSERT … ON CONFLICT upsert; unique key
`(application_id, stage, artifact_type, run_version)`). The file is written to
`artifacts/{app_id}/` **and** upserted to the `Artifact` table **before the agent finishes** — which is
why artifacts survive a crash even though FSM state doesn't. Schema validation is a *separate* call
(`validators/schema_validator.validate_artifact`, captured in `03-validation-contract.md`); the worker
extracts metadata from completed artifacts into the `Application` row (e.g. Discovery →
`business_domain, complexity_tier, primary_language, archetype, identity_model`; Rationalization →
`disposition, risk_tier`) at `worker.py:439-625`.

---

## 9. ⚠️ Durability: what survives a crash vs Temporal (the key difference)

| State | Persisted? | Recovered on process crash? | vs Temporal |
|---|---|---|---|
| `Application.current_state` (FSM phase) | ✅ DB column, committed post-handler | ✅ next poll re-discovers the app | Temporal: same durability, but at *activity* granularity |
| `PhaseRunLedger` rows (run audit: input/output digest, attempt, cost, status) | ✅ append-only (`fsm/ledger.py`) | ✅ read to choose retry/resume/rerun mode | Temporal: event history is the engine's native log |
| Artifacts | ✅ DB `Artifact` + filesystem, upserted mid-run | ✅ loaded on next run | Temporal: would be activity outputs |
| **In-flight agent tool-use progress** | ❌ in-memory `messages[]` only | ❌ **agent re-runs the whole phase from scratch** | Temporal: each tool call could be a durable activity, resumed |
| **Ralph Loop iteration state** | ❌ in-memory until final log write | ❌ **restarts from iteration 0** | Temporal: per-iteration local activity, resumable |
| `PhaseCheckpoint` (intra-phase unit status) | ⚠️ **partially merged** — model guarded `PhaseCheckpoint = None` until branch A17-P0-17 lands | ⚠️ only if merged | Temporal: native |

**Bottom line vs Temporal:** Olympus has **phase-level durability** (you never lose a *completed* phase,
and the ledger lets you retry/resume/rerun/rebase — `fsm/{resume,rerun,replay,promote}.py`), but **no
sub-phase durability**. A crash mid-phase re-executes the entire phase's agent loop, re-spending tokens
and re-running every Ralph iteration. Temporal's value proposition — durable execution at activity
granularity with automatic replay — is exactly what is *not* present. This is acceptable for the current
"cheap to re-run a phase" assumption but is the first thing that breaks at scale or for long T1 generation
runs. **For Skill Forge specifically:** because a skill is exercised *through* this orchestration, a skill
developer iterating on a slow Generation skill pays the full re-run cost on any interruption, and cannot
checkpoint a single skill's progress — reinforcing the need for an isolated single-skill runner
(`06-interface.md`, `05-contribution-TARGET.md`).

---

## 10. Mapping onto the sibling's logical stages

| Logical stage (sibling) | Olympus FSM realization | Real FSM state or sub-step? |
|---|---|---|
| Discovery | `DISCOVERY_RUNNING→COMPLETE→GATE_*` | **Real state**; 1 agent → analysis-report + tech-fingerprint |
| Rationalization | `RATIONALIZATION_*` | **Real state**; 1 agent → disposition-recommendation. ⚠️ Wave-scoped variant adds cross-app pre/post passes (`fsm/wave_runner.py`) |
| Architecture | `ARCHITECTURE_*` | **Real state**; → blueprint, ADRs, well-architected, topology |
| Extraction | `EXTRACTION_*` | **Real state** (Modernization step 1) |
| Design | `DESIGN_*` | **Real state** (Modernization step 2) |
| Generation | `GENERATION_*` | **Real state** (Modernization step 3) — **hosts the Ralph Loop** (N module agents) |
| Review | none of its own | **Sub-step** of Generation (`generation._run_adversarial_review`), not a standalone FSM state |
| Validation | `VALIDATION` (simplified API-layer state) | **Sub-step** of finalization; no dedicated agent |
| Deployment | `DEPLOYMENT` (simplified API-layer state) | **Sub-step** of finalization; no dedicated agent |

`AppState` has **56 states** total (`fsm/states.py:11-93`); `ACTIONABLE_STATES` = 44; `TRANSITIONS`
encodes the per-phase 6-state pattern (`states.py:98-181`); `GATE_STATES` maps gate-pending states to gate
codes G-DC/G-RR/G-02/G-04a/b/c (`states.py:230-237`). Recovery modes (`fsm/resume.py:35-177`): **retry**
(same attempt, no version bump), **resume** (from checkpoint, attempt+1), **rerun** (fresh, input-drift
detection), **rebase** (rerun + upstream version bump).

---

## GATE 2 — Every step in a full run, with its state-handling & failure behavior

| Step (a full Discovery→Generation run) | Handler | State change | Failure behavior |
|---|---|---|---|
| App registered | `_start_discovery` | `REGISTERED → DISCOVERY_RUNNING` | bad `source_path` → `DISCOVERY_FAILED` (worker.py:870-878) |
| Run discovery agent | `_run_discovery` | `DISCOVERY_RUNNING → DISCOVERY_COMPLETE` | `result.error` → `DISCOVERY_FAILED`; crash → stays RUNNING, re-run next tick (§3) |
| Open gate | `_advance_to_gate` | `…COMPLETE → …GATE_PENDING` (+ Gate row) | exception → rollback, retry tick |
| Approve gate | `_auto_approve_gate` | `GATE_PENDING → GATE_APPROVED` (policy) or wait for human | policy denies → stays pending |
| Advance | `_advance_after_gate` | `GATE_APPROVED → RATIONALIZATION_RUNNING` | — |
| (repeat 6-state pattern for RATIONALIZATION → ARCHITECTURE → EXTRACTION → DESIGN) | per phase | per phase | `_FAILED→_RUNNING` via `_retry_stage`; `_GATE_REJECTED→_RUNNING` via `_rework_stage` |
| Run generation (Ralph) | `_run_generation` | `GENERATION_RUNNING → GENERATION_COMPLETE` | per-module ESCALATED if max iters; crash → restart from iter 0 (§7) |
| Finalize | `_finalize_pipeline` | `MODERNIZATION_COMPLETE → PIPELINE_COMPLETE` (G-04c pre-check) | exception → rollback |
| Budget exceeded (any time) | `_halt_if_over_budget` | `*_RUNNING → *_FAILED` + Escalation row | inline halt, app skipped next tick (worker.py:803-806) |

Every step above appears in this spec with its state transition and failure path. **GATE 2 passes.**
