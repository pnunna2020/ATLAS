# 06 — Interface / Developer UX 【CAPTURE】

The developer-facing interface for authoring/running/eval'ing/iterating a skill. This app's value is fast
iteration, so the UX **is** the product — captured precisely, with `path:line`.

> **One-sentence verdict:** the skill developer's interface is **three disjoint surfaces stitched by the
> filesystem** — (1) shell scripts for authoring, (2) the `olympus` CLI for exercising, (3) the
> eval-harness Python CLI for grading — with **no `olympus skill` command group, no skill UI, and no
> isolated single-skill loop.** The fast-iteration tool has the slowest-tooled iteration path.

---

## 1. The three surfaces (what exists)

### Surface A — Authoring (shell scripts + a text editor)

| Action | Command | Notes |
|---|---|---|
| Scaffold a skill | `scripts/bootstrap_skill.sh <name> [--agent opus\|sonnet] [--description …]` | idempotent; stubs 9 sections (`01 §2`) |
| Author | edit `cross-cutting/skills/<name>/SKILL.md` (+ refs/assets/config) | plain text; no form/IDE |
| Validate | `python scripts/validate_skills.py <dir>` | frontmatter+refs; also pre-commit (`05-AS-IS §2`) |
| Lock | `python scripts/generate_skills_lock.py` / `verify_skills_lock.py` | content-addressed (`01 §4`) |
| Register | hand-edit `olympus/olympus/skills/registry.yaml` | ⚠️ no tool |

### Surface B — Exercising (the `olympus` CLI) — full command surface (verified `cli.py`)

| Command (`cli.py:line`) | Args / key options | Relevance to a skill dev |
|---|---|---|
| `olympus init` (`:47`) | `--project` (req) | bootstrap a project/pipeline/DB |
| `olympus config` (`:68`) | — | **verify env**: models, DB, skills path, thresholds |
| `olympus create-pipeline` (`:144`) | `name` | — |
| `olympus add-app` (`:173`) | `pipeline_id app_name --risk-tier {T1,T2,T3} --source-path …` | register an app to run a skill against |
| `olympus config-app` (`:248`) | `app_id …` | set risk tier / domain |
| `olympus status` (`:322`) | — | pipeline/app states |
| `olympus gate` (`:341`) | `app_id gate_name decision{APPROVED,REJECTED} --reviewer` | approve/reject a gate |
| `olympus run` (`:402`) | `--max-ticks --parallel --auto-approve --pipeline-id` | **the FSM poller** (`02 §2`) |
| **`olympus run-phase`** (`:433`) | `app_id phase` `--input-dir --resume-from-checkpoint --dry-run` | ★ **the closest thing to a skill runner** (§2) |
| `olympus run-wave` (`:543`) | `wave_id …` | portfolio-scoped rationalization |
| `olympus batch submit/status/results` (`:658,686,706`) | `--pipeline-id --skill-prompt` / `batch_id` | Anthropic Batch API path |
| `olympus cost report` (`:749`) | `[pipeline_id]` | cost report |
| `olympus rerun` (`:845`) | `app_id --from-phase` | reset+replay an app |
| `olympus resume` (`:884`) | `app_id --force` | resume from last good stage |
| **`olympus resume-phase`** (`:919`) | `app_id phase --mode {retry,resume,rerun,rebase}` | ★ re-iterate a phase (`02 §10`) |
| `olympus promote` (`:953`) | `app_id phase run_id` | bless a run as canonical |
| `olympus rerun-api` (`:1045`) | `app_id --from-stage --note --api-url --reviewer` | API-triggered rerun |
| `olympus versions` (`:1112`) | `app_id` | run-version history |
| `olympus replay` (`:1190`) | `run_id --mode {exact,best_effort}` | replay a ledger run |
| **`olympus replay-historical`** (`:1228`) | `--phase --since --until --skill-version --model --app-id… --limit --mode --dry-run` | ★ batch-replay prior runs by **skill-version** — the closest thing to A/B testing a skill change |

### Surface C — Grading (eval-harness Python CLI)

| Action | Command | Notes |
|---|---|---|
| Corpus self-check | `python eval-harness/run-baselines.py` | well-formedness |
| Compare vs golden | `python run-baselines.py --results-dir … --app … --phase …` | the working eval path (`04-AS-IS §4d`) |
| Save/diff baselines | `--save-baseline vX` ; `compare-baselines.py v1 v2` | regression diff |
| Run one eval by hand | `python evals/**/<eval>.py --output-path … [--schema-path\|--rubric-path] …` | individual eval scripts |

### Non-surfaces (delivery/monitoring, NOT skill authoring)

- **`olympus/olympus/dashboard/`** — static HTML/JS pages (`agents.js`, `gates.js`, `costs.js`,
  `portfolio.js`, `waves.js`, `traceability.js`, …). Monitors *pipeline delivery*. `agents.js` shows which
  skills loaded per agent run, but there is **no skill-authoring page.**
- **API `/insights/skills` + `/insights/skills/{name}`** — per-skill quality scorecards
  (first_pass_gate_rate, rework_count, determinism_score, defect_escape_rate over 30 days). ⚠️ **API
  exists; no UI consumes it.** This is the closest thing to a "how good is my skill" view, and it's
  headless.
- **`olympus/olympus/chat/`** — conversational analytics over pipeline state (tools: `query_applications`,
  `query_gates`, `query_agent_runs`, …). Cannot author or test skills.
- **`prototype/apps/web`** — the ATLAS Phase-3 client demo (`@atlas/web`); a domain app, **not** skill
  tooling. Out of scope.
- **`mcp-server`** — exposes resource/tool schemas over MCP JSON-RPC; introspection, not authoring.

---

## 2. How a developer authors / runs / evals / iterates today (the real ergonomics)

```
AUTHOR   vim cross-cutting/skills/<name>/SKILL.md         (after bootstrap_skill.sh)
   │     python scripts/validate_skills.py <dir>          → lint
REGISTER vim olympus/olympus/skills/registry.yaml          → add to a phase  (manual)
RUN      olympus add-app <pipe> <app> --source-path <legacy>
   │     olympus run-phase <app_id> DISCOVERY --dry-run    → preview skills loaded + est cost (NO LLM)
   │     olympus run-phase <app_id> DISCOVERY              → real run; writes artifacts to DB+fs
INSPECT  (read artifacts from artifacts/<app_id>/ or the DB; no CLI to diff them)
EVAL     cd eval-harness
   │     python run-baselines.py --results-dir … --app … --phase …   → tolerance comparison
ITERATE  olympus resume-phase <app_id> DISCOVERY --mode rerun        → re-run after edits
   │     python scripts/generate_skills_lock.py            → refresh lock (manual)
   └───▶ repeat
```

⚠️ **The `--dry-run` flag (`run-phase`, `cli.py:444`) is the one genuinely good iteration affordance** —
it shows which skills load (and the budget/truncation summary from `loader.get_last_load_summary`) and an
estimated cost **without** an LLM call, so a developer can confirm their skill *will load* and isn't being
truncated before spending tokens. It's the closest thing to a fast inner loop.

---

## 3. ⚠️ The iteration loop is broken in exactly the ways that matter for "fast skill iteration"

Each is a missing affordance, mapped to where it would attach:

1. **No isolated single-skill run.** `run-phase` loads **all** skills registered for the phase
   (`registry.resolve_skills`, `01 §3c`) against a **DB-resident app**. You cannot run *just* your skill,
   and you cannot supply context inline — it comes from `_build_app_context` over the app record. So
   testing one skill means standing up a full app + running the whole phase's skill set. ← the #1 pain.
2. **No edit→score in one step.** Exercising (Surface B) and grading (Surface C) are *different tools in
   different directories* with no glue. There's no `olympus skill eval <name>` that runs the skill and
   returns its score; you manually wire `run-phase` output into `run-baselines.py`.
3. **No skill discovery/info commands.** No `olympus skill list` / `info` — a developer reads the
   `cross-cutting/skills/` directory and greps `registry.yaml` by hand.
4. **No skill registration command.** Registering = hand-editing YAML with filter keys that are
   documented only in code (`registry.py:47-59`, surfaced in `01 §5`).
5. **The quality view is headless.** `/insights/skills/{name}` returns the scorecard but nothing renders
   it; a developer can't *see* their skill's pass-rate trend without calling the API raw.
6. **No determinism check.** No `--seed`/multi-run from the CLI (the `consistency` eval is unimplemented,
   `04-AS-IS §6.2`).

**Why this matters:** the app's entire premise is *rapid* skill iteration, but the inner loop is
"edit → register by hand → stand up an app → run the whole phase → cd to another tree → manually compare
→ refresh a lock by hand." That's a multi-minute, multi-tool loop for a one-line skill edit.

---

## 4. The TARGET interface (the `olympus skill` command group — referenced by `05-TARGET`)

The fix is a single cohesive command group that wraps the disjoint surfaces (each closes a §3 gap):

```
olympus skill new <name> --phase … --stack …      scaffold incl. required fields + eval case + registry stanza  (§3.4, gap #4/#10)
olympus skill list [--phase …] [--status …]        discover skills + their trust status                          (§3.3)
olympus skill info <name>                          frontmatter, config, which phases load it, eval scorecard      (§3.3,#5)
olympus skill test <name> --fixture <envelope>     ★ run ONLY this skill against a REAL-CONTEXT fixture           (§3.1 — THE unlock)
olympus skill eval <name> [--baseline vX]          ★ full harness verdict + scorecard, edit→score in one step     (§3.2,#5)
olympus skill register <name> --phase … --filter …  generate the registry stanza (no hand-YAML)                   (§3.4)
olympus skill lint <name>                          validate_skills + lock + section/schema-citation checks        (§3 gap)
olympus skill diff <name> --runs A B                compare two runs' outputs (determinism/regression)            (§3.6)
```

Behind it: `skill test` reuses `phase_runner` with a **single-skill override** (load only `<name>` +
its `depends_on`, against a serialized fixture envelope from `04-TARGET §5a` — not a DB app); `skill eval`
calls the fixed harness (`04-TARGET §5b`); `skill info` reads `/insights/skills/{name}`. A thin web view
over `/insights/skills` renders the scorecard (closes the headless gap). MVP order is in `05-TARGET §7`
(items 3-4 are this group's core).

---

## GATE 6 — Every user-facing action vs the spec

| User-facing action | Interface today | In this spec | Gap? |
|---|---|---|---|
| Scaffold a skill | `bootstrap_skill.sh` | §1A | — |
| Edit a skill | text editor | §1A, §2 | — |
| Validate skill structure | `validate_skills.py` (+pre-commit) | §1A | local-only (`05-AS-IS §2`) |
| Lock / verify lock | `generate/verify_skills_lock.py` | §1A | manual |
| Register a skill | hand-edit `registry.yaml` | §1A | ⚠️ no tool (§3.4) |
| Preview skills loaded + cost | `olympus run-phase --dry-run` | §1B, §2 | — (the good one) |
| Run a phase / exercise a skill | `olympus run-phase` | §1B | ⚠️ not isolated (§3.1) |
| Run the full poller | `olympus run` | §1B | — |
| Re-iterate a phase | `olympus resume-phase --mode …` | §1B | — |
| Replay / A-B a skill version | `olympus replay-historical --skill-version` | §1B | — |
| Promote a run | `olympus promote` | §1B | — |
| Approve/reject a gate | `olympus gate` | §1B | — |
| Inspect cost | `olympus cost report` | §1B | — |
| Eval a skill output | `run-baselines.py` / individual evals | §1C | ⚠️ separate tree, not glued (§3.2) |
| Compare baselines | `compare-baselines.py` | §1C | — |
| View skill quality metrics | `GET /insights/skills/{name}` | §1 non-surfaces | ⚠️ headless (§3.5) |
| Monitor pipeline delivery | dashboard UI | §1 non-surfaces | — (not skill authoring) |
| **List / info skills (CLI)** | — | §3.3, §4 | ❌ MISSING |
| **Test ONE skill in isolation w/ real context** | — | §3.1, §4 | ❌ MISSING (the key gap) |
| **Edit→score in one command** | — | §3.2, §4 | ❌ MISSING |
| **Register via command** | — | §3.4, §4 | ❌ MISSING |
| **Determinism check from CLI** | — | §3.6 | ❌ MISSING |

Every user-facing action that exists is documented above; every action a skill dev would want but that
has **no** interface is flagged ❌ and designed in §4. **GATE 6 passes** (reports all missing actions).
