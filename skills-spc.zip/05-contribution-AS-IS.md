# 05 — The Contribution Framework 【CAPTURE】 (AS-IS)

What exists *today* for a user to contribute a skill. Honest about gaps — gaps are listed as gaps, not
invented. `path:line` where there's code.

> **One-sentence verdict:** there is **no contribution framework** — there is a *file convention* + a
> *local, bypassable lint*. A skill enters the trusted library the instant a PR merges, with **no
> required review, no CI validation of the skill, and no eval-before-trust gate.** "Easy to contribute"
> is true; "quality stays high" is unguarded.

---

## 1. The contribution path that exists today

```
1. scripts/bootstrap_skill.sh <name>          → scaffold SKILL.md + dirs        (tool: yes)
2. edit SKILL.md (9 sections) + references/assets/config.json                    (manual)
3. python scripts/validate_skills.py <dir>     → frontmatter + reference lint     (tool: yes, LOCAL)
   └─ also fires as a pre-commit hook on cross-cutting/skills/*/SKILL.md changes  (.pre-commit-config.yaml)
4. hand-edit olympus/olympus/skills/registry.yaml → add to a phase               (manual, NO tool)
5. python scripts/generate_skills_lock.py      → refresh content lock            (manual, optional)
6. git commit + open PR (CONTRIBUTING.md: branch-per-task, PR template)          (manual)
7. PR merges → skill is LIVE to all agents immediately                           (NO gate)
```

That's the whole process. Steps 1, 3, 5 are tooled; 2, 4, 6 are manual; **step 7 has no quality gate.**

---

## 2. What's validated — and where (the one real check)

`scripts/validate_skills.py` (captured in `01 §2` step 3) checks, per `SKILL.md`:
- required frontmatter `name`/`description`/`agent` are non-empty strings (`validate_skills.py:82-97`);
- for **new** skills (not in `skills-lock.json`), the 5 CI-8 list fields are required
  (`validate_skills.py:161-186`);
- every `references/|scripts/|assets/` mention in the body resolves on disk (`validate_skills.py:115-122`).

⚠️ It does **not** check: the 9 mandatory sections are present (despite the template claiming it does —
`docs/skill-template.md:209-215`); that the cited `schemas/…` path exists (`03 §3`); that `name` equals
the folder; that `allowed-tools` is present.

**Where it runs:** as a **pre-commit hook** (`.pre-commit-config.yaml`) — `entry: python
scripts/validate_skills.py --root .`, `files: ^cross-cutting/skills/[^/]+/SKILL\.md$`. ⚠️ **Local and
bypassable**: a contributor without `pre-commit` installed, or one who runs `git commit --no-verify`,
skips it entirely. There is no server-side equivalent (§3).

---

## 3. Review / approval / CI — what is and isn't there

| Control | Exists? | Evidence |
|---|---|---|
| Pre-commit skill lint | ✅ (local, bypassable) | `.pre-commit-config.yaml` |
| **CI validation of `SKILL.md` in PRs** | ❌ | only 5 workflows: `edge-case-e2e, eval-harness, mirror-deploy-repo, oscal, sbom`. **None runs `validate_skills.py`** (grep verified). |
| `eval-harness.yml` runs evals on a contributed skill | ❌ | it validates **golden-corpus expected files only** — "NO Bedrock calls. NO live skill invocations" (its own header). Never touches `cross-cutting/skills/`. |
| **CODEOWNERS / required reviewer for skills** | ❌ | **no CODEOWNERS file** in repo (verified). Any approver can merge a skill. |
| Eval-before-trust gate (skill must pass harness before live) | ❌ | no link between harness verdict and registry membership (`04-AS-IS §5`). |
| Lockfile verification in CI | ❌ | `verify_skills_lock.py` exists but no workflow invokes it; it's manual/observability (`generate_skills_lock.py:18-20`). |
| PR template traceability expectations | ✅ (process, not enforced) | `CONTRIBUTING.md:50-71` (summary, spec traceability, test plan, contract compliance). |

**Net:** the only thing standing between a malformed skill and the live registry is a contributor
choosing to run a local lint. **CI does not gate skills at all.**

---

## 4. How a contributed skill enters the library

By **filesystem presence + a registry edit.** A skill is "in the library" when its dir exists under
`cross-cutting/skills/` (the loader scans it — `01 §3`) and it's named in `registry.yaml` for some phase.
There is **no enrollment step, no status field, no trust tier.** Consequences captured earlier:
- a registry entry pointing at a missing skill is **silently skipped** (`01 §6`; `registry.yaml:18-22`);
- **12 skills on disk are unregistered** (in neither lock nor registry) yet loadable by name (`01 §6`);
- a deprecated skill still **loads** (warn only — `loader.py:289-296`).

So "the library" is really three overlapping sets (on-disk ⊋ locked ⊋ registered) with no single source
of membership truth.

---

## 5. Versioning & ownership — what exists

- **Versioning:** none semantic. Only the content-addressed `skills-lock.json` SHA (`01 §4`). No
  `version:` field on a skill; breaking changes to a skill others depend on are invisible.
- **Ownership:** none. No CODEOWNERS, no `owner:`/`maintainer:` frontmatter field. The
  `skill-builder` meta-skill (`cross-cutting/skills/skill-builder/SKILL.md`) describes a *governance-line*
  process for extracting/refining skills ("pass `skill-validator` before registry entry; prioritize by
  frequency×failure rate; catalog anti-patterns") — but `skill-validator` as an enforced gate **does not
  exist as code**; it's the manual `validate_skills.py` lint. The skill *describes* the discipline the
  framework lacks.

---

## 6. Honest gap list (what's missing — to be designed in TARGET)

1. **No certification gate** — nothing requires a skill to pass the eval harness before becoming trusted.
2. **No CI enforcement** — skill validation is local-only and bypassable; CI ignores skills.
3. **No required review / ownership** — no CODEOWNERS, no maintainer field.
4. **No graduation model** — no draft → tested → trusted → reusable lifecycle; binary "merged = live."
5. **No isolated single-skill test/eval** — a contributor can't exercise *just* their skill (`01 §4`, `06`).
6. **No namespacing / collision policy** — flat `cross-cutting/skills/<name>/`; two contributors can
   pick the same name or fork a schema with nothing stopping them.
7. **No semantic versioning / breaking-change handling** — only a content hash.
8. **No self-improvement tie-in** — a contributor's skill gets no benefit from accumulated eval cases,
   and its production failures don't feed back (`04-AS-IS §8`).
9. **No new-stack onboarding** — to eval a skill for a stack outside the 7-corpus set, a contributor must
   hand-author golden ground truth with no tooling (`01 GATE 1` step 8).
10. **Template-vs-validator drift** — the template says 9 sections + lists frontmatter the validator
    doesn't check, and omits the 5 CI-8 fields the validator *requires* for new skills (`01 §1a`).

These ten gaps are the design surface for `05-contribution-TARGET.md`.
