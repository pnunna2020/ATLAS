# 05 — The Contribution Framework 【CRITIQUE + TARGET】

Design the framework against the goal: **MANY users contribute skills EASILY, over time, and quality
stays high.** Every gap below traces to `05-contribution-AS-IS.md §6`. Proposed as something an engineer
could build, with the **minimum-viable version to ship first** called out explicitly.

> **Design tension to resolve:** "easy to contribute" (drop a folder, merge a PR) and "quality stays
> high" (eval-before-trust) pull against each other. The resolution is **tiered trust**: make *starting*
> trivial and *getting trusted* automatic-but-earned. A skill can enter as `draft` with one command; it
> becomes `trusted` only by passing the harness (Phase 4). Contribution and certification are the two
> halves of one pipeline — which keeps "easy to contribute" from becoming "easy to pollute."

---

## 1. The contributor journey — minimum steps from idea to certified

**Target: a contributor needs to understand their skill, not the whole system.** The journey is one
command group (`olympus skill …`, designed in `06-interface.md`) wrapping the steps that are manual today:

```
┌─ DRAFT (minutes, no system knowledge needed) ─────────────────────────────────────────────┐
│  olympus skill new <name> --phase extraction --stack cobol                                 │
│    → scaffolds SKILL.md (9 sections incl. the 5 CI-8 fields the validator needs — fixes    │
│      the template-vs-validator drift), a starter eval case, and a registry stanza PROPOSAL. │
│    → registers the skill as status:draft (not yet loaded into production phase resolution). │
└────────────────────────────────────────────────┬─────────────────────────────────────────┘
                                                  │  edit SKILL.md + references/assets
                                                  ▼
┌─ SELF-TEST (the loop that's missing today) ───────────────────────────────────────────────┐
│  olympus skill test <name> --fixture <captured-or-sample-envelope>                         │
│    → runs ONLY this skill via the runtime against a REAL-CONTEXT fixture (04-TARGET §5a),   │
│      shows the produced artifact + deterministic gate results + a dry semantic score.      │
│  olympus skill eval <name>                                                                 │
│    → runs the full harness verdict (Stage1∧2∧3) and prints the certification scorecard.    │
└────────────────────────────────────────────────┬─────────────────────────────────────────┘
                                                  │  iterate until CERTIFIED locally
                                                  ▼
┌─ SUBMIT (PR) ─────────────────────────────────────────────────────────────────────────────┐
│  git push; open PR. CI (not local lint) runs: validate_skills + lockfile verify + harness  │
│  eval on the changed skill (§2). The PR shows the certification scorecard as a check.       │
└────────────────────────────────────────────────┬─────────────────────────────────────────┘
                                                  │  green check + owner review
                                                  ▼
┌─ CERTIFY & PROMOTE ───────────────────────────────────────────────────────────────────────┐
│  merge promotes status:draft → status:tested; a scheduled reuse/▢ threshold promotes        │
│  tested → trusted (§3). Only trusted skills are loaded into production phase resolution.    │
└────────────────────────────────────────────────────────────────────────────────────────────┘
```

**Friction removed (each maps to an AS-IS gap):** the scaffold includes the required CI-8 fields (gap
#10), a starter eval case (gap #9), and the registry stanza (gap — manual YAML, `05-AS-IS §1` step 4);
`olympus skill test` is the isolated single-skill runner that doesn't exist today (gap #5); the
certification scorecard makes "is my skill good enough" answerable without reading internals.

---

## 2. The quality gate — contribution tied to certification (the core mechanism)

**A contributed skill cannot enter the *trusted* library until it passes the eval harness (Phase 4).**
This is what makes easy-to-contribute safe. Define the bar and enforce it in CI (closing AS-IS gaps #1, #2, #3):

```
CI on any PR touching cross-cutting/skills/** OR registry.yaml:
  1. validate_skills.py --root .            (now SERVER-SIDE, not bypassable)   ← gap #2
       + extend it to also check: 9 sections present, name==folder, schemas/ citation resolves (03 §5)
  2. verify_skills_lock.py                   (lock matches disk)                ← gap #2
  3. olympus skill eval <changed-skill>      (the harness verdict — Stage1∧2∧3) ← gap #1
       → posts the certification scorecard as a PR check; FAILS the check if not CERTIFIED.
  4. CODEOWNERS requires a skill-maintainer review for cross-cutting/skills/**  ← gap #3
```

**The bar (`CERTIFIED`, from `04-TARGET §5b`):** deterministic gates all pass ∧ semantic median ≥
`pass_threshold` (independent Opus grader) ∧ all regression cases pass ∧ judge kappa ≥ θ. A PR that adds
a skill failing the bar can still **merge as `draft`** (so iteration is cheap and contribution stays
easy) — but `draft` skills are **not loaded into production phase resolution**, so they can't pollute
real runs. Trust is *earned by eval*, not granted by merge. This single rule resolves the design tension.

> ⚠️ **CI cost honesty.** Step 3 makes real LLM calls (the harness runs the skill + judges it). To keep
> PR CI fast/cheap: run the **deterministic gates + regression set on every PR** (cheap, no LLM for the
> deterministic tier), and run the **full semantic eval on a labeled `eval` trigger or nightly**, posting
> the scorecard back. The MVP (§7) can start with deterministic-only gating.

---

## 3. The GRADUATION model — draft → tested → trusted → reusable

Add a **`status` field** to each skill (frontmatter `status:` + mirrored in the registry), replacing
today's binary "merged = live" (gap #4):

| Status | Meaning | What promotes it | Loaded in production? |
|---|---|---|---|
| `draft` | scaffolded / in progress | `olympus skill new` | ❌ (resolvable only via explicit `--include-draft`) |
| `tested` | passes the harness on its eval set | green CI certification scorecard + merge | ✅ for its declared stack/phase |
| `trusted` | proven across ≥N apps with no production regressions | scheduled job: reuse_count ≥ N ∧ zero open captured-regressions over window | ✅, preferred in resolution ordering |
| `deprecated` | superseded | PR sets `deprecated:true, replaced_by:` | ❌ (warn + redirect) |

**Who/what approves:** `tested` is **machine-granted** by the certification check (no human bottleneck
for quality — the harness *is* the reviewer). `trusted` is **machine-granted** by the reuse/no-regression
scheduler (closes the loop with §6). A human CODEOWNER reviews for *fit/duplication*, not quality
re-derivation. **Reuse tracking:** increment a `reuse_count` per skill from `AgentRun` rows (the runtime
already records which skills loaded — `/insights/skills` exists, `06`), so graduation is data-driven, not
manual.

---

## 4. Namespacing & collisions; schemas as single source of truth

Closes gaps #6 and the schema-fork risk (`03 §5`):

1. **Namespace skills by contributor/domain:** `cross-cutting/skills/<namespace>/<name>/` or a frontmatter
   `namespace:` field, with the loader resolving `namespace:name`. Prevents two contributors clashing on
   `extraction`. The registry references the qualified name. (MVP can keep flat names but add a CI
   uniqueness check + a reserved-core-names list so a contributor can't shadow a core skill.)
2. **Collision check in CI:** fail a PR that introduces a duplicate qualified name or a skill whose
   `description` trigger-phrases collide with an existing trusted skill (so the model's skill-selection
   layer stays unambiguous).
3. **Schemas are imported, never forked:** per `03 §5`, publish `schemas/` as one versioned package;
   contributors *reference* a schema by its package path, and CI **rejects** a PR that adds a schema file
   outside the canonical package (no more `docs/.../schemas/` forks). A contributor who needs a new
   output schema adds it *to the package* in a reviewed PR — one source of truth, enforced.

---

## 5. Versioning & ownership

Closes gaps #3, #7:
- **Semantic version per skill:** add `version: MAJOR.MINOR` frontmatter. The content-addressed
  `skills-lock.json` SHA stays as the integrity check; the semver communicates *intent* (breaking vs
  additive). CI bumps/validates: a change that alters the output schema or removes a Quality Rule
  requires a MAJOR bump.
- **Breaking-change handling:** because `depends_on` between skills is expressible (frontmatter), CI can
  warn when a MAJOR bump affects dependents; the eval harness's regression set is the safety net (a
  breaking change that regresses a dependent's captured case fails certification).
- **Ownership:** `owner:` frontmatter + CODEOWNERS entry per namespace. The owner is the required
  reviewer and the escalation point for production failures of that skill (ties to §6).

---

## 6. Self-improvement tie-in — contribution and the compounding harness reinforce each other

This is what makes the framework *compound* rather than just *admit* skills (closes gap #8; ties to
`04-TARGET §4`):

1. **A contributor's skill inherits accumulated eval cases.** When you author an `extraction` skill for a
   new stack, you start from the *base* extraction eval set **plus** every captured regression case for
   that skill family — so you're held to the bar the whole community has already raised. You don't
   re-discover known failure modes; the harness already encodes them.
2. **Your skill's production failures feed back to you.** When a `trusted` skill fails in production, the
   case minter (`04-TARGET §4a`) captures it, the `owner:` is notified, and a regression case is added.
   The skill cannot return to clean `trusted` status until it passes the new case — and the distilled
   lesson is appended to the skill's `SKILL.md` Quality Rules, so the *next contributor* to touch it
   inherits the fix.
3. **Contribution velocity raises the bar for everyone.** Each accepted skill + each captured failure
   sharpens the shared eval set; the next contribution is measured against a higher bar. Easy
   contribution *feeds* the compounding harness instead of diluting it.

---

## 7. Minimum-viable version to ship FIRST

Don't build all of the above at once. The MVP that closes the **highest-leverage** gaps with the least
work (each is a small, pointed change to existing code):

| # | MVP item | Closes | Effort |
|---|---|---|---|
| 1 | **Move `validate_skills.py` into CI** as a required check (not just pre-commit), and extend it to assert the 9 sections + `name==folder` + schema-citation resolves | gaps #2, #10, part of #1 | S — one workflow + ~30 lines |
| 2 | **Add `verify_skills_lock.py` to CI** | gap #2 | XS — one workflow step |
| 3 | **Add a `status:` frontmatter field** (`draft`/`tested`/`trusted`/`deprecated`) and make the loader resolve only non-`draft` for production unless `--include-draft` | gap #4 | S — loader/registry change |
| 4 | **`olympus skill test <name> --fixture …`** — the isolated single-skill runner against a real-context fixture | gap #5 (the #1 contributor pain) | M — new CLI + reuse phase_runner |
| 5 | **Add CODEOWNERS for `cross-cutting/skills/**`** | gap #3 | XS |
| 6 | **Fix the harness wiring defects** (`04-AS-IS §6`) so `olympus skill eval` actually produces a verdict | prerequisite for #1 full | M |

Ship 1+2+5 first (pure guardrails, hours of work, immediately stops malformed skills landing). Then 3+4
(the graduation + isolated-test loop — the contributor-experience unlock). Then 6 + the full §2
certification gate (the eval-before-trust enforcement). The §4 namespacing and §3 `trusted`-scheduler are
post-MVP once volume justifies them.

---

## GATE 5 — Could a brand-new contributor ship a certified skill without a maintainer holding their hand?

**Trace the path (TARGET):**
1. `olympus skill new payroll-rule-extractor --phase extraction --stack cobol` → scaffold incl. required
   fields + starter eval case + registry stanza (no tribal knowledge: the scaffold encodes what
   `validate_skills.py` and the loader require — the three things a contributor had to *discover* in
   `01 GATE 1` are now generated).
2. Edit `SKILL.md`; cite output schema by package path (CI rejects a bad path — no silent phantom).
3. `olympus skill test payroll-rule-extractor --fixture <sample>` → see the artifact + gate results
   locally, iterate. (No need to stand up a full pipeline or understand the FSM.)
4. `olympus skill eval payroll-rule-extractor` → certification scorecard; fix until `CERTIFIED`.
5. PR → CI runs the same checks + posts the scorecard; CODEOWNER reviews *fit*, not quality.
6. Merge → `tested`; reuse over time → `trusted` automatically.

**Where it still requires tribal knowledge — and how the TARGET removes it:**
- *New-stack ground truth* (gap #9): a COBOL skill has no golden corpus. **Removed by** the scaffold's
  starter eval case + the case-minter seeding the eval set from the contributor's own `skill test`
  fixtures (a passing local run becomes a candidate seed case, pending owner confirmation per
  `04-TARGET §4c`). The contributor authors *their* expected output once; they don't need to understand
  the whole corpus system.
- *Which phase/filter to register under* (`01 §5`): **removed by** `--phase`/`--stack` flags generating
  the registry stanza with the correct filter keys (the keys that were code-only in `registry.py:47-59`
  are now surfaced by the CLI).
- *Judge/grader mechanics*: **removed** — the contributor reads a scorecard, never the harness internals.

**Remaining honest dependency:** producing a *correct* `expected.json` for a brand-new stack is
irreducibly a human judgment (the contributor must know what right looks like for their skill) — but that
is *domain* knowledge they already have, not *system* knowledge. With the MVP's isolated test + scaffold,
a new contributor ships a certified skill end-to-end without a maintainer deriving quality for them.
**GATE 5 passes**, with the new-stack ground-truth authoring noted as the one inherent (domain, not
tribal) step.
