# Regeneration Specification 05 — `dashboard` Web Interface

> **Premise.** The current codebase will be deleted. This document is the sole surviving
> artifact for rebuilding the Olympus `dashboard` (React + USWDS + Vite SPA), behaviorally
> and visually identical, from scratch. Everything here is derived from the repo. Citations
> use the format `{repo}:{file}:{line}` where `{repo}` is `dashboard` unless otherwise noted.
>
> **Repo root for this subsystem:** `/Users/pnunna/Documents/GitHub/foundry/dashboard`
>
> **What this SPA is.** A single-page React 19 application styled with the U.S. Web Design
> System (USWDS) via `@trussworks/react-uswds`. It is the operator/reviewer surface for the
> Olympus modernization platform: portfolio overview, application detail, assembly-line
> dashboards, wave management, gate review, analytics, admin, compliance, and an embedded
> AI chat drawer. It talks to `olympus-api` (spec 01) over HTTP + WebSocket/SSE and can run
> in a fully-stubbed "demo mode" against frozen fixtures.

---

## 1. Tooling / Build

### 1.1 Package identity & scripts (`dashboard/package.json:1-20`)

- Name `olympus-dashboard`, `private: true`, version `0.1.0`, `type: "module"` (ESM).
- Scripts (exact):
  - `dev` → `vite`
  - `build` → `tsc -b && vite build` (type-check via project references THEN bundle)
  - `build:line-contracts` → `node scripts/parse-line-contracts.mjs`
  - `lint` → `eslint .`
  - `preview` → `vite preview`
  - `test` → `vitest run`
  - `test:watch` → `vitest`
  - `test:coverage` → `vitest run --coverage`
  - `test:e2e` → `playwright test`
  - `test:visual` → `playwright test --grep @visual`
  - `test:layout` → `playwright test --grep @layout`
  - `test:a11y` → `playwright test --grep @a11y`
  - `test:e2e:update` → `playwright test --update-snapshots`

### 1.2 Runtime dependencies (`dashboard/package.json:21-39`) — pin to these majors

| Package | Range | Role |
|---|---|---|
| `react`, `react-dom` | `^19.2.5` | UI runtime (StrictMode, `createRoot`) |
| `react-router-dom` | `^7.14.0` | routing (`BrowserRouter`, `Routes`, `Route`, `Navigate`, `useParams`, `NavLink`, `Outlet`) |
| `@tanstack/react-query` | `^5.99.0` | server-state cache |
| `@tanstack/react-table` | `^8.21.3` | sortable/paginated tables (`DataGrid`) |
| `@trussworks/react-uswds` | `^11.0.1` | USWDS React components |
| `@uswds/uswds` | `^3.13.0` | USWDS SCSS/CSS source |
| `axios` | `^1.15.0` | HTTP client (single instance) |
| `recharts` | `^3.8.1` | charts |
| `mermaid` | `^11.14.0` | diagram rendering in markdown |
| `@xyflow/react` | `^12.10.2` | pipeline node graph |
| `sonner` | `^2.0.7` | toasts |
| `react-markdown` | `^10.1.0` + `remark-gfm` `^4.0.1` | agent/chat markdown |
| `react-syntax-highlighter` | `^16.1.1` (+ `@types/...` `^15.5.13`) | code fences |
| `focus-trap-react` | `^12.0.0` | modal focus trapping |

### 1.3 Dev/test dependencies (`dashboard/package.json:48-71`)

`vite` `^8.0.8`, `@vitejs/plugin-react` `^6.0.1`, `typescript` `~6.0.2`, `vitest` `^4.1.4`,
`@vitest/coverage-v8` `^4.1.4`, `jsdom` `^29.0.2`, `@testing-library/react` `^16.1.0`,
`@testing-library/jest-dom` `^6.6.3`, `@testing-library/user-event` `^14.6.1`,
`@playwright/test` `^1.59.1`, `@axe-core/playwright` `^4.11.2`, `jest-axe` `^10.0.0`,
`eslint` `^10.2.0`, `@eslint/js` `^10.0.1`, `typescript-eslint` `^8.58.1`,
`eslint-plugin-react-hooks` `^7.0.1`, `eslint-plugin-react-refresh` `^0.5.2`,
`globals` `^17.5.0`, `yaml` `^2.8.4` (used by `parse-line-contracts.mjs`).

`overrides` (`package.json:40-47`): force `eslint-plugin-react-hooks` to use the root
`eslint` version, and force `@trussworks/react-uswds` to use the root `focus-trap-react`
version (dedup). Reproduce these or peer-dependency resolution drifts.

### 1.4 Vite config (`dashboard/vite.config.ts`)

- `plugins: [react(), demoFixtureSyncPlugin()]` (`:92`).
- `REPO_ROOT = path.resolve(__dirname, "..")` — parent of `dashboard` (`:11`).
- **`demoFixtureSyncPlugin`** (`:58-89`): recursively copies
  `<REPO_ROOT>/test-data/demo/atlas-challenge` → `dashboard/public/test-data/demo/atlas-challenge`
  at `configResolved` (covers dev + build) and re-copies on dev-server file changes under the
  source dir. **Fail-soft**: missing source dir is a no-op; demo mode falls through to the
  live API.
- `server.port: 3000`, `server.host: "0.0.0.0"` (`:94-95`).
- `server.allowedHosts: ["localhost", "dashboard.olympus.bah.faa", "foundry-dev-nlb-64f80a3fced28c32.elb.us-east-1.amazonaws.com"]` (`:96-100`).
- `server.proxy["/api"]` → `process.env.API_URL || "http://localhost:8000"`, `changeOrigin: true` (`:101-106`).
- `server.fs.allow: [REPO_ROOT]` (`:107-109`) — required because `AboutContinuity` imports
  `../../../../docs/phase1-continuity-matrix.md?raw` from above the dashboard root.

### 1.5 TypeScript config (`dashboard/tsconfig.json`)

`target: ES2020`, `lib: [ES2020, DOM, DOM.Iterable]`, `module: ESNext`,
`moduleResolution: "bundler"`, `jsx: "react-jsx"`, `strict: true`, `noUnusedLocals`,
`noUnusedParameters`, `noUncheckedIndexedAccess: true`, `noFallthroughCasesInSwitch`,
`useDefineForClassFields: true`, `isolatedModules`. `include: ["src", "vite-env.d.ts"]`,
`exclude: ["src/test"]`. `noEmit` (Vite emits). The `noUncheckedIndexedAccess` flag is
load-bearing — array/record index access yields `T | undefined` and the code uses non-null
assertions (`!`) in many spots; reproduce it or types will not compile as written.

### 1.6 ESLint config (`dashboard/eslint.config.js`)

Flat config. Extends `@eslint/js` recommended + `typescript-eslint` recommended +
`eslint-plugin-react-hooks` recommended + `eslint-plugin-react-refresh` (Vite HMR rule).
`ignores: ["dist"]`. Applies to `**/*.{ts,tsx}` with browser globals.

### 1.7 Entry HTML (`dashboard/index.html`)

`<title>Olympus Dashboard</title>` (`:7`), `<div id="root"></div>` (`:10`),
`<script type="module" src="/src/main.tsx">` (`:11`). Inline SVG favicon: blue rounded rect
with a white "O" glyph. `lang="en"`, charset utf-8, viewport meta.

### 1.8 Bootstrap (`dashboard/src/main.tsx`)

```
createRoot(document.getElementById("root")!).render(
  <StrictMode><App /></StrictMode>
);
```
Imports `./styles/index.css` once at module top (global stylesheet entry).

### 1.9 Containerization

- **Dev image** (`dashboard/Dockerfile`): `node:22-slim`, `WORKDIR /app`. Installs
  `ca-certificates`. Optional Zscaler corporate-proxy CA trust: `COPY ZscalerRootCertificate*.crt*`
  into a staging dir, conditionally `update-ca-certificates` and write
  `/etc/profile.d/zscaler-ca.sh` exporting `NODE_EXTRA_CA_CERTS` (no-op off-network). `npm ci`
  after copying `package.json`+`package-lock.json` for layer caching. `EXPOSE 3000`. CMD runs
  `npx vite --host 0.0.0.0 --port 3000 --force` (sources the CA env first).
- **Prod image** (`dashboard/Dockerfile.fargate`): multi-stage — `node:20` build stage runs
  the Vite build, then `nginx:1.27-alpine` serves the static bundle. Build context is the
  **repo root** (not `dashboard/`) so `docs/` is reachable for the `?raw` markdown import.
- **nginx serving** (`dashboard/nginx.conf`): `listen 3000`; `root /usr/share/nginx/html`;
  SPA fallback `try_files $uri $uri/ /index.html` (`:71-73`); `/assets/` → `expires 1y` +
  `Cache-Control public, immutable` (`:60-63`); `= /index.html` → `Cache-Control no-store`
  (`:65-67`); `= /healthz` → `200 "ok\n"` for NLB HTTP health checks (`:77-81`); gzip on for
  text/js/css/json/svg/wasm (`:34-48`); security headers `X-Content-Type-Options: nosniff`,
  `X-Frame-Options: DENY`, `Referrer-Policy: strict-origin-when-cross-origin` (`:54-56`).
  **No CSP** is set (intentional — USWDS inlines styles). Client/header/send timeouts 30s.

### 1.10 Environment variables (`dashboard/.env.example`)

| Var | Default in code | Consumed at |
|---|---|---|
| `VITE_API_BASE_URL` | `http://localhost:8000` | `src/api/client.ts` (`API_BASE_URL`), SSE base |
| `VITE_WS_BASE_URL` | `ws://localhost:8000` | `src/hooks/useWebSocket.ts` |
| `VITE_DEMO_MODE` | unset (`"true"` enables) | `src/demo-mode.ts` (`IS_DEMO_MODE`) |
| `API_URL` (build/dev only) | `http://localhost:8000` | `vite.config.ts` proxy target |
| `DASHBOARD_PORT` | `4173` | `playwright.config.ts` preview port |

All `VITE_*` vars are inlined at build time (`import.meta.env.*`). Changing them requires a
rebuild, not just a restart.

---

## 2. Routing

### 2.1 Provider nesting (`dashboard/src/App.tsx:115-122`)

Outermost → innermost:
`QueryClientProvider` → `ArtifactContextProvider` → `PortfolioProvider` →
`BreadcrumbProvider` → `BrowserRouter` → (`Toaster position="top-right" richColors closeButton` +
`DemoModeIndicator`) → `Routes`.

`QueryClient` options (`App.tsx:106-113`): `queries.staleTime = 30_000`,
`refetchOnWindowFocus: true`. `installDemoToastGuard(toast)` is called once at module load
(`App.tsx:70-72`) so every `toast(...)` call site funnels through the demo suppressor.

### 2.2 Routes OUTSIDE `<Layout>` (no app shell — rendered standalone)

| Path | Element | Notes (`App.tsx`) |
|---|---|---|
| `login` | `Login` | unauthenticated, no sidebar (`:128`) |
| `auth/callback` | `OidcCallback` | OIDC fragment handler (`:129`) |
| `demo/one-stop-shop` | `OneStopShopDemo` | standalone federal mockup, not nav-linked (`:136`) |
| `demo/cold-open` | `DemoColdOpen` | full-screen animated ribbon splash; `?close=true` variant (`:142`) |

### 2.3 Routes INSIDE `<Layout>` (`App.tsx:144-280`)

`index` → `PortfolioOverview`. Then:

| Path | Element |
|---|---|
| `portfolios/:portfolioId/applications` | `ApplicationsPage` |
| `applications/:id` | `ApplicationDetail` |
| `gates` | `GateQueue` |
| `gates/:gateId/review` | `GateReview` |
| `escalations` | `EscalationQueue` |
| `me/tasks` | `MyTasks` |
| `me/tasks/:taskId` | `MyTaskDetail` |
| `me/bundles` | `MyBundles` |
| `bundles/:bundleId` | `BundleDetail` |
| `waves` | `WaveManagement` |
| `waves/:waveId` | `WaveDetail` |
| `waves/:waveId/plan` | `WavePlanRedirect` → `/waves/:waveId#plan` |
| `portfolios/:portfolioId/waves/:waveId/redundancy-matrix` | `RedundancyMatrix` |
| `portfolios/:portfolioId/waves/:waveId/plan` | `LegacyPortfolioWavePlanRedirect` → `/waves/:waveId#plan` |
| `analytics/scoring-heat-map` | `ScoringHeatMap` |
| `assembly-lines` | `AssemblyLinesIndex` |
| `assembly-lines/:lineId` | `AssemblyLineDashboard` |
| `assembly-lines/:lineId/anatomy` | `LineAnatomyPage` |
| `skills` | `SkillCatalog` |
| `skills/:skillId` | `SkillDetail` |
| `skills/evaluation` | `SkillEvaluation` |
| `agents` | `Navigate → /analytics/model-usage` (legacy) |
| `agents/performance` | `Navigate → /analytics/model-usage` |
| `agents/skills` | `Navigate → /skills` |
| `agents/skills/:skillId` | `LegacySkillRedirect` → `/skills/:skillId` |
| `agents/evaluation` | `Navigate → /skills/evaluation` |
| `analytics/readiness` | `ReadinessScores` |
| `analytics/growth` | `CompoundGrowth` |
| `analytics/velocity` | `FactoryVelocity` |
| `analytics/cost` | `CostDashboard` |
| `analytics/model-usage` | `ModelUsage` |
| `admin/profile` | `ClientProfile` |
| `admin/profile/compare` | `ProfileComparison` |
| `admin/system` | `SystemStatus` |
| `admin/workflow-health` | `WorkflowHealth` |
| `admin/config` | `Configuration` |
| `admin/scoring` | `ScoringConfig` |
| `admin/registries` | `ExtensibilityRegistry` |
| `admin/users` | `UserManagement` |
| `admin/portfolio-members` | `PortfolioMembers` |
| `admin/delegation` | `Delegation` |
| `compliance` | `CompliancePosture` |
| `compliance/cato` | `CatoEvidence` |
| `compliance/:appId` | `ApplicationCompliance` |
| `security` | `SecurityPosture` |
| `target-architecture` | `TargetArchitecture` |
| `capability-lineage` | `CapabilityLineage` |
| `traceability` | `TraceabilityExplorerPage` |
| `about/continuity` | `AboutContinuity` |
| `*` | `NotFound` |

Three redirect helper components (`App.tsx:78-104`): `LegacySkillRedirect`,
`WavePlanRedirect`, `LegacyPortfolioWavePlanRedirect` — each reads `useParams` and returns
`<Navigate ... replace />`.

### 2.4 The shell (`dashboard/src/components/Layout/Layout.tsx`)

`Layout` renders: a skip-nav link; a USWDS `Header basic` with the Olympus logo (custom
`BrandIcon` SVG of a 3-tier node graph, `:61-81`) + `PrimaryNav` whose items come from
`NAV_SECTIONS`; a `header-right-group` containing `PortfolioPicker`, `ActiveProfileBadge`,
a live/offline connection indicator (driven by `useWebSocket().connected`), `ThemeToggle`,
and `CurrentUserMenu` (`:230-247`). Below: `.olympus-layout` flex shell with a collapsible
`.olympus-sidebar` (`SidebarNav` + a collapse-toggle button) and `<main id="main-content">`
containing a `BreadcrumbBar` + `<Outlet/>`. A global `ChatDrawer` is keyed by chat context
(`:289-297`) so switching sections starts a fresh conversation.

**Breadcrumb derivation** (`breadcrumbsForPath`, `Layout.tsx:85-168`): pure function mapping
`pathname` (+ `BreadcrumbContextSegments`) to a crumb array. Always starts with
`{ label: "Portfolio", href: "/", icon: true }`. `/applications/*` builds
`Portfolio > [Wave] > [App Name] > [Assembly Line] > [Leaf]` from injected context;
other routes map to fixed labels (Gate Queue, My Tasks, Wave Management, Assembly Lines + slug,
Skills, Analytics + slug, Admin + slug). Last crumb is `current` (no link).

**Nav config** (`dashboard/src/components/Layout/navConfig.ts`): `NAV_SECTIONS: NavSection[]`
with sections `portfolio` (matchPrefix `/`), `assembly-lines`, `skills`, `analytics`, `admin`,
`about`. Each section has `items: NavItem[]` (`label`, `path`, `icon`). `resolveActiveSection`
sorts by `matchPrefix.length` descending so specific prefixes win; root (`/`) is the default
fallback. Portfolio section items include Overview, My Tasks (`/me/tasks`), My Bundles
(`/me/bundles`), Wave Management, Gate Queue, Escalations, Target Architecture, Capability
Lineage, Traceability, Compliance Posture, cATO Evidence, Security Posture. Assembly-lines
section lists all 10 lines + Overview. Reproduce item order — the sidebar renders in array
order.

---

## 3. Pages

### 3.1 Page inventory (`dashboard/src/pages/`)

| Route | Page file | Purpose | Key API calls |
|---|---|---|---|
| `/` | `PortfolioOverview/PortfolioOverview.tsx` | portfolio dashboard: stat cards, disposition donut, pipeline progress, Needs-My-Attention, pending gates | portfolios, applications, pending gates, activity, wave progress |
| `/portfolios/:pid/applications` | `Applications/ApplicationsPage.tsx` | filterable/sortable app table (`DataGrid`) + onboarding | applications list, onboarding |
| `/applications/:id` | `ApplicationDetail/ApplicationDetail.tsx` | tabbed detail (Status, Scores, Rationale, Artifacts, Decisions, Insights, Traceability, Outcome, UserImpact, InternalDuplication) | application detail/status, artifacts, decisions; sets breadcrumb context |
| `/gates` | `GateQueue/GateQueue.tsx` | pending-gate queue with SLA/overdue indicators | pending gates |
| `/gates/:gateId/review` | `GateReview/GateReview.tsx` | gate review: evidence panels, AI recommendation, approve/reject/escalate; sets artifact + chat context | gate evidence, gate decision, capability-lineage row review, tier1 approval |
| `/escalations` | `Escalations/EscalationQueue.tsx` | escalated gate queue | escalations |
| `/me/tasks`, `/me/tasks/:taskId` | `MyTasks/` | human-paired-agent task inbox + detail (accept/return) | `/api/v1/me/tasks`, agent-task return/audit |
| `/me/bundles`, `/bundles/:bundleId` | `MyBundles/` | delegated-bundle list + detail (claim/release/submit/validate) | `bundlesApi.ts` endpoints |
| `/waves` | `Waves/WaveManagement.tsx` | wave list + create + state-aware actions | waves CRUD, rationalize/cancel/retry/reset |
| `/waves/:waveId` | `WaveDetail/WaveDetail.tsx` | wave detail: progress, embedded plan (`#plan`), gate decisions, synthesis, performance | wave progress/performance/artifacts, gate decisions |
| `/analytics/scoring-heat-map` | `ScoringHeatMap/ScoringHeatMap.tsx` | per-dimension score heat grid | analytics/scoring |
| `/assembly-lines` | `AssemblyLines/AssemblyLinesIndex.tsx` | line overview + `PipelineNodeGraph` | pipeline counts |
| `/assembly-lines/:lineId` | `AssemblyLines/AssemblyLineDashboard.tsx` | per-line kanban, gate queue, activity feed, `LineSpotlight` | per-line apps/gates/activity |
| `/assembly-lines/:lineId/anatomy` | `AssemblyLines/LineAnatomyPage.tsx` | `LineAnatomy` from `data/line-contracts/<line>.json` | static line-contract JSON |
| `/skills` | `Skills/SkillCatalog.tsx` | skill registry catalog | skills list |
| `/skills/:skillId` | `Skills/SkillDetail.tsx` | skill detail | skill detail |
| `/skills/evaluation` | `Skills/SkillEvaluation.tsx` | dispatch/eval metrics | skills eval |
| `/analytics/readiness` | `Analytics/ReadinessScores.tsx` | readiness distribution charts | analytics |
| `/analytics/growth` | `Analytics/CompoundGrowth.tsx` | compound growth chart | analytics |
| `/analytics/velocity` | `Analytics/FactoryVelocity.tsx` | velocity chart | analytics |
| `/analytics/cost` | `Analytics/CostDashboard.tsx` | cost dashboard | analytics |
| `/analytics/model-usage` | `Analytics/ModelUsage.tsx` | agent/model telemetry (`ModelUsageChart`) | model-usage |
| `/admin/profile` | `Admin/ClientProfile.tsx` | **static** FAA profile (name "Federal Aviation Administration", scoring weights) | none (static) |
| `/admin/profile/compare` | `Admin/ProfileComparison.tsx` | profile diff | profiles |
| `/admin/system` | `Admin/SystemStatus.tsx` | health + static MCP resources/tools registries | `fetchDetailedHealth` |
| `/admin/workflow-health` | `Admin/WorkflowHealth.tsx` | workflow-health panel | workflow-health |
| `/admin/config` | `Admin/Configuration.tsx` | config view | registries/config |
| `/admin/scoring` | `Admin/ScoringConfig.tsx` | scoring config | scoring config |
| `/admin/registries` | `Admin/ExtensibilityRegistry.tsx` | 6 extension-point registries | registries |
| `/admin/users` | `Admin/UserManagement.tsx` | users | auth/users |
| `/admin/portfolio-members` | `Admin/PortfolioMembers.tsx` | membership admin | `bundlesApi` member endpoints |
| `/admin/delegation` | `Admin/Delegation.tsx` | bundle dispatch/delegation | `bundlesApi` admin endpoints |
| `/compliance` | `Compliance/CompliancePosture.tsx` | portfolio compliance rollup (`ComplianceDashboard`) | compliance posture |
| `/compliance/cato` | `Compliance/CatoEvidence.tsx` | OSCAL-flavored cATO evidence rollup | cato-evidence |
| `/compliance/:appId` | `Compliance/ApplicationCompliance.tsx` | per-app SSP/POA&M viewer (fixture-backed) | fixture |
| `/security` | `Compliance/SecurityPosture.tsx` | security posture | security |
| `/target-architecture` | `TargetArchitecture/TargetArchitecture.tsx` | SF3 S1–S11 + SF1 legacy systems for active portfolio | system/capability reads |
| `/capability-lineage` | `CapabilityLineage/CapabilityLineage.tsx` | source→target capability edges (incl. M:N) | capability-lineage |
| `/traceability` | `Traceability/TraceabilityExplorerPage.tsx` | traceability explorer | traceability |
| `/about/continuity` | `AboutContinuity/AboutContinuity.tsx` | renders `docs/phase1-continuity-matrix.md?raw` as markdown | none (build-time raw import) |
| `/login` | `Auth/Login.tsx` | login form; polls `/api/v1/auth/config` | auth config + token |
| `/auth/callback` | `Auth/OidcCallback.tsx` | parses URL fragment for `access_token` | sets auth token |
| `/demo/cold-open` | `DemoColdOpen/DemoColdOpen.tsx` | full-screen splash | none |
| `/demo/one-stop-shop` | `OneStopShopDemo/OneStopShopDemo.tsx` | OSS future-state mockup | none |
| `*` | `NotFound.tsx` | 404 | none |

A `PlaceholderPage.tsx` exists as a stub scaffold for not-yet-built surfaces.

### 3.2 Detail notes for high-fidelity pages

- **PortfolioOverview** depends on the active portfolio (`usePortfolioContext`). It composes
  stat cards (`.usa-card__container` with top accent border), `charts/DispositionDonut`,
  `charts/PipelineProgress`, `NeedsMyAttention`, `MyTasksSummaryCard`, `PendingGatesQueue`,
  and an activity feed. Empty/loading states use `EmptyState`.
- **ApplicationDetail** is tab-driven via `?tab=` query param (tabs under
  `ApplicationDetail/tabs/`). On mount it calls `setBreadcrumbContext({ appName, assemblyLine, waveName })`
  so the breadcrumb reads e.g. `Portfolio > Flight Scheduler > Rationalization`; it clears on
  unmount. The Artifacts tab routes each artifact through `ViewerRegistry` (see §4).
- **GateReview** sets `ArtifactContext` (so the chat drawer can answer "about this artifact")
  and a gate-scoped chat context. It renders the `GateReview/` evidence components
  (`AIRecommendationBanner`, `EvidenceSourcePanel`, `ConsequenceBanner`,
  `ValidationWarningsBanner`, `CapabilityLineageReviewPanel`) and the `GateReviewCards/`
  approve/reject dialogs. Gate friendly names come from `data/gateMetadata.ts` (see §6).
- **AssemblyLineDashboard** renders a kanban board (`.kanban-*`), a pending-gate queue
  (`.gate-queue__*`), an activity feed (`.activity-feed__*`), and `LineSpotlight` (per-line
  bespoke viz — Discovery passes/readiness, Rationalization overlap/disposition-mix, Data
  domain cards, Modernization Ralph KPIs, Disposition execution tiles/runbook, Validation
  parity, Deployment canary/wave-ladder, Sustainment SLO rings, Governance pattern library;
  all styled in `styles/assembly-lines.css`).
- **WaveDetail** embeds the wave plan as a `#plan` anchor section (`WavePlanEmbed`) — the
  legacy standalone plan routes 301-redirect here. Emits wave telemetry via `useWaveTelemetry`.

---

## 4. Components

~60 components under `dashboard/src/components/`, mostly folder-per-component with an
`index.ts` barrel and co-located `.css` + `*.test.tsx`. Group inventory:

- **Layout**: `Layout`, `SidebarNav`, `SidebarIcon`, `CurrentUserMenu`, `navConfig`,
  `PortfolioPicker`, `ActiveProfileBadge`, `ThemeToggle`.
- **Tables / primitives**: `DataGrid` (TanStack-based; see below), `StatusBadge`, `TabNav`,
  `ScoreBar`, `EmptyState`, `ErrorBoundary`, `CreateModal`, `Glossary`.
- **Gate review**: `GateReview/*` (AI recommendation banner+modal, AskAIButton,
  EvidenceSourcePanel, ConsequenceBanner, ValidationWarningsBanner, ConfirmModal,
  DispositionConfidenceChip, CapabilityLineageReviewPanel, `recommendationConfig.ts`),
  `GateReviewCards/*` (GateReviewCard(+List), Approve/Reject dialogs, CardStatusBadge,
  ReviewerNoteEditor, SupportingArtifactsList, RationalizationCapabilityCard), `GateCardList`,
  `PendingGatesQueue`, `Tier1ApprovalPanel`.
- **Waves**: `WaveRoadmap`, `WaveSynthesis/*`, `WaveGateDecisions`, `WavePerformanceReport`,
  `WavePlanEmbed`, `WaveRecoveryBanner`, `WaveBusinessRuleOverlap`, `MoveToWaveDialog`.
- **Workflow**: `WorkflowStepper/*` (stepper + `stepRegistry.ts`/`stepData.ts`,
  StepDetailDrawer, StepTooltip, LineSteps), `WorkflowControl/*` (OperationsStrip,
  NeedsAttentionBanner, WorkflowDetailsDrawer, `confirmDialogs.ts`, `useWorkflowDetails`),
  `WorkflowFailureBanner` (+ `workflowFailureCategory.ts`), `WaveWorkflowProgress`,
  `FanOutStatusTable`, `CancelAllChildrenButton`, `PreDispatchPanel`.
- **Assembly-line viz**: `AssemblyLinePipeline`, `PipelineNodeGraph/*` (xyflow-based:
  `LineNode`, `lineLayout.ts`, `usePipelineCounts.ts`), `LineAnatomy/*`
  (`sectionSpec.ts`, `types.ts`), `PhaseRibbon`.
- **Charts**: `charts/` (`ActivityTimeline`, `DispositionDonut`, `HealthGauge`,
  `PipelineProgress`) + `ModelUsageChart`, `Insights/MaturityTrendChart`. All resolve colors
  via `useChartTheme` (recharts needs inline SVG colors, not CSS vars).
- **Markdown**: `Markdown/*` (`AgentMarkdown` = react-markdown + remark-gfm + syntax
  highlighter, `MermaidBlock`/`MermaidModal` + `mermaidSanitize.ts`, `emojiShortcodes.ts`).
- **Chat**: `Chat/ChatDrawer` (drawer shell, keyed by context) + `Chat/AgentChatPanel`
  (message list + input; auto-scroll via `scrollIntoView`).
- **Compliance / capability**: `ComplianceDashboard/*`, `CapabilityClusterSummary`,
  `CapabilitySystemCallout`, `LineageBadge`, `ConsolidatedBanner`, `ActorKindBadge`.
- **Onboarding / misc**: `ApplicationOnboardingForm/*` (+ `TargetWavePicker`),
  `OnboardingCarousel`, `ApplicationDispositionChips`, `ProfileBundleModal`,
  `RenditionsDownloadMenu`, `StaleArtifactsCard`, `SkillDispatchExplorer`,
  `MyTasksSummaryCard`, `NeedsMyAttention/*` (+ `SummaryBar`), `AgentActivityByLine`,
  `TraceabilityExplorer`, `DemoModeIndicator`.
- **Viewers**: `viewers/*` — 23 artifact viewers behind `ViewerRegistry.ts`.

### 4.1 `DataGrid` (`dashboard/src/components/DataGrid.tsx`)

Generic `<DataGrid<T>>` built on `@tanstack/react-table`: column sorting (toggle on header
click, `aria-sort` set, ▲/▼/⇅ glyphs `:137`), optional global text filter (USWDS `TextInput`),
pagination (default `pageSize=20`; `0`/`Infinity` disables). Renders
`<table class="usa-table usa-table--striped width-full">` with an `sr-only` caption, a
`.datagrid-container` wrapper, and a `.datagrid-pagination` nav (First/Prev/Page N of M/Next/Last
using `« ‹ › »`). Empty data → `.empty-state` with `emptyMessage`. Props: `data`, `columns`,
`caption`, `filterable`, `filterPlaceholder`, `emptyMessage`, `headerRight`, `pageSize`.

### 4.2 `StatusBadge` (`dashboard/src/components/StatusBadge.tsx`)

Wraps USWDS `Tag` with `className="status-badge <variant>"`. Status→class map
(`:8-31`) covers gate statuses (`pending/approved/rejected/overridden→approved/escalated`),
workflow/app statuses (`active`, `onboarded`, `discovery_in_progress→in-progress`,
`discovery_complete→complete`, `discovery_failed→failed`, `planned→pending`,
`running→in-progress`, `completed→complete`, `failed`), and wave lifecycle (`draft→pending`,
`ready→active`, `in_progress`, `cancelled→failed`). Label defaults to the status string.

### 4.3 `ViewerRegistry` (`dashboard/src/components/viewers/ViewerRegistry.ts`)

`registry: Record<string, ComponentType<ViewerProps>>` mapping `artifact_type` → viewer.
`getViewerForType(type)` and `<ArtifactViewer artifactType=...>` both fall back to
`GenericStructuredViewer` for unknown types. **Critical routing rule** (`:43-51`): every
`*_step` artifact (`rationalization_step`, `architecture_step`, `data_step`,
`modernization_step`, `validation_step`, `deployment_step`, `disposition_execution_step`,
`sustainment_step`, `governance_step`) routes to `DiscoveryPassViewer` so its `analysis`
field renders as markdown (headings/tables/mermaid) — NOT as raw key-value text. Other keys:
`discovery_analysis`, `discovery_pass`, `file_artifact`, `business_rules`, `test_scenarios`,
`module_map`, `api_specification`, `data_model`, `compliance_map`, `test_results`,
`security_scan`, `accessibility_audit`, `quality_risk`, `gate_summary`, `gate_finding`,
`wave_plan`, `architecture_traceability`, `integration_graph`, `portfolio_manifest`,
`compliance_citations`, `ux_overlap_matrix`, `business_rule_redundancy`.

---

## 5. API Layer

### 5.1 Axios client (`dashboard/src/api/client.ts`, 3343 lines)

- `API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000"`.
- Single `apiClient = axios.create({ baseURL, headers: { "Content-Type": "application/json" }, timeout: 30000 })`.
- **Auth token storage**: `AUTH_TOKEN_KEY = "olympus:auth:token"` in `localStorage`.
  Exports `setAuthToken`, `clearAuthToken`, `getAuthToken`.
- **Request interceptor**: if a token exists, adds `Authorization: Bearer <token>`.
- **Response interceptor — error normalization** (4-tier, in order): (1) Olympus structured
  error envelope `{ error: { message, code } }`; (2) FastAPI `{ detail: string }`; (3)
  Pydantic validation arrays `{ detail: [{ loc, msg }] }` flattened to a readable string; (4)
  fall back to axios message. The normalized `Error.message` is what UI surfaces (toasts) show.
- Dozens of typed helper functions grouped by domain: **applications** (list/detail/status/
  update), **gates** (pending, wave gates, evidence, decision/approve/reject, force-advance,
  resolve-escalation), **onboarding**, **discovery** (start), **workflow** + **workflow-health**,
  **agent-runs/roles**, **model-usage**, **waves** (CRUD + rationalize/cancel/retry/reset/
  resume/ready/assign/remove/progress/performance/artifacts), **analytics**, **traceability**,
  **renditions**, **skills**, **health** (`fetchDetailedHealth`), **governance**, **registries**,
  **chat** (unified + gate-specific + history), **activity**, **auth/users**,
  **wave-synthesis**, **disposition-output**, **structural-analysis**, **profiles**, **dispatch**
  (v1 + v2 architecture fan-out), **capability-lineage row review**, **system/capability reads**,
  **my-tasks/agent-tasks**, **cato-evidence**, **tier1 approval**.
- Exports `ChatContextType` union consumed by `useChatContext`.
- `fetchWaveArtifact` contains a demo-mode intercept (returns a fixture instead of hitting the API).

### 5.2 Bundles client (`dashboard/src/api/bundlesApi.ts`)

Separate module wrapping the Phase-5-W20 delegated-bundle + portfolio-membership endpoints.
Reuses `apiClient`. Exports string-union types (`BundleScopeKind`, `BundleStatus`,
`BundleFallbackPolicy`, `BundleSessionArtifactKind`, `RBACRoleValue`) and wire types
(`BundleSummary`, `BundleDetail`, `BundleValidationResult`, `BundleAuditNarrative`,
`PortfolioMembership`, etc.). Pair-facing functions: `listBundles(filters)` →
`GET /api/v1/me/bundles`; `getBundle(id)` → `GET /api/v1/bundles/{id}`; `claimBundle`,
`releaseBundle`, `validateBundle`, `submitBundle`, `getBundleAudit`. Admin functions:
`listPortfolioMembers`, `addPortfolioMember`, `removePortfolioMember`, `createBundle`
(`POST /api/v1/admin/portfolios/{pid}/bundles`), `forceReleaseBundle`. All path segments use
`encodeURIComponent`.

### 5.3 Types (`dashboard/src/types/api.ts`, ~1926 lines)

The hand-maintained mirror of the API's wire shapes: `AssemblyLineName`, `GateType`,
`GateStatus`, disposition/risk-tier unions, application/wave/gate/skill/portfolio interfaces,
analytics + traceability shapes, etc. These are the canonical TS types every page/component
imports. `gateMetadata.ts` and `DataGrid`/`StatusBadge` import `AssemblyLineName`/`GateType`/
`GateStatus` from here.

### 5.4 Build-time line contracts

`scripts/parse-line-contracts.mjs` (run via `npm run build:line-contracts`) reads the
authoritative YAML at `olympus-contracts/olympus_contracts/data/assembly-lines/*.yaml` and
emits `dashboard/src/data/line-contracts/<line>.json` + `index.json` (consumed by the
`LineAnatomy` UI). It validates step-sequence canonicalization (1-based, unique-unless-parallel
via `parallel_with` clusters, no gaps) and **fails the build** on violations. The 10 line
display names are pinned in `LINE_DISPLAY_NAME` (`:44-55`). Run with `--validate-only` to check
without emitting. The committed JSON (`src/data/line-contracts/*.json`) is the regenerated
output — it can be reproduced from the YAML at any time.

### 5.5 Gate metadata (`dashboard/src/data/gateMetadata.ts`)

`GATE_METADATA: Record<GateType, { name, assemblyLine }>` — the 15 standard gates with
friendly names: `G-DC` Discovery Complete (Discovery), `G-RR` Portfolio Rationalization
Approval (Rationalization), `G-DA` Disposition Plan Approval, `G-02` Architecture Alignment
Review (Architecture), `G-DT` Data Architecture Review (Data), `G-04a/b/c` Extracted
Specifications / Modernization Design / Generated Code Review (Modernization), `G-DE-1/2`
Disposition Execution Plan Approval / Decommission Readiness Sign-off, `G-V1/2/3` Functional
Parity / Compliance & Security / Safety Assurance (Validation), `G-DP-1/2` Production
Deployment Approval / Legacy Decommission Authorization (Deployment). Helpers: `getGateName`
(falls back to code), `getGateAssemblyLine`, `formatGateLabel` (`"Name (CODE)"`). **Sync
contract**: this list must mirror `olympus-contracts/.../enums.py GATE_FRIENDLY_NAMES`,
`dashboard/src/config/glossary.ts`, and `cross-cutting/gates/README.md` (`:12-16`).

---

## 6. State + Demo Mode

### 6.1 React contexts (providers)

| Provider | File | State | Storage key |
|---|---|---|---|
| `PortfolioProvider` | `hooks/usePortfolioContext.tsx` | active portfolio (fetches list, persists active id, picks first if stored id absent) | `olympus-active-portfolio` |
| `ArtifactContextProvider` | `hooks/useArtifactContext.tsx` | `artifactContext: string\|null` for chat + `openChatSignal` counter + `requestOpenChat()` | — |
| `BreadcrumbProvider` | `hooks/useBreadcrumbContext.tsx` | `segments: { appName, assemblyLine, leaf, waveName }`, `setBreadcrumbContext`, `clearBreadcrumbContext` | — |

### 6.2 Hooks

- **`useTheme`** (`hooks/useTheme.ts`): sets `data-theme` on `document.documentElement`
  pre-hydration; persists to `localStorage` key `olympus-theme`; `toggle()` flips light/dark.
- **`useChartTheme`** (`hooks/useChartTheme.ts`): returns a `ChartTheme` palette (recharts uses
  inline SVG colors). LIGHT: primary `#177480`, accent `#23D2D7`, series
  `["#177480","#23D2D7","#00A5B5","#5B9BD5","#8B5CF6","#F59E0B","#EF4444"]`, grid `#E8E8E8`,
  text `#464646`, success `#00A91C`, warning `#FFBE2E`, error `#D54309`, muted `#A9AEB1`.
  DARK rotates the palette and uses grid `#3A3334`, text `#C4C0C1`, tooltip bg `#2A2526`.
- **`useWebSocket`** (`hooks/useWebSocket.ts`): `WS_BASE = VITE_WS_BASE_URL ?? "ws://localhost:8000"`,
  `SSE_BASE = VITE_API_BASE_URL`. Connects `/api/v1/events/ws`; after 5 retries falls back to
  SSE at `/api/v1/events`; exponential backoff capped at 30s. Exposes `{ connected, ... }`.
- **`useQueries`** (`hooks/useQueries.ts`): central `queryKeys` object + React Query hooks
  (`usePortfolios`, `useApplications`, `useApplicationDetail`, `useApplicationStatus`,
  `usePendingGates`, `useWaveGates`, `useGateEvidence`, `useWaveProgress` — polls every 5s while
  `RUNNING`, swallows `409 WAVE_WORKFLOW_NOT_STARTED`). Mutations: `useSubmitGateDecision`
  (demo short-circuit via `buildDemoGateDecisionResponse`), `useStartDiscovery`,
  `useUpdateApplication`, `useCancelWaveRationalization`, `useRetryWaveRationalization`,
  `useResetWave`.
- **`usePollingBackoff`** (`hooks/usePollingBackoff.ts`): generic adaptive poller. Starts at
  `minMs` (3000), steps to `midMs` (5000) then `maxMs` (10000) after `unchangedThreshold` (3)
  unchanged polls (compared by stable JSON); any change resets. Uses `setTimeout` chaining (not
  `setInterval`). Calls `shouldPollTick()` (demo guard) — skips when demo mode is on and the
  document is hidden.
- **`useChatContext`** (`hooks/useChatContext.ts`): derives `{ contextType, contextId, section,
  suggestedQuestions }` from the current route. Gate-review → `gate`/gateId; application →
  `application`/appId; everything else → `portfolio`/activePortfolioId (or `"default"`) with a
  `section` discriminator (`assembly-line:<id>`, `skills`, `analytics`, `admin`, `wave:<id>`,
  `waves`, `applications`, `gate-queue`, `overview`). Each branch ships 3 canned
  `suggestedQuestions`. The wave-detail regex MUST match before the bare `/waves` check.
- **`useWaveTelemetry`** (`hooks/useWaveTelemetry.ts`): `emitWaveEvent(name, payload)` dispatches
  `wave.action.clicked` / `wave.app.moved` / `wave.state.transitioned` as `CustomEvent` on
  `window` (decoupled from any analytics backend); logs to `console.debug` in DEV; never throws.

### 6.3 Auth

JWT stored in `localStorage` key `olympus:auth:token` (`api/client.ts`). `Login` polls
`/api/v1/auth/config` to discover available identity methods (local password / OIDC).
`OidcCallback` parses the URL fragment for `access_token` and calls `setAuthToken`. Both auth
pages render outside `<Layout>` (no app shell for unauthenticated users).

### 6.4 Demo mode (`dashboard/src/demo-mode.ts` + `demo-mode.README.md`)

Enabled by `VITE_DEMO_MODE === "true"` → `IS_DEMO_MODE`. Constants/behaviors:
- `FIXED_DEMO_CLOCK_ISO = "2026-05-08T14:22:00Z"` — `useDemoClock()` returns this frozen time
  so relative timestamps don't drift during a recording.
- `DEMO_FIXTURE_PATH = "/test-data/demo/atlas-challenge"`; `getDemoFixture(name)` fetches a
  fixture JSON (synced into `public/` by the Vite plugin); falls through to live API if absent.
- `shouldPollTick()` — false when demo mode on AND `document.hidden`; otherwise true.
- `shouldShortCircuitGateDecision()` — gate decisions resolve synthetically (no API write).
- **Toast guard**: `installDemoToastGuard(toast)` (called at `App.tsx` load) wraps
  `toast.success/error/info/warning/message` to suppress them in demo mode unless the call opts
  in via the `DEMO_PASSTHROUGH_KEY = "__demo_passthrough__"` marker (`toastForDemo` escape
  hatch). `__resetDemoToastGuardForTesting` resets it for unit tests.
- `DemoModeIndicator` renders a fixed pill when demo mode is on.
- Hard rule (from README): demo mode must be a thin runtime layer — never fork page/component
  logic; all suppression goes through these helpers.

---

## 7. Visual / Branding System

Global stylesheet entry `dashboard/src/styles/index.css` `@import`s, in order: `base.css`,
`layout.css`, `components.css`, `gate-review.css`, `GateReviewCards.css`, `app-detail.css`,
`chat.css`, `assembly-lines.css`. Plus USWDS CSS from `@uswds/uswds`. Theme is driven entirely
by CSS custom properties with a `[data-theme="dark"]` override on `<html>`.

### 7.1 Design tokens — light (`dashboard/src/styles/base.css` `:root`)

| Token | Value | Meaning |
|---|---|---|
| `--olympus-primary` | `#211D1E` | near-black brand ink (header bg, text) |
| `--olympus-teal` | `#177480` | primary brand accent |
| `--olympus-cyan` | `#23D2D7` | bright cyan accent |
| `--olympus-accent` | `#00A5B5` | interactive accent / links |
| `--olympus-bg` | `#F2F7F7` | app background |
| `--olympus-bg-card` | `#ffffff` | card/surface background |
| `--olympus-text` | `#211D1E` | body text |
| `--olympus-text-light` | `#464646` | secondary text |
| `--olympus-text-inverse` | `#ffffff` | text on dark surfaces |
| `--olympus-border` | `#E8E8E8` | hairline borders |
| `--olympus-radius` | `8px` | standard corner radius |
| `--olympus-sidebar-width` | `240px` | sidebar + navbar width |
| `--olympus-topnav-height` | `56px` | header height |
| `--olympus-shadow` | (soft drop shadow) | card elevation |

Dark theme overrides (same token names, darker surfaces: card `#1E1A1B`/`#2A2526`, border
`#352F30`, text `#C4C0C1`/`#E8E8E8`, primary accent shifts to cyan). Typography: **Inter**
(imported in `base.css`), `h1 = 1.75rem`, `h2 = 1.25rem` with an accent underline.

### 7.2 Layout chrome (`dashboard/src/styles/layout.css`)

Header uses `--olympus-primary` background; `.usa-navbar` width = sidebar width; sidebar is
240px, white, fixed-left, collapsible to 56px (`.olympus-sidebar--collapsed`); breadcrumbs,
`.theme-toggle`, `.connection-indicator` + `.connection-dot--connected/--disconnected`.
Responsive: sidebar hides below 1024px. Skip-nav link `.usa-skipnav`.

### 7.3 Components & semantics (`dashboard/src/styles/components.css`)

`.cursor-link`; stat cards (`.usa-card__container` with a colored top accent border);
**status-badge variants** (`--pending/--approved/--rejected/--active/--onboarded/--in-progress/
--complete/--failed/--escalated`, each a bg+fg color pair, with dark variants);
**line-tag per-line colors** (discovery=teal, rationalization=indigo, architecture=blue,
data=cyan, modernization=violet, disposition-execution=amber, validation=emerald,
deployment=slate, sustainment=rose, governance=gold + dark variants); USWDS tables
(`thead` bg `#1b3a5c`); `.datagrid-pagination`; score bars; `.tab-nav`; `.chart-card` +
`.widget-grid` (2/3/4-col + metrics, responsive breakpoints 1200/768/480px).

### 7.4 Specialized stylesheets

- **`assembly-lines.css`**: kanban board/columns/cards, gate-queue rows (`--overdue` red left
  border), risk pills (`--tier1` red, `--tier2` amber, `--tier3` blue), activity feed, spotlight
  grids (`--1-1`, `--2-1`, collapse <900px), and all per-line spotlight widgets (readiness
  buckets, disposition mix, domain cards, Ralph KPIs, execution tiles, runbook, parity bars,
  canary banner, wave ladder, SLO pills, pattern library). Dark touch-ups bucket many surfaces
  to `#1E1A1B`.
- **`app-detail.css`**: app-detail header, metrics strip, repo cards, edit form grid (2-col),
  discovery banner (`--onboarded` teal-tinted, `--error` red, `--stalled` amber).
- **`chat.css`**: chat FAB, 32em×42em fixed bottom-right drawer, message bubbles
  (`--reviewer` teal left-border, `--agent` neutral), markdown styling inside `.chat-message__body`,
  textarea input with teal focus ring; dark variants.
- **`gate-review.css`** (1229 lines): the gate-review evidence/decision UI styling.

---

## 8. Testing

### 8.1 Unit/component (Vitest)

- Config `dashboard/vitest.config.ts`: `environment: jsdom`, `globals: true`,
  `setupFiles: ["./src/test/setup.ts"]`, `testTimeout: 15000`. Excludes `node_modules`, `dist`,
  `tests-e2e`, `playwright.config`, worktrees.
- **Coverage** (`provider: v8`): include `src/**/*.{ts,tsx}`; exclude `src/test`, `main.tsx`,
  `vite-env.d.ts`, `*.test.*`, `src/data`. **Thresholds (floors): lines 81, branches 70,
  functions 76, statements 78.** A drop below any floor fails `npm run test:coverage`.
- **Setup** (`dashboard/src/test/setup.ts`): imports `@testing-library/jest-dom/vitest`; appends
  a `<style>` to stub USWDS CSS; defines global mocks: `MockWebSocket` (auto-OPEN next tick),
  `MockEventSource` (auto-OPEN next tick), `ResizeObserver` (no-op), and a `scrollIntoView`
  polyfill (jsdom lacks it; AgentChatPanel auto-scroll would otherwise throw).
- Co-located `*.test.tsx` files live next to components/pages (e.g. `GateReviewCards/__tests__/`,
  `WaveRoadmap/__tests__/` with `__snapshots__`, `PreDispatchPanel.a11y.test.tsx`,
  `RationaleTab.test.tsx`).

### 8.2 End-to-end (Playwright)

- Config `dashboard/playwright.config.ts`: `testDir: "./tests-e2e"`, `fullyParallel: false`,
  `workers: 1`, `timeout: 30000`, `retries: 1 in CI`. Single project **`chromium-desktop`**,
  viewport **1440×900**. `webServer` runs `npx vite preview --port 4173 --strictPort`
  (`DASHBOARD_PORT` overridable), `reuseExistingServer` off CI. Screenshot expectations:
  `maxDiffPixelRatio: 0.01`, `threshold: 0.2`, `animations: "disabled"`, `caret: "hide"`.
- API is stubbed deterministically by `tests-e2e/fixtures/api-stubs.ts` (`installApiStubs`,
  `STUB_IDS`, frozen `Date.now` to `STABLE_DATE`). Playwright matches routes LIFO — register
  broad catch-alls first, specific routes last.
- **Three suites** (`tests-e2e/README.md`):
  - `@visual` (`visual.spec.ts`): full-page pixel-diff of 10 demo-critical pages
    (portfolio-overview, applications-list, app-detail overview/artifacts/decisions, gate-queue,
    gate-review, line-discovery, line-modernization, waves) vs committed baselines under
    `tests-e2e/visual.spec.ts-snapshots/`. Update ONLY via `npm run test:e2e:update`.
    Non-blocking in CI until linux baselines exist (current baselines are darwin).
  - `@layout` (`layout.spec.ts`): for 8 pages — `<main>` width > 0, no horizontal overflow
    (docWidth ≤ viewportWidth + 1px), text/search inputs not clipped (w/h > 0). **Blocks merge.**
  - `@a11y` (`a11y.spec.ts`): axe-core on 5 pages with tags
    `wcag2a/wcag2aa/wcag21a/wcag21aa/section508`, `<svg>` excluded; `color-contrast` is
    baselined (USWDS palette), any net-new rule fails. **Blocks merge.**
  - Additional specs: `stepper-regression.spec.ts`, `line-anatomy.spec.ts` (guard the workflow
    stepper + line-anatomy registry against drift).

---

## Atomic Rebuild Checklist

Each step is independently buildable/testable with an explicit acceptance check. Build in order.

1. **Scaffold the package.** Create `dashboard/` with `package.json` exactly as §1.1–1.3
   (name, scripts, deps at the pinned majors, `overrides`, `type: module`). Add `tsconfig.json`
   (§1.5), `eslint.config.js` (§1.6), `vite.config.ts` (§1.4), `index.html` (§1.7),
   `src/main.tsx` (§1.8), `.env.example` (§1.10).
   **Accept:** `npm install` resolves; `npm run lint` runs (no config errors).

2. **Establish the token/style system.** Create `src/styles/{index.css,base.css,layout.css,
   components.css,gate-review.css,app-detail.css,chat.css,assembly-lines.css}` with the exact
   tokens (§7.1), dark overrides, and the `@import` order in `index.css`. Add USWDS via
   `@uswds/uswds`.
   **Accept:** importing `index.css` in `main.tsx` builds; `getComputedStyle(:root)` resolves
   `--olympus-primary` to `#211D1E` and `--olympus-teal` to `#177480`.

3. **API layer + types.** Recreate `src/types/api.ts` (the wire-type unions/interfaces),
   `src/api/client.ts` (base URL from `VITE_API_BASE_URL`, single axios instance, token key
   `olympus:auth:token`, request/response interceptors with the 4-tier error normalization, all
   typed helpers), and `src/api/bundlesApi.ts` (§5.2).
   **Accept:** `tsc -b` compiles `src/api` + `src/types` with no errors; a unit test asserts the
   response interceptor turns a Pydantic `{detail:[{loc,msg}]}` payload into a readable message.

4. **State providers + hooks.** Implement `usePortfolioContext`, `useArtifactContext`,
   `useBreadcrumbContext`, `useTheme` (key `olympus-theme`), `useChartTheme`, `useWebSocket`
   (WS→SSE fallback), `usePollingBackoff`, `useQueries`, `useChatContext`, `useWaveTelemetry`
   per §6.
   **Accept:** unit tests pass — `useTheme.toggle()` sets `data-theme="dark"` on `<html>` and
   persists `olympus-theme`; `usePollingBackoff` steps 3000→5000→10000ms after 3 unchanged polls.

5. **Demo mode.** Implement `src/demo-mode.ts` (frozen clock `2026-05-08T14:22:00Z`, fixture
   path, poll guard, gate short-circuit, toast guard + passthrough) and `DemoModeIndicator`.
   Wire `installDemoToastGuard(toast)` at `App.tsx` module load.
   **Accept:** with `VITE_DEMO_MODE=true`, `isDemoMode()===true`, `useDemoClock()` returns the
   frozen ISO, and a guarded `toast.success` is suppressed unless `toastForDemo` is used
   (`__resetDemoToastGuardForTesting` between tests).

6. **Layout shell + nav.** Build `Layout.tsx` (USWDS Header + PrimaryNav from `NAV_SECTIONS`,
   `BrandIcon`, header-right group, collapsible sidebar, breadcrumb bar, `<Outlet/>`, keyed
   `ChatDrawer`), `navConfig.ts` (`NAV_SECTIONS` + `resolveActiveSection`), `SidebarNav`,
   `SidebarIcon`, `CurrentUserMenu`, `PortfolioPicker`, `ActiveProfileBadge`, `ThemeToggle`.
   **Accept:** rendering `<Layout>` shows the Olympus header, sidebar with the portfolio-section
   items in order, and `breadcrumbsForPath("/gates")` returns `[Portfolio, Gate Queue]`.

7. **Router.** Recreate `src/App.tsx` with the full provider nesting (§2.1) and every route
   (§2.2–2.3) including the three redirect helpers and legacy `agents/*` redirects.
   **Accept:** `npm run dev` boots on :3000; navigating to `/`, `/gates`, `/waves`,
   `/assembly-lines/discovery`, `/admin/system`, and an unknown path renders PortfolioOverview,
   GateQueue, WaveManagement, AssemblyLineDashboard, SystemStatus, and NotFound respectively;
   `/waves/abc/plan` redirects to `/waves/abc#plan`.

8. **Shared primitives.** Build `DataGrid` (§4.1), `StatusBadge` (§4.2), `TabNav`, `ScoreBar`,
   `EmptyState`, `ErrorBoundary`, `CreateModal`, `Glossary`, `charts/*` (using `useChartTheme`),
   `Markdown/*`, `viewers/*` + `ViewerRegistry.ts` (§4.3).
   **Accept:** a `DataGrid` test asserts header-click toggles `aria-sort` and pagination shows
   "1–20 of N"; `getViewerForType("modernization_step")` returns the same component as
   `discovery_pass`, and an unknown type returns `GenericStructuredViewer`.

9. **Line contracts + gate metadata.** Add `scripts/parse-line-contracts.mjs`,
   `src/data/line-contracts/*.json` (+ `index.json`), `src/data/gateMetadata.ts` (§5.4–5.5),
   `src/config/glossary.ts`.
   **Accept:** `npm run build:line-contracts` regenerates 10 line JSONs + index with no
   validation violations; `getGateName("G-DC")==="Discovery Complete"` and
   `formatGateLabel("G-DC")==="Discovery Complete (G-DC)"`.

10. **Pages.** Implement every page in §3.1 (portfolio, applications + detail tabs, gates +
    review, escalations, my-tasks, my-bundles, waves + detail, assembly lines + dashboard +
    anatomy + spotlight, skills, analytics ×5, admin ×11, compliance ×4, target-architecture,
    capability-lineage, traceability, about-continuity, auth ×2, demo ×2, not-found) wiring the
    API helpers and contexts noted.
    **Accept:** `tsc -b && vite build` succeeds; each route renders without console errors under
    demo mode; ApplicationDetail sets the breadcrumb to the app name on mount.

11. **Unit + coverage gate.** Port co-located `*.test.tsx` and `src/test/setup.ts` (§8.1).
    **Accept:** `npm run test:coverage` passes at floors lines 81 / branches 70 / functions 76 /
    statements 78.

12. **E2E gates.** Add `playwright.config.ts` (§8.2), `tests-e2e/{visual,layout,a11y,
    stepper-regression,line-anatomy}.spec.ts`, `tests-e2e/fixtures/api-stubs.ts`, and the
    committed `visual.spec.ts-snapshots/`.
    **Accept:** `npm run test:layout` and `npm run test:a11y` pass (block-merge suites);
    `npm run test:visual` matches committed baselines (or regenerate intentionally via
    `npm run test:e2e:update`).

13. **Containerization.** Add `Dockerfile` (dev, node:22-slim + optional Zscaler CA),
    `Dockerfile.fargate` (multi-stage build → nginx, repo-root build context), and `nginx.conf`
    (§1.9).
    **Accept:** the dev image starts Vite on :3000; the fargate image serves the built SPA with
    SPA fallback and `GET /healthz` → `200 "ok"`; `/assets/*` carry immutable 1y caching and
    `/index.html` is `no-store`.

14. **End-to-end behavioral parity.** Point `VITE_API_BASE_URL`/`VITE_WS_BASE_URL` at a running
    `olympus-api` (spec 01) and exercise the live flows.
    **Accept:** portfolio loads from the active portfolio, gate review submits a decision, wave
    progress polls while RUNNING (swallowing `409 WAVE_WORKFLOW_NOT_STARTED`), the WebSocket
    connection indicator shows "Live", and the chat drawer scopes by section per `useChatContext`.
