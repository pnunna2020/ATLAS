# 07 — Assembly Lines & Framework Layer

> Regeneration specification for the **domain / framework layer** of Foundry
> (Olympus): the 10 assembly lines, 11 cross-cutting concerns, the FAA client
> profile, the 7 dispositions, the 3 risk tiers, the 15 standard gates, the
> Extract→Design→Generate factory (incl. the Ralph Loop), and the skill
> registry model. This layer is almost entirely **markdown + YAML specs**, not
> runtime code — it is the *connective tissue* that the Temporal workflows
> (doc 03), the API (doc 01), and the runtime/registries (doc 02) execute
> against. Where this doc references material that already exists in the repo,
> it **points** rather than duplicating; where the model must be precise, it
> captures it in full.
>
> Premise: the codebase will be deleted; this document is the only surviving
> artifact for the framework layer. Everything below is derived from the actual
> repo and cited as `{repo}:{file}:{line}`. Where written specs and code/other
> specs disagree, BOTH are documented and the drift is flagged (see
> [Drift Log](#drift-log)).
>
> Repo root: `/Users/pnunna/Documents/GitHub/foundry` (cited as `foundry`).

---

## 1. Four Pillars Recap

Olympus is a domain-customizable framework for modernizing enterprise
application portfolios using AI-native processes. Its conceptual model rests on
four pillars (`foundry:CLAUDE.md:111-125`):

| # | Pillar | Directory | What it is |
|---|--------|-----------|------------|
| 1 | **Assembly Lines** | `assembly-lines/` | 10 named process pipelines transforming defined inputs into defined outputs, with quality gates at transition points. Composable, extensible, parallelizable. |
| 2 | **Cross-Cutting Concerns** | `cross-cutting/` | 11 capabilities spanning all lines: Orchestration, Skills, Agents, Gates, HCD, Compliance, Security, Risk Classification, Extensibility, Traceability, Human-Agent Collaboration. |
| 3 | **Client Profiles** | `profiles/` | Domain-specific customization bundles (currently `faa`, plus a `test-generic`). A profile adapts risk tiers, compliance, tech stack, branding, scoring weights, gate criteria, and skills. |
| 4 | **Platform Specifications** | `specifications/` | API-first platform design (FastAPI backend, React+USWDS dashboard, Temporal orchestration, Git-backed artifact store, PostgreSQL query layer). Covered in regeneration docs 01–05. |

Two model attributes thread through all four pillars and are documented here
because they are pure framework constructs:

- **Git is the source of truth** — artifacts are versioned as commits; PostgreSQL
  is a derived, disposable projection rebuilt from Git (see doc 04).
- **Skills are the programmable control plane** — `SKILL.md` files define agent
  behavior; changing a skill changes factory behavior without altering pipeline
  structure (`foundry:cross-cutting/skills/README.md:3`,
  `foundry:assembly-lines/modernization/README.md:53`).

> **Architecture caveat (from the project's own guidance):** the
> `specifications/` tree describes a Temporal+A2A+MCP target architecture. The
> active runtime is Anthropic/Claude-Agent-SDK based, with Temporal present in
> `temporal/`. When code and spec disagree, **trust the code**. This document
> notes such drift inline.

---

## 2. Assembly Lines

### 2.1 Source of truth & line anatomy

The canonical registry, dependency model, and wave management are defined in
**`foundry:assembly-lines/overview.md`**. Read it first.

**Line anatomy (CURRENT convention).** Each line lives at
`assembly-lines/<line-name>/` and contains exactly **two files**
(`foundry:assembly-lines/overview.md:89-102`):

```
assembly-lines/<line-name>/
├── README.md     # Single source of truth: purpose, inputs, outputs,
│                 # dependencies, steps, gates, skills, agents, dashboard
└── artifacts.md  # Artifact specifications — what the line produces, schemas, formats
```

Verified contents of every line directory (each has exactly `README.md` +
`artifacts.md`): `architecture/`, `data/`, `deployment/`, `discovery/`,
`disposition/`, `governance/`, `modernization/`, `rationalization/`,
`sustainment/`, `validation/` (10 dirs + the top-level `overview.md`).

> **DRIFT-1 (line file convention).** The Olympus root `CLAUDE.md` boilerplate
> (and earlier revisions of `overview.md`) describes a **7-file** per-line
> convention: `README.md`, `steps.md`, `gates.md`, `skills.md`, `agents.md`,
> `artifacts.md`, `dashboard.md`. That convention is **retired**. The current
> repo uses `README.md` (which folds in steps/gates/skills/agents/dashboard) +
> `artifacts.md` only (`foundry:assembly-lines/overview.md:102`,
> `foundry:CLAUDE.md:146`). Rebuild to the 2-file model. *(Note: the Olympus
> repo's local CLAUDE.md in this working tree still asserts the 7-file model —
> that local note is stale relative to the foundry repo.)*

Within each `README.md`:
- **Skills** table — which cross-cutting skills the line invokes. Kept in sync
  with workflow dispatch; the skill-CI job enforces consistency
  (`foundry:assembly-lines/overview.md:98`).
- **Agents** table — agent roles and their model tiers (Tier 1 reasoning /
  Tier 2 standard / Tier 3 fast).
- **Gates / Steps / Dashboard** sections.

### 2.2 The 10 lines (registry)

From the Line Registry table (`foundry:assembly-lines/overview.md:9-20`):

| # | Line | Dir | Inputs | Outputs | Dependencies | Mode |
|---|------|-----|--------|---------|--------------|------|
| 1 | **Discovery** | `discovery/` | Legacy systems, docs, stakeholder context | Application catalog, 4-pass analysis, dependency maps, user context | None (entry point) | Per-app (parallel) |
| 2 | **Rationalization** | `rationalization/` | Analysis artifacts from Discovery | Disposition decisions, redundancy findings, wave plan, complexity tiers, user impact | Discovery (all apps) | Portfolio-wide |
| 3 | **Architecture** | `architecture/` | Disposition + wave plan | Cloud-native blueprints, EA alignment verification, integration architecture | Rationalization | Per-app or per-wave |
| 4 | **Data** | `data/` | Analysis artifacts + architecture blueprints | Data domain maps, shared-DB decomposition, migration strategies, ownership models | Discovery + Architecture | Per-domain |
| 5 | **Modernization** | `modernization/` | Architecture blueprints + data models | Extracted specs → DDD designs → generated code + tests | Architecture + Data | Per-app |
| 6 | **Disposition Execution** | `disposition/` | Disposition decisions from Rationalization | Decommission plans, vendor evaluations, retention plans, replatform configs, transition plans | Rationalization | Per-app |
| 7 | **Validation** | `validation/` | Modernized code + cATO artifacts | Parity reports, compliance certification, safety assurance clearance | Modernization | Per-app |
| 8 | **Deployment** | `deployment/` | Validated artifacts OR disposition-execution outputs | Production cutover, parallel-run completion, decommission certificates, cost savings | Validation OR Disposition Execution | Per-app |
| 9 | **Sustainment** | `sustainment/` | Active portfolio (legacy + modern) | Patching, incident response, change coordination, resource-drawdown tracking | Runs continuously | Portfolio-wide |
| 10 | **Governance** | `governance/` | All line outputs + production metrics | Health reports, drift alerts, extracted patterns, new/refined skills, compound-growth metrics | Runs continuously | Portfolio-wide |

> **Naming note.** The line registered as **"Disposition Execution"** lives in
> the directory `assembly-lines/disposition/` (not `disposition-execution/`).
> Its README scope is: "Execute non-modernization dispositions: Retire, Retain,
> Replace, Replatform, and Consolidate" — Refactor and Rearchitect instead flow
> through Modernization (`foundry:assembly-lines/disposition/README.md:3`).

### 2.3 Flow & dependency graph

The full ASCII flow diagram is in `foundry:assembly-lines/overview.md:35-74`.
Conceptually:

```
Discovery (entry)
   → Rationalization (portfolio-wide)
        ├→ Architecture ──┬→ Modernization → Validation → Deployment
        │                 │       (Extract→Design→Generate)
        │        Data ────┘
        └→ Disposition Execution ───────────────────────────→ Deployment
                          (Retire/Retain/Replace/Replatform/Consolidate)

═══ Sustainment (continuous) ═══════════════════════════════
═══ Governance & Improvement (continuous) ═════════════════
```

Dependency rules the orchestrator enforces
(`foundry:assembly-lines/overview.md:24-31`):
- **Parallel execution** — Architecture and Data run concurrently once
  Rationalization completes.
- **Wave pipelining** — Wave N in Deployment while Wave N+1 in Modernization
  while Wave N+2 in Architecture.
- **Independent tracks** — Disposition Execution runs in parallel with the
  Modernization → Validation → Deployment pipeline.
- **Continuous lines** — Sustainment and Governance run alongside everything
  without blocking.

**Rationalization is implemented as two Temporal workflows in sequence**
(`foundry:assembly-lines/overview.md:76-81`; cross-reference doc 03):
- `WaveRationalizationWorkflow` — cross-portfolio redundancy analysis,
  disposition recommendation fan-out across the wave, per-app synthesis, gate
  review staging (wave-scoped).
- `WaveWorkflow` — once Rationalization clears, drives the per-application
  pipelines (Discovery → per-disposition lines → Deployment) for the wave.
- Both live in `foundry:temporal/olympus_workflows/workflows/`.

### 2.4 Per-disposition routing through lines

A disposition decision routes an application to a specific sequence of lines
(`foundry:assembly-lines/rationalization/README.md:331-337`):

| Disposition | Primary line | Pipeline |
|-------------|--------------|----------|
| Refactor | Modernization | Architecture → Data → Modernization → Validation → Deployment |
| Rearchitect | Modernization | Architecture → Data → Modernization → Validation → Deployment |
| Retire | Disposition Execution | Disposition Execution → Deployment (decommission) |
| Retain | Disposition Execution | Disposition Execution (lightweight; stays in Sustainment) |
| Replace | Disposition Execution | Disposition Execution → Deployment (cutover) |
| Replatform | Disposition Execution | Disposition Execution → Deployment (platform migration) |
| Consolidate | Both | Target app → Modernization; redundant apps → Disposition Execution (Retire) |

### 2.5 Wave management & compound growth

`foundry:assembly-lines/overview.md:136-145`. Applications move through lines in
**waves** — batched groups sequenced by application dependency (especially
shared databases), risk tier, and factory capacity. Multiple waves run
concurrently at different pipeline positions. Wave cadence is configurable per
profile. The Governance line feeds learnings from completed waves into skills
and patterns for later waves — the **compound growth flywheel** (later waves
execute faster than earlier ones). Runtime concurrency caps live in
`foundry:temporal/olympus_workflows/types.py:131-135`:
`MAX_CONCURRENT_WAVES = 4`, `MAX_APPS_PER_WAVE = 10`,
`MAX_BC_CHILDREN_PER_APP = 12`, `MAX_VALIDATION_STREAMS = 4` (fixed).

### 2.6 Line-to-line contracts

Lines communicate through **versioned, schema-validated artifacts stored in
Git** (`foundry:assembly-lines/overview.md:149-158`). The contract is:
producer writes artifacts to a defined location/schema → consumer reads &
validates schema before processing → transition gate verifies completeness &
quality → every artifact references its source inputs (traceability). This
artifact-based coupling lets a line be replaced/extended/parallelized as long
as it honors the artifact contract. Per-line artifact schemas live in each
line's `artifacts.md`.

---

## 3. Cross-Cutting Concerns (11)

All live under `foundry:cross-cutting/<concern>/README.md` (intros cited).
Each concern is a capability that spans every assembly line.

1. **Orchestration** (`cross-cutting/orchestration/`) — "Workflow engine, state
   management, error recovery, and compensation. The runtime backbone that
   drives all assembly lines" (`README.md:3`). This is the conceptual home of
   the Temporal workflows in doc 03.
2. **Skills** (`cross-cutting/skills/`) — "AI behavior definitions that govern
   how agents perform specific tasks. Skills are the programmable control plane
   of Olympus" (`README.md:3`). Contains the 166+ skill subdirectories, the
   `registry.yaml`, and `CONVENTIONS.md`. See [§7](#7-skill-registry-model).
3. **Agents** (`cross-cutting/agents/`) — "Agent roles, model selection,
   evaluation, and team compositions. Defines who does the work, what model
   powers them, and how to measure their effectiveness" (`README.md:3`). Also
   contains `claude-agents-on-bedrock.md`.
4. **Gates** (`cross-cutting/gates/`) — "Quality checkpoints between and within
   assembly lines" (`README.md:3`). Home of the **Unified Gate Registry**
   ([§6](#6-gates-15-standard)). Also `nist-800-53-gate-mapping.md` (under
   compliance).
5. **HCD** (`cross-cutting/hcd/`) — "Personas, user journeys, accessibility,
   user impact analysis, and adoption tracking. HCD evidence flows through the
   same pipeline as technical evidence" (`README.md:3`).
6. **Compliance** (`cross-cutting/compliance/`) — "Section 508/WCAG, enterprise
   architecture alignment, coding standards, safety, and regulatory standards.
   Compliance is woven into assembly line definitions and gate criteria — not
   audited at the end" (`README.md:3`). Includes `nist-800-53-gate-mapping.md`
   and `regulation-cross-cut-template.md`.
7. **Security** (`cross-cutting/security/`) — "Intentional security design for
   both the Olympus platform and the applications it modernizes" (`README.md:3`).
8. **Risk Classification** (`cross-cutting/risk-classification/`) — "Tiered
   rigor based on system criticality. A generalized framework with
   domain-specific tier definitions in client profiles" (`README.md:3`). See
   [§5](#5-risk-tiers-3).
9. **Extensibility** (`cross-cutting/extensibility/`) — "Registry patterns for
   adding assembly lines, skills, dispositions, gates, and scoring dimensions.
   Olympus adapts to new domains through registration, not code modification"
   (`README.md:3`). Maps to the **6 extension points** — implemented as Python
   registries on a shared substrate at
   `foundry:temporal/olympus_workflows/registries/` (`assembly_line.py`,
   `disposition.py`, `analysis_pass.py`, `scoring_dimension.py`,
   `gate_provider.py`, `skill_composition.py`, plus `engine.py`,
   `profile_overrides.py`, `worker_bootstrap.py`, `defaults/`). See doc 02/03
   for the registry interfaces; this doc names them in [§8.4](#84-extension-points-touching-the-factory).
10. **Traceability** (`cross-cutting/traceability/`) — "Evidence chains from
    source to output, decision justification, and audit defense. Every Olympus
    output traces back to its inputs; every decision is defensible"
    (`README.md:3`). Citation format: `{artifact}:{section}:{finding-id}` or
    `{repo}:{file}:{line}`.
11. **Human-Agent Collaboration** (`cross-cutting/human-agent-collaboration/`) —
    "Review and approval workflows, oversight models, AI maturity levels, and
    escalation protocols. Defines how humans and agents co-produce work"
    (`README.md:3`). Olympus operates at **AI Maturity Level 3-4**: agents
    execute autonomously, humans review at gates.

> There is also `cross-cutting/templates/` (e.g. `devsecops-baseline/`) — a
> shared template set, not one of the 11 concerns.

---

## 4. FAA Client Profile

The FAA profile is the canonical worked example of a client profile. Directory:
`foundry:profiles/faa/`. Activating it loads all FAA extensions into the
registries (`foundry:profiles/faa/profile.yaml:2`).

### 4.1 `profile.yaml` — metadata + activation

(`foundry:profiles/faa/profile.yaml`). Configures:
- **Identity**: `id: faa`, version `1.0.0`, org = Federal Aviation
  Administration (parent DOT), sector Federal Gov — Transportation.
- **Portfolio scale**: ~200 applications, ~3000 databases, 10-year program,
  primary concern "NAS safety" (`:15-19`).
- **Extension bundles activated** (`:22-33`): `compliance.yaml`,
  `risk-classification.yaml`, `gates.yaml`, `scoring.yaml`, `technology.yaml`,
  `wave-planning.yaml`, `objectives.yaml`.
- **Profile-specific skills** (`:36-50`): `faa-code-standards`,
  `faa-style-greenfield`, `faa-style-brownfield`, plus Phase-3 ATLAS pilot
  certification skills (`pilot-certification-domain-modeler`,
  `faa-form-schema-generator`, `aerospace-medical-certification-mapper`,
  `form-8710-validator`, `medxpress-confirmation-binder`,
  `ame-decision-workflow-scaffolder`).
- **Templates** (`:53-57`): `safety-case.md`, `nas-impact-assessment.md`,
  `ato-decommission.md`, `security-safety-crosswalk.md`.
- **Deployment target** (`:62-65`): Tyrion Container Platform on AWS GovCloud
  (EKS).
- **DevSecOps baseline** (`:71-79`): CodeQL SAST, SBOM required, distroless base,
  Apache-2.0 license, branch protection (status checks, CODEOWNERS review,
  signed commits).
- **Inheritance** (`:82-83`): `inherits: null` (base profile), no overlays.
- **Mission context** (`:91-93`): markdown body of the FAA ATLAS Statement of
  Objectives is prepended to every dispatched agent's system prompt (loaded by
  `olympus-agent-runtime/src/services/profile_context.py`).

### 4.2 `compliance.yaml` — 5 compliance domains + regulatory sources

(`foundry:profiles/faa/compliance.yaml`). Defines what standards apply and at
which enforcement points:
1. **Accessibility** (`:6-41`): WCAG 2.1 AA (exceeds federal WCAG 2.0 AA min);
   USWDS + FAA Design System overlay; axe-core automated + JAWS/NVDA manual for
   Tier 1; concrete requirements (contrast 4.5/3.0, 44px touch targets, etc.).
2. **Security** (`:43-78`): NIST 800-53 Rev 5, OSCAL 1.1.2 artifacts, FAA Order
   1370.121, zero-trust, AES-256 at rest / TLS 1.2+ in transit, AWS Secrets
   Manager, patching SLA (critical 15d / high 30d / medium 90d / low 180d),
   OWASP enforcement rules.
3. **Enterprise Architecture** (`:80-92`): FAA AMS + EA Policy; gate `G-02`;
   Tier-1 review board = FAA EA Review Board.
4. **Coding** (`:94-112`): FAA Code Standards; linters per language
   (ruff/eslint/checkstyle/dotnet-format); twelve-factor adherence.
5. **Safety** (`:114-131`, Tier 1 only): FAA System Safety Assessment; 0.99
   traceability; IV&V; safety case; safety board; security-safety crosswalk;
   NAS impact assessment.
- **Regulatory sources** (`:133-288`): ingested CFR parts that serve as domain
  knowledge — 14 CFR Part 47 (Aircraft Registration), Part 61 (Pilot
  Certification), Part 63 (Other Flight Crew), Part 67 (Medical Standards),
  Part 183 (Representatives of the Administrator). Each lists authority,
  current amendment, analysis/raw-text paths, applicable FAA systems (IACRA,
  AMCS, MedXPress, DMS, etc.), and key concepts. These live on disk under
  `profiles/faa/regulatory-knowledge/<part>/`.
- **Branding** (`:290-303`): Source Sans Pro, primary `#15396c`, USA banner +
  DOT ribbon + FAA logo header, USWDS.

### 4.3 `risk-classification.yaml` — the 3 tiers (see §5)

(`foundry:profiles/faa/risk-classification.yaml`). Maps Olympus's generic 3-tier
model to FAA's "NAS Safety Tiering". Defines tier definitions, per-tier
parameters, auto-classification signals, and override rules. Full detail in
[§5](#5-risk-tiers-3).

### 4.4 `gates.yaml` — gate criteria additions & reviewer overrides

(`foundry:profiles/faa/gates.yaml`). `default_provider: github-pr`. Adds
FAA-specific checks/reviewers to standard gates without replacing them:
- `G-DC`: NAS interface inventory (T1), stakeholder business-criticality (T1);
  reviewers + safety_board_liaison.
- `G-DA`: FAA ISSM security review for Retire/Replace; reviewers + faa_issm.
- `G-02`: FAA EA Review Board (T1).
- `G-04b`: SWIM/Solace integration check (nas_facing), Gravitee API gateway
  spec (external_api).
- `G-04c`: FAA code standards, FAA security headers, twelve-factor compliance.
- `G-V2`: cATO OSCAL 1.1.2 package, FAA Order 1370.121 compliance.
- `G-V3`: NAS impact assessment, safety case review, security-safety crosswalk
  (T1); reviewers safety_board + compliance_lead.
- `G-DP-2`: ATO decommission certificate, data archival verification (retire).
- **Additional roles** (`:114-125`): `faa_issm`, `faa_ea_review_board`,
  `safety_board_liaison`.
- **SLA** (`:127-137`): per-tier critical-path / standard review hours.

### 4.5 `scoring.yaml` — scoring dimension weights

(`foundry:profiles/faa/scoring.yaml`). 6 dimensions whose weights MUST sum to
1.0. FAA elevates security-posture (0.25 vs default 0.20) and
architecture-clarity (0.25 vs 0.20), reduces code-quality (0.15 vs 0.20) and
dependency-currency (0.10 vs 0.15); test-coverage (0.15) and documentation
(0.10) unchanged. Each dimension declares `data_source` (a Discovery pass) and
a `scoring_function`.

### 4.6 `technology.yaml` — approved stack

(`foundry:profiles/faa/technology.yaml`). Infrastructure (Gravitee API gateway
mandatory, OKTA identity, AWS Lambda/EKS on Tyrion, Terraform, GitHub Actions,
Datadog, ArgoCD); data (legacy Oracle ~3000 DBs → Aurora PostgreSQL / DynamoDB);
messaging (Solace PubSub+/SWIM for NAS, EventBridge/SNS/SQS modern); legacy→
target modernization maps (Java EE→Spring Boot, ColdFusion→FastAPI/Node,
.NET→Node/TS Lambda, COBOL→Python/Java, batch→Step Functions); the **Phase-3
prototype target stack** (TypeScript/Node 20/Lambda/Express, React+USWDS, Aurora
PG, Cognito, Temporal, EventBridge); Tyrion compatibility requirements
(GitOps, OCI, twelve-factor, trunk-based, devsecops).

### 4.7 `objectives.yaml` — Agency Objectives layer

(`foundry:profiles/faa/objectives.yaml`). Outcome-shaped presentation contract
mapping the SOO's 8 objectives to KPIs/narrative templates; source of truth for
`presentation/exec/` and a future `GET /api/v1/portfolio/objectives`. Traces to
`specifications/agency-objectives-layer.md` and DECISION-020. Validated against
`schemas/profiles/objectives.schema.json`.

### 4.8 Other FAA profile assets

`profiles/faa/baselines/2024.yaml`, `branding/`, `config/` (15 per-skill config
overrides, e.g. `code-generation-*.yaml`, `tco-analyzer.yaml`),
`context-priors/manifest.yaml`, `delegation.yaml`, `regulatory-knowledge/`,
`skills/`, `templates/`, `wave-planning.yaml`. A second profile,
`profiles/test-generic/`, exists for portability proof
(`specifications/profile-portability-proof.md`).

---

## 5. Risk Tiers (3)

Olympus uses **3 risk tiers** (Tier 1 = highest criticality). Tier *definitions*
come from the **client profile**, not the core framework
(`foundry:CLAUDE.md:162`, `foundry:cross-cutting/risk-classification/README.md:3`).
The FAA instantiation (`foundry:profiles/faa/risk-classification.yaml`):

| Tier | FAA label | Definition | Key parameters (excerpt) |
|------|-----------|-----------|--------------------------|
| **Tier 1** | NAS Safety-Critical | Directly impacts NAS ops — failure could affect flight safety, ATC, or aviation safety data integrity (ATC systems, flight data, NOTAM, radar/surveillance, SWIM publishers) | Traceability fwd/bwd 0.99; coverage overall 0.90 / domain 0.95; parallel run **90d** continuous; **canary** deploy (5→25→50→100% over 14d); rollback 30d; **IV&V + safety case + safety board required**; force `tier_1` reasoning models; NAS impact assessment; stakeholder confirmation (`:10-36`) |
| **Tier 2** | Mission Support | Supports FAA mission, no direct NAS impact (certification tracking, workforce, logistics, finance, training) | Traceability 0.98; coverage 0.80/0.95; parallel run **30d**; **blue-green** (instant switch); rollback 14d; no IV&V/safety; default model tier (`:38-63`) |
| **Tier 3** | Administrative | Internal apps; failure = inconvenience with workarounds (timekeeping, travel, doc mgmt, intranet) | Traceability 0.98; coverage 0.80/0.95; parallel run **14d** sampling; blue-green; rollback 7d; default model tier (`:65-90`) |

- **Auto-classification signals** (`:92-117`): name/domain/interface heuristics
  map to a `tier_suggestion` with a confidence (e.g. name contains
  ATC/radar/NOTAM → T1 high; publishes/consumes SWIM → T1 high).
- **Override rules** (`:119-129`): any app reading/writing NAS operational DBs is
  **T1 minimum** (enforced); T1 requires Safety Board confirmation before
  proceeding past Discovery (enforced); downgrade from T1 needs documented
  justification + Safety Board approval (enforced); read-only T1 access is
  advisory case-by-case (not enforced).

Tiers drive **gate threshold overrides** (see [§6](#6-gates-15-standard)).
Override precedence: **per-app > risk tier > client profile > default**, and
overrides may only **increase** rigor
(`foundry:cross-cutting/gates/README.md:159-169`).

---

## 6. Dispositions (7)

Olympus uses **7 dispositions** (`foundry:CLAUDE.md:161`). They are defined in
the Rationalization line README's disposition table
(`foundry:assembly-lines/rationalization/README.md:176-182`):

| Disposition | When chosen | Evidence | Downstream line |
|-------------|------------|----------|-----------------|
| **Retire** | Redundant, low-use, or fully replaced by another system | Usage metrics, functional overlap with surviving app, stakeholder confirmation | Disposition Execution |
| **Retain** | Works well, low risk, unique business function | Clean quality assessment, unique value, low technical debt | Disposition Execution |
| **Refactor** | Sound business logic trapped in poor code quality | High technical debt but unique business value worth preserving | Modernization |
| **Rearchitect** | Architecture limitations blocking modernization goals | Monolithic coupling, scalability constraints, critical business function | Modernization |
| **Replace** | Beyond practical remediation, or better served by COTS/SaaS | Extreme technical debt + available modern alternative | Disposition Execution |
| **Replatform** | Suitable for low-code / citizen-development migration | Simple workflows, form-based UI, reporting — fits low-code platform | Disposition Execution |
| **Consolidate** | Multiple apps should merge into one — true redundancy confirmed | Redundancy matrix shows high overlap + same user base | Disposition Execution + Modernization |

User-impact requirement: Retire/Replace/Consolidate (user-facing) require user
impact analysis + transition plan; Rearchitect/Replatform optional; Refactor/
Retain none (`foundry:assembly-lines/rationalization/README.md:246-252`). The
disposition→line routing table is in [§2.4](#24-per-disposition-routing-through-lines).
Disposition logic is also encoded in the **Disposition Strategy Registry**
(`foundry:temporal/olympus_workflows/registries/disposition.py`) — one of the 6
extension points.

---

## 7. Gates (15 standard)

There are **15 standard gates** defined in the **Unified Gate Registry**
(`foundry:cross-cutting/gates/README.md:72-90`). Each has a stable **code**
(used in URLs, commits, schemas, registry IDs) and a friendly name:

| Gate (friendly name) | Code | Location | Purpose |
|----------------------|------|----------|---------|
| Discovery Complete | **G-DC** | Discovery → Rationalization | All apps cataloged and analyzed |
| Portfolio Rationalization Approval | **G-RR** | Rationalization (internal) | Overlap findings validated |
| Disposition Plan Approval | **G-DA** | Rationalization → downstream | Stakeholder sign-off on dispositions |
| Architecture Alignment Review | **G-02** | Architecture (internal) | Enterprise architecture standards met |
| Data Architecture Review | **G-DT** | Data (internal) | Domain ownership & decomposition validated |
| Extracted Specifications Review | **G-04a** | Modernization (Extract → Design) | Specs extracted with traceability |
| Modernization Design Review | **G-04b** | Modernization (Design → Generate) | DDD architecture with compliance integration |
| Generated Code Review | **G-04c** | Modernization (Generate → done) | Code generated with tests and compliance |
| Disposition Execution Plan Approval | **G-DE-1** | Disposition Execution (internal) | Execution plan reviewed & approved |
| Decommission Readiness Sign-off | **G-DE-2** | Disposition Execution (internal) | Ready for irreversible decommission |
| Functional Parity Confirmation | **G-V1** | Validation (Stream 1) | Behavioral parity confirmed |
| Compliance & Security Certification | **G-V2** | Validation (Stream 2+3) | Security + accessibility certified |
| Safety Assurance Sign-off | **G-V3** | Validation (Stream 4, Tier 1 only) | IV&V + safety case approved |
| Production Deployment Approval | **G-DP-1** | Validation → Deployment | All validation passed, env ready |
| Legacy Decommission Authorization | **G-DP-2** | Deployment (internal) | Parity sustained, adoption met, rollback expired |

**Gate model** (`foundry:cross-cutting/gates/README.md:13-60`): agent completes
work → artifacts committed to Git branch → PR with gate-check request →
automated checks (schema validation, coverage thresholds, traceability counts)
post results as PR comments → human reviewer evaluates evidence → PR approved →
Temporal **signal** advances the workflow; PR rejected → agent receives feedback
→ rework. Evidence may be produced by Olympus's internal hosted-agent pipelines
or by a **delegated bundle** (external human+agent producing artifacts against
the same JSON Schemas, submitted atomically).

**Four components per gate** (`:36-44`): automated checks, evidence package,
human review, approval mechanism. Worked threshold tables (G-04a/b/c, G-DA,
G-DP-2) are at `:92-153`, including **Tier-1 overrides** (e.g. G-04c coverage
≥80% standard / ≥90% Tier 1; backward traceability ≥98% / ≥99% Tier 1).

**Approval models** (`:173-203`): automated-only, automated + single reviewer,
automated + multiple reviewers, structured stakeholder checklist, board review;
plus a reviewer-assignment matrix per gate with Tier-1 overrides.

**Gate Provider Interface** (`:251-274`): the default is GitHub PR-based; the
provider is swappable (ServiceNow, JIRA, automated-only, custom) per profile —
this is the **Gate Provider** extension point
(`foundry:temporal/olympus_workflows/registries/gate_provider.py`).

> Note the codes are non-contiguous (G-DC, G-RR, G-DA, **G-02**, G-DT, G-04a/b/c,
> G-DE-1/2, G-V1/2/3, G-DP-1/2). `G-02` is a legacy numeric code kept stable for
> existing links; all others are mnemonic. Count = **15**, matching
> `foundry:CLAUDE.md:163`.

---

## 8. Modernization Factory + Ralph Loop

Source: `foundry:assembly-lines/modernization/README.md`.

### 8.1 The 3-step × 4-layer factory

The Modernization line runs apps dispositioned **Refactor** or **Rearchitect**
through a **3-step factory: Extract → Design → Generate**
(`:3`, `:9`). Each step is a 4-layer stack (`:11-56`):

| Layer | Role |
|-------|------|
| **Activities** | Sequential tasks performed by AI agents (pipeline — output feeds next) |
| **Skills** | `SKILL.md` files defining agent behavior (the programmable control plane) |
| **Specifications** | Machine-readable intermediate artifacts — the source of truth between steps |
| **Renditions** | Human-readable deliverables generated *from* specifications (never hand-authored) |

| Step | Activities | Key skills | Output specs | Exit gate |
|------|-----------|-----------|--------------|-----------|
| **1 Extract** (Legacy→Specs) | Pre-Process → Extract → Validate | `extraction`, `cross-validation` | Business Rules YAML, Test Scenarios, User Guide | **G-04a** |
| **2 Design** (Specs→Architecture) | Domain Modeling → API Design → Data Model | `module-design`, `api-specification`, `data-modeling` | Module Map YAML, OpenAPI 3.0, ER/DDL, Compliance Map | **G-04b** |
| **3 Generate** (Architecture→Code) | Code → Validate → Test | `tdd-generation`, `test-validation`, `style-greenfield`/`brownfield` | Source Code, Test Suites, 508 Audit, Security Scan | **G-04c** |

Generate produces code per bounded context in dependency order: Data → Domain →
Application → API → UI; cross-context integration after all contexts complete
(`:263-273`). The factory operates at **AI Maturity Level 3-4**: agents
autonomously extract, design, generate, test, and debug; humans review at gate
transitions (`:57`).

### 8.2 The Ralph Loop (TDD iteration cycle)

In the Generate step's **Validate** activity, a self-debugging TDD loop runs per
module (`:260`, `:275-301`):

```
Write tests from specs → Generate code to pass tests → Run test suite
   → all pass?  → SUCCESS
   → failures?  → Analyze failures → Apply fixes → (loop)
   while iteration < MAX; on exhaustion → ESCALATE
```

**Maximum iterations:** the modernization README states **"Maximum 10 iterations
per module"** (`:295`, `:297`, `:301`), and the runtime enforces exactly this:
`MAX_RALPH_ITERATIONS = 10` (`foundry:temporal/olympus_workflows/types.py:134`),
consumed by `generate_bc.py` (`:32`, `:55`, `:96`, `:303`). On exhaustion an
escalation record is created and the workflow waits.

**Escalation protocol** on hitting the cap (`:301-307`):
- **Path A — Re-Extract**: return to Step 1 with focused analysis (specs
  incomplete/contradictory). +1–2 weeks.
- **Path B — Manual Augment**: human fixes edge cases, AI continues; must keep
  ≥80% AI-generated code ratio. +3–5 days.
- **Path C — Re-Disposition**: return to Rationalization to change disposition
  (e.g. Replatform/Retain). Significant.

> **DRIFT-2 (Ralph Loop default — IMPORTANT).** The task brief and the *local*
> Olympus working-tree `CLAUDE.md` assert the Ralph Loop **default is 3
> iterations**, configurable via `Application.ralph_max_iterations` /
> `OLYMPUS_RALPH_MAX_ITERATIONS`. **Neither the foundry framework spec nor the
> runtime supports this.** The foundry modernization README says max **10**
> (`foundry:assembly-lines/modernization/README.md:295,301`); the runtime
> hard-codes `MAX_RALPH_ITERATIONS = 10` as a module constant
> (`foundry:temporal/olympus_workflows/types.py:134`) with **no** per-app
> override field and **no** `OLYMPUS_RALPH_MAX_ITERATIONS` env var anywhere in
> `temporal/`, `olympus-worker/`, `olympus-agent-runtime/`, or `olympus-api/`
> (grep returned zero matches). The foundry root `CLAUDE.md:164` only says the
> Ralph Loop is "the TDD cycle in Generate" — it makes no iteration-count claim.
> **Rebuild to 10, as a fixed constant.** *(The "3" that appears at
> `modernization/README.md:417` is the Ralph Loop Controller agent's **step
> number** in the factory, not an iteration count.)*

### 8.3 Complexity-based dispatch & agents

The factory scales with app complexity (Simple / Moderate / Complex), moving
from single-agent sequential to fan-out → synthesize per module/bounded-context
(`:337-...`). Agent roster with model tiers is at `:405-421` (Factory
Orchestrator Tier-1, Code Generator/Test Writer/Ralph Loop Controller Tier-2 at
step 3, Security/Accessibility Scanner Tier-3, etc.).

### 8.4 Extension points touching the factory

The factory is parameterized by registries (the **6 extension points**), all on
a shared substrate at `foundry:temporal/olympus_workflows/registries/`
(`foundry:CLAUDE.md:125`):

| Extension point | Registry module | Governs |
|-----------------|-----------------|---------|
| Assembly Line | `assembly_line.py` | Registering new lines |
| Disposition Strategy | `disposition.py` | The 7 dispositions + new ones |
| Analysis Pass | `analysis_pass.py` | Discovery analysis passes |
| Scoring Dimension | `scoring_dimension.py` | Scoring dimensions/weights |
| Gate Provider | `gate_provider.py` | Gate approval mechanism |
| Skill Composition | `skill_composition.py` | How skills compose/override |

(Interfaces & contracts: see regeneration doc 02/03. This doc only names them.)

---

## 9. Skill Registry Model

### 9.1 Where skills live & how they're defined

Skills live under `foundry:cross-cutting/skills/<skill-id>/`. Each skill is
defined by a **`SKILL.md`** file plus optional `references/`, `scripts/`,
`assets/`, `config.json`, and `fixtures/` (`foundry:CLAUDE.md:147`). Authoring
rules are the single source of truth in
`foundry:cross-cutting/skills/CONVENTIONS.md` (naming, SKILL.md structure,
frontmatter schema, profile overrides, the mandatory `depends_on` field). CI
enforces conventions.

**On-disk counts (verified):**
- `find cross-cutting/skills -name SKILL.md | wc -l` → **178** SKILL.md files.
- `find cross-cutting/skills -maxdepth 1 -mindepth 1 -type d | wc -l` → **187**
  subdirectories (178 skill dirs + non-skill dirs like `acceptable-divergences`,
  plus profile-overlay skills that share dirs).

### 9.2 The registry file

The authoritative index is **`foundry:cross-cutting/skills/registry.yaml`**
(2871 lines). It replaces the hand-maintained Python dicts that used to live in
`olympus-api/src/services/skill_bootstrap.py` and `scripts/seed_skills.py`
(`registry.yaml:1-8`). It is loaded by
`olympus_api.services.skill_registry.load_registry()`. CI job **P4-S7.H1**
enforces that every skill dispatched by a workflow has a registry entry **and** a
`SKILL.md` on disk (`registry.yaml:12-14`).

**Top-level shape:** one key `skills:` (list, line 54) + `dispatch_aliases: []`
(line 2871).

**Entry count (verified):** `grep -cE '^  - id:'` → **167** entries; of those
exactly **1** has `is_orchestration: true` (a workflow step with no SKILL.md),
leaving **166** skills. Each of the 167 entries carries these required fields
(verified present on all 167): `id`, `version` (semver), `category`,
`enrichment`, `line`, `step`, `is_orchestration`, `variants`,
`profile_overrides`, `depends_on`. Optional fields appear on subsets:
`supported_stacks` (28), `validation_commands` (16), `benchmark_tags` (16),
`profile` (9), `also_consumed_by` (5), `failure_classes` (4), `currency` (4),
`status` (1).

> **DRIFT-3 (skill count — "137" / "~65").** The task GOAL and
> `foundry:CLAUDE.md:124` say **"137 skills across 12 categories"**; the local
> Olympus working-tree `CLAUDE.md` says **"~65 skills across 12 categories."**
> The actual registry has **167 entries (166 skills + 1 orchestration)** and
> **19 distinct `category` values** (not 12). **The registry is authoritative —
> rebuild to 167 entries.** The "137"/"65"/"12-category" figures in the
> CLAUDE.md docs are stale and should be corrected to match `registry.yaml`.
> (Also note: a separate DB seed snapshot counts `skill`=157 rows
> per `foundry:db/seeds/README.md` — a third, different number; that is the
> seeded subset, not the full registry.)

### 9.3 Categories (19 distinct, from `category:` values)

Verified tally (`grep '^    category:' | sort | uniq -c`):

| Category | Count | | Category | Count |
|----------|------:|-|----------|------:|
| Code Scaffolding & Templates | 31 | | Meta-Tooling | 4 |
| Business Process & Automation | 30 | | Cross-Cutting | 3 |
| Product Verification | 20 | | CI/CD & Deployment | 3 |
| Data Fetching & Analysis | 17 | | Identity & Auth | 2 |
| Legacy Analysis | 16 | | Synthesis | 1 |
| Library & API Reference | 12 | | Documentation | 1 |
| Runbooks & Operations | 11 | | Data Modeling & Schema Design | 1 |
| Infrastructure Operations | 6 | | Compliance & Evidence | 1 |
| Code Quality & Review | 6 | | Architecture & Design | 1 |
| | | | Analysis & Assessment | 1 |

(These are the operational/capability categories. The `line:` field separately
groups skills by assembly line: Modernization 49, Disposition Execution 22,
Discovery 19, Architecture 18, Rationalization 16, Governance 14, Validation 8,
Deployment 7, Data 6, Sustainment 6, Cross-Cutting 2.)

### 9.4 Enrichment levels (Minimal / Partial / Full)

Defined in `foundry:cross-cutting/skills/CONVENTIONS.md:113-123`:

| Level | Contents | Use for |
|-------|----------|---------|
| **Minimal** | `SKILL.md` only | Exploratory tasks, low-stakes analysis |
| **Partial** | `SKILL.md` + `references/` | Standard analysis tasks with domain grounding |
| **Full** | `SKILL.md` + `references/` + `scripts/` + `assets/` + `config.json` | Code generation, compliance artifacts, gate-critical outputs (implies deterministic validation + templated output) |

Verified `enrichment:` tally in `registry.yaml`: **minimal 93, partial 51,
full 22, Full 1** (the single capitalized `Full` is a casing inconsistency to
normalize — value should be lowercase `full`).

### 9.5 Composition, variants & profile overrides

- **`variants`** — conditionally-fired sub-skills keyed by tech stack or context
  (e.g. `discovery-patterns` has `discovery-patterns-mainframe` variants firing
  via a `when:` condition through a router; the base handles default/unknown
  stack — `registry.yaml:98-113`). Mirrors the `extraction` /
  `extraction-cobol` / `extraction-java` base+variant pattern.
- **`depends_on`** — declares skills this skill consumes (mandatory field;
  enables the Skill Composition extension point).
- **`profile_overrides`** — per-profile substitutions. Profile override
  precedence (`CONVENTIONS.md:137-149`): config variables (preferred) →
  full `SKILL.md` overlay at `profiles/<client>/skills/<skill>/SKILL.md`
  (replaces the cross-cutting body at load time; reserve for fundamentally
  different methodology, e.g. a FAA `safety-critical-verifier`).
- **`is_orchestration`** — `false` = real skill with a SKILL.md dir; `true` =
  workflow orchestration step name (no SKILL.md), present only if referenced by
  line READMEs (`registry.yaml:21-27`).
- **Optional `currency` block** (`registry.yaml:29-40`, modeled on 14 CFR Part 61
  §§61.56–61.57): `recency_window_days`, `minimum_recent_executions`,
  `revalidation_interval_days`, `lapsed_action`. Declarative-only at this
  revision (loader ignores unknown nested fields).
- **Optional benchmark metadata** (`registry.yaml:42-52`):
  `validation_commands`, `supported_stacks`, `failure_classes`,
  `benchmark_tags` — all independent and optional.
- **Version policy** — semver per entry: major = breaking SKILL.md output/
  `depends_on` change; minor = new capability/field/variant; patch = prompt/
  doc refinement (`registry.yaml:16-19`).

### 9.6 Validators

- `foundry:scripts/validate_skill_registry.py` +
  `foundry:tests/test_validate_skill_registry.py` — validates `registry.yaml`
  against the conventions.
- `foundry:scripts/verify_step_registry.py` — verifies step/skill name
  consistency vs. line READMEs.
- `foundry:olympus-api/src/services/skill_registry.py` +
  `foundry:olympus-api/tests/test_skill_registry.py` — runtime loader & tests.

---

## 10. Canonical Reference Files

These are the framework's glossary/decision anchors — point to them rather than
re-deriving terms:

| File | Role |
|------|------|
| `foundry:reference/terminology.md` | Unified glossary — canonical definitions for all Olympus terms across lines, concerns, specs, and profiles. |
| `foundry:reference/tech-stack.md` | Reference technology choices for the platform (profiles may override/add). |
| `foundry:reference/origins.md` | Lineage from ATLAS, PROS, and George frameworks. |
| `foundry:specifications/decisions.md` | Architectural Decision Records — 22 entries (e.g. DECISION-018 mock runtime, DECISION-020 Agency Objectives layer), with context/rationale/alternatives/traceability. |
| `foundry:assembly-lines/overview.md` | Line registry, dependency model, wave management, extensibility, line-to-line contracts. |
| `foundry:cross-cutting/gates/README.md` | Unified Gate Registry — all 15 gates, thresholds, approval models, provider interface. |
| `foundry:cross-cutting/skills/CONVENTIONS.md` | Skill authoring single source of truth — naming, SKILL.md structure, enrichment, overrides, `depends_on`. |
| `foundry:cross-cutting/skills/registry.yaml` | Authoritative skill index (167 entries). |
| `foundry:profiles/README.md` | Client-profile schema and loading behavior. |

---

## 11. Drift Log

| ID | Where | Spec/claim A | Spec/code B (authoritative) | Resolution for rebuild |
|----|-------|--------------|------------------------------|------------------------|
| **DRIFT-1** | Line file convention | CLAUDE.md boilerplate / old `overview.md`: 7 files per line (README, steps, gates, skills, agents, artifacts, dashboard) | Current `assembly-lines/overview.md:89-102` + `CLAUDE.md:146`: **2 files** (README.md folds in the rest, + artifacts.md). Verified on disk. | Rebuild **2-file** model. |
| **DRIFT-2** | Ralph Loop max iterations | Task brief + local Olympus CLAUDE.md: default **3**, configurable via `Application.ralph_max_iterations` / `OLYMPUS_RALPH_MAX_ITERATIONS` | `modernization/README.md:295,301` says max **10**; runtime `temporal/.../types.py:134` hard-codes `MAX_RALPH_ITERATIONS = 10`; **no** per-app field and **no** env var exist (grep = 0 matches) | Rebuild to **fixed 10**, no override/env var. |
| **DRIFT-3** | Skill registry count | GOAL + foundry CLAUDE.md:124: "**137** skills, **12** categories"; local Olympus CLAUDE.md: "**~65** skills, 12 categories"; DB seed: `skill`=**157** rows | `cross-cutting/skills/registry.yaml`: **167 entries** (166 skills + 1 orchestration), **19** category values; **178** SKILL.md files on disk | Registry authoritative — rebuild **167 entries / 19 categories**; correct CLAUDE.md. |
| **DRIFT-4** | Enrichment value casing | CONVENTIONS.md uses Title-case "Minimal/Partial/Full" | `registry.yaml` values are lowercase except **1** stray `Full` (vs 22 `full`) | Normalize to lowercase `full`. |
| **DRIFT-5** | Disposition Execution dir name | Line is named "Disposition Execution" in registry/gates | Directory is `assembly-lines/disposition/` (not `disposition-execution/`) | Rebuild dir as `disposition/`; keep display name "Disposition Execution". |
| **DRIFT-6** | Target architecture | `specifications/` describes Temporal+A2A+MCP target | Active runtime is Anthropic/Claude-Agent-SDK based (Temporal present in `temporal/`); per project guidance, trust the code | This framework layer is runtime-agnostic markdown/yaml; flag the A2A/MCP target as aspirational. |

---

## Atomic Rebuild Checklist

Ordered, independently verifiable steps. Each has an explicit acceptance check.
Run from repo root (`foundry`).

1. **Create the 10 assembly-line directories**, each with `README.md` +
   `artifacts.md` only.
   - *Check:* `ls assembly-lines/` lists exactly:
     `architecture data deployment discovery disposition governance
     modernization rationalization sustainment validation overview.md`; and
     `for d in assembly-lines/*/; do ls "$d"; done` shows exactly `README.md`
     and `artifacts.md` in each (DRIFT-1).

2. **Author `assembly-lines/overview.md`** with the Line Registry table
   (10 rows), the dependency model bullets, the ASCII flow diagram, wave
   management, and the two-Temporal-workflow note (WaveRationalizationWorkflow /
   WaveWorkflow).
   - *Check:* table has 10 line rows; document references both
     `WaveRationalizationWorkflow` and `WaveWorkflow`.

3. **Encode the 7 dispositions** in `assembly-lines/rationalization/README.md`
   (disposition table + downstream routing table).
   - *Check:* `grep -ciE 'retire|retain|refactor|rearchitect|replace|replatform|consolidate'`
     finds all 7 names in the disposition table; routing table maps Refactor/
     Rearchitect → Modernization and the other 5 → Disposition Execution
     (Consolidate → Both).

4. **Author the Modernization factory** in `assembly-lines/modernization/README.md`:
   3 steps (Extract/Design/Generate), 4 layers (Activities/Skills/Specs/
   Renditions), exit gates G-04a/b/c, and the Ralph Loop with **max 10
   iterations** + 3 escalation paths (A/B/C).
   - *Check:* `grep -c 'Maximum 10 iterations'` ≥ 1; `grep -c 'G-04'` ≥ 3;
     the README names skills `extraction`, `module-design`, `tdd-generation`.

5. **Add the runtime Ralph constant** `MAX_RALPH_ITERATIONS = 10` in
   `temporal/olympus_workflows/types.py`, with no per-app override and no env
   var (DRIFT-2).
   - *Check:* `grep -rIn 'MAX_RALPH_ITERATIONS' temporal/` shows the constant =
     `10` and references in `workflows/generate_bc.py`;
     `grep -rIn 'OLYMPUS_RALPH_MAX_ITERATIONS\|ralph_max_iterations' .` returns
     **0** matches outside this doc.

6. **Create the 11 cross-cutting concern dirs**, each with `README.md` (Skills
   also has `CONVENTIONS.md`, `registry.yaml`, and skill subdirs).
   - *Check:* `ls cross-cutting/` includes `agents compliance extensibility
     gates hcd human-agent-collaboration orchestration risk-classification
     security skills traceability` (11) (+ `templates`).

7. **Author the Unified Gate Registry** in `cross-cutting/gates/README.md` with
   all 15 gate codes and friendly names, the gate model, four components,
   approval models, reviewer matrix, and Gate Provider Interface.
   - *Check:* all 15 codes present: `for g in G-DC G-RR G-DA G-02 G-DT G-04a
     G-04b G-04c G-DE-1 G-DE-2 G-V1 G-V2 G-V3 G-DP-1 G-DP-2; do grep -q "$g"
     cross-cutting/gates/README.md || echo "MISSING $g"; done` prints nothing.

8. **Build the FAA profile** at `profiles/faa/` with `profile.yaml`,
   `compliance.yaml`, `risk-classification.yaml`, `gates.yaml`, `scoring.yaml`,
   `technology.yaml`, `objectives.yaml`, plus `baselines/`, `branding/`,
   `config/`, `context-priors/`, `delegation.yaml`, `regulatory-knowledge/`,
   `skills/`, `templates/`, `wave-planning.yaml`.
   - *Check:* `ls profiles/faa/*.yaml` lists the 8 YAMLs;
     `profile.yaml` `extensions:` block references all activated bundles.

9. **Validate the 3 risk tiers** in `profiles/faa/risk-classification.yaml`:
   tier_1 (NAS Safety-Critical, 0.99 traceability, 90d parallel run, canary,
   IV&V+safety case+safety board), tier_2 (Mission Support, 30d, blue-green),
   tier_3 (Administrative, 14d). Plus auto-classification signals and override
   rules.
   - *Check:* `grep -c 'tier_[123]:'` = 3; tier_1 `parallel_run_days: 90`,
     `ivv_required: true`, `safety_case_required: true`.

10. **Validate scoring weights sum to 1.0** in `profiles/faa/scoring.yaml`
    (6 dimensions).
    - *Check:* sum of `weight:` values across the 6 dimensions = `1.0`
      (0.15+0.15+0.25+0.10+0.10+0.25); `total_weight: 1.0` present.

11. **Build the skill registry** `cross-cutting/skills/registry.yaml` with
    167 entries, each carrying the 10 required fields; 1 entry
    `is_orchestration: true`; `CONVENTIONS.md` defining Minimal/Partial/Full.
    - *Check:* `grep -cE '^  - id:' cross-cutting/skills/registry.yaml` = **167**;
      `grep -c 'is_orchestration: true'` = **1**;
      `grep -cE '^    enrichment:'` = **167**.

12. **Ensure every dispatched skill has a SKILL.md + registry entry.**
    - *Check:* `find cross-cutting/skills -name SKILL.md | wc -l` ≥ **166**;
      `python scripts/validate_skill_registry.py` (via
      `pytest tests/test_validate_skill_registry.py`) passes;
      `python scripts/verify_step_registry.py` passes.

13. **Wire the 6 extension-point registries** at
    `temporal/olympus_workflows/registries/`: `assembly_line.py`,
    `disposition.py`, `analysis_pass.py`, `scoring_dimension.py`,
    `gate_provider.py`, `skill_composition.py` (+ `engine.py`).
    - *Check:* all six module files exist; `ls
      temporal/olympus_workflows/registries/` lists them.

14. **Confirm reference anchors exist:** `reference/terminology.md`,
    `reference/tech-stack.md`, `reference/origins.md`,
    `specifications/decisions.md`.
    - *Check:* all four files present; `specifications/decisions.md` Decision
      Index lists ≥ 20 DECISION rows.

15. **Run the framework drift reconciliation:** confirm CLAUDE.md figures
    match the registry (167/19) and the Ralph cap (10), or document the
    deltas in this Drift Log.
    - *Check:* DRIFT-1…DRIFT-6 in [§11](#11-drift-log) each resolve to the
      authoritative source above; rebuilt artifacts match the "Resolution"
      column.
