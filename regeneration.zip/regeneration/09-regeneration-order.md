# 09 — Regeneration Order & Contracts Appendix

> **Premise.** This document is the **build runbook** for the regeneration spec. It defines the
> exact sequence to rebuild Foundry/Olympus from zero, and the **validation gate** that proves
> each layer is correct before moving to the next. It also serves as the **contracts appendix**,
> referencing every authoritative contract artifact. Use it alongside doc 00 (the map) and the
> eight subsystem docs (01–08).
>
> **Repo root:** `/Users/pnunna/Documents/GitHub/foundry`. Citations: `{repo}:{file}:{line}`.

---

## 1. Regeneration Principles

1. **Contracts before code.** Restore `olympus-contracts` + `schemas/` first; everything imports
   from them. (Doc 06.)
2. **Bottom-up dependency order.** Never build a layer before the layer it depends on passes its
   gate. The order below respects the dependency graph in [doc 00 §5](00-overview.md#5-dependency-graph-build--runtime).
3. **Every layer has a proof gate.** A layer is "done" only when its acceptance command exits 0
   *and* its coverage floor (doc 00 §6) is met. Do not proceed on a partially-passing layer.
4. **Git is the source of truth; PG is disposable.** Restore the Git artifact model before
   trusting any PostgreSQL state — PG is rebuilt from Git + migrations. (Doc 04.)
5. **Code wins over prose.** Where this spec and any older `specifications/` doc disagree, follow
   the regeneration docs and the [drift register](00-overview.md#7-drift-register).

---

## 2. The Regeneration Order (with validation gates)

Each phase lists: **what to build**, the **doc** with atomic detail, and the **GATE** — the
exact command/artifact that proves the phase is correct before you advance.

### Phase 0 — Repository scaffold & tooling
- **Build:** repo skeleton, `Makefile`, `docker-compose.yml`, `.env`/`.env.example`, root
  `package.json`/`tsconfig.json`, `.gitleaks.toml`, `.dockerignore`, the four
  `.github/workflows/` files. (Doc 08.)
- **GATE 0:**
  - `docker compose config` parses with no error (all 13 services resolve).
  - `make help` lists all 21 targets.
  - `gitleaks detect --config .gitleaks.toml` exits 0 on a clean tree.

### Phase 1 — Contracts & schemas (authoritative)
- **Build:** `olympus-contracts` package (enums, signals, errors, git types, assembly-line
  dataclass loader + 10 YAML contracts); all 84 JSON schemas + 24 samples under `schemas/`;
  `schemas/validate.sh`. (Doc 06.)
- **GATE 1:**
  - `pip install -e ./olympus-contracts` then `python -c "import olympus_contracts"` succeeds.
  - `cd olympus-contracts && pytest` passes (3 test modules).
  - `bash schemas/validate.sh` exits 0 and prints `Schemas: 84` / `Samples: 24`.
  - `make validate-schemas` exits 0.

### Phase 2 — Framework / domain layer
- **Build:** `assembly-lines/` (10 lines + `overview.md`), `cross-cutting/` (11 concerns),
  `profiles/faa/*` (7 YAMLs), `reference/`, the skill registry (167 entries / 19 categories),
  and the SKILL.md corpus. (Doc 07.)
- **GATE 2:**
  - `make validate-objectives` exits 0 (FAA profile validates against schema + registries).
  - Directory/count assertions in doc 07's checklist pass (10 line dirs, 11 concern dirs,
    7 disposition definitions, 15 gate definitions, 167 skill registry entries).

### Phase 3 — Data layer
- **Build:** `db/` (alembic config, `env.py`, `init/01-create-databases.sh`, seeds),
  migrations `001`→`057` (56 files, no `055`). (Doc 04.)
- **GATE 3:**
  - `docker compose up -d postgres` then the init script created DBs `olympus`, `temporal`,
    `temporal_visibility` (verify via `\l` / `pg_database`).
  - `alembic upgrade head` then `alembic current` == head `057`; `alembic heads` shows a
    single head.
  - Schema assertions from doc 04 checklist: expected enums in `pg_type`, expected tables in
    `information_schema.tables`, expected indexes in `pg_indexes`, the two views present.
  - `pytest` schema-drift test (doc 04) passes.

### Phase 4 — Core services (Temporal + API)
Build these together; the API starts/queries workflows and the worker hosts them.
- **4a. Temporal orchestration** — worker bootstrap, ~18 workflows, ~50 activities, 6 extension
  registries + defaults YAML. (Doc 03.)
  - **GATE 4a:** `cd temporal && pytest -n 4 --cov` passes at **≥78%**; worker imports and
    registers all task queues (doc 03 checklist import/registration probes).
- **4b. olympus-api** — app factory, 36 routers, 43 services, middleware, JWT/OIDC/service-token
  auth. (Doc 01.)
  - **GATE 4b:** `cd olympus-api && pytest --cov` passes at **≥87%**; `make seed-tokens`
    mints JWTs; route-inventory assertion matches doc 01; `/health/ready` envelope check.

### Phase 5 — Agent & integration services
- **5a. olympus-worker** — Temporal worker entrypoint + agent dispatch (live\|mock switch),
  model resolver, fallback adapter, config YAMLs. (Doc 02.)
  - **GATE 5a:** `cd olympus-worker && pytest --cov` ≥**90%**; mock-mode dispatch test passes.
- **5b. olympus-agent-runtime** — agent executor, skill loader, model selector, output
  validator, A2A endpoint, health. (Doc 02.)
  - **GATE 5b:** `pytest --cov` ≥**90%**; A2A endpoint contract test + health check pass.
- **5c. mcp-server** — MCP tools/resources over the query DB. (Doc 02.)
  - **GATE 5c:** `pytest --cov` ≥**90%**; tool/resource inventory matches doc 02.
- **5d. olympus-cli** — every CLI command. (Doc 02.)
  - **GATE 5d:** `pytest` passes; `olympus --help` lists all commands (no coverage floor).

### Phase 6 — Dashboard
- **Build:** React + USWDS + Vite SPA — ~25 pages, ~60 components, API layer, demo mode,
  design tokens, nginx + Dockerfiles. (Doc 05.)
- **GATE 6:**
  - `cd dashboard && npm ci && npm run build` succeeds (Vite production build).
  - `npm run test -- --coverage` meets floors (lines 81 / branches 70 / functions 76 /
    statements 78).
  - Playwright e2e (`a11y`, `layout`, `visual`, `stepper-regression`, `line-anatomy`) pass.

### Phase 7 — Full-stack bring-up & behavioral parity
- **Build:** nothing new — wire the stack and run it end-to-end. (Doc 08.)
- **GATE 7 (DONE definition):**
  - `make up` (or `make demo-up`) brings up all 13 services; `make demo-wait` polls
    `/health/ready` to 200.
  - `make demo-seed` seeds FAA demo + Modernization Corpus; `make demo-smoke` asserts the
    expected portfolios exist via `/api/v1/portfolio`.
  - Dashboard renders at its port and drives a portfolio→application→wave→gate flow.
  - A Temporal workflow (e.g. `WaveWorkflow` / `WaveRationalizationWorkflow`) runs to a
    signal-based gate and resumes on signal — behaviorally identical to the documented flow.
  - `.github/workflows/ci.yml` passes green on the rebuilt repo (branch-naming, schema
    validation, per-service tests at floors, gitleaks).

---

## 3. Critical-Path Summary

```
Phase 0  scaffold/tooling ─┐
Phase 1  contracts+schemas ─┼─► Phase 2  framework layer
                            │
                            └─► Phase 3  data layer ─► Phase 4  temporal + api
                                                          │
                                                          ├─► Phase 5  worker / agent-runtime / mcp / cli
                                                          │
                                                          └─► Phase 6  dashboard
                                                                          │
                                                                          ▼
                                                              Phase 7  full-stack parity (DONE)
```

Phases 1 and 3 can proceed in parallel after Phase 0; Phase 2 needs Phase 1. Phase 4 needs
Phases 1+3. Phase 5 needs Phase 4. Phase 6 needs Phase 4 (API contract). Phase 7 needs all.

---

## 4. Contracts Appendix

The authoritative contract artifacts. **These are produced before code** and are the reference
inputs for every service. Full field-level detail is in [doc 06](06-contracts.md); this appendix
is the index.

### 4.1 `olympus-contracts` Python package
Source: `foundry:olympus-contracts/olympus_contracts/`
- `enums.py` — 9 domain enums (dispositions, risk tiers, line/step/gate identifiers, statuses).
- `signals.py` — 3 Temporal signal payload types (gate signals).
- `errors.py` — 3 Git-service merge error types.
- `git_types.py` — 6 Git-service types.
- `assembly_lines.py` — frozen dataclass loader for the 10 assembly-line YAML contracts.
- `__init__.py` — public re-export surface (every consumer imports from here).

### 4.2 JSON Schemas (`schemas/`, 84 schemas + 24 samples)
Grouped by subdir (complete per-file inventory with `$id`/title in doc 06):

| Subdir | Purpose |
|--------|---------|
| `common/` | Shared primitives reused via `$ref`. |
| `cross-cutting/` | `event-envelope`, `temporal-workflow-contract`, `audit-event`, `metric`, `traceability-report`, `attestation-chain`, `rendition-manifest`, `journey-fsm`, `score-snapshot`, `oidc-server-config`. |
| `discovery/` | catalog, analysis-report, capability-catalog, business-logic/rule inventory, tech-fingerprint, identity-landscape, quality-risk, ux-accessibility, discovery-synthesis, eligibility/8710 domain schemas. |
| `rationalization/` | scoring & disposition decision contracts. |
| `architecture/` | target architecture projection contracts. |
| `data/` | data-line projection contracts. |
| `modernization/` | Extract→Design→Generate factory contracts. |
| `dispositions/` | base `disposition-output` + one per disposition: retire, retain, refactor, rearchitect, replace, replatform, consolidate. |
| `gates/` | `gate-review-checklist`, `gate-evidence-package`, `escalation-record`. |
| `profiles/` | profile/objectives validation schemas. |
| `design/` | FAA domain design schemas — **note: excluded by `validate.sh`** (drift D4). |
| `samples/` | 24 example instances used to exercise schemas in validation. |

### 4.3 Validation & CI enforcement
- `schemas/validate.sh` — metaschema + shape validation; exit 0 + `Schemas: 84` / `Samples: 24`.
- `make validate-schemas` — Make wrapper around `validate.sh`.
- CI (`.github/workflows/ci.yml`) runs schema validation with an `$id`-keyed `RefResolver`
  (so the exact `$id` host strings are load-bearing — drift D5).

### 4.4 OpenAPI surface
- `olympus-api` exposes its OpenAPI document via FastAPI (the app's `/openapi.json`); see doc 01
  for the route inventory the spec is generated from. There is no committed static `openapi.json`
  — it is produced from the FastAPI app at runtime.

### 4.5 Temporal interface contracts
- `schemas/cross-cutting/temporal-workflow-contract.schema.json` defines the workflow contract
  envelope; the concrete workflow/activity signatures are in doc 03. The 6 extension-point
  registries load default YAML from `temporal/olympus_workflows/registries/defaults/`
  (`dispositions.yaml`, `scoring-dimensions.yaml`, `skill-compositions.yaml`,
  `gate-providers.yaml`) plus profile overrides.

---

## 5. Final Acceptance (the GOAL's "Done when")

A reader with no prior exposure to Foundry, using only `specifications/regeneration/`, must be
able to:
1. Rebuild each service and pass its tests at the documented coverage floors (doc 00 §6).
2. Bring up the full `docker-compose` stack via `make up` / `make demo-up` (Phase 7).
3. Reproduce the dashboard (Phase 6) and the Temporal workflows behaviorally identically
   (Phase 4a + Phase 7).

When GATE 7 passes green, the regeneration is complete.
