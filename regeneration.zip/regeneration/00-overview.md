# 00 — Regeneration Specification: System Overview & Map

> **Premise.** The current Foundry/Olympus codebase will be deleted. The documents in
> `specifications/regeneration/` are the **only** surviving artifacts. An engineering team
> (human or AI) must be able to rebuild every service from scratch — behaviorally identical,
> passing tests at the documented coverage floors, bringing up the full `docker-compose`
> stack, and reproducing the dashboard and Temporal workflows — using *only* these documents.
>
> This file is the **map**: it tells you what exists, how the pieces fit, what order to build
> in, and where to find the atomic detail. Everything is derived from the actual repository
> and cited as `{repo}:{file}:{line}`. Where the written specs and the running code disagree,
> the code wins and the drift is flagged (see [§7 Drift Register](#7-drift-register)).
>
> **Repo root:** `/Users/pnunna/Documents/GitHub/foundry`

---

## 1. What Foundry/Olympus Is

Olympus (the platform; "Foundry" is the working repo name) is a **domain-customizable
framework and platform for modernizing enterprise application portfolios using AI-native
processes.** Humans and AI agents co-produce enterprise software through structured assembly
lines guarded by quality gates. It operates at AI Maturity Level 3–4: agents execute
autonomously; humans review at gates.

The system is realized as **seven deployable services + a contracts package + a framework
spec layer + a data layer**, orchestrated by Temporal and fronted by a React/USWDS dashboard.

> **Architecture reality check.** The `specifications/` tree describes a
> **Temporal + A2A + MCP** target architecture. The running code **does** use Temporal
> (see doc 03) and **does** ship an MCP server (doc 02) and an A2A endpoint on the agent
> runtime (doc 02), so the implemented architecture largely matches the target — with
> documented drifts. When in doubt, trust the regeneration docs, which are derived from code.

---

## 2. The Four Pillars

| Pillar | Where | Regeneration doc |
|--------|-------|------------------|
| **1. Assembly Lines** — 10 named process pipelines (Discovery → Rationalization → Architecture/Data → Modernization → Validation → Deployment, plus Disposition Execution, Sustainment, Governance) | `assembly-lines/` | [07](07-assembly-lines-and-framework.md) |
| **2. Cross-Cutting Concerns** — 11 capabilities spanning all lines (Orchestration, Skills, Agents, Gates, HCD, Compliance, Security, Risk Classification, Extensibility, Traceability, Human-Agent Collaboration) | `cross-cutting/` | [07](07-assembly-lines-and-framework.md) |
| **3. Client Profiles** — domain customization bundles (FAA) adapting risk tiers, compliance, tech stack, branding, scoring, skills | `profiles/` | [07](07-assembly-lines-and-framework.md) |
| **4. Platform Specifications** — the runnable system: FastAPI API, Temporal worker, agent runtime, MCP server, CLI, dashboard, PostgreSQL query layer, Git artifact store | `olympus-*`, `temporal/`, `dashboard/`, `db/`, `schemas/` | [01](01-olympus-api.md)–[06](06-contracts.md), [08](08-build-ci-tooling.md) |

---

## 3. Document Set

| Doc | Subsystem | Lines | Key build artifacts |
|-----|-----------|------:|---------------------|
| **00** | This overview / system map | — | — |
| **[01](01-olympus-api.md)** | `olympus-api` (FastAPI backend) | 1079 | 36 routers, 43 services, JWT/OIDC auth, middleware stack |
| **[02](02-worker-agent-runtime-mcp-cli.md)** | `olympus-worker`, `olympus-agent-runtime`, `mcp-server`, `olympus-cli` | 961 | Temporal worker bootstrap, live\|mock agent dispatch, A2A endpoint, MCP tools, CLI |
| **[03](03-temporal-orchestration.md)** | `temporal/` orchestration | 1110 | ~18 workflows, ~50 activities, 6 extension-point registries |
| **[04](04-data-layer.md)** | PostgreSQL + Alembic + Git-as-SoT | 930 | Migrations 001→057, full schema, projection mechanism |
| **[05](05-dashboard.md)** | `dashboard/` (React + USWDS + Vite) | 771 | ~25 pages, ~60 components, design tokens, demo mode |
| **[06](06-contracts.md)** | `olympus-contracts` + `schemas/` | 685 | 84 JSON schemas, 24 samples, enums/signals/errors, assembly-line contracts |
| **[07](07-assembly-lines-and-framework.md)** | Assembly lines + cross-cutting + FAA profile | 861 | 10 lines, 11 concerns, 7 dispositions, 3 tiers, 15 gates, Ralph loop, skill registry |
| **[08](08-build-ci-tooling.md)** | Docker stack, Makefile, CI, deploy | 648 | 13-service compose stack, 21 Make targets, 4 CI workflows |
| **[09](09-regeneration-order.md)** | Build sequence + validation gates + contracts appendix | — | The order to rebuild in, with per-layer proof gates |

Each subsystem doc ends with an **Atomic Rebuild Checklist** — ordered, independently
buildable/testable steps, each paired with an explicit acceptance check (a command to run or
artifact to inspect).

---

## 4. Service Inventory (the runtime)

The full local stack is a single `docker-compose.yml` (13 services, no explicit network —
all share the default bridge and address peers by service name). Source:
`foundry:docker-compose.yml`.

| Compose service | Role | Doc | Port(s) |
|-----------------|------|-----|---------|
| `postgres` | PostgreSQL 16; hosts `olympus`, `temporal`, `temporal_visibility` DBs | 04 | 5432 |
| `redis` | Cache / rate-limit / ephemeral state | 01, 08 | 6379 |
| `localstack` | Local AWS (S3/Bedrock stand-ins) | 08 | 4566 |
| `db-migrate` | Runs Alembic migrations to head, then exits | 04 | — |
| `temporal-server` | Temporal service | 03 | 7233 |
| `temporal-namespace-init` | One-shot namespace registration | 03 | — |
| `temporal-ui` | Temporal web UI | 03 | 8080→8233 |
| `olympus-api` | FastAPI backend | 01 | 8000 |
| `olympus-temporal-worker` | Temporal worker (workflows + activities) | 02, 03 | — |
| `olympus-dashboard` | React SPA (nginx) | 05 | 80/5173 |
| `olympus-agent-runtime` | Agent executor (live\|mock), A2A endpoint | 02 | 8100 |
| `olympus-agent` | Agent sidecar/workspace variant | 02 | — |
| `olympus-mcp-server` | MCP tools/resources over the query DB | 02 | — |

Named volumes: `postgres-data`, `redis-data`, `localstack-data`, `agent-workspace`.
`olympus-cli` is not a compose service — it is a local CLI package (no Dockerfile).

---

## 5. Dependency Graph (build & runtime)

```
                          ┌─────────────────────┐
                          │  olympus-contracts  │  (enums, signals, errors,
                          │   + schemas/ (84)   │   assembly-line contracts —
                          └──────────┬──────────┘   contracts-before-code)
                                     │ imported / re-exported by everything
        ┌───────────────┬───────────┼────────────┬──────────────┐
        ▼               ▼           ▼            ▼              ▼
 ┌────────────┐  ┌────────────┐ ┌────────┐ ┌────────────┐ ┌──────────┐
 │ olympus-api│  │  temporal  │ │ worker │ │agent-runtime│ │mcp-server│
 │ (FastAPI)  │  │ workflows  │ │        │ │ (live|mock) │ │          │
 └─────┬──────┘  └─────┬──────┘ └───┬────┘ └──────┬──────┘ └────┬─────┘
       │ reads/writes  │ executes   │ hosts       │ executes     │ reads
       ▼               ▼            ▼ workflows    ▼ agent tasks  ▼
 ┌──────────────────────────────────────────────────────────────────┐
 │  PostgreSQL (derived query layer)  ◄── rebuilt from ──  Git (SoT)  │
 └──────────────────────────────────────────────────────────────────┘
       ▲
       │ HTTP + WebSocket/SSE
 ┌─────┴──────┐
 │  dashboard │  (React + USWDS; or fully-stubbed demo mode)
 └────────────┘
```

**Key invariants:**
- **Contracts before code.** `olympus-contracts` + `schemas/` are authoritative and built
  first; every other package installs the contracts package editable and imports from it.
- **Git is the source of truth.** Artifacts are committed to Git; PostgreSQL is a *derived,
  disposable* query/read layer populated by `persist_*_side_effects` activities that parse
  committed JSON after merge. PG can be dropped and rebuilt from Git + migrations. (Doc 04.)
- **Temporal orchestrates.** Assembly-line steps are Temporal workflows/activities; gates are
  signal-based waits; the API starts workflows and fires gate signals; the worker hosts them;
  the agent runtime executes the `dispatch_agent_task` activity. (Docs 01–03.)
- **The 6 extension points** (Assembly Line, Disposition Strategy, Analysis Pass, Scoring
  Dimension, Gate Provider, Skill Composition) are registries under
  `temporal/olympus_workflows/registries/`, each with default YAML and profile overrides.

---

## 6. Coverage Floors (test gates per package)

The "rebuilt correctly" bar includes passing each package's test suite at its coverage floor.
Floors live in per-package `pyproject.toml`/`vitest.config.ts`, not the CI YAML.

| Package | Test runner | Coverage floor |
|---------|-------------|----------------|
| `olympus-api` | `pytest --cov` | **87%** (`--cov-fail-under=87`) |
| `olympus-worker` | `pytest --cov` | **90%** (per DECISION-017) |
| `olympus-agent-runtime` | `pytest --cov` | **90%** |
| `mcp-server` | `pytest --cov` | **90%** |
| `olympus-cli` | `pytest` | none (excluded from CI coverage matrix) |
| `temporal` | `pytest -n 4 --cov` | **78%** (`--cov-fail-under=78`) |
| `dashboard` | `vitest --coverage` | lines **81**, branches **70**, functions **76**, statements **78** |
| `schemas` | `schemas/validate.sh` | 84 schemas + 24 samples validate, exit 0 |

> Floors **ratchet up only** — never lower them during a rebuild. Confirm the exact current
> value in the cited package config before relying on these numbers.

---

## 7. Drift Register (code-vs-spec discrepancies)

Flagged by the subsystem agents; the **code is authoritative**. Full detail in each doc.

| # | Drift | Authoritative reality | Doc |
|---|-------|-----------------------|-----|
| D1 | **Ralph Loop iterations.** CLAUDE.md says "default 3, configurable via `Application.ralph_max_iterations` / `OLYMPUS_RALPH_MAX_ITERATIONS`." | Code has a fixed `MAX_RALPH_ITERATIONS = 10`; **no such field or env var exists**. | 07 |
| D2 | **Skill registry count.** CLAUDE.md says ~65 / ~137 skills across 12 categories; GOAL.md says 137. | Actual registry holds **167 entries across 19 categories**. | 07 |
| D3 | **Contracts version.** Package metadata shows `0.3.0` in one place and `0.2.0`/`0.3.0` drift across files. | Reconcile to a single version on rebuild; flagged anomaly. | 06 |
| D4 | **`design/` schemas skipped.** `validate.sh` does not validate `schemas/design/*`. | Validator covers 84 schemas + 24 samples but excludes `design/`. | 06 |
| D5 | **Inconsistent `$id` hosts.** CI's `$id`-keyed `RefResolver` depends on these. | Preserve the exact `$id` strings as-is; they are load-bearing for `$ref` resolution. | 06 |
| D6 | **Migration docstring typos.** Migrations 027 and 049 name the wrong revision id in their docstrings. | The `revision` **string in code** is authoritative; ignore the docstring. | 04 |
| D7 | **No migration `055`.** The DAG runs 001→057 with 56 files; `055` is deliberately absent. | Expected gap — not a missing file. | 04 |
| D8 | **`.env` == `.env.example`.** They are byte-identical. | No real secrets in `.env`; safe to commit, but rotate for any real deploy. | 08 |
| D9 | **Postgres boots on DB `postgres`.** Init script creates the three real DBs. | Connect to `olympus`/`temporal`/`temporal_visibility`, not `postgres`. | 04, 08 |
| D10 | **CLI has no Dockerfile** and is excluded from the CI coverage matrix. | CLI ships as a local editable package only. | 02 |
| D11 | **Two Dockerfiles for dashboard.** `csn-deploy-dashboard` uses `Dockerfile.fargate`, distinct from the dev `Dockerfile`. | Build the Fargate image for the CSN/Fargate deploy path. | 05, 08 |

---

## 8. Glossary Pointers

Canonical definitions live in the repo (point, don't duplicate):
- `reference/terminology.md` — canonical glossary for all Olympus terms.
- `reference/tech-stack.md` — reference technology choices.
- `reference/origins.md` — lineage from ATLAS, PROS, George.
- `specifications/decisions.md` — architectural decision records (e.g. DECISION-017 coverage).
- `assembly-lines/overview.md` — line registry, dependency model, wave management.

The **7 dispositions**: Retire, Retain, Refactor, Rearchitect, Replace, Replatform,
Consolidate. The **3 risk tiers** (Tier 1 highest) are defined by client profiles, not core.
The **15 standard gates**: G-DC, G-RR, G-DA, G-02, G-DT, G-04a/b/c, G-DE-1/2, G-V1/2/3,
G-DP-1/2. (Detail in doc 07.)

---

## 9. How To Use This Spec

1. Read this overview, then **doc 09 (regeneration order)** for the exact build sequence and
   per-layer validation gates.
2. Build bottom-up: **contracts/schemas (06) → data layer (04) → services (01, 02, 03) →
   dashboard (05)**, wiring the stack per **doc 08** as you go.
3. The framework layer (**doc 07**) is mostly markdown/YAML; restore it alongside contracts so
   the registries and profiles have content to load.
4. Each layer is "done" only when its Atomic Rebuild Checklist passes — including the coverage
   floor in §6.
