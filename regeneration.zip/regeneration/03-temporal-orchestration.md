# 03 — Temporal Orchestration Layer (`temporal/`)

> **Premise.** This document is a behavioral-rebuild specification for the
> `temporal/` tree of the Foundry/Olympus repo. Assume the source code has
> been deleted. An engineering team must be able to rebuild the orchestration
> layer to behave identically using only this document. Everything below is
> derived from the actual source; citations use `{repo}:{file}:{line}`
> relative to the repo root, e.g. `temporal/olympus_workflows/workflows/wave.py:103`.
>
> **Companion docs.** `01-olympus-api.md` (FastAPI service that starts/queries
> workflows and fires gate signals), `02-worker-agent-runtime-mcp-cli.md` (the
> agent runtime that executes the `dispatch_agent_task` activity). This doc
> owns the Temporal worker, the workflow/activity definitions, the 6
> extensibility registries, config, and tests.

---

## 0. Package shape and dependencies

The package is `olympus-workflows` (importable as `olympus_workflows`), version
`0.1.0`, Python `>=3.11` (`temporal/pyproject.toml:6-9`). Build backend is
setuptools (`temporal/pyproject.toml:1-3`); `setuptools.packages.find` includes
`olympus_workflows*` (`temporal/pyproject.toml:132-133`).

Runtime dependencies (`temporal/pyproject.toml:10-29`):

- `temporalio>=1.7.0,<2.0.0` — Temporal Python SDK.
- `pydantic>=2.0.0,<3.0.0`.
- `asyncpg>=0.29.0` — direct Postgres writes for Layer B execution records and
  side-effect projections.
- `foundry-temporal>=1.3.0` — **private Artifactory registry**; the worker
  bootstrap, signal mixin, error taxonomy, and activity decorator all come from
  here. Without it nothing imports.
- `olympus-contracts>=0.1.0` — re-exports `AssemblyLine`, `Disposition`,
  `GateType`, `RiskTier`, the assembly-line YAML contracts, and the
  `get_line` / `step_weights` helpers consumed at module import.
- `pyyaml>=6.0` — `ModernizationWorkflow` reads the committed `module-map.yaml`
  to fan out per bounded context; profile loaders parse YAML.
- `jsonschema>=4.20.0` — disposition-output bundle + artifact validation.
- `sqlalchemy[asyncio]>=2.0.0,<3.0.0` — bundle activities wrap `olympus-api`'s
  bundle service over an `AsyncSession`.

Dev dependencies (`temporal/pyproject.toml:31-49`): `pytest>=7.0`,
`pytest-asyncio>=0.23.0`, `pytest-cov>=4.0`, `pytest-xdist>=3.5`, `ruff>=0.4.0`.

Source-tree layout (rebuild to match):

```
temporal/
  pyproject.toml
  config/                       services.yaml, workflows.yaml, activities.yaml
  scripts/                      smoke_test_agent.py
  olympus_workflows/
    worker.py                   bootstrap + ALL_WORKFLOWS + ALL_ACTIVITIES
    types.py                    all shared dataclasses + enums + limits (~2790 lines)
    retry_policies.py           named RetryPolicy objects + RETRY_POLICIES dict
    workflows/                  ~25 workflow + router modules
    activities/                 ~16 activity modules
    registries/                 6 extension points + engine + bootstrap + defaults/
    utils/                      execution.py, target_plan.py, __init__.py
  tests/                        74 test_*.py files + conftest + fixtures + schemas
```

---

## 1. The Worker (`temporal/olympus_workflows/worker.py`)

The worker is the single process that registers every workflow and activity and
connects to a Temporal server. Entrypoint: `python -m olympus_workflows.worker`
(`temporal/olympus_workflows/worker.py:3-4,270-271`).

### 1.1 Bootstrap sequence — `run_worker()` (`worker.py:225-267`)

Exact order (must be preserved for determinism):

1. **Activate profile first.** `bootstrap_profile_from_env()` is imported inside
   the function and called before anything else (`worker.py:238-242`). This
   populates the 6 extensibility registries with profile overrides *before* the
   worker accepts tasks — registries must never mutate mid-workflow.
2. `config = WorkerConfig.from_env()` (`worker.py:244`).
3. **Task-queue override:** if `config.task_queue == "foundry-workflows"`
   (the foundry-temporal default), set it to `"olympus-main"`
   (`worker.py:246-247`).
4. `client = await create_temporal_client(config)` (`worker.py:249`).
5. `worker = create_worker_with_defaults(client, workflows=ALL_WORKFLOWS,
   activities=ALL_ACTIVITIES, config=config)` (`worker.py:250-255`).
6. Log host, task queue, and counts; `await worker.run()` (`worker.py:257-267`).

`WorkerConfig`, `create_temporal_client`, `create_worker_with_defaults` come
from `foundry_temporal.worker` (`worker.py:27-31`). The worker fails to connect
without a running Temporal server — that is expected; the module's secondary
purpose is to prove every workflow/activity stub registers without error
(`worker.py:14-17`).

### 1.2 Environment variables (`worker.py:6-12`)

Handled by `WorkerConfig.from_env`:

| Env var | Default | Meaning |
|---|---|---|
| `TEMPORAL_HOST` | `localhost:7233` | server address |
| `TASK_QUEUE` | `olympus-main` (after override) | task queue name |
| `TEMPORAL_NAMESPACE` | `default` | namespace |
| `MAX_CONCURRENT_ACTIVITIES` | `100` | activity concurrency |
| `MAX_CONCURRENT_WORKFLOW_TASKS` | `50` | workflow-task concurrency |
| `LOG_LEVEL` | `INFO` | logging level |

Additional env read elsewhere: `OLYMPUS_PROFILE` / `OLYMPUS_PROFILES_DIR`
(profile bootstrap), `AGENT_RUNTIME_MODE` (`live`|`mock`, default `live`,
`agent_dispatch.py:472`), `DATABASE_*` (asyncpg), `GITHUB_TOKEN` / `GITHUB_REPO`
/ `GITHUB_BASE_URL` (git_operations).

### 1.3 Task queues

There is **one** task queue: `olympus-main`. All workflows and all activities
register on it. Child workflows are explicitly launched on the parent's queue
via `task_queue=workflow.info().task_queue` (`wave.py:107`). The
`BundleReaperWorkflow` cron and the Sustainment/Governance schedules all target
`olympus-main` (`bundle_reaper.py:20`).

### 1.4 `ALL_WORKFLOWS` — register all 18 (`worker.py:135-161`)

`PortfolioWorkflow`, `WaveWorkflow`, `AppWorkflow`, `DiscoveryWorkflow`,
`RationalizationWorkflow`, `WaveRationalizationWorkflow`,
`WaveArchitectureWorkflow`, `ArchitectureWorkflow`, `DataWorkflow`,
`ModernizationWorkflow`, `GenerateBCWorkflow`, `ValidationWorkflow`,
`DeploymentWorkflow`, `DispositionWorkflow`, `SustainmentWorkflow`,
`GovernanceWorkflow`, `SmokeTestAgentDispatchWorkflow`, `BundleReaperWorkflow`.

### 1.5 `ALL_ACTIVITIES` — register all ~50 (`worker.py:164-222`)

Grouped by module:

- **agent_dispatch:** `dispatch_agent_task`, `update_agent_task_output_ref`.
- **git_operations:** `read_artifact`, `write_artifact`, `write_artifacts_batch`,
  `create_pr`, `merge_pr`, `reconcile_and_merge_pr`, `provision_target_repo`.
- **disposition_outputs:** `emit_disposition_output_bundle`.
- **gate_operations:** `check_gate_criteria`, `create_gate_record`,
  `mark_gate_ready_for_review`, `set_gate_merge_blocked`, `submit_gate_evidence`,
  `update_application_status`, `wait_for_gate_decision`.
- **gate_pre_review:** `store_gate_pre_review`.
- **scoring:** `calculate_readiness_score`, `record_score_snapshot`,
  `persist_portfolio_score`.
- **line_transitions:** `start_next_line_workflow`,
  `update_application_line_projection`, `create_target_app_and_repo`,
  `fetch_application_source_repos`, `terminate_source_app_workflows`,
  `persist_decomposition_map`, `persist_discovery_side_effects`,
  `persist_capability_catalog`, `load_wave_rationalization_capabilities`,
  `persist_rationalization_capabilities`,
  `persist_rationalization_capability_dispositions`,
  `persist_rationalization_side_effects`, `persist_architecture_side_effects`,
  `realize_target_state_grain`, `persist_data_side_effects`,
  `persist_modernization_side_effects`,
  `persist_sustainment_sweep_side_effects`, `persist_validation_side_effects`,
  `persist_governance_sweep_side_effects`, `persist_deployment_side_effects`,
  `persist_disposition_side_effects`.
- **wave_operations:** `update_wave_status`,
  `update_wave_architecture_workflow_id`, `persist_wave_failure`.
- **classification:** `persist_classification`, `confirm_classification_tier_1`.
- **governance_operations:** `list_active_modernization_workflows`.
- **arch_data_registry:** `publish_arch_data_signal`, `consume_arch_data_signal`.
- **artifact_validation:** `validate_artifact_against_schema`.
- **context_priors:** `load_context_priors`.
- **bundle_activities:** `dispatch_delegated_bundle`, `expire_due_bundles_activity`.

> **Rebuild check.** If a workflow dispatches an activity by name string (e.g.
> `"AppWorkflow"`), it must appear in the matching list above or Temporal raises
> at task time. Adding an activity = add the import + add to `ALL_ACTIVITIES`.

---

## 2. Shared types (`temporal/olympus_workflows/types.py`)

This ~2790-line module is the single source of dataclasses, enums, signal
payloads, and concurrency limits shared between workflows and activities. All
types are plain `@dataclass` (Temporal-serializable) unless noted.

### 2.1 Enums

- `TaskStatus` — agent task result status (`COMPLETED`, `FAILED`, …); compared
  by `.value` because Temporal may deserialize a str-enum as a list of chars
  (see `generate_bc.py:167-171`).
- `WorkflowStatus` — `PENDING`, `RUNNING`, `COMPLETED`, `FAILED`, `CANCELLED`,
  `WAITING_FOR_SIGNAL`.
- `EscalationStatus` / `EscalationType` / `EscalationSeverity`,
  `ResolutionType` (`ABANDON` and resolvable outcomes — `generate_bc.py:252`),
  `OverrideType`, `ComplexityTier`.
- Re-exported from `olympus_contracts`: `AssemblyLine`, `Disposition`,
  `GateType`, `RiskTier`.

### 2.2 Concurrency limits (`types.py:131-135`)

```
MAX_CONCURRENT_WAVES   = 4
MAX_APPS_PER_WAVE      = 10
MAX_BC_CHILDREN_PER_APP= 12
MAX_RALPH_ITERATIONS   = 10
MAX_VALIDATION_STREAMS = 4
```

These cap fan-out: `WaveWorkflow` uses `asyncio.Semaphore(max_apps_per_wave)`
(`wave.py:83`), `ModernizationWorkflow` caps BC children at
`MAX_BC_CHILDREN_PER_APP` (`modernization.py:84`), and `GenerateBCWorkflow`'s
Ralph Loop runs `while self._iteration < MAX_RALPH_ITERATIONS`
(`generate_bc.py:96`).

### 2.3 Signal payloads

`GateApprovedSignal` (gate_id, approved_by, justification, card_decisions,
reviewer_notes), `GateRejectedSignal` (gate_id, rejected_by, reason,
card_decisions, reviewer_notes), `OverrideApprovedSignal`,
`EscalationResolvedSignal` (resolution, resolution_type),
`StakeholderApprovedSignal` (stakeholder, scope),
`RemoveAppFromWaveSignal` (app_id), `WavePatternsReadySignal`,
`DataReadyForTargetSignal`, `TargetProvisionedSignal`,
`DispositionExecutedSignal`, `ValidationApprovedSignal` (risk_tier,
validation_output_refs), `SustainmentSweepCompletedSignal`,
`GateMergeRetrySignal`, `PreDispatchConfirmedSignal`,
`BundleCompletedSignal` (bundle_id, outcome, outputs, validation_summary),
`BundleExpiredSignal` (bundle_id, reason).

### 2.4 Workflow inputs

`PortfolioWorkflowInput`, `WaveWorkflowInput` (wave_id, portfolio_id, app_ids,
max_apps_per_wave, artifact_repo), `AppWorkflowInput` (app_id, app_name,
wave_id, portfolio_id, artifact_repo), `LineWorkflowInput` (app_id,
artifact_repo, source_repo, portfolio_id, wave_id, prior_artifacts,
disposition, complexity_tier, risk_tier), `WaveRationalizationInput`,
`WaveArchitectureWorkflowInput` (wave_id, portfolio_id, artifact_repo, app_ids,
wave_name), `GenerateBCInput` (bc_name, app_id, design_artifacts, module_map,
source_repo, target_framework, target_frontend, primary_language),
`CronWorkflowInput` (portfolio_id, schedule_id, activities, triggered_at).

### 2.5 Activity I/O dataclasses

Every activity has matching `*Input`/`*Result` dataclasses (e.g.
`AgentTaskInput`/`AgentTaskResult`, `CreatePRInput`/`CreatePRResult`,
`CreateGateRecordInput`/`CreateGateRecordResult`, `CheckGateCriteriaInput`/
`Result`, `WriteArtifactsBatchInput`, `PersistDiscoverySideEffectsInput`,
`DispatchArchitecturePayload` v1 + `DispatchArchitecturePayloadV2`, etc.).
`StepExecutionContext` carries Layer B identity (portfolio_id, line_id,
step_id, wave_id, app_id, input_artifact_paths) into activities.

> **Rebuild rule.** Temporal serializes enum fields; defensively normalize any
> enum read from an activity result or signal — a str-enum may arrive as a list
> of characters. See `_normalize_disposition` (`rationalization.py:765-776`) and
> the `"".join(raw_status)` pattern (`generate_bc.py:167-171`).

---

## 3. Retry policies (`temporal/olympus_workflows/retry_policies.py`)

Named `temporalio.common.RetryPolicy` instances, plus a lookup dict
`RETRY_POLICIES` mapping string → policy. Workflows reference them as
`RETRY_POLICIES["agent_failure"]`, etc.

| Name (`RETRY_POLICIES` key) | initial | backoff | max interval | max attempts | non-retryable |
|---|---|---|---|---|---|
| `transient` (= `TRANSIENT_RETRY_POLICY` = HTTP) | — | — | — | — | — |
| `agent_failure` | 5s | 2.0 | 60s | 3 | — |
| `validation_failure` | — | — | — | **1** (no retry) | — |
| `timeout` | 30s | 2.0 | 60s | 2 | — |
| `infrastructure` | 5s | 2.0 | 300s | 10 | — |
| `git_merge` | 5s | 2.0 | 30s | 3 | `MergeConflict`, `MergeDivergenceUnresolved`, `MergeBranchProtectionRejected` |

(`temporal/retry_policies.py:1-117`.) Usage conventions seen across workflows:

- Agent dispatch → `agent_failure`, 1-hour `start_to_close_timeout`
  (`discovery.py:642-648`, `generate_bc.py:111-114`).
- Git writes / gate-record / persistence → `transient`, 30-120s timeouts
  (`discovery.py:366-369,462-473`).
- Schema validation → `validation_failure` (single attempt; fail loud)
  (`wave_architecture.py:393-401`).
- Gate-PR merge with conflict handling → `git_merge` inside the merge-blocked
  retry loop (see §5.1).

---

## 4. The workflow base class (`temporal/olympus_workflows/workflows/base.py`, ~1087 lines)

`LineWorkflowBase(HILSignalsMixin)` is the shared scaffold for the eight
per-line workflows (Discovery, Rationalization, Architecture, Data,
Modernization, Validation, Deployment, Disposition). `HILSignalsMixin` (from
`foundry_temporal.signals`) supplies base approve/cancel/feedback signals and
the `self.cancelled` flag.

### 4.1 Subclass configuration classvars

Each subclass sets: `ASSEMBLY_LINE` (an `AssemblyLine` enum), `ARTIFACT_ROOT`
(git path root, e.g. `"discovery"`), `LINE_LABEL`, `STATUS_PREFIX`, `STEPS`
(dict of step-id → `{skill_id, artifact, kind}`), `STEP_WEIGHTS` (progress
weights summing to 100), and optionally `SINGLE_GATE_KEY` (e.g.
`"G-DC"`). Examples: `discovery.py:174-180`, `rationalization.py:121-127`.

### 4.2 Inherited signal handlers — DO NOT redefine in subclasses

`gate_approved`, `gate_rejected`, `escalation_resolved`, `merge_retry`. These
buffer into `self._gate_decisions` / `self._pending_signals` and set
`self._merge_retry_signalled`. Redefining them in a subclass shadows the base
buffering and silently drops signals.

### 4.3 Inherited helpers (the core orchestration primitives)

- `_set_step(step_id, cumulative_progress)` — writes `self._current_step` and
  `self._progress_pct`; the step-id must exist in the line contract (validated
  at dispatch).
- `_update_app_status(app_id, status, step, line)` — calls
  `update_application_status` activity (transient retry, 30s).
- `_dispatch_agent(...)` — wraps `dispatch_agent_task` with `agent_failure`
  retry, 1-hour timeout, `activity_id=f"agent-{step}"`, the
  `context-priors-v1` patch, and `rework_feedback` forwarding from
  `self._rework_feedback[gate_key]`.
- `_commit_step_artifacts(...)` — `write_artifacts_batch` (transient, 120s),
  supports `mirror_repo`, applies `patch-output-artifact-ref-v1`.
- `_create_gate_pr(...)` / `_submit_gate_evidence(...)` — the latter builds slim
  vs. content-enriched evidence bundles depending on `GATE_THRESHOLDS`, and
  threads `forward_risk_tier`.
- `_run_gate_pre_review(...)` — dispatches the `gate-pre-review` skill (advisory,
  fault-tolerant), applies `mark-gate-ready-for-review-v1` patch.
- `_wait_for_gate_decision(gate_type)` — returns `"approved"` / `"rejected"` /
  `"cancelled"`; consumes buffered `self._gate_decisions`.
- `_reconcile_and_merge_with_retry_loop(...)` — see §5.1 (merge-blocked loop).
- `_rework_count(gate_key)` / `_bump_rework(gate_key)` — per-gate rework
  counters in `self._rework_iterations`.
- `get_status()` query — returns `WorkflowStatusResponse`.

`_now_iso()` (module function) returns `workflow.now().isoformat()` for
deterministic timestamps; every workflow imports it (`base.py`, mirrored in
`wave.py:254-256`).

---

## 5. Workflows (`temporal/olympus_workflows/workflows/`)

General invariants for every workflow:

- Decorated `@workflow.defn`; the entry method `@workflow.run`.
- Non-deterministic imports wrapped in
  `with workflow.unsafe.imports_passed_through():` (all activity + types
  imports). Pure-Python routers (no Temporal imports) may be imported at module
  top level (`discovery.py:93-96`).
- All in-flight behavior changes are gated behind `workflow.patched("<id>")` so
  replay of histories started before the change stays deterministic. Patch IDs
  seen: `discovery-data-steps-v1`, `discovery-capability-extraction-v1`,
  `discovery-batch-writes-v1`, `patch-output-artifact-ref-v1`,
  `gda-dual-signal-v1`, `arch-data-registry-v1`, `arch-data-signal-first-v1`,
  `arch-parallel-fanout-v1`, `data-parallel-fanout-v1`, `br-reconciliation-v1`,
  `context-priors-v1`, `mark-gate-ready-for-review-v1`.

### 5.0 Orchestration hierarchy

```
PortfolioWorkflow (stub)
  └─ WaveWorkflow (per wave, ≤MAX_APPS_PER_WAVE concurrent)
        └─ AppWorkflow (per app)
              └─ DiscoveryWorkflow (per app)        [stops here — see 5.4]

WaveRationalizationWorkflow (per wave, post-Discovery, manual start)
WaveArchitectureWorkflow    (per wave, post-G-DA)
        └─ ArchitectureWorkflow (per target, ABANDON)
        └─ DataWorkflow         (per target, ABANDON)
ModernizationWorkflow (per app)
        └─ GenerateBCWorkflow (per bounded context, ≤MAX_BC_CHILDREN_PER_APP)
ValidationWorkflow → DeploymentWorkflow   (signal handoff)
DispositionWorkflow (non-modernization 7Rs) → DeploymentWorkflow
SustainmentWorkflow / GovernanceWorkflow  (cron, continuous)
BundleReaperWorkflow                       (cron, 15 min)
```

### 5.1 The merge-blocked retry loop (shared gate-merge pattern)

`_reconcile_and_merge_with_retry_loop(repo, pr_number, gate_id, merge_method)`:
calls `reconcile_and_merge_pr` under `git_merge` retry; on a non-retryable merge
error (`MergeConflict` / `MergeDivergenceUnresolved` /
`MergeBranchProtectionRejected`) it transitions the gate to `merge_blocked` via
`set_gate_merge_blocked`, then `await workflow.wait_condition(...)` until the
reviewer fires `merge_retry` (W17 / P5-S17.4). Called by Discovery
(`discovery.py:546-551`), Rationalization (`rationalization.py:292-297,571-576`),
and the W19 line workflows.

### 5.2 PortfolioWorkflow (`workflows/portfolio.py`, 79 lines) — STUB

All methods raise `NotImplementedError`. Signals/queries are declared so the
class registers, but no body exists. Rebuild as a stub that registers cleanly.

### 5.3 WaveWorkflow (`workflows/wave.py`, 256 lines)

- Input `WaveWorkflowInput`. Sets status RUNNING, seeds `_app_statuses` PENDING
  per app (`wave.py:79-80`).
- Fan-out: `asyncio.Semaphore(input.max_apps_per_wave)` (`wave.py:83`); per app
  runs `run_one_app` which executes a child `"AppWorkflow"` with
  `id=f"app-{app_id}-wave-{wave_id}"`, `task_queue=workflow.info().task_queue`
  (`wave.py:103-108`). **Failure isolation:** a child failure marks that app
  FAILED but does not abort the wave (`wave.py:113-120`); all tasks gathered
  with `return_exceptions=True` (`wave.py:124`).
- Signals: `gate_approved`, `gate_rejected` (buffer into `_pending_gate_signals`),
  `remove_app` (adds to `_removed_apps`, marks CANCELLED, cancels the child via
  `get_external_workflow_handle(...).cancel()` — `wave.py:179-186`),
  `override_approved`, `escalation_resolved`, `stakeholder_approved`,
  `wave_patterns_ready`.
- Queries: `get_status` (aggregate counts), `get_app_status(app_id)`.
- Returns `"completed"`.

### 5.4 AppWorkflow (`workflows/application.py`, 211 lines)

Runs **only** the `DiscoveryWorkflow` child (`id=f"discovery-{app_id}"`) and
stops. Rationalization is intentionally NOT chained here — it is wave-scoped and
started separately (`discovery.py:558-566` documents why). Same signal set as
WaveWorkflow; `get_status` query.

### 5.5 DiscoveryWorkflow (`workflows/discovery.py`, 1352 lines)

- Config: `ASSEMBLY_LINE=DISCOVERY`, `ARTIFACT_ROOT="discovery"`,
  `SINGLE_GATE_KEY="G-DC"` (`discovery.py:174-180`).
- `DISCOVERY_PASSES` and `STEP_WEIGHTS` are **built at import** from the
  authoritative contract via `olympus_contracts.get_line("Discovery")` /
  `step_weights("Discovery")` (`discovery.py:107-153`). A contract rename
  without a matching code edit raises `KeyError` at startup.
- Flow (`discovery.py:239-589`): Step 1 Catalog → Step 2 Structural Analysis
  (Pass 1: generic `legacy-architecture-mapper` + optional tech-stack specialist
  from `discovery_patterns_router`, run in parallel via `asyncio.gather`) →
  Steps 3a-3c parallel passes (business-logic-extraction, quality-risk,
  ux-accessibility; under `discovery-data-steps-v1` also data-domain-discovery +
  shared-database-analysis; under `discovery-capability-extraction-v1` also
  capability-extraction) → Step 4 Synthesis + TCO (parallel) → Step 5 commit
  artifacts (batched under `discovery-batch-writes-v1`, one
  `write_artifacts_batch` per pass to stay under the 2 MB activity-input cap) →
  best-effort projections (`persist_decomposition_map`,
  `persist_discovery_side_effects`, `persist_capability_catalog`) → Step 6
  create PR + `create_gate_record(G-DC)` → Step 7 submit evidence
  (`forward_risk_tier=False`) → gate-readiness-check → Step 8
  `_wait_for_gate_decision(G_DC)`.
- On `approved`: merge via the merge-blocked loop, score + snapshot, status
  `discovery_complete`, return `"completed"`. On `rejected`: `_bump_rework`,
  fail after `MAX_REWORK_ITERATIONS=3` (`discovery.py:155-156,574-582`),
  else re-run parallel passes with feedback and loop.
- Extra signal: `reclassify_complexity(new_tier)` (`discovery.py:595-606`).
- Gate: **G-DC**.

### 5.6 RationalizationWorkflow (`workflows/rationalization.py`, 788 lines)

- Config: `ASSEMBLY_LINE=RATIONALIZATION`. `STEP_WEIGHTS` hand-mapped
  (`rationalization.py:88-96`). Two gates: **G-RR**, **G-DA**.
- `_rework_gate_key_for_step`: `redundancy-analysis → G-RR`, everything else →
  `G-DA` (`rationalization.py:133-135`).
- Flow: redundancy-analysis (`redundancy-analyzer`) → commit → **G-RR loop**
  (PR + gate record + evidence + pre-review + wait; approve → merge, reject →
  rework ≤3) → disposition-recommendation → disposition-governance (silent
  sub-phase, same UI step) → user-impact (Retire/Replace only,
  `_is_retire_or_replace`) → classification (`classify-application` →
  `persist_classification`; if `tier_1_flag`, pause for
  `StakeholderApprovedSignal(scope="tier-1-classification")` then
  `confirm_classification_tier_1`) → **G-DA loop**.
- **G-DA dual-signal** (`gda-dual-signal-v1`): approval requires BOTH the PM
  `gate_approved` (PR merge) AND a `StakeholderApprovedSignal` with non-tier-1
  scope (`rationalization.py:549-577`). The stakeholder flag is consumed each
  cycle so a rework requires a fresh sign-off.
- Extra signal `stakeholder_approved` routes by `scope`
  (`rationalization.py:670-692`).

### 5.7 WaveRationalizationWorkflow (`workflows/wave_rationalization.py`, ~5969 lines)

Wave-scoped replacement for per-app Rationalization (P3.5-R2). Produces ONE
cross-portfolio redundancy matrix; disposition/governance/impact/classification
fan out per app under the one workflow (`wave_rationalization.py:1-29`). Flow:
(1) cross-portfolio redundancy pass (one dispatch → `redundancy-matrix.json` +
`ux-overlap-matrix.json` + `consolidation-report.md`); (2) per-app intra-app
redundancy; (3) **G-RR** (wave-level); (4) per-app disposition + governance
fan-out; (5) per-app user-impact (Retire/Replace); (6) per-app classification
with Tier-1 pause; (7) **G-DA** (wave-level, dual-signal). Signals
`gate_approved`/`gate_rejected` carry a `gate_id` whose prefix disambiguates
G-RR vs G-DA; `stakeholder_approved` uses `scope`. On clearing G-DA it provisions
targets (`create_target_app_and_repo`) and may start `WaveArchitectureWorkflow`
(`update_wave_architecture_workflow_id`). Helpers `_normalize_relationship`
(`:138-155`) and `_legacy_disposition_from_relationship` (`:158-172`) project
the lowercase plan relationship vocabulary onto the Title-cased 7R disposition
the legacy v1 dispatch path expects.

### 5.8 WaveArchitectureWorkflow (`workflows/wave_architecture.py`, 888 lines)

Runs once per wave after WaveRationalization clears G-DA. **No gates, no patch
gates** (brand-new workflow). Flow (`wave_architecture.py:246-323`):

1. `_dispatch_wave_target_state_mapper` — single `target-state-mapper` dispatch
   (`model_preference="tier-2"`, `app_id=""` + `wave_id=<uuid>` to satisfy the
   exactly-one-scope DB check), strict schema-validates the emitted
   `architecture-target-plan.json` (`validation_failure` retry → raise
   `ApplicationError(non_retryable=True)` on drift), commits the plan to artifact
   repo `main` (`wave_architecture.py:329-431`).
2. `_await_pre_dispatch_confirmation` — flips wave status to
   `awaiting-architecture-dispatch`, waits for `pre_dispatch_confirmed` or
   `cancel_all_children_requested` (`:437-447`).
3. `_provision_and_spawn` — re-reads the (possibly operator-edited) plan from git
   (git is source of truth), provisions every target in parallel
   (`create_target_app_and_repo`, per-target failure isolated into
   `_dispatch_status`), then spawns `ArchitectureWorkflow` + `DataWorkflow` per
   provisioned target with `ParentClosePolicy.ABANDON` so children outlive the
   coordinator (`:453-552`).
4. Outcomes: `"completed"` (children spawned), `"failed"`,
   `"stuck-awaiting-recovery"` (every target failed — operator `/resume`),
   `"cancelled"`.

Plan path: `architecture/wave-{wave_id}/architecture-target-plan.json`
(`:159-160`). `relationship → disposition` Title-cased via
`_disposition_from_relationship` (`:182-195`, raises non-retryable on unknown).

### 5.9 ArchitectureWorkflow (`workflows/architecture.py`, 2191 lines)

Per-target 16-step shape (`architecture.py:20-37`): target-state-mapping →
(cloud-pattern-selection ∥ ea-compliance) → (integration-arch ∥
data-architecture[signal-wait]) → (security-arch ∥ design-system ∥
accessibility-review ∥ ai-ml-integration) → blueprint-assembly → commit →
create-G-02-PR → ai-pre-review → gate-review-02 → persist-architecture-side-
effects → merge. Additional fan-out gated by `arch-parallel-fanout-v1`. **Gate:
G-02.** Tier-1 = triple signal: PM `gate_approved` AND
`StakeholderApprovedSignal(scope="g-02-ea")` AND
`...(scope="g-02-security")` (`architecture.py:44-48`). **Arch↔Data handshake**
(`arch-data-registry-v1`): publishes `TargetProvisionedSignal` at step 1 and
polls the `arch_data_signal_registry` for `DataReadyForTargetSignal` at step 5,
24h timeout, DB-backstop poll cadence under `arch-data-signal-first-v1`
(`architecture.py:128-145`). Blueprint skill chosen by
`architecture_patterns_router.select_architecture_blueprint_skill(disposition)`;
Retire/Retain → `None` (skip step).

### 5.10 DataWorkflow (`workflows/data.py`, 1673 lines)

Per-target 12-step shape (`data.py:19-34`): wait-for-target-provisioned (signal)
→ (domain-discovery ∥ shared-db-analysis) → decomposition-strategy →
(migration-planning ∥ data-product-design) → data-synthesis → commit →
create-G-DT-PR → ai-pre-review → gate-review-dt → persist-data-side-effects →
merge. Fan-out gated by `data-parallel-fanout-v1`. **Gate: G-DT.** Tier-1 triple
signal: PM AND `scope="g-dt-data-governance"` AND `scope="g-dt-security"`.
Captures `architecture_workflow_id` from the provisioned signal so its terminal
`DataReadyForTargetSignal` routes back. Step-5 skill from
`data_router.select_data_product_skill(fingerprint)`.

### 5.11 ModernizationWorkflow (`workflows/modernization.py`, 2527 lines)

Per-app 3-step factory Extract → Design → Generate
(`modernization.py:1-22`). **Three gates: G-04a, G-04b, G-04c**, per-gate rework
counters in `self._rework_iterations`. Extract skill chosen by source language
(`LANGUAGE_SKILL_MAP` — cobol/java/coldfusion/python/default,
`modernization.py:111-117`), cross-validation, then optional reconciliation
steps under `br-reconciliation-v1` (`modernization.py:173-188`). Generate fans
out one `GenerateBCWorkflow` child per bounded context (read from committed
`module-map.yaml`), capped at `MAX_BC_CHILDREN_PER_APP=12`, then synthesizes BC
results + adversarial review. Code-gen skill per BC chosen by
`code_generation_router.select_code_generation_skill(...)`. Refactor and
Rearchitect dispositions flow through this workflow (NOT DispositionWorkflow).

### 5.12 GenerateBCWorkflow (`workflows/generate_bc.py`, 313 lines)

Child of Modernization, one per bounded context. **Ralph Loop**
(`generate_bc.py:96-190`): while `iteration < MAX_RALPH_ITERATIONS` (10): (1)
`tdd-generation` → (2) code-generation (variant via
`select_code_generation_skill`) → (3) `test-validation`. All tests passing →
return `GenerateBCResult(status="completed")`. Each dispatch:
`agent_failure` retry, distinct `activity_id` per iteration. On exhaustion →
`_handle_escalation`: dispatch `escalation-handler`, set
`WAITING_FOR_SIGNAL`, `await workflow.wait_condition(escalation_resolved or
cancelled)`. Resolution outcomes: `ABANDON` → status `"abandoned"` (terminal,
parent marks line failed); others → `"escalated"`; cancel → `"cancelled"`
(`generate_bc.py:241-264`). Signals: `escalation_resolved` (carries
`resolution_type`), `gate_approved`, `gate_rejected`, `wave_patterns_ready`.

### 5.13 ValidationWorkflow (`workflows/validation.py`, 1077 lines)

Per-app 18-step shape (`validation.py:1-55`). Three always-on parallel streams
(functional-parity, security-compliance, accessibility-ux) fan out after intake;
gates run serially. **Gates G-V1 / G-V2 / G-V3.** G-V1 is automated pass/fail
(PM merge is acknowledgement; auto-reject when parity < threshold routes back to
Modernization rework). Tier-1 triple signal on G-V2
(`scope="g-v2-compliance"` + `g-v2-security`) and G-V3
(`scope="g-v3-safety"` + `g-v3-cert`); steps 12-16 (safety-assurance + G-V3)
skipped for Tier-2/3. Terminal step fires `ValidationApprovedSignal` to
Deployment with `risk_tier` + `validation_output_refs`. `VALIDATION_STEPS` dict
(`validation.py:103-`) declares per-step skills/artifacts/kind.

### 5.14 DeploymentWorkflow (`workflows/deployment.py`, 1290 lines)

Per-app 18-step shape (`deployment.py:1-68`). Runs after Validation
(modernization path) or after Disposition (non-modernization path). **Entry
signals consumed at start via `wait_condition`:** `ValidationApprovedSignal`
(modernization) or `DispositionExecutedSignal` (non-modernization); if the input
already carries a `disposition` it is used directly. Per-disposition step
branching (Retire skips 2-10; others run all 18). **Gates G-DP-1 (Cutover Go),
G-DP-2 (Deployment Complete).** Tier-2/3 = PM + Ops Lead dual; Tier-1 = +Safety
Board (G-DP-1) / +Certifying Authority (G-DP-2) triple. Parallel-run duration is
risk-tier driven (14/30/90 days defaults from profile registry); under
time-skipping tests the timer collapses. Rework ≤3: G-DP-1 reject → rerun
adoption-verification; G-DP-2 reject → rerun legacy-decommission +
cost-certification. Terminal step + Sustainment handoff.

### 5.15 DispositionWorkflow (`workflows/disposition.py`, 1604 lines)

Per-app, runs in parallel with the Modernization→Validation→Deployment pipeline,
for the **non-modernization** dispositions only (Retire, Retain, Replace,
Replatform, Consolidate). Refactor/Rearchitect are **rejected** here
(`disposition.py:5-7`). Per-disposition step sequences spelled out in the
docstring (`disposition.py:15-66`). **Gates: G-DE-1** (plan approval, stakeholder
+ PM) and, for dispositions with a decommission phase, **G-DE-2** (decommission
readiness, ops lead + security). Retain uses only G-DE-1. Uses the
`DISPOSITION_REGISTRY` (extension point #2) for `StepSpec` sequences
(`disposition.py:102-107`). Emits `emit_disposition_output_bundle` +
`DispositionExecutedSignal` to Deployment.

### 5.16 GovernanceWorkflow (`workflows/governance.py`, 798 lines)

Continuous, portfolio-wide, cron-driven via Temporal Schedules (`gov-weekly-*`
vs `gov-quarterly-*`). One class serves both cadences; `run()` inspects
`CronWorkflowInput.schedule_id` to choose the activity set. 10 canonical steps
(`governance.py:22-36`); steps 2-7 (drift-detection, pattern-extraction,
health-report, skill-evolution, factory-capacity, +model-evaluation quarterly)
fan out via `asyncio.gather`. `GOVERNANCE_ACTIVITIES` maps step→skill→artifact
(`governance.py:82-107`); writes under
`governance/{portfolio_id}/{schedule_id}/{activity}.json`. Emits
`wave_patterns_ready` to Modernization Generate after pattern extraction.
Persists via `persist_governance_sweep_side_effects`.

### 5.17 SustainmentWorkflow (`workflows/sustainment.py`, 664 lines)

Continuous cron workflow. 8 canonical steps (`sustainment.py:1-43`); activities
2-6 (cve-triage, incident-response, sla-monitoring, change-conflict-detection,
cost-anomaly-detection) run concurrently via `asyncio.gather` emitting a
`per_activity_parallel` FanoutBlock. Cadence selection at intake
(`sus-daily-*` → 2 activities; `sus-weekly-*` → all 5; `sus-adhoc-*` → verbatim
from `CronWorkflowInput.activities`; default → all 5). No per-app state; emits a
portfolio-wide sweep summary + `SustainmentSweepCompletedSignal`. Consumes
`override_approved` when a finding needs modernization-line coordination.
`SUSTAINMENT_ACTIVITIES` map at `sustainment.py:86-107`.

### 5.18 BundleReaperWorkflow (`workflows/bundle_reaper.py`, 118 lines)

Tiny one-shot cron (15-minute cadence via Temporal Schedules, NOT a decorator).
`run()` calls `expire_due_bundles_activity` once (transient retry, 2-min
timeout), then for each returned `{bundle_id, workflow_id}` with a non-empty
workflow_id fires `BundleExpiredSignal(reason="expired")` to that workflow via
`get_external_workflow_handle(...).signal(...)`. Returns
`{"expired": n, "signalled": m}` (`bundle_reaper.py:64-118`). No signal handlers,
no inter-run state.

### 5.19 SmokeTestAgentDispatchWorkflow (`workflows/smoke_test.py`, 92 lines)

Operator-only single-activity live smoke test (started by
`temporal/scripts/smoke_test_agent.py`). Builds `AgentTaskInput` from a dict
payload, dispatches `dispatch_agent_task` (2h `start_to_close_timeout`, 5-min
heartbeat), returns a JSON-serializable summary. NOT part of any line.

### 5.20 BundleAwareMixin (`workflows/bundle_helpers.py`, 190 lines)

Opt-in mixin (Phase 5 W20) for delegated bundles. Provides `bundle_completed` /
`bundle_expired` signal handlers, `await_bundle_completion(bundle_id,
timeout_seconds)` → one of `accepted`/`rejected`/`expired`/`released`/`timeout`,
and `get_bundle_outcome` / `get_bundle_outputs` queries. State:
`_bundle_outcomes`, `_bundle_outputs`, `_bundle_validation_summaries`. Purely
additive — no existing workflow consumes it yet.

### 5.21 Routers (pure Python, below the workflow boundary)

All four are pure-Python (no Temporal imports) so unit tests call them directly:

- `discovery_patterns_router.select_discovery_patterns_skill(fingerprint,
  has_source_available)` — resolution: no-source → `discovery-patterns-doc-only`;
  mainframe token → `-mainframe`; oracle/plsql → `-oracle`; sqlserver/mssql/tsql
  → `-sqlserver`; C#/.NET → `-dotnet`; else base `discovery-patterns`
  (`discovery_patterns_router.py:204-295`). Substring-aware probing
  (`DATABASE_TOKEN_MATCHERS`, `LANGUAGE_TOKEN_MATCHERS`) handles vendor-blob
  strings.
- `code_generation_router.select_code_generation_skill(target_framework,
  target_frontend, primary_language)` — (lang, framework) pair map first (e.g.
  `(cobol,springboot) → code-generation-cobol-to-java`), then frontend, then
  framework, else `code-generation` (`code_generation_router.py:60-92`).
- `architecture_patterns_router.select_architecture_blueprint_skill(disposition)`
  — refactor/replatform/rearchitect → variant; replace/consolidate →
  `-rearchitect`; retire/retain → `None` (skip step); unknown/empty → base
  (`architecture_patterns_router.py:76-106`).
- `data_router.select_data_product_skill(fingerprint)` — mainframe → `-mainframe`;
  oracle/sqlserver/postgres families → variant; else `data-product-specification`
  (`data_router.py:141-183`).

---

## 6. Activities (`temporal/olympus_workflows/activities/`)

All activities are decorated `@foundry_activity(config=ActivityConfig(
enable_observability=True))` (from `foundry_temporal.activities`) which supplies
observability, logging, and error wrapping. Timeouts are set per
`execute_activity` call by the workflow (see `config/activities.yaml` for the
declarative defaults). Errors use `foundry_temporal.errors`
(`RetryableError`, `NonRetryableError`); the worker's retry policy decides
retry vs. fail.

### 6.1 agent_dispatch.py (623 lines)

- `dispatch_agent_task(AgentTaskInput) -> AgentTaskResult`
  (`agent_dispatch.py:382-433`): spawns a 30s heartbeat loop
  (`_heartbeat_loop`) for the dispatch lifetime so the workflow relies on
  `heartbeat_timeout` to detect hangs; cancels it on every exit path. Inner body
  (`_dispatch_agent_task_inner`, `:436-`): inserts an `agent_task` DB row
  (`_insert_agent_task_row`), emits a Layer B `RUNNING` step_execution record
  (`_emit_agent_start`), resolves the agent card via `OlympusAgentRegistry`,
  dispatches. **Routing:** `AGENT_RUNTIME_MODE=mock` → `dispatch_via_mock`
  (tests only, DECISION-018); else olympus-api's `dispatch_via_a2a`, falling
  back to the bundled client (`agent_dispatch.py:472-483`). A `FAILED` result is
  propagated so Temporal retries (`agent_failure` policy). Updates the DB row +
  emits terminal `_emit_agent_complete`.
- `update_agent_task_output_ref(app_id, task_type, artifact_path)` — patches the
  persisted output ref (`:285`).

### 6.2 git_operations.py (600 lines)

Reads `GITHUB_TOKEN` / `GITHUB_REPO` / `GITHUB_BASE_URL`
(`git_operations.py:10-14`). Uses `olympus_contracts.GitServiceConfig`. Each
activity emits Layer B git step records (`_emit_git_start`/`_emit_git_complete`).
Activities: `read_artifact` (`:169`), `write_artifact` (`:218`),
`write_artifacts_batch` (`:269` — one tree+commit for N files), `create_pr`
(`:324`), `merge_pr` (`:378`), `reconcile_and_merge_pr` (`:425` — rebases/merges
main and re-merges; raises `MergeConflict`/`MergeDivergenceUnresolved`/
`MergeBranchProtectionRejected` which are the `git_merge` non-retryables),
`provision_target_repo` (`:544`).

### 6.3 gate_operations.py (1358 lines)

`GATE_REQUIRED_ARTIFACTS` maps each gate type → required artifact suffixes
(`gate_operations.py:51-`): G-DC, G-RR, G-DA, G-02, G-DT, G-04a/b/c, G-DE-1/2
omitted (per-disposition variation). Activities: `check_gate_criteria`
(`:770` — evaluates thresholds with `_resolve_threshold` /
`_find_file_artifact` / `_get_json_path` / `_evaluate_threshold`, risk-tier
aware), `submit_gate_evidence` (`:936`), `wait_for_gate_decision` (`:996` —
long-poll, 172800s/48h timeout from `activities.yaml`), `create_gate_record`
(`:1045`), `set_gate_merge_blocked` (`:1120`), `mark_gate_ready_for_review`
(`:1169`), `update_application_status` (`:1196`),
`fetch_gate_capability_lineage_rework` (`:1233`).

### 6.4 line_transitions.py (8217 lines — the projection + provisioning engine)

The largest module. Two responsibilities: (a) **Layer B "side-effect"
projections** — parse line artifacts and UPSERT the derived columns/rows onto
the Postgres query layer; (b) **target provisioning + cross-line transitions**.
Activities (top-level `async def`):

- Transitions: `start_next_line_workflow` (`:106`),
  `update_application_line_projection` (`:6265`),
  `create_target_app_and_repo` (`:7537` — mints the target app row + GitHub repo,
  Title-cased disposition; `_TARGET_EQUALS_SOURCE_DISPOSITIONS` vs
  `_NEW_TARGET_DISPOSITIONS`), `fetch_application_source_repos` (`:220`),
  `terminate_source_app_workflows` (`:8169`).
- Discovery: `persist_decomposition_map` (`:408`),
  `persist_discovery_side_effects` (`:1148`), `persist_capability_catalog`
  (`:1300`).
- Rationalization: `load_wave_rationalization_capabilities` (`:1768`),
  `persist_rationalization_capabilities` (`:1934`),
  `persist_rationalization_capability_dispositions` (`:2489`),
  `persist_rationalization_side_effects` (`:2862`).
- Architecture/Data: `persist_architecture_side_effects` (`:3138`),
  `realize_target_state_grain` (`:6853` — capability/system lineage UPSERTs),
  `persist_data_side_effects` (`:3493`).
- Modernization/Validation: `persist_modernization_side_effects` (`:3855`),
  `persist_validation_side_effects` (`:4244`).
- Sustainment/Governance/Deployment/Disposition:
  `persist_sustainment_sweep_side_effects` (`:4747`),
  `persist_governance_sweep_side_effects` (`:5362`),
  `persist_deployment_side_effects` (`:5852`),
  `persist_disposition_side_effects` (`:6127`).

All projections are best-effort from the workflow's perspective (callers wrap in
try/except and continue — e.g. `discovery.py:355-444`). Some validate against
JSON schemas before writing (consolidation-plan, disposition-recommendation,
rat-cap clustering-plan).

### 6.5 Remaining activity modules

- **scoring.py** (449): `calculate_readiness_score` (`:137`),
  `record_score_snapshot` (`:197`), `persist_portfolio_score` (`:361`).
- **classification.py** (210): `persist_classification` (`:70`, returns
  `tier_1_flag`), `confirm_classification_tier_1` (`:175`, flips source
  auto→confirmed).
- **wave_operations.py** (309): `persist_wave_failure` (`:49`),
  `update_wave_status` (`:131`), `update_wave_architecture_workflow_id` (`:237`).
- **governance_operations.py** (117): `list_active_modernization_workflows`
  (`:52` — queries Temporal for live workflow ids).
- **arch_data_registry.py** (214): `publish_arch_data_signal` (`:83`),
  `consume_arch_data_signal` (`:138`); constants `SIGNAL_TARGET_PROVISIONED`,
  `SIGNAL_DATA_READY_FOR_TARGET`; `_require_known_signal_type` guards.
- **artifact_validation.py** (432): `validate_artifact_against_schema` (`:380`)
  — loads schema from the schemas dir (`_resolve_schemas_dir`), returns
  `validated`, `errors`, `parsed_payload`.
- **context_priors.py** (165): `load_context_priors` (`:108`) — reads the active
  profile's prior-artifact manifest.
- **gate_pre_review.py** (220): `store_gate_pre_review` (`:145`) — parses the
  pre-review markdown into structured findings.
- **traceability.py** (94): `index_artifact_citations` (`:57`),
  `validate_gate_traceability` (`:77`). *(Not in `ALL_ACTIVITIES` — supporting
  helpers.)*
- **disposition_outputs.py** (578): `emit_disposition_output_bundle` (`:539` —
  validates the bundle against
  `schemas/dispositions/disposition-output.schema.json` at emission); the
  per-disposition payload builders (`_retire_payload`, `_retain_payload`, …) and
  the `bundle_pre_gate_evidence` / `bundle_post_gate_evidence` pure helpers.
- **bundle_activities.py** (408): `dispatch_delegated_bundle` (`:244` — wraps
  olympus-api's bundle service over an `AsyncSession`),
  `expire_due_bundles_activity` (`:345` — reaper sweep). Reads
  `fallback_policy` from the active profile.

### 6.6 Layer B execution records (`utils/execution.py`, 374 lines)

`StepKind` enum (`agent`, `git`, `gate`, `code`, `terminal`), `ExecutionStatus`
enum. `emit_execution_record(EmitExecutionRecordInput)` INSERTs a row into the
`step_execution` table via asyncpg (best-effort — returns `None` on failure so a
DB outage never fails a workflow). `update_execution_record` UPDATEs with a
computed `duration_ms` and a merged JSONB payload. `emit_code_step_start` /
`emit_code_step_complete` for code-kind steps. `resolve_input_artifacts(paths,
repo, ref)` builds `StepArtifactRef`s. `_db_url()` from `DATABASE_*` env.

### 6.7 Target-plan helpers (`utils/target_plan.py`, 247 lines)

Pure Python. `slugify_target_name(name)` → kebab-case repo slug suffix
(`:22-51`; empty → caller must fall back to `olympus-target-{id[:8]}`).
`derive_target_application_map_from_plan(plan, target_app_id,
target_portfolio_id)` projects one wave-plan `targets[]` entry to the legacy
`target-application-map.json` (`:101-187`): maps lowercase `relationship` →
Title-case `disposition` (`_RELATIONSHIP_TO_DISPOSITION`), adds `-of` suffix for
retain-class relationships, infers source roles
(sole-source/anchor/peer), `provisioned_new_row=True` for replace/consolidate.
`synthesize_target_application_map(...)` builds the same shape with no wave plan
(`:190-240`).

---

## 7. The 6 Extension Points (`temporal/olympus_workflows/registries/`)

All six are backed by a generic `Registry[T]` engine and exposed as
module-level singletons. They are populated from `registries/defaults/*.yaml`
(and from `olympus_contracts` for the contract-derived ones) at **import time**,
then optionally overridden by a profile at worker bootstrap. **They must never
be mutated mid-workflow** (Temporal determinism).

### 7.0 The engine (`registries/engine.py`, 453 lines)

`Registry[T]` is generic over the entity type with `id_getter`, `dep_getter`,
`validators`, `case_sensitive`. CRUD: `register`, `upsert`, `get`, `has`,
`list_all`, `ids`, `labels`, `delete`, `clear`. Versioning: `VersionRecord`,
`version`, `version_history`, `bump_version`, `parse_semver`, `bump_semver`.
Dependencies: `dependencies`, `dependents`, `_assert_no_cycle` (DFS cycle
detection). Errors: `RegistryError`, `EntityExists`,
`EntityNotFound(KeyError)`, `EntityHasDependents`, `RegistryValidationError`,
`CircularDependencyError`.

### 7.1 Extension #1 — Assembly Line Registry (`assembly_line.py`, 187 lines)

`AssemblyLine` frozen dataclass: `name`, `description`, `steps`, `gates`,
`depends_on`, `inputs`, `outputs`, `mode`, `metadata`. Modes: `per-app`,
`per-wave`, `per-target-app`, `continuous`. Defaults loaded from
`olympus_contracts` via `_load_default_lines_from_contract()`. Singleton
`ASSEMBLY_LINE_REGISTRY`.

### 7.2 Extension #2 — Disposition Strategy Registry (`disposition.py`, 491 lines)

`StepSpec` + `DispositionStrategy` (`label`, `pre_gate1_steps`,
`post_gate1_steps`, `has_gate2`, `max_rework_iterations=3`, `workflow`,
`required_gates`). 5 defaults: `_RETIRE`, `_RETAIN`, `_REPLACE`, `_REPLATFORM`,
`_CONSOLIDATE` (Refactor/Rearchitect deliberately absent — they route through
`ModernizationWorkflow`). Singleton `DISPOSITION_REGISTRY`,
`UnknownDispositionError`. Consumed by `DispositionWorkflow`.

### 7.3 Extension #3 — Analysis Pass Registry (`analysis_pass.py`, 171 lines)

`AnalysisPass` (`name`, `skill_id`, `artifact`, `depends_on`, `pass_number`,
`synthesis_rule`, `parallel_with`). Defaults from the Discovery contract.
Singleton `ANALYSIS_PASS_REGISTRY`.

### 7.4 Extension #4 — Scoring Dimension Registry (`scoring_dimension.py`, 205 lines)

`ScoringDimensionEntry` (`name`, `weight`, `default_weight`, `bounds`). Weights
**must sum to 1.0** (`validate_weights`). 6 defaults
(`registries/defaults/scoring-dimensions.yaml`): code-quality 0.20,
test-coverage 0.15, security-posture 0.20, documentation 0.10,
dependency-currency 0.15, architecture-clarity 0.20. Singleton
`SCORING_DIMENSION_REGISTRY`.

### 7.5 Extension #5 — Gate Provider Interface (`gate_provider.py`, 407 lines)

`GateProviderAdapter` Protocol (`initiate`, `poll`, `close`) +
`GateApprovalRequest` / `GateApprovalStatus`. Adapters: `GitHubPRGateProvider`
(default, id `github-pr`), `AutomatedOnlyGateProvider` (`automated-only`),
`ServiceNowGateProvider` (stub, `NotImplementedError`), `JIRAGateProvider`
(stub). `GateProvider` record (`id`, `supports_automated`, `requires_human`,
`implemented`). Per-gate overrides + a default provider. Singleton
`GATE_PROVIDER_REGISTRY` (default `github-pr`). Defaults in
`registries/defaults/gate-providers.yaml` (4 providers).

### 7.6 Extension #6 — Skill Composition Model (`skill_composition.py`, 194 lines)

`SkillComposition` (`name`, `skills`, `mode` ∈ {sequential, parallel,
conditional}, `conditions`, `variant_selectors`). `make_skill_presence_validator`
factory. **Empty by default** (`registries/defaults/skill-compositions.yaml` is a
schema-reference comment only). Singleton `SKILL_COMPOSITION_REGISTRY`.

### 7.7 Profile overrides + bootstrap

- `profile_overrides.py` (309 lines): `apply_profile(profile, bundle)`,
  `RegistryBundle`, `default_registries()`, `reset_registries_to_defaults()`,
  `_apply_scoring` / `_apply_gates` / `_apply_skill_composition`. Profile shapes
  are duck-typed via Protocols.
- `worker_bootstrap.py` (198 lines): `bootstrap_profile_from_env()` reads
  `OLYMPUS_PROFILE` / `OLYMPUS_PROFILES_DIR`, `load_profile_stub` parses
  `profile.yaml` / `scoring.yaml` / `gates.yaml`, then calls `apply_profile`.
  Raises `ProfileBootstrapError` on failure. **Called first in `run_worker()`**
  (`worker.py:242`).

---

## 8. Config (`temporal/config/`)

Three declarative YAML files following the foundry-temporal worker-starter
pattern. They mirror the code-side `ALL_WORKFLOWS` / `ALL_ACTIVITIES` registers
and supply default per-activity timeouts.

- `services.yaml` — service registration.
- `workflows.yaml` — declarative workflow registration.
- `activities.yaml` — declarative activity registration with `timeout_seconds`:
  `dispatch_agent_task=1800`, `read_artifact=60`, `write_artifact=120`,
  `create_pr=120`, `check_gate_criteria=300`, `submit_gate_evidence=120`,
  `wait_for_gate_decision=172800` (48h), `calculate_readiness_score=300`,
  `record_score_snapshot=60`.

> These declarative timeouts are the canonical defaults; workflows may pass an
> explicit `start_to_close_timeout` per call which overrides them.

---

## 9. Testing

### 9.1 Command + coverage floor

From `pyproject.toml` (`temporal/pyproject.toml:51-115`):

- `asyncio_mode = "auto"`, `testpaths = ["tests"]`.
- `addopts = "--cov=olympus_workflows --cov-report=term-missing
  --cov-report=html:htmlcov --cov-fail-under=78"`.
- Coverage `source = ["olympus_workflows"]`, omitting `__init__.py` files;
  `exclude_lines` = `pragma: no cover`, `if __name__ == .__main__.`,
  `if TYPE_CHECKING:`.

**The coverage floor is 78%** — staged down over time (87→85→83→82→80→79→78) as
documented inline; the aspirational target is 90% (DECISION-017). When rebuilding,
the floor is what CI enforces.

CI command (`.github/workflows/ci.yml`, temporal matrix leg, Python 3.12):
installs `olympus-contracts`, `temporal`, `olympus-worker --ignore-requires-
python`, `olympus-api --ignore-requires-python`; runs `ruff check .` then:

```
pytest -n 4 --cov=olympus_workflows --cov-report=term-missing \
       --cov-report=xml:coverage.xml --tb=short -q
```

with env `AGENT_RUNTIME_MODE=mock`, `APP_ENV=test`. `-n 4` is pinned (NOT
`-n auto`) — `auto` over-subscribes the per-test Temporal time-skipping Rust
sidecars and desyncs them. There is **no Makefile** in `temporal/`.

### 9.2 Test harness (`tests/conftest.py`)

Per DECISION-018, `MockAgentRuntime` is the only sanctioned mock. The conftest
(1) sets `AGENT_RUNTIME_MODE=mock` + `APP_ENV=test` at session start so
`dispatch_agent_task` routes through `dispatch_via_mock`; (2) stubs
`_insert_agent_task_row` / `_update_agent_task_row` so no Postgres is required;
(3) registers one mock agent card owning every skill used by the workflow tests;
(4) pins `OLYMPUS_SKILLS_ROOT` to this checkout's `cross-cutting/skills`. Other
activity mocks live in `tests/_workflow_mocks.py`. Fixtures + JSON schemas under
`tests/fixtures/` and `tests/schemas/`.

### 9.3 Test inventory

74 `test_*.py` files. Coverage spans: every workflow
(`test_wave_workflow`, `test_discovery_workflow`, `test_rationalization_workflow`,
`test_wave_rationalization_workflow`, `test_wave_architecture_workflow`,
`test_architecture_workflow`, `test_data_workflow`, `test_modernization_workflow`,
`test_generate_bc_workflow`, `test_validation_workflow`,
`test_deployment_workflow`, `test_disposition_workflow`,
`test_governance_workflow`, `test_sustainment_workflow`, `test_app_workflow`),
every router (`test_*_router`), the registry engine + overrides
(`test_registry_engine`, `test_registries_overrides`,
`test_registry_extensions_p4s5`, `test_disposition_registry`), retry policies
(`test_retry_policies`), Layer B emission
(`test_*_activity_emission`, `test_execution_utils`), merge handling
(`test_git_merge_reconciliation`, `test_merge_blocked_retry`,
`test_discovery_two_gate_merge`), contract compliance
(`test_gate_card_contract_compliance`, `test_contract_envelope_schema`,
`test_skill_input_artifact_contract`), and end-to-end smokes
(`test_atlas_rat_cap_e2e_smoke`, `test_modernization_devsecops_baseline_e2e`,
`test_gate_pre_review_e2e`). Workflow tests use
`WorkflowEnvironment.start_time_skipping()` (each spawns its own Rust sidecar —
the reason `-n 4` is pinned).

---

## 10. Atomic Rebuild Checklist

Ordered, each with an explicit acceptance check. Build in this order — later
steps depend on earlier ones importing cleanly.

1. **Package skeleton.** Create `temporal/pyproject.toml` (§0) with the exact
   dependency pins and `[tool.pytest.ini_options]` addopts (`--cov-fail-under=78`).
   *Accept:* `pip install -e temporal/[dev]` resolves (with the private
   `foundry-temporal` registry configured) and `python -c "import
   olympus_workflows"` succeeds.

2. **Types module.** Author `olympus_workflows/types.py` (§2): all enums, the 5
   concurrency limits (§2.2 exact values), every signal payload (§2.3), every
   workflow input (§2.4), and every activity I/O dataclass (§2.5).
   *Accept:* `from olympus_workflows.types import MAX_APPS_PER_WAVE,
   WaveWorkflowInput, GateApprovedSignal` works; `MAX_APPS_PER_WAVE == 10`,
   `MAX_BC_CHILDREN_PER_APP == 12`, `MAX_RALPH_ITERATIONS == 10`.

3. **Retry policies.** Author `retry_policies.py` (§3) with the six policies and
   the `RETRY_POLICIES` dict. *Accept:* `RETRY_POLICIES["validation_failure"]`
   has `maximum_attempts == 1`; `RETRY_POLICIES["git_merge"].non_retryable_error_types`
   contains the three merge errors; `agent_failure` = 5s/2.0/60s/3.

4. **Registry engine.** Author `registries/engine.py` (§7.0): generic
   `Registry[T]` with CRUD, semver versioning, and DFS cycle detection plus the
   error hierarchy. *Accept:* `test_registry_engine` passes — register/get/
   upsert/delete round-trip, `bump_semver("1.2.3","minor")=="1.3.0"`, and a
   dependency cycle raises `CircularDependencyError`.

5. **The 6 extension points + defaults.** Author the six registry modules (§7.1-
   7.6) + `registries/defaults/{dispositions,scoring-dimensions,
   gate-providers,skill-compositions}.yaml`, all loading defaults at import.
   *Accept:* `SCORING_DIMENSION_REGISTRY` weights sum to exactly 1.0;
   `DISPOSITION_REGISTRY` has exactly 5 strategies (no Refactor/Rearchitect);
   `GATE_PROVIDER_REGISTRY` default is `github-pr`; `SKILL_COMPOSITION_REGISTRY`
   is empty.

6. **Profile overrides + bootstrap.** Author `profile_overrides.py` +
   `worker_bootstrap.py` (§7.7). *Accept:* `test_registries_overrides` and
   `test_worker_bootstrap` pass; `bootstrap_profile_from_env()` with no
   `OLYMPUS_PROFILE` is a no-op leaving defaults intact, and
   `reset_registries_to_defaults()` restores them.

7. **Utils.** Author `utils/execution.py` (§6.6) and `utils/target_plan.py`
   (§6.7) and `utils/__init__.py` (exports `dedup_paths`, `parse_agent_json`).
   *Accept:* `test_execution_utils`, `test_target_plan_utils`,
   `test_dedup_utils` pass; `emit_execution_record` returns `None` (not raise)
   when no DB is reachable; `slugify_target_name("Medical Readiness & Case")
   == "medical-readiness-case"`.

8. **Activities.** Author all modules in `activities/` (§6), each decorated
   `@foundry_activity`. Build leaf-first: agent_dispatch, git_operations,
   gate_operations, gate_pre_review, scoring, classification, wave_operations,
   governance_operations, arch_data_registry, artifact_validation,
   context_priors, disposition_outputs, bundle_activities, traceability, and the
   large line_transitions projection set. *Accept:* every name in
   `ALL_ACTIVITIES` (§1.5) imports; `test_agent_dispatch_persistence`,
   `test_gate_operations`, `test_git_activity_emission`, `test_line_transitions`,
   `test_artifact_validation`, `test_bundle_activities` pass with
   `AGENT_RUNTIME_MODE=mock`.

9. **Workflow base.** Author `workflows/base.py` (§4): `LineWorkflowBase` with
   classvars, the four non-overridable signal handlers, and all helpers
   (`_set_step`, `_dispatch_agent`, `_commit_step_artifacts`,
   `_submit_gate_evidence`, `_run_gate_pre_review`, `_wait_for_gate_decision`,
   `_reconcile_and_merge_with_retry_loop`, rework counters, `get_status`).
   *Accept:* `test_line_workflow_batch_invariant` passes.

10. **Routers.** Author the four pure-Python routers (§5.21). *Accept:*
    `test_discovery_patterns_router`, `test_code_generation_router`,
    `test_architecture_patterns_router`, `test_data_router` pass — including the
    Oracle-vendor-blob substring case and the `retire/retain → None` arch case.

11. **Orchestration + line workflows.** Author every workflow in §5: the
    PortfolioWorkflow stub, Wave, App, Discovery, Rationalization,
    WaveRationalization, WaveArchitecture, Architecture, Data, Modernization,
    GenerateBC, Validation, Deployment, Disposition, Governance, Sustainment,
    BundleReaper, SmokeTest, and the BundleAwareMixin. Preserve every
    `workflow.patched("<id>")` gate and every gate/signal name exactly.
    *Accept:* `WaveWorkflow` child id is `app-{app_id}-wave-{wave_id}` on the
    parent's task queue with `asyncio.Semaphore(max_apps_per_wave)`;
    `GenerateBCWorkflow` Ralph Loop caps at 10 and escalates on exhaustion;
    `WaveArchitectureWorkflow` spawns children with `ParentClosePolicy.ABANDON`
    and strict-fails schema validation; the per-line gate names match §5
    (G-DC / G-RR+G-DA / G-02 / G-DT / G-04a/b/c / G-V1/2/3 / G-DP-1/2 /
    G-DE-1/2). All `test_*_workflow` suites pass.

12. **Worker.** Author `worker.py` (§1): `ALL_WORKFLOWS` (18, §1.4),
    `ALL_ACTIVITIES` (~50, §1.5), and `run_worker()` with the exact bootstrap
    order — profile bootstrap FIRST, then `WorkerConfig.from_env()`, then the
    `foundry-workflows → olympus-main` task-queue override, then client +
    worker. *Accept:* `python -m olympus_workflows.worker` registers all
    workflows/activities without error (it will then fail to *connect* without a
    server — expected); the logged counts are 18 workflows and the full activity
    count.

13. **Config.** Author `config/{services,workflows,activities}.yaml` (§8) with
    the per-activity timeouts. *Accept:* `wait_for_gate_decision` timeout is
    172800s and `dispatch_agent_task` is 1800s; the declarative registration
    matches the code-side `ALL_*` lists.

14. **Test harness + green CI.** Author `tests/conftest.py` (§9.2), the 74
    `test_*.py` files, `_workflow_mocks.py`, and `tests/fixtures/` +
    `tests/schemas/`. *Accept:* `pytest -n 4 --cov=olympus_workflows
    --cov-report=term-missing -q` with `AGENT_RUNTIME_MODE=mock APP_ENV=test`
    passes with coverage ≥ 78% and `ruff check .` is clean.

15. **End-to-end behavioral parity.** Run the smoke suites
    (`test_atlas_rat_cap_e2e_smoke`, `test_modernization_devsecops_baseline_e2e`,
    `test_gate_pre_review_e2e`) under the time-skipping environment. *Accept:*
    all pass; a Discovery→G-DC→merge cycle, a Rationalization G-RR+G-DA
    dual-signal cycle, and a Modernization Ralph-Loop-to-escalation cycle each
    reach their documented terminal states.
