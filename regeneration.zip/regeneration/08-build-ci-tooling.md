# 08 — Build, CI, Deployment, Docker Stack & Contributor Workflow

> **Regeneration premise.** The codebase has been deleted. This document is the sole
> surviving artifact for the *build/run/CI/deploy* surface. Every fact below is derived
> from the repo and cited as `{repo}:{file}:{line}`. `{repo}` is the foundry repo root
> (`/Users/pnunna/Documents/GitHub/foundry`). Where a value has a compose default it is
> shown as `${VAR:-default}` exactly as the source declares it.

This file is the system view. Per-service internals (FastAPI routers, worker activities,
agent runtime, MCP tools, dashboard) live in their own regeneration docs. Here we capture
the *stack wiring*: compose services, Makefile targets, CI jobs, env vars, secrets scan,
infra inventory, contributor rules, and seeds — enough to stand the whole environment back
up from zero.

---

## 1. Docker Compose Stack

Source: `{repo}:docker-compose.yml:1-501`. One Compose file, `services:` block opens at
line 9, `volumes:` block at line 496. Usage banner: `docker compose up`; reset:
`docker compose down -v` (`{repo}:docker-compose.yml:6-7`). There is **no top-level
`networks:` block** — every service shares the implicit default Compose bridge network and
addresses peers by service name (e.g. `postgres`, `temporal-server:7233`,
`http://olympus-api:8000`).

### 1.1 Full service table

| Service | Image / Build | Host ports | depends_on (condition) | Healthcheck | Source lines |
|---------|---------------|-----------|------------------------|-------------|--------------|
| `postgres` | `postgres:16` | `5432:5432` | — | `pg_isready -U ${POSTGRES_USER:-olympus}` int 5s / to 5s / retries 10 | `:13-28` |
| `redis` | `redis:7` | `6379:6379` | — | `redis-cli ping` int 5s / to 3s / retries 5 | `:30-40` |
| `localstack` | `localstack/localstack:latest` | `4566:4566` | — | none | `:42-50` |
| `db-migrate` | build `db/Dockerfile` | — | postgres (healthy) | none; `restart: "no"` (one-shot) | `:52-65` |
| `temporal-server` | `temporalio/auto-setup:latest` | `7233:7233` | postgres (healthy) | `tctl … cluster health \|\| nc -z localhost 7233` int 10s / retries 20 / start 30s | `:70-95` |
| `temporal-namespace-init` | `temporalio/auto-setup:latest` | — | temporal-server (healthy) | none; one-shot `restart: "no"` | `:105-117` |
| `temporal-ui` | `temporalio/ui:latest` | `8080:8080` | temporal-server (healthy) | none | `:119-128` |
| `olympus-api` | build `olympus-api/Dockerfile` (arg `PIP_EXTRA_INDEX_URL`) | `8000:8000` | db-migrate (completed), postgres (healthy), temporal-server (healthy), redis (healthy) | `curl -sf http://localhost:8000/health` int 10s / start 15s | `:133-217` |
| `olympus-temporal-worker` | build `olympus-worker/Dockerfile` (arg `PIP_EXTRA_INDEX_URL`) | none (scale-compatible) | db-migrate (completed), temporal-server (healthy), postgres (healthy) | python `/proc` scan for `src.worker` cmdline (excludes own pid) int 15s / start 30s | `:219-302` |
| `olympus-dashboard` | build `./dashboard/Dockerfile` | `3000:3000` | olympus-api (healthy) | node `fetch('http://localhost:3000')` | `:304-329` |
| `olympus-agent-runtime` | build `olympus-agent-runtime/Dockerfile` (arg `PIP_EXTRA_INDEX_URL`) | none (behind LB) | — | `curl -sf http://localhost:8100/health` int 10s / start 15s | `:346-422` |
| `olympus-agent` | `haproxy:2.9-alpine` | `8100:8100` | olympus-agent-runtime (healthy) | `wget -qO- http://127.0.0.1:8100/lb-health` int 10s / start 5s | `:450-470` |
| `olympus-mcp-server` | build `mcp-server/Dockerfile` | `3001:3001` | db-migrate (completed), postgres (healthy) | python `urllib.request.urlopen('http://localhost:3001/')` int 10s / start 10s | `:472-494` |

Named volumes (`{repo}:docker-compose.yml:496-500`): `postgres-data`, `redis-data`,
`localstack-data`, `agent-workspace`.

### 1.2 Per-service detail

**postgres** (`:13-28`) — Postgres 16. Env: `POSTGRES_USER=${POSTGRES_USER:-olympus}`,
`POSTGRES_PASSWORD=${POSTGRES_PASSWORD:-olympus_dev}`, `POSTGRES_DB=${POSTGRES_DB:-postgres}`.
Volumes: `postgres-data:/var/lib/postgresql/data` plus
`./db/init:/docker-entrypoint-initdb.d` (`:21-23`). The init dir contains
`01-create-databases.sh` (`{repo}:db/init/01-create-databases.sh:1-18`) which on first launch
runs `CREATE DATABASE olympus; CREATE DATABASE temporal; CREATE DATABASE temporal_visibility;`
and grants all privileges to `$POSTGRES_USER`. **Critical:** Postgres boots with DB
`postgres`, and the init script creates the three real DBs — `olympus` (app), `temporal`,
`temporal_visibility`.

**redis** (`:30-40`) — Redis 7 for API rate-limit/cache backing
(`REDIS_URL=redis://redis:6379/0`).

**localstack** (`:42-50`) — S3 + Secrets Manager emulation only
(`SERVICES: s3,secretsmanager`, `DEFAULT_REGION: us-east-1`). Does **not** emulate Bedrock;
agent inference needs real AWS (`{repo}:.env.example:40-45`).

**db-migrate** (`:52-65`) — One-shot Alembic runner. Build `db/Dockerfile`
(`{repo}:db/Dockerfile:1-13`): `python:3.14-slim`, installs `db/requirements.txt`
(`alembic>=1.13,<2.0`, `psycopg2-binary>=2.9,<3.0`, `sqlalchemy>=2.0,<3.0` —
`{repo}:db/requirements.txt:1-3`), copies `alembic.ini` + `alembic/`, `CMD ["alembic","upgrade","head"]`.
Connects with `DATABASE_HOST=postgres … DATABASE_NAME=olympus`. `restart: "no"` — it
exits 0 and other services gate on `service_completed_successfully`. Migrations are
`db/alembic/versions/001_…` through `057_create_delegated_bundle.py` (numbering skips 055;
039 is a merge head) — 56 revisions total.

**temporal-server** (`:70-95`) — `temporalio/auto-setup`. Env: `DB: postgres12`,
`DB_PORT: 5432`, `POSTGRES_USER`/`POSTGRES_PWD` from the same compose vars, `POSTGRES_SEEDS: postgres`,
`DYNAMIC_CONFIG_FILE_PATH: config/dynamicconfig/docker.yaml`. Mounts
`./infra/temporal/dynamicconfig.yaml` to that path read-only (`:86`). The dynamic config
(`{repo}:infra/temporal/dynamicconfig.yaml:23-26`) raises `limit.blobSize.warn` to 1 MiB and
`limit.blobSize.error` to 4 MiB (default error is 2 MiB) so oversized gate-evidence payloads
don't terminate Discovery workflows — explicitly flagged as a band-aid.

**temporal-namespace-init** (`:105-117`) — One-shot. Runs
`temporal operator namespace update -n default --retention 720h` (30 days) then describes to
confirm. Idempotent.

**temporal-ui** (`:119-128`) — Web UI on `8080`. `TEMPORAL_CORS_ORIGINS: http://localhost:3000`.

**olympus-api** (`:133-217`) — FastAPI on `8000`. Build context repo root,
`olympus-api/Dockerfile`. Key env (`:141-183`):
`DATABASE_*` → postgres/olympus, `TEMPORAL_HOST: temporal-server:7233`,
`TEMPORAL_NAMESPACE: default`, `REDIS_URL: redis://redis:6379/0`, `DEV_AUTH_BYPASS: "true"`,
`MCP_SERVER_URL: http://olympus-mcp-server:3001`, `SKILLS_ROOT: /app/repo`,
`OLYMPUS_PROFILES_DIR: /app/repo/profiles`, `OLYMPUS_WORKER_CONFIG_DIR: /app/repo/olympus-worker/config`,
`RATE_LIMIT_ENABLED: ${RATE_LIMIT_ENABLED:-false}` (disabled in compose because the dashboard
fires 15-20 requests per navigation), `JWT_SECRET: ${JWT_SECRET:-olympus-dev-secret}`,
`SERVICE_TOKEN_PROVISIONING_SECRET: ${…:-olympus-dev-provisioning}`,
`SOURCE_INTAKE_ROOT: /workspace/sources`,
`SOURCE_INTAKE_MAX_UPLOAD_BYTES: ${…:-524288000}` (500 MiB). Volumes (`:184-202`):
`~/.aws:/root/.aws:ro`, `./cross-cutting/skills:/app/repo/cross-cutting/skills:ro`,
`./profiles:/app/repo/profiles:ro`, `./olympus-worker/config:/app/repo/olympus-worker/config:ro`,
`agent-workspace:/workspace`. Dockerfile (`{repo}:olympus-api/Dockerfile:3-38`):
`python:3.14-slim` from `public.ecr.aws/docker/library`, installs `curl`, installs vendored
wheels from `vendor/wheels/`, installs `temporal/` package, installs the api package, copies
skills, `CMD uvicorn src.main:create_app --factory --host 0.0.0.0 --port 8000`.

**olympus-temporal-worker** (`:219-302`) — Background Temporal worker, **no host port** so it
scales: `docker compose up -d --scale olympus-temporal-worker=N`. Polls task queue
`olympus-main` (`TASK_QUEUE: olympus-main`, `:233`). `OLYMPUS_AGENT_URL: http://olympus-agent:8100`
(the HAProxy LB), `OLYMPUS_PROFILE_ROOT: /app/repo/profiles/faa`, `OLYMPUS_SCHEMAS_DIR: /app/repo/schemas`.
`WORKER_IDENTITY` deliberately unset — derived from container hostname+pid at startup.
Volumes: `~/.aws:ro`, `./profiles:ro`, `./schemas:ro`. Dockerfile is multi-stage
(`{repo}:olympus-worker/Dockerfile:1-43`): builder on `python:3.14-slim` installs wheels +
`temporal/` + worker package; runtime stage copies site-packages, worker `src/`+`config/`,
and copies `olympus-api/src/services/git_service.py` to `/app/src/git_service.py` (single
source of truth for GitService). `CMD python -m src.worker`. The healthcheck scans `/proc`
for the `src.worker` cmdline because `procps`/`pgrep` is absent in slim.

**olympus-dashboard** (`:304-329`) — Vite dev server on `3000`. Build `./dashboard/Dockerfile`.
Env: `API_URL: http://olympus-api:8000`, `VITE_API_BASE_URL: http://localhost:8000`,
`VITE_WS_BASE_URL: ws://localhost:8000`. Volumes bind `./dashboard/src`, `./dashboard/index.html`,
and `./docs:/docs:ro` (the AboutContinuity page imports `docs/phase1-continuity-matrix.md?raw`).
Dockerfile (`{repo}:dashboard/Dockerfile:1-47`): `node:22-slim`, installs `ca-certificates`,
optionally installs a Booz Allen Zscaler root cert from `ZscalerRootCertificate*.crt*` in the
build context (no-ops cleanly if absent), `npm ci`, `CMD npx vite --host 0.0.0.0 --port 3000 --force`.

**olympus-agent-runtime** (`:346-422`) — Agent runtime image (one image, `AGENT_NAME` selects
the registered identity per DECISION-019; default `discovery-analyst`). Listens on `8100`,
**no host port** — reached only through the LB. Env (`:352-379`):
`INFERENCE_PROVIDER: ${…:-bedrock}`, `DEFAULT_MODEL_TIER: tier-2`, `CLAUDE_CODE_USE_BEDROCK: "1"`,
`MAX_CONCURRENT_TASKS: "12"`, `MAX_QUEUED_WAITERS: "2"`, `SKILL_API_URL: http://olympus-api:8000`,
`OLYMPUS_API_TOKEN: ${OLYMPUS_AGENT_RUNTIME_TOKEN:-}`, `OLYMPUS_SCHEMA_ROOT: /app/repo`,
`WORKSPACE_DIR: /workspace`. `shm_size: ${AGENT_SHM_SIZE:-512m}`.
`deploy.replicas: ${AGENT_REPLICAS:-3}`, memory limit `${AGENT_MEMORY_LIMIT:-6G}`,
reservation `${AGENT_MEMORY_RESERVATION:-2G}`. Dockerfile multi-stage
(`{repo}:olympus-agent-runtime/Dockerfile:1-42`): builder installs `[agent]` extra; runtime
on `python:3.14-slim` installs `curl git`, exposes 8100, `CMD uvicorn src.main:create_app --factory --host 0.0.0.0 --port 8100`.

**olympus-agent** (`:450-470`) — HAProxy 2.9-alpine LB in front of the runtime pool. Host
port `8100:8100`. Mounts `./infra/haproxy/agent-lb.cfg` to
`/usr/local/etc/haproxy/haproxy.cfg:ro`. Config (`{repo}:infra/haproxy/agent-lb.cfg:88-131`):
`balance leastconn`, `option httpchk GET /health`, `retry-on conn-failure empty-response
response-timeout 503 502 504`, and a `server-template agent "${MAX_BACKENDS}"
"${BACKEND_DNS_NAME}:8100" … resolvers backend_resolver` so DNS-discovered replicas are
tracked dynamically. Env knobs with compose defaults via `presetenv` (`:65-67`):
`RESOLVER_ADDRESS=127.0.0.11:53` (Docker DNS), `BACKEND_DNS_NAME=olympus-agent-runtime`,
`MAX_BACKENDS=16`. The `/lb-health` 200 endpoint backs the compose healthcheck.

**olympus-mcp-server** (`:472-494`) — MCP JSON-RPC server on `3001`. `DATABASE_*` → olympus.
Dockerfile (`{repo}:mcp-server/Dockerfile:1-22`): `python:3.14-slim`, installs vendored
wheels, copies `olympus_mcp/` + `schemas/`, installs the package,
`CMD python3 -m olympus_mcp.server --host 0.0.0.0 --port 3001`.

### 1.3 Vendored wheels (offline-build fallback)

`vendor/wheels/` (`{repo}:vendor/wheels/`) ships three private foundry packages so images
build without Artifactory reachability:
`foundry_strands_agents-0.4.0-py3-none-any.whl`, `foundry_temporal-1.3.0-py3-none-any.whl`,
`olympus_contracts-0.3.0-py3-none-any.whl`. The api/worker/mcp/agent Dockerfiles all install
from `vendor/wheels/` first; `PIP_EXTRA_INDEX_URL` (the Artifactory index) is the remote
alternative.

---

## 2. Makefile Targets

Source: `{repo}:Makefile:1-174`. `SHELL := /bin/bash`, `.ONESHELL` (`:17-18`). Variables:
`COMPOSE ?= docker compose`, `PYTHON ?= python3` (`:20-21`), `AGENT_SCALE ?= 8` (`:28`),
host DB connection exported for seed scripts: `DATABASE_HOST ?= localhost`,
`DATABASE_PORT ?= 5432`, `DATABASE_USER ?= olympus`, `DATABASE_PASSWORD ?= olympus_dev`,
`DATABASE_NAME ?= olympus` (`:31-35`), `API_URL ?= http://localhost:8000`,
`READY_RETRIES ?= 60`, `READY_INTERVAL ?= 2` (`:37-39`).

| Target | Lines | Exact command sequence |
|--------|-------|------------------------|
| `help` | `:43-44` | greps `##` annotations from the Makefile and pretty-prints. |
| `demo-up` | `:46-56` | `$(COMPOSE) up -d --scale olympus-agent=$(AGENT_SCALE)` → `$(MAKE) demo-wait` → `$(MAKE) demo-seed` → `$(MAKE) demo-smoke` → prints Dashboard/API/Temporal URLs. |
| `demo-wait` | `:58-67` | Loops `READY_RETRIES` times: `curl -s -o /dev/null -w "%{http_code}" $(API_URL)/health/ready`; exit 0 on `200`; sleep `READY_INTERVAL`; fail after retries exhausted. |
| `demo-seed` | `:69-71` | `$(PYTHON) scripts/seed_all.py --reset`. |
| `demo-reset` | `:73-76` | `demo-wait` → `demo-seed` → `demo-smoke` (no stack restart). |
| `demo-down` | `:78-79` | `$(COMPOSE) down` (volumes preserved). |
| `demo-nuke` | `:81-82` | `$(COMPOSE) down -v` (destructive — drops volumes). |
| `demo-smoke` | `:84-86` | `$(PYTHON) scripts/demo_smoke.py`. |
| `seed-tokens` | `:97-98` | `$(PYTHON) scripts/seed_service_tokens.py` → writes `.service-tokens.env`. |
| `up` | `:100-107` | depends on `seed-tokens`; then `$(COMPOSE) --env-file .env --env-file .service-tokens.env up -d --scale olympus-agent=$(AGENT_SCALE)`. |
| `down` | `:109-110` | `$(COMPOSE) down`. |
| `reset` | `:112-114` | `$(COMPOSE) down -v` → `$(MAKE) up`. |
| `validate-schemas` | `:120-121` | `bash schemas/validate.sh`. |
| `validate-objectives` | `:123-124` | `$(PYTHON) scripts/validate_objectives.py`. |
| `render-exec` | `:131-132` | depends on `validate-objectives`; then `$(PYTHON) scripts/render_exec_microsite.py`. |
| `render-exec-generic` | `:134-135` | depends on `validate-objectives`; then `… render_exec_microsite.py --profile test-generic`. |
| `serve-exec` | `:138-142` | depends on `render-exec`; then `$(PYTHON) -m http.server $(EXEC_PORT) --directory presentation` (`EXEC_PORT ?= 8765`). |
| `csn-apply` | `:149-150` | `cd infra/terraform/environments/dev-csn-fargate && terraform apply`. |
| `csn-deploy-dashboard` | `:152-153` | `scripts/csn-fargate/build-and-push-dashboard.sh`. |
| `csn-seed-admin` | `:155-156` | `scripts/csn-fargate/seed-admin.sh`. |
| `csn-migrate-data` | `:158-159` | `scripts/csn-fargate/migrate-local-data.sh`. |
| `csn-bootstrap` | `:161` | `csn-apply` → `csn-seed-admin` → `csn-migrate-data` → `csn-deploy-dashboard`. |
| `csn-admin-password` | `:163-166` | `aws … secretsmanager get-secret-value --secret-id foundry/dev/admin-user …` then jq-prints username/email/password. |
| `csn-status` | `:168-173` | `aws … ecs describe-services --cluster foundry-dev --services olympus-api olympus-worker olympus-agent olympus-mcp-server olympus-dashboard temporal-server temporal-ui …` table. |

`CSN_TF_DIR := infra/terraform/environments/dev-csn-fargate` (`:147`).

**Two distinct bring-up paths.** `make up` (the auth-aware path) mints service-account JWTs
first and passes **two** env-files; `make demo-up` is the full demo lifecycle
(up → wait → seed → smoke) and scales `olympus-agent` to 8. There is no top-level `test`
target in the Makefile — tests run per-package via `pytest` / `npm` (see §7) and in CI.

---

## 3. CI Workflows

Four workflows under `{repo}:.github/workflows/`: `ci.yml`, `deploy.yml`,
`traceability-check.yml`, `pages-publish-traceability.yml`.

### 3.1 `ci.yml` — main CI

Source `{repo}:.github/workflows/ci.yml:1-973`. Triggers (`:3-13`): `pull_request` → main,
`push` → main, and nightly `schedule: "0 7 * * *"` (07:00 UTC). Concurrency group cancels
superseded PR runs only (`:17-19`). Default permissions `contents: read`,
`pull-requests: read` (`:21-23`).

**Job `preflight`** (`:33-221`) — `ubuntu-latest`, `actions/checkout@v5` with
`fetch-depth: 0`. Classifies the PR diff into per-surface boolean outputs (19 outputs,
`:37-55`). Rules:
- `push` or `schedule` → **all outputs forced true** (full CI) (`:76-90`).
- Resolves BASE/HEAD; if unresolvable, safe-fallback to full CI (`:92-117`).
- `docs_only` true when every changed path matches `.md/.mdx` or is under
  `specifications/ docs/ reference/ .claude/ .agents/` (`:123-130`).
- Any change under `.github/workflows/` forces all-true (`:135-149`).
- Path→flag mapping via `match()` (`:160-175`): `contracts_changed`=`schemas/|specifications/api/|olympus-contracts/`;
  `skill_catalog_changed`; `objectives_changed`; `step_registry_changed`; `sql_schema_changed`;
  `line_contracts_changed`; `api_changed`=`^olympus-api/`; `worker_changed`; `agent_runtime_changed`;
  `mcp_changed`; `temporal_changed`; `contracts_pkg_changed`; `dashboard_changed`;
  `helm_changed`=`^infra/helm/`; `terraform_changed`=`^infra/terraform/`; `argocd_changed`=`^infra/argocd/`.
- Shared-python surface (`olympus-contracts/ tests/ scripts/ pyproject.toml requirements*.txt
  .pre-commit-config.yaml`) flips api/worker/agent/mcp/temporal all true (`:181-188`).
- `python_any_changed` = OR of the python package flags (`:190-196`).

**Job `branch-naming`** (`:223-237`) — PR-only. Regex
`^(phase-[0-9][a-z]|feat|fix|refactor|docs|ci|chore|dependabot|integration)/` against
`github.head_ref`; fails otherwise.

**Job `contracts`** (`:239-321`) — gated on `contracts_changed`. Node 22 + Python 3.13.
Lints `specifications/api/openapi.yaml` with `@redocly/cli lint`, bundles + re-lints,
installs `check-jsonschema jsonschema`, runs `check-jsonschema --check-metaschema` over every
`schemas/**/*.schema.json`, and validates `schemas/samples/*.json` against a locally-built
schema store using `Draft202012Validator` + `RefResolver`.

**Job `skill-catalog`** (`:323-340`) — gated on `skill_catalog_changed`. Python 3.13 + PyYAML;
`python3 scripts/validate_skill_registry.py`.

**Job `agency-objectives`** (`:342-366`) — gated on `objectives_changed`. Installs
`pyyaml jsonschema pytest`; `python3 scripts/validate_objectives.py` then
`pytest tests/test_validate_objectives.py -v`.

**Job `step-registry-consistency`** (`:368-385`) — gated on `step_registry_changed`. Installs
`olympus-contracts` editable; `python3 scripts/verify_step_registry.py`.

**Job `sql-schema-drift`** (`:387-407`) — gated on `sql_schema_changed`. `python3
scripts/verify_sql_schema.py` then `pytest tests/test_verify_sql_schema.py -v`.

**Job `line-contracts-consistency`** (`:409-428`) — gated on `line_contracts_changed`. Node 22,
`npm ci` in dashboard, `node dashboard/scripts/parse-line-contracts.mjs --validate-only`.

**Job `profile-portability`** (`:430-464`) — gated on api/temporal/contracts-pkg changed.
Installs `olympus-contracts`, `temporal`, `olympus-api[dev]` (with
`PIP_EXTRA_INDEX_URL=https://jfrog-platform.bah-ss-nonprod.te-test-domain.com/artifactory/api/pypi/agentic-ai-pypi/simple`),
then `AGENT_RUNTIME_MODE=mock APP_ENV=test pytest tests/test_generic_profile_portability.py -v --no-cov`.

**Job `python` (matrix)** (`:477-595`) — gated on `python_any_changed`; 5 legs
(`:484-505`): `olympus-api` (3.13, cov `src`), `temporal` (3.12, cov `olympus_workflows`),
`olympus-agent-runtime` (3.13, cov `src`), `olympus-worker` (3.13, cov `src`),
`mcp-server` (3.12, cov `olympus_mcp`). Each leg re-checks its own flag (`steps.gate`) so a
temporal-only PR skips the others. Install path installs `olympus-contracts` + `temporal` +
the package `[dev]` + `ruff`; the temporal leg additionally installs worker & api with
`--ignore-requires-python`. Steps: `ruff check .`; then
`pytest [--cov=<source> --cov-report=term-missing --cov-report=xml:coverage.xml --tb=short -q]`
with `AGENT_RUNTIME_MODE=mock APP_ENV=test`; temporal runs with `-n 4` (xdist, pinned). Coverage
artifact uploaded per package. **Coverage floors are enforced inside each package's pytest
config (`addopts`/`--cov-fail-under`), not in the workflow YAML** — see §6 for the table.

**Job `python-integration`** (`:597-646`) — gated on `api_changed`. Spins a `postgres:16`
service (user/pw/db = olympus/olympus_dev/olympus). Installs `olympus-api[dev,integration]`,
`ruff check tests/integration/`, then
`OLYMPUS_INTEGRATION_DATABASE_URL=postgresql://olympus:olympus_dev@localhost:5432/olympus
AGENT_RUNTIME_MODE=mock APP_ENV=test pytest tests/integration/ -v --no-cov --tb=short`.

**Job `frontend`** (`:648-685`) — gated on `dashboard_changed`. Node 20, `npm ci`,
`npm run lint`, `npm run typecheck`, `npm run build` (all `--if-present`),
`npx vitest run --coverage`; uploads `dashboard/coverage/`.

**Job `secrets-scan`** (`:693-748`) — always runs. Caches/installs gitleaks **8.21.2**.
PR fast-lane: `gitleaks protect --source=. --config=.gitleaks.toml --redact --no-banner
--log-opts="$BASE_SHA..$HEAD_SHA" --report-format=sarif --report-path=gitleaks.sarif`.
Push/nightly: `gitleaks detect …` over full history. SARIF uploaded.

**Job `codeql`** (`:755-780`) — push/schedule only, `continue-on-error: true`. Matrix
`[python, javascript]`, `security-and-quality` queries.

**Job `trivy-fs`** (`:787-847`) — push/schedule only, `continue-on-error: true`. Trivy
**0.59.1** filesystem scan, severities `CRITICAL,HIGH`, `--exit-code 0` (advisory), SARIF
upload. Tolerates download outages.

**Job `helm-lint`** (`:853-895`) — gated on `helm_changed` OR push/schedule. Matrix of 8
charts: `olympus-api olympus-worker olympus-agent-runtime olympus-mcp-server olympus-dashboard
db-migrate ingress olympus-umbrella`. Helm v3.14.0. `helm lint` + `helm template … > /dev/null`;
umbrella additionally `helm dependency update` and renders `values-{dev,staging,prod}.yaml`.

**Job `terraform-validate`** (`:900-939`) — gated on `terraform_changed` OR push/schedule.
Matrix of 15 roots: modules `vpc eks rds redis ecr s3 secrets gfi-mirror dms dms-endpoint` and
environments `dev staging prod phase3-dms dev-csn-fargate`. Terraform 1.7.5;
`fmt -check -recursive`, `init -backend=false`, `validate`.

**Job `kubeval-argocd`** (`:941-959`) — gated on `argocd_changed` OR push/schedule. `yamllint`
(relaxed) over `infra/argocd/`.

**Disabled `build-push`** (`:961-973`) — commented out; container build/push is deferred until
the deploy pipeline is wired end-to-end.

### 3.2 `deploy.yml`

Source `{repo}:.github/workflows/deploy.yml:1-269`. Triggers (`:3-18`): `workflow_run`
after CI completes on main, plus `workflow_dispatch` with `target_env` choice (dev/staging/prod).
Permissions `id-token: write`, `contents: read` (OIDC to AWS).

- **`deploy-dev`** (`:31-133`) — runs on successful CI workflow_run OR dispatch target_env=dev.
  GitHub environment `dev`. Steps: configure AWS creds via
  `aws-actions/configure-aws-credentials@v4` (role `secrets.AWS_DEPLOY_ROLE_ARN`,
  region `vars.AWS_REGION || us-east-1`); ECR login; setup kubectl + Helm v3.14.0;
  `aws eks update-kubeconfig --name ${vars.EKS_CLUSTER_NAME_DEV || olympus-dev}`; run db
  migrations via `helm upgrade --install olympus-db-migrate infra/helm/db-migrate`; deploy via
  `helm upgrade --install olympus infra/helm/olympus-umbrella -f values-dev.yaml` with per-service
  image repo/tag `--set`s (tag = `workflow_run.head_sha || github.sha`); then a smoke test that
  waits for the ALB ingress hostname and **fails** if `/health/live` ≠ 200.
- **`deploy-staging`** (`:145-205`) — `needs: deploy-dev`, `if: always() && (auto-promote on
  success OR dispatch=staging)`. Same deploy mechanics with `values-staging.yaml` and
  `EKS_CLUSTER_NAME_STAGING || olympus-staging`. No smoke test.
- **`deploy-prod`** (`:215-269`) — dispatch-only (`target_env=prod`), GitHub environment `prod`
  (required-reviewers gate). `values-prod.yaml`, `EKS_CLUSTER_NAME_PROD || olympus-prod`,
  tag = `github.sha`.

The umbrella chart (`{repo}:infra/helm/olympus-umbrella/Chart.yaml:8-`) declares subcharts
`db-migrate, olympus-api, olympus-worker, olympus-agent-runtime, olympus-mcp-server,
olympus-dashboard, ingress` (each `file://`-referenced, conditioned on `<name>.enabled`).

### 3.3 `traceability-check.yml`

Source `{repo}:.github/workflows/traceability-check.yml:1-91`. PR-triggered on paths under
`specifications/ temporal/ dashboard/ cross-cutting/ profiles/ docs/ schemas/
olympus-agent-runtime/ scripts/traceability/` and the workflow itself. Permissions
`contents: read`, `pull-requests: write`. Runs `python scripts/traceability/check.py --base
<base.sha> --head <head.sha> --output … --json …`, upserts a PR comment when `has_signal=true`,
uploads result JSON, and emits `::warning::` on status backslides / `::notice::` on coverage
gaps. Advisory only — does not fail CI.

### 3.4 `pages-publish-traceability.yml`

Source `{repo}:.github/workflows/pages-publish-traceability.yml:1-60`. Push-to-main (path-scoped)
or dispatch. `contents: write`. Runs `python scripts/traceability/build_dashboard_json.py
--appendix specifications/phase-3-traceability-appendix.md --out traceability/traceability.json`
and commits the regenerated JSON with `[skip ci]` if changed. Feeds the GitHub Pages dashboard.

### 3.5 Dependabot

`{repo}:.github/dependabot.yml` — weekly updates for pip (`/olympus-api`, `/olympus-worker`,
`/olympus-contracts`, `/temporal`, `/olympus-agent-runtime`, `/mcp-server`), npm (`/dashboard`),
docker (api/worker/dashboard/mcp/agent-runtime/db), and github-actions (`/`). Minor+patch grouped.

---

## 4. Environment Variables

`.env` and `.env.example` are **byte-identical** (verified via diff). Copy
`.env.example` → `.env` (`{repo}:.env.example:1-2`). Full inventory
(`{repo}:.env.example:1-49`):

| Var | Default | Purpose |
|-----|---------|---------|
| `PIP_EXTRA_INDEX_URL` | `https://jfrog-platform.bah-ss-nonprod.te-test-domain.com/artifactory/api/pypi/agentic-ai-pypi/simple` | Artifactory PyPI index for foundry packages (anonymous read). Build-arg into python images. |
| `POSTGRES_USER` | `olympus` | Postgres superuser. |
| `POSTGRES_PASSWORD` | `olympus_dev` | Postgres password. |
| `POSTGRES_DB` | `postgres` | Initial DB (app DBs created by init script). |
| `API_PORT` | `8000` | API listen port. |
| `DATABASE_HOST` | `postgres` | DB host (compose service name). |
| `DATABASE_PORT` | `5432` | DB port. |
| `DATABASE_NAME` | `olympus` | App DB. |
| `DATABASE_USER` | `olympus` | App DB user. |
| `DATABASE_PASSWORD` | `olympus_dev` | App DB password. |
| `TEMPORAL_HOST` | `temporal-server:7233` | Temporal frontend. |
| `TEMPORAL_NAMESPACE` | `default` | Temporal namespace. |
| `LOG_LEVEL` | `INFO` | Log level. |
| `GITHUB_TOKEN` | _(empty)_ | GitHub token for portfolio create + Discovery commits. |
| `GITHUB_BASE_URL` | `https://api.github.com` | GitHub API root (set to GHE instance for enterprise). |
| `REDIS_URL` | `redis://redis:6379/0` | Redis connection. |
| `AWS_ENDPOINT_URL` | `http://localstack:4566` | LocalStack endpoint (S3/SecretsManager). |
| `AWS_ACCESS_KEY_ID` | `test` | LocalStack dummy creds. |
| `AWS_SECRET_ACCESS_KEY` | `test` | LocalStack dummy creds. |
| `AWS_DEFAULT_REGION` | `us-east-1` | AWS region. |
| `AWS_REGION` | `us-east-1` | AWS region (Bedrock). |
| `INFERENCE_PROVIDER` | `bedrock` | Agent inference provider. |
| `CLAUDE_CODE_USE_BEDROCK` | `1` | Route Claude SDK through Bedrock. |
| `OLYMPUS_AGENT_URL` | `http://olympus-agent:8100` | LB URL for all agent identities (DECISION-019). |

**Compose-only vars not in `.env.example`** (read from environment with defaults in
docker-compose.yml): `RATE_LIMIT_ENABLED` (default false), `JWT_SECRET`
(`olympus-dev-secret`), `SERVICE_TOKEN_PROVISIONING_SECRET` (`olympus-dev-provisioning`),
`GITHUB_WEBHOOK_SECRET`, `GITHUB_REPO`, `AWS_PROFILE` (`ATLAS`), `AGENT_NAME`
(`discovery-analyst`), `AGENT_REPLICAS` (3), `AGENT_MEMORY_LIMIT` (6G),
`AGENT_MEMORY_RESERVATION` (2G), `AGENT_SHM_SIZE` (512m), `SOURCE_INTAKE_MAX_UPLOAD_BYTES`
(524288000), `SOURCE_INTAKE_S3_REGION`.

**Generated env-file** `.service-tokens.env` (written by `scripts/seed_service_tokens.py`,
`{repo}:scripts/seed_service_tokens.py:40-49`): `OLYMPUS_AGENT_RUNTIME_TOKEN=<jwt>` and
`OLYMPUS_WORKER_TOKEN=<jwt>`, signed with `JWT_SECRET` (dev default `olympus-dev-secret` if
unset, `:30-35`). Consumed by `make up` via the second `--env-file`.

---

## 5. Secrets Scan, Lint, and Other Root Config

**`.gitleaks.toml`** (`{repo}:.gitleaks.toml:1-29`): `[extend] useDefault = true` (built-in
ruleset, never loosened). `[allowlist]` exempts `infra/terraform/modules/secrets/*.tf`
(placeholder defaults injected from Secrets Manager at apply time) and the literal regex
`REPLACE_ME` repo-wide.

**`.dockerignore`** (`{repo}:.dockerignore:1-66`): excludes `.git`, IDE/agent rule files,
`*.md` (with re-includes for `mcp-server/**`, `cross-cutting/skills/**`, `profiles/faa/skills/**`,
and `docs/phase1-continuity-matrix.md`), `presentation/ specifications/ assembly-lines/
cross-cutting/ profiles/ reference/` (with skill subdirs re-included), python/node caches,
`docker-compose*.yml`, secrets (`.env`, `*.pem`, `*.key`, `credentials.json`, `secrets.yaml`;
re-includes `.env.example`), terraform state, OS junk.

**`.npmrc`** (`{repo}:.npmrc:1`): scopes `@civiltech` to the Booz Allen Nexus npm registry.

**`tsconfig.json`** (`{repo}:tsconfig.json:1-29`): root TS config for the demo-record Playwright
harness only. `target ES2022`, `module ESNext`, `moduleResolution bundler`, `strict`,
`types: ["node"]`; includes `tests/demo-record/**/*.ts` + `playwright.config.ts`; excludes all
service dirs.

**`package.json`** (`{repo}:package.json:1-17`): name `foundry-demo-record`, private. Scripts
`demo:shoot`, `demo:shoot:dry`, `demo:shoot:headed`, `demo:report` (Playwright). devDeps
`@playwright/test ^1.60.0`, `@types/node ^20.12.12`, `typescript ^5.4.5`. **This is not the
dashboard package** — the dashboard has its own `dashboard/package.json`.

**Playwright configs (root)** — all three drive the demo-recording/recon harness, not service
tests: `playwright.config.ts` (SF2 demo-shoot, `testDir ./tests/demo-record`, base
`http://localhost:5173`, `workers:1`, `video:'on'`, `slowMo:250`, 1080p — `{repo}:playwright.config.ts:30-65`);
`playwright.recon.config.ts` (live read-only recon on :3000 — `{repo}:playwright.recon.config.ts:1-10`);
`playwright.v6.config.ts` (v6 per-scene capture on :3000 — `{repo}:playwright.v6.config.ts:1-10`).

**`schemas/validate.sh`** (`{repo}:schemas/validate.sh:1-`): validates every `*.schema.json`
under `common/ discovery/ rationalization/ architecture/ data/ modernization/ gates/
cross-cutting/ profiles/ dispositions/` for valid JSON + presence of `$schema/$id/title/description`,
and validates `samples/*.sample.json` have a `$schema` reference; prints counts and fails on any
error. Invoked by `make validate-schemas`.

---

## 6. Coverage Floors (CONTRIBUTING)

Source `{repo}:CONTRIBUTING.md:89-107`. Target 90% Python lines and 90/80/85/90 dashboard
(lines/branches/functions/statements) per DECISION-017. Floors **only ratchet up**.

| Package | Current floor | Target | Tool | Local run |
|---------|--------------:|-------:|------|-----------|
| olympus-agent-runtime | 90% | 90% | pytest-cov | `cd olympus-agent-runtime && pytest` |
| olympus-api | 87% | 90% | pytest-cov | `cd olympus-api && pytest` |
| olympus-worker | 90% | 90% | pytest-cov | `cd olympus-worker && pytest` |
| mcp-server | 90% | 90% | pytest-cov | `cd mcp-server && pytest` |
| temporal | 87% | 90% | pytest-cov | `cd temporal && pytest` |
| dashboard lines | 81% | 90% | @vitest/coverage-v8 | `cd dashboard && npm run test:coverage` |
| dashboard branches | 70% | 80% | (same) | (same) |
| dashboard functions | 76% | 85% | (same) | (same) |
| dashboard statements | 79% | 90% | (same) | (same) |

Automated tests MUST use `MockAgentRuntime` via `AGENT_RUNTIME_MODE=mock` (DECISION-018);
the worker refuses to start in production with `mock` (`{repo}:CONTRIBUTING.md:117-135`).

---

## 7. Infra / Deployment Inventory

`infra/` (`{repo}:infra/`) trees:

- **`infra/helm/`** — 8 charts: `olympus-api`, `olympus-worker`, `olympus-agent-runtime`,
  `olympus-mcp-server`, `olympus-dashboard`, `db-migrate`, `ingress`, and the
  `olympus-umbrella` aggregator with `values-{dev,staging,prod}.yaml` + base `values.yaml`.
  This is the **EKS/Kubernetes deploy path** driven by `deploy.yml`.
- **`infra/terraform/`** — modules: `vpc eks rds redis ecr s3 secrets gfi-mirror dms
  dms-endpoint fargate-service`; environments: `dev staging prod phase3-dms dev-csn-fargate`.
  The `dev-csn-fargate` env (`{repo}:infra/terraform/environments/dev-csn-fargate/main.tf:1-50`)
  provisions **ECS Fargate** in an existing CSN VPC: ECS cluster `foundry-dev`, IAM roles, EFS,
  RDS, Redis, internal NLB + target groups, and 7 Fargate services (api, worker, agent, mcp,
  dashboard, temporal-server, temporal-ui), DNS records. Terraform required `>= 1.5.0`, AWS
  provider `~> 5.0`, S3 backend bucket `foundry-tfstate-081142215512`, lock table
  `foundry-tfstate-locks`, region us-east-1. CI validates with Terraform 1.7.5.
- **`infra/argocd/applications/`** — `olympus-dev.yaml`, `olympus-staging.yaml`,
  `olympus-prod.yaml` (GitOps Application manifests; yamllint-validated in CI).
- **`infra/haproxy/agent-lb.cfg`** — the agent LB config (§1.2), portable across compose /
  Fargate / EKS via the three `presetenv` knobs.
- **`infra/temporal/dynamicconfig.yaml`** — Temporal blobSize overrides (§1.2).
- Also: `infra/dms/` (Database Migration Service tasks + SCT reports), `infra/gfi/`
  (government-furnished-info mirror restore scripts), `infra/grafana/` + `infra/prometheus/`
  (observability dashboards + alert rules).

### 7.1 CSN-Fargate deploy path (the Makefile `csn-*` targets)

Shared helpers in `{repo}:scripts/csn-fargate/lib.sh:1-127`: AWS profile defaults to
`foundry-admin`, region `us-east-1`, cluster `foundry-dev`, account `081142215512`, artifacts
bucket `foundry-dev-artifacts-<account>`; `tf_output` reads terraform outputs with a live-ECS
fallback; `run_one_shot` launches a Fargate task and polls to STOPPED.

- **`csn-deploy-dashboard`** (`{repo}:scripts/csn-fargate/build-and-push-dashboard.sh:1-72`):
  `docker buildx build --platform linux/arm64 -f dashboard/Dockerfile.fargate
  --build-arg VITE_API_BASE_URL=http://<NLB>:8000 …`, push to ECR
  `foundry/olympus-dashboard:<date-stamp>`, `terraform apply -var dashboard_image_tag=<TAG>
  -auto-approve`, poll rollout. (Note: requires `dashboard/Dockerfile.fargate`, the
  nginx-served prod image — distinct from the dev `dashboard/Dockerfile`.)
- **`csn-seed-admin`** (`{repo}:scripts/csn-fargate/seed-admin.sh:1-`): Fargate one-shot that
  generates a 24-char password, bcrypt-hashes it into `user_account`, writes plaintext to
  Secrets Manager `foundry/dev/admin-user`. Idempotent (re-run = rotate).
- **`csn-migrate-data`** (`{repo}:scripts/csn-fargate/migrate-local-data.sh:1-`): uploads
  `db/seeds/initial-data.sql` to the artifacts bucket, triggers the `data-migrate` Fargate task
  which TRUNCATEs CASCADE then `psql -f`.

---

## 8. Contributor Workflow

Sources: `{repo}:CONTRIBUTING.md`, `{repo}:CLAUDE.md`, `{repo}:.github/pull_request_template.md`.

**Guiding principles** (`{repo}:CONTRIBUTING.md:9-18`): (1) **Contracts before code** —
OpenAPI/JSON-Schema/Temporal interfaces first, implementation satisfies them; (2) API before
UI; (3) Temporal is the orchestration backbone; (4) Git is source of truth, Postgres is a
disposable query layer; (5) one real app, not mocks; (6) speed over cost.

**Branch naming** (`{repo}:CONTRIBUTING.md:22-45`, enforced by CI `branch-naming`):
`<category>/<short-description>`. Categories: `phase-0a/ … phase-1b/ …`, `feat/`, `fix/`,
`refactor/`, `docs/`, `ci/`, `chore/` (CI regex also allows `dependabot/`, `integration/` —
`{repo}:.github/workflows/ci.yml:231`). **No direct commits to `main`.**

**PR requirements** (`{repo}:CONTRIBUTING.md:48-58`): Summary; **Spec traceability** (which
spec/phase/workstream/decision/requirement); task tracking (mark user-story tasks Done and
deliverable checkboxes); test plan; contract compliance. The PR template
(`{repo}:.github/pull_request_template.md`) encodes Summary / Spec Traceability / Contract
Compliance checklist (OpenAPI, JSON Schema, Temporal, MCP, N/A) / Test Plan / Checklist
(branch convention, trace to spec, tests pass, no secrets).

**Testing** (`{repo}:CONTRIBUTING.md:62-87`): zero failing tests always; write tests, run them
locally, run `ruff check` (Python) / `npm run lint` (frontend) with zero warnings, execute and
check off the PR test plan. Coverage floors per §6.

**Traceability citation forms** (`{repo}:CLAUDE.md`): `{artifact}:{section}:{finding-id}` or
`{repo}:{file}:{line}`.

**Tool guidance files** (`{repo}:CONTRIBUTING.md:170-179`): `CLAUDE.md`, `.cursorrules`,
`.windsurfrules`, `.clinerules`, `.specify/memory/constitution.md` — all point at the same
specs; CI enforces the real standards.

> **Architecture caveat** (`{repo}:CLAUDE.md`): specifications describe a Temporal+A2A+MCP
> target; the *active runtime is Anthropic-SDK based*. The Compose stack here is the Temporal
> target stack. When code and spec disagree, trust the code.

---

## 9. Seeds

**`make demo-seed` → `scripts/seed_all.py --reset`** (`{repo}:Makefile:69-71`).
`seed_all.py` (`{repo}:scripts/seed_all.py:41-103`) loads two sibling seeds in-process and runs
them async:
1. **FAA demo portfolio** — `seed_demo_faa.py`, `run(reset, portfolio_name)`; default portfolio
   name **`Test Portfolio 4`** (`{repo}:scripts/seed_all.py:50-66`).
2. **Modernization Corpus portfolio** — `seed_modernization_corpus.py`,
   `PORTFOLIO_NAME = "Modernization Corpus"` (`{repo}:scripts/seed_modernization_corpus.py:46`).

`--reset` deletes each seed's portfolio rows before seeding (idempotent, portfolio-scoped).
Requires `asyncpg` (the script errors out with an install hint if missing,
`{repo}:scripts/seed_all.py:95-102`). DB connection comes from the Makefile-exported
`DATABASE_*` host vars (defaults to `localhost:5432`, user/db `olympus`).

**`make demo-smoke` → `scripts/demo_smoke.py`** (`{repo}:scripts/demo_smoke.py:1-50`): GETs
`/health/ready` (expects 200 + `status=ready`) and `/api/v1/portfolio`, asserting both
`Modernization Corpus` and `$DEMO_PORTFOLIO_NAME` (default `Test Portfolio 4`) exist with
non-empty app counts. Stdlib-only.

**Other seed scripts** (`{repo}:scripts/`, used outside the demo lifecycle): `seed_data.py`,
`seed_admin_user.py`, `seed_skills.py`, `seed_service_tokens.py` (§4), `seed_atlas_challenge.py`,
`seed_atlas_mid_flight.py`, `seed_phase5_testdata.py`, `seed_portfolio_memberships.py`,
`seed_test_portfolio_4_demo_grain.py`, plus shell seeders `seed-aurora.sh`, `seed-aurora-cp4.sh`,
`seed_demo_test_portfolio_4.sh`. SQL seed dump for cloud: `db/seeds/initial-data.sql`
(pg_dump from Postgres 16, imported by `csn-migrate-data`).

---

## Atomic Rebuild Checklist

Ordered, each with an explicit acceptance check. Stop at the first failure.

1. **Recreate root config files.** Restore `docker-compose.yml`, `Makefile`, `.env.example`,
   `.gitleaks.toml`, `.dockerignore`, `.npmrc`, `tsconfig.json`, `package.json`,
   `playwright*.config.ts`, all `.github/workflows/*.yml`, `.github/dependabot.yml`,
   `.github/pull_request_template.md`, the 6 per-service `Dockerfile`s,
   `db/Dockerfile`+`db/requirements.txt`+`db/init/01-create-databases.sh`,
   `infra/temporal/dynamicconfig.yaml`, `infra/haproxy/agent-lb.cfg`, and `vendor/wheels/*.whl`.
   **Accept:** `cp .env.example .env && docker compose config -q` exits 0 (compose file parses,
   all interpolations resolve).
2. **Verify compose service inventory.** **Accept:** `docker compose config --services` lists
   exactly: `postgres redis localstack db-migrate temporal-server temporal-namespace-init
   temporal-ui olympus-api olympus-temporal-worker olympus-dashboard olympus-agent-runtime
   olympus-agent olympus-mcp-server` (13 services).
3. **Build images.** **Accept:** `docker compose build` completes; vendored wheels install
   (`foundry_strands_agents`, `foundry_temporal`, `olympus_contracts`) without reaching
   Artifactory.
4. **Bring the data tier up first.** `docker compose up -d postgres`.
   **Accept:** `docker compose exec postgres psql -U olympus -lqt | cut -d'|' -f1` shows
   `olympus`, `temporal`, `temporal_visibility` (init script ran).
5. **Run migrations.** `docker compose up db-migrate` (one-shot).
   **Accept:** container exits 0; `docker compose exec postgres psql -U olympus -d olympus -c
   "SELECT version_num FROM alembic_version;"` returns the head revision (`057`).
6. **Bring the full stack up.** `make up` (mints `.service-tokens.env`, scales agent LB to 8).
   **Accept:** `.service-tokens.env` exists with `OLYMPUS_AGENT_RUNTIME_TOKEN=` and
   `OLYMPUS_WORKER_TOKEN=`; `docker compose ps` shows api/agent/mcp healthy.
7. **API readiness.** **Accept:** `curl -sf http://localhost:8000/health/ready` returns 200
   (this is the exact gate `make demo-wait` polls).
8. **Temporal + LB health.** **Accept:** `curl -sf http://localhost:8100/lb-health` → `ok`;
   Temporal UI reachable at `http://localhost:8080`; `default` namespace retention = 720h.
9. **Seed + smoke.** `make demo-seed && make demo-smoke`.
   **Accept:** `demo_smoke.py` exits 0 — `Modernization Corpus` and `Test Portfolio 4`
   portfolios both present with non-empty app counts.
10. **Dashboard.** **Accept:** `curl -sf http://localhost:3000` returns 200; the page loads
    against `VITE_API_BASE_URL=http://localhost:8000`.
11. **Schema/contract validators (offline CI invariants).** **Accept:**
    `make validate-schemas` prints `ALL VALIDATIONS PASSED`; `make validate-objectives` exits 0.
12. **CI dry-runs.** **Accept:** branch-naming regex
    `^(phase-[0-9][a-z]|feat|fix|refactor|docs|ci|chore|dependabot|integration)/` matches your
    branch; `gitleaks detect --source=. --config=.gitleaks.toml --no-banner` exits 0;
    per-package `pytest` meets the §6 floors; `cd dashboard && npm run test:coverage` meets the
    dashboard floors; `helm lint infra/helm/olympus-umbrella` and
    `terraform -chdir=infra/terraform/environments/dev-csn-fargate validate` (after
    `init -backend=false`) succeed.
13. **Deploy-path validation (no live cloud).** **Accept:**
    `helm template olympus infra/helm/olympus-umbrella -f infra/helm/olympus-umbrella/values-dev.yaml`
    renders without error; `terraform -chdir=infra/terraform/environments/dev-csn-fargate fmt -check`
    passes. Live deploys require AWS OIDC role `AWS_DEPLOY_ROLE_ARN` + EKS clusters
    (`olympus-{dev,staging,prod}`) or the CSN Fargate cluster `foundry-dev`.
14. **Teardown sanity.** **Accept:** `make down` stops containers preserving volumes;
    `make demo-nuke` (`docker compose down -v`) removes the four named volumes
    (`postgres-data redis-data localstack-data agent-workspace`).
