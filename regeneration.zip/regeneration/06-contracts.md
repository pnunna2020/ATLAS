# 06 — Contracts (Regeneration Specification)

> **Premise.** The current codebase will be deleted. This document is the authoritative
> rebuild source for the **contract layer**: the `olympus-contracts` Python package, every
> JSON Schema under `schemas/`, the schema-validation tooling, the CI enforcement, and the
> OpenAPI surface. "Contracts before code" — these definitions are produced first; all other
> packages (`olympus-api`, `temporal`, `olympus-worker`, `dashboard`, `mcp-server`) depend on
> them and re-export them. Everything below is derived from the actual repo; citations are
> `{repo}:{file}:{line}`.

---

## Part A — `olympus-contracts` Package

The package is a pure-stdlib + PyYAML shared library. It is the **single source of truth** for
domain enums, cross-service signal payloads, Git-service types/errors, and the authoritative
assembly-line contracts. Every consumer installs it editable (`pip install -e ./olympus-contracts`)
and imports from it rather than redefining these types.

### A.1 Package metadata (`pyproject.toml`)

`foundry:olympus-contracts/pyproject.toml:1-23`

- Build backend: `setuptools>=68.0` + `wheel` (`pyproject.toml:1-3`).
- `name = "olympus-contracts"`, `version = "0.3.0"` (`pyproject.toml:6-8`).
  - **Drift note:** `__init__.py` declares `__version__ = "0.2.0"` (`olympus_contracts/__init__.py:62`)
    while `pyproject.toml` says `0.3.0`. On rebuild, reconcile these — make `__version__` match the
    project version (recommend `0.3.0`).
- `requires-python = ">=3.11"` (`pyproject.toml:9`). The code uses `enum.StrEnum` (3.11+) and
  PEP 604 unions.
- Single runtime dependency: `pyyaml>=6.0` (`pyproject.toml:10`).
- Ruff config: `target-version = "py311"`, `line-length = 100`, lint selects `["E","F","I","W"]`
  (`pyproject.toml:12-17`).
- Package discovery: `include = ["olympus_contracts*"]` (`pyproject.toml:19-20`).
- **Package data (critical):** `olympus_contracts = ["data/assembly-lines/*.yaml"]`
  (`pyproject.toml:22-23`). The 10 assembly-line YAML files MUST ship inside the wheel — the loader
  reads them via `importlib.resources` at runtime. If they are not packaged, `_load_all()` raises
  `RuntimeError` (`olympus_contracts/assembly_lines.py:322-326`).
- Lockfile present: `olympus-contracts/uv.lock` (managed by `uv`).

### A.2 Public surface (`__init__.py`)

`foundry:olympus-contracts/olympus_contracts/__init__.py:1-108`

The package re-exports symbols from four submodules. `__all__` (lines 64-107) is the contract of
public names. The complete export set:

- **From `assembly_lines`** (`__init__.py:9-27`): `AgentContract`, `GateRef`, `LineContract`,
  `RepoAccess`, `RetryPolicy`, `SideEffect`, `StepContract`, `StepIO`, `discovery_passes`,
  `get_line`, `get_step`, `line_names`, `list_lines`, `pass_order`, `skill_for_step`,
  `step_progress`, `step_weights`.
- **From `enums`** (`__init__.py:28-42`): `GATE_ASSEMBLY_LINES`, `GATE_FRIENDLY_NAMES`,
  `Archetype`, `AssemblyLine`, `AssemblyLineName`, `ComplexityTier`, `Disposition`, `GateStatus`,
  `GateType`, `RiskTier`, `TierSource`, `gate_assembly_line`, `gate_friendly_name`.
- **From `errors`** (`__init__.py:43-47`): `MergeBranchProtectionRejected`, `MergeConflict`,
  `MergeDivergenceUnresolved`.
- **From `git_types`** (`__init__.py:48-55`): `BRANCH_PATTERN`, `CommitResult`, `FileReadResult`,
  `GitServiceConfig`, `GitServiceError`, `PRResult`.
- **From `signals`** (`__init__.py:56-60`): `GateApprovedSignal`, `GateMergeRetrySignal`,
  `GateRejectedSignal`.

### A.3 Enums (`enums.py`)

`foundry:olympus-contracts/olympus_contracts/enums.py:1-239`. These are "aligned with
`specifications/api/components/schemas.yaml`" (`enums.py:7`). Two deliberate base-class choices
matter: `StrEnum`/`IntEnum` (not `(str, Enum)`/`(int, Enum)`) are used **specifically** because
Temporal's default payload converter special-cases those subclasses for round-tripping across
workflow boundaries (`enums.py:17-22, 35-39, 47-51`). Rebuild MUST preserve these base classes.

| Enum | Base | Values (member = "value") | Cite |
|------|------|---------------------------|------|
| `Disposition` | `StrEnum` | `RETIRE="Retire"`, `RETAIN="Retain"`, `REFACTOR="Refactor"`, `REARCHITECT="Rearchitect"`, `REPLACE="Replace"`, `REPLATFORM="Replatform"`, `CONSOLIDATE="Consolidate"` (7) | `enums.py:15-29` |
| `RiskTier` | `IntEnum` | `TIER_1=1`, `TIER_2=2`, `TIER_3=3` (1=Critical, 2=Standard, 3=Low-Risk) | `enums.py:33-43` |
| `ComplexityTier` | `StrEnum` | `SIMPLE="simple"`, `MODERATE="moderate"`, `COMPLEX="complex"` | `enums.py:46-55` |
| `Archetype` | `StrEnum` | `WEB_APP="web-app"`, `BATCH_ETL="batch-etl"`, `API_SERVICE="api-service"`, `SCHEDULED_JOB="scheduled-job"`, `HYBRID="hybrid"` (set by Rationalization Step 5) | `enums.py:58-69` |
| `TierSource` | `StrEnum` | `AUTO="auto"`, `CONFIRMED="confirmed"`, `OVERRIDDEN="overridden"` | `enums.py:72-77` |
| `GateType` | `StrEnum` | 15 gates (see below); value is the **stable code** used in URLs, commits, schemas, DB columns — must NOT be renamed without migration | `enums.py:80-106` |
| `GateStatus` | `StrEnum` | `PREPARING="preparing"`, `PENDING="pending"`, `APPROVED="approved"`, `REJECTED="rejected"`, `OVERRIDDEN="overridden"`, `ESCALATED="escalated"`, `MERGE_BLOCKED="merge_blocked"` | `enums.py:200-219` |
| `AssemblyLine` | `StrEnum` | 10 lines (see below) | `enums.py:222-234` |
| `AssemblyLineName` | alias | `= AssemblyLine` (backward-compat for API/MCP) | `enums.py:239` |

**`GateType` — the 15 standard gates** (`enums.py:92-106`), member → value:
`G_DC="G-DC"`, `G_RR="G-RR"`, `G_DA="G-DA"`, `G_02="G-02"`, `G_DT="G-DT"`, `G_04A="G-04a"`,
`G_04B="G-04b"`, `G_04C="G-04c"`, `G_DE_1="G-DE-1"`, `G_DE_2="G-DE-2"`, `G_V1="G-V1"`,
`G_V2="G-V2"`, `G_V3="G-V3"`, `G_DP_1="G-DP-1"`, `G_DP_2="G-DP-2"`.

**`AssemblyLine` — the 10 lines** (`enums.py:225-234`): `DISCOVERY="Discovery"`,
`RATIONALIZATION="Rationalization"`, `ARCHITECTURE="Architecture"`, `DATA="Data"`,
`MODERNIZATION="Modernization"`, `DISPOSITION_EXECUTION="Disposition Execution"`,
`VALIDATION="Validation"`, `DEPLOYMENT="Deployment"`, `SUSTAINMENT="Sustainment"`,
`GOVERNANCE="Governance"`.

**`MERGE_BLOCKED` semantics** (`enums.py:204-211`): a *post-decision* state. The reviewer already
approved, but the downstream artifact-repo merge hit a non-retryable condition (one of the three
merge errors below) after retries exhausted. The gate waits in `merge_blocked` until a reviewer
fires a `merge_retry` signal via `POST /gates/{id}/retry-merge`.

#### Gate lookup tables + helpers

- `GATE_FRIENDLY_NAMES: dict[GateType, str]` (`enums.py:122-138`) — plain-English label for each of
  the 15 gates. Must stay in sync with `dashboard/src/data/gateMetadata.ts`,
  `dashboard/src/config/glossary.ts`, and `cross-cutting/gates/README.md` (`enums.py:116-120`). Map:
  G-DC→"Discovery Complete", G-RR→"Portfolio Rationalization Approval", G-DA→"Disposition Plan
  Approval", G-02→"Architecture Alignment Review", G-DT→"Data Architecture Review", G-04a→"Extracted
  Specifications Review", G-04b→"Modernization Design Review", G-04c→"Generated Code Review",
  G-DE-1→"Disposition Execution Plan Approval", G-DE-2→"Decommission Readiness Sign-off",
  G-V1→"Functional Parity Confirmation", G-V2→"Compliance & Security Certification", G-V3→"Safety
  Assurance Sign-off", G-DP-1→"Production Deployment Approval", G-DP-2→"Legacy Decommission
  Authorization".
- `gate_friendly_name(gate_type: GateType | str) -> str` (`enums.py:141-154`) — accepts enum **or**
  raw string; falls back to the raw code for unknown gates (defensive for extension registries).
- `GATE_ASSEMBLY_LINES: dict[GateType, str]` (`enums.py:167-183`) — owning assembly line per gate
  (single source of truth for the API gate service + scoring analytics). Map: G-DC→Discovery,
  G-RR/G-DA→Rationalization, G-02→Architecture, G-DT→Data, G-04a/b/c→Modernization,
  G-DE-1/G-DE-2→"Disposition Execution", G-V1/V2/V3→Validation, G-DP-1/DP-2→Deployment.
- `gate_assembly_line(gate_type: GateType | str) -> str` (`enums.py:186-197`) — accepts enum or
  code; falls back to `"Discovery"` for unknown gates.

### A.4 Signals (`signals.py`)

`foundry:olympus-contracts/olympus_contracts/signals.py:1-99`. Cross-service Temporal signal
payloads (sent by `olympus-api` gate service, received by Temporal workflows). Workflow-*internal*
signals stay in `temporal/olympus_workflows/types.py` (`signals.py:7-9`).

**CRITICAL rebuild constraint** (`signals.py:12-18`): this module MUST NOT use
`from __future__ import annotations`. Temporal's payload converter resolves field types via
`typing.get_type_hints` against module globals; deferred string annotations force `Any` lookups
that fail at runtime with `NameError` in the worker. Keep eager (non-stringized) annotations.

All three are plain `@dataclass` (not frozen):

1. **`GateApprovedSignal`** (`signals.py:24-43`): `gate_id: str`, `approved_by: str`,
   `justification: str = ""`, `card_decisions: List[dict] = field(default_factory=list)`,
   `reviewer_notes: Optional[str] = None`. `card_decisions` entries carry `card_id`,
   `artifact_type`, `decision`, `note`, `ai_pre_review_used` (per-card UI; empty for legacy callers).
2. **`GateRejectedSignal`** (`signals.py:46-68`): `gate_id: str`, `rejected_by: str`, `reason: str`,
   `reason_category: Optional[str] = None`, `card_decisions: List[dict] = field(default_factory=list)`,
   `reviewer_notes: Optional[str] = None`. `reason` always present; `reason_category` is a structured
   category chosen in the Gate Review UI.
3. **`GateMergeRetrySignal`** (`signals.py:71-89`): `gate_id: str`, `retried_by: str`,
   `note: Optional[str] = None`. Emitted by `POST /api/v1/gates/{id}/retry-merge`; workflow's
   `merge_retry` handler flips `_merge_retry_signalled` to re-enter `reconcile_and_merge_pr`.

`__all__` also exports `Any` (`signals.py:94-99`) so future signal additions can use it.

### A.5 Git types (`git_types.py`)

`foundry:olympus-contracts/olympus_contracts/git_types.py:1-61`. Pure-stdlib types shared between
`olympus-api` and `olympus-worker` (the concrete `GitService` lives in `olympus-api`, requires
PyGithub, and is copied into the worker at Docker build time — `git_types.py:1-6`).

- **`BRANCH_PATTERN`** (`git_types.py:13-19`): compiled regex enforcing branch convention
  `olympus/{line}/{app_id}/{step}`:
  ```
  ^olympus/(?P<line>[a-z][a-z0-9-]*)/(?P<app_id>[a-z0-9][a-z0-9-]*)/(?P<step>[a-z0-9][a-z0-9-]*)$
  ```
- **`GitServiceConfig`** `@dataclass` (`git_types.py:22-28`): `token: str`, `repo: str`,
  `base_url: str = "https://api.github.com"`.
- **`PRResult`** `@dataclass` (`git_types.py:31-38`): `pr_number: int`, `pr_url: str`,
  `source_branch: str`, `target_branch: str`.
- **`FileReadResult`** `@dataclass` (`git_types.py:41-47`): `content: str`, `commit_sha: str`,
  `path: str`.
- **`CommitResult`** `@dataclass` (`git_types.py:50-56`): `commit_sha: str`, `path: str`,
  `branch: str`.
- **`GitServiceError(Exception)`** (`git_types.py:59-60`): base exception for all Git-service
  failures.

### A.6 Errors (`errors.py`)

`foundry:olympus-contracts/olympus_contracts/errors.py:1-68`. Three structured merge errors, all
subclassing `GitServiceError` (so legacy `except GitServiceError` still catches them;
`errors.py:23-29`). Their names are listed in
`temporal/olympus_workflows/retry_policies.py`'s `GIT_MERGE_RETRY_POLICY.non_retryable_error_types`
so Temporal short-circuits retry on the non-retryable ones.

| Error | `mergeable_state` | Retryable? | Meaning |
|-------|-------------------|-----------|---------|
| `MergeConflict` | `"dirty"` | **No** | Real content conflicts; needs human resolve+rebase, then `merge_retry` signal (`errors.py:37-46`). |
| `MergeDivergenceUnresolved` | `"behind"` (persists after update-branch) | **Yes** (bounded) | PR behind base, auto-rebase didn't converge — usually a racing merge; outer retry loop resolves (`errors.py:49-58`). |
| `MergeBranchProtectionRejected` | `"blocked"` | **No** | Branch-protection rule automation cannot satisfy (`errors.py:61-68`). |

### A.7 Assembly-Line Contracts (`assembly_lines.py` + `data/assembly-lines/*.yaml`)

`foundry:olympus-contracts/olympus_contracts/assembly_lines.py:1-404`. **The single source of
truth** for every line's steps, skills, artifacts, side-effects, agent contract, retry policy, and
progress weights. The 10 YAML files under `data/assembly-lines/` are authoritative; this module
loads them into **frozen** dataclasses at import time and exposes a small query API. Downstream
consumers (Temporal workflows, API gate service, step-progress calculator, frontend step registry)
read FROM here — hardcoding step lists is forbidden and policed by `test_no_hardcoded_step_lists`
(`assembly_lines.py:1-26`).

The 10 YAML files (`olympus_contracts/data/assembly-lines/`): `architecture.yaml`, `data.yaml`,
`deployment.yaml`, `discovery.yaml`, `disposition-execution.yaml`, `governance.yaml`,
`modernization.yaml`, `rationalization.yaml`, `sustainment.yaml`, `validation.yaml`.

#### Typed models (all `@dataclass(frozen=True, slots=True)`)

- **`RepoAccess`** (`assembly_lines.py:62-69`): `artifact="none"`, `source="none"`, `target="none"`
  (values: `rw`|`ro`|`none`).
- **`AgentContract`** (`:71-77`): `mcp_servers: tuple[str,...]=()`,
  `repos: RepoAccess = field(default_factory=RepoAccess)`.
- **`SideEffect`** (`:79-84`): `target: str` (e.g. `application`, `gate_record`, `artifact-repo`),
  `fields: tuple[str,...]=()`.
- **`StepIO`** (`:87-93`): `artifacts: tuple[str,...]=()`, `context: tuple[str,...]=()`,
  `side_effects: tuple[SideEffect,...]=()`.
- **`RetryPolicy`** (`:96-102`): `category="transient"`, `non_retryable_errors: tuple[str,...]=()`,
  `max_attempts_override: int|None=None`.
- **`GateRef`** (`:105-110`): `id: str`, `label: str=""`.
- **`StepContract`** (`:113-139`): `id`, `label`, `kind` (agent|git|gate|deterministic|code|terminal
  — see test allowlist), `scope`, `sequence: int`, `purpose`, `skills: tuple=()`,
  `agent_role: str|None=None`, `role="analysis"` (analysis|pre-review|rollup|operational),
  `inputs: StepIO`, `outputs: StepIO`, `agent_contract: AgentContract`, `parallel_with: tuple=()`,
  `gate: str|None=None`, `retry_policy: RetryPolicy`, `progress_pct: int|None=None`,
  `progress_weight: float|None=None`, `artifact_filename: str|None=None`, `summary: bool=False`.
- **`LineContract`** (`:142-192`): `name`, `description`, `trigger`, `depends_on: tuple`,
  `gates: tuple[GateRef,...]`, `mode` (per-app|per-wave|per-target-app|continuous),
  `inputs: tuple`, `outputs: tuple`, `steps: tuple[StepContract,...]`. Methods: `step(id)` (raises
  `KeyError`), `step_ids()`, `agent_steps()` (kind==agent), `evidence_steps()` (agent steps whose
  `role in {"analysis","rollup"}` — excludes pre-review/operational), `summary_step()` (the one with
  `summary: true`).

#### Loader + parsing

- `_t(value)` (`:200-206`) normalizes None/list/scalar → tuple.
- `_parse_step_io`, `_parse_agent_contract`, `_parse_retry_policy`, `_parse_gates`, `_parse_step`,
  `_parse_line` (`:209-294`) map YAML dicts → frozen dataclasses; `_parse_gates` accepts either bare
  strings or `{id,label}` dicts.
- `_load_all()` (`:297-327`): `@lru_cache(maxsize=1)`. Reads every `*.yaml` (skips names starting
  with `_`) under `data/assembly-lines` via `importlib.resources.files`. Raises `ValueError` if a
  file lacks top-level `name` or duplicates a line name; raises `RuntimeError` if no contracts found.
  Tests call `_load_all.cache_clear()` between cases.

#### Public query API

- `list_lines() -> tuple[LineContract,...]` sorted by name (`:335-337`).
- `line_names() -> tuple[str,...]` sorted (`:340-342`).
- `get_line(name) -> LineContract` (`:345-352`) — `KeyError` listing known lines if unknown.
- `get_step(line, step_id)` (`:355-357`).
- `skill_for_step(line, step_id) -> str|None` — first skill or None for deterministic steps (`:360-365`).
- `pass_order(line) -> tuple[str,...]` — ordered ids of `evidence_steps()` (the gate-review cards),
  excludes pre-review/operational (`:368-376`).
- `discovery_passes()` — shortcut for `pass_order("Discovery")` (`:379-382`).
- `step_progress(line) -> dict[str,int]` — step_id → progress_pct (`:385-390`).
- `step_weights(line) -> dict[str,float]` — step_id → progress_weight (`:393-403`).

#### YAML schema shape (exemplar: `discovery.yaml`)

`foundry:olympus-contracts/olympus_contracts/data/assembly-lines/discovery.yaml:1-680`. Top-level
keys: `name`, `description`, `trigger`, `depends_on`, `gates` (list of `{id,label}`), `mode`,
`inputs`, `outputs`, `steps`. Each step mirrors `StepContract` exactly: `id`, `label`, `kind`,
`scope`, `sequence`, `progress_pct`, `progress_weight`, `artifact_filename`, `purpose`, `skills`,
`agent_role`, `role`, `inputs.{artifacts,context}`, `outputs.{artifacts,side_effects[].{target,fields}}`,
`agent_contract.{mcp_servers,repos.{artifact,source,target}}`, `parallel_with`, `gate`,
`retry_policy.{category,non_retryable_errors,max_attempts_override}`, `summary`.

Discovery's canonical step set (declaration order, `discovery.yaml:42-679`): `catalog` (seq 1),
`structural-analysis` (seq 2), then the sequence-3 parallel fan-out
[`business-logic-extraction`, `quality-risk-assessment`, `ux-accessibility-assessment`,
`data-domain-discovery`, `shared-database-analysis`, `capability-extraction`], then seq-4
[`synthesis` (`summary: true`), `tco-baseline`], then `commit-artifacts` (git, seq 5), `create-pr`
(git, seq 6), `gate-readiness-check` (agent, `role: pre-review`, `max_attempts_override: 1`, seq 7),
`gate-review` (kind gate, `gate: G-DC`, seq 8). `discovery_passes()` returns the 10-tuple of
analysis/rollup pass ids and **excludes** `gate-readiness-check` (pre-review runs on the PR, not
source).

### A.8 Tests + coverage floor

Three test modules under `olympus-contracts/tests/`:

- **`test_assembly_lines.py`** (`:1-174`) — loader correctness. Notable invariants: every line has
  unique step ids (`:43-48`) and ≥1 step (`:50-52`); every step `kind` ∈
  `{agent, git, gate, deterministic, code, terminal}` (`:54-63`); `line_names()` is sorted
  (`:65-67`); unknown line raises `KeyError` (`:69-71`); `discovery_passes()` equals the exact
  10-tuple `(catalog, structural-analysis, business-logic-extraction, quality-risk-assessment,
  ux-accessibility-assessment, data-domain-discovery, shared-database-analysis, capability-extraction,
  synthesis, tco-baseline)` (`:88-99`); synthesis is the summary step (`:101-105`);
  `gate-readiness-check` is an agent step but NOT a pass (`:107-114`); progress is monotonic
  (`:126-137`); contracts are frozen (`:169-173`).
- **`test_no_hardcoded_step_lists.py`** (`:1-176`) — drift guard. Scans `olympus-api/src`,
  `olympus-worker/src`, `temporal/olympus_workflows` for clusters of ≥5 step-id string literals
  within any 10-line window (`CLUSTER_WINDOW=10`, `CLUSTER_THRESHOLD=5`, `:104-105`). Skips
  `/.venv/`, `/__pycache__/`, `/build/`, `/.agents/`, `/.codex/`, `/tests/`, `/registries/defaults/`.
  Waivers: `# allow: step-list-literal — <reason>` (per-line) or `# allow-file: step-list-literal —
  <reason>` (whole file). Catches the 2026-05-05 bug where a stale `_DISCOVERY_ORDER` literal in
  `gate.py` dropped 4 of 7 gate cards.
- **`test_skill_manifest.py`** (`:1-30+`) — lints every `SKILL.md` under `cross-cutting/skills/`:
  YAML frontmatter parses, required fields (`name`, `description`) present, optional `output_schemas`
  is a list of `{path, schema}` maps, and wired schema paths resolve on disk.

**Coverage floor:** no per-package `--cov-fail-under` is declared in `olympus-contracts/pyproject.toml`
(`pyproject.toml:1-23`). The repo-level CI installs the package editable and runs the test suite per
the Python matrix (Part D). Rebuild should keep these three test modules green; they are the contract
acceptance tests.

> **Extra schemas inside the package.** `olympus-contracts/schemas/` also ships two JSON Schemas
> co-located with the package: `discovery/business-logic.schema.json` and
> `pipeline-execution/step-execution-record.schema.json`. These are distinct from the top-level
> `schemas/` tree (the package copy of `business-logic` may diverge — reconcile on rebuild).

---

## Part B — JSON Schema Inventory

All schemas live under `foundry:schemas/`. **Count: 84 `*.schema.json` files** across 12 subdirs,
plus **24 `*.sample.json`** under `schemas/samples/`. Metaschema varies by file:
`http://json-schema.org/draft-07/schema#` (cross-cutting/design) vs.
`https://json-schema.org/draft/2020-12/schema` (most others). `$id` style also varies:
`https://olympus.framework/schemas/...` (canonical majority), bare relative paths
`schemas/<dir>/<name>.schema.json` (all cross-cutting + design), plus three outliers
(`https://olympus.dev/...` for two modernization schemas, `https://olympus.faa.gov/...` for the
rationalization clustering plan). **Rebuild note:** the inconsistent `$id` host/style is preserved
exactly because the sample-validation step in CI resolves `$ref`s through a store keyed on `$id`
(Part D); changing an `$id` without updating cross-references breaks resolution.

### B.1 `schemas/architecture/` (12)
| File | title |
|------|-------|
| accessibility-review.schema.json | Accessibility Review |
| ai-ml-integration.schema.json | AI/ML Integration Architecture |
| architecture-blueprint.schema.json | Architecture Blueprint |
| architecture-target-plan.schema.json | Architecture Target Plan |
| cloud-pattern.schema.json | Cloud Pattern Selection |
| cost-estimate.schema.json | Cloud Cost Estimate |
| design-system.schema.json | Design System Selection |
| ea-compliance.schema.json | EA Compliance Report |
| integration-arch.schema.json | Integration Architecture / API Contract Compliance |
| security-arch.schema.json | Security Architecture |
| target-application-map.schema.json | Target Application Map |
| well-architected-review.schema.json | Well-Architected Review |

All `$id` = `https://olympus.framework/schemas/architecture/<file>`.

### B.2 `schemas/common/` (4) — shared `$defs` building blocks
| File | title | $id |
|------|-------|-----|
| confidence-level.schema.json | Confidence Level | framework/common/... |
| evidence-reference.schema.json | Evidence Reference | framework/common/... |
| risk-tier-annotation.schema.json | Risk Tier Annotation | framework/common/... |
| traceability-citation.schema.json | Traceability Citation | framework/common/... |

### B.3 `schemas/cross-cutting/` (10) — `$id` is bare relative `schemas/cross-cutting/...`
| File | title |
|------|-------|
| attestation-chain.schema.json | Attestation Chain (3-link) |
| audit-event.schema.json | Audit Event |
| event-envelope.schema.json | Event Envelope |
| journey-fsm.schema.json | Journey FSM Definition |
| metric.schema.json | Metric Registry Entry (`$id` = framework/...) |
| oidc-server-config.schema.json | OIDC Server Configuration |
| rendition-manifest.schema.json | Rendition Manifest (`$id` = framework/...) |
| score-snapshot.schema.json | Score Snapshot (`$id` = framework/...) |
| temporal-workflow-contract.schema.json | Temporal Workflow Contract |
| traceability-report.schema.json | Traceability Report (`$id` = framework/...) |

### B.4 `schemas/data/` (6) — all `$id` = framework/data/...
data-architecture (Data Architecture), data-domains (Data Domain Discovery), data-migration-plan
(Data Migration Plan), data-product-design (Data Product Design), decomposition-strategy
(Decomposition Strategy), shared-db-analysis (Shared Database Analysis).

### B.5 `schemas/design/` (6) — FAA-profile domain; all `$id` bare relative `schemas/design/...`
8710-field-dependency-graph (Form 8710-1 Field Dependency Graph), application-state-machine
(Application State Machine), faa-pilot-cert-domain (FAA Pilot Certification Domain Model),
form-8710-rules (FAA Form 8710 Validation Rules), medical-cert-class (FAA Medical Certification
Class), principal-mapping (JWT Claim → Principal Mapping).
> **VALIDATION GAP (must reproduce or fix):** `schemas/validate.sh` does **not** glob `design/`
> (its per-dir loop omits it — `validate.sh:11`), so `make validate-schemas` skips these 6. CI's
> `check-jsonschema` step DOES cover them via `schemas/**/*.schema.json` (Part D). Decide on rebuild
> whether to add `design/*.schema.json` to validate.sh.

### B.6 `schemas/discovery/` (12) — all `$id` = framework/discovery/...
analysis-report (4-Pass Analysis Report), application-catalog-entry (Application Catalog Entry),
business-logic (Business Logic Inventory), business-rule-inventory (Business Rule Inventory
(Discovery)), capability-catalog (Capability Catalog), catalog (Application Catalog Entry — note same
title as application-catalog-entry), discovery-synthesis (Discovery Synthesis), eligibility-rule-engine
(Eligibility Rule Engine; `$id` bare relative), identity-landscape (Identity Landscape Analysis),
quality-risk (Quality & Risk Assessment), tech-fingerprint (Tech Fingerprint), ux-accessibility
(UX & Accessibility Assessment).

### B.7 `schemas/dispositions/` (8) — all `$id` = framework/dispositions/...
disposition-output (Disposition Output Bundle — the base/envelope), plus 7 per-disposition payloads:
retire-output, retain-output, refactor-output, rearchitect-output, replace-output, replatform-output,
consolidate-output (each "{Disposition} Disposition Output Payload").

### B.8 `schemas/gates/` (3) — all `$id` = framework/gates/...
escalation-record (Escalation Record), gate-evidence-package (Gate Evidence Package),
gate-review-checklist (Gate Review Checklist).

### B.9 `schemas/modernization/` (5)
business-rules (Business Rules Catalog; framework/...), modern-requirements (Modern Requirements
Catalog; **`$id` = olympus.dev/...**), module-map (Module Map; framework/...),
rule-reconciliation-matrix (Business Rule Reconciliation Matrix; **`$id` = olympus.dev/...**),
test-scenarios (Test Scenario Suite; framework/...).

### B.10 `schemas/profiles/` (1)
objectives.schema.json (Agency Objectives; framework/profiles/...). Validated separately by
`scripts/validate_objectives.py` via `make validate-objectives`.

### B.11 `schemas/rationalization/` (17) — all `$id` framework/... except clustering-plan
business-rule-redundancy (Cross-App Business Rule Redundancy), capability-consolidation-plan
(Capability Consolidation Plan), classification (Application Risk Classification),
disposition-governance (Disposition Governance Package), disposition-recommendation (Disposition
Recommendation), integration-graph (Portfolio Integration Graph), portfolio-score (Portfolio Score),
portfolio-target-state-rollup (Portfolio Target-State Rollup), rationalization-clustering-plan
(Rationalization Capability Clustering Plan; **`$id` = olympus.faa.gov/...rationalization-clustering-plan.json**),
redundancy-matrix (Redundancy Matrix), shared-identity-report (Shared Identity Report), tco-analysis
(TCO Analysis), user-impact-analysis (User Impact Analysis), ux-overlap-matrix (UX Overlap Matrix),
wave-outcome-synthesis (Wave Outcome Synthesis), wave-plan-validation (Wave Plan Validation Report),
wave-plan (Wave Modernization Plan).

### B.12 `schemas/samples/` (24 `*.sample.json`)
Each carries a relative `$schema` ref (e.g. `"../dispositions/disposition-output.schema.json"`,
`schemas/samples/disposition-output.sample.json`) and is validated against its referenced schema in
CI. Files: business-rule-inventory, business-rules, consolidate-output, disposition-output,
disposition-recommendation, escalation-record, gate-evidence-package, modern-requirements, module-map,
portfolio-target-state-rollup, rearchitect-output, redundancy-matrix, refactor-output,
rendition-manifest, replace-output, replatform-output, retain-output, retire-output,
rule-reconciliation-matrix, score-snapshot, tech-fingerprint, test-scenarios, traceability-report,
wave-outcome-synthesis (each `.sample.json`).

---

## Part C — Key Schemas In Detail

### C.1 `cross-cutting/event-envelope.schema.json`
`foundry:schemas/cross-cutting/event-envelope.schema.json:1-72`. draft-07; `$id` bare relative;
`additionalProperties: true`. Canonical envelope for domain events emitted via the outbox pattern.
**Required (7):** `event_id` (uuid), `aggregate_id` (str), `aggregate_type` (str), `type` (str,
pattern `^[A-Z][A-Za-z]+$` — PascalCase event name), `version` (int ≥1), `occurred_at` (date-time),
`payload` (object). **Optional:** `actor` (`{kind ∈ {user,system,agent}, id}`), `trace_id`,
`causation_id` (uuid), `correlation_id` (uuid).

### C.2 `cross-cutting/temporal-workflow-contract.schema.json`
`foundry:schemas/cross-cutting/temporal-workflow-contract.schema.json:1-102`. draft-07;
`additionalProperties: true`. Contract for a Temporal v1 workflow. **Required (3):** `name`,
`task_queue`, `activities`. **Properties:** `deterministic_invariants` (array<str>); `signals`
(array of `{name, payload_schema}`, both required); `queries` (array of `{name, return_schema}`,
both required); `activities` (array of `{name, idempotency_key, retry_policy}` all required, plus
optional `compensation: str`). `retry_policy` = `{initial_interval_ms:int, max_attempts:int,
non_retryable_errors: array<str>}`.

### C.3 `dispositions/disposition-output.schema.json` (base/envelope)
`foundry:schemas/dispositions/disposition-output.schema.json:1-125`. draft 2020-12;
`additionalProperties: false`. The "what did this application become" terminal record, one per app.
**Required (12):** `application_id` (uuid), `application_name` (minLength 1), `portfolio_id` (uuid),
`wave_id` (uuid), `disposition` (enum of the 7 dispositions), `status` (enum
`completed|partial|rolled-back|abandoned`), `started_at`, `completed_at` (date-time),
`disposition_decision_ref` (path to Rationalization disposition.json), `approvals`,
`realized_net_impact`, `payload`.
- `approvals` (array, minItems 1): each `{gate ∈ {G-DE-1,G-DE-2,G-04a,G-04b,G-04c,G-V1,G-V2,G-V3,
  G-DP-1,G-DP-2}, approved_at, approved_by, record_ref}` all required, `additionalProperties:false`.
- `realized_net_impact`: `{tco_delta:{annual_savings_usd, one_time_cost_usd, baseline_ref} (each
  nullable, all required), users_affected_actual (int|null), users_affected_estimate_ref (str|null)}`.
- `payload`: discriminated object; `payload.disposition` must equal top-level `disposition`,
  enforced by an `allOf` of 7 `if/then` const-match branches (`:93-123`). Each disposition's payload
  shape is defined in its own `{label}-output.schema.json`.

### C.4 `dispositions/retire-output.schema.json` (example per-disposition payload)
`foundry:schemas/dispositions/retire-output.schema.json:1-68`. draft 2020-12;
`additionalProperties: false`. **Required (6):** `disposition` (`const: "Retire"`),
`decommission_certificate_ref`, `archival`, `consumer_migration`, `license_reclamation_ref`,
`infrastructure_torn_down`.
- `archival`: `{archive_locations (array minItems 1 of {type ∈ {s3,glacier,azure-blob,gcs,tape,
  on-prem-filesystem}, uri, retention_years≥1}), reconstruction_plan_ref, data_archival_plan_ref}`.
- `consumer_migration`: `{consumers_notified≥0, consumers_confirmed_migrated≥0, migration_report_ref}`.
- `infrastructure_torn_down`: array of resource identifier strings (empty for data-only retirement).

### C.5 `gates/gate-review-checklist.schema.json`
`foundry:schemas/gates/gate-review-checklist.schema.json:1-88`. draft 2020-12;
`additionalProperties: false`. **Required (3):** `gate_id` (enum of all 15 gates),
`application_name`, `checklist_items` (minItems 1). Optional: `risk_tier` (int ∈ {1,2,3}),
`overall_verdict` (`approved|rejected|pending`), `reviewer`, `reviewed_at`, `rejection_feedback`.
Each checklist item requires `{id, description, category ∈ {completeness,quality,traceability,
compliance,security,accessibility,safety,performance}, required:bool}`; optional `tier_applicable`
(array of {1,2,3}), `automated_check`, `automated_result ∈ {pass,fail,warning,not_run}`,
`reviewer_verdict ∈ {pass,fail,not_reviewed}`, `reviewer_notes`.

### C.6 `gates/gate-evidence-package.schema.json`
`foundry:schemas/gates/gate-evidence-package.schema.json:1-181`. draft 2020-12;
`additionalProperties: false`. Used across all 15 gates. **Inlines two `$defs`** —
`risk-tier-annotation` and `evidence-reference` — copied from `schemas/common/` (so the file is
self-contained and does not need an external `$ref` resolver). **Required (5):** `gate_id` (15-gate
enum), `application_name`, `prepared_by`, `assembly_line` (enum: `discovery, rationalization,
architecture, data, modernization, disposition-execution, validation, deployment` — lowercase,
8 values), `evidence_items` (minItems 1, each an `evidence-reference`). Optional: `portfolio_id`,
`wave_id`, `prepared_date`, `risk_tier` (`$ref #/$defs/risk-tier-annotation`), `validation_results`
(array of `{check_name, result ∈ {pass,fail,warning,skipped}}` + optional details/threshold/
actual_value), `traceability_score` (`{forward_coverage, backward_coverage, threshold (0-100),
status ∈ {pass,fail}}`), `reviewer_guidance`, `previous_attempts`, `previous_feedback`.
- `evidence-reference` `$def`: required `{title, artifact_path, artifact_type (16-value enum),
  finding_summary, citations (minItems 1)}`; each citation is a `oneOf` of an **artifact** citation
  `{type:"artifact", artifact, section, finding_id (pattern ^[A-Z]{1,5}-[0-9]+$)}` or a **source**
  citation `{type:"source", repository, file, line_start, line_end, commit_sha (^[0-9a-f]{7,40}$)}`.
  `id` pattern `^EVD-[0-9]+$`.
- `risk-tier-annotation` `$def`: required `{tier ∈ {1,2,3}, source ∈ {auto,confirmed,overridden}}`;
  conditional `if source==overridden then require {tier,source,justification,previous_tier}`.

### C.7 `gates/escalation-record.schema.json`
`foundry:schemas/gates/escalation-record.schema.json:1-100`. draft 2020-12;
`additionalProperties: false`. **Required (6):** `id` (pattern `^ESC-[0-9]+$`), `type` (enum:
`ralph_loop_exhausted, gate_rejection, synthesis_conflict, agent_failure, validation_failure,
compliance_block, stakeholder_required, other`), `severity` (`critical|high|medium|low`),
`application_name`, `trigger`, `status` (`open|investigating|resolved`). `trigger` requires
`trigger_type`; optional `details, iteration_count≥0 (Ralph Loop), failing_tests[], error_message`.
`resolution` (optional) requires `{resolver, resolution_type ∈ {re_extract, manual_augment,
re_disposition, manual_override, selective_reanalysis, reclassify, accepted, other}}` + optional
`description, resolved_at`. Optional `pattern_extracted:bool`, `pattern_id`.

### C.8 `discovery/discovery-synthesis.schema.json`
`foundry:schemas/discovery/discovery-synthesis.schema.json:1-113`. draft 2020-12;
`additionalProperties: true` (lenient — synthesis is the rollup the G-DC reviewer reads).
**Required (2 only):** `application_id` (minLength 1), `summary`. Notable properties: `input_passes`
(status map of upstream passes), `scope_caveat`, `summary.{system_classification,
high/medium/low_confidence_findings}` (each `oneOf` int|array), `per_module_view[]` (each requires
`module_id`), `contradictions[]` (each requires `id`; `claim_a/claim_b` oneOf string|object),
`confidence_scores`, `open_questions[]`, `downstream_consumer_summary`.

> The `discovery/catalog.schema.json` (title "Application Catalog Entry",
> `$id` framework/discovery/catalog) and `discovery/application-catalog-entry.schema.json` (same
> title) are two distinct files with overlapping intent — preserve both; the loader/skills reference
> them by path, and they back the `catalog` step's `application-catalog-entry` + `tech-fingerprint`
> outputs (`discovery.yaml:54-70`).

---

## Part D — Validation + CI Enforcement

### D.1 `schemas/validate.sh`
`foundry:schemas/validate.sh:1-71`. Bash, `set -e`. Two-phase shape check (NOT full metaschema —
that is CI's job via `check-jsonschema`):
1. **Schema shape** (`:10-34`): for each `*.schema.json` in the explicit per-dir glob list
   (`common, discovery, rationalization, architecture, data, modernization, gates, cross-cutting,
   profiles, dispositions` — note `design/` and `samples/` excluded, `:11`), a Python one-liner
   asserts valid JSON and presence of `$schema`, `$id`, `title`, `description`. Missing any → FAIL.
2. **Sample shape** (`:37-55`): every `samples/*.sample.json` must be valid JSON and carry a
   `$schema` reference.
3. **Summary** (`:57-70`): counts `*.schema.json` (excluding `samples/`) and `*.sample.json`, prints
   `Schemas:`, `Samples:`, `Errors:`; exits 1 if any error. (Counts ALL schema dirs including
   `design/` here even though the shape loop skipped `design/` — so the printed schema count is 84.)

### D.2 `Makefile`
`foundry:Makefile:117-124`. Targets:
- `validate-schemas:` → `@bash schemas/validate.sh` (`Makefile:120-121`).
- `validate-objectives:` → `@$(PYTHON) scripts/validate_objectives.py` (`Makefile:123-124`); also a
  prerequisite of `render-exec` / `render-exec-generic` (`Makefile:131,134`).
Both are in `.PHONY` (`Makefile:41`).

### D.3 CI — `.github/workflows/ci.yml`
`foundry:.github/workflows/ci.yml`. A `preflight` job classifies changed paths into boolean outputs
that gate every downstream job (`ci.yml:160-205`). Relevant flags:
- `CONTRACTS_CHANGED` = match `^schemas/|^specifications/api/|^olympus-contracts/` (`ci.yml:160`).
- `CONTRACTS_PKG_CHANGED` = match `^olympus-contracts/` (`ci.yml:171`).
- `SHARED_PYTHON` includes `^olympus-contracts/` (flips every Python package's flag) (`ci.yml:181`).

**Job: `Validate Contracts`** (`ci.yml:240-321`), runs when `contracts_changed == true`:
1. **OpenAPI lint** (`:256-258`): `npx @redocly/cli lint specifications/api/openapi.yaml` (only if
   that file exists).
2. **OpenAPI bundle + re-lint** (`:260-264`): `redocly bundle … -o openapi.bundled.yaml` then lint
   the bundle.
3. **JSON-schema metaschema validation** (`:266-277`): `pip install check-jsonschema jsonschema`,
   then loop `for schema in schemas/**/*.schema.json` running `check-jsonschema --check-metaschema`.
   This DOES cover `design/` (unlike validate.sh).
4. **Sample validation** (`:279-321`): a Python block builds a `store` of every schema keyed by `$id`,
   then for each `schemas/samples/*.json` pops its relative `$schema`, loads the referenced schema,
   and validates with `jsonschema.Draft202012Validator` + `RefResolver(base_uri=$id, store=store)`.
   Any error → exit 1. (This is why every schema needs a unique, stable `$id` and every sample needs
   a resolvable relative `$schema`.)

**Job: `Step Registry Consistency`** (`ci.yml:368-385`) — `pip install -e olympus-contracts` then
`python3 scripts/verify_step_registry.py` (frontend ↔ backend step parity).

**Job: line-contract sequence validation** (`ci.yml:427-428`) —
`node dashboard/scripts/parse-line-contracts.mjs --validate-only`.

**Python matrix + profile-portability** (`ci.yml:430-633`) — multiple jobs `pip install -e
./olympus-contracts` (e.g. `:456, :537, :633`) before running their pytest suites; the contracts
package tests (Part A.8) run here when `contracts_pkg_changed`/shared-python flips. `profile-portability`
(`ci.yml:430-467`) runs `pytest tests/test_generic_profile_portability.py` with
`AGENT_RUNTIME_MODE=mock`.

Other related jobs: `Skill Catalog Consistency` (`:323-340`, `scripts/validate_skill_registry.py`),
`Agency Objectives Consistency` (`:342-366`, `scripts/validate_objectives.py` +
`tests/test_validate_objectives.py`), `SQL Schema Drift` (`:387-407`, `scripts/verify_sql_schema.py`).

---

## Part E — OpenAPI

Olympus has **two** OpenAPI surfaces; rebuild both and keep them aligned.

### E.1 Authoritative spec (design-time, multi-file) — `specifications/api/`
`foundry:specifications/api/openapi.yaml` (`openapi: 3.0.3`, `info.title: "Olympus Platform API"`,
`info.version: 0.1.0`, server `/api/v1`, security `BearerJWT`, `openapi.yaml:1-22`). It is a
**multi-file** spec: paths/operations are split into `specifications/api/domains/*.yaml` (18 files:
agents, analytics, applications, artifacts, auth, escalations, events, gates, governance, lines,
portfolio, profiles, registries, skills, system, users, waves, webhooks) referenced via `$ref`
(~220 `$ref`s). Shared components live in `specifications/api/components/{schemas,parameters,
responses}.yaml`. `components/schemas.yaml` is the alignment target for `olympus_contracts.enums`
(`enums.py:7`). CI lints the raw spec and the bundled output with Redocly (Part D.3).

### E.2 Runtime spec (generated by FastAPI) — `olympus-api`
`foundry:olympus-api/src/main.py:146-151`. The app instantiates
`FastAPI(title="Olympus API", description="Olympus platform backend — portfolio management and
orchestration", version=config.version, lifespan=_lifespan)`. FastAPI auto-generates the runtime
OpenAPI JSON at `/openapi.json` (plus `/docs`, `/redoc`); these three paths are exempted from
rate limiting (`olympus-api/src/middleware/rate_limit.py:112`). Routers are mounted under `/api/v1`
(`main.py:176+`). Pydantic models under `olympus-api/src/models/` are written to "match the OpenAPI
component schemas" (`models/__init__.py:1`, `models/common.py:1`) so the generated runtime schema and
the design-time spec converge. Typed response models are declared on routes to enrich the generated
schema (e.g. disposition-output bundle `routers/applications.py:734`, portfolio rollup
`routers/portfolio.py:249-252`; the discriminated disposition payload uses a `Literal` tag so
FastAPI renders the `oneOf` — `models/disposition_output.py:17`).

---

## Atomic Rebuild Checklist

Ordered, each with an explicit acceptance check. Do them in sequence.

1. **Scaffold the `olympus-contracts` package.** Create `olympus-contracts/pyproject.toml` exactly
   per Part A.1 (setuptools backend, `requires-python>=3.11`, dep `pyyaml>=6.0`, package-data
   `data/assembly-lines/*.yaml`, ruff E/F/I/W line-length 100). Reconcile version to `0.3.0` in both
   `pyproject.toml` and `__init__.__version__`.
   **Accept:** `python -c "import tomllib,pathlib; tomllib.loads(pathlib.Path('olympus-contracts/pyproject.toml').read_text())"` succeeds.

2. **Write `enums.py`.** All 9 enums + 2 lookup dicts + 2 helper functions per Part A.3. Preserve
   `StrEnum`/`IntEnum` bases.
   **Accept:** `python -c "from olympus_contracts.enums import *; assert len(list(Disposition))==7 and len(list(GateType))==15 and len(list(AssemblyLine))==10 and gate_friendly_name('G-DC')=='Discovery Complete' and gate_assembly_line('G-V1')=='Validation'"`.

3. **Write `git_types.py` then `errors.py`.** `BRANCH_PATTERN` regex + 5 dataclasses + base
   `GitServiceError`; then 3 merge-error subclasses.
   **Accept:** `python -c "from olympus_contracts.git_types import BRANCH_PATTERN; assert BRANCH_PATTERN.match('olympus/discovery/app-1/catalog') and not BRANCH_PATTERN.match('bad/branch'); from olympus_contracts.errors import MergeConflict; from olympus_contracts.git_types import GitServiceError; assert issubclass(MergeConflict, GitServiceError)"`.

4. **Write `signals.py`.** 3 signal dataclasses. **MUST NOT** add `from __future__ import
   annotations`.
   **Accept:** `grep -L 'from __future__' olympus-contracts/olympus_contracts/signals.py` lists the
   file (i.e. the import is absent), and `python -c "from olympus_contracts.signals import GateApprovedSignal; GateApprovedSignal(gate_id='g',approved_by='u')"` succeeds.

5. **Write the 10 assembly-line YAML files** under `olympus_contracts/data/assembly-lines/` and the
   `assembly_lines.py` loader (frozen dataclasses + query API per Part A.7).
   **Accept:** `find olympus-contracts/olympus_contracts/data/assembly-lines -name '*.yaml' | wc -l`
   == `10`; then `python -c "from olympus_contracts.assembly_lines import line_names, discovery_passes; assert len(line_names())==10 and list(line_names())==sorted(line_names()); assert discovery_passes()==('catalog','structural-analysis','business-logic-extraction','quality-risk-assessment','ux-accessibility-assessment','data-domain-discovery','shared-database-analysis','capability-extraction','synthesis','tco-baseline')"`.

6. **Write `__init__.py`** re-exporting the full `__all__` (Part A.2).
   **Accept:** `pip install -e ./olympus-contracts` then
   `python -c "import olympus_contracts as o; [getattr(o,n) for n in o.__all__]"` raises nothing.

7. **Add the 3 contract test modules** (`test_assembly_lines.py`, `test_no_hardcoded_step_lists.py`,
   `test_skill_manifest.py`).
   **Accept:** `pytest olympus-contracts/tests -q` is green (or, if downstream package dirs the drift
   guard scans do not yet exist, that test no-ops cleanly).

8. **Recreate the `schemas/` tree.** Produce all **84** `*.schema.json` across the 12 subdirs and
   **24** `*.sample.json` under `samples/`, with the `$id`/title values in Part B and the detailed
   shapes in Part C for the 8 key schemas. Preserve the exact `$id` hosts/styles (framework / dev /
   faa.gov / bare-relative) and metaschema drafts noted.
   **Accept:** `find schemas -name '*.schema.json' | wc -l` == `84` **and**
   `find schemas/samples -name '*.sample.json' | wc -l` == `24`.

9. **Restore `schemas/validate.sh` + `Makefile` targets** (Part D.1–D.2). Decide whether to close the
   `design/` gap; if reproducing as-is, leave `design/` out of the shape loop.
   **Accept:** `bash schemas/validate.sh` exits 0 and prints `ALL VALIDATIONS PASSED` with
   `Schemas: 84` and `Samples: 24`; `make validate-schemas` exits 0.

10. **Full metaschema + sample validation (CI parity).** Install `check-jsonschema jsonschema`; run
    `for s in schemas/**/*.schema.json; do check-jsonschema --check-metaschema "$s"; done`, then run
    the sample-resolution Python block from `ci.yml:283-321`.
    **Accept:** every schema passes `--check-metaschema` (covers `design/` too) and every
    `samples/*.sample.json` validates against its `$schema`-referenced schema via the `$id`-keyed
    `RefResolver` store, exit 0.

11. **Reproduce the design-time OpenAPI spec** under `specifications/api/` (root `openapi.yaml` 3.0.3
    + 18 `domains/*.yaml` + 3 `components/*.yaml`).
    **Accept:** `npx @redocly/cli lint specifications/api/openapi.yaml` passes; `redocly bundle … -o
    openapi.bundled.yaml && redocly lint openapi.bundled.yaml` passes.

12. **Wire the FastAPI runtime OpenAPI** (`olympus-api/src/main.py` `FastAPI(title="Olympus API", …)`)
    and ensure Pydantic `models/` match the component schemas.
    **Accept:** booting the app and `GET /openapi.json` returns HTTP 200 with `info.title ==
    "Olympus API"` and paths mounted under `/api/v1`.

13. **Wire CI** (`.github/workflows/ci.yml`): `preflight` path classification + the `Validate
    Contracts`, `Step Registry Consistency`, line-contract validation, and Python-matrix jobs that
    `pip install -e ./olympus-contracts`.
    **Accept:** a PR touching `schemas/` triggers `Validate Contracts`; a PR touching
    `olympus-contracts/` flips `contracts_pkg_changed` and runs the contracts test job — both green.
