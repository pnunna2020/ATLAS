# Regeneration Goal

> Reference this file from Claude Code's `/goal` feature to keep the typed prompt short.
> Everything below is the full goal definition.

GOAL: Produce a complete, atomic-level regeneration specification for the entire Foundry
(Olympus) repository — a spec detailed enough that an engineering team (human or AI) could
rebuild this solution from scratch, as-is, without access to the current source code.

## Premise
Assume the current codebase will be deleted. The ONLY surviving artifact is the spec you
produce. Anything not captured is lost forever. Optimize for completeness and precision over
brevity. When in doubt, over-specify.

## Scope — every layer must be covered
1. **Services & runtime** — olympus-api (FastAPI), olympus-worker (Temporal worker),
   olympus-agent-runtime (live|mock modes), mcp-server, olympus-cli, olympus-contracts.
   For each: responsibilities, entry points, env vars, ports, startup/shutdown, dependencies,
   internal module structure, and how it is tested (coverage floors included).
2. **Temporal orchestration** — every workflow and activity (e.g. WaveRationalizationWorkflow,
   WaveWorkflow), signal-based gates, fan-out/synthesize patterns, cron schedules, task queues,
   retry/timeout policies, and the registry substrate in temporal/olympus_workflows/registries/.
3. **The 6 extension points** — Assembly Line, Disposition Strategy, Analysis Pass, Scoring
   Dimension, Gate Provider, Skill Composition. Document each registry's interface, contract,
   and how extensions plug in.
4. **Data layer** — PostgreSQL + JSONB query schema, every table/index/migration, the
   Git-as-source-of-truth model, and how PG is rebuilt from Git (it is derived/disposable).
5. **Web interface** — dashboard/ (React + USWDS + Vite). Every page, route, component,
   state model, API calls consumed, and the visual/branding system. Capture the design tokens,
   layout, and USWDS usage precisely enough to reproduce the look.
6. **Contracts** — all OpenAPI specs, JSON schemas (schemas/), and Temporal interface
   definitions. These are authoritative: contracts-before-code.
7. **Assembly lines & cross-cutting concerns** — the 10 assembly lines, 11 cross-cutting
   concerns, the FAA profile, the 7 dispositions, 3 risk tiers, 15 gates, the
   Extract→Design→Generate factory (incl. the Ralph Loop), and the 137-skill registry model.
8. **Build, CI, and tooling** — Makefile targets (make up / demo-up / reset, etc.),
   docker-compose stack, CI validation (branch naming, schema validation, lint, tests,
   secrets scan), and the contributor workflow.

## Required output structure
Write the spec under specifications/regeneration/ as a navigable set of documents:
- 00-overview.md — system map, the four pillars, dependency graph, glossary pointers
- One document per service / subsystem (numbered), each ending with an "atomic rebuild
  checklist" — an ordered, verifiable list of build steps with acceptance criteria.
- A contracts appendix that inlines or references every schema and API spec.
- A "regeneration order" document: the exact sequence to rebuild in, with the validation
  gate that proves each layer is correct before moving on.

## Definition of "atomic"
Each unit of work in the spec must be: independently buildable, independently testable, and
paired with an explicit acceptance check (a command to run or an artifact to inspect that
proves it was rebuilt correctly). No step should assume tribal knowledge.

## Method
- Derive everything from the actual repository state — read the code, contracts, schemas,
  Makefile, CI config, and existing specs. Do NOT invent behavior; cite sources using the
  repo's citation format ({repo}:{file}:{line} or {artifact}:{section}:{finding-id}).
- Where the current implementation and the written specs disagree, document BOTH and flag the
  drift — the regeneration spec should describe what the system actually does.
- Reuse and reference existing material in specifications/, assembly-lines/, cross-cutting/,
  and profiles/ rather than duplicating it; the regeneration spec is the connective tissue
  that makes those reproducible.

## Done when
A reader with no prior exposure to Foundry could, using only specifications/regeneration/,
rebuild each service, pass its tests at the documented coverage floors, bring up the full
docker-compose stack via the documented commands, and reproduce the dashboard and Temporal
workflows behaviorally identically to today.
