# Regeneration Specification 01 — `olympus-api` Service

> **Premise.** The current codebase will be deleted. This document is the sole surviving
> artifact for rebuilding the `olympus-api` FastAPI service, behaviorally identical, from
> scratch. Everything here is derived from the repo. Citations use the format
> `{repo}:{file}:{line}` where `{repo}` is `olympus-api` unless otherwise noted.
>
> **Repo root for this service:** `/Users/pnunna/Documents/GitHub/foundry/olympus-api`

---

## 1. Service Responsibilities & Identity

`olympus-api` is the FastAPI backend for the Olympus modernization platform. It provides:

- Portfolio / application / wave / gate CRUD and orchestration control surfaces.
- Six extensibility registries (assembly-lines, disposition-strategies, analysis-passes,
  scoring-dimensions, gate-providers, skill-compositions) consumed read-mostly from a
  Temporal-package registry (`olympus-api/src/routers/registries.py:1`).
- Skill registry bootstrap from `SKILL.md` files into Postgres at startup.
- Analytics / scoring, traceability, governance sweeps, escalations.
- Auth (local password + OIDC + service tokens), RBAC, portfolio membership.
- Real-time event fan-out (WebSocket + SSE), chat over evidence (Bedrock), GitHub webhooks.
- Human-paired-agent task inbox + strict output-spec validation.

Service identity defaults (`olympus-api/src/config.py:18-24`):

| Field | Default |
|---|---|
| `service_name` | `olympus-api` |
| `version` | `0.1.0` |
| `log_level` | `INFO` |
| `api_port` | `8000` |

The package is named `olympus-api`, version `0.1.0`, requires **Python >= 3.13**
(`olympus-api/pyproject.toml:6-9`). The runtime Docker image uses **python:3.14-slim**
(`olympus-api/Dockerfile:3`).

---

## 2. Entry Point, App Factory & Lifecycle

### 2.1 Entry point

Run locally with (`olympus-api/src/main.py:3-4`):

```
uvicorn src.main:create_app --factory --reload --port 8000
```

Container CMD (`olympus-api/Dockerfile:38`):

```
uvicorn src.main:create_app --factory --host 0.0.0.0 --port 8000
```

### 2.2 App factory — `create_app()` (`olympus-api/src/main.py:138-221`)

Ordered steps inside `create_app`:

1. `config = AppConfig()` — loads env + `.env` (`main.py:140`).
2. `_configure_logging(config.log_level)` — structlog with stdlib integration, ISO
   timestamps, ConsoleRenderer (`main.py:66-86`, called `main.py:141`).
3. `init_db(config)` — **must run before lifespan** (`main.py:144`; see §4).
4. Construct `FastAPI(title="Olympus API", description="Olympus platform backend — portfolio
   management and orchestration", version=config.version, lifespan=_lifespan)`
   (`main.py:146-151`).
5. Register middleware (registration order, outermost first):
   `CORSMiddleware → RequestIdMiddleware → RateLimitMiddleware → MetricsMiddleware`
   (`main.py:161-170`). CORS uses `allow_origins=config.cors_origins`,
   `allow_credentials=True`, `allow_methods=["*"]`, `allow_headers=["*"]`.
   The documented intended effective request flow is
   `CORS → RequestId → RateLimit → Metrics → routes` (`main.py:153-160`).
6. `register_error_handlers(app)` (`main.py:173`; see §6.5).
7. Include all routers in the exact order at `main.py:176-219` (see §7 table — order
   matters: `traceability_router` is registered **before** `artifacts_router` so
   `/api/v1/artifacts/stale` matches before `/api/v1/artifacts/{app_id}`, `main.py:196-200`).

### 2.3 Lifespan — `_lifespan` (`olympus-api/src/main.py:89-135`)

On startup, in order:

1. `activate_profile()` — activates the client profile named by env `OLYMPUS_PROFILE`.
   **A missing/invalid profile is FATAL** — the exception is logged
   (`profile_activation.failed`) and re-raised, aborting startup (`main.py:104-108`).
2. Open one DB session via `get_db()`; inside it:
   - `count = await bootstrap_skills(db)` — loads `SKILL.md` files into the DB; on any
     exception logs `skill_bootstrap.failed` and sets `count = 0` (`main.py:111-117`).
   - `hydrate_portfolios_from_db(db)` — logs `portfolio_hydrate.complete`/`.failed`
     (`main.py:118-122`).
   - `break` after the first session (`main.py:123`).
   - If the DB is entirely unavailable, logs `skill_bootstrap.db_unavailable`
     (`main.py:124-125`).
3. `set_skill_count(count)` stores the count in module state (`main.py:127`; see §3).
4. If `count == 0`, logs `startup.no_skills` "system will report as unhealthy"
   (`main.py:129-133`).
5. `yield` (no shutdown teardown logic) (`main.py:135`).

### 2.4 Shared startup state (`olympus-api/src/startup_state.py`)

Module-level `_skill_count: int = 0` with `set_skill_count()` / `get_skill_count()`
(`startup_state.py:8-19`). Exists to avoid circular imports between `main` and routers
(`startup_state.py:1`). Health and metrics endpoints read `get_skill_count()`.

---

## 3. Configuration & Environment Variables

`AppConfig` is a `pydantic_settings.BaseSettings`; env vars load automatically, `.env`
supported (`olympus-api/src/config.py:1-15,74`). Field → env var is the upper-snake of the
field name. Full list (`config.py:18-72`):

| Field | Env var | Default | Notes |
|---|---|---|---|
| `service_name` | `SERVICE_NAME` | `olympus-api` | |
| `version` | `VERSION` | `0.1.0` | |
| `log_level` | `LOG_LEVEL` | `INFO` | |
| `api_port` | `API_PORT` | `8000` | |
| `database_host` | `DATABASE_HOST` | `localhost` | |
| `database_port` | `DATABASE_PORT` | `5432` | |
| `database_name` | `DATABASE_NAME` | `olympus` | |
| `database_user` | `DATABASE_USER` | `olympus` | |
| `database_password` | `DATABASE_PASSWORD` | `olympus_dev` | |
| `temporal_host` | `TEMPORAL_HOST` | `localhost:7233` | |
| `temporal_namespace` | `TEMPORAL_NAMESPACE` | `default` | |
| `temporal_task_queue` | `TEMPORAL_TASK_QUEUE` | `olympus-main` | |
| `temporal_ui_base_url` | `TEMPORAL_UI_BASE_URL` | `http://localhost:8080` | |
| `workflow_staleness_minutes` | `WORKFLOW_STALENESS_MINUTES` | `30` | stale when running + no event for N min and not at a gate |
| `workflow_cancel_grace_seconds` | `WORKFLOW_CANCEL_GRACE_SECONDS` | `30` | |
| `cors_origins` | `CORS_ORIGINS` | `["http://localhost:3000"]` | comma-separated list |
| `redis_url` | `REDIS_URL` | `redis://localhost:6379/0` | |
| `mcp_server_url` | `MCP_SERVER_URL` | `http://localhost:3001` | |
| `github_token` | `GITHUB_TOKEN` | `""` | |
| `github_repo` | `GITHUB_REPO` | `""` | |
| `github_base_url` | `GITHUB_BASE_URL` | `https://api.github.com` | |
| `github_webhook_secret` | `GITHUB_WEBHOOK_SECRET` | `""` | HMAC-SHA256 webhook secret |
| `source_intake_root` | `SOURCE_INTAKE_ROOT` | `/workspace/sources` | unpacked sources under `{root}/{application_id}` |
| `source_intake_max_upload_bytes` | `SOURCE_INTAKE_MAX_UPLOAD_BYTES` | `524288000` (500MB) | |
| `source_intake_s3_region` | `SOURCE_INTAKE_S3_REGION` | `""` | falls back to boto3 chain |

**Database URL composition** (`config.py:76-96`): `get_database_url()` requires
`DATABASE_HOST/NAME/USER/PASSWORD` (non-blank) else raises
`ValueError("Incomplete database config. Missing: ...")`. Password is `quote_plus`-encoded.
Sync URL: `postgresql://{user}:{enc_pw}@{host}:{port}/{name}`.
`get_async_database_url()` replaces scheme with `postgresql+asyncpg://`.

**Env vars read directly via `os.environ` (NOT in `AppConfig`):**

| Env var | Default | Read at | Purpose |
|---|---|---|---|
| `JWT_SECRET` | `olympus-dev-secret` | `middleware/auth.py:26`, `auth/user_tokens.py:46`, `auth/service_tokens.py:47` | JWT signing key |
| `JWT_ALGORITHM` | `HS256` | `middleware/auth.py:27` etc. | |
| `AUTH_SKIP_VERIFICATION` | `true` | `middleware/auth.py:28` | skip signature/exp/aud verification |
| `DEV_AUTH_BYPASS` | `""` (false) | `middleware/auth.py:29` | bypass auth, grant all roles |
| `RATE_LIMIT_ENABLED` | `true` (off in tests) | `middleware/rate_limit.py:105` | |
| `RATE_LIMIT_PER_SERVICE_PER_MIN` | `6000` | `rate_limit.py:106` | |
| `RATE_LIMIT_PER_USER_PER_MIN` | `600` | `rate_limit.py:107` | |
| `RATE_LIMIT_PER_IP_PER_MIN` | `60` | `rate_limit.py:108` | |
| `RATE_LIMIT_WINDOW_SECONDS` | `60` | `rate_limit.py:109` | |
| `RATE_LIMIT_EXEMPT_PREFIXES` | `/health,/system/metrics,/docs,/openapi.json,/redoc` | `rate_limit.py:110-113` | |
| `APP_ENV` | `""` | `rate_limit.py:102`, tests | `test` disables rate limit by default |
| `OLYMPUS_PROFILE` | (profile activation) | `services/profile_activation.py` | which client profile to activate |
| `OLYMPUS_ENVIRONMENT` | `development` | `routers/system.py:90` | reported in `/system/info` |
| `SKILLS_ROOT` | `/app/repo` (in image) | skill bootstrap | root for `SKILL.md` discovery (`Dockerfile:34`) |
| `SERVICE_TOKEN_PROVISIONING_SECRET` | `""` | `routers/auth.py:94` | gate for `/auth/service-token` |
| `OIDC_STATE_TTL` | `300` (sec) | `routers/auth.py:259` | PKCE state expiry |
| `AGENT_RUNTIME_MODE` | (CI sets `mock`) | tests | `ci.yml` env |

Port: the service listens on **8000** (`Dockerfile:36 EXPOSE 8000`, `config.api_port=8000`).

---

## 4. Database Layer (`olympus-api/src/database.py`)

- Async engine via SQLAlchemy 2.x `create_async_engine` with `asyncpg`. Module globals
  `_engine`, `_async_session_factory` initialized lazily by `init_db` (`database.py:20-21`).
- `init_db(config)` (`database.py:24-52`): builds async URL, logs `database.init`, creates
  engine with pool resilience: `pool_pre_ping=True`, `pool_recycle=300`, `pool_timeout=30`,
  `pool_size=5`, `max_overflow=10`. Session factory `async_sessionmaker(_engine,
  expire_on_commit=False)`.
- `get_engine()` returns the engine (health checks) (`database.py:55-57`).
- `get_db()` async generator dependency yields a request-scoped `AsyncSession`; raises
  `RuntimeError("Database not initialised. Call init_db() first.")` if uninitialized
  (`database.py:60-65`).

The service uses **raw SQL via `sqlalchemy.text(...)`** against an externally-managed schema
(tables: `application`, `wave`, `gate`, `system`, `capability`, `capability_lineage`,
`portfolio_membership`, skills, etc.). There are no ORM model classes; schema lives in the
DB migration package (`db/alembic/` per `ci.yml:164`), out of scope for this doc but a hard
dependency. Membership/portfolio resolution queries are in `dependencies.py:202-386`.

---

## 5. Dependency Injection (`olympus-api/src/dependencies.py`)

- `get_config()` — `@lru_cache` singleton `AppConfig` (`dependencies.py:28-31`).
- `get_temporal_client()` — lazily connects a module-cached `temporalio.client.Client` to
  `config.temporal_host`/`namespace` (`dependencies.py:34-43`).
- **Portfolio membership enforcement (Phase 5 W20)** — `portfolio_admin` always bypasses.
  Path-style dependencies (read `{id}` from the URL path, raise 403 `PORTFOLIO_NOT_MEMBER`
  or 404 if entity missing):
  - `require_portfolio_member` (`{portfolio_id}`) (`dependencies.py:76-102`).
  - `require_application_member` (`{app_id}`) (`dependencies.py:136-157`).
  - `require_wave_member` (`{wave_id}`) (`dependencies.py:160-169`).
  - `require_gate_member` (`{gate_id}`) (`dependencies.py:172-181`).
  - `require_system_member` (`{system_id}`) (`dependencies.py:320-329`).
  - `require_capability_member` (`{capability_id}`) (`dependencies.py:332-341`).
  - `require_capability_lineage_member` (`{lineage_id}`) (`dependencies.py:344-353`).
  - Resolver helpers (`verify_*_portfolio_access`) for body/query-sourced IDs, all 403
    via `PORTFOLIO_NOT_MEMBER`, 404 if missing (`dependencies.py:105-133, 184-386`).
  - Gate portfolio resolved via `COALESCE(application.portfolio_id, wave.portfolio_id)`
    (`dependencies.py:373-377`).
  - `filter_portfolio_ids_by_membership` — returns `None` (no filter) for admins, else the
    user's member portfolio ids intersected with candidates (`dependencies.py:389-411`).

The 403 detail shape is `{"code": "PORTFOLIO_NOT_MEMBER", "message": "..."}`
(`dependencies.py:93-102`).

---

## 6. Middleware & Cross-Cutting (`olympus-api/src/middleware/`)

### 6.1 Request ID (`request_id.py`)

`RequestIdMiddleware` (BaseHTTPMiddleware). Reads incoming `X-Request-ID` header or
generates `req-{uuid4hex[:12]}`; stores in `request_id_ctx` ContextVar; sets the same value
on the response `X-Request-ID` header; resets the contextvar in `finally`
(`request_id.py:25-38`). `get_request_id()` accessor (`request_id.py:20-22`).

### 6.2 Rate limit (`rate_limit.py`)

In-process sliding-window limiter keyed by JWT `sub` (decoded **unverified** via
`jwt.get_unverified_claims`) → `service:`/`user:` key by quota tier, else `ip:` from
`X-Forwarded-For` (first hop) or client host (`rate_limit.py:116-152`). Three tiers
(service 6000, user 600, anon-IP 60 per minute by default). Exempt prefixes bypass
entirely. On reject: HTTP 429 with body
`{"error": {"code": "RATE_LIMITED", "message": "...", "details": {"limit": N,
"retry_after": S}, "request_id": ...}}` plus headers `X-RateLimit-Limit`,
`X-RateLimit-Remaining: 0`, `X-RateLimit-Reset`, `Retry-After` (`rate_limit.py:243-267`).
Allowed responses get the three `X-RateLimit-*` headers (`rate_limit.py:270-272`).
Default-off when `APP_ENV=test` or `PYTEST_CURRENT_TEST` present
(`rate_limit.py:101-105`). `_SlidingWindow` uses one deque per key, coarse `Lock`
(`rate_limit.py:155-194`). Test helpers `reload_config()`, `reset_rate_limit_state()`.

### 6.3 Metrics (`metrics.py`)

`MetricsMiddleware` records per-`(method, path_template, status)` counters and per-`(method,
path_template)` duration sum/count in process memory under a `Lock`
(`metrics.py:33-114`). Path template from `request.scope['route'].path`, else `<unmatched>`
(`metrics.py:44-51`). On an exception inside the chain it records a `"500"` and re-raises
(`metrics.py:88-101`). `record_rate_limited()` bumps `_rate_limited_total`. Snapshot via
`collect_metrics()`; `reset_metrics()` for tests. No `prometheus_client` dependency.

### 6.4 Pagination (`pagination.py`)

`PaginationParams(page, per_page)` dataclass with `.offset`. `get_pagination` dependency:
`page` `Query(1, ge=1)`, `per_page` `Query(20, ge=1, le=100)` (`pagination.py:28-33`).
`paginated_response(items, total, params)` returns
`{"data": [...], "pagination": {"page", "per_page", "total", "total_pages"}}`,
`total_pages = max(1, ceil(total/per_page))` (`pagination.py:36-47`).

### 6.5 Error handler (`error_handler.py`)

`register_error_handlers(app)` installs four handlers (`error_handler.py:49-107`). All
responses follow the envelope:

```json
{"error": {"code": "...", "message": "...", "details": {...}, "request_id": "..."}}
```

- `OlympusHTTPException` (subclass of Starlette HTTPException carrying `code` + optional
  `error_details`) → uses its code/message/details (`error_handler.py:20-59`).
- `StarletteHTTPException` → code mapped from status: 400 `BAD_REQUEST`, 401 `UNAUTHORIZED`,
  403 `FORBIDDEN`, 404 `NOT_FOUND`, 409 `CONFLICT`, 422 `VALIDATION_ERROR`, 429
  `RATE_LIMITED`, else `ERROR` (`error_handler.py:61-73`).
- `RequestValidationError` → 422 `VALIDATION_ERROR` with `details.errors`, after stringifying
  non-JSON-serializable `ctx`/`input` values (e.g. UploadFile) (`error_handler.py:75-102`).
- `Exception` (catch-all) → 500 `INTERNAL_ERROR`, logs `unhandled_exception`
  (`error_handler.py:104-107`).

`request_id` in the envelope comes from `get_request_id()` (`error_handler.py:43`).

---

## 7. Auth & RBAC

### 7.1 JWT decode middleware (`middleware/auth.py`)

`CurrentUser(sub, roles: list[RBACRole], claims)` with `has_role(*roles)` (`auth.py:32-41`).
`get_current_user(request)` (`auth.py:52-103`):

- If `DEV_AUTH_BYPASS=true`: returns `CurrentUser(sub="local-dev", roles=all RBACRole,
  claims={"sub":"local-dev","dev_bypass":True})` (`auth.py:61-66`).
- Extract Bearer token from `Authorization`; missing → 401 "Missing authorization token"
  (`auth.py:44-70`).
- Decode with `jose.jwt`; if `AUTH_SKIP_VERIFICATION=true` (default), options disable
  signature/exp/aud verification (`auth.py:73-85`). `JWTError` → 401 "Invalid or expired
  token" (`auth.py:86-88`).
- `sub` defaults to `"anonymous"`; roles parsed from `roles` claim (unknown roles logged and
  dropped); empty → `[VIEWER]` (`auth.py:90-103`).

`require_role(*required_roles)` returns a dependency that 403s
`"Requires one of: [...]"` if the user lacks all (`auth.py:106-119`).

### 7.2 Role enum (`models/common.py:47-57`)

`RBACRole` (str enum): `portfolio_admin`, `portfolio_manager`, `tech_lead`, `arch_lead`,
`compliance_lead`, `operations_lead`, `safety_board`, `viewer`, `service`. (8 human roles +
`service`.)

**Role groups** used across routers (canonical values; defined per-router):

- `VIEWER_PLUS` = all 8 human roles (viewer, tech_lead, arch_lead, compliance_lead,
  operations_lead, safety_board, portfolio_manager, portfolio_admin) (`waves.py:27-36`,
  `gates.py`).
- `REVIEWER_ROLES` = VIEWER_PLUS minus `viewer` (i.e. tech/arch/compliance/operations/
  safety/manager/admin) (`gates.py`).
- `MANAGER_ROLES` / `MANAGER_PLUS` = `[portfolio_manager, portfolio_admin]`
  (`waves.py:38-41`, `governance.py`).
- `ADMIN_ROLES` = `[portfolio_admin]` (`waves.py:43-45`).
- `TECH_PLUS` = `[tech_lead, portfolio_manager, portfolio_admin]` (`artifacts.py`).
- `RESOLVER_ROLES` = `[tech_lead, portfolio_manager, portfolio_admin]` (`escalations.py`).
- `CLEAR_HISTORY_ROLES` = VIEWER_PLUS minus `viewer` (`chat.py`).
- `SERVICE_ONLY` = `[RBACRole.SERVICE]` (`agents.py`).

### 7.3 Token minting

- **Service tokens** (`auth/service_tokens.py`): `issue_service_token(service, ttl=3600)`.
  Known identities `("agent-runtime", "worker")`; unknown → `ValueError`. Payload:
  `sub="service:{service}"`, `roles=["service"]`, `iat`, `exp`, `service`. Signed with
  `JWT_SECRET`/`JWT_ALGORITHM` (`service_tokens.py:18-49`).
- **User tokens** (`auth/user_tokens.py`): `issue_user_token(user_id, username, roles,
  identity_provider, ttl=28800)` (8h). Payload: `sub=str(user_id)`, `username`, `roles`,
  `identity_provider`, `iat`, `exp` (`user_tokens.py:18-48`).

---

## 8. Routers (`olympus-api/src/routers/`)

36 router modules; `main.py` mounts them in the order at `main.py:176-219`. Auth column:
`role:GROUP` = `require_role(*GROUP)` on the handler; `member:KIND` =
`dependencies=[Depends(require_*_member)]` path-level; `user` = `get_current_user` only;
`none` = unauthenticated. Unless noted, every router applies the standard middleware chain.

### 8.1 Health & System (unauthenticated probes)

`health.py` — no prefix, tag `health` (`health.py:25`):

| Method | Path | Returns |
|---|---|---|
| GET | `/health` | `{status:ok, service, version, timestamp}` (`health.py:33-41`) |
| GET | `/health/detailed` | DB + Temporal + skills deps, overall `ok`/`degraded` (`health.py:44-87`) |
| GET | `/health/temporal` | Temporal connectivity (`health.py:90-111`) |
| GET | `/health/ready` | `ready`/`not_ready` (Temporal + skills) (`health.py:114-145`) |

`system.py` — no prefix, tag `System` (`system.py:41`):

| Method | Path | Returns |
|---|---|---|
| GET | `/health/live` | liveness, process-only (`system.py:56-68`) |
| GET | `/system/info` | `{version, profile, deployment, temporal_namespace, service, timestamp}` (`system.py:76-99`) |
| GET | `/system/metrics` | Prometheus exposition text (`text/plain; version=0.0.4`) (`system.py:164-173`) |
| GET | `/system/dependencies` | richer deps incl. Temporal UI URL (`system.py:181-229`) |

Prometheus metrics emitted (`system.py:107-161`): `olympus_api_info{service,version}`,
`olympus_api_uptime_seconds`, `olympus_api_skills_loaded`,
`olympus_api_requests_total{method,path,status}`,
`olympus_api_request_duration_seconds_{sum,count}{method,path}`,
`olympus_api_rate_limited_total`.

### 8.2 Auth (`auth.py`, prefix `/api/v1/auth`, tag `Auth`)

| Method | Path | Auth | Model / Behavior |
|---|---|---|---|
| POST | `/service-token` | none | `ServiceTokenRequest`→`ServiceTokenResponse`; checks `SERVICE_TOKEN_PROVISIONING_SECRET` (401), validates identity (400) (`auth.py:91-107`) |
| POST | `/login` | none | `LoginRequest`→`TokenResponse`; rejects non-local IdP (401 `SSO_USER`), bad creds (401 `INVALID_CREDENTIALS`) (`auth.py:129-158`) |
| POST | `/logout` | none | `{"success": true}` stateless (`auth.py:161-168`) |
| GET | `/me` | user | `UserProfile` (synthesizes for service/dev-bypass) (`auth.py:176-212`) |
| GET | `/config` | none | `AuthModeConfig` (local/oidc flags) (`auth.py:220-237`) |
| GET | `/oidc/login` | none | OIDC auth-code + PKCE start (`auth.py:287-307`) |
| GET | `/oidc/callback` | none | OIDC callback, mints user token (`auth.py:308-404`) |
| GET | `/roles` | role:PORTFOLIO_ADMIN | list roles (`auth.py:405-416`) |
| GET | `/users` | role:PORTFOLIO_ADMIN | list auth users (`auth.py:417-436`) |
| PUT | `/users/{user_id}/roles` | role:PORTFOLIO_ADMIN | `UserProfile` (`auth.py:437-...`) |

OIDC PKCE state held in-memory `_OIDC_STATES`, TTL `OIDC_STATE_TTL` (default 300s)
(`auth.py:259-...`). Calls `services/oidc.py`, `services/identity_config.py`,
`services/user.py`, `services/password.py`.

### 8.3 Portfolio / Profiles / Me / Members

`portfolio.py` (prefix `/api/v1/portfolio`, tag `portfolio`):

| Method | Path | Auth | Service |
|---|---|---|---|
| POST | `` | user | `services/portfolio.py` (201, `PortfolioDetail`) (`portfolio.py:85-...`) |
| GET | `` | user | `list[PortfolioListItem]` (`portfolio.py:166-...`) |
| GET | `/{portfolio_id}` | user | `PortfolioDetail` (`portfolio.py:211-...`) |
| GET | `/{portfolio_id}/target-state-rollup` | user | `services/target_state_rollup.py` (`portfolio.py:247-...`) |

`hydrate_portfolios_from_db(db)` (called by lifespan) and `find_portfolio_by_repo` are
module functions (`portfolio.py:43, 280`).

`profiles.py` — two routers: `/api/v1/profiles` (tag `profiles`) and
`portfolio_profile_router` `/api/v1/portfolio` (tag `portfolio`):

| Method | Path | Auth |
|---|---|---|
| GET | `/api/v1/profiles` | none — `list[ProfileSummary]` (`profiles.py:267`) |
| GET | `/api/v1/profiles/active` | none — `ActiveProfileResponse` (`profiles.py:306`) |
| GET | `/api/v1/profiles/compare` | none — `ProfileComparisonResponse` (`profiles.py:315`) |
| GET | `/api/v1/profiles/{profile_id}` | none — `ProfileDetail` (`profiles.py:343`) |
| GET | `/api/v1/portfolio/{portfolio_id}/profile-bundle` | user (`profiles.py:565-572`) |
| PUT | `/api/v1/portfolio/{portfolio_id}/profile` | user — switch profile (`profiles.py:703-708`) |

`me.py` (prefix `/api/v1/me`, tag `Me`): GET `/portfolios` → `list[MyPortfolioListItem]`
(user) (`me.py:30-31`).

`portfolio_members.py` (prefix `/api/v1/admin`, tag `Admin`) — all
`role:PORTFOLIO_ADMIN`:

| Method | Path |
|---|---|
| GET | `/portfolios/{portfolio_id}/members` (`portfolio_members.py:39-43`) |
| POST | `/portfolios/{portfolio_id}/members` (add/update) (`:63-68`) |
| DELETE | `/portfolios/{portfolio_id}/members/{user_id}` (`:115-119`) |

### 8.4 Applications (`applications.py`, prefix `/api/v1/applications`, tag `Applications`)

All `{app_id}` routes carry `member:application`. Calls `services/application.py`,
`services/insights.py`, `services/lineage.py`, `services/rationale.py`,
`services/disposition_output.py`, `services/workflow_control.py`, `services/git_service.py`,
`services/source_intake.py`, `services/step_mapping.py`.

| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `` | user | list (`applications.py:64-65`) |
| POST | `` | user | `ApplicationCreate`→`ApplicationDetail` 201 (`:127-128`) |
| POST | `/upload` | user | multipart zip onboarding, 201 (`:203-204`) |
| GET | `/{app_id}` | member | `:293-298` |
| PATCH | `/{app_id}` | member | `ApplicationUpdate` (`:306-311`) |
| GET | `/{app_id}/status` | member | `:320-325` |
| GET | `/{app_id}/lineage` | member | `:333-338` |
| GET | `/{app_id}/source-artifacts-index` | member | `:383-384` |
| GET | `/{app_id}/rationale` | member | `:473-478` |
| GET | `/{app_id}/steps/{line}/{step}` | member | step execution (`:493-497`) |
| POST | `/{app_id}/discover` | member | start discovery (`:507-513`) |
| POST | `/{app_id}/discovery/start` | member | alias (`:550-555`) |
| POST | `/{app_id}/discovery/retry` | member | `:567-572` |
| POST | `/{app_id}/discovery/rerun` | member | `:590-595` |
| GET | `/{app_id}/workflow` | member | `:623-628` |
| POST | `/{app_id}/workflow/start` | member | `:638-643` |
| POST | `/{app_id}/workflow/cancel` | member | `:656-661` |
| POST | `/{app_id}/workflow/retry` | member | `:671-676` |
| GET | `/{app_id}/insights` | member | `:699-704` |
| GET | `/{app_id}/decisions` | member | `:719-724` |
| GET | `/{app_id}/disposition-output` | member | `:732-741` |
| GET | `/{app_id}/dispositions` | member | `:757-761` |

`renditions.py` (prefix `/api/v1/applications`, tag `Renditions`): POST
`/{app_id}/renditions/generate` (`:72-77`), GET `/{app_id}/renditions` (`:105-109`).

### 8.5 Waves (`waves.py`, prefix `/api/v1/waves`, tag `Waves`)

The largest router. `{wave_id}` routes use `member:wave`. Role gates per route via
`require_role`. Calls `services/wave.py`, `services/wave_assignment.py`,
`services/wave_target_provisioning.py`, `services/performance_report.py`,
`services/workflow_control.py`, `services/git_service.py`, `services/gate.py`,
`services/step_mapping.py`.

| Method | Path | Role gate |
|---|---|---|
| POST | `` | MANAGER_ROLES — `WaveDetail` 201 (`:178-179`) |
| GET | `` | VIEWER_PLUS — list (`:268-269`) |
| GET | `/{wave_id}` | VIEWER_PLUS + member (`:344-345`) |
| PUT | `/{wave_id}` | MANAGER_ROLES + member (`:385-386`) |
| DELETE | `/{wave_id}` | ADMIN_ROLES + member, 204 (`:426-427`) |
| POST | `/{wave_id}/start` | MANAGER_ROLES + member (`:451-457`) |
| POST | `/assign` | MANAGER_ROLES — `WaveAssignmentResult` (`:472-473`) |
| POST | `/bulk-onboard` | MANAGER_ROLES — `WaveDetail` 201 (`:495-496`) |
| POST | `/{wave_id}/ready` | MANAGER_ROLES + member (`:518-523`) |
| POST | `/{wave_id}/cancel` | MANAGER_ROLES + member (`:544-549`) |
| POST | `/{wave_id}/revert` | MANAGER_ROLES + member (`:564-569`) |
| POST | `/{wave_id}/assign-apps` | MANAGER_ROLES + member (`:588-593`) |
| POST | `/{wave_id}/remove-apps` | MANAGER_ROLES + member (`:618-623`) |
| GET | `/{wave_id}/app-progress` | VIEWER_PLUS + member (`:642-647`) |
| GET | `/{wave_id}/app-activity` | VIEWER_PLUS + member (`:663-668`) |
| GET | `/{wave_id}/progress` | VIEWER_PLUS + member (`:690-695`) |
| GET | `/{wave_id}/performance-report` | VIEWER_PLUS + member (`:719-724`) |
| POST | `/{wave_id}/rationalize` | MANAGER_ROLES + member (`:747-753`) |
| POST | `/{wave_id}/cancel-rationalization` | MANAGER_ROLES + member (`:776-781`) |
| POST | `/{wave_id}/reset` | MANAGER_ROLES + member (`:806-811`) |
| POST | `/{wave_id}/resume` | MANAGER_ROLES + member (`:836-842`) |
| POST | `/{wave_id}/retry-rationalization` | MANAGER_ROLES + member (`:877-883`) |
| GET | `/{wave_id}/pending-gates` | VIEWER_PLUS + member (`:921-926`) |
| POST | `/{wave_id}/cancel-all-children` | MANAGER_ROLES + member (`:949-955`) |
| GET | `/{wave_id}/artifacts` | VIEWER_PLUS + member (path-traversal guarded) (`:1022-1027`) |
| GET | `/{wave_id}/dispatch-preview` | VIEWER_PLUS + member (`:1944-1949`) |
| GET | `/{wave_id}/dispatch-target-preview` | VIEWER_PLUS + member (`:1967-1972`) |
| POST | `/{wave_id}/dispatch-architecture` | MANAGER_ROLES + member (`:2316-2322`) |
| GET | `/{wave_id}/dispatch-status` | VIEWER_PLUS + member (`:2799-2804`) |
| POST | `/{wave_id}/dispatch-retry` | MANAGER_ROLES + member (`:2911-2917`) |
| GET | `/{wave_id}/tier1-pending` | VIEWER_PLUS + member (`:3056-3061`) |
| POST | `/{wave_id}/tier1-approval` | MANAGER_ROLES + member (`:3151-3157`) |

### 8.6 Gates (`gates.py`)

`router` prefix `/api/v1/gates` (tag `Gates`); `wave_gates_router` prefix `/api/v1/waves`
(tags `Gates`,`Waves`). Calls `services/gate.py`.

| Method | Path | Auth |
|---|---|---|
| GET | `/api/v1/gates/pending` | user (`gates.py:92-113`) |
| POST | `/api/v1/gates/{gate_id}/approve` | REVIEWER_ROLES + member (`:145-153`) |
| POST | `/api/v1/gates/{gate_id}/reject` | REVIEWER_ROLES + member (`:181-189`) |
| GET | `/api/v1/gates/{gate_id}/evidence` | VIEWER_PLUS + member (`:205-212`) |
| POST | `/api/v1/gates/{gate_id}/decision` | REVIEWER_ROLES + member (`:225-233`) |
| POST | `/api/v1/gates/{gate_id}/retry-merge` | REVIEWER_ROLES + member (`:335-343`) |
| POST | `/api/v1/gates/{gate_id}/force-advance` | MANAGER_ROLES + member (`:367-375`) |
| POST | `/api/v1/gates/{gate_id}/resolve-escalation` | REVIEWER_ROLES + member (`:398-406`) |
| POST | `/api/v1/waves/{wave_id}/gates/approve-pending` | REVIEWER_ROLES (`:442-456`) |

### 8.7 Systems / Capabilities (`systems.py`, prefix `/api/v1`, tag `Systems`)

Calls `services/system.py`. Membership via `require_system_member`,
`require_capability_member`, `require_capability_lineage_member`, `require_wave_member`.

| Method | Path | Auth |
|---|---|---|
| GET | `/systems` | user — `list[SystemSummary]` (`:67-73`) |
| GET | `/systems/{system_id}` | member:system (`:80-85`) |
| GET | `/systems/{system_id}/capabilities` | member:system (`:92-97`) |
| GET | `/systems/{system_id}/business-domains` | member:system (`:104-109`) |
| GET | `/systems/{system_id}/lineage` | member:system (`:116-119`) |
| GET | `/capabilities/{capability_id}` | member:capability (`:126-131`) |
| GET | `/capabilities/{capability_id}/lineage` | member:capability (`:138-143`) |
| GET | `/capability-lineage/{lineage_id}` | member:lineage (`:155-160`) |
| POST | `/capability-lineage/{lineage_id}/ratify` | REVIEWER_ROLES + member:lineage (`:168-176`) |
| POST | `/capability-lineage/{lineage_id}/reject` | REVIEWER_ROLES + member:lineage (`:196-204`) |
| GET | `/waves/{wave_id}/capability-lineage` | member:wave (`:224-229`) |
| GET | `/portfolios/{portfolio_id}/compliance/system-rollup` | user (`:247-253`) |

### 8.8 Traceability (`traceability.py`, prefix `/api/v1`, tag `Traceability`)

Calls `services/traceability.py`. All but stale carry `member:application` and
`role:VIEWER_PLUS`.

| Method | Path |
|---|---|
| GET | `/applications/{app_id}/traceability` (`:50-59`) |
| GET | `/applications/{app_id}/traceability/forward` (`:84-93`) |
| GET | `/applications/{app_id}/traceability/backward` (`:100-109`) |
| GET | `/applications/{app_id}/traceability/coverage` (`:116-123`) |
| GET | `/applications/{app_id}/traceability/validate` (`:130-139`) |
| GET | `/applications/{app_id}/traceability/cross-validate` (`:146-153`) |
| GET | `/artifacts/stale` | VIEWER_PLUS — **registered before artifacts router** (`:160-166`) |

### 8.9 Artifacts (`artifacts.py`, prefix `/api/v1/artifacts`, tag `Artifacts`)

Calls `services/git_service.py`. `{app_id}` routes carry `member:application`.

| Method | Path | Role |
|---|---|---|
| POST | `/validate` | TECH_PLUS — `ArtifactValidateResponse` (`:173-176`) |
| GET | `/{app_id}` | VIEWER_PLUS + member (`:209-215`) |
| GET | `/{app_id}/{artifact_path:path}/history` | VIEWER_PLUS + member (`:268-275`) |
| GET | `/{app_id}/{artifact_path:path}` | VIEWER_PLUS + member (`:318-322`) |

### 8.10 Analytics (`analytics.py`, prefix `/api/v1/analytics`, tag `Analytics`)

Calls `services/scoring.py`, `services/model_usage.py`. All `role:VIEWER_PLUS` except
dimension-registry PUT (`MANAGER_PLUS`).

| Method | Path | Model |
|---|---|---|
| GET | `/readiness-scores` | (`:64-65`) |
| GET | `/overlap-matrix` | `OverlapMatrixResponse` (`:104-105`) |
| GET | `/portfolio-health` | `PortfolioHealthResponse` (`:117-118`) |
| GET | `/portfolio-scoring` | `PortfolioScoringHeatMapResponse` (`:130-134`) |
| GET | `/disposition-confidence` | (`:153-157`) |
| GET | `/compound-growth` | `CompoundGrowthResponse` (`:168-169`) |
| GET | `/gate-pass-rate` | `GatePassRateResponse` (`:181-182`) |
| GET | `/score-history` | `ScoreHistoryResponse` (`:194-195`) |
| GET | `/dimension-registry` | (`:207-211`) |
| PUT | `/dimension-registry` | MANAGER_PLUS (`:217-222`) |
| GET | `/model-usage` | `ModelUsageResponse` (`:233-242`) |

### 8.11 Registries (`registries.py`, prefix `/api/v1/registries`, tag `registries`)

Reads the six registries from the `olympus_workflows` Temporal package; mutations require
`role:PORTFOLIO_ADMIN`. Reads are unauthenticated. Index: GET `` →
`list[RegistryIndexEntry]` (`:289-290`). For each of the six registries the pattern is:
GET (list), GET `/{key}`, POST (upsert, admin), DELETE `/{key}` (admin), POST
`/{key}/version-bump` (admin); scoring-dimensions additionally has POST `/replace-all`
(admin). Full path set (`registries.py:331-864`):

- Assembly lines: `/assembly-lines`, `/assembly-lines/{name}`,
  `/assembly-lines/{name}/version-bump`.
- Disposition strategies: `/disposition-strategies`, `/disposition-strategies/{label}`,
  `/disposition-strategies/{label}/version-bump`.
- Analysis passes: `/analysis-passes`, `/analysis-passes/{name}`,
  `/analysis-passes/{name}/version-bump`.
- Scoring dimensions: `/scoring-dimensions`, `/scoring-dimensions/{name}`,
  `/scoring-dimensions/replace-all`, `/scoring-dimensions/{name}/version-bump`.
- Gate providers: `/gate-providers`, `/gate-providers/{provider_id}`,
  `/gate-providers/{provider_id}/version-bump`.
- Skill compositions: `/skill-compositions`, `/skill-compositions/{name}`,
  `/skill-compositions/{name}/version-bump`.

`_translate_registry_error` maps registry exceptions to HTTPException
(`registries.py:266`).

### 8.12 Skills (`skills.py`, prefix `/api/v1/skills`, tag `Skills`)

Calls `services/skill.py`. Reads `VIEWER_PLUS`, writes `MANAGER_ROLES`.

| Method | Path | Role |
|---|---|---|
| GET | `` | VIEWER_PLUS (`:53-59`) |
| POST | `` | MANAGER_ROLES — `SkillDetail` 201 (`:71-74`) |
| GET | `/categories` | VIEWER_PLUS (`:81-83`) |
| GET | `/metrics` | VIEWER_PLUS (`:103-105`) |
| GET | `/metrics/by-line` | VIEWER_PLUS (`:145-147`) |
| GET | `/dispatch/{dispatch_id}` | VIEWER_PLUS — `SkillDetail` (`:173-176`) |
| GET | `/{skill_id}` | VIEWER_PLUS — `SkillDetail` (`:183-186`) |
| GET | `/{skill_id}/variants` | VIEWER_PLUS (`:193-196`) |
| GET | `/{skill_id}/metrics` | VIEWER_PLUS (`:217-220`) |
| PUT | `/{skill_id}` | MANAGER_ROLES — `SkillDetail` (`:257-261`) |
| DELETE | `/{skill_id}` | MANAGER_ROLES — 204 (`:268-271`) |

### 8.13 Assembly Lines (`lines.py`)

`router` prefix `/api/v1/lines` (tag `Assembly Lines`); `line_start_router` prefix
`/api/v1` (tag `Assembly Lines`). Calls `services/lines.py`, `services/workflow_control.py`,
`services/step_mapping.py`.

| Method | Path | Auth |
|---|---|---|
| GET | `/api/v1/lines` | VIEWER_PLUS (`:80-82`) |
| GET | `/api/v1/lines/{line_name}` | VIEWER_PLUS (`:88-91`) |
| GET | `/api/v1/lines/{line_name}/status` | VIEWER_PLUS (`:102-108`) |
| GET | `/api/v1/lines/{line_name}/throughput` | VIEWER_PLUS (`:135-142`) |
| POST | `/api/v1/architecture/start` | MANAGER_ROLES (`:374-381`) |
| POST | `/api/v1/data/start` | MANAGER_ROLES (`:389-396`) |
| POST | `/api/v1/modernization/start` | MANAGER_ROLES (`:404-411`) |

### 8.14 Workflows & Signals

`workflows.py` (prefix `/api/v1/workflows`, tag `Workflows`), calls
`services/workflow_health.py`:

| Method | Path | Auth |
|---|---|---|
| GET | `` | (`WorkflowListResponse`) (`:33-34`) |
| GET | `/{workflow_id}` | (`WorkflowDetail`) (`:44-45`) |
| POST | `/{workflow_id}/restart` | role: OPERATIONS_LEAD or PORTFOLIO_ADMIN (`:55-64`) |
| POST | `/{workflow_id}/fail` | role: OPERATIONS_LEAD or PORTFOLIO_ADMIN (`:74-82`) |

`workflow_signals.py` (prefix `/api/v1/workflow-signals`, tag `Workflow Signals`), calls
`services/signal_inbox.py`: GET `/pending` → `PendingSignalsResponse`, VIEWER_PLUS
(`:56-62`).

`agent_runs.py` (prefix `/api/v1/agent-runs`, tag `Agent Runs`): GET `/recent-errors` →
`AgentRunErrorListResponse`, user (`:26-37`). Calls `services/agent_runs.py`.

### 8.15 Agents & Agent Roles

`agents.py` (prefix `/api/v1/agents`, tag `Agents`) — telemetry ingestion, `SERVICE_ONLY`:
POST `/tasks` (`:39-46`), POST `/tasks/{task_id}/complete` (`:62-69`). Calls
`services/agents.py`.

`agent_roles.py` (prefix `/api/v1/agent-roles`, tag `Agent Roles`): GET `` →
`AgentRoleListResponse`, VIEWER_PLUS (`:46-66`). Calls `services/agent_roles.py`.

### 8.16 Escalations (`escalations.py`, prefix `/api/v1/escalations`, tag `Escalations`)

| Method | Path | Role |
|---|---|---|
| GET | `` | VIEWER_PLUS (`:154-161`) |
| GET | `/metrics` | VIEWER_PLUS — `EscalationMetrics` (`:219-221`) |
| GET | `/{escalation_id}` | VIEWER_PLUS — `EscalationDetail` (`:283-286`) |
| POST | `/{escalation_id}/resolve` | RESOLVER_ROLES — `EscalationDetail` (`:303-307`) |

### 8.17 Governance (`governance.py`, prefix `/api/v1/governance`, tag `Governance`)

| Method | Path | Role |
|---|---|---|
| GET | `/health-checks` | VIEWER_PLUS (`:150-154`) |
| GET | `/health-checks/latest` | VIEWER_PLUS (`:196-198`) |
| GET | `/drift-alerts` | VIEWER_PLUS (`:230-233`) |
| POST | `/drift-alerts/{alert_id}/acknowledge` | MANAGER_PLUS — `DriftAlert` (`:272-275`) |
| GET | `/patterns` | VIEWER_PLUS (`:320-325`) |
| GET | `/patterns/{pattern_id}` | VIEWER_PLUS — `PatternDetail` (`:376-379`) |
| POST | `/sweep` | MANAGER_PLUS (`:492-499`) |
| GET | `/sweeps` | VIEWER_PLUS (`:567-572`) |
| GET | `/portfolios/{portfolio_id}/cato-evidence` | VIEWER_PLUS (tag also `Compliance`) (`:786-794`) |

### 8.18 Bundles & Admin Bundles (Human-paired-agent W20)

`bundles.py` (prefix `/api/v1`, tag `Bundles`), all `user` auth, calls `services/bundle.py`:

| Method | Path |
|---|---|
| GET | `/me/bundles` → `list[BundleSummary]` (`:65-67`) |
| GET | `/bundles/{bundle_id}` → `BundleDetail` (`:108-111`) |
| GET | `/bundles/{bundle_id}/audit` → `BundleAuditNarrative` (`:117-120`) |
| POST | `/bundles/{bundle_id}/claim` → `BundleDetail` (`:133-137`) |
| POST | `/bundles/{bundle_id}/release` → `BundleDetail` (`:153-157`) |
| POST | `/bundles/{bundle_id}/validate` (`:171-177`) |
| POST | `/bundles/{bundle_id}/submit` (`:187-191`) |

`admin_bundles.py` (prefix `/api/v1/admin`, tag `Admin`), `role:PORTFOLIO_ADMIN`:
POST `/portfolios/{portfolio_id}/bundles` (create) (`:39-48`), POST
`/bundles/{bundle_id}/force-release` (`:87-95`).

`human_paired_agent.py` (prefix `/api/v1`, tag `Human-Paired Agent`), `user` auth, calls
`services/human_paired_agent.py`:

| Method | Path |
|---|---|
| GET | `/me/tasks` → `MyTasksResponse` (`:40-42`) |
| POST | `/agent-tasks/{task_id}/return` → `TaskReturnResponse` (`:80-87`) — runs strict output-spec validator |
| GET | `/agent-tasks/{task_id}/audit-narrative` → `TaskAuditNarrative` (`:129-135`) |

### 8.19 Admin / Users

`admin.py` (prefix `/api/v1/admin`, tag `Admin`): POST `/seed-sample-portfolio`,
`role:PORTFOLIO_ADMIN`, gated by `_is_enabled()` feature flag (`:223-230`).

`users.py` (prefix `/api/v1/users`, tag `Users`), calls `services/user.py`,
`services/password.py`:

| Method | Path | Auth |
|---|---|---|
| GET | `` | role:PORTFOLIO_ADMIN (`:67-71`) |
| GET | `/{user_id}` | user; admin-or-self enforced in body (`:88-91`) |
| POST | `` | role:PORTFOLIO_ADMIN — `UserProfile` 201 (`:107-110`) |
| PUT | `/{user_id}` | user; admin-or-self (`:140-144`) |
| DELETE | `/{user_id}` | role:PORTFOLIO_ADMIN — 204 (`:180-183`) |
| POST | `/{user_id}/password` | user; admin-or-self — 204 (`:208-212`) |

Helpers `_is_self`, `_require_admin_or_self` (`users.py:48-52`).

### 8.20 Chat (`chat.py`, tags `Chat`)

No router prefix; full paths declared per-route. Calls Bedrock (`_invoke_bedrock`,
`chat.py:986`), A2A dispatch (`_dispatch_a2a_chat`, `:922`), persistence helpers,
`services/gate.py`/application/portfolio context builders.

| Method | Path | Role |
|---|---|---|
| POST | `/api/v1/gates/{gate_id}/chat` | VIEWER_PLUS (`:1037-1044`) |
| POST | `/api/v1/chat` | VIEWER_PLUS — `ChatResponse` (`:1100-1104`) |
| GET | `/api/v1/gates/{gate_id}/chat/history` | VIEWER_PLUS (`:1204-1211`) |
| GET | `/api/v1/chat/history` | VIEWER_PLUS — `ChatHistoryResponse` (`:1225-1238`) |
| DELETE | `/api/v1/chat/history` | CLEAR_HISTORY_ROLES — 204 (`:1266-1279`) |

### 8.21 Activity, Git, Events, Webhooks

`activity.py` (prefix `/api/v1/activity`, tag `Activity`): GET `/recent`, user (`:21-25`).

`git.py` (prefix `/api/v1/git`, tag `Git`): GET `/repo-available` →
`RepoAvailableResponse`, `MANAGER_ROLES` (`:49-60`). Calls `services/git_service.py`.

`events.py` (prefix `/api/v1/events`, tag `Events`) — **no auth dependency**:
- WebSocket `/ws` (`event_types` query) — echo `ping`→`pong`, broadcast fan-out
  (`events.py:86-101`).
- GET `` — SSE `text/event-stream`; 15s keepalive comments, disconnect-aware
  (`events.py:122-151`).
In-memory `ConnectionManager` with `broadcast(event_type, payload)` to WS + SSE queues
(`events.py:28-78`). Skeleton — replace with Redis pub/sub for multi-replica.

`webhooks.py` (prefix `/api/v1/webhooks`, tag `webhooks`): POST `/github`
(`:84-85`). `_verify_signature` validates `X-Hub-Signature-256` HMAC-SHA256 against
`github_webhook_secret` using `hmac.compare_digest` (`:38-48`). Maps branch →
workflow/gate id (`:55-67, :67-83`).

---

## 9. Models (`olympus-api/src/models/`)

Pydantic v2 response/request models, mirroring OpenAPI component schemas. Shared enums
(`AssemblyLine`, `ComplexityTier`, `Disposition`, `GateStatus`, `GateType`, `RiskTier`,
`TierSource`) are **re-exported from the `olympus_contracts` package** and re-exported via
`models/common.py:12-22`. Local enums: `SourceType` (git/zip/s3/confluence/sharepoint/
gdrive/gcs, `common.py:26-44`), `RBACRole` (`common.py:47-57`), `EventType` (12 values,
`common.py:59-71`).

Module → key classes (`models/*.py`):

- `common.py` — `PaginationMeta`, `PaginatedResponse`, `ErrorDetail`, `ErrorResponse`,
  `ReadinessScores`, `RealtimeEvent`.
- `application.py` — `ApplicationCreate/Update/Detail`, `ApplicationStatus`,
  `SourceIntakeResult`, `StepExecutionRecord`, `WorkflowStart/Retry/Action*`,
  `DiscoverResponse`, `AppDispositionResponse`, `InsightsMetrics`, etc. (33 classes).
- `wave.py` — `WaveCreate/Update/Detail`, `WaveStart*`, `WaveResume*`, `WaveAssignment*`,
  `WaveBulkOnboardRequest`, `WaveProgressResponse`, `WavePendingGate*`, `WavePerf*` (~25).
- `gate.py` — `GateSummary/Detail`, `GateApprove/Reject/Decision/MergeRetry/
  ForceAdvance/EscalationResolve Request`, `GateEvidencePackage`, `CardDecision`,
  `CapabilityLineageRowDecision`, `WaveBatchApprove*` (~17).
- `portfolio.py`, `portfolio_membership.py`, `rollup.py` — portfolio shapes +
  `PortfolioTargetStateRollup`.
- `system.py` — `System*`, `Capability*`, `BusinessDomain*`, `CapabilityLineage*`,
  `PortfolioComplianceRollup` (~21).
- `skill.py` — `SkillCreate/Update/Detail`.
- `analytics.py` — readiness/overlap/health/heat-map/pass-rate/score-history/model-usage
  responses (~22).
- `agent.py`, `agent_role.py`, `agent_run.py` — agent telemetry + role + error shapes.
- `traceability.py` — `Citation`, `TraceabilityLink`, `Forward/BackwardTraceResult`,
  `CoverageResult`, `StaleArtifact(s)Response`, `CrossValidationIssue`,
  `GateTraceabilityResult`, `TraceabilityResponse`.
- `bundle.py` — `Bundle*` incl. enums `BundleScopeKind/Status/FallbackPolicy`,
  `SessionArtifactKind`, contract + validation + audit shapes (~21).
- `human_paired_agent.py` — `MyTask*`, `TaskReturn*`, `TaskAuditNarrative`,
  `LocalAgentDescriptor/Session`.
- `disposition_output.py` — per-disposition payloads (`Retire/Retain/Refactor/Rearchitect/
  Replace/Replatform/Consolidate Payload`) + `DispositionOutputBundle`.
- `user.py` — `UserProfile`, `UserCreate/Update Request`, `PasswordUpdateRequest`,
  `LoginRequest`, `TokenResponse`, `RoleAssignmentRequest`, `AuthModeConfig`.
- `workflow.py` — `WorkflowSummary/Detail`, `WorkflowList/Action*`, `WorkflowFailureDetail`.

---

## 10. Services (`olympus-api/src/services/`)

43 service modules. One-line responsibility + key entry points (line cites in
`services/<file>.py`):

| Service | Responsibility / key functions |
|---|---|
| `agent_client.py` | Provider-agnostic A2A dispatch. `dispatch_via_a2a` (`:145`). |
| `agent_roles.py` | Agent-role config (agents.yaml). `load_agent_roles_config` (`:101`), `get_agent_roles` (`:331`). |
| `agent_runs.py` | Cross-app agent run error queries. `list_recent_errors` (`:18`). |
| `agents.py` | Agent telemetry ingestion. `record_task_start` (`:24`), `record_task_complete` (`:65`). |
| `application.py` | Application CRUD + discovery start. `create_application` (`:483`), `list_applications` (`:649`), `get_application` (`:735`), `update_application` (`:789`), `get_application_status` (`:841`), `start_discovery` (`:970`), `get_step_execution` (`:1366`). |
| `bundle.py` | Bundle lifecycle (claim/release/validate/submit/expire). `get_bundle` (`:148`), `dispatch` (`:309`), `claim` (`:404`), `release` (`:508`), `validate_payload` (`:687`), `submit` (`:754`), `expire_due_bundles` (`:857`), `get_audit_narrative` (`:910`). |
| `bundle_contract.py` | Bundle contract resolver. `known_gate_targets` (`:313`), `known_step_targets` (`:318`), `resolve` (`:466`). |
| `disposition_output.py` | Per-disposition output bundles from artifact repo. `get_disposition_output` (`:76`). |
| `gate.py` | Gate queries + decisions + Temporal signaling. `list_pending_gates` (`:153`), `approve_gate` (`:315`), `reject_gate` (`:388`), `send_gate_temporal_signal` (`:459`), `get_gate_evidence` (`:1127`), `set_gate_merge_blocked` (`:1455`), `retry_merge_gate` (`:1519`), `force_advance_gate` (`:1648`), `resolve_escalation` (`:1787`), `submit_gate_decision` (`:1988`). |
| `git_service.py` | Branch-per-task + PR gates (PyGithub). `GitService` methods: `create_branch` (`:156`), `commit_file(s)` (`:213,:255`), `read_file` (`:317`), `create_pull_request` (`:353`), `merge_pull_request` (`:451`), `rebase_pr_onto_base` (`:549`), `reconcile_and_merge` (`:606`), `validate_repo_access` (`:699`), static `build_branch_name` (`:741`), `provision_repository` (`:749`), `parse_branch_name` (`:856`). |
| `human_paired_agent.py` | HPA task inbox + return + audit narrative. `list_my_tasks` (`:49`), `return_task` (`:172`), `render_task_audit_narrative` (`:476`). |
| `identity_config.py` | Active-profile OIDC config. `get_identity_config` (`:49`), `refresh_identity_config` (`:76`). |
| `insights.py` | App Detail insights + decisions timeline. `get_insights` (`:577`), `get_decisions_timeline` (`:623`). |
| `lineage.py` | App lineage read. `get_application_lineage` (`:25`). |
| `lines.py` | Assembly Lines info/status/throughput. `list_lines` (`:106`), `get_line` (`:111`), `get_line_status` (`:115`), `get_line_throughput` (`:208`). |
| `mcp_client.py` | Async MCP server client. `read_mcp_resource` (`:24`). |
| `model_usage.py` | Model usage analytics. `get_model_usage` (`:71`). |
| `oidc.py` | OIDC/SSO scaffold. `load_identity_config` (`:360`). |
| `password.py` | bcrypt hashing. `hash_password` (`:48`), `verify_password` (`:57`). |
| `performance_report.py` | Wave performance aggregator. `get_wave_performance_report` (`:55`). |
| `portfolio.py` | Portfolio summary/manifest. `get_portfolio_summary` (`:21`), `get_portfolio_manifest` (`:78`). |
| `portfolio_membership.py` | `portfolio_membership` table R/W. `is_member` (`:43`), `list_user_portfolio_ids` (`:61`), `list_portfolio_members` (`:78`), `add_member` (`:109`), `remove_member` (`:157`). |
| `profile_activation.py` | Profile activate/deactivate + active singleton. `active_profile` (`:45`), `activate_profile` (`:50`), `deactivate_profile` (`:114`); `ProfileActivationError`. |
| `profile_loader.py` | Client profile YAML loader. `load_profile` (`:476`), `discover_profile_root` (`:532`). |
| `rationale.py` | Retrospective traceability for target apps. `get_application_rationale` (`:49`). |
| `return_payload_validator.py` | Strict JSON-Schema output-spec validator for HPA returns. `load_output_schemas_for_skill` (`:166`), `validate_return_output_payload` (`:315`), `reset_cache` (`:416`). |
| `scoring.py` | Readiness/overlap/health/heat-map/confidence/growth/pass-rate. `get_dimension_registry` (`:110`), `update_dimension_weights` (`:128`), `get_all_readiness_scores` (`:184`), `calculate_readiness_score` (`:268`), `calculate_overlap_matrix` (`:369`), `calculate_portfolio_health` (`:470`), `calculate_disposition_confidence` (`:571`), `calculate_compound_growth` (`:651`), `calculate_gate_pass_rate` (`:775`), `get_score_history` (`:893`), `get_portfolio_scoring_heat_map` (`:971`). |
| `signal_inbox.py` | DB-backed workflow signal inbox. `enqueue_signal` (`:26`), `mark_queued` (`:65`), `list_pending` (`:82`). |
| `skill.py` | Skill CRUD + dispatch lookup + metrics. `list_skills` (`:44`), `get_skill` (`:84`), `create_skill` (`:99`), `update_skill` (`:163`), `delete_skill` (`:195`), `get_skill_by_dispatch_id` (`:205`), `list_line_skill_metrics` (`:350`). |
| `skill_bootstrap.py` | Loads `SKILL.md` → DB at startup. `parse_skill_md` (`:116`), `collect_skills` (`:351`), `upsert_skills` (`:470`), `bootstrap_skills` (`:528`). |
| `skill_registry.py` | Skill registry loader (cached). `load_registry` (`:173`), `get_registry` (`:212`), `reset_cache` (`:220`). |
| `source_intake.py` | Non-Git source intake (zip/s3 + scaffolds). `build_provider` (`:571`), `destination_for` (`:613`). |
| `step_mapping.py` | Step → skill/task_type/gate mapping. `is_known_step` (`:887`), `steps_for` (`:892`), `ui_steps_for` (`:902`), `task_types_for` (`:912`), `skills_for` (`:921`), `gate_for` (`:926`), `task_type_to_line_map` (`:931`). |
| `system.py` | System/capability/business-domain reads + lineage ratify/reject + compliance rollup. `list_systems` (`:48`), `get_system` (`:68`), `list_capabilities_for_system` (`:141`), `get_capability` (`:188`), `get_capability_lineage` (`:227`), `list_business_domains_for_system` (`:321`), `get_system_lineage` (`:359`), `ratify_capability_lineage_row` (`:489`), `reject_capability_lineage_row` (`:534`), `list_wave_capability_lineage` (`:589`), `get_portfolio_compliance_rollup` (`:683`). |
| `target_state_rollup.py` | Portfolio target-state rollup. `get_target_state_rollup` (`:193`). |
| `traceability.py` | Citation parse/index + trace + coverage + validation. `parse_citations` (`:56`), `index_citations` (`:132`), `forward_trace` (`:183`), `backward_trace` (`:214`), `detect_staleness` (`:245`), `compute_coverage` (`:300`), `cross_validate` (`:368`), `validate_gate_traceability` (`:430`). |
| `user.py` | User/credential service. `list_users` (`:72`), `get_user` (`:103`), `get_user_by_login` (`:123`), `get_user_by_external_identity` (`:150`), `create_user` (`:178`), `update_user` (`:265`), `set_password` (`:302`), `deactivate_user` (`:342`), `record_login` (`:358`), `upsert_oidc_user` (`:378`). |
| `wave.py` | Wave orchestration (draft/onboard/ready/cancel/rationalize/dispatch/resume). `get_or_create_draft_wave` (`:41`), `bulk_onboard_apps` (`:145`), `mark_wave_ready` (`:246`), `cancel_wave` (`:319`), `revert_wave_to_draft` (`:392`), `start_wave_rationalization` (`:476`), `start_wave` (`:878`), `assign_apps_to_wave` (`:1110`), `get_wave_progress` (`:1533`), `resume_wave_fanout` (`:2124`), …(~20 functions). |
| `wave_assignment.py` | Auto-group unassigned apps into waves. `assign_waves` (`:35`). |
| `wave_target_provisioning.py` | Seed lineage from disposition artifacts. `load_wave_apps` (`:146`), `seed_targets_from_artifacts` (`:259`). |
| `workflow_control.py` | Cancel/retry/start/describe any line workflow (Temporal). `start_line_workflow` (`:147`), `cancel_workflow` (`:237`), `retry_workflow` (`:299`), `get_workflow_details` (`:337`). |
| `workflow_health.py` | Cross-workflow health surface. `list_workflows` (`:136`), `get_workflow_detail` (`:337`), `restart_workflow` (`:429`), `fail_workflow` (`:500`). |

---

## 11. Dependencies (`olympus-api/pyproject.toml`)

Runtime deps (`pyproject.toml:10-43`): `fastapi>=0.115,<1`, `uvicorn[standard]>=0.32,<1`,
`temporalio>=1.7,<2`, `pydantic>=2,<3`, `pydantic-settings>=2,<3`, `PyGithub>=2,<3`,
`structlog>=24`, `sqlalchemy[asyncio]>=2,<3`, `asyncpg>=0.29`,
`python-jose[cryptography]>=3.3`, **`foundry-temporal>=1.3`** (private Artifactory),
`httpx>=0.27`, **`olympus-contracts>=0.1`** (shared enums), `PyYAML>=6,<7`,
`bcrypt>=4.1,<6` (bcrypt directly — passlib broken on py3.13), `python-multipart>=0.0.9,<1`
(UploadFile), `boto3>=1.34,<2` (S3 intake), `jsonschema>=4.20` (output-spec validator).

Dev extras (`pyproject.toml:45-54`): `pytest>=7`, `pytest-asyncio>=0.23`, `pytest-cov>=4`,
`ruff>=0.4`, `httpx>=0.27`.

Integration extras (`pyproject.toml:60-67`): `alembic>=1.13,<2`,
`testcontainers[postgres]>=4.7,<5`, `psycopg2-binary>=2.9,<3`.

Locked transitive versions are pinned in `olympus-api/uv.lock` (401KB). The two foundry-local
packages (`foundry-temporal`/`olympus_workflows`, `olympus-contracts`) are installed via
Artifactory or vendored wheels (`Dockerfile:7-28`).

Ruff config (`pyproject.toml:90-95`): `target-version=py313`, `line-length=100`, lint select
`E,F,I,W`.

---

## 12. Docker Image (`olympus-api/Dockerfile`)

Build context is the **repo root** (to COPY shared packages). Steps:

1. `FROM public.ecr.aws/docker/library/python:3.14-slim`; `WORKDIR /app`.
2. `ARG/ENV PIP_EXTRA_INDEX_URL` for Artifactory.
3. `apt-get install curl`.
4. `COPY vendor/wheels/ /tmp/wheels/` then `pip install /tmp/wheels/*.whl` (local fallback).
5. `COPY temporal/ /build/temporal/` then `pip install /build/temporal/` (registries pkg).
6. `COPY olympus-api/ ./` then `pip install .`.
7. `COPY cross-cutting/skills/ /app/repo/cross-cutting/skills/` and
   `COPY profiles/faa/skills/ /app/repo/profiles/faa/skills/`.
8. `ENV SKILLS_ROOT=/app/repo`.
9. `EXPOSE 8000`.
10. `CMD ["uvicorn", "src.main:create_app", "--factory", "--host", "0.0.0.0", "--port", "8000"]`.

---

## 13. Testing

### 13.1 Layout

85 test modules in `olympus-api/tests/` (unit) plus `tests/integration/` (real-Postgres via
testcontainers). Shared fixtures in `tests/conftest.py`:

- Forces `os.environ.setdefault("APP_ENV","test")` **before** any `src.*` import so the rate
  limiter defaults off (`conftest.py:20`).
- Uses `httpx.AsyncClient(ASGITransport)` against `create_app()`.
- Overrides `get_db` with a mock async session; overrides `get_current_user`.
- Standard tokens (HS256, secret `olympus-dev-secret`): `VIEWER_TOKEN` (viewer+admin),
  `VIEWER_ONLY_TOKEN` (viewer), `MANAGER_TOKEN`, `MANAGER_ONLY_TOKEN`, `ADMIN_TOKEN`
  (`conftest.py:48-...`). Admin-bearing tokens short-circuit the W20 membership dependency
  so handlers' mocked queries are the only DB calls.

### 13.2 Coverage floor & exact command

- `pyproject.toml:69-80` `[tool.pytest.ini_options]`: `asyncio_mode="auto"`,
  `testpaths=["tests"]`, and
  **`addopts = "--cov=src --cov-report=term-missing --cov-report=html:htmlcov
  --cov-fail-under=87 --ignore=tests/integration"`**.
- **Coverage floor = 87%** (transitional per DECISION-017; 90% aspirational). Source
  measured: `src` (`pyproject.toml:82-84`, omit `__init__.py`).
- CI (`.github/workflows/ci.yml:579-587`) runs, with `working-directory: olympus-api`,
  env `AGENT_RUNTIME_MODE=mock`, `APP_ENV=test`:
  ```
  pytest --cov=src --cov-report=term-missing --cov-report=xml:coverage.xml --tb=short -q
  ```
  The `--cov-fail-under=87` and `--ignore=tests/integration` come from `addopts`, so the
  effective default local command is simply `pytest` from the `olympus-api/` directory.
- Lint gate in CI: `ruff check .` (`ci.yml:556-557`).
- Integration suite (real Postgres) runs separately:
  `pip install -e "./olympus-api[dev,integration]"` then `pytest tests/integration/`
  (`ci.yml:598-635`).
- Profile-portability test runs standalone with `--no-cov`:
  `pytest tests/test_generic_profile_portability.py -v --no-cov` (`ci.yml:464`).

---

## Atomic Rebuild Checklist

Each step has an explicit acceptance check. Run from `olympus-api/` unless stated.

1. **Scaffold package skeleton.** Create `pyproject.toml` exactly per §11 (name
   `olympus-api`, version `0.1.0`, `requires-python>=3.13`, all runtime + dev + integration
   deps, the `[tool.pytest.ini_options].addopts` line with `--cov-fail-under=87`, ruff
   config). Create `src/__init__.py`.
   **Check:** `python -c "import tomllib,sys; d=tomllib.load(open('pyproject.toml','rb'));
   assert '--cov-fail-under=87' in d['tool']['pytest']['ini_options']['addopts']; print('ok')"`.

2. **Config.** Write `src/config.py` `AppConfig` with all fields/defaults in §3 and
   `get_database_url`/`get_async_database_url`.
   **Check:** `python -c "from src.config import AppConfig; c=AppConfig();
   assert c.api_port==8000 and c.service_name=='olympus-api';
   assert c.get_async_database_url().startswith('postgresql+asyncpg://'); print('ok')"`.

3. **Database layer.** Write `src/database.py` (`init_db`, `get_db`, `get_engine`) with the
   pool settings in §4.
   **Check:** `python -c "import src.database as d; import asyncio;
   from src.database import get_db;
   asyncio.run(__import__('inspect').isasyncgenfunction(get_db) or 1); print('ok')"` and
   verify `get_db()` raises `RuntimeError` before `init_db`.

4. **Shared startup state.** Write `src/startup_state.py`.
   **Check:** `python -c "from src.startup_state import set_skill_count,get_skill_count;
   set_skill_count(5); assert get_skill_count()==5; print('ok')"`.

5. **Common models + RBAC.** Write `src/models/common.py` with `RBACRole` (9 values),
   `SourceType`, `EventType`, pagination + error envelope models. (Requires
   `olympus_contracts` installed for re-exported enums.)
   **Check:** `python -c "from src.models.common import RBACRole;
   assert {r.value for r in RBACRole} >= {'portfolio_admin','viewer','service'};
   assert len(list(RBACRole))==9; print('ok')"`.

6. **Auth subsystem.** Write `src/middleware/auth.py` (`CurrentUser`, `get_current_user`,
   `require_role`), `src/auth/service_tokens.py`, `src/auth/user_tokens.py` per §7.
   **Check:** `python -c "from src.auth.service_tokens import issue_service_token;
   from jose import jwt; t=issue_service_token('worker');
   p=jwt.get_unverified_claims(t); assert p['roles']==['service'] and
   p['sub']=='service:worker'; print('ok')"`.

7. **Middleware stack.** Write `request_id.py`, `rate_limit.py`, `metrics.py`,
   `pagination.py`, `error_handler.py` per §6.
   **Check:** `python -c "from src.middleware.pagination import get_pagination,
   paginated_response,PaginationParams as P;
   r=paginated_response([1],10,P(page=1,per_page=20));
   assert r['pagination']['total_pages']==1; print('ok')"` and confirm the error envelope
   shape `{"error":{"code","message","details","request_id"}}`.

8. **DI helpers.** Write `src/dependencies.py` with `get_config`, `get_temporal_client`, and
   all `require_*_member` / `verify_*_portfolio_access` / `filter_portfolio_ids_by_membership`
   functions per §5.
   **Check:** `python -c "import src.dependencies as d;
   assert all(hasattr(d,n) for n in
   ['require_portfolio_member','require_application_member','require_wave_member',
   'require_gate_member','require_system_member','require_capability_member',
   'require_capability_lineage_member','filter_portfolio_ids_by_membership']); print('ok')"`.

9. **Models.** Write all `src/models/*.py` modules with the classes listed in §9 (mirror
   OpenAPI component schemas; reuse `olympus_contracts` enums).
   **Check:** `python -c "import importlib,glob,os;
   [importlib.import_module('src.models.'+os.path.basename(f)[:-3]) for f in
   glob.glob('src/models/*.py') if not f.endswith('__init__.py')]; print('ok')"`.

10. **Services.** Write all 43 `src/services/*.py` modules with the functions in §10.
    **Check:** `python -c "import importlib,glob,os;
    [importlib.import_module('src.services.'+os.path.basename(f)[:-3]) for f in
    glob.glob('src/services/*.py') if not f.endswith('__init__.py')]; print('ok')"`.

11. **Routers.** Write all 36 `src/routers/*.py` modules with the exact prefixes, paths,
    methods, role groups, membership deps, and response models in §8. Preserve role-group
    tuple values from §7.2.
    **Check:** `python -c "import importlib,glob,os;
    [importlib.import_module('src.routers.'+os.path.basename(f)[:-3]) for f in
    glob.glob('src/routers/*.py') if not f.endswith('__init__.py')]; print('ok')"`.

12. **App factory.** Write `src/main.py` with `create_app`, `_lifespan`,
    `_configure_logging`, and the router include order at §2.2 (traceability before
    artifacts).
    **Check (route inventory):**
    `python -c "from src.main import create_app; import os;
    os.environ['DEV_AUTH_BYPASS']='true';
    app=create_app();
    paths={(m,r.path) for r in app.routes for m in getattr(r,'methods',[]) or []};
    assert ('GET','/health') in paths;
    assert ('POST','/api/v1/gates/{gate_id}/approve') in paths;
    assert ('GET','/api/v1/artifacts/stale') in paths;
    assert ('POST','/api/v1/waves/{wave_id}/tier1-approval') in paths;
    print(len(paths),'routes ok')"` — confirm the artifacts/stale path resolves (precedence
    intact) and `app.title=='Olympus API'`, `app.version=='0.1.0'`.

13. **Health behavior.** With DB+Temporal stubbed (or a live stack), boot the app.
    **Check:** `GET /health` returns `{"status":"ok","service":"olympus-api",
    "version":"0.1.0",...}`; `GET /system/metrics` returns `text/plain` containing
    `olympus_api_info{...}` and `olympus_api_skills_loaded`.

14. **Auth + rate-limit headers.** With `DEV_AUTH_BYPASS` off and `RATE_LIMIT_ENABLED=true`,
    hit any `/api/v1/...` endpoint without a token.
    **Check:** 401 envelope `{"error":{"code":"UNAUTHORIZED",...}}`; an allowed response
    carries `X-RateLimit-Limit/Remaining/Reset` and every response carries `X-Request-ID`.

15. **Dockerfile.** Write `Dockerfile` per §12 (build context = repo root; vendored wheels +
    temporal pkg + skills copy; `SKILLS_ROOT=/app/repo`; EXPOSE 8000).
    **Check:** `docker build -f olympus-api/Dockerfile -t olympus-api .` from repo root
    succeeds; `docker run` then `curl localhost:8000/health` returns `status:ok`.

16. **Test harness.** Write `tests/conftest.py` (force `APP_ENV=test` before `src.*` import;
    AsyncClient transport; mock DB; standard tokens) and port the 85 unit test modules.
    **Check:** `pytest` (from `olympus-api/`) runs the suite, ignores `tests/integration`,
    and **passes the `--cov-fail-under=87` gate** (build fails if coverage < 87%).

17. **Lint.** **Check:** `ruff check .` exits 0.

18. **Integration suite (optional, real Postgres).**
    **Check:** `pip install -e ".[dev,integration]" && pytest tests/integration/` passes
    against a testcontainers Postgres.

19. **Profile activation is fatal-on-missing.** Boot with an invalid `OLYMPUS_PROFILE`.
    **Check:** startup aborts with logged `profile_activation.failed` (process does not serve
    traffic) — proves the lifespan §2.3 step 1 behavior.
