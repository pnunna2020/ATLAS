# 02 — Worker, Agent Runtime, MCP Server, CLI

> **Regeneration scope.** This document is one of a multi-document
> regeneration specification (see `specifications/regeneration/GOAL.md`).
> It covers four services: **`olympus-worker`**, **`olympus-agent-runtime`**,
> **`mcp-server`**, and **`olympus-cli`**. Every fact below is derived from
> the repository and cited as `{repo-relative-path}:{line}`. Where the
> implementation differs from prose specs, the implementation wins (per
> GOAL.md §Method) and the drift is flagged.
>
> **Premise.** Rebuild these four services from this document alone,
> behaviorally identical, passing tests at the documented coverage floors.

## Table of contents

1. [olympus-worker](#1-olympus-worker)
2. [olympus-agent-runtime](#2-olympus-agent-runtime)
3. [mcp-server](#3-mcp-server)
4. [olympus-cli](#4-olympus-cli)
5. [Cross-service contracts & shared invariants](#5-cross-service-contracts--shared-invariants)

---

## 1. olympus-worker

### 1.1 Responsibility

The Temporal worker process. It registers Olympus workflows and activities
against the Temporal task queue and polls it forever. It owns **no HTTP
port** — it is a background poller (`docker-compose.yml:283-302`: the
liveness check scans `/proc` for a `src.worker` cmdline rather than hitting
a port). Its only outward calls are: Temporal (gRPC), the agent runtime
(A2A over HTTP), the Olympus API, GitHub, and Postgres (via activities).

The worker package supplies:
- The bootstrap entry point (`src/worker.py`).
- The **provider-agnostic A2A dispatch client** (`src/agent_client.py`).
- The **agent registry** that maps skills → agent endpoints
  (`src/agent_registry.py`, `src/agents/olympus_agent.py`).
- **Model-tier resolution** (`src/model_resolver.py`).
- A **deprecated subprocess fallback adapter** (`src/fallback_adapter.py`).
- Worker configuration (`src/config.py`).
- A **mock agent runtime** for deterministic tests
  (`src/testing/mock_agent_runtime.py`).
- A Jinja2 **rendition engine** (`src/renditions/engine.py`).
- Declarative YAML config: `config/{models,services,agents,workflows,activities}.yaml`.

The workflow and activity *definitions themselves* live in the separate
`temporal/olympus_workflows` package (installed as a dependency); the worker
only registers and runs them. The **live|mock dispatch switch** lives in
`temporal/olympus_workflows/activities/agent_dispatch.py`, not in the worker
(see §1.9).

### 1.2 Entry point & startup sequence

`olympus-worker/src/worker.py` is the entry point; container CMD is
`python -m src.worker` (`olympus-worker/Dockerfile:43`).

Startup, in order (from `src/worker.py`):

1. `run_worker()` first calls `config.validate_agent_runtime_mode()` — a
   **fail-fast safety rail**. If `APP_ENV` is one of
   `{production, prod, staging, stage}` (`src/config.py` `_NON_TEST_ENVS`)
   **and** `AGENT_RUNTIME_MODE` resolves to `mock`, it raises
   `MockInProductionError` and the process refuses to start (DECISION-018).
2. `_resolve_worker_identity(task_queue)` computes the Temporal worker
   identity: the value of env `WORKER_IDENTITY` if set, else
   `olympus-worker-{task_queue}-{hostname}-{pid}`. This makes each replica a
   distinct identity in the Temporal UI "Workers" tab under
   `docker compose --scale`.
3. `_load_agent_config()` reads the agents YAML at `AGENT_CONFIG_PATH`
   (default `config/agents.yaml`) and populates the agent registry.
4. A Temporal client/worker is created via the `foundry_temporal` bootstrap
   helper, connecting to `temporal_host` in namespace `namespace`, polling
   task queue `task_queue` with concurrency limits
   `max_concurrent_activities` / `max_concurrent_workflow_tasks`.
5. All workflow classes (from `config/workflows.yaml`) and activity callables
   (from `config/activities.yaml`) are registered.
6. A **SIGHUP handler** is installed: on `SIGHUP` the process calls
   `olympus_agent_registry.reload()` so agent config can be hot-reloaded
   without a restart.
7. The worker runs until interrupted; shutdown is the Temporal worker's
   graceful drain.

### 1.3 Configuration (`src/config.py`)

`WorkerConfig` is a `pydantic-settings` model. Defaults (each overridable by
the matching env var):

| Field | Default | Notes |
|---|---|---|
| `temporal_host` | `localhost:7233` | Temporal frontend gRPC |
| `namespace` | `default` | |
| `task_queue` | `olympus-main` | |
| `max_concurrent_activities` | `100` | |
| `max_concurrent_workflow_tasks` | `50` | |
| `database_host` | `localhost` | compose sets `postgres` (`docker-compose.yml:241`) |
| `database_port` | `5432` | |
| `database_name` | `olympus` | |
| `database_user` | `olympus` | |
| `database_password` | `olympus_dev` | dev default |
| `log_level` | `INFO` | |
| `agent_runtime_mode` | `live` | `live` or `mock` |
| `app_env` | `development` | |

`_NON_TEST_ENVS = {production, prod, staging, stage}`. Helpers:
`get_database_url()` → `postgresql://…`; `get_async_database_url()` →
`postgresql+asyncpg://…`. `validate_agent_runtime_mode()` enforces the
no-mock-in-prod rail described in §1.2.

### 1.4 Environment variables (full set the worker honors)

- `TEMPORAL_HOST`, `NAMESPACE`, `TASK_QUEUE`,
  `MAX_CONCURRENT_ACTIVITIES`, `MAX_CONCURRENT_WORKFLOW_TASKS`
- `DATABASE_HOST`, `DATABASE_PORT`, `DATABASE_NAME`, `DATABASE_USER`,
  `DATABASE_PASSWORD`
- `LOG_LEVEL`, `APP_ENV`, `AGENT_RUNTIME_MODE`
- `WORKER_IDENTITY` (per-replica identity override)
- `AGENT_CONFIG_PATH` (default `config/agents.yaml`)
- `OLYMPUS_AGENT_URL` (consumed by `agents/olympus_agent.py`; default
  `http://olympus-agent:8100`)
- Model-tier overrides: `MODEL_TIER_1_CLAUDE`, `MODEL_TIER_2_CLAUDE`,
  `MODEL_TIER_3_CLAUDE`, and the `_OPENAI` / `_GEMINI` variants
  (`src/model_resolver.py`)
- `ENABLE_SUBPROCESS_FALLBACK` (gate for the deprecated adapter; `1` enables)
- `OLYMPUS_SKILLS_ROOT` (mock-fixture root override, tests)
- Activity-level env consumed by the `temporal` package via the worker
  process: `GITHUB_TOKEN`, `GITHUB_BASE_URL`, `GITHUB_REPO`,
  `OLYMPUS_PROFILE_ROOT`, `OLYMPUS_SCHEMAS_DIR` (`docker-compose.yml:255-268`).

### 1.5 Ports

None. Background poller only. Compose health-check scans `/proc`
(`docker-compose.yml:295-302`).

### 1.6 Internal module structure

```
olympus-worker/
├── src/
│   ├── worker.py              # entry point, Temporal bootstrap, SIGHUP reload
│   ├── config.py              # WorkerConfig + no-mock-in-prod rail
│   ├── agent_client.py        # A2A dispatch client (see §1.7)
│   ├── agent_registry.py      # OlympusAgentCard + registry singleton
│   ├── model_resolver.py      # tier→concrete-model resolution
│   ├── fallback_adapter.py    # DEPRECATED subprocess fallback (gated)
│   ├── git_service.py         # copied at build time from olympus-api (see §1.10)
│   ├── agents/
│   │   └── olympus_agent.py   # the single catch-all agent card
│   ├── testing/
│   │   └── mock_agent_runtime.py  # fixture-driven mock dispatch
│   └── renditions/
│       └── engine.py          # Jinja2 RenditionEngine.render_markdown
├── config/
│   ├── models.yaml
│   ├── services.yaml
│   ├── agents.yaml
│   ├── workflows.yaml
│   └── activities.yaml
├── tests/                     # see §1.11
├── pyproject.toml
└── Dockerfile
```

### 1.7 A2A dispatch client (`src/agent_client.py`)

This is the worker→agent transport. It maps Olympus
`AgentTaskInput`/`AgentTaskResult` types (from `olympus_workflows.types`) onto
the A2A HTTP/JSON-RPC protocol via `httpx`.

**Public entry:** `async def dispatch_via_a2a(agent_url, task_input, model_used="") -> AgentTaskResult`
(`olympus-worker/src/agent_client.py:238`). The `model_used` argument is
deprecated/ignored — model selection is delegated to the agent runtime
(`agent_client.py:253`).

**Request shape** (POST `{agent_url}/a2a/tasks`, `agent_client.py:193,274-285`):
```json
{
  "task": "<rendered task message>",
  "context": { ... },
  "model_preference": "<task_input.model_preference or empty string>"
}
```
- `model_preference` is sent **empty** when the caller has no explicit
  preference, so the agent runtime resolves the skill's declared tier
  itself. Sending `"tier-2"` here is explicitly called out as a bug because
  it clobbers Opus-declared skills down to Sonnet (`agent_client.py:277-283`).
- `_build_task_message` (`:51`) renders:
  `Execute skill '<skill_id>' for application '<app_id>'. Task type: <task_type>.`
  and appends `Context: k=v, ….` (sorted) when `task_input.context` is set.
- `_build_context` (`:70`) emits `app_id, skill_id, task_type,
  input_artifacts, optional_input_artifacts, model_preference`, plus optional
  `source_repo, artifact_repo, artifact_ref, workspace_key`, plus caller
  context under a dedicated `extras` key (`:90-94`).

**Response mapping** `_extract_result` (`:98`): reads `output_artifacts`
(list of str), `output_files` (list of `{path, content, encoding}` →
`OutputFile`), `token_usage.{input,output}`, `cost_estimate_usd`,
`model_used`, and `status` (`"failed"` → `TaskStatus.FAILED` with `error`,
otherwise `COMPLETED`). `duration_ms` is wall-clock from dispatch.

**Retry policy.** Two layers:
- `AGENT_RETRY_POLICY` (`:32-37`) — a Temporal `RetryPolicy`:
  `initial_interval=5s`, `backoff_coefficient=2.0`, `maximum_interval=60s`,
  `maximum_attempts=3`. Replaces the former `foundry-strands-agents` preset.
  Used by the activity layer for general agent failures.
- `_post_with_saturation_retry` (`:165`) — local 503 handling. The agent
  returns **503 + `Retry-After`** when its concurrency semaphore is saturated
  *and* the queued-waiter cap is exceeded. Because an HAProxy/nginx LB sits
  in front of the runtime pool with `option redispatch`, a 503 reaching the
  worker means **every replica is saturated**. Constants
  (`:45-48`): `_RETRY_ON_503_MAX_ATTEMPTS=5`, `_RETRY_ON_503_BASE_DELAY_S=1.0`,
  `_RETRY_ON_503_BACKOFF=2.0`, `_RETRY_ON_503_MAX_DELAY_S=30.0`. Delay =
  `max(Retry-After, exp_backoff) + random.uniform(0, 0.5)` jitter
  (`:209-216`). Non-503 errors bubble via `raise_for_status()`. After
  exhausting attempts, the last 503 is re-raised for Temporal's policy.

The per-request HTTP timeout is `task_input.timeout_seconds`
(`agent_client.py:289`).

### 1.8 Agent registry (`src/agent_registry.py`, `src/agents/olympus_agent.py`)

`OlympusAgentCard` fields: `name, description, url, skill_ids (list[str]),
capabilities, supported_models, preferred_model_tier (default "tier-2"),
assembly_lines, version ("0.1.0"), metadata`. `_expand_env_vars` resolves
`${VAR:-default}` strings in YAML config. The module exposes a singleton
`olympus_agent_registry` with `register`, `reload`, and `find_agent_for_skill`.
`find_agent_for_skill` matches an explicit `skill_ids` entry first, then
falls back to any card with an **empty `skill_ids` list** (the catch-all).

`src/agents/olympus_agent.py` defines the single catch-all card: `url`
defaults to `OLYMPUS_AGENT_URL` (`http://olympus-agent:8100`), `skill_ids=[]`,
`version="2.0.0"`. It **auto-registers on import** so the runtime always has
a default route. This realizes DECISION-019: one general-purpose runtime
serves every agent identity; `AGENT_NAME` selects the identity at the runtime
side, not via distinct cards.

### 1.9 The live|mock dispatch switch

**Location:** `temporal/olympus_workflows/activities/agent_dispatch.py:436-540`
(NOT in the worker package). The switch (`:472`):

```python
if os.environ.get("AGENT_RUNTIME_MODE", "live").strip().lower() == "mock":
    # → dispatch_via_mock (olympus-worker/src/testing/mock_agent_runtime.py)
else:
    # → olympus_api.src.services.agent_client.dispatch_via_a2a
    #   (falls through to olympus-worker/src/agent_client.dispatch_via_a2a)
```

Two guards make this safe:
- **Default is `live`.** Mock is opt-in.
- The worker **refuses to boot** in prod/staging while in mock mode
  (§1.2 / `src/config.py`). CI sets `AGENT_RUNTIME_MODE=mock` and
  `APP_ENV=test` (`.github/workflows/ci.yml:564-565`).

**Mock fixtures** (`src/testing/mock_agent_runtime.py`): JSON fixtures live at
`cross-cutting/skills/<skill_id>/fixtures/<scenario>.json`
(`OLYMPUS_SKILLS_ROOT` overrides the root). `load_fixture` resolves by, in
order: `context["fixture_scenario"]`, a single fixture file if exactly one
exists, else an error. `validate_all_fixtures` runs at test collection.
`dispatch_via_mock` returns an `AgentTaskResult` built from the fixture.

### 1.10 Build & dependencies

`olympus-worker/pyproject.toml` dependencies: `temporalio`, `pydantic`,
`pydantic-settings`, `PyGithub`, `pyyaml`, `Jinja2`, `structlog`,
`olympus-workflows`, `httpx`, `foundry-temporal`, `olympus-contracts`.
`requires-python >= 3.13`. `[tool.pytest.ini_options]` `asyncio_mode = "auto"`
and `addopts` include `--cov=src … --cov-fail-under=90` (DECISION-017 floor).

`olympus-worker/Dockerfile` (multi-stage, build context = repo root):
- Builder: `public.ecr.aws/docker/library/python:3.14-slim`; installs
  vendored wheels from `vendor/wheels/*.whl`, then the `temporal/` package,
  then the worker package (`pyproject.toml`, `src/`, `config/`).
  `PIP_EXTRA_INDEX_URL` ARG points at Artifactory in CI; vendored wheels are
  the local fallback.
- Runtime: copies site-packages + `/usr/local/bin` from builder, copies
  `src/` and `config/`, then **copies the canonical `GitService` from
  `olympus-api/src/services/git_service.py` to `/app/src/git_service.py`**
  (`Dockerfile:41`) — single source of truth, no duplication.
- `CMD ["python", "-m", "src.worker"]`.

### 1.11 Tests & coverage floor

Test files (`olympus-worker/tests/`): `test_agent_client.py`,
`test_agent_registry.py`, `test_compose_scale_compat.py`, `test_config.py`,
`test_config_agent_runtime_mode.py`, `test_dispatch_mock_switch.py`,
`test_fallback_adapter.py`, `test_mock_agent_runtime.py`,
`test_model_resolver.py`, `test_olympus_agent.py`, `test_renditions.py`,
`test_worker_entrypoint.py` (+ `conftest.py`).

**Coverage floor: 90%** (`--cov=src --cov-fail-under=90` in pyproject
`addopts`; DECISION-017). CI runs this leg on **Python 3.13**, `cov_source: src`
(`.github/workflows/ci.yml:498-505`), gated by `worker_changed`. The CI
invocation (`ci.yml:583-588`):
```
pytest --cov=src --cov-report=term-missing --cov-report=xml:coverage.xml --tb=short -q
```
with `AGENT_RUNTIME_MODE=mock`, `APP_ENV=test`. Dependencies are installed
editable from `olympus-contracts`, `temporal`, then `./olympus-worker[dev]`
(`ci.yml:537-552`). Lint gate: `ruff check .`.

### 1.12 Config YAML reference

- **`config/models.yaml`** — providers `claude`/`openai`/`gemini`, each with
  tier→model maps, plus `task_defaults` (task_type → default tier).
- **`config/services.yaml`** — service URLs, e.g. `olympus_api:
  http://olympus-api:8000`.
- **`config/agents.yaml`** — a single catch-all agent `olympus-agent`, `url:
  ${OLYMPUS_AGENT_URL:-http://olympus-agent:8100}`, `skill_ids: []`.
- **`config/workflows.yaml`** — the 12 workflow classes to register.
- **`config/activities.yaml`** — 4 activity modules with timeouts:
  `agent_dispatch` (`dispatch_agent_task`, 1800s),
  `git_operations` (read/write/create_pr),
  `gate_operations` (check/submit/wait, 172800s = 48h),
  `scoring` (calculate/record).

### 1.13 Model resolver (`src/model_resolver.py`)

`DEFAULT_TIER_MAP` maps (provider, tier) → concrete model id, overridable by
the `MODEL_TIER_{1,2,3}_{CLAUDE,OPENAI,GEMINI}` env vars. Resolution order:
explicit preference → per-app override → task-type default → default tier.

### 1.14 Deprecated fallback adapter (`src/fallback_adapter.py`)

Subprocess fallback path, **disabled by default**. Gated by
`ENABLE_SUBPROCESS_FALLBACK=1`; default timeout 1800s. When disabled it
returns a `FAILED` `AgentTaskResult`. Kept only for backward compatibility.

### 1.15 Atomic Rebuild Checklist — olympus-worker

1. **Scaffold package.** Create `olympus-worker/{src,config,tests}` with
   `pyproject.toml` (deps in §1.10, `requires-python>=3.13`,
   `asyncio_mode=auto`, `addopts` incl. `--cov=src --cov-fail-under=90`).
   *Accept:* `pip install -e ./olympus-worker[dev]` succeeds.
2. **WorkerConfig.** Implement `src/config.py` with the table in §1.3,
   `_NON_TEST_ENVS`, `get_database_url`, `get_async_database_url`,
   `validate_agent_runtime_mode` raising `MockInProductionError`.
   *Accept:* `pytest tests/test_config.py tests/test_config_agent_runtime_mode.py`
   green; `APP_ENV=prod AGENT_RUNTIME_MODE=mock python -c "import src.config as c; c.validate_agent_runtime_mode()"` exits non-zero.
3. **Model resolver.** Implement `src/model_resolver.py` (§1.13).
   *Accept:* `pytest tests/test_model_resolver.py` green.
4. **Agent registry + catch-all card.** Implement `src/agent_registry.py`
   (`OlympusAgentCard`, `_expand_env_vars`, `find_agent_for_skill`, singleton)
   and `src/agents/olympus_agent.py` (auto-register on import).
   *Accept:* `pytest tests/test_agent_registry.py tests/test_olympus_agent.py` green.
5. **A2A client.** Implement `src/agent_client.py` per §1.7 (request shape,
   `_extract_result`, `AGENT_RETRY_POLICY`, `_post_with_saturation_retry`).
   *Accept:* `pytest tests/test_agent_client.py` green (covers 503 retry +
   response mapping).
6. **Mock runtime + dispatch switch.** Implement
   `src/testing/mock_agent_runtime.py` (fixture resolution) and confirm the
   `AGENT_RUNTIME_MODE` switch in the `temporal` activity routes to it.
   *Accept:* `pytest tests/test_mock_agent_runtime.py tests/test_dispatch_mock_switch.py` green.
7. **Fallback adapter + rendition engine.** Implement
   `src/fallback_adapter.py` (gated) and `src/renditions/engine.py`.
   *Accept:* `pytest tests/test_fallback_adapter.py tests/test_renditions.py` green.
8. **Config YAMLs.** Author the five `config/*.yaml` files per §1.12.
   *Accept:* the worker loads them at boot without error; `agents.yaml`
   yields one catch-all card.
9. **Entry point.** Implement `src/worker.py` (§1.2: identity resolution,
   agent-config load, Temporal bootstrap, workflow/activity registration,
   SIGHUP reload, prod-mode rail).
   *Accept:* `pytest tests/test_worker_entrypoint.py tests/test_compose_scale_compat.py` green.
10. **Coverage gate.** *Accept:* `pytest` (with `--cov-fail-under=90`) passes
    at ≥90%; `ruff check .` clean.
11. **Container.** Author the multi-stage `Dockerfile` (§1.10) copying
    `git_service.py` from olympus-api.
    *Accept:* `docker build -f olympus-worker/Dockerfile .` succeeds and the
    image runs `python -m src.worker` (polls the configured task queue —
    visible as a distinct identity in Temporal UI).

---

## 2. olympus-agent-runtime

### 2.1 Responsibility

The general-purpose **agent execution runtime**. A FastAPI service exposing
the A2A endpoint. It accepts a task (skill + app + context + model
preference), loads the skill definition, selects a concrete model, sets up an
isolated workspace, runs the Claude Agent SDK against the skill prompt,
validates the structured output against a JSON Schema (with one retry), emits
telemetry to the Olympus API, and returns an A2A response. One image serves
**all** agent identities; `AGENT_NAME` selects which (DECISION-019,
`docker-compose.yml:334-336`).

Supports two modes: **live** (real inference via Bedrock/Anthropic) and
**mock** (deterministic, for tests). The runtime is the *server* side of the
worker's A2A client (§1.7).

### 2.2 Entry point & startup

`create_app()` factory in `olympus-agent-runtime/src/main.py`. Container CMD:
`uvicorn src.main:create_app --factory --host 0.0.0.0 --port 8100`
(Dockerfile). On startup `main.py` initializes an
`asyncio.Semaphore(max_concurrent_tasks)` plus a queued-waiter cap
(`init_concurrency` / `init_semaphore`). The semaphore is the basis for the
503/Retry-After saturation signal (§2.6).

### 2.3 Configuration (`src/config.py`)

`AgentRuntimeConfig` (`pydantic-settings`):

| Field | Default | Env |
|---|---|---|
| `agent_port` | `8100` | `AGENT_PORT` |
| `skills_dir` | `/app/skills` | `SKILLS_DIR` |
| `inference_provider` | `bedrock` | `INFERENCE_PROVIDER` (`bedrock`/`anthropic`) |
| `bedrock_model_prefix` | `us` | region/inference-profile prefix |
| `permission_mode` | `acceptEdits` | Claude Agent SDK permission mode |
| `workspace_dir` | `/workspace` | task workspace root |
| `max_concurrent_tasks` | `12` | semaphore size |
| `max_queued_waiters` | `2` | queued-waiter cap before 503 |

Other env consumed by services: `AGENT_NAME` (identity selector,
`docker-compose.yml:353`), `DEFAULT_MODEL_TIER` (`tier-2`),
`AWS_REGION`/`AWS_PROFILE` (Bedrock), `OLYMPUS_API_URL`/`OLYMPUS_API_TOKEN`
(telemetry, §2.10), `OLYMPUS_SCHEMA_ROOT` (output validation, §2.9),
`OLYMPUS_PROFILE_ROOT` (mission context, §2.11), `AGENT_RUNTIME_MODE`
(live|mock).

### 2.4 Ports

**8100** (HTTP). Exposed in the Dockerfile (`EXPOSE 8100`) and behind the
`olympus-agent` LB in compose; replicas don't bind host ports (the LB binds
8100, `docker-compose.yml:338-344`).

### 2.5 Internal module structure

```
olympus-agent-runtime/
├── src/
│   ├── main.py                 # create_app factory, semaphore init
│   ├── config.py               # AgentRuntimeConfig
│   ├── routers/
│   │   ├── a2a.py              # POST /a2a/tasks (the contract)
│   │   └── health.py          # GET /health, /health/ready
│   ├── models/
│   │   └── a2a.py             # A2AContext/A2ATaskRequest/Response, TokenUsage, OutputFile
│   └── services/
│       ├── agent_executor.py  # the execution pipeline (SDK)
│       ├── skill_loader.py    # SkillDefinition + API-first load + profile overlays
│       ├── model_selector.py  # config/models.yaml → concrete model
│       ├── output_validator.py# Draft202012 JSON-Schema validation
│       ├── task_recorder.py   # telemetry to Olympus API
│       └── profile_context.py # OLYMPUS_PROFILE_ROOT mission context
├── config/
│   ├── models.yaml
│   └── skill_mapping.yaml     # empty placeholder (filesystem fallback)
├── tests/                     # see §2.12
├── pyproject.toml
└── Dockerfile
```

### 2.6 The A2A endpoint contract (`src/routers/a2a.py`, `src/models/a2a.py`)

**`POST /a2a/tasks`**

Request body (`A2ATaskRequest`):
```json
{
  "task": "string (human-readable task message)",
  "context": {
    "app_id": "string",
    "skill_id": "string",
    "task_type": "string",
    "input_artifacts": ["..."],
    "optional_input_artifacts": ["..."],
    "model_preference": "string|''",
    "source_repo": "string?",
    "artifact_repo": "string?",
    "artifact_ref": "string?",
    "workspace_key": "string?",
    "extras": { }
  },
  "model_preference": "string|''"
}
```
Response body (`A2ATaskResponse`):
```json
{
  "status": "completed|failed",
  "output_artifacts": ["..."],
  "output_files": [{"path": "...", "content": "...", "encoding": "utf-8"}],
  "token_usage": {"input": 0, "output": 0},
  "cost_estimate_usd": 0.0,
  "model_used": "string",
  "error": "string"
}
```
This shape is the exact counterpart of the worker client's request/response
mapping in §1.7 — they must stay in lockstep.

**Saturation behavior.** When the semaphore is saturated **and** the
queued-waiter count exceeds `max_queued_waiters`, the endpoint returns **HTTP
503** with header `Retry-After: 5` instead of queueing indefinitely. This is
the health-aware-routing-without-a-sidecar signal the worker's
`_post_with_saturation_retry` (and the LB) consume.

**`_execute` pipeline** (called under the semaphore): resolve+load skill →
select model → build system prompt + workspace → run SDK → validate output
(retry once with a feedback marker on failure) → record telemetry → assemble
`A2ATaskResponse`.

### 2.7 Health (`src/routers/health.py`)

- `GET /health` — liveness (always 200 if the process is up).
- `GET /health/ready` — readiness. Dockerfile `HEALTHCHECK` hits `/health`.

### 2.8 Execution pipeline (`src/services/agent_executor.py`)

`execute_skill(...)`: builds the system prompt via `build_system_prompt`
(skill prompt + mission context from `profile_context`), sets up a structured
workspace under `workspace_dir`, fetches input artifacts from GitHub using the
**Trees + Blobs API** (so large trees are fetched efficiently), then runs the
**Claude Agent SDK** (`claude_agent_sdk.query`). If the assembled system
prompt exceeds **64 KB** it is spilled to a system-prompt file and passed by
reference. Output is validated against the skill's JSON Schema; on validation
failure the executor retries once, injecting a **retry-feedback marker** with
the validation errors into the prompt. The SDK import is gated behind the
`[agent]` optional-dependency extra so the package imports cleanly in
environments without the SDK (e.g. lint-only or mock CI legs).

### 2.9 Skill loading & output validation

- `src/services/skill_loader.py` — `SkillDefinition`. **API-first**:
  `load_skill_from_api` calls `GET /api/v1/skills/dispatch/{skill_id}` on the
  Olympus API; `resolve_and_load_skill` falls back to the filesystem
  (`skill_mapping.yaml`, currently empty) when the API is unavailable.
  Applies **profile overlays** so a profile (e.g. FAA) can override skill
  behavior.
- `src/services/output_validator.py` — uses `jsonschema.Draft202012Validator`;
  schema files resolved from `OLYMPUS_SCHEMA_ROOT`.
- `src/services/model_selector.py` — loads `config/models.yaml`, `select()`
  resolves a tier/alias preference → concrete provider model.

### 2.10 Telemetry (`src/services/task_recorder.py`)

Fire-and-forget POSTs to the Olympus API **Agents domain** recording task
start/finish, token usage, cost, model used, and error codes (an
`ERROR_CODE_*` enum). Uses `OLYMPUS_API_URL` and `OLYMPUS_API_TOKEN`. Failures
to record are non-fatal (telemetry must never break execution).

### 2.11 Mission context (`src/services/profile_context.py`)

Loads `profile.yaml` mission context from `OLYMPUS_PROFILE_ROOT` (compose:
`/app/repo/profiles/faa`) and injects it into the system prompt so the agent
operates with the client profile's mission framing.

### 2.12 Build, dependencies, tests

`pyproject.toml`: base deps `fastapi`, `uvicorn`, `pydantic`, `boto3`,
`jsonschema`; optional `[agent]` extra = `claude-agent-sdk`,
`anthropic[bedrock]`. `requires-python >= 3.13`. `asyncio_mode=auto`,
`addopts` include `--cov-fail-under=90`.

`Dockerfile`: python:3.14-slim, `EXPOSE 8100`, `HEALTHCHECK` against
`/health`, `CMD uvicorn src.main:create_app --factory --host 0.0.0.0 --port 8100`.

Test files (`tests/`): `test_a2a_endpoint.py`, `test_agent_executor.py`,
`test_health.py`, `test_model_selector.py`, `test_output_validator.py`,
`test_profile_context.py`, `test_skill_loader.py`, `test_skill_loader_api.py`,
`test_skill_loader_profile.py`, `test_task_recorder.py` (+ `conftest.py`).

**Coverage floor: 90%.** CI runs on **Python 3.13**, `cov_source: src`
(`.github/workflows/ci.yml:494-497`), gated by `agent_runtime_changed`, same
invocation/env as §1.11.

### 2.13 config/models.yaml & skill_mapping.yaml

- `config/models.yaml` — `bedrock` and `anthropic` provider sections, each
  with tier maps and model aliases.
- `config/skill_mapping.yaml` — currently an **empty placeholder**; the
  filesystem fallback path exists but the catalog is served by the API.

### 2.14 Atomic Rebuild Checklist — olympus-agent-runtime

1. **Scaffold + deps.** Create the package with `pyproject.toml` (base +
   `[agent]` extra, `requires-python>=3.13`, `--cov-fail-under=90`).
   *Accept:* `pip install -e ./olympus-agent-runtime[dev]` succeeds; importing
   `src.main` works without the `[agent]` extra installed.
2. **Config.** Implement `src/config.py` (§2.3 table).
   *Accept:* defaults match the table; env overrides applied.
3. **A2A models.** Implement `src/models/a2a.py` (`A2AContext`,
   `A2ATaskRequest`, `A2ATaskResponse`, `TokenUsage`, `OutputFile`).
   *Accept:* round-trips the JSON in §2.6.
4. **Health router.** Implement `src/routers/health.py`.
   *Accept:* `pytest tests/test_health.py` green; `GET /health` → 200.
5. **Model selector.** Implement `src/services/model_selector.py` +
   `config/models.yaml`.
   *Accept:* `pytest tests/test_model_selector.py` green.
6. **Skill loader.** Implement `src/services/skill_loader.py` (API-first +
   filesystem fallback + profile overlays) and `config/skill_mapping.yaml`.
   *Accept:* `pytest tests/test_skill_loader*.py` green (API, profile, fallback).
7. **Output validator.** Implement `src/services/output_validator.py`
   (Draft202012, `OLYMPUS_SCHEMA_ROOT`).
   *Accept:* `pytest tests/test_output_validator.py` green.
8. **Profile context + task recorder.** Implement `profile_context.py` and
   `task_recorder.py` (fire-and-forget, `ERROR_CODE_*`).
   *Accept:* `pytest tests/test_profile_context.py tests/test_task_recorder.py` green.
9. **Executor.** Implement `src/services/agent_executor.py` (system-prompt
   build + 64KB spill, Trees+Blobs fetch, SDK run gated by `[agent]`,
   validate-with-one-retry feedback marker).
   *Accept:* `pytest tests/test_agent_executor.py` green (mock SDK).
10. **A2A endpoint.** Implement `src/routers/a2a.py` (`POST /a2a/tasks`, the
    `_execute` pipeline, 503+`Retry-After:5` on saturation).
    *Accept:* `pytest tests/test_a2a_endpoint.py` green incl. the 503 path.
11. **App factory.** Implement `src/main.py` (`create_app`, semaphore init).
    *Accept:* `uvicorn src.main:create_app --factory --port 8100` boots;
    `curl :8100/health` → 200.
12. **Coverage + lint.** *Accept:* `pytest` ≥90%; `ruff check .` clean.
13. **Container.** Author `Dockerfile` (EXPOSE 8100, HEALTHCHECK, uvicorn
    factory CMD).
    *Accept:* `docker build -f olympus-agent-runtime/Dockerfile .` succeeds;
    container reports healthy.

---

## 3. mcp-server

### 3.1 Responsibility

The **Model Context Protocol (MCP) server** — a JSON-RPC 2.0 server that
exposes Olympus capabilities as MCP **resources** (read-only data) and
**tools** (actions) to MCP-capable agents. Most reads proxy to the Olympus
API; a few catalog/analysis/disposition reads go **directly to Postgres** via
`asyncpg`.

### 3.2 Entry point & startup

`olympus_mcp/server.py` `main()` parses `--host` (default `127.0.0.1`),
`--port` (default `3001`), and `--dump-schemas`. It serves JSON-RPC over a
`BaseHTTPRequestHandler`. The MCP `initialize` method advertises
`protocolVersion = 2024-11-05`. `python -m olympus_mcp.server` and the
`olympus-mcp` console script (`pyproject.toml`) are equivalent entry points.
Container CMD: `python3 -m olympus_mcp.server --host 0.0.0.0 --port 3001`
(Dockerfile).

### 3.3 Configuration / env vars

- `--host` / `--port` CLI flags (compose binds `3001:3001`,
  `docker-compose.yml:476-477`).
- `OLYMPUS_API_URL` (default `http://localhost:8000`) — proxy target
  (`tools/http.py`).
- `OLYMPUS_SERVICE_TOKEN` — service auth bearer for non-public tools
  (`tools/auth.py`); `_PUBLIC_TOOLS` set is exempt.
- Direct-DB reads: `DATABASE_HOST`, `DATABASE_PORT`, `DATABASE_USER`,
  `DATABASE_PASSWORD`, `DATABASE_NAME` (`olympus_mcp/db.py`).

### 3.4 Ports

**3001** (HTTP/JSON-RPC). `EXPOSE 3001` in Dockerfile.

### 3.5 Internal module structure

```
mcp-server/
├── olympus_mcp/
│   ├── server.py              # JSON-RPC server, main(), initialize
│   ├── db.py                  # asyncpg get_connection from DATABASE_* env
│   ├── schemas.py             # tool/resource JSON schemas
│   ├── resources/registry.py  # 16 resources
│   ├── tools/
│   │   ├── registry.py        # 29 tools
│   │   ├── http.py            # api_get/api_post proxy (OLYMPUS_API_URL)
│   │   ├── auth.py            # _PUBLIC_TOOLS, OLYMPUS_SERVICE_TOKEN
│   │   └── hashing.py         # sha256_file (64KiB chunks)
│   └── handlers/              # catalog/analysis/disposition/task/bundle/artifact
├── tests/                     # see §3.8
├── pyproject.toml
└── Dockerfile
```

### 3.6 Exposed resources (16) and tools (29)

**Resources (16):** read-only data resources surfaced over MCP. They include
catalog/analysis/disposition reads plus human-paired-agent and bundle
resources (see `resources/registry.py`; tests
`test_human_paired_resources.py`).

**Tools (29 total):**
- **7** local dev tools — git/scan/test family.
- **8** `olympus.api.*` — generic API proxies.
- **3** `olympus.artifact.*` — artifact operations.
- **4** `olympus.task.*` — human-paired-agent task operations
  (list/show/return/feedback analogs).
- **7** `olympus.bundle.*` — delegated-bundle operations
  (list/show/contract/claim/release/validate/submit/audit family, mirroring
  the CLI in §4.4).

### 3.7 Data access split (handlers)

- **Direct Postgres (`asyncpg`):**
  - **catalog** & **disposition** handlers read the `application` table.
  - **analysis** handler reads the `gate` table's `evidence_data` JSONB.
- **Proxy to Olympus API (`tools/http.py` `api_get`):** everything else.
- `tools/auth.py` attaches `Authorization: Bearer <OLYMPUS_SERVICE_TOKEN>`
  for non-public tools; tools in `_PUBLIC_TOOLS` skip auth.
- `tools/hashing.py` `sha256_file` streams in 64KiB chunks — byte-for-byte
  identical to the CLI hasher (§4.6) so a hash from either surface matches.

### 3.8 Build, dependencies, tests

`pyproject.toml`: deps `pydantic`, `jsonschema`, `asyncpg`, `httpx`,
`olympus-contracts`; console script `olympus-mcp`; `requires-python >= 3.11`;
`asyncio_mode=auto`; `addopts` include `--cov-fail-under=90`.

`Dockerfile`: `EXPOSE 3001`, `CMD python3 -m olympus_mcp.server --host 0.0.0.0 --port 3001`.

Test files (`tests/`): `test_bundle_handlers.py`, `test_handlers.py`,
`test_human_paired_agent.py`, `test_human_paired_resources.py`,
`test_schemas.py`, `test_server_and_db.py`, `test_tool_handlers.py`.

**Coverage floor: 90%.** CI runs on **Python 3.12**, `cov_source: olympus_mcp`
(`.github/workflows/ci.yml:502-505`), gated by `mcp_changed`, same
invocation/env as §1.11.

### 3.9 Atomic Rebuild Checklist — mcp-server

1. **Scaffold + deps.** Create `mcp-server/{olympus_mcp,tests}` with
   `pyproject.toml` (deps in §3.8, `requires-python>=3.11`, `olympus-mcp`
   script, `--cov-fail-under=90`).
   *Accept:* `pip install -e ./mcp-server[dev]` succeeds; `olympus-mcp --help`
   runs.
2. **DB layer.** Implement `olympus_mcp/db.py` (`get_connection` from
   `DATABASE_*`).
   *Accept:* `pytest tests/test_server_and_db.py` green.
3. **Schemas.** Implement `olympus_mcp/schemas.py`.
   *Accept:* `pytest tests/test_schemas.py` green; `--dump-schemas` emits valid
   JSON Schema.
4. **HTTP proxy + auth + hashing helpers.** Implement `tools/http.py`,
   `tools/auth.py` (`_PUBLIC_TOOLS`, `OLYMPUS_SERVICE_TOKEN`),
   `tools/hashing.py` (64KiB `sha256_file`).
   *Accept:* hashing returns the same digest as the CLI for the same file.
5. **Handlers.** Implement catalog/disposition (→ `application`), analysis
   (→ `gate.evidence_data`), and api-proxy handlers; task and bundle handlers.
   *Accept:* `pytest tests/test_handlers.py tests/test_tool_handlers.py
   tests/test_bundle_handlers.py tests/test_human_paired_agent.py` green.
6. **Registries.** Implement `resources/registry.py` (16 resources) and
   `tools/registry.py` (29 tools per §3.6).
   *Accept:* `pytest tests/test_human_paired_resources.py` green; tool/resource
   counts match.
7. **Server.** Implement `olympus_mcp/server.py` (JSON-RPC, `initialize` →
   `protocolVersion 2024-11-05`, `main()` flags).
   *Accept:* a JSON-RPC `initialize` over `:3001` returns the protocol version;
   `tools/list` and `resources/list` enumerate the full sets.
8. **Coverage + lint.** *Accept:* `pytest` ≥90%; `ruff check .` clean.
9. **Container.** Author `Dockerfile` (EXPOSE 3001, module CMD).
   *Accept:* `docker build -f mcp-server/Dockerfile .` succeeds; `curl`-style
   JSON-RPC `initialize` against the running container succeeds.

---

## 4. olympus-cli

### 4.1 Responsibility

The **`olympus` collaboration CLI** — a thin, deterministic `click` client a
human (or their local agent) uses to fetch/accept/return human-paired-agent
tasks and operate on delegated bundles, artifacts, and skills. Per memo §11.3
every command emits **structured output** (table or JSON) safe for an agent to
parse. The CLI is intentionally "dumb": **no retries** (retries are the
agent's job, `api.py:9-10`).

> **Drift / fact:** `olympus-cli` has **no Dockerfile** and is **not** part of
> the CI python test matrix (`.github/workflows/ci.yml:480-505` lists only
> olympus-api, temporal, olympus-agent-runtime, olympus-worker, mcp-server).
> It ships as a pip-installable console script, run on a developer's machine.

### 4.2 Entry point

`pyproject.toml` `[project.scripts] olympus = "olympus_cli.main:cli"`.
`python -m olympus_cli` works via `olympus_cli/__main__.py` →
`olympus_cli.main:main` → `cli(standalone_mode=True)`. The top-level group
accepts `--api-url`, `--token`, `--output {table,json}` and builds a
`CLIContext` via `load_context` (`main.py:42-62`).

### 4.3 Configuration (`olympus_cli/config.py`)

`CLIContext(api_url, token, output)`. Resolution order (flag → env → file →
default):
- `api_url`: `--api-url` → `OLYMPUS_API_URL` → `http://localhost:8000`
  (trailing slash stripped).
- `token`: `--token` → `OLYMPUS_TOKEN` → `~/.olympus/config.json` `"token"`.
- `output`: `--output` → `OLYMPUS_OUTPUT` → `table`.

`write_token(token)` (used by `auth login`) writes `~/.olympus/config.json`
with dir mode `0700` and file mode `0600`, preserving any other keys
(`config.py:64-81`).

### 4.4 Commands (every one)

`olympus_cli/main.py` registers groups `task`, `artifact`, `skill`, `auth`
plus the `bundle` subgroup (`bundle.py`). Each command calls the API and
`emit`s the result.

**`task` group** (`main.py:78-290`):
- `task list [--include-claimable/--owned-only] [--limit N]` → `GET
  /api/v1/me/tasks` with `include_claimable`, `limit` params.
- `task show <task_id>` → `GET /api/v1/agent-tasks/{id}/audit-narrative`.
- `task accept <task_id>` → `POST /api/v1/agent-tasks/{id}/return` with
  `{status: needs_help, feedback_text: "accepted via …"}` (no-op return that
  stamps the caller's `human_user_id`; memo §14 open-question 2).
- `task return <task_id>` — two modes: `--payload <file>` posts the file's
  JSON verbatim, OR inline flags (`--status {completed,needs_help}`,
  `--implementation-notes`, repeatable `--result`, repeatable `--evidence`,
  `--transcript-ref`) assembled by `_assemble_return_payload` (`main.py:204`)
  into a `TaskReturnRequest`. POST `/api/v1/agent-tasks/{id}/return`.
- `task transcript <task_id> <file> [--tool claude-code] [--model] [--version]`
  — SHA-256s the file (64KiB chunks, `main.py:257-262`) and POSTs a
  `needs_help` return carrying a `local_agent_session` block.
- `task feedback <task_id> <text>` → POST return with `{status: needs_help,
  feedback_text: text}`.

**`artifact` group** (`main.py:298-335`):
- `artifact get <ref>` → `GET /api/v1/artifacts/by-path?path=<ref>`.
- `artifact list (--task <id> | --app <id>)` — `--task` reads the task's
  audit-narrative and lists output + session refs; `--app` → `GET
  /api/v1/artifacts/{app_id}`. Requires one of the two flags.

**`skill` group** (`main.py:343-380`):
- `skill install <skill_id> [--source DIR] [--target DIR]` — copies
  `cross-cutting/skills/<skill_id>/` into the local agent's skills dir via
  `install_skill` (§4.5). Exits `2` on `SkillInstallError`.

**`auth` group** (`main.py:388-399`):
- `auth login --token <token>` → `write_token`, persists to
  `~/.olympus/config.json`.

**`bundle` subgroup** (`bundle.py`) — delegated bundles (Phase 5 W20):
- `bundle list [--status …] [--scope-kind {gate_packet,line_step}]
  [--application-id] [--wave-id] [--mine-only] [--limit] [--offset]` → `GET
  /api/v1/me/bundles`.
- `bundle show <id>` → `GET /api/v1/bundles/{id}`.
- `bundle contract <id> [--out FILE]` — extracts the contract slice
  (`bundle_id, scope_kind, target_id, portfolio_id, application_id, wave_id,
  status, expires_at, inputs, outputs`) from the envelope; writes to file or
  stdout.
- `bundle claim <id> [--tool] [--version] [--model]` → `POST
  /api/v1/bundles/{id}/claim` (idempotent for same caller; 409 on collision).
- `bundle release <id> [--reason]` → `POST /api/v1/bundles/{id}/release`.
- `bundle validate <id> --outputs FILE [--session FILE]` → `POST
  /api/v1/bundles/{id}/validate` (dry-run).
- `bundle submit <id> --outputs FILE [--session FILE]` → `POST
  /api/v1/bundles/{id}/submit` (atomic; success → `accepted` + Temporal
  signal).
- `bundle audit <id>` → `GET /api/v1/bundles/{id}/audit`.

`--outputs` files map `artifact_kind → artifact_ref` (validated as a flat
string→string JSON object, `bundle.py:45-69`). `--session` files are JSON
arrays of `{kind, artifact_ref, hash?}`; missing hashes are filled by
`fill_session_hashes` (§4.6).

### 4.5 Skill install (`olympus_cli/skill_install.py`)

`install_skill(skill_id, source_dir=None, target_dir=None)`:
- Rejects empty / path-traversing ids (`/`, `..`, leading `.`).
- Source: `--source` → `OLYMPUS_SKILL_SOURCE_DIR` → walk up from the package
  looking for `cross-cutting/skills/`. Requires `<src>/SKILL.md` to exist.
- Target: `--target` → `CLAUDE_AGENT_SKILLS_DIR` → `./.claude/skills/` if a
  `.claude` dir exists in CWD, else `~/.claude/skills/`.
- Copies the whole skill dir (removing any existing target first).

### 4.6 HTTP, output, hashing helpers

- `olympus_cli/api.py` — `get(ctx, path, params=None)` (30s timeout) and
  `post(ctx, path, json=...)` (60s timeout). Forwards `Authorization: Bearer`
  from the context, `Accept: application/json`. Non-2xx → `OlympusAPIError`
  with the parsed body intact. **No retries.**
- `olympus_cli/output.py` — `emit(ctx, payload)`: `json` mode pretty-prints
  (`sort_keys`, `default=str`); `table` mode renders lists/`items` envelopes as
  an aligned text table (skipping nested list/dict columns) and dicts as
  `key: value` (nested → indented JSON). No external table dependency.
- `olympus_cli/hashing.py` — `sha256_file(path)` streams in **64KiB** chunks
  (identical to the MCP hasher, §3.7); `fill_session_hashes(session)` returns a
  new list with `hash` filled per entry (validates `kind`/`artifact_ref`,
  passes through caller-supplied hashes).

### 4.7 Build, dependencies, tests

`pyproject.toml`: deps `httpx>=0.27`, `click>=8.1`, `pydantic>=2,<3`;
`requires-python >= 3.11`; `[project.scripts] olympus`. Pytest:
`asyncio_mode=auto`, `testpaths=["tests"]`, `addopts="-q"` — **no coverage
floor** (unlike the other three; the CLI is not in the CI coverage matrix).
Ruff `target-version=py311`, `line-length=100`, lint select `E,F,I,W`.

Test files (`tests/`): `test_bundle_cli.py`, `test_cli_smoke.py`.

### 4.8 Atomic Rebuild Checklist — olympus-cli

1. **Scaffold + deps.** Create `olympus-cli/{olympus_cli,tests}` with
   `pyproject.toml` (deps in §4.7, `requires-python>=3.11`, `olympus` script,
   `addopts="-q"`).
   *Accept:* `pip install -e ./olympus-cli[dev]`; `olympus --help` lists groups
   `task`, `artifact`, `skill`, `auth`, `bundle`.
2. **Config.** Implement `config.py` (`CLIContext`, `load_context`
   resolution order, `write_token` 0700/0600).
   *Accept:* `OLYMPUS_API_URL` and `~/.olympus/config.json` resolve as in §4.3.
3. **HTTP + output.** Implement `api.py` (get/post, `OlympusAPIError`, no
   retries) and `output.py` (table/json `emit`).
   *Accept:* `emit` produces both formats; a non-2xx raises `OlympusAPIError`
   with the body intact.
4. **Hashing.** Implement `hashing.py` (64KiB `sha256_file`,
   `fill_session_hashes`).
   *Accept:* digest matches the MCP hasher for the same file.
5. **Skill install.** Implement `skill_install.py` (id validation, source
   resolution incl. `OLYMPUS_SKILL_SOURCE_DIR`, target resolution incl.
   `CLAUDE_AGENT_SKILLS_DIR`).
   *Accept:* installing a valid skill copies `SKILL.md`; a `../`-style id exits 2.
6. **task/artifact/skill/auth groups.** Implement `main.py` per §4.4.
   *Accept:* `pytest tests/test_cli_smoke.py` green; each command hits the
   documented endpoint (verify against a mock server).
7. **bundle subgroup.** Implement `bundle.py` per §4.4 (incl. `_read_outputs_file`,
   `_read_session_file`, `_build_submit_body`, `_build_descriptor`).
   *Accept:* `pytest tests/test_bundle_cli.py` green.
8. **Entry point.** Implement `__main__.py` and the `main()` wrapper.
   *Accept:* `python -m olympus_cli --help` works; `olympus` console script
   resolves.
9. **Lint + tests.** *Accept:* `ruff check .` clean; `pytest -q` green. (No
   coverage floor — this package is excluded from the CI coverage matrix.)

---

## 5. Cross-service contracts & shared invariants

These bind the four services together; a regeneration that breaks any one
desyncs the system.

1. **A2A request/response shape** (§1.7 ⇄ §2.6) is the worker↔runtime
   contract. The worker sends `{task, context, model_preference}` to
   `POST /a2a/tasks`; the runtime returns `{status, output_artifacts,
   output_files[], token_usage{input,output}, cost_estimate_usd, model_used,
   error}`. `model_preference` must be **empty** unless the caller explicitly
   overrides, so the runtime resolves the skill's declared tier.
2. **503 + `Retry-After` saturation protocol** (§2.6 ⇄ §1.7). Runtime emits
   503/`Retry-After:5` when the semaphore is saturated past
   `max_queued_waiters`; the worker (and LB) retry against the logical DNS
   name. This is health-aware routing with no sidecar.
3. **`AGENT_RUNTIME_MODE` (live|mock)** governs the worker's dispatch switch
   (§1.9) and is forced to `mock` in CI (`ci.yml:564`). Default `live`; the
   worker **refuses to boot** in prod/staging while mock (DECISION-018).
4. **64KiB SHA-256 streaming** is shared, byte-for-byte, between the CLI
   (`olympus_cli/hashing.py`), the per-skill `task transcript` flow, and the
   MCP `olympus.bundle.*` family (`mcp-server/.../tools/hashing.py`). Any
   re-implementation must keep the chunk size at `64 * 1024`.
5. **Bundle/task endpoints** are the same surface the CLI (§4.4) and MCP
   tools (§3.6) call: `/api/v1/me/tasks`, `/api/v1/agent-tasks/{id}/return`,
   `/api/v1/agent-tasks/{id}/audit-narrative`, `/api/v1/me/bundles`,
   `/api/v1/bundles/{id}` (+ `/claim`, `/release`, `/validate`, `/submit`,
   `/audit`), `/api/v1/artifacts/by-path`, `/api/v1/artifacts/{app_id}`.
6. **Coverage floors:** worker, agent-runtime, mcp-server = **90%**
   (`--cov-fail-under=90`, DECISION-017, enforced via each pyproject `addopts`
   in CI `ci.yml:583-588`). CLI has **no floor**. Python versions in CI:
   worker/agent-runtime **3.13**, mcp-server **3.12**, CLI **3.11** (its
   `requires-python`); Docker base images are `python:3.14-slim`.
7. **One runtime, many identities** (DECISION-019): the worker has a single
   catch-all agent card; the runtime selects identity via `AGENT_NAME`; the
   LB (`olympus-agent`, host port 8100) fronts the replica pool with
   `least_conn`.
